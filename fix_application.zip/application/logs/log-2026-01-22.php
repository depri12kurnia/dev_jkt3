<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-22 07:46:16 --> Config Class Initialized
INFO - 2026-01-22 07:46:16 --> Hooks Class Initialized
DEBUG - 2026-01-22 07:46:16 --> UTF-8 Support Enabled
INFO - 2026-01-22 07:46:16 --> Utf8 Class Initialized
INFO - 2026-01-22 07:46:16 --> URI Class Initialized
DEBUG - 2026-01-22 07:46:16 --> No URI present. Default controller set.
INFO - 2026-01-22 07:46:16 --> Router Class Initialized
INFO - 2026-01-22 07:46:17 --> Output Class Initialized
INFO - 2026-01-22 07:46:17 --> Security Class Initialized
DEBUG - 2026-01-22 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-22 07:46:17 --> CSRF cookie sent
INFO - 2026-01-22 07:46:17 --> Input Class Initialized
INFO - 2026-01-22 07:46:17 --> Language Class Initialized
INFO - 2026-01-22 07:46:17 --> Loader Class Initialized
INFO - 2026-01-22 07:46:17 --> Helper loaded: url_helper
INFO - 2026-01-22 07:46:17 --> Helper loaded: text_helper
INFO - 2026-01-22 07:46:17 --> Helper loaded: string_helper
INFO - 2026-01-22 07:46:17 --> Helper loaded: form_helper
INFO - 2026-01-22 07:46:17 --> Helper loaded: download_helper
INFO - 2026-01-22 07:46:17 --> Helper loaded: security_helper
INFO - 2026-01-22 07:46:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-22 07:46:18 --> Database Driver Class Initialized
DEBUG - 2026-01-22 07:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-22 07:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-22 07:46:18 --> Form Validation Class Initialized
INFO - 2026-01-22 07:46:18 --> Model "User_model" initialized
INFO - 2026-01-22 13:46:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-22 13:46:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-22 13:46:18 --> Model "Nav_model" initialized
INFO - 2026-01-22 13:46:18 --> Controller Class Initialized
INFO - 2026-01-22 13:46:18 --> Model "Berita_model" initialized
INFO - 2026-01-22 13:46:18 --> Model "Galeri_model" initialized
INFO - 2026-01-22 13:46:18 --> Model "Video_model" initialized
INFO - 2026-01-22 13:46:19 --> Model "Agenda_model" initialized
INFO - 2026-01-22 13:46:19 --> Model "Tautan_model" initialized
INFO - 2026-01-22 13:46:19 --> Model "Mitra_model" initialized
INFO - 2026-01-22 13:46:19 --> Model "Jurusan_model" initialized
INFO - 2026-01-22 13:46:19 --> Model "Prodi_model" initialized
INFO - 2026-01-22 13:46:19 --> Model "Testimoni_model" initialized
INFO - 2026-01-22 13:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-22 13:46:19 --> Pagination Class Initialized
INFO - 2026-01-22 13:46:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-22 13:46:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-22 13:46:22 --> Model "Log_model" initialized
INFO - 2026-01-22 13:46:22 --> Final output sent to browser
DEBUG - 2026-01-22 13:46:22 --> Total execution time: 6.2702
