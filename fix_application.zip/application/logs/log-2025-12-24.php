<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-12-24 02:43:01 --> Config Class Initialized
INFO - 2025-12-24 02:43:01 --> Hooks Class Initialized
DEBUG - 2025-12-24 02:43:01 --> UTF-8 Support Enabled
INFO - 2025-12-24 02:43:01 --> Utf8 Class Initialized
INFO - 2025-12-24 02:43:01 --> URI Class Initialized
DEBUG - 2025-12-24 02:43:02 --> No URI present. Default controller set.
INFO - 2025-12-24 02:43:02 --> Router Class Initialized
INFO - 2025-12-24 02:43:02 --> Output Class Initialized
INFO - 2025-12-24 02:43:02 --> Security Class Initialized
DEBUG - 2025-12-24 02:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 02:43:02 --> CSRF cookie sent
INFO - 2025-12-24 02:43:02 --> Input Class Initialized
INFO - 2025-12-24 02:43:02 --> Language Class Initialized
INFO - 2025-12-24 02:43:02 --> Loader Class Initialized
INFO - 2025-12-24 02:43:02 --> Helper loaded: url_helper
INFO - 2025-12-24 02:43:02 --> Helper loaded: text_helper
INFO - 2025-12-24 02:43:02 --> Helper loaded: string_helper
INFO - 2025-12-24 02:43:02 --> Helper loaded: form_helper
INFO - 2025-12-24 02:43:02 --> Helper loaded: download_helper
INFO - 2025-12-24 02:43:02 --> Helper loaded: security_helper
INFO - 2025-12-24 02:43:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-24 02:43:03 --> Database Driver Class Initialized
DEBUG - 2025-12-24 02:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-24 02:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 02:43:03 --> Form Validation Class Initialized
INFO - 2025-12-24 02:43:03 --> Model "User_model" initialized
INFO - 2025-12-24 08:43:03 --> Model "Kunjungan_model" initialized
INFO - 2025-12-24 08:43:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-24 08:43:03 --> Model "Nav_model" initialized
INFO - 2025-12-24 08:43:03 --> Controller Class Initialized
INFO - 2025-12-24 08:43:04 --> Model "Berita_model" initialized
INFO - 2025-12-24 08:43:04 --> Model "Galeri_model" initialized
INFO - 2025-12-24 08:43:04 --> Model "Video_model" initialized
INFO - 2025-12-24 08:43:04 --> Model "Agenda_model" initialized
INFO - 2025-12-24 08:43:04 --> Model "Tautan_model" initialized
INFO - 2025-12-24 08:43:04 --> Model "Mitra_model" initialized
INFO - 2025-12-24 08:43:04 --> Model "Jurusan_model" initialized
INFO - 2025-12-24 08:43:04 --> Model "Prodi_model" initialized
INFO - 2025-12-24 08:43:04 --> Model "Testimoni_model" initialized
INFO - 2025-12-24 08:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-24 08:43:04 --> Pagination Class Initialized
INFO - 2025-12-24 08:43:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-24 08:43:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-24 08:43:07 --> Model "Log_model" initialized
INFO - 2025-12-24 08:43:07 --> Final output sent to browser
DEBUG - 2025-12-24 08:43:07 --> Total execution time: 5.6501
