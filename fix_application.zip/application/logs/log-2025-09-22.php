<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-09-22 03:46:15 --> Config Class Initialized
INFO - 2025-09-22 03:46:15 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:46:16 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:46:16 --> Utf8 Class Initialized
INFO - 2025-09-22 03:46:16 --> URI Class Initialized
DEBUG - 2025-09-22 03:46:16 --> No URI present. Default controller set.
INFO - 2025-09-22 03:46:16 --> Router Class Initialized
INFO - 2025-09-22 03:46:16 --> Output Class Initialized
INFO - 2025-09-22 03:46:16 --> Security Class Initialized
DEBUG - 2025-09-22 03:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:46:16 --> CSRF cookie sent
INFO - 2025-09-22 03:46:16 --> Input Class Initialized
INFO - 2025-09-22 03:46:16 --> Language Class Initialized
INFO - 2025-09-22 03:46:17 --> Loader Class Initialized
INFO - 2025-09-22 03:46:17 --> Helper loaded: url_helper
INFO - 2025-09-22 03:46:17 --> Helper loaded: text_helper
INFO - 2025-09-22 03:46:17 --> Helper loaded: string_helper
INFO - 2025-09-22 03:46:17 --> Helper loaded: form_helper
INFO - 2025-09-22 03:46:17 --> Helper loaded: download_helper
INFO - 2025-09-22 03:46:17 --> Helper loaded: security_helper
INFO - 2025-09-22 03:46:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:46:18 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:46:18 --> Form Validation Class Initialized
INFO - 2025-09-22 03:46:18 --> Model "User_model" initialized
INFO - 2025-09-22 08:46:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:46:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:46:19 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:46:19 --> Controller Class Initialized
INFO - 2025-09-22 08:46:19 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:46:19 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:46:19 --> Model "Video_model" initialized
INFO - 2025-09-22 08:46:19 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:46:19 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:46:19 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:46:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:46:19 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:46:19 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:46:20 --> Pagination Class Initialized
INFO - 2025-09-22 08:46:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:46:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:46:23 --> Model "Log_model" initialized
INFO - 2025-09-22 08:46:23 --> Final output sent to browser
DEBUG - 2025-09-22 08:46:23 --> Total execution time: 7.9484
INFO - 2025-09-22 03:47:05 --> Config Class Initialized
INFO - 2025-09-22 03:47:05 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:47:05 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:47:05 --> Utf8 Class Initialized
INFO - 2025-09-22 03:47:05 --> URI Class Initialized
DEBUG - 2025-09-22 03:47:05 --> No URI present. Default controller set.
INFO - 2025-09-22 03:47:05 --> Router Class Initialized
INFO - 2025-09-22 03:47:05 --> Output Class Initialized
INFO - 2025-09-22 03:47:05 --> Security Class Initialized
DEBUG - 2025-09-22 03:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:47:05 --> CSRF cookie sent
INFO - 2025-09-22 03:47:05 --> Input Class Initialized
INFO - 2025-09-22 03:47:05 --> Language Class Initialized
INFO - 2025-09-22 03:47:05 --> Loader Class Initialized
INFO - 2025-09-22 03:47:05 --> Helper loaded: url_helper
INFO - 2025-09-22 03:47:05 --> Helper loaded: text_helper
INFO - 2025-09-22 03:47:05 --> Helper loaded: string_helper
INFO - 2025-09-22 03:47:05 --> Helper loaded: form_helper
INFO - 2025-09-22 03:47:05 --> Helper loaded: download_helper
INFO - 2025-09-22 03:47:05 --> Helper loaded: security_helper
INFO - 2025-09-22 03:47:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:47:05 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:47:05 --> Form Validation Class Initialized
INFO - 2025-09-22 03:47:05 --> Model "User_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:47:05 --> Controller Class Initialized
INFO - 2025-09-22 08:47:05 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Video_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:47:05 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:47:05 --> Pagination Class Initialized
INFO - 2025-09-22 08:47:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:47:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:47:05 --> Model "Log_model" initialized
INFO - 2025-09-22 08:47:05 --> Final output sent to browser
DEBUG - 2025-09-22 08:47:05 --> Total execution time: 0.1039
INFO - 2025-09-22 03:47:08 --> Config Class Initialized
INFO - 2025-09-22 03:47:08 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:47:08 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:47:08 --> Utf8 Class Initialized
INFO - 2025-09-22 03:47:08 --> URI Class Initialized
DEBUG - 2025-09-22 03:47:08 --> No URI present. Default controller set.
INFO - 2025-09-22 03:47:08 --> Router Class Initialized
INFO - 2025-09-22 03:47:08 --> Output Class Initialized
INFO - 2025-09-22 03:47:08 --> Security Class Initialized
DEBUG - 2025-09-22 03:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:47:08 --> CSRF cookie sent
INFO - 2025-09-22 03:47:08 --> Input Class Initialized
INFO - 2025-09-22 03:47:08 --> Language Class Initialized
INFO - 2025-09-22 03:47:08 --> Loader Class Initialized
INFO - 2025-09-22 03:47:08 --> Helper loaded: url_helper
INFO - 2025-09-22 03:47:08 --> Helper loaded: text_helper
INFO - 2025-09-22 03:47:08 --> Helper loaded: string_helper
INFO - 2025-09-22 03:47:08 --> Helper loaded: form_helper
INFO - 2025-09-22 03:47:08 --> Helper loaded: download_helper
INFO - 2025-09-22 03:47:08 --> Helper loaded: security_helper
INFO - 2025-09-22 03:47:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:47:08 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:47:08 --> Form Validation Class Initialized
INFO - 2025-09-22 03:47:08 --> Model "User_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:47:08 --> Controller Class Initialized
INFO - 2025-09-22 08:47:08 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Video_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:47:08 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:47:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:47:08 --> Pagination Class Initialized
INFO - 2025-09-22 08:47:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:47:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:47:08 --> Model "Log_model" initialized
INFO - 2025-09-22 08:47:08 --> Final output sent to browser
DEBUG - 2025-09-22 08:47:08 --> Total execution time: 0.0958
INFO - 2025-09-22 03:47:10 --> Config Class Initialized
INFO - 2025-09-22 03:47:10 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:47:10 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:47:10 --> Utf8 Class Initialized
INFO - 2025-09-22 03:47:10 --> URI Class Initialized
DEBUG - 2025-09-22 03:47:10 --> No URI present. Default controller set.
INFO - 2025-09-22 03:47:10 --> Router Class Initialized
INFO - 2025-09-22 03:47:10 --> Output Class Initialized
INFO - 2025-09-22 03:47:10 --> Security Class Initialized
DEBUG - 2025-09-22 03:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:47:10 --> CSRF cookie sent
INFO - 2025-09-22 03:47:10 --> Input Class Initialized
INFO - 2025-09-22 03:47:10 --> Language Class Initialized
INFO - 2025-09-22 03:47:10 --> Loader Class Initialized
INFO - 2025-09-22 03:47:10 --> Helper loaded: url_helper
INFO - 2025-09-22 03:47:10 --> Helper loaded: text_helper
INFO - 2025-09-22 03:47:10 --> Helper loaded: string_helper
INFO - 2025-09-22 03:47:10 --> Helper loaded: form_helper
INFO - 2025-09-22 03:47:10 --> Helper loaded: download_helper
INFO - 2025-09-22 03:47:10 --> Helper loaded: security_helper
INFO - 2025-09-22 03:47:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:47:10 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:47:10 --> Form Validation Class Initialized
INFO - 2025-09-22 03:47:10 --> Model "User_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:47:10 --> Controller Class Initialized
INFO - 2025-09-22 08:47:10 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Video_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:47:10 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:47:10 --> Pagination Class Initialized
INFO - 2025-09-22 08:47:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:47:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:47:10 --> Model "Log_model" initialized
INFO - 2025-09-22 08:47:10 --> Final output sent to browser
DEBUG - 2025-09-22 08:47:10 --> Total execution time: 0.0907
INFO - 2025-09-22 03:47:12 --> Config Class Initialized
INFO - 2025-09-22 03:47:12 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:47:12 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:47:12 --> Utf8 Class Initialized
INFO - 2025-09-22 03:47:12 --> URI Class Initialized
DEBUG - 2025-09-22 03:47:12 --> No URI present. Default controller set.
INFO - 2025-09-22 03:47:12 --> Router Class Initialized
INFO - 2025-09-22 03:47:12 --> Output Class Initialized
INFO - 2025-09-22 03:47:12 --> Security Class Initialized
DEBUG - 2025-09-22 03:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:47:12 --> CSRF cookie sent
INFO - 2025-09-22 03:47:12 --> Input Class Initialized
INFO - 2025-09-22 03:47:12 --> Language Class Initialized
INFO - 2025-09-22 03:47:12 --> Loader Class Initialized
INFO - 2025-09-22 03:47:12 --> Helper loaded: url_helper
INFO - 2025-09-22 03:47:12 --> Helper loaded: text_helper
INFO - 2025-09-22 03:47:12 --> Helper loaded: string_helper
INFO - 2025-09-22 03:47:12 --> Helper loaded: form_helper
INFO - 2025-09-22 03:47:12 --> Helper loaded: download_helper
INFO - 2025-09-22 03:47:12 --> Helper loaded: security_helper
INFO - 2025-09-22 03:47:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:47:12 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:47:12 --> Form Validation Class Initialized
INFO - 2025-09-22 03:47:12 --> Model "User_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:47:12 --> Controller Class Initialized
INFO - 2025-09-22 08:47:12 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Video_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:47:12 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:47:12 --> Pagination Class Initialized
INFO - 2025-09-22 08:47:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:47:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:47:12 --> Model "Log_model" initialized
INFO - 2025-09-22 08:47:12 --> Final output sent to browser
DEBUG - 2025-09-22 08:47:12 --> Total execution time: 0.0870
INFO - 2025-09-22 03:47:18 --> Config Class Initialized
INFO - 2025-09-22 03:47:18 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:47:18 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:47:18 --> Utf8 Class Initialized
INFO - 2025-09-22 03:47:18 --> URI Class Initialized
DEBUG - 2025-09-22 03:47:18 --> No URI present. Default controller set.
INFO - 2025-09-22 03:47:18 --> Router Class Initialized
INFO - 2025-09-22 03:47:18 --> Output Class Initialized
INFO - 2025-09-22 03:47:18 --> Security Class Initialized
DEBUG - 2025-09-22 03:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:47:18 --> CSRF cookie sent
INFO - 2025-09-22 03:47:18 --> Input Class Initialized
INFO - 2025-09-22 03:47:18 --> Language Class Initialized
INFO - 2025-09-22 03:47:18 --> Loader Class Initialized
INFO - 2025-09-22 03:47:18 --> Helper loaded: url_helper
INFO - 2025-09-22 03:47:18 --> Helper loaded: text_helper
INFO - 2025-09-22 03:47:18 --> Helper loaded: string_helper
INFO - 2025-09-22 03:47:18 --> Helper loaded: form_helper
INFO - 2025-09-22 03:47:18 --> Helper loaded: download_helper
INFO - 2025-09-22 03:47:18 --> Helper loaded: security_helper
INFO - 2025-09-22 03:47:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:47:18 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:47:18 --> Form Validation Class Initialized
INFO - 2025-09-22 03:47:18 --> Model "User_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:47:18 --> Controller Class Initialized
INFO - 2025-09-22 08:47:18 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Video_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:47:18 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:47:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:47:18 --> Pagination Class Initialized
INFO - 2025-09-22 08:47:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:47:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:47:18 --> Model "Log_model" initialized
INFO - 2025-09-22 08:47:18 --> Final output sent to browser
DEBUG - 2025-09-22 08:47:18 --> Total execution time: 0.0815
INFO - 2025-09-22 03:47:31 --> Config Class Initialized
INFO - 2025-09-22 03:47:31 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:47:31 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:47:31 --> Utf8 Class Initialized
INFO - 2025-09-22 03:47:31 --> URI Class Initialized
DEBUG - 2025-09-22 03:47:31 --> No URI present. Default controller set.
INFO - 2025-09-22 03:47:31 --> Router Class Initialized
INFO - 2025-09-22 03:47:31 --> Output Class Initialized
INFO - 2025-09-22 03:47:31 --> Security Class Initialized
DEBUG - 2025-09-22 03:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:47:31 --> CSRF cookie sent
INFO - 2025-09-22 03:47:31 --> Input Class Initialized
INFO - 2025-09-22 03:47:31 --> Language Class Initialized
INFO - 2025-09-22 03:47:31 --> Loader Class Initialized
INFO - 2025-09-22 03:47:31 --> Helper loaded: url_helper
INFO - 2025-09-22 03:47:31 --> Helper loaded: text_helper
INFO - 2025-09-22 03:47:31 --> Helper loaded: string_helper
INFO - 2025-09-22 03:47:31 --> Helper loaded: form_helper
INFO - 2025-09-22 03:47:31 --> Helper loaded: download_helper
INFO - 2025-09-22 03:47:31 --> Helper loaded: security_helper
INFO - 2025-09-22 03:47:31 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:47:31 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:47:31 --> Form Validation Class Initialized
INFO - 2025-09-22 03:47:31 --> Model "User_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:47:31 --> Controller Class Initialized
INFO - 2025-09-22 08:47:31 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Video_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:47:31 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:47:31 --> Pagination Class Initialized
INFO - 2025-09-22 08:47:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:47:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:47:31 --> Model "Log_model" initialized
INFO - 2025-09-22 08:47:31 --> Final output sent to browser
DEBUG - 2025-09-22 08:47:31 --> Total execution time: 0.0853
INFO - 2025-09-22 03:47:32 --> Config Class Initialized
INFO - 2025-09-22 03:47:32 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:47:32 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:47:32 --> Utf8 Class Initialized
INFO - 2025-09-22 03:47:32 --> URI Class Initialized
DEBUG - 2025-09-22 03:47:32 --> No URI present. Default controller set.
INFO - 2025-09-22 03:47:32 --> Router Class Initialized
INFO - 2025-09-22 03:47:32 --> Output Class Initialized
INFO - 2025-09-22 03:47:32 --> Security Class Initialized
DEBUG - 2025-09-22 03:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:47:32 --> CSRF cookie sent
INFO - 2025-09-22 03:47:32 --> Input Class Initialized
INFO - 2025-09-22 03:47:32 --> Language Class Initialized
INFO - 2025-09-22 03:47:32 --> Loader Class Initialized
INFO - 2025-09-22 03:47:32 --> Helper loaded: url_helper
INFO - 2025-09-22 03:47:32 --> Helper loaded: text_helper
INFO - 2025-09-22 03:47:32 --> Helper loaded: string_helper
INFO - 2025-09-22 03:47:32 --> Helper loaded: form_helper
INFO - 2025-09-22 03:47:32 --> Helper loaded: download_helper
INFO - 2025-09-22 03:47:32 --> Helper loaded: security_helper
INFO - 2025-09-22 03:47:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:47:32 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:47:32 --> Form Validation Class Initialized
INFO - 2025-09-22 03:47:32 --> Model "User_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:47:32 --> Controller Class Initialized
INFO - 2025-09-22 08:47:32 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Video_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:47:32 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:47:33 --> Pagination Class Initialized
INFO - 2025-09-22 08:47:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:47:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:47:33 --> Model "Log_model" initialized
INFO - 2025-09-22 08:47:33 --> Final output sent to browser
DEBUG - 2025-09-22 08:47:33 --> Total execution time: 0.1141
INFO - 2025-09-22 03:48:09 --> Config Class Initialized
INFO - 2025-09-22 03:48:09 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:48:09 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:48:09 --> Utf8 Class Initialized
INFO - 2025-09-22 03:48:09 --> URI Class Initialized
DEBUG - 2025-09-22 03:48:09 --> No URI present. Default controller set.
INFO - 2025-09-22 03:48:09 --> Router Class Initialized
INFO - 2025-09-22 03:48:09 --> Output Class Initialized
INFO - 2025-09-22 03:48:09 --> Security Class Initialized
DEBUG - 2025-09-22 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:48:09 --> CSRF cookie sent
INFO - 2025-09-22 03:48:09 --> Input Class Initialized
INFO - 2025-09-22 03:48:09 --> Language Class Initialized
INFO - 2025-09-22 03:48:09 --> Loader Class Initialized
INFO - 2025-09-22 03:48:09 --> Helper loaded: url_helper
INFO - 2025-09-22 03:48:09 --> Helper loaded: text_helper
INFO - 2025-09-22 03:48:09 --> Helper loaded: string_helper
INFO - 2025-09-22 03:48:09 --> Helper loaded: form_helper
INFO - 2025-09-22 03:48:09 --> Helper loaded: download_helper
INFO - 2025-09-22 03:48:09 --> Helper loaded: security_helper
INFO - 2025-09-22 03:48:09 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:48:09 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:48:09 --> Form Validation Class Initialized
INFO - 2025-09-22 03:48:09 --> Model "User_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:48:09 --> Controller Class Initialized
INFO - 2025-09-22 08:48:09 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Video_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:48:09 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:48:09 --> Pagination Class Initialized
INFO - 2025-09-22 08:48:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:48:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:48:09 --> Model "Log_model" initialized
INFO - 2025-09-22 08:48:09 --> Final output sent to browser
DEBUG - 2025-09-22 08:48:09 --> Total execution time: 0.1160
INFO - 2025-09-22 03:48:17 --> Config Class Initialized
INFO - 2025-09-22 03:48:17 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:48:17 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:48:17 --> Utf8 Class Initialized
INFO - 2025-09-22 03:48:17 --> URI Class Initialized
DEBUG - 2025-09-22 03:48:17 --> No URI present. Default controller set.
INFO - 2025-09-22 03:48:17 --> Router Class Initialized
INFO - 2025-09-22 03:48:17 --> Output Class Initialized
INFO - 2025-09-22 03:48:17 --> Security Class Initialized
DEBUG - 2025-09-22 03:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:48:17 --> CSRF cookie sent
INFO - 2025-09-22 03:48:17 --> Input Class Initialized
INFO - 2025-09-22 03:48:17 --> Language Class Initialized
INFO - 2025-09-22 03:48:17 --> Loader Class Initialized
INFO - 2025-09-22 03:48:17 --> Helper loaded: url_helper
INFO - 2025-09-22 03:48:17 --> Helper loaded: text_helper
INFO - 2025-09-22 03:48:17 --> Helper loaded: string_helper
INFO - 2025-09-22 03:48:17 --> Helper loaded: form_helper
INFO - 2025-09-22 03:48:17 --> Helper loaded: download_helper
INFO - 2025-09-22 03:48:17 --> Helper loaded: security_helper
INFO - 2025-09-22 03:48:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:48:17 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:48:17 --> Form Validation Class Initialized
INFO - 2025-09-22 03:48:17 --> Model "User_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:48:17 --> Controller Class Initialized
INFO - 2025-09-22 08:48:17 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Video_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:48:17 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:48:17 --> Pagination Class Initialized
INFO - 2025-09-22 08:48:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:48:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:48:17 --> Model "Log_model" initialized
INFO - 2025-09-22 08:48:17 --> Final output sent to browser
DEBUG - 2025-09-22 08:48:17 --> Total execution time: 0.1394
INFO - 2025-09-22 03:49:33 --> Config Class Initialized
INFO - 2025-09-22 03:49:33 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:49:33 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:49:33 --> Utf8 Class Initialized
INFO - 2025-09-22 03:49:33 --> URI Class Initialized
DEBUG - 2025-09-22 03:49:33 --> No URI present. Default controller set.
INFO - 2025-09-22 03:49:33 --> Router Class Initialized
INFO - 2025-09-22 03:49:33 --> Output Class Initialized
INFO - 2025-09-22 03:49:33 --> Security Class Initialized
DEBUG - 2025-09-22 03:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:49:33 --> CSRF cookie sent
INFO - 2025-09-22 03:49:33 --> Input Class Initialized
INFO - 2025-09-22 03:49:33 --> Language Class Initialized
INFO - 2025-09-22 03:49:33 --> Loader Class Initialized
INFO - 2025-09-22 03:49:33 --> Helper loaded: url_helper
INFO - 2025-09-22 03:49:33 --> Helper loaded: text_helper
INFO - 2025-09-22 03:49:33 --> Helper loaded: string_helper
INFO - 2025-09-22 03:49:33 --> Helper loaded: form_helper
INFO - 2025-09-22 03:49:33 --> Helper loaded: download_helper
INFO - 2025-09-22 03:49:33 --> Helper loaded: security_helper
INFO - 2025-09-22 03:49:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:49:33 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:49:33 --> Form Validation Class Initialized
INFO - 2025-09-22 03:49:33 --> Model "User_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:49:33 --> Controller Class Initialized
INFO - 2025-09-22 08:49:33 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Video_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:49:33 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:49:33 --> Pagination Class Initialized
INFO - 2025-09-22 08:49:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:49:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:49:33 --> Model "Log_model" initialized
INFO - 2025-09-22 08:49:33 --> Final output sent to browser
DEBUG - 2025-09-22 08:49:33 --> Total execution time: 0.0984
INFO - 2025-09-22 03:49:47 --> Config Class Initialized
INFO - 2025-09-22 03:49:47 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:49:47 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:49:47 --> Utf8 Class Initialized
INFO - 2025-09-22 03:49:47 --> URI Class Initialized
DEBUG - 2025-09-22 03:49:47 --> No URI present. Default controller set.
INFO - 2025-09-22 03:49:47 --> Router Class Initialized
INFO - 2025-09-22 03:49:47 --> Output Class Initialized
INFO - 2025-09-22 03:49:47 --> Security Class Initialized
DEBUG - 2025-09-22 03:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:49:47 --> CSRF cookie sent
INFO - 2025-09-22 03:49:47 --> Input Class Initialized
INFO - 2025-09-22 03:49:47 --> Language Class Initialized
INFO - 2025-09-22 03:49:47 --> Loader Class Initialized
INFO - 2025-09-22 03:49:47 --> Helper loaded: url_helper
INFO - 2025-09-22 03:49:47 --> Helper loaded: text_helper
INFO - 2025-09-22 03:49:47 --> Helper loaded: string_helper
INFO - 2025-09-22 03:49:47 --> Helper loaded: form_helper
INFO - 2025-09-22 03:49:47 --> Helper loaded: download_helper
INFO - 2025-09-22 03:49:47 --> Helper loaded: security_helper
INFO - 2025-09-22 03:49:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:49:47 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:49:47 --> Form Validation Class Initialized
INFO - 2025-09-22 03:49:47 --> Model "User_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:49:47 --> Controller Class Initialized
INFO - 2025-09-22 08:49:47 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Video_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:49:47 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:49:47 --> Pagination Class Initialized
INFO - 2025-09-22 08:49:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:49:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:49:47 --> Model "Log_model" initialized
INFO - 2025-09-22 08:49:47 --> Final output sent to browser
DEBUG - 2025-09-22 08:49:47 --> Total execution time: 0.1237
INFO - 2025-09-22 03:53:53 --> Config Class Initialized
INFO - 2025-09-22 03:53:53 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:53:53 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:53:53 --> Utf8 Class Initialized
INFO - 2025-09-22 03:53:53 --> URI Class Initialized
DEBUG - 2025-09-22 03:53:53 --> No URI present. Default controller set.
INFO - 2025-09-22 03:53:53 --> Router Class Initialized
INFO - 2025-09-22 03:53:53 --> Output Class Initialized
INFO - 2025-09-22 03:53:53 --> Security Class Initialized
DEBUG - 2025-09-22 03:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:53:53 --> CSRF cookie sent
INFO - 2025-09-22 03:53:53 --> Input Class Initialized
INFO - 2025-09-22 03:53:53 --> Language Class Initialized
INFO - 2025-09-22 03:53:53 --> Loader Class Initialized
INFO - 2025-09-22 03:53:53 --> Helper loaded: url_helper
INFO - 2025-09-22 03:53:53 --> Helper loaded: text_helper
INFO - 2025-09-22 03:53:53 --> Helper loaded: string_helper
INFO - 2025-09-22 03:53:53 --> Helper loaded: form_helper
INFO - 2025-09-22 03:53:53 --> Helper loaded: download_helper
INFO - 2025-09-22 03:53:53 --> Helper loaded: security_helper
INFO - 2025-09-22 03:53:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:53:53 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:53:53 --> Form Validation Class Initialized
INFO - 2025-09-22 03:53:53 --> Model "User_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:53:53 --> Controller Class Initialized
INFO - 2025-09-22 08:53:53 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Video_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:53:53 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:53:53 --> Pagination Class Initialized
INFO - 2025-09-22 08:53:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:53:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:53:53 --> Model "Log_model" initialized
INFO - 2025-09-22 08:53:53 --> Final output sent to browser
DEBUG - 2025-09-22 08:53:53 --> Total execution time: 0.1247
INFO - 2025-09-22 03:55:22 --> Config Class Initialized
INFO - 2025-09-22 03:55:22 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:55:22 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:55:22 --> Utf8 Class Initialized
INFO - 2025-09-22 03:55:22 --> URI Class Initialized
DEBUG - 2025-09-22 03:55:22 --> No URI present. Default controller set.
INFO - 2025-09-22 03:55:22 --> Router Class Initialized
INFO - 2025-09-22 03:55:22 --> Output Class Initialized
INFO - 2025-09-22 03:55:22 --> Security Class Initialized
DEBUG - 2025-09-22 03:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:55:22 --> CSRF cookie sent
INFO - 2025-09-22 03:55:22 --> Input Class Initialized
INFO - 2025-09-22 03:55:22 --> Language Class Initialized
INFO - 2025-09-22 03:55:22 --> Loader Class Initialized
INFO - 2025-09-22 03:55:22 --> Helper loaded: url_helper
INFO - 2025-09-22 03:55:22 --> Helper loaded: text_helper
INFO - 2025-09-22 03:55:22 --> Helper loaded: string_helper
INFO - 2025-09-22 03:55:22 --> Helper loaded: form_helper
INFO - 2025-09-22 03:55:22 --> Helper loaded: download_helper
INFO - 2025-09-22 03:55:22 --> Helper loaded: security_helper
INFO - 2025-09-22 03:55:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:55:22 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:55:22 --> Form Validation Class Initialized
INFO - 2025-09-22 03:55:22 --> Model "User_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:55:22 --> Controller Class Initialized
INFO - 2025-09-22 08:55:22 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Video_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:55:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:55:22 --> Pagination Class Initialized
INFO - 2025-09-22 08:55:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:55:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:55:22 --> Model "Log_model" initialized
INFO - 2025-09-22 08:55:22 --> Final output sent to browser
DEBUG - 2025-09-22 08:55:22 --> Total execution time: 0.1175
INFO - 2025-09-22 03:55:25 --> Config Class Initialized
INFO - 2025-09-22 03:55:25 --> Hooks Class Initialized
DEBUG - 2025-09-22 03:55:25 --> UTF-8 Support Enabled
INFO - 2025-09-22 03:55:25 --> Utf8 Class Initialized
INFO - 2025-09-22 03:55:25 --> URI Class Initialized
DEBUG - 2025-09-22 03:55:25 --> No URI present. Default controller set.
INFO - 2025-09-22 03:55:25 --> Router Class Initialized
INFO - 2025-09-22 03:55:25 --> Output Class Initialized
INFO - 2025-09-22 03:55:25 --> Security Class Initialized
DEBUG - 2025-09-22 03:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-22 03:55:25 --> CSRF cookie sent
INFO - 2025-09-22 03:55:25 --> Input Class Initialized
INFO - 2025-09-22 03:55:25 --> Language Class Initialized
INFO - 2025-09-22 03:55:25 --> Loader Class Initialized
INFO - 2025-09-22 03:55:25 --> Helper loaded: url_helper
INFO - 2025-09-22 03:55:25 --> Helper loaded: text_helper
INFO - 2025-09-22 03:55:25 --> Helper loaded: string_helper
INFO - 2025-09-22 03:55:25 --> Helper loaded: form_helper
INFO - 2025-09-22 03:55:25 --> Helper loaded: download_helper
INFO - 2025-09-22 03:55:25 --> Helper loaded: security_helper
INFO - 2025-09-22 03:55:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-22 03:55:25 --> Database Driver Class Initialized
DEBUG - 2025-09-22 03:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-22 03:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-22 03:55:25 --> Form Validation Class Initialized
INFO - 2025-09-22 03:55:25 --> Model "User_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Nav_model" initialized
INFO - 2025-09-22 08:55:25 --> Controller Class Initialized
INFO - 2025-09-22 08:55:25 --> Model "Berita_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Galeri_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Video_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Agenda_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Tautan_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Mitra_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Jurusan_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Prodi_model" initialized
INFO - 2025-09-22 08:55:25 --> Model "Testimoni_model" initialized
INFO - 2025-09-22 08:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-22 08:55:25 --> Pagination Class Initialized
INFO - 2025-09-22 08:55:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-22 08:55:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-22 08:55:25 --> Model "Log_model" initialized
INFO - 2025-09-22 08:55:25 --> Final output sent to browser
DEBUG - 2025-09-22 08:55:25 --> Total execution time: 0.1314
