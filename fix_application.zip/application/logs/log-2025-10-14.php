<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-14 08:27:39 --> Config Class Initialized
INFO - 2025-10-14 08:27:39 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:27:40 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:27:40 --> Utf8 Class Initialized
INFO - 2025-10-14 08:27:40 --> URI Class Initialized
DEBUG - 2025-10-14 08:27:40 --> No URI present. Default controller set.
INFO - 2025-10-14 08:27:40 --> Router Class Initialized
INFO - 2025-10-14 08:27:40 --> Output Class Initialized
INFO - 2025-10-14 08:27:40 --> Security Class Initialized
DEBUG - 2025-10-14 08:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:27:40 --> CSRF cookie sent
INFO - 2025-10-14 08:27:40 --> Input Class Initialized
INFO - 2025-10-14 08:27:40 --> Language Class Initialized
INFO - 2025-10-14 08:27:40 --> Loader Class Initialized
INFO - 2025-10-14 08:27:40 --> Helper loaded: url_helper
INFO - 2025-10-14 08:27:40 --> Helper loaded: text_helper
INFO - 2025-10-14 08:27:40 --> Helper loaded: string_helper
INFO - 2025-10-14 08:27:40 --> Helper loaded: form_helper
INFO - 2025-10-14 08:27:40 --> Helper loaded: download_helper
INFO - 2025-10-14 08:27:40 --> Helper loaded: security_helper
INFO - 2025-10-14 08:27:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:27:40 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:27:41 --> Form Validation Class Initialized
INFO - 2025-10-14 08:27:41 --> Model "User_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:27:41 --> Controller Class Initialized
INFO - 2025-10-14 13:27:41 --> Model "Berita_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Galeri_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Video_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Agenda_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Tautan_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Mitra_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Jurusan_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Prodi_model" initialized
INFO - 2025-10-14 13:27:41 --> Model "Testimoni_model" initialized
INFO - 2025-10-14 13:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-14 13:27:41 --> Pagination Class Initialized
INFO - 2025-10-14 13:27:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-14 13:27:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:27:43 --> Model "Log_model" initialized
INFO - 2025-10-14 13:27:43 --> Final output sent to browser
DEBUG - 2025-10-14 13:27:43 --> Total execution time: 3.7059
INFO - 2025-10-14 08:28:26 --> Config Class Initialized
INFO - 2025-10-14 08:28:26 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:28:26 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:28:26 --> Utf8 Class Initialized
INFO - 2025-10-14 08:28:26 --> URI Class Initialized
INFO - 2025-10-14 08:28:26 --> Router Class Initialized
INFO - 2025-10-14 08:28:26 --> Output Class Initialized
INFO - 2025-10-14 08:28:26 --> Security Class Initialized
DEBUG - 2025-10-14 08:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:28:26 --> CSRF cookie sent
INFO - 2025-10-14 08:28:26 --> Input Class Initialized
INFO - 2025-10-14 08:28:26 --> Language Class Initialized
INFO - 2025-10-14 08:28:26 --> Loader Class Initialized
INFO - 2025-10-14 08:28:26 --> Helper loaded: url_helper
INFO - 2025-10-14 08:28:26 --> Helper loaded: text_helper
INFO - 2025-10-14 08:28:26 --> Helper loaded: string_helper
INFO - 2025-10-14 08:28:26 --> Helper loaded: form_helper
INFO - 2025-10-14 08:28:26 --> Helper loaded: download_helper
INFO - 2025-10-14 08:28:26 --> Helper loaded: security_helper
INFO - 2025-10-14 08:28:26 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:28:26 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:28:26 --> Form Validation Class Initialized
INFO - 2025-10-14 08:28:26 --> Model "User_model" initialized
INFO - 2025-10-14 13:28:26 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:28:26 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:28:26 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:28:26 --> Controller Class Initialized
INFO - 2025-10-14 13:28:26 --> Model "Download_model" initialized
INFO - 2025-10-14 13:28:26 --> Model "Kategori_download_model" initialized
INFO - 2025-10-14 13:28:26 --> Model "Jenis_download_model" initialized
INFO - 2025-10-14 13:28:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2025-10-14 13:28:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:28:26 --> Model "Log_model" initialized
INFO - 2025-10-14 13:28:26 --> Final output sent to browser
DEBUG - 2025-10-14 13:28:26 --> Total execution time: 0.3342
INFO - 2025-10-14 08:28:34 --> Config Class Initialized
INFO - 2025-10-14 08:28:34 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:28:34 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:28:34 --> Utf8 Class Initialized
INFO - 2025-10-14 08:28:34 --> URI Class Initialized
INFO - 2025-10-14 08:28:34 --> Router Class Initialized
INFO - 2025-10-14 08:28:34 --> Output Class Initialized
INFO - 2025-10-14 08:28:34 --> Security Class Initialized
DEBUG - 2025-10-14 08:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:28:34 --> CSRF cookie sent
INFO - 2025-10-14 08:28:34 --> Input Class Initialized
INFO - 2025-10-14 08:28:34 --> Language Class Initialized
INFO - 2025-10-14 08:28:34 --> Loader Class Initialized
INFO - 2025-10-14 08:28:34 --> Helper loaded: url_helper
INFO - 2025-10-14 08:28:34 --> Helper loaded: text_helper
INFO - 2025-10-14 08:28:34 --> Helper loaded: string_helper
INFO - 2025-10-14 08:28:34 --> Helper loaded: form_helper
INFO - 2025-10-14 08:28:34 --> Helper loaded: download_helper
INFO - 2025-10-14 08:28:34 --> Helper loaded: security_helper
INFO - 2025-10-14 08:28:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:28:34 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:28:34 --> Form Validation Class Initialized
INFO - 2025-10-14 08:28:34 --> Model "User_model" initialized
INFO - 2025-10-14 13:28:34 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:28:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:28:34 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:28:34 --> Controller Class Initialized
INFO - 2025-10-14 13:28:34 --> Model "Pages_model" initialized
INFO - 2025-10-14 13:28:34 --> Model "Berita_model" initialized
INFO - 2025-10-14 13:28:34 --> Model "Download_model" initialized
INFO - 2025-10-14 13:28:34 --> Model "Kategori_download_model" initialized
INFO - 2025-10-14 13:28:34 --> Model "Jenis_download_model" initialized
INFO - 2025-10-14 13:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/alumni.php
INFO - 2025-10-14 13:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:28:34 --> Model "Log_model" initialized
INFO - 2025-10-14 13:28:34 --> Final output sent to browser
DEBUG - 2025-10-14 13:28:34 --> Total execution time: 0.2338
INFO - 2025-10-14 08:29:34 --> Config Class Initialized
INFO - 2025-10-14 08:29:34 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:29:34 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:29:34 --> Utf8 Class Initialized
INFO - 2025-10-14 08:29:34 --> URI Class Initialized
INFO - 2025-10-14 08:29:34 --> Router Class Initialized
INFO - 2025-10-14 08:29:34 --> Output Class Initialized
INFO - 2025-10-14 08:29:34 --> Security Class Initialized
DEBUG - 2025-10-14 08:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:29:34 --> CSRF cookie sent
INFO - 2025-10-14 08:29:34 --> Input Class Initialized
INFO - 2025-10-14 08:29:34 --> Language Class Initialized
INFO - 2025-10-14 08:29:34 --> Loader Class Initialized
INFO - 2025-10-14 08:29:34 --> Helper loaded: url_helper
INFO - 2025-10-14 08:29:34 --> Helper loaded: text_helper
INFO - 2025-10-14 08:29:34 --> Helper loaded: string_helper
INFO - 2025-10-14 08:29:34 --> Helper loaded: form_helper
INFO - 2025-10-14 08:29:34 --> Helper loaded: download_helper
INFO - 2025-10-14 08:29:34 --> Helper loaded: security_helper
INFO - 2025-10-14 08:29:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:29:34 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:29:34 --> Form Validation Class Initialized
INFO - 2025-10-14 08:29:34 --> Model "User_model" initialized
INFO - 2025-10-14 13:29:34 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:29:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:29:34 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:29:34 --> Controller Class Initialized
INFO - 2025-10-14 13:29:34 --> Model "Maturity_model" initialized
INFO - 2025-10-14 13:29:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\maturity/list.php
INFO - 2025-10-14 13:29:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:29:34 --> Model "Log_model" initialized
INFO - 2025-10-14 13:29:34 --> Final output sent to browser
DEBUG - 2025-10-14 13:29:34 --> Total execution time: 0.2552
INFO - 2025-10-14 08:29:38 --> Config Class Initialized
INFO - 2025-10-14 08:29:38 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:29:38 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:29:38 --> Utf8 Class Initialized
INFO - 2025-10-14 08:29:38 --> URI Class Initialized
INFO - 2025-10-14 08:29:38 --> Router Class Initialized
INFO - 2025-10-14 08:29:38 --> Output Class Initialized
INFO - 2025-10-14 08:29:38 --> Security Class Initialized
DEBUG - 2025-10-14 08:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:29:38 --> CSRF cookie sent
INFO - 2025-10-14 08:29:38 --> Input Class Initialized
INFO - 2025-10-14 08:29:38 --> Language Class Initialized
INFO - 2025-10-14 08:29:38 --> Loader Class Initialized
INFO - 2025-10-14 08:29:38 --> Helper loaded: url_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: text_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: string_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: form_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: download_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: security_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:29:38 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:29:38 --> Form Validation Class Initialized
INFO - 2025-10-14 08:29:38 --> Model "User_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:29:38 --> Controller Class Initialized
INFO - 2025-10-14 13:29:38 --> Model "Maturity_model" initialized
INFO - 2025-10-14 13:29:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\maturity/read.php
INFO - 2025-10-14 13:29:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:29:38 --> Model "Log_model" initialized
INFO - 2025-10-14 13:29:38 --> Final output sent to browser
DEBUG - 2025-10-14 13:29:38 --> Total execution time: 0.1351
INFO - 2025-10-14 08:29:38 --> Config Class Initialized
INFO - 2025-10-14 08:29:38 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:29:38 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:29:38 --> Utf8 Class Initialized
INFO - 2025-10-14 08:29:38 --> URI Class Initialized
INFO - 2025-10-14 08:29:38 --> Router Class Initialized
INFO - 2025-10-14 08:29:38 --> Output Class Initialized
INFO - 2025-10-14 08:29:38 --> Security Class Initialized
DEBUG - 2025-10-14 08:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:29:38 --> CSRF cookie sent
INFO - 2025-10-14 08:29:38 --> Input Class Initialized
INFO - 2025-10-14 08:29:38 --> Language Class Initialized
INFO - 2025-10-14 08:29:38 --> Loader Class Initialized
INFO - 2025-10-14 08:29:38 --> Helper loaded: url_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: text_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: string_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: form_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: download_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: security_helper
INFO - 2025-10-14 08:29:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:29:38 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:29:38 --> Form Validation Class Initialized
INFO - 2025-10-14 08:29:38 --> Model "User_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:29:38 --> Controller Class Initialized
INFO - 2025-10-14 13:29:38 --> Model "Berita_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Galeri_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Video_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Agenda_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Tautan_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Mitra_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Jurusan_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Prodi_model" initialized
INFO - 2025-10-14 13:29:38 --> Model "Testimoni_model" initialized
INFO - 2025-10-14 13:29:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-14 13:29:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:29:38 --> Model "Log_model" initialized
INFO - 2025-10-14 13:29:38 --> Final output sent to browser
DEBUG - 2025-10-14 13:29:38 --> Total execution time: 0.1047
INFO - 2025-10-14 08:29:40 --> Config Class Initialized
INFO - 2025-10-14 08:29:40 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:29:40 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:29:40 --> Utf8 Class Initialized
INFO - 2025-10-14 08:29:40 --> URI Class Initialized
INFO - 2025-10-14 08:29:40 --> Router Class Initialized
INFO - 2025-10-14 08:29:40 --> Output Class Initialized
INFO - 2025-10-14 08:29:40 --> Security Class Initialized
DEBUG - 2025-10-14 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:29:40 --> CSRF cookie sent
INFO - 2025-10-14 08:29:40 --> Input Class Initialized
INFO - 2025-10-14 08:29:40 --> Language Class Initialized
INFO - 2025-10-14 08:29:40 --> Loader Class Initialized
INFO - 2025-10-14 08:29:40 --> Helper loaded: url_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: text_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: string_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: form_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: download_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: security_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:29:40 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:29:40 --> Form Validation Class Initialized
INFO - 2025-10-14 08:29:40 --> Model "User_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:29:40 --> Controller Class Initialized
INFO - 2025-10-14 13:29:40 --> Model "Maturity_model" initialized
INFO - 2025-10-14 13:29:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\maturity/read.php
INFO - 2025-10-14 13:29:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:29:40 --> Model "Log_model" initialized
INFO - 2025-10-14 13:29:40 --> Final output sent to browser
DEBUG - 2025-10-14 13:29:40 --> Total execution time: 0.0893
INFO - 2025-10-14 08:29:40 --> Config Class Initialized
INFO - 2025-10-14 08:29:40 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:29:40 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:29:40 --> Utf8 Class Initialized
INFO - 2025-10-14 08:29:40 --> URI Class Initialized
INFO - 2025-10-14 08:29:40 --> Router Class Initialized
INFO - 2025-10-14 08:29:40 --> Output Class Initialized
INFO - 2025-10-14 08:29:40 --> Security Class Initialized
DEBUG - 2025-10-14 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:29:40 --> CSRF cookie sent
INFO - 2025-10-14 08:29:40 --> Input Class Initialized
INFO - 2025-10-14 08:29:40 --> Language Class Initialized
INFO - 2025-10-14 08:29:40 --> Loader Class Initialized
INFO - 2025-10-14 08:29:40 --> Helper loaded: url_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: text_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: string_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: form_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: download_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: security_helper
INFO - 2025-10-14 08:29:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:29:40 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:29:40 --> Form Validation Class Initialized
INFO - 2025-10-14 08:29:40 --> Model "User_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:29:40 --> Controller Class Initialized
INFO - 2025-10-14 13:29:40 --> Model "Berita_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Galeri_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Video_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Agenda_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Tautan_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Mitra_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Jurusan_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Prodi_model" initialized
INFO - 2025-10-14 13:29:40 --> Model "Testimoni_model" initialized
INFO - 2025-10-14 13:29:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-14 13:29:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:29:40 --> Model "Log_model" initialized
INFO - 2025-10-14 13:29:40 --> Final output sent to browser
DEBUG - 2025-10-14 13:29:40 --> Total execution time: 0.1041
INFO - 2025-10-14 08:29:43 --> Config Class Initialized
INFO - 2025-10-14 08:29:43 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:29:43 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:29:43 --> Utf8 Class Initialized
INFO - 2025-10-14 08:29:43 --> URI Class Initialized
INFO - 2025-10-14 08:29:43 --> Router Class Initialized
INFO - 2025-10-14 08:29:43 --> Output Class Initialized
INFO - 2025-10-14 08:29:43 --> Security Class Initialized
DEBUG - 2025-10-14 08:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:29:43 --> CSRF cookie sent
INFO - 2025-10-14 08:29:43 --> Input Class Initialized
INFO - 2025-10-14 08:29:43 --> Language Class Initialized
INFO - 2025-10-14 08:29:43 --> Loader Class Initialized
INFO - 2025-10-14 08:29:43 --> Helper loaded: url_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: text_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: string_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: form_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: download_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: security_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:29:43 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:29:43 --> Form Validation Class Initialized
INFO - 2025-10-14 08:29:43 --> Model "User_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:29:43 --> Controller Class Initialized
INFO - 2025-10-14 13:29:43 --> Model "Maturity_model" initialized
INFO - 2025-10-14 13:29:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\maturity/read.php
INFO - 2025-10-14 13:29:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:29:43 --> Model "Log_model" initialized
INFO - 2025-10-14 13:29:43 --> Final output sent to browser
DEBUG - 2025-10-14 13:29:43 --> Total execution time: 0.0826
INFO - 2025-10-14 08:29:43 --> Config Class Initialized
INFO - 2025-10-14 08:29:43 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:29:43 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:29:43 --> Utf8 Class Initialized
INFO - 2025-10-14 08:29:43 --> URI Class Initialized
INFO - 2025-10-14 08:29:43 --> Router Class Initialized
INFO - 2025-10-14 08:29:43 --> Output Class Initialized
INFO - 2025-10-14 08:29:43 --> Security Class Initialized
DEBUG - 2025-10-14 08:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:29:43 --> CSRF cookie sent
INFO - 2025-10-14 08:29:43 --> Input Class Initialized
INFO - 2025-10-14 08:29:43 --> Language Class Initialized
INFO - 2025-10-14 08:29:43 --> Loader Class Initialized
INFO - 2025-10-14 08:29:43 --> Helper loaded: url_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: text_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: string_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: form_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: download_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: security_helper
INFO - 2025-10-14 08:29:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:29:43 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:29:43 --> Form Validation Class Initialized
INFO - 2025-10-14 08:29:43 --> Model "User_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:29:43 --> Controller Class Initialized
INFO - 2025-10-14 13:29:43 --> Model "Berita_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Galeri_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Video_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Agenda_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Tautan_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Mitra_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Jurusan_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Prodi_model" initialized
INFO - 2025-10-14 13:29:43 --> Model "Testimoni_model" initialized
INFO - 2025-10-14 13:29:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-14 13:29:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:29:43 --> Model "Log_model" initialized
INFO - 2025-10-14 13:29:43 --> Final output sent to browser
DEBUG - 2025-10-14 13:29:43 --> Total execution time: 0.0897
INFO - 2025-10-14 08:40:10 --> Config Class Initialized
INFO - 2025-10-14 08:40:10 --> Hooks Class Initialized
DEBUG - 2025-10-14 08:40:10 --> UTF-8 Support Enabled
INFO - 2025-10-14 08:40:10 --> Utf8 Class Initialized
INFO - 2025-10-14 08:40:10 --> URI Class Initialized
INFO - 2025-10-14 08:40:10 --> Router Class Initialized
INFO - 2025-10-14 08:40:10 --> Output Class Initialized
INFO - 2025-10-14 08:40:10 --> Security Class Initialized
DEBUG - 2025-10-14 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-14 08:40:10 --> CSRF cookie sent
INFO - 2025-10-14 08:40:10 --> Input Class Initialized
INFO - 2025-10-14 08:40:10 --> Language Class Initialized
INFO - 2025-10-14 08:40:10 --> Loader Class Initialized
INFO - 2025-10-14 08:40:10 --> Helper loaded: url_helper
INFO - 2025-10-14 08:40:10 --> Helper loaded: text_helper
INFO - 2025-10-14 08:40:10 --> Helper loaded: string_helper
INFO - 2025-10-14 08:40:10 --> Helper loaded: form_helper
INFO - 2025-10-14 08:40:10 --> Helper loaded: download_helper
INFO - 2025-10-14 08:40:10 --> Helper loaded: security_helper
INFO - 2025-10-14 08:40:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-14 08:40:10 --> Database Driver Class Initialized
DEBUG - 2025-10-14 08:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-14 08:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-14 08:40:10 --> Form Validation Class Initialized
INFO - 2025-10-14 08:40:10 --> Model "User_model" initialized
INFO - 2025-10-14 13:40:10 --> Model "Kunjungan_model" initialized
INFO - 2025-10-14 13:40:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-14 13:40:10 --> Model "Nav_model" initialized
INFO - 2025-10-14 13:40:10 --> Controller Class Initialized
INFO - 2025-10-14 13:40:10 --> Model "Pusat_model" initialized
INFO - 2025-10-14 13:40:10 --> Model "Prodi_model" initialized
INFO - 2025-10-14 13:40:10 --> Model "Sdm_model" initialized
INFO - 2025-10-14 13:40:10 --> Model "Sdm_pusat_model" initialized
INFO - 2025-10-14 13:40:10 --> Query SDM berhasil untuk pusat: Pusat Pengembangan Pendidikan, Total: 1
INFO - 2025-10-14 13:40:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-10-14 13:40:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-14 13:40:11 --> Model "Log_model" initialized
INFO - 2025-10-14 13:40:11 --> Final output sent to browser
DEBUG - 2025-10-14 13:40:11 --> Total execution time: 0.9595
