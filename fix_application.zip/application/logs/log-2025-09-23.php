<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-09-23 03:32:20 --> Config Class Initialized
INFO - 2025-09-23 03:32:20 --> Hooks Class Initialized
DEBUG - 2025-09-23 03:32:20 --> UTF-8 Support Enabled
INFO - 2025-09-23 03:32:20 --> Utf8 Class Initialized
INFO - 2025-09-23 03:32:20 --> URI Class Initialized
DEBUG - 2025-09-23 03:32:20 --> No URI present. Default controller set.
INFO - 2025-09-23 03:32:20 --> Router Class Initialized
INFO - 2025-09-23 03:32:20 --> Output Class Initialized
INFO - 2025-09-23 03:32:20 --> Security Class Initialized
DEBUG - 2025-09-23 03:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 03:32:21 --> CSRF cookie sent
INFO - 2025-09-23 03:32:21 --> Input Class Initialized
INFO - 2025-09-23 03:32:21 --> Language Class Initialized
INFO - 2025-09-23 03:32:21 --> Loader Class Initialized
INFO - 2025-09-23 03:32:21 --> Helper loaded: url_helper
INFO - 2025-09-23 03:32:21 --> Helper loaded: text_helper
INFO - 2025-09-23 03:32:21 --> Helper loaded: string_helper
INFO - 2025-09-23 03:32:21 --> Helper loaded: form_helper
INFO - 2025-09-23 03:32:21 --> Helper loaded: download_helper
INFO - 2025-09-23 03:32:21 --> Helper loaded: security_helper
INFO - 2025-09-23 03:32:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 03:32:22 --> Database Driver Class Initialized
DEBUG - 2025-09-23 03:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 03:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 03:32:22 --> Form Validation Class Initialized
INFO - 2025-09-23 03:32:22 --> Model "User_model" initialized
INFO - 2025-09-23 08:32:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 08:32:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 08:32:23 --> Model "Nav_model" initialized
INFO - 2025-09-23 08:32:23 --> Controller Class Initialized
INFO - 2025-09-23 08:32:23 --> Model "Berita_model" initialized
INFO - 2025-09-23 08:32:23 --> Model "Galeri_model" initialized
INFO - 2025-09-23 08:32:23 --> Model "Video_model" initialized
INFO - 2025-09-23 08:32:23 --> Model "Agenda_model" initialized
INFO - 2025-09-23 08:32:23 --> Model "Tautan_model" initialized
INFO - 2025-09-23 08:32:23 --> Model "Mitra_model" initialized
INFO - 2025-09-23 08:32:23 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 08:32:23 --> Model "Prodi_model" initialized
INFO - 2025-09-23 08:32:23 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 08:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 08:32:24 --> Pagination Class Initialized
INFO - 2025-09-23 08:32:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 08:32:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 08:32:26 --> Model "Log_model" initialized
INFO - 2025-09-23 08:32:26 --> Final output sent to browser
DEBUG - 2025-09-23 08:32:26 --> Total execution time: 6.5709
INFO - 2025-09-23 03:32:53 --> Config Class Initialized
INFO - 2025-09-23 03:32:53 --> Hooks Class Initialized
DEBUG - 2025-09-23 03:32:53 --> UTF-8 Support Enabled
INFO - 2025-09-23 03:32:53 --> Utf8 Class Initialized
INFO - 2025-09-23 03:32:53 --> URI Class Initialized
DEBUG - 2025-09-23 03:32:53 --> No URI present. Default controller set.
INFO - 2025-09-23 03:32:53 --> Router Class Initialized
INFO - 2025-09-23 03:32:53 --> Output Class Initialized
INFO - 2025-09-23 03:32:53 --> Security Class Initialized
DEBUG - 2025-09-23 03:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 03:32:53 --> CSRF cookie sent
INFO - 2025-09-23 03:32:53 --> Input Class Initialized
INFO - 2025-09-23 03:32:53 --> Language Class Initialized
INFO - 2025-09-23 03:32:53 --> Loader Class Initialized
INFO - 2025-09-23 03:32:53 --> Helper loaded: url_helper
INFO - 2025-09-23 03:32:53 --> Helper loaded: text_helper
INFO - 2025-09-23 03:32:53 --> Helper loaded: string_helper
INFO - 2025-09-23 03:32:53 --> Helper loaded: form_helper
INFO - 2025-09-23 03:32:53 --> Helper loaded: download_helper
INFO - 2025-09-23 03:32:53 --> Helper loaded: security_helper
INFO - 2025-09-23 03:32:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 03:32:53 --> Database Driver Class Initialized
DEBUG - 2025-09-23 03:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 03:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 03:32:54 --> Form Validation Class Initialized
INFO - 2025-09-23 03:32:54 --> Model "User_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Nav_model" initialized
INFO - 2025-09-23 08:32:54 --> Controller Class Initialized
INFO - 2025-09-23 08:32:54 --> Model "Berita_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Galeri_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Video_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Agenda_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Tautan_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Mitra_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Prodi_model" initialized
INFO - 2025-09-23 08:32:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 08:32:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 08:32:54 --> Pagination Class Initialized
INFO - 2025-09-23 08:32:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 08:32:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 08:32:54 --> Model "Log_model" initialized
INFO - 2025-09-23 08:32:54 --> Final output sent to browser
DEBUG - 2025-09-23 08:32:54 --> Total execution time: 0.2107
INFO - 2025-09-23 03:33:06 --> Config Class Initialized
INFO - 2025-09-23 03:33:06 --> Hooks Class Initialized
DEBUG - 2025-09-23 03:33:06 --> UTF-8 Support Enabled
INFO - 2025-09-23 03:33:06 --> Utf8 Class Initialized
INFO - 2025-09-23 03:33:06 --> URI Class Initialized
DEBUG - 2025-09-23 03:33:06 --> No URI present. Default controller set.
INFO - 2025-09-23 03:33:06 --> Router Class Initialized
INFO - 2025-09-23 03:33:06 --> Output Class Initialized
INFO - 2025-09-23 03:33:06 --> Security Class Initialized
DEBUG - 2025-09-23 03:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 03:33:06 --> CSRF cookie sent
INFO - 2025-09-23 03:33:06 --> Input Class Initialized
INFO - 2025-09-23 03:33:06 --> Language Class Initialized
INFO - 2025-09-23 03:33:06 --> Loader Class Initialized
INFO - 2025-09-23 03:33:06 --> Helper loaded: url_helper
INFO - 2025-09-23 03:33:06 --> Helper loaded: text_helper
INFO - 2025-09-23 03:33:06 --> Helper loaded: string_helper
INFO - 2025-09-23 03:33:06 --> Helper loaded: form_helper
INFO - 2025-09-23 03:33:06 --> Helper loaded: download_helper
INFO - 2025-09-23 03:33:06 --> Helper loaded: security_helper
INFO - 2025-09-23 03:33:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 03:33:06 --> Database Driver Class Initialized
DEBUG - 2025-09-23 03:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 03:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 03:33:06 --> Form Validation Class Initialized
INFO - 2025-09-23 03:33:06 --> Model "User_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Nav_model" initialized
INFO - 2025-09-23 08:33:06 --> Controller Class Initialized
INFO - 2025-09-23 08:33:06 --> Model "Berita_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Galeri_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Video_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Agenda_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Tautan_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Mitra_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Prodi_model" initialized
INFO - 2025-09-23 08:33:06 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 08:33:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 08:33:06 --> Pagination Class Initialized
INFO - 2025-09-23 08:33:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 08:33:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 08:33:06 --> Model "Log_model" initialized
INFO - 2025-09-23 08:33:06 --> Final output sent to browser
DEBUG - 2025-09-23 08:33:06 --> Total execution time: 0.2120
INFO - 2025-09-23 03:33:08 --> Config Class Initialized
INFO - 2025-09-23 03:33:08 --> Hooks Class Initialized
DEBUG - 2025-09-23 03:33:08 --> UTF-8 Support Enabled
INFO - 2025-09-23 03:33:08 --> Utf8 Class Initialized
INFO - 2025-09-23 03:33:08 --> URI Class Initialized
DEBUG - 2025-09-23 03:33:08 --> No URI present. Default controller set.
INFO - 2025-09-23 03:33:08 --> Router Class Initialized
INFO - 2025-09-23 03:33:08 --> Output Class Initialized
INFO - 2025-09-23 03:33:08 --> Security Class Initialized
DEBUG - 2025-09-23 03:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 03:33:08 --> CSRF cookie sent
INFO - 2025-09-23 03:33:08 --> Input Class Initialized
INFO - 2025-09-23 03:33:08 --> Language Class Initialized
INFO - 2025-09-23 03:33:08 --> Loader Class Initialized
INFO - 2025-09-23 03:33:08 --> Helper loaded: url_helper
INFO - 2025-09-23 03:33:08 --> Helper loaded: text_helper
INFO - 2025-09-23 03:33:08 --> Helper loaded: string_helper
INFO - 2025-09-23 03:33:08 --> Helper loaded: form_helper
INFO - 2025-09-23 03:33:08 --> Helper loaded: download_helper
INFO - 2025-09-23 03:33:08 --> Helper loaded: security_helper
INFO - 2025-09-23 03:33:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 03:33:08 --> Database Driver Class Initialized
DEBUG - 2025-09-23 03:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 03:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 03:33:08 --> Form Validation Class Initialized
INFO - 2025-09-23 03:33:08 --> Model "User_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Nav_model" initialized
INFO - 2025-09-23 08:33:08 --> Controller Class Initialized
INFO - 2025-09-23 08:33:08 --> Model "Berita_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Galeri_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Video_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Agenda_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Tautan_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Mitra_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Prodi_model" initialized
INFO - 2025-09-23 08:33:08 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 08:33:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 08:33:08 --> Pagination Class Initialized
INFO - 2025-09-23 08:33:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 08:33:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 08:33:08 --> Model "Log_model" initialized
INFO - 2025-09-23 08:33:08 --> Final output sent to browser
DEBUG - 2025-09-23 08:33:08 --> Total execution time: 0.2578
INFO - 2025-09-23 03:37:42 --> Config Class Initialized
INFO - 2025-09-23 03:37:42 --> Hooks Class Initialized
DEBUG - 2025-09-23 03:37:42 --> UTF-8 Support Enabled
INFO - 2025-09-23 03:37:42 --> Utf8 Class Initialized
INFO - 2025-09-23 03:37:42 --> URI Class Initialized
DEBUG - 2025-09-23 03:37:42 --> No URI present. Default controller set.
INFO - 2025-09-23 03:37:42 --> Router Class Initialized
INFO - 2025-09-23 03:37:42 --> Output Class Initialized
INFO - 2025-09-23 03:37:42 --> Security Class Initialized
DEBUG - 2025-09-23 03:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 03:37:42 --> CSRF cookie sent
INFO - 2025-09-23 03:37:42 --> Input Class Initialized
INFO - 2025-09-23 03:37:42 --> Language Class Initialized
INFO - 2025-09-23 03:37:42 --> Loader Class Initialized
INFO - 2025-09-23 03:37:42 --> Helper loaded: url_helper
INFO - 2025-09-23 03:37:42 --> Helper loaded: text_helper
INFO - 2025-09-23 03:37:42 --> Helper loaded: string_helper
INFO - 2025-09-23 03:37:42 --> Helper loaded: form_helper
INFO - 2025-09-23 03:37:42 --> Helper loaded: download_helper
INFO - 2025-09-23 03:37:42 --> Helper loaded: security_helper
INFO - 2025-09-23 03:37:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 03:37:42 --> Database Driver Class Initialized
DEBUG - 2025-09-23 03:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 03:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 03:37:42 --> Form Validation Class Initialized
INFO - 2025-09-23 03:37:42 --> Model "User_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Nav_model" initialized
INFO - 2025-09-23 08:37:42 --> Controller Class Initialized
INFO - 2025-09-23 08:37:42 --> Model "Berita_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Galeri_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Video_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Agenda_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Tautan_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Mitra_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Prodi_model" initialized
INFO - 2025-09-23 08:37:42 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 08:37:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 08:37:43 --> Pagination Class Initialized
INFO - 2025-09-23 08:37:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 08:37:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 08:37:43 --> Model "Log_model" initialized
INFO - 2025-09-23 08:37:43 --> Final output sent to browser
DEBUG - 2025-09-23 08:37:43 --> Total execution time: 0.3824
INFO - 2025-09-23 03:48:27 --> Config Class Initialized
INFO - 2025-09-23 03:48:27 --> Hooks Class Initialized
DEBUG - 2025-09-23 03:48:27 --> UTF-8 Support Enabled
INFO - 2025-09-23 03:48:27 --> Utf8 Class Initialized
INFO - 2025-09-23 03:48:27 --> URI Class Initialized
DEBUG - 2025-09-23 03:48:27 --> No URI present. Default controller set.
INFO - 2025-09-23 03:48:27 --> Router Class Initialized
INFO - 2025-09-23 03:48:27 --> Output Class Initialized
INFO - 2025-09-23 03:48:27 --> Security Class Initialized
DEBUG - 2025-09-23 03:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 03:48:27 --> CSRF cookie sent
INFO - 2025-09-23 03:48:27 --> Input Class Initialized
INFO - 2025-09-23 03:48:27 --> Language Class Initialized
INFO - 2025-09-23 03:48:27 --> Loader Class Initialized
INFO - 2025-09-23 03:48:27 --> Helper loaded: url_helper
INFO - 2025-09-23 03:48:27 --> Helper loaded: text_helper
INFO - 2025-09-23 03:48:27 --> Helper loaded: string_helper
INFO - 2025-09-23 03:48:27 --> Helper loaded: form_helper
INFO - 2025-09-23 03:48:27 --> Helper loaded: download_helper
INFO - 2025-09-23 03:48:27 --> Helper loaded: security_helper
INFO - 2025-09-23 03:48:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 03:48:28 --> Database Driver Class Initialized
DEBUG - 2025-09-23 03:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 03:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 03:48:28 --> Form Validation Class Initialized
INFO - 2025-09-23 03:48:28 --> Model "User_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Nav_model" initialized
INFO - 2025-09-23 08:48:28 --> Controller Class Initialized
INFO - 2025-09-23 08:48:28 --> Model "Berita_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Galeri_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Video_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Agenda_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Tautan_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Mitra_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Prodi_model" initialized
INFO - 2025-09-23 08:48:28 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 08:48:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 08:48:28 --> Pagination Class Initialized
INFO - 2025-09-23 08:48:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 08:48:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 08:48:28 --> Model "Log_model" initialized
INFO - 2025-09-23 08:48:28 --> Final output sent to browser
DEBUG - 2025-09-23 08:48:28 --> Total execution time: 0.0834
INFO - 2025-09-23 03:48:48 --> Config Class Initialized
INFO - 2025-09-23 03:48:48 --> Hooks Class Initialized
DEBUG - 2025-09-23 03:48:48 --> UTF-8 Support Enabled
INFO - 2025-09-23 03:48:48 --> Utf8 Class Initialized
INFO - 2025-09-23 03:48:48 --> URI Class Initialized
DEBUG - 2025-09-23 03:48:48 --> No URI present. Default controller set.
INFO - 2025-09-23 03:48:48 --> Router Class Initialized
INFO - 2025-09-23 03:48:48 --> Output Class Initialized
INFO - 2025-09-23 03:48:48 --> Security Class Initialized
DEBUG - 2025-09-23 03:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 03:48:48 --> CSRF cookie sent
INFO - 2025-09-23 03:48:48 --> Input Class Initialized
INFO - 2025-09-23 03:48:48 --> Language Class Initialized
INFO - 2025-09-23 03:48:48 --> Loader Class Initialized
INFO - 2025-09-23 03:48:48 --> Helper loaded: url_helper
INFO - 2025-09-23 03:48:48 --> Helper loaded: text_helper
INFO - 2025-09-23 03:48:48 --> Helper loaded: string_helper
INFO - 2025-09-23 03:48:48 --> Helper loaded: form_helper
INFO - 2025-09-23 03:48:48 --> Helper loaded: download_helper
INFO - 2025-09-23 03:48:48 --> Helper loaded: security_helper
INFO - 2025-09-23 03:48:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 03:48:48 --> Database Driver Class Initialized
DEBUG - 2025-09-23 03:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 03:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 03:48:48 --> Form Validation Class Initialized
INFO - 2025-09-23 03:48:48 --> Model "User_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Nav_model" initialized
INFO - 2025-09-23 08:48:48 --> Controller Class Initialized
INFO - 2025-09-23 08:48:48 --> Model "Berita_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Galeri_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Video_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Agenda_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Tautan_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Mitra_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Prodi_model" initialized
INFO - 2025-09-23 08:48:48 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 08:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 08:48:48 --> Pagination Class Initialized
INFO - 2025-09-23 08:48:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 08:48:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 08:48:48 --> Model "Log_model" initialized
INFO - 2025-09-23 08:48:48 --> Final output sent to browser
DEBUG - 2025-09-23 08:48:48 --> Total execution time: 0.1128
INFO - 2025-09-23 03:48:50 --> Config Class Initialized
INFO - 2025-09-23 03:48:50 --> Hooks Class Initialized
DEBUG - 2025-09-23 03:48:50 --> UTF-8 Support Enabled
INFO - 2025-09-23 03:48:50 --> Utf8 Class Initialized
INFO - 2025-09-23 03:48:50 --> URI Class Initialized
DEBUG - 2025-09-23 03:48:50 --> No URI present. Default controller set.
INFO - 2025-09-23 03:48:50 --> Router Class Initialized
INFO - 2025-09-23 03:48:50 --> Output Class Initialized
INFO - 2025-09-23 03:48:50 --> Security Class Initialized
DEBUG - 2025-09-23 03:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 03:48:50 --> CSRF cookie sent
INFO - 2025-09-23 03:48:50 --> Input Class Initialized
INFO - 2025-09-23 03:48:50 --> Language Class Initialized
INFO - 2025-09-23 03:48:50 --> Loader Class Initialized
INFO - 2025-09-23 03:48:50 --> Helper loaded: url_helper
INFO - 2025-09-23 03:48:50 --> Helper loaded: text_helper
INFO - 2025-09-23 03:48:50 --> Helper loaded: string_helper
INFO - 2025-09-23 03:48:50 --> Helper loaded: form_helper
INFO - 2025-09-23 03:48:50 --> Helper loaded: download_helper
INFO - 2025-09-23 03:48:50 --> Helper loaded: security_helper
INFO - 2025-09-23 03:48:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 03:48:50 --> Database Driver Class Initialized
DEBUG - 2025-09-23 03:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 03:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 03:48:50 --> Form Validation Class Initialized
INFO - 2025-09-23 03:48:50 --> Model "User_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Nav_model" initialized
INFO - 2025-09-23 08:48:50 --> Controller Class Initialized
INFO - 2025-09-23 08:48:50 --> Model "Berita_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Galeri_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Video_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Agenda_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Tautan_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Mitra_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Prodi_model" initialized
INFO - 2025-09-23 08:48:50 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 08:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 08:48:50 --> Pagination Class Initialized
INFO - 2025-09-23 08:48:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 08:48:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 08:48:50 --> Model "Log_model" initialized
INFO - 2025-09-23 08:48:50 --> Final output sent to browser
DEBUG - 2025-09-23 08:48:50 --> Total execution time: 0.1107
INFO - 2025-09-23 04:40:57 --> Config Class Initialized
INFO - 2025-09-23 04:40:57 --> Hooks Class Initialized
DEBUG - 2025-09-23 04:40:57 --> UTF-8 Support Enabled
INFO - 2025-09-23 04:40:57 --> Utf8 Class Initialized
INFO - 2025-09-23 04:40:57 --> URI Class Initialized
DEBUG - 2025-09-23 04:40:57 --> No URI present. Default controller set.
INFO - 2025-09-23 04:40:57 --> Router Class Initialized
INFO - 2025-09-23 04:40:57 --> Output Class Initialized
INFO - 2025-09-23 04:40:57 --> Security Class Initialized
DEBUG - 2025-09-23 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 04:40:57 --> CSRF cookie sent
INFO - 2025-09-23 04:40:57 --> Input Class Initialized
INFO - 2025-09-23 04:40:57 --> Language Class Initialized
INFO - 2025-09-23 04:40:57 --> Loader Class Initialized
INFO - 2025-09-23 04:40:57 --> Helper loaded: url_helper
INFO - 2025-09-23 04:40:57 --> Helper loaded: text_helper
INFO - 2025-09-23 04:40:57 --> Helper loaded: string_helper
INFO - 2025-09-23 04:40:57 --> Helper loaded: form_helper
INFO - 2025-09-23 04:40:57 --> Helper loaded: download_helper
INFO - 2025-09-23 04:40:57 --> Helper loaded: security_helper
INFO - 2025-09-23 04:40:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 04:40:57 --> Database Driver Class Initialized
DEBUG - 2025-09-23 04:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 04:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 04:40:57 --> Form Validation Class Initialized
INFO - 2025-09-23 04:40:57 --> Model "User_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Nav_model" initialized
INFO - 2025-09-23 09:40:57 --> Controller Class Initialized
INFO - 2025-09-23 09:40:57 --> Model "Berita_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Galeri_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Video_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Agenda_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Tautan_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Mitra_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Prodi_model" initialized
INFO - 2025-09-23 09:40:57 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 09:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 09:40:57 --> Pagination Class Initialized
INFO - 2025-09-23 09:40:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 09:40:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 09:40:57 --> Model "Log_model" initialized
INFO - 2025-09-23 09:40:57 --> Final output sent to browser
DEBUG - 2025-09-23 09:40:57 --> Total execution time: 0.1422
INFO - 2025-09-23 04:49:56 --> Config Class Initialized
INFO - 2025-09-23 04:49:56 --> Hooks Class Initialized
DEBUG - 2025-09-23 04:49:56 --> UTF-8 Support Enabled
INFO - 2025-09-23 04:49:56 --> Utf8 Class Initialized
INFO - 2025-09-23 04:49:56 --> URI Class Initialized
DEBUG - 2025-09-23 04:49:56 --> No URI present. Default controller set.
INFO - 2025-09-23 04:49:56 --> Router Class Initialized
INFO - 2025-09-23 04:49:56 --> Output Class Initialized
INFO - 2025-09-23 04:49:56 --> Security Class Initialized
DEBUG - 2025-09-23 04:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 04:49:56 --> CSRF cookie sent
INFO - 2025-09-23 04:49:56 --> Input Class Initialized
INFO - 2025-09-23 04:49:56 --> Language Class Initialized
INFO - 2025-09-23 04:49:56 --> Loader Class Initialized
INFO - 2025-09-23 04:49:56 --> Helper loaded: url_helper
INFO - 2025-09-23 04:49:56 --> Helper loaded: text_helper
INFO - 2025-09-23 04:49:56 --> Helper loaded: string_helper
INFO - 2025-09-23 04:49:56 --> Helper loaded: form_helper
INFO - 2025-09-23 04:49:56 --> Helper loaded: download_helper
INFO - 2025-09-23 04:49:56 --> Helper loaded: security_helper
INFO - 2025-09-23 04:49:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 04:49:56 --> Database Driver Class Initialized
DEBUG - 2025-09-23 04:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 04:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 04:49:56 --> Form Validation Class Initialized
INFO - 2025-09-23 04:49:56 --> Model "User_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Nav_model" initialized
INFO - 2025-09-23 09:49:56 --> Controller Class Initialized
INFO - 2025-09-23 09:49:56 --> Model "Berita_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Galeri_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Video_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Agenda_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Tautan_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Mitra_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Prodi_model" initialized
INFO - 2025-09-23 09:49:56 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 09:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 09:49:56 --> Pagination Class Initialized
INFO - 2025-09-23 09:49:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 09:49:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 09:49:56 --> Model "Log_model" initialized
INFO - 2025-09-23 09:49:56 --> Final output sent to browser
DEBUG - 2025-09-23 09:49:56 --> Total execution time: 0.0926
INFO - 2025-09-23 04:51:22 --> Config Class Initialized
INFO - 2025-09-23 04:51:22 --> Hooks Class Initialized
DEBUG - 2025-09-23 04:51:22 --> UTF-8 Support Enabled
INFO - 2025-09-23 04:51:22 --> Utf8 Class Initialized
INFO - 2025-09-23 04:51:22 --> URI Class Initialized
DEBUG - 2025-09-23 04:51:22 --> No URI present. Default controller set.
INFO - 2025-09-23 04:51:22 --> Router Class Initialized
INFO - 2025-09-23 04:51:22 --> Output Class Initialized
INFO - 2025-09-23 04:51:22 --> Security Class Initialized
DEBUG - 2025-09-23 04:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 04:51:22 --> CSRF cookie sent
INFO - 2025-09-23 04:51:22 --> Input Class Initialized
INFO - 2025-09-23 04:51:22 --> Language Class Initialized
INFO - 2025-09-23 04:51:22 --> Loader Class Initialized
INFO - 2025-09-23 04:51:22 --> Helper loaded: url_helper
INFO - 2025-09-23 04:51:22 --> Helper loaded: text_helper
INFO - 2025-09-23 04:51:22 --> Helper loaded: string_helper
INFO - 2025-09-23 04:51:22 --> Helper loaded: form_helper
INFO - 2025-09-23 04:51:22 --> Helper loaded: download_helper
INFO - 2025-09-23 04:51:22 --> Helper loaded: security_helper
INFO - 2025-09-23 04:51:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 04:51:22 --> Database Driver Class Initialized
DEBUG - 2025-09-23 04:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 04:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 04:51:22 --> Form Validation Class Initialized
INFO - 2025-09-23 04:51:22 --> Model "User_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Nav_model" initialized
INFO - 2025-09-23 09:51:22 --> Controller Class Initialized
INFO - 2025-09-23 09:51:22 --> Model "Berita_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Galeri_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Video_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Agenda_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Tautan_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Mitra_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Prodi_model" initialized
INFO - 2025-09-23 09:51:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 09:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 09:51:23 --> Pagination Class Initialized
INFO - 2025-09-23 09:51:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 09:51:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 09:51:23 --> Model "Log_model" initialized
INFO - 2025-09-23 09:51:23 --> Final output sent to browser
DEBUG - 2025-09-23 09:51:23 --> Total execution time: 0.1063
INFO - 2025-09-23 04:57:46 --> Config Class Initialized
INFO - 2025-09-23 04:57:46 --> Hooks Class Initialized
DEBUG - 2025-09-23 04:57:46 --> UTF-8 Support Enabled
INFO - 2025-09-23 04:57:46 --> Utf8 Class Initialized
INFO - 2025-09-23 04:57:46 --> URI Class Initialized
DEBUG - 2025-09-23 04:57:46 --> No URI present. Default controller set.
INFO - 2025-09-23 04:57:46 --> Router Class Initialized
INFO - 2025-09-23 04:57:46 --> Output Class Initialized
INFO - 2025-09-23 04:57:46 --> Security Class Initialized
DEBUG - 2025-09-23 04:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 04:57:46 --> CSRF cookie sent
INFO - 2025-09-23 04:57:46 --> Input Class Initialized
INFO - 2025-09-23 04:57:46 --> Language Class Initialized
INFO - 2025-09-23 04:57:46 --> Loader Class Initialized
INFO - 2025-09-23 04:57:46 --> Helper loaded: url_helper
INFO - 2025-09-23 04:57:46 --> Helper loaded: text_helper
INFO - 2025-09-23 04:57:46 --> Helper loaded: string_helper
INFO - 2025-09-23 04:57:46 --> Helper loaded: form_helper
INFO - 2025-09-23 04:57:46 --> Helper loaded: download_helper
INFO - 2025-09-23 04:57:46 --> Helper loaded: security_helper
INFO - 2025-09-23 04:57:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 04:57:46 --> Database Driver Class Initialized
DEBUG - 2025-09-23 04:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 04:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 04:57:46 --> Form Validation Class Initialized
INFO - 2025-09-23 04:57:46 --> Model "User_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Nav_model" initialized
INFO - 2025-09-23 09:57:46 --> Controller Class Initialized
INFO - 2025-09-23 09:57:46 --> Model "Berita_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Galeri_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Video_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Agenda_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Tautan_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Mitra_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Prodi_model" initialized
INFO - 2025-09-23 09:57:46 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 09:57:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 09:57:46 --> Pagination Class Initialized
INFO - 2025-09-23 09:57:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 09:57:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 09:57:46 --> Model "Log_model" initialized
INFO - 2025-09-23 09:57:46 --> Final output sent to browser
DEBUG - 2025-09-23 09:57:46 --> Total execution time: 0.1948
INFO - 2025-09-23 04:57:49 --> Config Class Initialized
INFO - 2025-09-23 04:57:49 --> Hooks Class Initialized
DEBUG - 2025-09-23 04:57:49 --> UTF-8 Support Enabled
INFO - 2025-09-23 04:57:49 --> Utf8 Class Initialized
INFO - 2025-09-23 04:57:49 --> URI Class Initialized
INFO - 2025-09-23 04:57:49 --> Router Class Initialized
INFO - 2025-09-23 04:57:49 --> Output Class Initialized
INFO - 2025-09-23 04:57:49 --> Security Class Initialized
DEBUG - 2025-09-23 04:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 04:57:49 --> CSRF cookie sent
INFO - 2025-09-23 04:57:49 --> Input Class Initialized
INFO - 2025-09-23 04:57:49 --> Language Class Initialized
ERROR - 2025-09-23 04:57:49 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) D:\xampp\htdocs\dev_jkt3\application\controllers\Cookies.php 26
INFO - 2025-09-23 04:58:21 --> Config Class Initialized
INFO - 2025-09-23 04:58:21 --> Hooks Class Initialized
DEBUG - 2025-09-23 04:58:21 --> UTF-8 Support Enabled
INFO - 2025-09-23 04:58:21 --> Utf8 Class Initialized
INFO - 2025-09-23 04:58:21 --> URI Class Initialized
INFO - 2025-09-23 04:58:21 --> Router Class Initialized
INFO - 2025-09-23 04:58:21 --> Output Class Initialized
INFO - 2025-09-23 04:58:21 --> Security Class Initialized
DEBUG - 2025-09-23 04:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 04:58:21 --> CSRF cookie sent
INFO - 2025-09-23 04:58:21 --> Input Class Initialized
INFO - 2025-09-23 04:58:21 --> Language Class Initialized
INFO - 2025-09-23 04:58:21 --> Loader Class Initialized
INFO - 2025-09-23 04:58:21 --> Helper loaded: url_helper
INFO - 2025-09-23 04:58:21 --> Helper loaded: text_helper
INFO - 2025-09-23 04:58:21 --> Helper loaded: string_helper
INFO - 2025-09-23 04:58:21 --> Helper loaded: form_helper
INFO - 2025-09-23 04:58:21 --> Helper loaded: download_helper
INFO - 2025-09-23 04:58:21 --> Helper loaded: security_helper
INFO - 2025-09-23 04:58:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 04:58:21 --> Database Driver Class Initialized
DEBUG - 2025-09-23 04:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 04:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 04:58:21 --> Form Validation Class Initialized
INFO - 2025-09-23 04:58:21 --> Model "User_model" initialized
INFO - 2025-09-23 09:58:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 09:58:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 09:58:21 --> Model "Nav_model" initialized
INFO - 2025-09-23 09:58:21 --> Controller Class Initialized
INFO - 2025-09-23 09:58:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\kebijakan-cookies.php
INFO - 2025-09-23 09:58:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 09:58:21 --> Model "Log_model" initialized
INFO - 2025-09-23 09:58:21 --> Final output sent to browser
DEBUG - 2025-09-23 09:58:21 --> Total execution time: 0.0657
INFO - 2025-09-23 04:58:30 --> Config Class Initialized
INFO - 2025-09-23 04:58:30 --> Hooks Class Initialized
DEBUG - 2025-09-23 04:58:30 --> UTF-8 Support Enabled
INFO - 2025-09-23 04:58:30 --> Utf8 Class Initialized
INFO - 2025-09-23 04:58:30 --> URI Class Initialized
DEBUG - 2025-09-23 04:58:30 --> No URI present. Default controller set.
INFO - 2025-09-23 04:58:30 --> Router Class Initialized
INFO - 2025-09-23 04:58:30 --> Output Class Initialized
INFO - 2025-09-23 04:58:30 --> Security Class Initialized
DEBUG - 2025-09-23 04:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 04:58:30 --> CSRF cookie sent
INFO - 2025-09-23 04:58:30 --> Input Class Initialized
INFO - 2025-09-23 04:58:30 --> Language Class Initialized
INFO - 2025-09-23 04:58:30 --> Loader Class Initialized
INFO - 2025-09-23 04:58:30 --> Helper loaded: url_helper
INFO - 2025-09-23 04:58:30 --> Helper loaded: text_helper
INFO - 2025-09-23 04:58:30 --> Helper loaded: string_helper
INFO - 2025-09-23 04:58:30 --> Helper loaded: form_helper
INFO - 2025-09-23 04:58:30 --> Helper loaded: download_helper
INFO - 2025-09-23 04:58:30 --> Helper loaded: security_helper
INFO - 2025-09-23 04:58:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 04:58:30 --> Database Driver Class Initialized
DEBUG - 2025-09-23 04:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 04:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 04:58:30 --> Form Validation Class Initialized
INFO - 2025-09-23 04:58:30 --> Model "User_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Nav_model" initialized
INFO - 2025-09-23 09:58:30 --> Controller Class Initialized
INFO - 2025-09-23 09:58:30 --> Model "Berita_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Galeri_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Video_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Agenda_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Tautan_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Mitra_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Prodi_model" initialized
INFO - 2025-09-23 09:58:30 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 09:58:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 09:58:30 --> Pagination Class Initialized
INFO - 2025-09-23 09:58:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 09:58:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 09:58:30 --> Model "Log_model" initialized
INFO - 2025-09-23 09:58:30 --> Final output sent to browser
DEBUG - 2025-09-23 09:58:30 --> Total execution time: 0.1112
INFO - 2025-09-23 04:58:32 --> Config Class Initialized
INFO - 2025-09-23 04:58:32 --> Hooks Class Initialized
DEBUG - 2025-09-23 04:58:32 --> UTF-8 Support Enabled
INFO - 2025-09-23 04:58:32 --> Utf8 Class Initialized
INFO - 2025-09-23 04:58:32 --> URI Class Initialized
INFO - 2025-09-23 04:58:32 --> Router Class Initialized
INFO - 2025-09-23 04:58:32 --> Output Class Initialized
INFO - 2025-09-23 04:58:32 --> Security Class Initialized
DEBUG - 2025-09-23 04:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 04:58:32 --> CSRF cookie sent
INFO - 2025-09-23 04:58:32 --> Input Class Initialized
INFO - 2025-09-23 04:58:32 --> Language Class Initialized
INFO - 2025-09-23 04:58:32 --> Loader Class Initialized
INFO - 2025-09-23 04:58:32 --> Helper loaded: url_helper
INFO - 2025-09-23 04:58:32 --> Helper loaded: text_helper
INFO - 2025-09-23 04:58:32 --> Helper loaded: string_helper
INFO - 2025-09-23 04:58:32 --> Helper loaded: form_helper
INFO - 2025-09-23 04:58:32 --> Helper loaded: download_helper
INFO - 2025-09-23 04:58:32 --> Helper loaded: security_helper
INFO - 2025-09-23 04:58:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 04:58:32 --> Database Driver Class Initialized
DEBUG - 2025-09-23 04:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 04:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 04:58:32 --> Form Validation Class Initialized
INFO - 2025-09-23 04:58:32 --> Model "User_model" initialized
INFO - 2025-09-23 09:58:32 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 09:58:32 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 09:58:32 --> Model "Nav_model" initialized
INFO - 2025-09-23 09:58:32 --> Controller Class Initialized
INFO - 2025-09-23 09:58:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\kebijakan-cookies.php
INFO - 2025-09-23 09:58:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 09:58:32 --> Model "Log_model" initialized
INFO - 2025-09-23 09:58:32 --> Final output sent to browser
DEBUG - 2025-09-23 09:58:32 --> Total execution time: 0.0636
INFO - 2025-09-23 04:59:01 --> Config Class Initialized
INFO - 2025-09-23 04:59:01 --> Hooks Class Initialized
DEBUG - 2025-09-23 04:59:01 --> UTF-8 Support Enabled
INFO - 2025-09-23 04:59:01 --> Utf8 Class Initialized
INFO - 2025-09-23 04:59:01 --> URI Class Initialized
INFO - 2025-09-23 04:59:01 --> Router Class Initialized
INFO - 2025-09-23 04:59:01 --> Output Class Initialized
INFO - 2025-09-23 04:59:01 --> Security Class Initialized
DEBUG - 2025-09-23 04:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 04:59:01 --> CSRF cookie sent
INFO - 2025-09-23 04:59:01 --> Input Class Initialized
INFO - 2025-09-23 04:59:01 --> Language Class Initialized
INFO - 2025-09-23 04:59:01 --> Loader Class Initialized
INFO - 2025-09-23 04:59:01 --> Helper loaded: url_helper
INFO - 2025-09-23 04:59:01 --> Helper loaded: text_helper
INFO - 2025-09-23 04:59:01 --> Helper loaded: string_helper
INFO - 2025-09-23 04:59:01 --> Helper loaded: form_helper
INFO - 2025-09-23 04:59:01 --> Helper loaded: download_helper
INFO - 2025-09-23 04:59:01 --> Helper loaded: security_helper
INFO - 2025-09-23 04:59:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 04:59:01 --> Database Driver Class Initialized
DEBUG - 2025-09-23 04:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 04:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 04:59:01 --> Form Validation Class Initialized
INFO - 2025-09-23 04:59:01 --> Model "User_model" initialized
INFO - 2025-09-23 09:59:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 09:59:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 09:59:01 --> Model "Nav_model" initialized
INFO - 2025-09-23 09:59:01 --> Controller Class Initialized
INFO - 2025-09-23 09:59:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\kebijakan-cookies.php
INFO - 2025-09-23 09:59:01 --> Model "Log_model" initialized
INFO - 2025-09-23 09:59:01 --> Final output sent to browser
DEBUG - 2025-09-23 09:59:01 --> Total execution time: 0.0409
INFO - 2025-09-23 04:59:18 --> Config Class Initialized
INFO - 2025-09-23 04:59:18 --> Hooks Class Initialized
DEBUG - 2025-09-23 04:59:18 --> UTF-8 Support Enabled
INFO - 2025-09-23 04:59:18 --> Utf8 Class Initialized
INFO - 2025-09-23 04:59:18 --> URI Class Initialized
INFO - 2025-09-23 04:59:18 --> Router Class Initialized
INFO - 2025-09-23 04:59:18 --> Output Class Initialized
INFO - 2025-09-23 04:59:18 --> Security Class Initialized
DEBUG - 2025-09-23 04:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 04:59:18 --> CSRF cookie sent
INFO - 2025-09-23 04:59:18 --> Input Class Initialized
INFO - 2025-09-23 04:59:18 --> Language Class Initialized
INFO - 2025-09-23 04:59:18 --> Loader Class Initialized
INFO - 2025-09-23 04:59:18 --> Helper loaded: url_helper
INFO - 2025-09-23 04:59:18 --> Helper loaded: text_helper
INFO - 2025-09-23 04:59:18 --> Helper loaded: string_helper
INFO - 2025-09-23 04:59:18 --> Helper loaded: form_helper
INFO - 2025-09-23 04:59:18 --> Helper loaded: download_helper
INFO - 2025-09-23 04:59:18 --> Helper loaded: security_helper
INFO - 2025-09-23 04:59:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 04:59:18 --> Database Driver Class Initialized
DEBUG - 2025-09-23 04:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 04:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 04:59:18 --> Form Validation Class Initialized
INFO - 2025-09-23 04:59:18 --> Model "User_model" initialized
INFO - 2025-09-23 09:59:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 09:59:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 09:59:18 --> Model "Nav_model" initialized
INFO - 2025-09-23 09:59:18 --> Controller Class Initialized
INFO - 2025-09-23 09:59:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\kebijakan-cookies.php
INFO - 2025-09-23 09:59:18 --> Model "Log_model" initialized
INFO - 2025-09-23 09:59:18 --> Final output sent to browser
DEBUG - 2025-09-23 09:59:18 --> Total execution time: 0.0672
INFO - 2025-09-23 05:01:50 --> Config Class Initialized
INFO - 2025-09-23 05:01:50 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:01:50 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:01:50 --> Utf8 Class Initialized
INFO - 2025-09-23 05:01:50 --> URI Class Initialized
INFO - 2025-09-23 05:01:50 --> Router Class Initialized
INFO - 2025-09-23 05:01:50 --> Output Class Initialized
INFO - 2025-09-23 05:01:50 --> Security Class Initialized
DEBUG - 2025-09-23 05:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:01:50 --> CSRF cookie sent
INFO - 2025-09-23 05:01:50 --> Input Class Initialized
INFO - 2025-09-23 05:01:50 --> Language Class Initialized
INFO - 2025-09-23 05:01:50 --> Loader Class Initialized
INFO - 2025-09-23 05:01:50 --> Helper loaded: url_helper
INFO - 2025-09-23 05:01:50 --> Helper loaded: text_helper
INFO - 2025-09-23 05:01:50 --> Helper loaded: string_helper
INFO - 2025-09-23 05:01:50 --> Helper loaded: form_helper
INFO - 2025-09-23 05:01:50 --> Helper loaded: download_helper
INFO - 2025-09-23 05:01:50 --> Helper loaded: security_helper
INFO - 2025-09-23 05:01:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:01:50 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:01:50 --> Form Validation Class Initialized
INFO - 2025-09-23 05:01:50 --> Model "User_model" initialized
INFO - 2025-09-23 10:01:50 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:01:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:01:50 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:01:50 --> Controller Class Initialized
INFO - 2025-09-23 10:01:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\kebijakan-cookies.php
INFO - 2025-09-23 10:01:50 --> Model "Log_model" initialized
INFO - 2025-09-23 10:01:50 --> Final output sent to browser
DEBUG - 2025-09-23 10:01:50 --> Total execution time: 0.0581
INFO - 2025-09-23 05:02:02 --> Config Class Initialized
INFO - 2025-09-23 05:02:02 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:02:02 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:02:02 --> Utf8 Class Initialized
INFO - 2025-09-23 05:02:02 --> URI Class Initialized
DEBUG - 2025-09-23 05:02:02 --> No URI present. Default controller set.
INFO - 2025-09-23 05:02:02 --> Router Class Initialized
INFO - 2025-09-23 05:02:02 --> Output Class Initialized
INFO - 2025-09-23 05:02:02 --> Security Class Initialized
DEBUG - 2025-09-23 05:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:02:02 --> CSRF cookie sent
INFO - 2025-09-23 05:02:02 --> Input Class Initialized
INFO - 2025-09-23 05:02:02 --> Language Class Initialized
INFO - 2025-09-23 05:02:02 --> Loader Class Initialized
INFO - 2025-09-23 05:02:02 --> Helper loaded: url_helper
INFO - 2025-09-23 05:02:02 --> Helper loaded: text_helper
INFO - 2025-09-23 05:02:02 --> Helper loaded: string_helper
INFO - 2025-09-23 05:02:02 --> Helper loaded: form_helper
INFO - 2025-09-23 05:02:02 --> Helper loaded: download_helper
INFO - 2025-09-23 05:02:02 --> Helper loaded: security_helper
INFO - 2025-09-23 05:02:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:02:02 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:02:02 --> Form Validation Class Initialized
INFO - 2025-09-23 05:02:02 --> Model "User_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:02:02 --> Controller Class Initialized
INFO - 2025-09-23 10:02:02 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Video_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:02:02 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:02:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:02:02 --> Pagination Class Initialized
INFO - 2025-09-23 10:02:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:02:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:02:02 --> Model "Log_model" initialized
INFO - 2025-09-23 10:02:02 --> Final output sent to browser
DEBUG - 2025-09-23 10:02:02 --> Total execution time: 0.1207
INFO - 2025-09-23 05:04:44 --> Config Class Initialized
INFO - 2025-09-23 05:04:44 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:04:44 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:04:44 --> Utf8 Class Initialized
INFO - 2025-09-23 05:04:44 --> URI Class Initialized
INFO - 2025-09-23 05:04:44 --> Router Class Initialized
INFO - 2025-09-23 05:04:44 --> Output Class Initialized
INFO - 2025-09-23 05:04:44 --> Security Class Initialized
DEBUG - 2025-09-23 05:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:04:44 --> CSRF cookie sent
INFO - 2025-09-23 05:04:44 --> Input Class Initialized
INFO - 2025-09-23 05:04:45 --> Language Class Initialized
INFO - 2025-09-23 05:04:45 --> Loader Class Initialized
INFO - 2025-09-23 05:04:45 --> Helper loaded: url_helper
INFO - 2025-09-23 05:04:45 --> Helper loaded: text_helper
INFO - 2025-09-23 05:04:45 --> Helper loaded: string_helper
INFO - 2025-09-23 05:04:45 --> Helper loaded: form_helper
INFO - 2025-09-23 05:04:45 --> Helper loaded: download_helper
INFO - 2025-09-23 05:04:45 --> Helper loaded: security_helper
INFO - 2025-09-23 05:04:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:04:45 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:04:45 --> Form Validation Class Initialized
INFO - 2025-09-23 05:04:45 --> Model "User_model" initialized
INFO - 2025-09-23 10:04:45 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:04:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:04:45 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:04:45 --> Controller Class Initialized
INFO - 2025-09-23 10:04:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\kebijakan-cookies.php
INFO - 2025-09-23 10:04:45 --> Model "Log_model" initialized
INFO - 2025-09-23 10:04:45 --> Final output sent to browser
DEBUG - 2025-09-23 10:04:45 --> Total execution time: 0.0502
INFO - 2025-09-23 05:04:49 --> Config Class Initialized
INFO - 2025-09-23 05:04:49 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:04:49 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:04:49 --> Utf8 Class Initialized
INFO - 2025-09-23 05:04:49 --> URI Class Initialized
DEBUG - 2025-09-23 05:04:49 --> No URI present. Default controller set.
INFO - 2025-09-23 05:04:49 --> Router Class Initialized
INFO - 2025-09-23 05:04:49 --> Output Class Initialized
INFO - 2025-09-23 05:04:49 --> Security Class Initialized
DEBUG - 2025-09-23 05:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:04:49 --> CSRF cookie sent
INFO - 2025-09-23 05:04:49 --> Input Class Initialized
INFO - 2025-09-23 05:04:49 --> Language Class Initialized
INFO - 2025-09-23 05:04:49 --> Loader Class Initialized
INFO - 2025-09-23 05:04:49 --> Helper loaded: url_helper
INFO - 2025-09-23 05:04:49 --> Helper loaded: text_helper
INFO - 2025-09-23 05:04:49 --> Helper loaded: string_helper
INFO - 2025-09-23 05:04:49 --> Helper loaded: form_helper
INFO - 2025-09-23 05:04:49 --> Helper loaded: download_helper
INFO - 2025-09-23 05:04:49 --> Helper loaded: security_helper
INFO - 2025-09-23 05:04:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:04:49 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:04:49 --> Form Validation Class Initialized
INFO - 2025-09-23 05:04:49 --> Model "User_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:04:49 --> Controller Class Initialized
INFO - 2025-09-23 10:04:49 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Video_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:04:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:04:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:04:49 --> Pagination Class Initialized
INFO - 2025-09-23 10:04:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:04:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:04:49 --> Model "Log_model" initialized
INFO - 2025-09-23 10:04:49 --> Final output sent to browser
DEBUG - 2025-09-23 10:04:49 --> Total execution time: 0.0960
INFO - 2025-09-23 05:21:26 --> Config Class Initialized
INFO - 2025-09-23 05:21:26 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:21:26 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:21:26 --> Utf8 Class Initialized
INFO - 2025-09-23 05:21:26 --> URI Class Initialized
DEBUG - 2025-09-23 05:21:26 --> No URI present. Default controller set.
INFO - 2025-09-23 05:21:26 --> Router Class Initialized
INFO - 2025-09-23 05:21:26 --> Output Class Initialized
INFO - 2025-09-23 05:21:26 --> Security Class Initialized
DEBUG - 2025-09-23 05:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:21:26 --> CSRF cookie sent
INFO - 2025-09-23 05:21:26 --> Input Class Initialized
INFO - 2025-09-23 05:21:26 --> Language Class Initialized
INFO - 2025-09-23 05:21:26 --> Loader Class Initialized
INFO - 2025-09-23 05:21:26 --> Helper loaded: url_helper
INFO - 2025-09-23 05:21:26 --> Helper loaded: text_helper
INFO - 2025-09-23 05:21:26 --> Helper loaded: string_helper
INFO - 2025-09-23 05:21:26 --> Helper loaded: form_helper
INFO - 2025-09-23 05:21:26 --> Helper loaded: download_helper
INFO - 2025-09-23 05:21:26 --> Helper loaded: security_helper
INFO - 2025-09-23 05:21:26 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:21:26 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:21:26 --> Form Validation Class Initialized
INFO - 2025-09-23 05:21:26 --> Model "User_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:21:26 --> Controller Class Initialized
INFO - 2025-09-23 10:21:26 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Video_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:21:26 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:21:26 --> Pagination Class Initialized
INFO - 2025-09-23 10:21:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:21:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:21:26 --> Model "Log_model" initialized
INFO - 2025-09-23 10:21:26 --> Final output sent to browser
DEBUG - 2025-09-23 10:21:26 --> Total execution time: 0.1514
INFO - 2025-09-23 05:21:59 --> Config Class Initialized
INFO - 2025-09-23 05:21:59 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:21:59 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:21:59 --> Utf8 Class Initialized
INFO - 2025-09-23 05:21:59 --> URI Class Initialized
DEBUG - 2025-09-23 05:21:59 --> No URI present. Default controller set.
INFO - 2025-09-23 05:21:59 --> Router Class Initialized
INFO - 2025-09-23 05:21:59 --> Output Class Initialized
INFO - 2025-09-23 05:21:59 --> Security Class Initialized
DEBUG - 2025-09-23 05:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:21:59 --> CSRF cookie sent
INFO - 2025-09-23 05:21:59 --> Input Class Initialized
INFO - 2025-09-23 05:21:59 --> Language Class Initialized
INFO - 2025-09-23 05:21:59 --> Loader Class Initialized
INFO - 2025-09-23 05:21:59 --> Helper loaded: url_helper
INFO - 2025-09-23 05:21:59 --> Helper loaded: text_helper
INFO - 2025-09-23 05:21:59 --> Helper loaded: string_helper
INFO - 2025-09-23 05:21:59 --> Helper loaded: form_helper
INFO - 2025-09-23 05:21:59 --> Helper loaded: download_helper
INFO - 2025-09-23 05:21:59 --> Helper loaded: security_helper
INFO - 2025-09-23 05:21:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:21:59 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:21:59 --> Form Validation Class Initialized
INFO - 2025-09-23 05:21:59 --> Model "User_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:21:59 --> Controller Class Initialized
INFO - 2025-09-23 10:21:59 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Video_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:21:59 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:21:59 --> Pagination Class Initialized
INFO - 2025-09-23 10:21:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:21:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:21:59 --> Model "Log_model" initialized
INFO - 2025-09-23 10:21:59 --> Final output sent to browser
DEBUG - 2025-09-23 10:21:59 --> Total execution time: 0.2145
INFO - 2025-09-23 05:22:20 --> Config Class Initialized
INFO - 2025-09-23 05:22:20 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:22:20 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:22:20 --> Utf8 Class Initialized
INFO - 2025-09-23 05:22:20 --> URI Class Initialized
DEBUG - 2025-09-23 05:22:20 --> No URI present. Default controller set.
INFO - 2025-09-23 05:22:20 --> Router Class Initialized
INFO - 2025-09-23 05:22:20 --> Output Class Initialized
INFO - 2025-09-23 05:22:20 --> Security Class Initialized
DEBUG - 2025-09-23 05:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:22:20 --> CSRF cookie sent
INFO - 2025-09-23 05:22:20 --> Input Class Initialized
INFO - 2025-09-23 05:22:20 --> Language Class Initialized
INFO - 2025-09-23 05:22:20 --> Loader Class Initialized
INFO - 2025-09-23 05:22:20 --> Helper loaded: url_helper
INFO - 2025-09-23 05:22:20 --> Helper loaded: text_helper
INFO - 2025-09-23 05:22:20 --> Helper loaded: string_helper
INFO - 2025-09-23 05:22:20 --> Helper loaded: form_helper
INFO - 2025-09-23 05:22:20 --> Helper loaded: download_helper
INFO - 2025-09-23 05:22:20 --> Helper loaded: security_helper
INFO - 2025-09-23 05:22:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:22:20 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:22:20 --> Form Validation Class Initialized
INFO - 2025-09-23 05:22:20 --> Model "User_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:22:20 --> Controller Class Initialized
INFO - 2025-09-23 10:22:20 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Video_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:22:20 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:22:20 --> Pagination Class Initialized
INFO - 2025-09-23 10:22:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:22:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:22:20 --> Model "Log_model" initialized
INFO - 2025-09-23 10:22:20 --> Final output sent to browser
DEBUG - 2025-09-23 10:22:20 --> Total execution time: 0.1951
INFO - 2025-09-23 05:22:42 --> Config Class Initialized
INFO - 2025-09-23 05:22:42 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:22:42 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:22:42 --> Utf8 Class Initialized
INFO - 2025-09-23 05:22:42 --> URI Class Initialized
DEBUG - 2025-09-23 05:22:42 --> No URI present. Default controller set.
INFO - 2025-09-23 05:22:42 --> Router Class Initialized
INFO - 2025-09-23 05:22:42 --> Output Class Initialized
INFO - 2025-09-23 05:22:42 --> Security Class Initialized
DEBUG - 2025-09-23 05:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:22:42 --> CSRF cookie sent
INFO - 2025-09-23 05:22:42 --> Input Class Initialized
INFO - 2025-09-23 05:22:42 --> Language Class Initialized
INFO - 2025-09-23 05:22:42 --> Loader Class Initialized
INFO - 2025-09-23 05:22:42 --> Helper loaded: url_helper
INFO - 2025-09-23 05:22:42 --> Helper loaded: text_helper
INFO - 2025-09-23 05:22:42 --> Helper loaded: string_helper
INFO - 2025-09-23 05:22:42 --> Helper loaded: form_helper
INFO - 2025-09-23 05:22:42 --> Helper loaded: download_helper
INFO - 2025-09-23 05:22:42 --> Helper loaded: security_helper
INFO - 2025-09-23 05:22:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:22:42 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:22:42 --> Form Validation Class Initialized
INFO - 2025-09-23 05:22:42 --> Model "User_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:22:42 --> Controller Class Initialized
INFO - 2025-09-23 10:22:42 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Video_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:22:42 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:22:42 --> Pagination Class Initialized
INFO - 2025-09-23 10:22:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:22:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:22:42 --> Model "Log_model" initialized
INFO - 2025-09-23 10:22:42 --> Final output sent to browser
DEBUG - 2025-09-23 10:22:42 --> Total execution time: 0.1716
INFO - 2025-09-23 05:22:49 --> Config Class Initialized
INFO - 2025-09-23 05:22:49 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:22:49 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:22:49 --> Utf8 Class Initialized
INFO - 2025-09-23 05:22:49 --> URI Class Initialized
DEBUG - 2025-09-23 05:22:49 --> No URI present. Default controller set.
INFO - 2025-09-23 05:22:49 --> Router Class Initialized
INFO - 2025-09-23 05:22:49 --> Output Class Initialized
INFO - 2025-09-23 05:22:49 --> Security Class Initialized
DEBUG - 2025-09-23 05:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:22:49 --> CSRF cookie sent
INFO - 2025-09-23 05:22:49 --> Input Class Initialized
INFO - 2025-09-23 05:22:49 --> Language Class Initialized
INFO - 2025-09-23 05:22:49 --> Loader Class Initialized
INFO - 2025-09-23 05:22:49 --> Helper loaded: url_helper
INFO - 2025-09-23 05:22:49 --> Helper loaded: text_helper
INFO - 2025-09-23 05:22:49 --> Helper loaded: string_helper
INFO - 2025-09-23 05:22:49 --> Helper loaded: form_helper
INFO - 2025-09-23 05:22:49 --> Helper loaded: download_helper
INFO - 2025-09-23 05:22:49 --> Helper loaded: security_helper
INFO - 2025-09-23 05:22:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:22:49 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:22:49 --> Form Validation Class Initialized
INFO - 2025-09-23 05:22:49 --> Model "User_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:22:49 --> Controller Class Initialized
INFO - 2025-09-23 10:22:49 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Video_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:22:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:22:49 --> Pagination Class Initialized
INFO - 2025-09-23 10:22:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:22:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:22:49 --> Model "Log_model" initialized
INFO - 2025-09-23 10:22:49 --> Final output sent to browser
DEBUG - 2025-09-23 10:22:49 --> Total execution time: 0.1858
INFO - 2025-09-23 05:23:02 --> Config Class Initialized
INFO - 2025-09-23 05:23:02 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:23:02 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:23:02 --> Utf8 Class Initialized
INFO - 2025-09-23 05:23:02 --> URI Class Initialized
DEBUG - 2025-09-23 05:23:02 --> No URI present. Default controller set.
INFO - 2025-09-23 05:23:02 --> Router Class Initialized
INFO - 2025-09-23 05:23:02 --> Output Class Initialized
INFO - 2025-09-23 05:23:02 --> Security Class Initialized
DEBUG - 2025-09-23 05:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:23:02 --> CSRF cookie sent
INFO - 2025-09-23 05:23:02 --> Input Class Initialized
INFO - 2025-09-23 05:23:02 --> Language Class Initialized
INFO - 2025-09-23 05:23:02 --> Loader Class Initialized
INFO - 2025-09-23 05:23:02 --> Helper loaded: url_helper
INFO - 2025-09-23 05:23:02 --> Helper loaded: text_helper
INFO - 2025-09-23 05:23:02 --> Helper loaded: string_helper
INFO - 2025-09-23 05:23:02 --> Helper loaded: form_helper
INFO - 2025-09-23 05:23:02 --> Helper loaded: download_helper
INFO - 2025-09-23 05:23:02 --> Helper loaded: security_helper
INFO - 2025-09-23 05:23:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:23:02 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:23:02 --> Form Validation Class Initialized
INFO - 2025-09-23 05:23:02 --> Model "User_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:23:02 --> Controller Class Initialized
INFO - 2025-09-23 10:23:02 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Video_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:23:02 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:23:02 --> Pagination Class Initialized
INFO - 2025-09-23 10:23:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:23:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:23:02 --> Model "Log_model" initialized
INFO - 2025-09-23 10:23:02 --> Final output sent to browser
DEBUG - 2025-09-23 10:23:02 --> Total execution time: 0.1296
INFO - 2025-09-23 05:23:04 --> Config Class Initialized
INFO - 2025-09-23 05:23:04 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:23:04 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:23:04 --> Utf8 Class Initialized
INFO - 2025-09-23 05:23:04 --> URI Class Initialized
DEBUG - 2025-09-23 05:23:04 --> No URI present. Default controller set.
INFO - 2025-09-23 05:23:04 --> Router Class Initialized
INFO - 2025-09-23 05:23:04 --> Output Class Initialized
INFO - 2025-09-23 05:23:04 --> Security Class Initialized
DEBUG - 2025-09-23 05:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:23:04 --> CSRF cookie sent
INFO - 2025-09-23 05:23:04 --> Input Class Initialized
INFO - 2025-09-23 05:23:04 --> Language Class Initialized
INFO - 2025-09-23 05:23:04 --> Loader Class Initialized
INFO - 2025-09-23 05:23:04 --> Helper loaded: url_helper
INFO - 2025-09-23 05:23:04 --> Helper loaded: text_helper
INFO - 2025-09-23 05:23:04 --> Helper loaded: string_helper
INFO - 2025-09-23 05:23:04 --> Helper loaded: form_helper
INFO - 2025-09-23 05:23:04 --> Helper loaded: download_helper
INFO - 2025-09-23 05:23:04 --> Helper loaded: security_helper
INFO - 2025-09-23 05:23:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:23:04 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:23:04 --> Form Validation Class Initialized
INFO - 2025-09-23 05:23:04 --> Model "User_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:23:04 --> Controller Class Initialized
INFO - 2025-09-23 10:23:04 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Video_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:23:04 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:23:04 --> Pagination Class Initialized
INFO - 2025-09-23 10:23:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:23:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:23:04 --> Model "Log_model" initialized
INFO - 2025-09-23 10:23:04 --> Final output sent to browser
DEBUG - 2025-09-23 10:23:04 --> Total execution time: 0.1526
INFO - 2025-09-23 05:40:30 --> Config Class Initialized
INFO - 2025-09-23 05:40:30 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:40:30 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:40:30 --> Utf8 Class Initialized
INFO - 2025-09-23 05:40:30 --> URI Class Initialized
DEBUG - 2025-09-23 05:40:30 --> No URI present. Default controller set.
INFO - 2025-09-23 05:40:30 --> Router Class Initialized
INFO - 2025-09-23 05:40:30 --> Output Class Initialized
INFO - 2025-09-23 05:40:30 --> Security Class Initialized
DEBUG - 2025-09-23 05:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:40:30 --> CSRF cookie sent
INFO - 2025-09-23 05:40:30 --> Input Class Initialized
INFO - 2025-09-23 05:40:30 --> Language Class Initialized
INFO - 2025-09-23 05:40:30 --> Loader Class Initialized
INFO - 2025-09-23 05:40:30 --> Helper loaded: url_helper
INFO - 2025-09-23 05:40:30 --> Helper loaded: text_helper
INFO - 2025-09-23 05:40:30 --> Helper loaded: string_helper
INFO - 2025-09-23 05:40:30 --> Helper loaded: form_helper
INFO - 2025-09-23 05:40:30 --> Helper loaded: download_helper
INFO - 2025-09-23 05:40:30 --> Helper loaded: security_helper
INFO - 2025-09-23 05:40:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:40:30 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:40:30 --> Form Validation Class Initialized
INFO - 2025-09-23 05:40:30 --> Model "User_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:40:30 --> Controller Class Initialized
INFO - 2025-09-23 10:40:30 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Video_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:40:30 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:40:30 --> Pagination Class Initialized
INFO - 2025-09-23 10:40:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:40:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:40:30 --> Model "Log_model" initialized
INFO - 2025-09-23 10:40:30 --> Final output sent to browser
DEBUG - 2025-09-23 10:40:30 --> Total execution time: 0.1055
INFO - 2025-09-23 05:40:33 --> Config Class Initialized
INFO - 2025-09-23 05:40:33 --> Hooks Class Initialized
DEBUG - 2025-09-23 05:40:33 --> UTF-8 Support Enabled
INFO - 2025-09-23 05:40:33 --> Utf8 Class Initialized
INFO - 2025-09-23 05:40:33 --> URI Class Initialized
DEBUG - 2025-09-23 05:40:33 --> No URI present. Default controller set.
INFO - 2025-09-23 05:40:33 --> Router Class Initialized
INFO - 2025-09-23 05:40:33 --> Output Class Initialized
INFO - 2025-09-23 05:40:33 --> Security Class Initialized
DEBUG - 2025-09-23 05:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 05:40:33 --> CSRF cookie sent
INFO - 2025-09-23 05:40:33 --> Input Class Initialized
INFO - 2025-09-23 05:40:33 --> Language Class Initialized
INFO - 2025-09-23 05:40:33 --> Loader Class Initialized
INFO - 2025-09-23 05:40:33 --> Helper loaded: url_helper
INFO - 2025-09-23 05:40:33 --> Helper loaded: text_helper
INFO - 2025-09-23 05:40:33 --> Helper loaded: string_helper
INFO - 2025-09-23 05:40:33 --> Helper loaded: form_helper
INFO - 2025-09-23 05:40:33 --> Helper loaded: download_helper
INFO - 2025-09-23 05:40:33 --> Helper loaded: security_helper
INFO - 2025-09-23 05:40:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 05:40:33 --> Database Driver Class Initialized
DEBUG - 2025-09-23 05:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 05:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 05:40:33 --> Form Validation Class Initialized
INFO - 2025-09-23 05:40:33 --> Model "User_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Nav_model" initialized
INFO - 2025-09-23 10:40:33 --> Controller Class Initialized
INFO - 2025-09-23 10:40:33 --> Model "Berita_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Galeri_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Video_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Agenda_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Tautan_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Mitra_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Prodi_model" initialized
INFO - 2025-09-23 10:40:33 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 10:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 10:40:33 --> Pagination Class Initialized
INFO - 2025-09-23 10:40:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 10:40:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 10:40:33 --> Model "Log_model" initialized
INFO - 2025-09-23 10:40:33 --> Final output sent to browser
DEBUG - 2025-09-23 10:40:33 --> Total execution time: 0.1334
INFO - 2025-09-23 06:10:17 --> Config Class Initialized
INFO - 2025-09-23 06:10:17 --> Hooks Class Initialized
DEBUG - 2025-09-23 06:10:17 --> UTF-8 Support Enabled
INFO - 2025-09-23 06:10:17 --> Utf8 Class Initialized
INFO - 2025-09-23 06:10:17 --> URI Class Initialized
INFO - 2025-09-23 06:10:17 --> Router Class Initialized
INFO - 2025-09-23 06:10:17 --> Output Class Initialized
INFO - 2025-09-23 06:10:17 --> Security Class Initialized
DEBUG - 2025-09-23 06:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 06:10:17 --> CSRF cookie sent
INFO - 2025-09-23 06:10:17 --> Input Class Initialized
INFO - 2025-09-23 06:10:17 --> Language Class Initialized
INFO - 2025-09-23 06:10:17 --> Loader Class Initialized
INFO - 2025-09-23 06:10:17 --> Helper loaded: url_helper
INFO - 2025-09-23 06:10:17 --> Helper loaded: text_helper
INFO - 2025-09-23 06:10:17 --> Helper loaded: string_helper
INFO - 2025-09-23 06:10:17 --> Helper loaded: form_helper
INFO - 2025-09-23 06:10:17 --> Helper loaded: download_helper
INFO - 2025-09-23 06:10:17 --> Helper loaded: security_helper
INFO - 2025-09-23 06:10:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 06:10:17 --> Database Driver Class Initialized
DEBUG - 2025-09-23 06:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 06:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 06:10:17 --> Form Validation Class Initialized
INFO - 2025-09-23 06:10:17 --> Model "User_model" initialized
INFO - 2025-09-23 11:10:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 11:10:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 11:10:17 --> Model "Nav_model" initialized
INFO - 2025-09-23 11:10:17 --> Controller Class Initialized
INFO - 2025-09-23 11:10:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\kebijakan-cookies.php
INFO - 2025-09-23 11:10:17 --> Model "Log_model" initialized
INFO - 2025-09-23 11:10:17 --> Final output sent to browser
DEBUG - 2025-09-23 11:10:17 --> Total execution time: 0.0714
INFO - 2025-09-23 06:10:20 --> Config Class Initialized
INFO - 2025-09-23 06:10:20 --> Hooks Class Initialized
DEBUG - 2025-09-23 06:10:20 --> UTF-8 Support Enabled
INFO - 2025-09-23 06:10:20 --> Utf8 Class Initialized
INFO - 2025-09-23 06:10:20 --> URI Class Initialized
DEBUG - 2025-09-23 06:10:20 --> No URI present. Default controller set.
INFO - 2025-09-23 06:10:20 --> Router Class Initialized
INFO - 2025-09-23 06:10:20 --> Output Class Initialized
INFO - 2025-09-23 06:10:20 --> Security Class Initialized
DEBUG - 2025-09-23 06:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 06:10:20 --> CSRF cookie sent
INFO - 2025-09-23 06:10:20 --> Input Class Initialized
INFO - 2025-09-23 06:10:20 --> Language Class Initialized
INFO - 2025-09-23 06:10:20 --> Loader Class Initialized
INFO - 2025-09-23 06:10:20 --> Helper loaded: url_helper
INFO - 2025-09-23 06:10:20 --> Helper loaded: text_helper
INFO - 2025-09-23 06:10:20 --> Helper loaded: string_helper
INFO - 2025-09-23 06:10:20 --> Helper loaded: form_helper
INFO - 2025-09-23 06:10:20 --> Helper loaded: download_helper
INFO - 2025-09-23 06:10:20 --> Helper loaded: security_helper
INFO - 2025-09-23 06:10:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 06:10:20 --> Database Driver Class Initialized
DEBUG - 2025-09-23 06:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 06:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 06:10:20 --> Form Validation Class Initialized
INFO - 2025-09-23 06:10:20 --> Model "User_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Nav_model" initialized
INFO - 2025-09-23 11:10:20 --> Controller Class Initialized
INFO - 2025-09-23 11:10:20 --> Model "Berita_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Galeri_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Video_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Agenda_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Tautan_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Mitra_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Prodi_model" initialized
INFO - 2025-09-23 11:10:20 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 11:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 11:10:20 --> Pagination Class Initialized
INFO - 2025-09-23 11:10:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 11:10:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 11:10:20 --> Model "Log_model" initialized
INFO - 2025-09-23 11:10:20 --> Final output sent to browser
DEBUG - 2025-09-23 11:10:20 --> Total execution time: 0.1187
INFO - 2025-09-23 06:12:16 --> Config Class Initialized
INFO - 2025-09-23 06:12:16 --> Hooks Class Initialized
DEBUG - 2025-09-23 06:12:16 --> UTF-8 Support Enabled
INFO - 2025-09-23 06:12:16 --> Utf8 Class Initialized
INFO - 2025-09-23 06:12:16 --> URI Class Initialized
DEBUG - 2025-09-23 06:12:16 --> No URI present. Default controller set.
INFO - 2025-09-23 06:12:16 --> Router Class Initialized
INFO - 2025-09-23 06:12:16 --> Output Class Initialized
INFO - 2025-09-23 06:12:16 --> Security Class Initialized
DEBUG - 2025-09-23 06:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 06:12:16 --> CSRF cookie sent
INFO - 2025-09-23 06:12:16 --> Input Class Initialized
INFO - 2025-09-23 06:12:16 --> Language Class Initialized
INFO - 2025-09-23 06:12:16 --> Loader Class Initialized
INFO - 2025-09-23 06:12:16 --> Helper loaded: url_helper
INFO - 2025-09-23 06:12:16 --> Helper loaded: text_helper
INFO - 2025-09-23 06:12:16 --> Helper loaded: string_helper
INFO - 2025-09-23 06:12:16 --> Helper loaded: form_helper
INFO - 2025-09-23 06:12:16 --> Helper loaded: download_helper
INFO - 2025-09-23 06:12:16 --> Helper loaded: security_helper
INFO - 2025-09-23 06:12:16 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 06:12:16 --> Database Driver Class Initialized
DEBUG - 2025-09-23 06:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 06:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 06:12:16 --> Form Validation Class Initialized
INFO - 2025-09-23 06:12:16 --> Model "User_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Nav_model" initialized
INFO - 2025-09-23 11:12:16 --> Controller Class Initialized
INFO - 2025-09-23 11:12:16 --> Model "Berita_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Galeri_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Video_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Agenda_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Tautan_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Mitra_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Prodi_model" initialized
INFO - 2025-09-23 11:12:16 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 11:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 11:12:16 --> Pagination Class Initialized
INFO - 2025-09-23 11:12:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 11:12:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 11:12:16 --> Model "Log_model" initialized
INFO - 2025-09-23 11:12:16 --> Final output sent to browser
DEBUG - 2025-09-23 11:12:16 --> Total execution time: 0.0857
INFO - 2025-09-23 06:12:29 --> Config Class Initialized
INFO - 2025-09-23 06:12:29 --> Hooks Class Initialized
DEBUG - 2025-09-23 06:12:29 --> UTF-8 Support Enabled
INFO - 2025-09-23 06:12:29 --> Utf8 Class Initialized
INFO - 2025-09-23 06:12:29 --> URI Class Initialized
DEBUG - 2025-09-23 06:12:29 --> No URI present. Default controller set.
INFO - 2025-09-23 06:12:29 --> Router Class Initialized
INFO - 2025-09-23 06:12:29 --> Output Class Initialized
INFO - 2025-09-23 06:12:29 --> Security Class Initialized
DEBUG - 2025-09-23 06:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 06:12:29 --> CSRF cookie sent
INFO - 2025-09-23 06:12:29 --> Input Class Initialized
INFO - 2025-09-23 06:12:29 --> Language Class Initialized
INFO - 2025-09-23 06:12:29 --> Loader Class Initialized
INFO - 2025-09-23 06:12:29 --> Helper loaded: url_helper
INFO - 2025-09-23 06:12:29 --> Helper loaded: text_helper
INFO - 2025-09-23 06:12:29 --> Helper loaded: string_helper
INFO - 2025-09-23 06:12:29 --> Helper loaded: form_helper
INFO - 2025-09-23 06:12:29 --> Helper loaded: download_helper
INFO - 2025-09-23 06:12:29 --> Helper loaded: security_helper
INFO - 2025-09-23 06:12:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 06:12:29 --> Database Driver Class Initialized
DEBUG - 2025-09-23 06:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 06:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 06:12:29 --> Form Validation Class Initialized
INFO - 2025-09-23 06:12:29 --> Model "User_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Nav_model" initialized
INFO - 2025-09-23 11:12:29 --> Controller Class Initialized
INFO - 2025-09-23 11:12:29 --> Model "Berita_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Galeri_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Video_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Agenda_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Tautan_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Mitra_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Prodi_model" initialized
INFO - 2025-09-23 11:12:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 11:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 11:12:29 --> Pagination Class Initialized
INFO - 2025-09-23 11:12:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 11:12:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 11:12:29 --> Model "Log_model" initialized
INFO - 2025-09-23 11:12:29 --> Final output sent to browser
DEBUG - 2025-09-23 11:12:29 --> Total execution time: 0.1910
INFO - 2025-09-23 06:12:32 --> Config Class Initialized
INFO - 2025-09-23 06:12:32 --> Hooks Class Initialized
DEBUG - 2025-09-23 06:12:32 --> UTF-8 Support Enabled
INFO - 2025-09-23 06:12:32 --> Utf8 Class Initialized
INFO - 2025-09-23 06:12:32 --> URI Class Initialized
DEBUG - 2025-09-23 06:12:32 --> No URI present. Default controller set.
INFO - 2025-09-23 06:12:32 --> Router Class Initialized
INFO - 2025-09-23 06:12:32 --> Output Class Initialized
INFO - 2025-09-23 06:12:32 --> Security Class Initialized
DEBUG - 2025-09-23 06:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-23 06:12:32 --> CSRF cookie sent
INFO - 2025-09-23 06:12:32 --> Input Class Initialized
INFO - 2025-09-23 06:12:32 --> Language Class Initialized
INFO - 2025-09-23 06:12:32 --> Loader Class Initialized
INFO - 2025-09-23 06:12:32 --> Helper loaded: url_helper
INFO - 2025-09-23 06:12:32 --> Helper loaded: text_helper
INFO - 2025-09-23 06:12:32 --> Helper loaded: string_helper
INFO - 2025-09-23 06:12:32 --> Helper loaded: form_helper
INFO - 2025-09-23 06:12:32 --> Helper loaded: download_helper
INFO - 2025-09-23 06:12:32 --> Helper loaded: security_helper
INFO - 2025-09-23 06:12:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-23 06:12:32 --> Database Driver Class Initialized
DEBUG - 2025-09-23 06:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-23 06:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-23 06:12:32 --> Form Validation Class Initialized
INFO - 2025-09-23 06:12:32 --> Model "User_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Kunjungan_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Nav_model" initialized
INFO - 2025-09-23 11:12:32 --> Controller Class Initialized
INFO - 2025-09-23 11:12:32 --> Model "Berita_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Galeri_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Video_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Agenda_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Tautan_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Mitra_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Jurusan_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Prodi_model" initialized
INFO - 2025-09-23 11:12:32 --> Model "Testimoni_model" initialized
INFO - 2025-09-23 11:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-23 11:12:32 --> Pagination Class Initialized
INFO - 2025-09-23 11:12:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-23 11:12:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-23 11:12:32 --> Model "Log_model" initialized
INFO - 2025-09-23 11:12:32 --> Final output sent to browser
DEBUG - 2025-09-23 11:12:32 --> Total execution time: 0.1677
