<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-06 06:10:04 --> Config Class Initialized
INFO - 2025-10-06 06:10:04 --> Hooks Class Initialized
DEBUG - 2025-10-06 06:10:05 --> UTF-8 Support Enabled
INFO - 2025-10-06 06:10:05 --> Utf8 Class Initialized
INFO - 2025-10-06 06:10:05 --> URI Class Initialized
DEBUG - 2025-10-06 06:10:05 --> No URI present. Default controller set.
INFO - 2025-10-06 06:10:05 --> Router Class Initialized
INFO - 2025-10-06 06:10:05 --> Output Class Initialized
INFO - 2025-10-06 06:10:05 --> Security Class Initialized
DEBUG - 2025-10-06 06:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-06 06:10:05 --> CSRF cookie sent
INFO - 2025-10-06 06:10:05 --> Input Class Initialized
INFO - 2025-10-06 06:10:05 --> Language Class Initialized
INFO - 2025-10-06 06:10:06 --> Loader Class Initialized
INFO - 2025-10-06 06:10:06 --> Helper loaded: url_helper
INFO - 2025-10-06 06:10:06 --> Helper loaded: text_helper
INFO - 2025-10-06 06:10:06 --> Helper loaded: string_helper
INFO - 2025-10-06 06:10:06 --> Helper loaded: form_helper
INFO - 2025-10-06 06:10:06 --> Helper loaded: download_helper
INFO - 2025-10-06 06:10:06 --> Helper loaded: security_helper
INFO - 2025-10-06 06:10:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-06 06:10:06 --> Database Driver Class Initialized
DEBUG - 2025-10-06 06:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-06 06:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-06 06:10:07 --> Form Validation Class Initialized
INFO - 2025-10-06 06:10:07 --> Model "User_model" initialized
INFO - 2025-10-06 11:10:08 --> Model "Kunjungan_model" initialized
INFO - 2025-10-06 11:10:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-06 11:10:08 --> Model "Nav_model" initialized
INFO - 2025-10-06 11:10:08 --> Controller Class Initialized
INFO - 2025-10-06 11:10:08 --> Model "Berita_model" initialized
INFO - 2025-10-06 11:10:08 --> Model "Galeri_model" initialized
INFO - 2025-10-06 11:10:08 --> Model "Video_model" initialized
INFO - 2025-10-06 11:10:09 --> Model "Agenda_model" initialized
INFO - 2025-10-06 11:10:09 --> Model "Tautan_model" initialized
INFO - 2025-10-06 11:10:09 --> Model "Mitra_model" initialized
INFO - 2025-10-06 11:10:09 --> Model "Jurusan_model" initialized
INFO - 2025-10-06 11:10:09 --> Model "Prodi_model" initialized
INFO - 2025-10-06 11:10:09 --> Model "Testimoni_model" initialized
INFO - 2025-10-06 11:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-06 11:10:10 --> Pagination Class Initialized
INFO - 2025-10-06 11:10:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-06 11:10:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-06 11:10:13 --> Model "Log_model" initialized
INFO - 2025-10-06 11:10:13 --> Final output sent to browser
DEBUG - 2025-10-06 11:10:13 --> Total execution time: 9.5456
INFO - 2025-10-06 06:10:28 --> Config Class Initialized
INFO - 2025-10-06 06:10:28 --> Hooks Class Initialized
DEBUG - 2025-10-06 06:10:28 --> UTF-8 Support Enabled
INFO - 2025-10-06 06:10:28 --> Utf8 Class Initialized
INFO - 2025-10-06 06:10:28 --> URI Class Initialized
INFO - 2025-10-06 06:10:28 --> Router Class Initialized
INFO - 2025-10-06 06:10:28 --> Output Class Initialized
INFO - 2025-10-06 06:10:28 --> Security Class Initialized
DEBUG - 2025-10-06 06:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-06 06:10:28 --> CSRF cookie sent
INFO - 2025-10-06 06:10:28 --> Input Class Initialized
INFO - 2025-10-06 06:10:28 --> Language Class Initialized
INFO - 2025-10-06 06:10:28 --> Loader Class Initialized
INFO - 2025-10-06 06:10:28 --> Helper loaded: url_helper
INFO - 2025-10-06 06:10:28 --> Helper loaded: text_helper
INFO - 2025-10-06 06:10:28 --> Helper loaded: string_helper
INFO - 2025-10-06 06:10:28 --> Helper loaded: form_helper
INFO - 2025-10-06 06:10:28 --> Helper loaded: download_helper
INFO - 2025-10-06 06:10:28 --> Helper loaded: security_helper
INFO - 2025-10-06 06:10:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-06 06:10:28 --> Database Driver Class Initialized
DEBUG - 2025-10-06 06:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-06 06:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-06 06:10:28 --> Form Validation Class Initialized
INFO - 2025-10-06 06:10:28 --> Model "User_model" initialized
INFO - 2025-10-06 11:10:28 --> Model "Kunjungan_model" initialized
INFO - 2025-10-06 11:10:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-06 11:10:28 --> Model "Nav_model" initialized
INFO - 2025-10-06 11:10:28 --> Controller Class Initialized
INFO - 2025-10-06 11:10:28 --> Model "Pusat_model" initialized
INFO - 2025-10-06 11:10:28 --> Model "Prodi_model" initialized
INFO - 2025-10-06 11:10:28 --> Model "Sdm_model" initialized
INFO - 2025-10-06 11:10:28 --> Model "Sdm_pusat_model" initialized
INFO - 2025-10-06 11:10:28 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-10-06 11:10:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-10-06 11:10:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-06 11:10:29 --> Model "Log_model" initialized
INFO - 2025-10-06 11:10:29 --> Final output sent to browser
DEBUG - 2025-10-06 11:10:29 --> Total execution time: 0.6161
INFO - 2025-10-06 06:10:39 --> Config Class Initialized
INFO - 2025-10-06 06:10:39 --> Hooks Class Initialized
DEBUG - 2025-10-06 06:10:39 --> UTF-8 Support Enabled
INFO - 2025-10-06 06:10:39 --> Utf8 Class Initialized
INFO - 2025-10-06 06:10:39 --> URI Class Initialized
INFO - 2025-10-06 06:10:39 --> Router Class Initialized
INFO - 2025-10-06 06:10:39 --> Output Class Initialized
INFO - 2025-10-06 06:10:39 --> Security Class Initialized
DEBUG - 2025-10-06 06:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-06 06:10:39 --> CSRF cookie sent
INFO - 2025-10-06 06:10:39 --> Input Class Initialized
INFO - 2025-10-06 06:10:39 --> Language Class Initialized
INFO - 2025-10-06 06:10:39 --> Loader Class Initialized
INFO - 2025-10-06 06:10:39 --> Helper loaded: url_helper
INFO - 2025-10-06 06:10:39 --> Helper loaded: text_helper
INFO - 2025-10-06 06:10:39 --> Helper loaded: string_helper
INFO - 2025-10-06 06:10:39 --> Helper loaded: form_helper
INFO - 2025-10-06 06:10:39 --> Helper loaded: download_helper
INFO - 2025-10-06 06:10:39 --> Helper loaded: security_helper
INFO - 2025-10-06 06:10:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-06 06:10:39 --> Database Driver Class Initialized
DEBUG - 2025-10-06 06:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-06 06:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-06 06:10:40 --> Form Validation Class Initialized
INFO - 2025-10-06 06:10:40 --> Model "User_model" initialized
INFO - 2025-10-06 11:10:40 --> Model "Kunjungan_model" initialized
INFO - 2025-10-06 11:10:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-06 11:10:40 --> Model "Nav_model" initialized
INFO - 2025-10-06 11:10:40 --> Controller Class Initialized
INFO - 2025-10-06 11:10:40 --> Model "Unit_model" initialized
INFO - 2025-10-06 11:10:40 --> Model "Prodi_model" initialized
INFO - 2025-10-06 11:10:40 --> Model "Sdm_model" initialized
INFO - 2025-10-06 11:10:40 --> Model "Sdm_unit_model" initialized
INFO - 2025-10-06 11:10:40 --> Query SDM berhasil untuk unit: Unit Pengelola Usaha, Total: 1
INFO - 2025-10-06 11:10:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\unit/list.php
INFO - 2025-10-06 11:10:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-06 11:10:40 --> Model "Log_model" initialized
INFO - 2025-10-06 11:10:40 --> Final output sent to browser
DEBUG - 2025-10-06 11:10:40 --> Total execution time: 0.6561
INFO - 2025-10-06 06:10:49 --> Config Class Initialized
INFO - 2025-10-06 06:10:49 --> Hooks Class Initialized
DEBUG - 2025-10-06 06:10:49 --> UTF-8 Support Enabled
INFO - 2025-10-06 06:10:49 --> Utf8 Class Initialized
INFO - 2025-10-06 06:10:49 --> URI Class Initialized
DEBUG - 2025-10-06 06:10:49 --> No URI present. Default controller set.
INFO - 2025-10-06 06:10:49 --> Router Class Initialized
INFO - 2025-10-06 06:10:49 --> Output Class Initialized
INFO - 2025-10-06 06:10:49 --> Security Class Initialized
DEBUG - 2025-10-06 06:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-06 06:10:49 --> CSRF cookie sent
INFO - 2025-10-06 06:10:49 --> Input Class Initialized
INFO - 2025-10-06 06:10:49 --> Language Class Initialized
INFO - 2025-10-06 06:10:49 --> Loader Class Initialized
INFO - 2025-10-06 06:10:49 --> Helper loaded: url_helper
INFO - 2025-10-06 06:10:49 --> Helper loaded: text_helper
INFO - 2025-10-06 06:10:49 --> Helper loaded: string_helper
INFO - 2025-10-06 06:10:49 --> Helper loaded: form_helper
INFO - 2025-10-06 06:10:49 --> Helper loaded: download_helper
INFO - 2025-10-06 06:10:49 --> Helper loaded: security_helper
INFO - 2025-10-06 06:10:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-06 06:10:49 --> Database Driver Class Initialized
DEBUG - 2025-10-06 06:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-06 06:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-06 06:10:49 --> Form Validation Class Initialized
INFO - 2025-10-06 06:10:49 --> Model "User_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Kunjungan_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Nav_model" initialized
INFO - 2025-10-06 11:10:49 --> Controller Class Initialized
INFO - 2025-10-06 11:10:49 --> Model "Berita_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Galeri_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Video_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Agenda_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Tautan_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Mitra_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Jurusan_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Prodi_model" initialized
INFO - 2025-10-06 11:10:49 --> Model "Testimoni_model" initialized
INFO - 2025-10-06 11:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-06 11:10:49 --> Pagination Class Initialized
INFO - 2025-10-06 11:10:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-06 11:10:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-06 11:10:49 --> Model "Log_model" initialized
INFO - 2025-10-06 11:10:49 --> Final output sent to browser
DEBUG - 2025-10-06 11:10:49 --> Total execution time: 0.2427
