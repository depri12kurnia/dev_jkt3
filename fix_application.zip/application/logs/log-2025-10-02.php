<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-02 05:26:28 --> Config Class Initialized
INFO - 2025-10-02 05:26:28 --> Hooks Class Initialized
DEBUG - 2025-10-02 05:26:28 --> UTF-8 Support Enabled
INFO - 2025-10-02 05:26:28 --> Utf8 Class Initialized
INFO - 2025-10-02 05:26:28 --> URI Class Initialized
DEBUG - 2025-10-02 05:26:28 --> No URI present. Default controller set.
INFO - 2025-10-02 05:26:28 --> Router Class Initialized
INFO - 2025-10-02 05:26:29 --> Output Class Initialized
INFO - 2025-10-02 05:26:29 --> Security Class Initialized
DEBUG - 2025-10-02 05:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-02 05:26:29 --> CSRF cookie sent
INFO - 2025-10-02 05:26:29 --> Input Class Initialized
INFO - 2025-10-02 05:26:29 --> Language Class Initialized
INFO - 2025-10-02 05:26:29 --> Loader Class Initialized
INFO - 2025-10-02 05:26:29 --> Helper loaded: url_helper
INFO - 2025-10-02 05:26:29 --> Helper loaded: text_helper
INFO - 2025-10-02 05:26:29 --> Helper loaded: string_helper
INFO - 2025-10-02 05:26:29 --> Helper loaded: form_helper
INFO - 2025-10-02 05:26:29 --> Helper loaded: download_helper
INFO - 2025-10-02 05:26:30 --> Helper loaded: security_helper
INFO - 2025-10-02 05:26:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-02 05:26:30 --> Database Driver Class Initialized
DEBUG - 2025-10-02 05:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-02 05:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-02 05:26:31 --> Form Validation Class Initialized
INFO - 2025-10-02 05:26:31 --> Model "User_model" initialized
INFO - 2025-10-02 10:26:31 --> Model "Kunjungan_model" initialized
INFO - 2025-10-02 10:26:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-02 10:26:31 --> Model "Nav_model" initialized
INFO - 2025-10-02 10:26:31 --> Controller Class Initialized
INFO - 2025-10-02 10:26:31 --> Model "Berita_model" initialized
INFO - 2025-10-02 10:26:31 --> Model "Galeri_model" initialized
INFO - 2025-10-02 10:26:31 --> Model "Video_model" initialized
INFO - 2025-10-02 10:26:31 --> Model "Agenda_model" initialized
INFO - 2025-10-02 10:26:31 --> Model "Tautan_model" initialized
INFO - 2025-10-02 10:26:32 --> Model "Mitra_model" initialized
INFO - 2025-10-02 10:26:32 --> Model "Jurusan_model" initialized
INFO - 2025-10-02 10:26:32 --> Model "Prodi_model" initialized
INFO - 2025-10-02 10:26:32 --> Model "Testimoni_model" initialized
INFO - 2025-10-02 10:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-02 10:26:32 --> Pagination Class Initialized
INFO - 2025-10-02 10:26:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-02 10:26:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-02 10:26:35 --> Model "Log_model" initialized
INFO - 2025-10-02 10:26:35 --> Final output sent to browser
DEBUG - 2025-10-02 10:26:35 --> Total execution time: 7.3411
INFO - 2025-10-02 05:27:21 --> Config Class Initialized
INFO - 2025-10-02 05:27:21 --> Hooks Class Initialized
DEBUG - 2025-10-02 05:27:21 --> UTF-8 Support Enabled
INFO - 2025-10-02 05:27:21 --> Utf8 Class Initialized
INFO - 2025-10-02 05:27:21 --> URI Class Initialized
INFO - 2025-10-02 05:27:21 --> Router Class Initialized
INFO - 2025-10-02 05:27:21 --> Output Class Initialized
INFO - 2025-10-02 05:27:21 --> Security Class Initialized
DEBUG - 2025-10-02 05:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-02 05:27:22 --> CSRF cookie sent
INFO - 2025-10-02 05:27:22 --> Input Class Initialized
INFO - 2025-10-02 05:27:22 --> Language Class Initialized
INFO - 2025-10-02 05:27:22 --> Loader Class Initialized
INFO - 2025-10-02 05:27:22 --> Helper loaded: url_helper
INFO - 2025-10-02 05:27:22 --> Helper loaded: text_helper
INFO - 2025-10-02 05:27:22 --> Helper loaded: string_helper
INFO - 2025-10-02 05:27:22 --> Helper loaded: form_helper
INFO - 2025-10-02 05:27:22 --> Helper loaded: download_helper
INFO - 2025-10-02 05:27:22 --> Helper loaded: security_helper
INFO - 2025-10-02 05:27:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-02 05:27:22 --> Database Driver Class Initialized
DEBUG - 2025-10-02 05:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-02 05:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-02 05:27:22 --> Form Validation Class Initialized
INFO - 2025-10-02 05:27:22 --> Model "User_model" initialized
INFO - 2025-10-02 10:27:22 --> Model "Kunjungan_model" initialized
INFO - 2025-10-02 10:27:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-02 10:27:22 --> Model "Nav_model" initialized
INFO - 2025-10-02 10:27:22 --> Controller Class Initialized
INFO - 2025-10-02 10:27:22 --> Model "Jurusan_model" initialized
INFO - 2025-10-02 10:27:22 --> Model "Prodi_model" initialized
INFO - 2025-10-02 10:27:22 --> Model "Sdm_model" initialized
INFO - 2025-10-02 10:27:22 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-10-02 10:27:22 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-10-02 10:27:22 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-10-02 10:27:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-10-02 10:27:23 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2025-10-02 10:27:23 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2025-10-02 10:27:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-10-02 10:27:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-02 10:27:23 --> Model "Log_model" initialized
INFO - 2025-10-02 10:27:23 --> Final output sent to browser
DEBUG - 2025-10-02 10:27:23 --> Total execution time: 1.9006
INFO - 2025-10-02 08:26:51 --> Config Class Initialized
INFO - 2025-10-02 08:26:51 --> Hooks Class Initialized
DEBUG - 2025-10-02 08:26:52 --> UTF-8 Support Enabled
INFO - 2025-10-02 08:26:52 --> Utf8 Class Initialized
INFO - 2025-10-02 08:26:52 --> URI Class Initialized
DEBUG - 2025-10-02 08:26:52 --> No URI present. Default controller set.
INFO - 2025-10-02 08:26:52 --> Router Class Initialized
INFO - 2025-10-02 08:26:52 --> Output Class Initialized
INFO - 2025-10-02 08:26:52 --> Security Class Initialized
DEBUG - 2025-10-02 08:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-02 08:26:52 --> CSRF cookie sent
INFO - 2025-10-02 08:26:52 --> Input Class Initialized
INFO - 2025-10-02 08:26:52 --> Language Class Initialized
INFO - 2025-10-02 08:26:53 --> Loader Class Initialized
INFO - 2025-10-02 08:26:53 --> Helper loaded: url_helper
INFO - 2025-10-02 08:26:53 --> Helper loaded: text_helper
INFO - 2025-10-02 08:26:53 --> Helper loaded: string_helper
INFO - 2025-10-02 08:26:53 --> Helper loaded: form_helper
INFO - 2025-10-02 08:26:53 --> Helper loaded: download_helper
INFO - 2025-10-02 08:26:53 --> Helper loaded: security_helper
INFO - 2025-10-02 08:26:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-02 08:26:54 --> Database Driver Class Initialized
DEBUG - 2025-10-02 08:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-02 08:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-02 08:26:54 --> Form Validation Class Initialized
INFO - 2025-10-02 08:26:55 --> Model "User_model" initialized
INFO - 2025-10-02 13:26:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-02 13:26:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-02 13:26:55 --> Model "Nav_model" initialized
INFO - 2025-10-02 13:26:55 --> Controller Class Initialized
INFO - 2025-10-02 13:26:55 --> Model "Berita_model" initialized
INFO - 2025-10-02 13:26:56 --> Model "Galeri_model" initialized
INFO - 2025-10-02 13:26:56 --> Model "Video_model" initialized
INFO - 2025-10-02 13:26:56 --> Model "Agenda_model" initialized
INFO - 2025-10-02 13:26:56 --> Model "Tautan_model" initialized
INFO - 2025-10-02 13:26:56 --> Model "Mitra_model" initialized
INFO - 2025-10-02 13:26:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-02 13:26:56 --> Model "Prodi_model" initialized
INFO - 2025-10-02 13:26:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-02 13:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-02 13:26:57 --> Pagination Class Initialized
INFO - 2025-10-02 13:27:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-02 13:27:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-02 13:27:00 --> Model "Log_model" initialized
INFO - 2025-10-02 13:27:00 --> Final output sent to browser
DEBUG - 2025-10-02 13:27:00 --> Total execution time: 9.1967
