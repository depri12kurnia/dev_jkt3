<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-09-12 03:37:21 --> Config Class Initialized
INFO - 2025-09-12 03:37:21 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:37:21 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:37:21 --> Utf8 Class Initialized
INFO - 2025-09-12 03:37:21 --> URI Class Initialized
DEBUG - 2025-09-12 03:37:21 --> No URI present. Default controller set.
INFO - 2025-09-12 03:37:21 --> Router Class Initialized
INFO - 2025-09-12 03:37:22 --> Output Class Initialized
INFO - 2025-09-12 03:37:22 --> Security Class Initialized
DEBUG - 2025-09-12 03:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:37:22 --> CSRF cookie sent
INFO - 2025-09-12 03:37:22 --> Input Class Initialized
INFO - 2025-09-12 03:37:22 --> Language Class Initialized
INFO - 2025-09-12 03:37:22 --> Loader Class Initialized
INFO - 2025-09-12 03:37:22 --> Helper loaded: url_helper
INFO - 2025-09-12 03:37:22 --> Helper loaded: text_helper
INFO - 2025-09-12 03:37:22 --> Helper loaded: string_helper
INFO - 2025-09-12 03:37:22 --> Helper loaded: form_helper
INFO - 2025-09-12 03:37:22 --> Helper loaded: download_helper
INFO - 2025-09-12 03:37:22 --> Helper loaded: security_helper
INFO - 2025-09-12 03:37:22 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:37:23 --> Form Validation Class Initialized
INFO - 2025-09-12 03:37:23 --> Model "User_model" initialized
INFO - 2025-09-12 08:37:23 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:37:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:37:23 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:37:23 --> Controller Class Initialized
INFO - 2025-09-12 08:37:23 --> Model "Berita_model" initialized
INFO - 2025-09-12 08:37:23 --> Model "Galeri_model" initialized
INFO - 2025-09-12 08:37:23 --> Model "Video_model" initialized
INFO - 2025-09-12 08:37:24 --> Model "Agenda_model" initialized
INFO - 2025-09-12 08:37:24 --> Model "Tautan_model" initialized
INFO - 2025-09-12 08:37:24 --> Model "Mitra_model" initialized
INFO - 2025-09-12 08:37:24 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 08:37:24 --> Model "Prodi_model" initialized
INFO - 2025-09-12 08:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 08:37:24 --> Pagination Class Initialized
INFO - 2025-09-12 08:37:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 08:37:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:37:25 --> Model "Log_model" initialized
INFO - 2025-09-12 08:37:25 --> Final output sent to browser
DEBUG - 2025-09-12 08:37:25 --> Total execution time: 4.0216
INFO - 2025-09-12 03:38:15 --> Config Class Initialized
INFO - 2025-09-12 03:38:15 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:38:15 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:38:15 --> Utf8 Class Initialized
INFO - 2025-09-12 03:38:15 --> URI Class Initialized
INFO - 2025-09-12 03:38:15 --> Router Class Initialized
INFO - 2025-09-12 03:38:15 --> Output Class Initialized
INFO - 2025-09-12 03:38:15 --> Security Class Initialized
DEBUG - 2025-09-12 03:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:38:15 --> CSRF cookie sent
INFO - 2025-09-12 03:38:15 --> Input Class Initialized
INFO - 2025-09-12 03:38:15 --> Language Class Initialized
INFO - 2025-09-12 03:38:15 --> Loader Class Initialized
INFO - 2025-09-12 03:38:15 --> Helper loaded: url_helper
INFO - 2025-09-12 03:38:15 --> Helper loaded: text_helper
INFO - 2025-09-12 03:38:15 --> Helper loaded: string_helper
INFO - 2025-09-12 03:38:15 --> Helper loaded: form_helper
INFO - 2025-09-12 03:38:15 --> Helper loaded: download_helper
INFO - 2025-09-12 03:38:15 --> Helper loaded: security_helper
INFO - 2025-09-12 03:38:15 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:38:15 --> Form Validation Class Initialized
INFO - 2025-09-12 03:38:15 --> Model "User_model" initialized
INFO - 2025-09-12 08:38:15 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:38:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:38:15 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:38:15 --> Controller Class Initialized
INFO - 2025-09-12 08:38:15 --> Model "Pusat_model" initialized
INFO - 2025-09-12 08:38:15 --> Model "Prodi_model" initialized
INFO - 2025-09-12 08:38:15 --> Model "Sdm_model" initialized
INFO - 2025-09-12 08:38:15 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-12 08:38:16 --> Query SDM berhasil untuk pusat: Pusat Penelitian dan Pengabdian Masyarakat, Total: 1
INFO - 2025-09-12 08:38:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-12 08:38:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:38:16 --> Model "Log_model" initialized
INFO - 2025-09-12 08:38:16 --> Final output sent to browser
DEBUG - 2025-09-12 08:38:16 --> Total execution time: 0.3294
INFO - 2025-09-12 03:38:25 --> Config Class Initialized
INFO - 2025-09-12 03:38:25 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:38:25 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:38:25 --> Utf8 Class Initialized
INFO - 2025-09-12 03:38:25 --> URI Class Initialized
INFO - 2025-09-12 03:38:25 --> Router Class Initialized
INFO - 2025-09-12 03:38:25 --> Output Class Initialized
INFO - 2025-09-12 03:38:25 --> Security Class Initialized
DEBUG - 2025-09-12 03:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:38:25 --> CSRF cookie sent
INFO - 2025-09-12 03:38:25 --> Input Class Initialized
INFO - 2025-09-12 03:38:25 --> Language Class Initialized
INFO - 2025-09-12 03:38:25 --> Loader Class Initialized
INFO - 2025-09-12 03:38:25 --> Helper loaded: url_helper
INFO - 2025-09-12 03:38:25 --> Helper loaded: text_helper
INFO - 2025-09-12 03:38:25 --> Helper loaded: string_helper
INFO - 2025-09-12 03:38:25 --> Helper loaded: form_helper
INFO - 2025-09-12 03:38:25 --> Helper loaded: download_helper
INFO - 2025-09-12 03:38:25 --> Helper loaded: security_helper
INFO - 2025-09-12 03:38:25 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:38:25 --> Form Validation Class Initialized
INFO - 2025-09-12 03:38:25 --> Model "User_model" initialized
INFO - 2025-09-12 08:38:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:38:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:38:25 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:38:25 --> Controller Class Initialized
INFO - 2025-09-12 08:38:25 --> Model "Helpdesk_model" initialized
INFO - 2025-09-12 08:38:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list.php
INFO - 2025-09-12 08:38:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:38:25 --> Model "Log_model" initialized
INFO - 2025-09-12 08:38:25 --> Final output sent to browser
DEBUG - 2025-09-12 08:38:25 --> Total execution time: 0.3886
INFO - 2025-09-12 03:38:28 --> Config Class Initialized
INFO - 2025-09-12 03:38:28 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:38:28 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:38:28 --> Utf8 Class Initialized
INFO - 2025-09-12 03:38:28 --> URI Class Initialized
INFO - 2025-09-12 03:38:28 --> Router Class Initialized
INFO - 2025-09-12 03:38:28 --> Output Class Initialized
INFO - 2025-09-12 03:38:28 --> Security Class Initialized
DEBUG - 2025-09-12 03:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:38:28 --> CSRF cookie sent
INFO - 2025-09-12 03:38:28 --> Input Class Initialized
INFO - 2025-09-12 03:38:28 --> Language Class Initialized
INFO - 2025-09-12 03:38:28 --> Loader Class Initialized
INFO - 2025-09-12 03:38:28 --> Helper loaded: url_helper
INFO - 2025-09-12 03:38:28 --> Helper loaded: text_helper
INFO - 2025-09-12 03:38:28 --> Helper loaded: string_helper
INFO - 2025-09-12 03:38:28 --> Helper loaded: form_helper
INFO - 2025-09-12 03:38:28 --> Helper loaded: download_helper
INFO - 2025-09-12 03:38:28 --> Helper loaded: security_helper
INFO - 2025-09-12 03:38:28 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:38:28 --> Form Validation Class Initialized
INFO - 2025-09-12 03:38:28 --> Model "User_model" initialized
INFO - 2025-09-12 08:38:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:38:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:38:28 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:38:28 --> Controller Class Initialized
INFO - 2025-09-12 08:38:28 --> Model "Helpdesk_model" initialized
INFO - 2025-09-12 08:38:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list_adak.php
INFO - 2025-09-12 08:38:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:38:28 --> Model "Log_model" initialized
INFO - 2025-09-12 08:38:28 --> Final output sent to browser
DEBUG - 2025-09-12 08:38:28 --> Total execution time: 0.1446
INFO - 2025-09-12 03:38:44 --> Config Class Initialized
INFO - 2025-09-12 03:38:44 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:38:44 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:38:44 --> Utf8 Class Initialized
INFO - 2025-09-12 03:38:44 --> URI Class Initialized
INFO - 2025-09-12 03:38:44 --> Router Class Initialized
INFO - 2025-09-12 03:38:44 --> Output Class Initialized
INFO - 2025-09-12 03:38:44 --> Security Class Initialized
DEBUG - 2025-09-12 03:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:38:44 --> CSRF cookie sent
INFO - 2025-09-12 03:38:44 --> Input Class Initialized
INFO - 2025-09-12 03:38:44 --> Language Class Initialized
INFO - 2025-09-12 03:38:44 --> Loader Class Initialized
INFO - 2025-09-12 03:38:44 --> Helper loaded: url_helper
INFO - 2025-09-12 03:38:44 --> Helper loaded: text_helper
INFO - 2025-09-12 03:38:44 --> Helper loaded: string_helper
INFO - 2025-09-12 03:38:44 --> Helper loaded: form_helper
INFO - 2025-09-12 03:38:44 --> Helper loaded: download_helper
INFO - 2025-09-12 03:38:44 --> Helper loaded: security_helper
INFO - 2025-09-12 03:38:44 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:38:44 --> Form Validation Class Initialized
INFO - 2025-09-12 03:38:44 --> Model "User_model" initialized
INFO - 2025-09-12 08:38:44 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:38:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:38:44 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:38:44 --> Controller Class Initialized
INFO - 2025-09-12 08:38:44 --> Model "Helpdesk_model" initialized
INFO - 2025-09-12 08:38:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list_adak.php
INFO - 2025-09-12 08:38:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:38:44 --> Model "Log_model" initialized
INFO - 2025-09-12 08:38:44 --> Final output sent to browser
DEBUG - 2025-09-12 08:38:44 --> Total execution time: 0.1421
INFO - 2025-09-12 03:39:18 --> Config Class Initialized
INFO - 2025-09-12 03:39:18 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:39:18 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:39:18 --> Utf8 Class Initialized
INFO - 2025-09-12 03:39:18 --> URI Class Initialized
INFO - 2025-09-12 03:39:18 --> Router Class Initialized
INFO - 2025-09-12 03:39:18 --> Output Class Initialized
INFO - 2025-09-12 03:39:18 --> Security Class Initialized
DEBUG - 2025-09-12 03:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:39:18 --> CSRF cookie sent
INFO - 2025-09-12 03:39:18 --> Input Class Initialized
INFO - 2025-09-12 03:39:18 --> Language Class Initialized
INFO - 2025-09-12 03:39:18 --> Loader Class Initialized
INFO - 2025-09-12 03:39:18 --> Helper loaded: url_helper
INFO - 2025-09-12 03:39:18 --> Helper loaded: text_helper
INFO - 2025-09-12 03:39:18 --> Helper loaded: string_helper
INFO - 2025-09-12 03:39:18 --> Helper loaded: form_helper
INFO - 2025-09-12 03:39:18 --> Helper loaded: download_helper
INFO - 2025-09-12 03:39:18 --> Helper loaded: security_helper
INFO - 2025-09-12 03:39:18 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:39:18 --> Form Validation Class Initialized
INFO - 2025-09-12 03:39:18 --> Model "User_model" initialized
INFO - 2025-09-12 08:39:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:39:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:39:18 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:39:18 --> Controller Class Initialized
INFO - 2025-09-12 08:39:18 --> Model "Helpdesk_model" initialized
INFO - 2025-09-12 08:39:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list_adak.php
INFO - 2025-09-12 08:39:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:39:18 --> Model "Log_model" initialized
INFO - 2025-09-12 08:39:18 --> Final output sent to browser
DEBUG - 2025-09-12 08:39:18 --> Total execution time: 0.1472
INFO - 2025-09-12 03:39:39 --> Config Class Initialized
INFO - 2025-09-12 03:39:39 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:39:39 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:39:39 --> Utf8 Class Initialized
INFO - 2025-09-12 03:39:39 --> URI Class Initialized
DEBUG - 2025-09-12 03:39:39 --> No URI present. Default controller set.
INFO - 2025-09-12 03:39:39 --> Router Class Initialized
INFO - 2025-09-12 03:39:39 --> Output Class Initialized
INFO - 2025-09-12 03:39:39 --> Security Class Initialized
DEBUG - 2025-09-12 03:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:39:39 --> CSRF cookie sent
INFO - 2025-09-12 03:39:39 --> Input Class Initialized
INFO - 2025-09-12 03:39:39 --> Language Class Initialized
INFO - 2025-09-12 03:39:39 --> Loader Class Initialized
INFO - 2025-09-12 03:39:39 --> Helper loaded: url_helper
INFO - 2025-09-12 03:39:39 --> Helper loaded: text_helper
INFO - 2025-09-12 03:39:39 --> Helper loaded: string_helper
INFO - 2025-09-12 03:39:39 --> Helper loaded: form_helper
INFO - 2025-09-12 03:39:39 --> Helper loaded: download_helper
INFO - 2025-09-12 03:39:39 --> Helper loaded: security_helper
INFO - 2025-09-12 03:39:39 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:39:39 --> Form Validation Class Initialized
INFO - 2025-09-12 03:39:39 --> Model "User_model" initialized
INFO - 2025-09-12 08:39:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:39:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:39:39 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:39:39 --> Controller Class Initialized
INFO - 2025-09-12 08:39:39 --> Model "Berita_model" initialized
INFO - 2025-09-12 08:39:39 --> Model "Galeri_model" initialized
INFO - 2025-09-12 08:39:39 --> Model "Video_model" initialized
INFO - 2025-09-12 08:39:39 --> Model "Agenda_model" initialized
INFO - 2025-09-12 08:39:39 --> Model "Tautan_model" initialized
INFO - 2025-09-12 08:39:39 --> Model "Mitra_model" initialized
INFO - 2025-09-12 08:39:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 08:39:39 --> Model "Prodi_model" initialized
INFO - 2025-09-12 08:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 08:39:39 --> Pagination Class Initialized
INFO - 2025-09-12 08:39:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 08:39:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:39:39 --> Model "Log_model" initialized
INFO - 2025-09-12 08:39:39 --> Final output sent to browser
DEBUG - 2025-09-12 08:39:39 --> Total execution time: 0.2156
INFO - 2025-09-12 03:40:12 --> Config Class Initialized
INFO - 2025-09-12 03:40:12 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:40:12 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:40:12 --> Utf8 Class Initialized
INFO - 2025-09-12 03:40:12 --> URI Class Initialized
DEBUG - 2025-09-12 03:40:12 --> No URI present. Default controller set.
INFO - 2025-09-12 03:40:12 --> Router Class Initialized
INFO - 2025-09-12 03:40:12 --> Output Class Initialized
INFO - 2025-09-12 03:40:12 --> Security Class Initialized
DEBUG - 2025-09-12 03:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:40:12 --> CSRF cookie sent
INFO - 2025-09-12 03:40:12 --> Input Class Initialized
INFO - 2025-09-12 03:40:12 --> Language Class Initialized
INFO - 2025-09-12 03:40:12 --> Loader Class Initialized
INFO - 2025-09-12 03:40:12 --> Helper loaded: url_helper
INFO - 2025-09-12 03:40:12 --> Helper loaded: text_helper
INFO - 2025-09-12 03:40:12 --> Helper loaded: string_helper
INFO - 2025-09-12 03:40:12 --> Helper loaded: form_helper
INFO - 2025-09-12 03:40:12 --> Helper loaded: download_helper
INFO - 2025-09-12 03:40:12 --> Helper loaded: security_helper
INFO - 2025-09-12 03:40:12 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:40:12 --> Form Validation Class Initialized
INFO - 2025-09-12 03:40:12 --> Model "User_model" initialized
INFO - 2025-09-12 08:40:12 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:40:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:40:12 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:40:12 --> Controller Class Initialized
INFO - 2025-09-12 08:40:12 --> Model "Berita_model" initialized
INFO - 2025-09-12 08:40:12 --> Model "Galeri_model" initialized
INFO - 2025-09-12 08:40:12 --> Model "Video_model" initialized
INFO - 2025-09-12 08:40:12 --> Model "Agenda_model" initialized
INFO - 2025-09-12 08:40:12 --> Model "Tautan_model" initialized
INFO - 2025-09-12 08:40:12 --> Model "Mitra_model" initialized
INFO - 2025-09-12 08:40:12 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 08:40:12 --> Model "Prodi_model" initialized
INFO - 2025-09-12 08:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 08:40:12 --> Pagination Class Initialized
INFO - 2025-09-12 08:40:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 08:40:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:40:12 --> Model "Log_model" initialized
INFO - 2025-09-12 08:40:12 --> Final output sent to browser
DEBUG - 2025-09-12 08:40:12 --> Total execution time: 0.2378
INFO - 2025-09-12 03:40:15 --> Config Class Initialized
INFO - 2025-09-12 03:40:15 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:40:15 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:40:15 --> Utf8 Class Initialized
INFO - 2025-09-12 03:40:15 --> URI Class Initialized
DEBUG - 2025-09-12 03:40:15 --> No URI present. Default controller set.
INFO - 2025-09-12 03:40:15 --> Router Class Initialized
INFO - 2025-09-12 03:40:15 --> Output Class Initialized
INFO - 2025-09-12 03:40:15 --> Security Class Initialized
DEBUG - 2025-09-12 03:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:40:15 --> CSRF cookie sent
INFO - 2025-09-12 03:40:15 --> Input Class Initialized
INFO - 2025-09-12 03:40:15 --> Language Class Initialized
INFO - 2025-09-12 03:40:15 --> Loader Class Initialized
INFO - 2025-09-12 03:40:15 --> Helper loaded: url_helper
INFO - 2025-09-12 03:40:15 --> Helper loaded: text_helper
INFO - 2025-09-12 03:40:15 --> Helper loaded: string_helper
INFO - 2025-09-12 03:40:15 --> Helper loaded: form_helper
INFO - 2025-09-12 03:40:15 --> Helper loaded: download_helper
INFO - 2025-09-12 03:40:15 --> Helper loaded: security_helper
INFO - 2025-09-12 03:40:15 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:40:15 --> Form Validation Class Initialized
INFO - 2025-09-12 03:40:15 --> Model "User_model" initialized
INFO - 2025-09-12 08:40:15 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:40:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:40:15 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:40:15 --> Controller Class Initialized
INFO - 2025-09-12 08:40:15 --> Model "Berita_model" initialized
INFO - 2025-09-12 08:40:15 --> Model "Galeri_model" initialized
INFO - 2025-09-12 08:40:15 --> Model "Video_model" initialized
INFO - 2025-09-12 08:40:15 --> Model "Agenda_model" initialized
INFO - 2025-09-12 08:40:15 --> Model "Tautan_model" initialized
INFO - 2025-09-12 08:40:15 --> Model "Mitra_model" initialized
INFO - 2025-09-12 08:40:15 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 08:40:15 --> Model "Prodi_model" initialized
INFO - 2025-09-12 08:40:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 08:40:15 --> Pagination Class Initialized
INFO - 2025-09-12 08:40:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 08:40:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:40:15 --> Model "Log_model" initialized
INFO - 2025-09-12 08:40:15 --> Final output sent to browser
DEBUG - 2025-09-12 08:40:15 --> Total execution time: 0.2682
INFO - 2025-09-12 03:51:23 --> Config Class Initialized
INFO - 2025-09-12 03:51:23 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:51:24 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:51:24 --> Utf8 Class Initialized
INFO - 2025-09-12 03:51:24 --> URI Class Initialized
INFO - 2025-09-12 03:51:24 --> Router Class Initialized
INFO - 2025-09-12 03:51:24 --> Output Class Initialized
INFO - 2025-09-12 03:51:24 --> Security Class Initialized
DEBUG - 2025-09-12 03:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:51:24 --> CSRF cookie sent
INFO - 2025-09-12 03:51:24 --> Input Class Initialized
INFO - 2025-09-12 03:51:24 --> Language Class Initialized
INFO - 2025-09-12 03:51:24 --> Loader Class Initialized
INFO - 2025-09-12 03:51:25 --> Helper loaded: url_helper
INFO - 2025-09-12 03:51:25 --> Helper loaded: text_helper
INFO - 2025-09-12 03:51:25 --> Helper loaded: string_helper
INFO - 2025-09-12 03:51:25 --> Helper loaded: form_helper
INFO - 2025-09-12 03:51:25 --> Helper loaded: download_helper
INFO - 2025-09-12 03:51:25 --> Helper loaded: security_helper
INFO - 2025-09-12 03:51:25 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:51:26 --> Form Validation Class Initialized
INFO - 2025-09-12 03:51:26 --> Model "User_model" initialized
INFO - 2025-09-12 08:51:26 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:51:26 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:51:26 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:51:26 --> Controller Class Initialized
INFO - 2025-09-12 08:51:26 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 08:51:26 --> Model "Prodi_model" initialized
INFO - 2025-09-12 08:51:26 --> Model "Sdm_model" initialized
INFO - 2025-09-12 08:51:26 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-12 08:51:27 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-12 08:51:27 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-12 08:51:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-12 08:51:28 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-12 08:51:28 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-12 08:51:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-12 08:51:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:51:28 --> Model "Log_model" initialized
INFO - 2025-09-12 08:51:28 --> Final output sent to browser
DEBUG - 2025-09-12 08:51:28 --> Total execution time: 5.3542
INFO - 2025-09-12 03:59:04 --> Config Class Initialized
INFO - 2025-09-12 03:59:04 --> Hooks Class Initialized
DEBUG - 2025-09-12 03:59:04 --> UTF-8 Support Enabled
INFO - 2025-09-12 03:59:04 --> Utf8 Class Initialized
INFO - 2025-09-12 03:59:04 --> URI Class Initialized
DEBUG - 2025-09-12 03:59:04 --> No URI present. Default controller set.
INFO - 2025-09-12 03:59:04 --> Router Class Initialized
INFO - 2025-09-12 03:59:04 --> Output Class Initialized
INFO - 2025-09-12 03:59:04 --> Security Class Initialized
DEBUG - 2025-09-12 03:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 03:59:04 --> CSRF cookie sent
INFO - 2025-09-12 03:59:04 --> Input Class Initialized
INFO - 2025-09-12 03:59:04 --> Language Class Initialized
INFO - 2025-09-12 03:59:04 --> Loader Class Initialized
INFO - 2025-09-12 03:59:04 --> Helper loaded: url_helper
INFO - 2025-09-12 03:59:04 --> Helper loaded: text_helper
INFO - 2025-09-12 03:59:04 --> Helper loaded: string_helper
INFO - 2025-09-12 03:59:04 --> Helper loaded: form_helper
INFO - 2025-09-12 03:59:04 --> Helper loaded: download_helper
INFO - 2025-09-12 03:59:04 --> Helper loaded: security_helper
INFO - 2025-09-12 03:59:04 --> Database Driver Class Initialized
DEBUG - 2025-09-12 03:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 03:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 03:59:05 --> Form Validation Class Initialized
INFO - 2025-09-12 03:59:05 --> Model "User_model" initialized
INFO - 2025-09-12 08:59:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 08:59:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 08:59:05 --> Model "Nav_model" initialized
INFO - 2025-09-12 08:59:05 --> Controller Class Initialized
INFO - 2025-09-12 08:59:05 --> Model "Berita_model" initialized
INFO - 2025-09-12 08:59:05 --> Model "Galeri_model" initialized
INFO - 2025-09-12 08:59:05 --> Model "Video_model" initialized
INFO - 2025-09-12 08:59:05 --> Model "Agenda_model" initialized
INFO - 2025-09-12 08:59:05 --> Model "Tautan_model" initialized
INFO - 2025-09-12 08:59:05 --> Model "Mitra_model" initialized
INFO - 2025-09-12 08:59:05 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 08:59:05 --> Model "Prodi_model" initialized
INFO - 2025-09-12 08:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 08:59:05 --> Pagination Class Initialized
INFO - 2025-09-12 08:59:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 08:59:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 08:59:06 --> Model "Log_model" initialized
INFO - 2025-09-12 08:59:06 --> Final output sent to browser
DEBUG - 2025-09-12 08:59:06 --> Total execution time: 1.6011
INFO - 2025-09-12 04:00:45 --> Config Class Initialized
INFO - 2025-09-12 04:00:45 --> Hooks Class Initialized
DEBUG - 2025-09-12 04:00:45 --> UTF-8 Support Enabled
INFO - 2025-09-12 04:00:45 --> Utf8 Class Initialized
INFO - 2025-09-12 04:00:45 --> URI Class Initialized
DEBUG - 2025-09-12 04:00:45 --> No URI present. Default controller set.
INFO - 2025-09-12 04:00:45 --> Router Class Initialized
INFO - 2025-09-12 04:00:45 --> Output Class Initialized
INFO - 2025-09-12 04:00:45 --> Security Class Initialized
DEBUG - 2025-09-12 04:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 04:00:45 --> CSRF cookie sent
INFO - 2025-09-12 04:00:45 --> Input Class Initialized
INFO - 2025-09-12 04:00:45 --> Language Class Initialized
INFO - 2025-09-12 04:00:45 --> Loader Class Initialized
INFO - 2025-09-12 04:00:45 --> Helper loaded: url_helper
INFO - 2025-09-12 04:00:45 --> Helper loaded: text_helper
INFO - 2025-09-12 04:00:45 --> Helper loaded: string_helper
INFO - 2025-09-12 04:00:45 --> Helper loaded: form_helper
INFO - 2025-09-12 04:00:45 --> Helper loaded: download_helper
INFO - 2025-09-12 04:00:45 --> Helper loaded: security_helper
INFO - 2025-09-12 04:00:45 --> Database Driver Class Initialized
DEBUG - 2025-09-12 04:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 04:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 04:00:45 --> Form Validation Class Initialized
INFO - 2025-09-12 04:00:45 --> Model "User_model" initialized
INFO - 2025-09-12 09:00:45 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 09:00:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 09:00:45 --> Model "Nav_model" initialized
INFO - 2025-09-12 09:00:45 --> Controller Class Initialized
INFO - 2025-09-12 09:00:45 --> Model "Berita_model" initialized
INFO - 2025-09-12 09:00:45 --> Model "Galeri_model" initialized
INFO - 2025-09-12 09:00:45 --> Model "Video_model" initialized
INFO - 2025-09-12 09:00:45 --> Model "Agenda_model" initialized
INFO - 2025-09-12 09:00:45 --> Model "Tautan_model" initialized
INFO - 2025-09-12 09:00:45 --> Model "Mitra_model" initialized
INFO - 2025-09-12 09:00:45 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 09:00:45 --> Model "Prodi_model" initialized
INFO - 2025-09-12 09:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 09:00:45 --> Pagination Class Initialized
INFO - 2025-09-12 09:00:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 09:00:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 09:00:45 --> Model "Log_model" initialized
INFO - 2025-09-12 09:00:45 --> Final output sent to browser
DEBUG - 2025-09-12 09:00:45 --> Total execution time: 0.1521
INFO - 2025-09-12 04:01:56 --> Config Class Initialized
INFO - 2025-09-12 04:01:56 --> Hooks Class Initialized
DEBUG - 2025-09-12 04:01:56 --> UTF-8 Support Enabled
INFO - 2025-09-12 04:01:56 --> Utf8 Class Initialized
INFO - 2025-09-12 04:01:56 --> URI Class Initialized
DEBUG - 2025-09-12 04:01:56 --> No URI present. Default controller set.
INFO - 2025-09-12 04:01:56 --> Router Class Initialized
INFO - 2025-09-12 04:01:56 --> Output Class Initialized
INFO - 2025-09-12 04:01:56 --> Security Class Initialized
DEBUG - 2025-09-12 04:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 04:01:56 --> CSRF cookie sent
INFO - 2025-09-12 04:01:56 --> Input Class Initialized
INFO - 2025-09-12 04:01:56 --> Language Class Initialized
INFO - 2025-09-12 04:01:56 --> Loader Class Initialized
INFO - 2025-09-12 04:01:56 --> Helper loaded: url_helper
INFO - 2025-09-12 04:01:56 --> Helper loaded: text_helper
INFO - 2025-09-12 04:01:56 --> Helper loaded: string_helper
INFO - 2025-09-12 04:01:56 --> Helper loaded: form_helper
INFO - 2025-09-12 04:01:56 --> Helper loaded: download_helper
INFO - 2025-09-12 04:01:56 --> Helper loaded: security_helper
INFO - 2025-09-12 04:01:56 --> Database Driver Class Initialized
DEBUG - 2025-09-12 04:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 04:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 04:01:57 --> Form Validation Class Initialized
INFO - 2025-09-12 04:01:57 --> Model "User_model" initialized
INFO - 2025-09-12 09:01:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 09:01:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 09:01:57 --> Model "Nav_model" initialized
INFO - 2025-09-12 09:01:57 --> Controller Class Initialized
INFO - 2025-09-12 09:01:57 --> Model "Berita_model" initialized
INFO - 2025-09-12 09:01:57 --> Model "Galeri_model" initialized
INFO - 2025-09-12 09:01:57 --> Model "Video_model" initialized
INFO - 2025-09-12 09:01:57 --> Model "Agenda_model" initialized
INFO - 2025-09-12 09:01:57 --> Model "Tautan_model" initialized
INFO - 2025-09-12 09:01:57 --> Model "Mitra_model" initialized
INFO - 2025-09-12 09:01:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 09:01:57 --> Model "Prodi_model" initialized
INFO - 2025-09-12 09:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 09:01:57 --> Pagination Class Initialized
INFO - 2025-09-12 09:01:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 09:01:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 09:01:57 --> Model "Log_model" initialized
INFO - 2025-09-12 09:01:57 --> Final output sent to browser
DEBUG - 2025-09-12 09:01:57 --> Total execution time: 0.1015
INFO - 2025-09-12 09:28:04 --> Config Class Initialized
INFO - 2025-09-12 09:28:04 --> Hooks Class Initialized
DEBUG - 2025-09-12 09:28:05 --> UTF-8 Support Enabled
INFO - 2025-09-12 09:28:05 --> Utf8 Class Initialized
INFO - 2025-09-12 09:28:05 --> URI Class Initialized
DEBUG - 2025-09-12 09:28:05 --> No URI present. Default controller set.
INFO - 2025-09-12 09:28:05 --> Router Class Initialized
INFO - 2025-09-12 09:28:05 --> Output Class Initialized
INFO - 2025-09-12 09:28:05 --> Security Class Initialized
DEBUG - 2025-09-12 09:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 09:28:06 --> CSRF cookie sent
INFO - 2025-09-12 09:28:06 --> Input Class Initialized
INFO - 2025-09-12 09:28:06 --> Language Class Initialized
INFO - 2025-09-12 09:28:06 --> Loader Class Initialized
INFO - 2025-09-12 09:28:06 --> Helper loaded: url_helper
INFO - 2025-09-12 09:28:06 --> Helper loaded: text_helper
INFO - 2025-09-12 09:28:06 --> Helper loaded: string_helper
INFO - 2025-09-12 09:28:06 --> Helper loaded: form_helper
INFO - 2025-09-12 09:28:06 --> Helper loaded: download_helper
INFO - 2025-09-12 09:28:06 --> Helper loaded: security_helper
INFO - 2025-09-12 09:28:07 --> Database Driver Class Initialized
DEBUG - 2025-09-12 09:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 09:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 09:28:08 --> Form Validation Class Initialized
INFO - 2025-09-12 09:28:08 --> Model "User_model" initialized
INFO - 2025-09-12 14:28:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 14:28:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 14:28:09 --> Model "Nav_model" initialized
INFO - 2025-09-12 14:28:09 --> Controller Class Initialized
INFO - 2025-09-12 14:28:09 --> Model "Berita_model" initialized
INFO - 2025-09-12 14:28:09 --> Model "Galeri_model" initialized
INFO - 2025-09-12 14:28:10 --> Model "Video_model" initialized
INFO - 2025-09-12 14:28:10 --> Model "Agenda_model" initialized
INFO - 2025-09-12 14:28:10 --> Model "Tautan_model" initialized
INFO - 2025-09-12 14:28:10 --> Model "Mitra_model" initialized
INFO - 2025-09-12 14:28:10 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 14:28:10 --> Model "Prodi_model" initialized
INFO - 2025-09-12 14:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 14:28:10 --> Pagination Class Initialized
INFO - 2025-09-12 14:28:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 14:28:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 14:28:12 --> Model "Log_model" initialized
INFO - 2025-09-12 14:28:12 --> Final output sent to browser
DEBUG - 2025-09-12 14:28:12 --> Total execution time: 8.5409
INFO - 2025-09-12 09:47:29 --> Config Class Initialized
INFO - 2025-09-12 09:47:29 --> Hooks Class Initialized
DEBUG - 2025-09-12 09:47:29 --> UTF-8 Support Enabled
INFO - 2025-09-12 09:47:29 --> Utf8 Class Initialized
INFO - 2025-09-12 09:47:29 --> URI Class Initialized
INFO - 2025-09-12 09:47:29 --> Router Class Initialized
INFO - 2025-09-12 09:47:29 --> Output Class Initialized
INFO - 2025-09-12 09:47:29 --> Security Class Initialized
DEBUG - 2025-09-12 09:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 09:47:29 --> CSRF cookie sent
INFO - 2025-09-12 09:47:29 --> Input Class Initialized
INFO - 2025-09-12 09:47:29 --> Language Class Initialized
INFO - 2025-09-12 09:47:29 --> Loader Class Initialized
INFO - 2025-09-12 09:47:29 --> Helper loaded: url_helper
INFO - 2025-09-12 09:47:29 --> Helper loaded: text_helper
INFO - 2025-09-12 09:47:29 --> Helper loaded: string_helper
INFO - 2025-09-12 09:47:29 --> Helper loaded: form_helper
INFO - 2025-09-12 09:47:29 --> Helper loaded: download_helper
INFO - 2025-09-12 09:47:29 --> Helper loaded: security_helper
INFO - 2025-09-12 09:47:29 --> Database Driver Class Initialized
DEBUG - 2025-09-12 09:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 09:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 09:47:29 --> Form Validation Class Initialized
INFO - 2025-09-12 09:47:29 --> Model "User_model" initialized
INFO - 2025-09-12 14:47:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 14:47:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 14:47:29 --> Model "Nav_model" initialized
INFO - 2025-09-12 14:47:29 --> Controller Class Initialized
INFO - 2025-09-12 14:47:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 14:47:29 --> Model "Prodi_model" initialized
INFO - 2025-09-12 14:47:29 --> Model "Sdm_model" initialized
INFO - 2025-09-12 14:47:29 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-12 14:47:29 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 0
ERROR - 2025-09-12 14:47:29 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-12 14:47:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-12 14:47:30 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-12 14:47:30 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-12 14:47:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-12 14:47:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 14:47:30 --> Model "Log_model" initialized
INFO - 2025-09-12 14:47:30 --> Final output sent to browser
DEBUG - 2025-09-12 14:47:30 --> Total execution time: 1.3303
INFO - 2025-09-12 09:54:06 --> Config Class Initialized
INFO - 2025-09-12 09:54:06 --> Hooks Class Initialized
DEBUG - 2025-09-12 09:54:06 --> UTF-8 Support Enabled
INFO - 2025-09-12 09:54:06 --> Utf8 Class Initialized
INFO - 2025-09-12 09:54:06 --> URI Class Initialized
INFO - 2025-09-12 09:54:06 --> Router Class Initialized
INFO - 2025-09-12 09:54:06 --> Output Class Initialized
INFO - 2025-09-12 09:54:06 --> Security Class Initialized
DEBUG - 2025-09-12 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 09:54:06 --> CSRF cookie sent
INFO - 2025-09-12 09:54:06 --> Input Class Initialized
INFO - 2025-09-12 09:54:06 --> Language Class Initialized
INFO - 2025-09-12 09:54:06 --> Loader Class Initialized
INFO - 2025-09-12 09:54:06 --> Helper loaded: url_helper
INFO - 2025-09-12 09:54:06 --> Helper loaded: text_helper
INFO - 2025-09-12 09:54:06 --> Helper loaded: string_helper
INFO - 2025-09-12 09:54:06 --> Helper loaded: form_helper
INFO - 2025-09-12 09:54:06 --> Helper loaded: download_helper
INFO - 2025-09-12 09:54:06 --> Helper loaded: security_helper
INFO - 2025-09-12 09:54:06 --> Database Driver Class Initialized
DEBUG - 2025-09-12 09:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 09:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 09:54:06 --> Form Validation Class Initialized
INFO - 2025-09-12 09:54:06 --> Model "User_model" initialized
INFO - 2025-09-12 14:54:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 14:54:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 14:54:06 --> Model "Nav_model" initialized
INFO - 2025-09-12 14:54:06 --> Controller Class Initialized
INFO - 2025-09-12 14:54:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 14:54:06 --> Model "Prodi_model" initialized
INFO - 2025-09-12 14:54:06 --> Model "Sdm_model" initialized
INFO - 2025-09-12 14:54:06 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-12 14:54:06 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 0
ERROR - 2025-09-12 14:54:06 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-12 14:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-12 14:54:06 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-12 14:54:06 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-12 14:54:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-12 14:54:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 14:54:06 --> Model "Log_model" initialized
INFO - 2025-09-12 14:54:06 --> Final output sent to browser
DEBUG - 2025-09-12 14:54:06 --> Total execution time: 0.0895
INFO - 2025-09-12 09:54:10 --> Config Class Initialized
INFO - 2025-09-12 09:54:10 --> Hooks Class Initialized
DEBUG - 2025-09-12 09:54:10 --> UTF-8 Support Enabled
INFO - 2025-09-12 09:54:10 --> Utf8 Class Initialized
INFO - 2025-09-12 09:54:10 --> URI Class Initialized
DEBUG - 2025-09-12 09:54:10 --> No URI present. Default controller set.
INFO - 2025-09-12 09:54:10 --> Router Class Initialized
INFO - 2025-09-12 09:54:10 --> Output Class Initialized
INFO - 2025-09-12 09:54:10 --> Security Class Initialized
DEBUG - 2025-09-12 09:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 09:54:10 --> CSRF cookie sent
INFO - 2025-09-12 09:54:10 --> Input Class Initialized
INFO - 2025-09-12 09:54:10 --> Language Class Initialized
INFO - 2025-09-12 09:54:10 --> Loader Class Initialized
INFO - 2025-09-12 09:54:10 --> Helper loaded: url_helper
INFO - 2025-09-12 09:54:10 --> Helper loaded: text_helper
INFO - 2025-09-12 09:54:10 --> Helper loaded: string_helper
INFO - 2025-09-12 09:54:10 --> Helper loaded: form_helper
INFO - 2025-09-12 09:54:10 --> Helper loaded: download_helper
INFO - 2025-09-12 09:54:10 --> Helper loaded: security_helper
INFO - 2025-09-12 09:54:10 --> Database Driver Class Initialized
DEBUG - 2025-09-12 09:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 09:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 09:54:10 --> Form Validation Class Initialized
INFO - 2025-09-12 09:54:10 --> Model "User_model" initialized
INFO - 2025-09-12 14:54:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 14:54:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 14:54:10 --> Model "Nav_model" initialized
INFO - 2025-09-12 14:54:10 --> Controller Class Initialized
INFO - 2025-09-12 14:54:10 --> Model "Berita_model" initialized
INFO - 2025-09-12 14:54:10 --> Model "Galeri_model" initialized
INFO - 2025-09-12 14:54:10 --> Model "Video_model" initialized
INFO - 2025-09-12 14:54:10 --> Model "Agenda_model" initialized
INFO - 2025-09-12 14:54:10 --> Model "Tautan_model" initialized
INFO - 2025-09-12 14:54:10 --> Model "Mitra_model" initialized
INFO - 2025-09-12 14:54:10 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 14:54:10 --> Model "Prodi_model" initialized
INFO - 2025-09-12 14:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 14:54:10 --> Pagination Class Initialized
INFO - 2025-09-12 14:54:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 14:54:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 14:54:10 --> Model "Log_model" initialized
INFO - 2025-09-12 14:54:10 --> Final output sent to browser
DEBUG - 2025-09-12 14:54:10 --> Total execution time: 0.0928
INFO - 2025-09-12 09:59:59 --> Config Class Initialized
INFO - 2025-09-12 09:59:59 --> Hooks Class Initialized
DEBUG - 2025-09-12 09:59:59 --> UTF-8 Support Enabled
INFO - 2025-09-12 09:59:59 --> Utf8 Class Initialized
INFO - 2025-09-12 09:59:59 --> URI Class Initialized
DEBUG - 2025-09-12 09:59:59 --> No URI present. Default controller set.
INFO - 2025-09-12 09:59:59 --> Router Class Initialized
INFO - 2025-09-12 09:59:59 --> Output Class Initialized
INFO - 2025-09-12 09:59:59 --> Security Class Initialized
DEBUG - 2025-09-12 09:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 09:59:59 --> CSRF cookie sent
INFO - 2025-09-12 09:59:59 --> Input Class Initialized
INFO - 2025-09-12 09:59:59 --> Language Class Initialized
INFO - 2025-09-12 09:59:59 --> Loader Class Initialized
INFO - 2025-09-12 09:59:59 --> Helper loaded: url_helper
INFO - 2025-09-12 09:59:59 --> Helper loaded: text_helper
INFO - 2025-09-12 09:59:59 --> Helper loaded: string_helper
INFO - 2025-09-12 09:59:59 --> Helper loaded: form_helper
INFO - 2025-09-12 09:59:59 --> Helper loaded: download_helper
INFO - 2025-09-12 09:59:59 --> Helper loaded: security_helper
INFO - 2025-09-12 09:59:59 --> Database Driver Class Initialized
DEBUG - 2025-09-12 09:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 09:59:59 --> Form Validation Class Initialized
INFO - 2025-09-12 09:59:59 --> Model "User_model" initialized
INFO - 2025-09-12 14:59:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 14:59:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 14:59:59 --> Model "Nav_model" initialized
INFO - 2025-09-12 14:59:59 --> Controller Class Initialized
INFO - 2025-09-12 14:59:59 --> Model "Berita_model" initialized
INFO - 2025-09-12 14:59:59 --> Model "Galeri_model" initialized
INFO - 2025-09-12 14:59:59 --> Model "Video_model" initialized
INFO - 2025-09-12 14:59:59 --> Model "Agenda_model" initialized
INFO - 2025-09-12 14:59:59 --> Model "Tautan_model" initialized
INFO - 2025-09-12 14:59:59 --> Model "Mitra_model" initialized
INFO - 2025-09-12 14:59:59 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 14:59:59 --> Model "Prodi_model" initialized
INFO - 2025-09-12 14:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 14:59:59 --> Pagination Class Initialized
INFO - 2025-09-12 14:59:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 14:59:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 14:59:59 --> Model "Log_model" initialized
INFO - 2025-09-12 14:59:59 --> Final output sent to browser
DEBUG - 2025-09-12 14:59:59 --> Total execution time: 0.1212
INFO - 2025-09-12 10:04:09 --> Config Class Initialized
INFO - 2025-09-12 10:04:09 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:04:09 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:04:09 --> Utf8 Class Initialized
INFO - 2025-09-12 10:04:09 --> URI Class Initialized
DEBUG - 2025-09-12 10:04:09 --> No URI present. Default controller set.
INFO - 2025-09-12 10:04:09 --> Router Class Initialized
INFO - 2025-09-12 10:04:09 --> Output Class Initialized
INFO - 2025-09-12 10:04:09 --> Security Class Initialized
DEBUG - 2025-09-12 10:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:04:09 --> CSRF cookie sent
INFO - 2025-09-12 10:04:09 --> Input Class Initialized
INFO - 2025-09-12 10:04:09 --> Language Class Initialized
INFO - 2025-09-12 10:04:09 --> Loader Class Initialized
INFO - 2025-09-12 10:04:09 --> Helper loaded: url_helper
INFO - 2025-09-12 10:04:09 --> Helper loaded: text_helper
INFO - 2025-09-12 10:04:09 --> Helper loaded: string_helper
INFO - 2025-09-12 10:04:09 --> Helper loaded: form_helper
INFO - 2025-09-12 10:04:09 --> Helper loaded: download_helper
INFO - 2025-09-12 10:04:09 --> Helper loaded: security_helper
INFO - 2025-09-12 10:04:09 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:04:09 --> Form Validation Class Initialized
INFO - 2025-09-12 10:04:09 --> Model "User_model" initialized
INFO - 2025-09-12 15:04:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:04:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:04:09 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:04:09 --> Controller Class Initialized
INFO - 2025-09-12 15:04:09 --> Model "Berita_model" initialized
INFO - 2025-09-12 15:04:09 --> Model "Galeri_model" initialized
INFO - 2025-09-12 15:04:09 --> Model "Video_model" initialized
INFO - 2025-09-12 15:04:09 --> Model "Agenda_model" initialized
INFO - 2025-09-12 15:04:09 --> Model "Tautan_model" initialized
INFO - 2025-09-12 15:04:09 --> Model "Mitra_model" initialized
INFO - 2025-09-12 15:04:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 15:04:09 --> Model "Prodi_model" initialized
INFO - 2025-09-12 15:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 15:04:09 --> Pagination Class Initialized
INFO - 2025-09-12 15:04:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 15:04:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:04:09 --> Model "Log_model" initialized
INFO - 2025-09-12 15:04:09 --> Final output sent to browser
DEBUG - 2025-09-12 15:04:09 --> Total execution time: 0.1199
INFO - 2025-09-12 10:06:30 --> Config Class Initialized
INFO - 2025-09-12 10:06:30 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:06:30 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:06:30 --> Utf8 Class Initialized
INFO - 2025-09-12 10:06:30 --> URI Class Initialized
INFO - 2025-09-12 10:06:30 --> Router Class Initialized
INFO - 2025-09-12 10:06:30 --> Output Class Initialized
INFO - 2025-09-12 10:06:30 --> Security Class Initialized
DEBUG - 2025-09-12 10:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:06:30 --> CSRF cookie sent
INFO - 2025-09-12 10:06:30 --> Input Class Initialized
INFO - 2025-09-12 10:06:30 --> Language Class Initialized
INFO - 2025-09-12 10:06:30 --> Loader Class Initialized
INFO - 2025-09-12 10:06:30 --> Helper loaded: url_helper
INFO - 2025-09-12 10:06:30 --> Helper loaded: text_helper
INFO - 2025-09-12 10:06:30 --> Helper loaded: string_helper
INFO - 2025-09-12 10:06:30 --> Helper loaded: form_helper
INFO - 2025-09-12 10:06:30 --> Helper loaded: download_helper
INFO - 2025-09-12 10:06:30 --> Helper loaded: security_helper
INFO - 2025-09-12 10:06:30 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:06:31 --> Form Validation Class Initialized
INFO - 2025-09-12 10:06:31 --> Model "User_model" initialized
INFO - 2025-09-12 15:06:31 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:06:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:06:31 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:06:31 --> Controller Class Initialized
INFO - 2025-09-12 15:06:31 --> Model "Sdm_model" initialized
INFO - 2025-09-12 15:06:31 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-12 15:06:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-09-12 15:06:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:06:31 --> Model "Log_model" initialized
INFO - 2025-09-12 15:06:31 --> Final output sent to browser
DEBUG - 2025-09-12 15:06:31 --> Total execution time: 0.2595
INFO - 2025-09-12 10:06:40 --> Config Class Initialized
INFO - 2025-09-12 10:06:40 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:06:40 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:06:40 --> Utf8 Class Initialized
INFO - 2025-09-12 10:06:40 --> URI Class Initialized
INFO - 2025-09-12 10:06:40 --> Router Class Initialized
INFO - 2025-09-12 10:06:40 --> Output Class Initialized
INFO - 2025-09-12 10:06:40 --> Security Class Initialized
DEBUG - 2025-09-12 10:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:06:40 --> CSRF cookie sent
INFO - 2025-09-12 10:06:40 --> Input Class Initialized
INFO - 2025-09-12 10:06:40 --> Language Class Initialized
INFO - 2025-09-12 10:06:40 --> Loader Class Initialized
INFO - 2025-09-12 10:06:40 --> Helper loaded: url_helper
INFO - 2025-09-12 10:06:40 --> Helper loaded: text_helper
INFO - 2025-09-12 10:06:40 --> Helper loaded: string_helper
INFO - 2025-09-12 10:06:40 --> Helper loaded: form_helper
INFO - 2025-09-12 10:06:40 --> Helper loaded: download_helper
INFO - 2025-09-12 10:06:40 --> Helper loaded: security_helper
INFO - 2025-09-12 10:06:40 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:06:40 --> Form Validation Class Initialized
INFO - 2025-09-12 10:06:40 --> Model "User_model" initialized
INFO - 2025-09-12 15:06:40 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:06:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:06:40 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:06:40 --> Controller Class Initialized
INFO - 2025-09-12 15:06:40 --> Model "Sdm_model" initialized
INFO - 2025-09-12 15:06:40 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-12 15:06:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2025-09-12 15:06:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:06:40 --> Model "Log_model" initialized
INFO - 2025-09-12 15:06:40 --> Final output sent to browser
DEBUG - 2025-09-12 15:06:40 --> Total execution time: 0.0836
INFO - 2025-09-12 10:06:45 --> Config Class Initialized
INFO - 2025-09-12 10:06:45 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:06:45 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:06:45 --> Utf8 Class Initialized
INFO - 2025-09-12 10:06:45 --> URI Class Initialized
INFO - 2025-09-12 10:06:45 --> Router Class Initialized
INFO - 2025-09-12 10:06:45 --> Output Class Initialized
INFO - 2025-09-12 10:06:45 --> Security Class Initialized
DEBUG - 2025-09-12 10:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:06:45 --> CSRF cookie sent
INFO - 2025-09-12 10:06:45 --> Input Class Initialized
INFO - 2025-09-12 10:06:45 --> Language Class Initialized
INFO - 2025-09-12 10:06:45 --> Loader Class Initialized
INFO - 2025-09-12 10:06:45 --> Helper loaded: url_helper
INFO - 2025-09-12 10:06:45 --> Helper loaded: text_helper
INFO - 2025-09-12 10:06:45 --> Helper loaded: string_helper
INFO - 2025-09-12 10:06:45 --> Helper loaded: form_helper
INFO - 2025-09-12 10:06:45 --> Helper loaded: download_helper
INFO - 2025-09-12 10:06:45 --> Helper loaded: security_helper
INFO - 2025-09-12 10:06:45 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:06:45 --> Form Validation Class Initialized
INFO - 2025-09-12 10:06:45 --> Model "User_model" initialized
INFO - 2025-09-12 15:06:45 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:06:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:06:45 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:06:45 --> Controller Class Initialized
INFO - 2025-09-12 15:06:45 --> Model "Sdm_model" initialized
INFO - 2025-09-12 15:06:45 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-12 15:06:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-09-12 15:06:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:06:45 --> Model "Log_model" initialized
INFO - 2025-09-12 15:06:45 --> Final output sent to browser
DEBUG - 2025-09-12 15:06:45 --> Total execution time: 0.0592
INFO - 2025-09-12 10:06:50 --> Config Class Initialized
INFO - 2025-09-12 10:06:50 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:06:50 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:06:50 --> Utf8 Class Initialized
INFO - 2025-09-12 10:06:50 --> URI Class Initialized
INFO - 2025-09-12 10:06:50 --> Router Class Initialized
INFO - 2025-09-12 10:06:50 --> Output Class Initialized
INFO - 2025-09-12 10:06:50 --> Security Class Initialized
DEBUG - 2025-09-12 10:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:06:50 --> CSRF cookie sent
INFO - 2025-09-12 10:06:50 --> Input Class Initialized
INFO - 2025-09-12 10:06:50 --> Language Class Initialized
INFO - 2025-09-12 10:06:50 --> Loader Class Initialized
INFO - 2025-09-12 10:06:50 --> Helper loaded: url_helper
INFO - 2025-09-12 10:06:50 --> Helper loaded: text_helper
INFO - 2025-09-12 10:06:50 --> Helper loaded: string_helper
INFO - 2025-09-12 10:06:50 --> Helper loaded: form_helper
INFO - 2025-09-12 10:06:50 --> Helper loaded: download_helper
INFO - 2025-09-12 10:06:50 --> Helper loaded: security_helper
INFO - 2025-09-12 10:06:50 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:06:50 --> Form Validation Class Initialized
INFO - 2025-09-12 10:06:50 --> Model "User_model" initialized
INFO - 2025-09-12 15:06:50 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:06:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:06:50 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:06:50 --> Controller Class Initialized
INFO - 2025-09-12 15:06:50 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 15:06:50 --> Model "Prodi_model" initialized
INFO - 2025-09-12 15:06:50 --> Model "Sdm_model" initialized
INFO - 2025-09-12 15:06:50 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-12 15:06:50 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 0
ERROR - 2025-09-12 15:06:50 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-12 15:06:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-12 15:06:50 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-12 15:06:50 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-12 15:06:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-12 15:06:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:06:50 --> Model "Log_model" initialized
INFO - 2025-09-12 15:06:50 --> Final output sent to browser
DEBUG - 2025-09-12 15:06:50 --> Total execution time: 0.0725
INFO - 2025-09-12 10:07:00 --> Config Class Initialized
INFO - 2025-09-12 10:07:00 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:07:00 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:07:00 --> Utf8 Class Initialized
INFO - 2025-09-12 10:07:00 --> URI Class Initialized
INFO - 2025-09-12 10:07:00 --> Router Class Initialized
INFO - 2025-09-12 10:07:00 --> Output Class Initialized
INFO - 2025-09-12 10:07:00 --> Security Class Initialized
DEBUG - 2025-09-12 10:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:07:00 --> CSRF cookie sent
INFO - 2025-09-12 10:07:00 --> Input Class Initialized
INFO - 2025-09-12 10:07:00 --> Language Class Initialized
INFO - 2025-09-12 10:07:00 --> Loader Class Initialized
INFO - 2025-09-12 10:07:00 --> Helper loaded: url_helper
INFO - 2025-09-12 10:07:00 --> Helper loaded: text_helper
INFO - 2025-09-12 10:07:00 --> Helper loaded: string_helper
INFO - 2025-09-12 10:07:00 --> Helper loaded: form_helper
INFO - 2025-09-12 10:07:00 --> Helper loaded: download_helper
INFO - 2025-09-12 10:07:00 --> Helper loaded: security_helper
INFO - 2025-09-12 10:07:00 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:07:00 --> Form Validation Class Initialized
INFO - 2025-09-12 10:07:00 --> Model "User_model" initialized
INFO - 2025-09-12 15:07:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:07:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:07:00 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:07:00 --> Controller Class Initialized
INFO - 2025-09-12 15:07:00 --> Model "Pusat_model" initialized
INFO - 2025-09-12 15:07:00 --> Model "Prodi_model" initialized
INFO - 2025-09-12 15:07:00 --> Model "Sdm_model" initialized
INFO - 2025-09-12 15:07:00 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-12 15:07:00 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-09-12 15:07:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-12 15:07:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:07:00 --> Model "Log_model" initialized
INFO - 2025-09-12 15:07:00 --> Final output sent to browser
DEBUG - 2025-09-12 15:07:00 --> Total execution time: 0.2608
INFO - 2025-09-12 10:07:04 --> Config Class Initialized
INFO - 2025-09-12 10:07:04 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:07:04 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:07:04 --> Utf8 Class Initialized
INFO - 2025-09-12 10:07:04 --> URI Class Initialized
INFO - 2025-09-12 10:07:04 --> Router Class Initialized
INFO - 2025-09-12 10:07:04 --> Output Class Initialized
INFO - 2025-09-12 10:07:04 --> Security Class Initialized
DEBUG - 2025-09-12 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:07:04 --> CSRF cookie sent
INFO - 2025-09-12 10:07:04 --> Input Class Initialized
INFO - 2025-09-12 10:07:04 --> Language Class Initialized
INFO - 2025-09-12 10:07:04 --> Loader Class Initialized
INFO - 2025-09-12 10:07:04 --> Helper loaded: url_helper
INFO - 2025-09-12 10:07:04 --> Helper loaded: text_helper
INFO - 2025-09-12 10:07:04 --> Helper loaded: string_helper
INFO - 2025-09-12 10:07:04 --> Helper loaded: form_helper
INFO - 2025-09-12 10:07:04 --> Helper loaded: download_helper
INFO - 2025-09-12 10:07:04 --> Helper loaded: security_helper
INFO - 2025-09-12 10:07:04 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:07:04 --> Form Validation Class Initialized
INFO - 2025-09-12 10:07:04 --> Model "User_model" initialized
INFO - 2025-09-12 15:07:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:07:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:07:04 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:07:04 --> Controller Class Initialized
INFO - 2025-09-12 15:07:04 --> Model "Sdm_model" initialized
INFO - 2025-09-12 15:07:04 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-12 15:07:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2025-09-12 15:07:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:07:04 --> Model "Log_model" initialized
INFO - 2025-09-12 15:07:04 --> Final output sent to browser
DEBUG - 2025-09-12 15:07:04 --> Total execution time: 0.0670
INFO - 2025-09-12 10:07:09 --> Config Class Initialized
INFO - 2025-09-12 10:07:09 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:07:09 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:07:09 --> Utf8 Class Initialized
INFO - 2025-09-12 10:07:09 --> URI Class Initialized
DEBUG - 2025-09-12 10:07:09 --> No URI present. Default controller set.
INFO - 2025-09-12 10:07:09 --> Router Class Initialized
INFO - 2025-09-12 10:07:09 --> Output Class Initialized
INFO - 2025-09-12 10:07:09 --> Security Class Initialized
DEBUG - 2025-09-12 10:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:07:09 --> CSRF cookie sent
INFO - 2025-09-12 10:07:09 --> Input Class Initialized
INFO - 2025-09-12 10:07:09 --> Language Class Initialized
INFO - 2025-09-12 10:07:09 --> Loader Class Initialized
INFO - 2025-09-12 10:07:09 --> Helper loaded: url_helper
INFO - 2025-09-12 10:07:09 --> Helper loaded: text_helper
INFO - 2025-09-12 10:07:09 --> Helper loaded: string_helper
INFO - 2025-09-12 10:07:09 --> Helper loaded: form_helper
INFO - 2025-09-12 10:07:09 --> Helper loaded: download_helper
INFO - 2025-09-12 10:07:09 --> Helper loaded: security_helper
INFO - 2025-09-12 10:07:09 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:07:09 --> Form Validation Class Initialized
INFO - 2025-09-12 10:07:09 --> Model "User_model" initialized
INFO - 2025-09-12 15:07:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:07:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:07:09 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:07:09 --> Controller Class Initialized
INFO - 2025-09-12 15:07:09 --> Model "Berita_model" initialized
INFO - 2025-09-12 15:07:09 --> Model "Galeri_model" initialized
INFO - 2025-09-12 15:07:09 --> Model "Video_model" initialized
INFO - 2025-09-12 15:07:09 --> Model "Agenda_model" initialized
INFO - 2025-09-12 15:07:09 --> Model "Tautan_model" initialized
INFO - 2025-09-12 15:07:09 --> Model "Mitra_model" initialized
INFO - 2025-09-12 15:07:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 15:07:09 --> Model "Prodi_model" initialized
INFO - 2025-09-12 15:07:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 15:07:09 --> Pagination Class Initialized
INFO - 2025-09-12 15:07:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 15:07:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:07:09 --> Model "Log_model" initialized
INFO - 2025-09-12 15:07:09 --> Final output sent to browser
DEBUG - 2025-09-12 15:07:09 --> Total execution time: 0.0893
INFO - 2025-09-12 10:07:21 --> Config Class Initialized
INFO - 2025-09-12 10:07:21 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:07:21 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:07:21 --> Utf8 Class Initialized
INFO - 2025-09-12 10:07:21 --> URI Class Initialized
INFO - 2025-09-12 10:07:21 --> Router Class Initialized
INFO - 2025-09-12 10:07:21 --> Output Class Initialized
INFO - 2025-09-12 10:07:21 --> Security Class Initialized
DEBUG - 2025-09-12 10:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:07:21 --> CSRF cookie sent
INFO - 2025-09-12 10:07:21 --> Input Class Initialized
INFO - 2025-09-12 10:07:21 --> Language Class Initialized
INFO - 2025-09-12 10:07:21 --> Loader Class Initialized
INFO - 2025-09-12 10:07:21 --> Helper loaded: url_helper
INFO - 2025-09-12 10:07:21 --> Helper loaded: text_helper
INFO - 2025-09-12 10:07:21 --> Helper loaded: string_helper
INFO - 2025-09-12 10:07:21 --> Helper loaded: form_helper
INFO - 2025-09-12 10:07:21 --> Helper loaded: download_helper
INFO - 2025-09-12 10:07:21 --> Helper loaded: security_helper
INFO - 2025-09-12 10:07:21 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:07:21 --> Form Validation Class Initialized
INFO - 2025-09-12 10:07:21 --> Model "User_model" initialized
INFO - 2025-09-12 15:07:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:07:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:07:21 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:07:21 --> Controller Class Initialized
INFO - 2025-09-12 15:07:21 --> Model "Pages_model" initialized
INFO - 2025-09-12 15:07:21 --> Model "Berita_model" initialized
INFO - 2025-09-12 15:07:21 --> Model "Download_model" initialized
INFO - 2025-09-12 15:07:22 --> Model "Kategori_download_model" initialized
INFO - 2025-09-12 15:07:22 --> Model "Jenis_download_model" initialized
INFO - 2025-09-12 15:07:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-12 15:07:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:07:22 --> Model "Log_model" initialized
INFO - 2025-09-12 15:07:22 --> Final output sent to browser
DEBUG - 2025-09-12 15:07:22 --> Total execution time: 0.3587
INFO - 2025-09-12 10:07:29 --> Config Class Initialized
INFO - 2025-09-12 10:07:29 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:07:29 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:07:29 --> Utf8 Class Initialized
INFO - 2025-09-12 10:07:29 --> URI Class Initialized
INFO - 2025-09-12 10:07:29 --> Router Class Initialized
INFO - 2025-09-12 10:07:29 --> Output Class Initialized
INFO - 2025-09-12 10:07:29 --> Security Class Initialized
DEBUG - 2025-09-12 10:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:07:29 --> CSRF cookie sent
INFO - 2025-09-12 10:07:29 --> Input Class Initialized
INFO - 2025-09-12 10:07:29 --> Language Class Initialized
INFO - 2025-09-12 10:07:29 --> Loader Class Initialized
INFO - 2025-09-12 10:07:29 --> Helper loaded: url_helper
INFO - 2025-09-12 10:07:29 --> Helper loaded: text_helper
INFO - 2025-09-12 10:07:29 --> Helper loaded: string_helper
INFO - 2025-09-12 10:07:29 --> Helper loaded: form_helper
INFO - 2025-09-12 10:07:29 --> Helper loaded: download_helper
INFO - 2025-09-12 10:07:29 --> Helper loaded: security_helper
INFO - 2025-09-12 10:07:29 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:07:29 --> Form Validation Class Initialized
INFO - 2025-09-12 10:07:29 --> Model "User_model" initialized
INFO - 2025-09-12 15:07:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:07:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:07:29 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:07:29 --> Controller Class Initialized
INFO - 2025-09-12 15:07:29 --> Model "Berita_model" initialized
INFO - 2025-09-12 15:07:29 --> Model "Galeri_model" initialized
INFO - 2025-09-12 15:07:29 --> Model "Video_model" initialized
INFO - 2025-09-12 15:07:29 --> Model "Agenda_model" initialized
INFO - 2025-09-12 15:07:29 --> Model "Tautan_model" initialized
INFO - 2025-09-12 15:07:29 --> Model "Mitra_model" initialized
INFO - 2025-09-12 15:07:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 15:07:29 --> Model "Prodi_model" initialized
INFO - 2025-09-12 15:07:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-12 15:07:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:07:29 --> Model "Log_model" initialized
INFO - 2025-09-12 15:07:29 --> Final output sent to browser
DEBUG - 2025-09-12 15:07:29 --> Total execution time: 0.0583
INFO - 2025-09-12 10:07:31 --> Config Class Initialized
INFO - 2025-09-12 10:07:31 --> Hooks Class Initialized
DEBUG - 2025-09-12 10:07:31 --> UTF-8 Support Enabled
INFO - 2025-09-12 10:07:31 --> Utf8 Class Initialized
INFO - 2025-09-12 10:07:31 --> URI Class Initialized
DEBUG - 2025-09-12 10:07:31 --> No URI present. Default controller set.
INFO - 2025-09-12 10:07:31 --> Router Class Initialized
INFO - 2025-09-12 10:07:31 --> Output Class Initialized
INFO - 2025-09-12 10:07:31 --> Security Class Initialized
DEBUG - 2025-09-12 10:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-12 10:07:31 --> CSRF cookie sent
INFO - 2025-09-12 10:07:31 --> Input Class Initialized
INFO - 2025-09-12 10:07:31 --> Language Class Initialized
INFO - 2025-09-12 10:07:31 --> Loader Class Initialized
INFO - 2025-09-12 10:07:31 --> Helper loaded: url_helper
INFO - 2025-09-12 10:07:31 --> Helper loaded: text_helper
INFO - 2025-09-12 10:07:31 --> Helper loaded: string_helper
INFO - 2025-09-12 10:07:31 --> Helper loaded: form_helper
INFO - 2025-09-12 10:07:31 --> Helper loaded: download_helper
INFO - 2025-09-12 10:07:31 --> Helper loaded: security_helper
INFO - 2025-09-12 10:07:31 --> Database Driver Class Initialized
DEBUG - 2025-09-12 10:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-12 10:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-12 10:07:31 --> Form Validation Class Initialized
INFO - 2025-09-12 10:07:31 --> Model "User_model" initialized
INFO - 2025-09-12 15:07:31 --> Model "Kunjungan_model" initialized
INFO - 2025-09-12 15:07:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-12 15:07:31 --> Model "Nav_model" initialized
INFO - 2025-09-12 15:07:31 --> Controller Class Initialized
INFO - 2025-09-12 15:07:31 --> Model "Berita_model" initialized
INFO - 2025-09-12 15:07:31 --> Model "Galeri_model" initialized
INFO - 2025-09-12 15:07:31 --> Model "Video_model" initialized
INFO - 2025-09-12 15:07:31 --> Model "Agenda_model" initialized
INFO - 2025-09-12 15:07:31 --> Model "Tautan_model" initialized
INFO - 2025-09-12 15:07:31 --> Model "Mitra_model" initialized
INFO - 2025-09-12 15:07:31 --> Model "Jurusan_model" initialized
INFO - 2025-09-12 15:07:31 --> Model "Prodi_model" initialized
INFO - 2025-09-12 15:07:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-12 15:07:31 --> Pagination Class Initialized
INFO - 2025-09-12 15:07:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-12 15:07:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-12 15:07:31 --> Model "Log_model" initialized
INFO - 2025-09-12 15:07:31 --> Final output sent to browser
DEBUG - 2025-09-12 15:07:31 --> Total execution time: 0.1221
