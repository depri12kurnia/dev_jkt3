<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-09-18 03:43:20 --> Config Class Initialized
INFO - 2025-09-18 03:43:20 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:43:20 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:43:20 --> Utf8 Class Initialized
INFO - 2025-09-18 03:43:20 --> URI Class Initialized
DEBUG - 2025-09-18 03:43:20 --> No URI present. Default controller set.
INFO - 2025-09-18 03:43:20 --> Router Class Initialized
INFO - 2025-09-18 03:43:21 --> Output Class Initialized
INFO - 2025-09-18 03:43:21 --> Security Class Initialized
DEBUG - 2025-09-18 03:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:43:21 --> CSRF cookie sent
INFO - 2025-09-18 03:43:21 --> Input Class Initialized
INFO - 2025-09-18 03:43:21 --> Language Class Initialized
INFO - 2025-09-18 03:43:21 --> Loader Class Initialized
INFO - 2025-09-18 03:43:21 --> Helper loaded: url_helper
INFO - 2025-09-18 03:43:21 --> Helper loaded: text_helper
INFO - 2025-09-18 03:43:21 --> Helper loaded: string_helper
INFO - 2025-09-18 03:43:21 --> Helper loaded: form_helper
INFO - 2025-09-18 03:43:21 --> Helper loaded: download_helper
INFO - 2025-09-18 03:43:21 --> Helper loaded: security_helper
INFO - 2025-09-18 03:43:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:43:21 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:43:22 --> Form Validation Class Initialized
INFO - 2025-09-18 03:43:22 --> Model "User_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:43:22 --> Controller Class Initialized
INFO - 2025-09-18 08:43:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Video_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:43:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:43:22 --> Pagination Class Initialized
INFO - 2025-09-18 08:43:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:43:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:43:24 --> Model "Log_model" initialized
INFO - 2025-09-18 08:43:24 --> Final output sent to browser
DEBUG - 2025-09-18 08:43:24 --> Total execution time: 4.7213
INFO - 2025-09-18 03:43:58 --> Config Class Initialized
INFO - 2025-09-18 03:43:58 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:43:58 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:43:58 --> Utf8 Class Initialized
INFO - 2025-09-18 03:43:58 --> URI Class Initialized
DEBUG - 2025-09-18 03:43:58 --> No URI present. Default controller set.
INFO - 2025-09-18 03:43:58 --> Router Class Initialized
INFO - 2025-09-18 03:43:58 --> Output Class Initialized
INFO - 2025-09-18 03:43:58 --> Security Class Initialized
DEBUG - 2025-09-18 03:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:43:58 --> CSRF cookie sent
INFO - 2025-09-18 03:43:58 --> Input Class Initialized
INFO - 2025-09-18 03:43:58 --> Language Class Initialized
INFO - 2025-09-18 03:43:58 --> Loader Class Initialized
INFO - 2025-09-18 03:43:58 --> Helper loaded: url_helper
INFO - 2025-09-18 03:43:58 --> Helper loaded: text_helper
INFO - 2025-09-18 03:43:58 --> Helper loaded: string_helper
INFO - 2025-09-18 03:43:58 --> Helper loaded: form_helper
INFO - 2025-09-18 03:43:58 --> Helper loaded: download_helper
INFO - 2025-09-18 03:43:58 --> Helper loaded: security_helper
INFO - 2025-09-18 03:43:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:43:58 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:43:58 --> Form Validation Class Initialized
INFO - 2025-09-18 03:43:58 --> Model "User_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:43:58 --> Controller Class Initialized
INFO - 2025-09-18 08:43:58 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Video_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:43:58 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:43:58 --> Pagination Class Initialized
INFO - 2025-09-18 08:43:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:43:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:43:58 --> Model "Log_model" initialized
INFO - 2025-09-18 08:43:58 --> Final output sent to browser
DEBUG - 2025-09-18 08:43:58 --> Total execution time: 0.2053
INFO - 2025-09-18 03:44:11 --> Config Class Initialized
INFO - 2025-09-18 03:44:11 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:44:11 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:44:11 --> Utf8 Class Initialized
INFO - 2025-09-18 03:44:11 --> URI Class Initialized
DEBUG - 2025-09-18 03:44:11 --> No URI present. Default controller set.
INFO - 2025-09-18 03:44:11 --> Router Class Initialized
INFO - 2025-09-18 03:44:11 --> Output Class Initialized
INFO - 2025-09-18 03:44:11 --> Security Class Initialized
DEBUG - 2025-09-18 03:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:44:11 --> CSRF cookie sent
INFO - 2025-09-18 03:44:11 --> Input Class Initialized
INFO - 2025-09-18 03:44:11 --> Language Class Initialized
INFO - 2025-09-18 03:44:11 --> Loader Class Initialized
INFO - 2025-09-18 03:44:11 --> Helper loaded: url_helper
INFO - 2025-09-18 03:44:11 --> Helper loaded: text_helper
INFO - 2025-09-18 03:44:11 --> Helper loaded: string_helper
INFO - 2025-09-18 03:44:11 --> Helper loaded: form_helper
INFO - 2025-09-18 03:44:11 --> Helper loaded: download_helper
INFO - 2025-09-18 03:44:11 --> Helper loaded: security_helper
INFO - 2025-09-18 03:44:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:44:11 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:44:11 --> Form Validation Class Initialized
INFO - 2025-09-18 03:44:11 --> Model "User_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:44:11 --> Controller Class Initialized
INFO - 2025-09-18 08:44:11 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Video_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:44:11 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:44:11 --> Pagination Class Initialized
INFO - 2025-09-18 08:44:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:44:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:44:11 --> Model "Log_model" initialized
INFO - 2025-09-18 08:44:11 --> Final output sent to browser
DEBUG - 2025-09-18 08:44:11 --> Total execution time: 0.1936
INFO - 2025-09-18 03:44:27 --> Config Class Initialized
INFO - 2025-09-18 03:44:27 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:44:27 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:44:27 --> Utf8 Class Initialized
INFO - 2025-09-18 03:44:27 --> URI Class Initialized
DEBUG - 2025-09-18 03:44:27 --> No URI present. Default controller set.
INFO - 2025-09-18 03:44:27 --> Router Class Initialized
INFO - 2025-09-18 03:44:27 --> Output Class Initialized
INFO - 2025-09-18 03:44:27 --> Security Class Initialized
DEBUG - 2025-09-18 03:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:44:27 --> CSRF cookie sent
INFO - 2025-09-18 03:44:27 --> Input Class Initialized
INFO - 2025-09-18 03:44:27 --> Language Class Initialized
INFO - 2025-09-18 03:44:27 --> Loader Class Initialized
INFO - 2025-09-18 03:44:27 --> Helper loaded: url_helper
INFO - 2025-09-18 03:44:27 --> Helper loaded: text_helper
INFO - 2025-09-18 03:44:27 --> Helper loaded: string_helper
INFO - 2025-09-18 03:44:27 --> Helper loaded: form_helper
INFO - 2025-09-18 03:44:27 --> Helper loaded: download_helper
INFO - 2025-09-18 03:44:27 --> Helper loaded: security_helper
INFO - 2025-09-18 03:44:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:44:27 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:44:27 --> Form Validation Class Initialized
INFO - 2025-09-18 03:44:27 --> Model "User_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:44:27 --> Controller Class Initialized
INFO - 2025-09-18 08:44:27 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Video_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:44:27 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:44:27 --> Pagination Class Initialized
INFO - 2025-09-18 08:44:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:44:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:44:27 --> Model "Log_model" initialized
INFO - 2025-09-18 08:44:27 --> Final output sent to browser
DEBUG - 2025-09-18 08:44:27 --> Total execution time: 0.1597
INFO - 2025-09-18 03:44:32 --> Config Class Initialized
INFO - 2025-09-18 03:44:32 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:44:32 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:44:32 --> Utf8 Class Initialized
INFO - 2025-09-18 03:44:32 --> URI Class Initialized
DEBUG - 2025-09-18 03:44:32 --> No URI present. Default controller set.
INFO - 2025-09-18 03:44:32 --> Router Class Initialized
INFO - 2025-09-18 03:44:32 --> Output Class Initialized
INFO - 2025-09-18 03:44:32 --> Security Class Initialized
DEBUG - 2025-09-18 03:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:44:32 --> CSRF cookie sent
INFO - 2025-09-18 03:44:32 --> Input Class Initialized
INFO - 2025-09-18 03:44:32 --> Language Class Initialized
INFO - 2025-09-18 03:44:32 --> Loader Class Initialized
INFO - 2025-09-18 03:44:32 --> Helper loaded: url_helper
INFO - 2025-09-18 03:44:32 --> Helper loaded: text_helper
INFO - 2025-09-18 03:44:32 --> Helper loaded: string_helper
INFO - 2025-09-18 03:44:32 --> Helper loaded: form_helper
INFO - 2025-09-18 03:44:32 --> Helper loaded: download_helper
INFO - 2025-09-18 03:44:32 --> Helper loaded: security_helper
INFO - 2025-09-18 03:44:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:44:32 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:44:32 --> Form Validation Class Initialized
INFO - 2025-09-18 03:44:32 --> Model "User_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:44:32 --> Controller Class Initialized
INFO - 2025-09-18 08:44:32 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Video_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:44:32 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:44:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:44:32 --> Pagination Class Initialized
INFO - 2025-09-18 08:44:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:44:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:44:32 --> Model "Log_model" initialized
INFO - 2025-09-18 08:44:32 --> Final output sent to browser
DEBUG - 2025-09-18 08:44:32 --> Total execution time: 0.1979
INFO - 2025-09-18 03:45:17 --> Config Class Initialized
INFO - 2025-09-18 03:45:17 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:45:17 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:45:17 --> Utf8 Class Initialized
INFO - 2025-09-18 03:45:17 --> URI Class Initialized
DEBUG - 2025-09-18 03:45:17 --> No URI present. Default controller set.
INFO - 2025-09-18 03:45:17 --> Router Class Initialized
INFO - 2025-09-18 03:45:17 --> Output Class Initialized
INFO - 2025-09-18 03:45:17 --> Security Class Initialized
DEBUG - 2025-09-18 03:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:45:17 --> CSRF cookie sent
INFO - 2025-09-18 03:45:17 --> Input Class Initialized
INFO - 2025-09-18 03:45:17 --> Language Class Initialized
INFO - 2025-09-18 03:45:17 --> Loader Class Initialized
INFO - 2025-09-18 03:45:18 --> Helper loaded: url_helper
INFO - 2025-09-18 03:45:18 --> Helper loaded: text_helper
INFO - 2025-09-18 03:45:18 --> Helper loaded: string_helper
INFO - 2025-09-18 03:45:18 --> Helper loaded: form_helper
INFO - 2025-09-18 03:45:18 --> Helper loaded: download_helper
INFO - 2025-09-18 03:45:18 --> Helper loaded: security_helper
INFO - 2025-09-18 03:45:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:45:18 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:45:18 --> Form Validation Class Initialized
INFO - 2025-09-18 03:45:18 --> Model "User_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:45:18 --> Controller Class Initialized
INFO - 2025-09-18 08:45:18 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Video_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:45:18 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:45:18 --> Pagination Class Initialized
INFO - 2025-09-18 08:45:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:45:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:45:18 --> Model "Log_model" initialized
INFO - 2025-09-18 08:45:18 --> Final output sent to browser
DEBUG - 2025-09-18 08:45:18 --> Total execution time: 0.2811
INFO - 2025-09-18 03:45:23 --> Config Class Initialized
INFO - 2025-09-18 03:45:23 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:45:23 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:45:23 --> Utf8 Class Initialized
INFO - 2025-09-18 03:45:23 --> URI Class Initialized
DEBUG - 2025-09-18 03:45:23 --> No URI present. Default controller set.
INFO - 2025-09-18 03:45:23 --> Router Class Initialized
INFO - 2025-09-18 03:45:23 --> Output Class Initialized
INFO - 2025-09-18 03:45:23 --> Security Class Initialized
DEBUG - 2025-09-18 03:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:45:23 --> CSRF cookie sent
INFO - 2025-09-18 03:45:23 --> Input Class Initialized
INFO - 2025-09-18 03:45:23 --> Language Class Initialized
INFO - 2025-09-18 03:45:23 --> Loader Class Initialized
INFO - 2025-09-18 03:45:23 --> Helper loaded: url_helper
INFO - 2025-09-18 03:45:23 --> Helper loaded: text_helper
INFO - 2025-09-18 03:45:23 --> Helper loaded: string_helper
INFO - 2025-09-18 03:45:23 --> Helper loaded: form_helper
INFO - 2025-09-18 03:45:23 --> Helper loaded: download_helper
INFO - 2025-09-18 03:45:23 --> Helper loaded: security_helper
INFO - 2025-09-18 03:45:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:45:23 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:45:23 --> Form Validation Class Initialized
INFO - 2025-09-18 03:45:23 --> Model "User_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:45:23 --> Controller Class Initialized
INFO - 2025-09-18 08:45:23 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Video_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:45:23 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:45:23 --> Pagination Class Initialized
INFO - 2025-09-18 08:45:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:45:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:45:23 --> Model "Log_model" initialized
INFO - 2025-09-18 08:45:23 --> Final output sent to browser
DEBUG - 2025-09-18 08:45:23 --> Total execution time: 0.2142
INFO - 2025-09-18 03:45:36 --> Config Class Initialized
INFO - 2025-09-18 03:45:36 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:45:36 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:45:36 --> Utf8 Class Initialized
INFO - 2025-09-18 03:45:36 --> URI Class Initialized
DEBUG - 2025-09-18 03:45:36 --> No URI present. Default controller set.
INFO - 2025-09-18 03:45:36 --> Router Class Initialized
INFO - 2025-09-18 03:45:36 --> Output Class Initialized
INFO - 2025-09-18 03:45:36 --> Security Class Initialized
DEBUG - 2025-09-18 03:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:45:36 --> CSRF cookie sent
INFO - 2025-09-18 03:45:36 --> Input Class Initialized
INFO - 2025-09-18 03:45:36 --> Language Class Initialized
INFO - 2025-09-18 03:45:36 --> Loader Class Initialized
INFO - 2025-09-18 03:45:36 --> Helper loaded: url_helper
INFO - 2025-09-18 03:45:36 --> Helper loaded: text_helper
INFO - 2025-09-18 03:45:36 --> Helper loaded: string_helper
INFO - 2025-09-18 03:45:36 --> Helper loaded: form_helper
INFO - 2025-09-18 03:45:36 --> Helper loaded: download_helper
INFO - 2025-09-18 03:45:36 --> Helper loaded: security_helper
INFO - 2025-09-18 03:45:36 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:45:36 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:45:36 --> Form Validation Class Initialized
INFO - 2025-09-18 03:45:36 --> Model "User_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:45:36 --> Controller Class Initialized
INFO - 2025-09-18 08:45:36 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Video_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:45:36 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:45:36 --> Pagination Class Initialized
INFO - 2025-09-18 08:45:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:45:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:45:36 --> Model "Log_model" initialized
INFO - 2025-09-18 08:45:36 --> Final output sent to browser
DEBUG - 2025-09-18 08:45:36 --> Total execution time: 0.3127
INFO - 2025-09-18 03:45:38 --> Config Class Initialized
INFO - 2025-09-18 03:45:38 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:45:38 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:45:38 --> Utf8 Class Initialized
INFO - 2025-09-18 03:45:38 --> URI Class Initialized
DEBUG - 2025-09-18 03:45:38 --> No URI present. Default controller set.
INFO - 2025-09-18 03:45:38 --> Router Class Initialized
INFO - 2025-09-18 03:45:38 --> Output Class Initialized
INFO - 2025-09-18 03:45:38 --> Security Class Initialized
DEBUG - 2025-09-18 03:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:45:38 --> CSRF cookie sent
INFO - 2025-09-18 03:45:38 --> Input Class Initialized
INFO - 2025-09-18 03:45:38 --> Language Class Initialized
INFO - 2025-09-18 03:45:38 --> Loader Class Initialized
INFO - 2025-09-18 03:45:38 --> Helper loaded: url_helper
INFO - 2025-09-18 03:45:38 --> Helper loaded: text_helper
INFO - 2025-09-18 03:45:38 --> Helper loaded: string_helper
INFO - 2025-09-18 03:45:38 --> Helper loaded: form_helper
INFO - 2025-09-18 03:45:38 --> Helper loaded: download_helper
INFO - 2025-09-18 03:45:38 --> Helper loaded: security_helper
INFO - 2025-09-18 03:45:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:45:38 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:45:38 --> Form Validation Class Initialized
INFO - 2025-09-18 03:45:38 --> Model "User_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:45:38 --> Controller Class Initialized
INFO - 2025-09-18 08:45:38 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Video_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:45:38 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:45:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:45:38 --> Pagination Class Initialized
INFO - 2025-09-18 08:45:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:45:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:45:38 --> Model "Log_model" initialized
INFO - 2025-09-18 08:45:38 --> Final output sent to browser
DEBUG - 2025-09-18 08:45:38 --> Total execution time: 0.2380
INFO - 2025-09-18 03:48:02 --> Config Class Initialized
INFO - 2025-09-18 03:48:02 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:48:02 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:48:02 --> Utf8 Class Initialized
INFO - 2025-09-18 03:48:02 --> URI Class Initialized
DEBUG - 2025-09-18 03:48:02 --> No URI present. Default controller set.
INFO - 2025-09-18 03:48:02 --> Router Class Initialized
INFO - 2025-09-18 03:48:02 --> Output Class Initialized
INFO - 2025-09-18 03:48:02 --> Security Class Initialized
DEBUG - 2025-09-18 03:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:48:02 --> CSRF cookie sent
INFO - 2025-09-18 03:48:02 --> Input Class Initialized
INFO - 2025-09-18 03:48:02 --> Language Class Initialized
INFO - 2025-09-18 03:48:02 --> Loader Class Initialized
INFO - 2025-09-18 03:48:03 --> Helper loaded: url_helper
INFO - 2025-09-18 03:48:03 --> Helper loaded: text_helper
INFO - 2025-09-18 03:48:03 --> Helper loaded: string_helper
INFO - 2025-09-18 03:48:03 --> Helper loaded: form_helper
INFO - 2025-09-18 03:48:03 --> Helper loaded: download_helper
INFO - 2025-09-18 03:48:03 --> Helper loaded: security_helper
INFO - 2025-09-18 03:48:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:48:03 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:48:03 --> Form Validation Class Initialized
INFO - 2025-09-18 03:48:03 --> Model "User_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:48:03 --> Controller Class Initialized
INFO - 2025-09-18 08:48:03 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Video_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:48:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:48:03 --> Pagination Class Initialized
INFO - 2025-09-18 08:48:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:48:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:48:03 --> Model "Log_model" initialized
INFO - 2025-09-18 08:48:03 --> Final output sent to browser
DEBUG - 2025-09-18 08:48:03 --> Total execution time: 0.3821
INFO - 2025-09-18 03:48:49 --> Config Class Initialized
INFO - 2025-09-18 03:48:49 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:48:49 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:48:49 --> Utf8 Class Initialized
INFO - 2025-09-18 03:48:49 --> URI Class Initialized
DEBUG - 2025-09-18 03:48:49 --> No URI present. Default controller set.
INFO - 2025-09-18 03:48:49 --> Router Class Initialized
INFO - 2025-09-18 03:48:49 --> Output Class Initialized
INFO - 2025-09-18 03:48:49 --> Security Class Initialized
DEBUG - 2025-09-18 03:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:48:49 --> CSRF cookie sent
INFO - 2025-09-18 03:48:49 --> Input Class Initialized
INFO - 2025-09-18 03:48:49 --> Language Class Initialized
INFO - 2025-09-18 03:48:49 --> Loader Class Initialized
INFO - 2025-09-18 03:48:49 --> Helper loaded: url_helper
INFO - 2025-09-18 03:48:49 --> Helper loaded: text_helper
INFO - 2025-09-18 03:48:49 --> Helper loaded: string_helper
INFO - 2025-09-18 03:48:49 --> Helper loaded: form_helper
INFO - 2025-09-18 03:48:49 --> Helper loaded: download_helper
INFO - 2025-09-18 03:48:49 --> Helper loaded: security_helper
INFO - 2025-09-18 03:48:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:48:49 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:48:49 --> Form Validation Class Initialized
INFO - 2025-09-18 03:48:49 --> Model "User_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:48:49 --> Controller Class Initialized
INFO - 2025-09-18 08:48:49 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Video_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:48:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:48:49 --> Pagination Class Initialized
INFO - 2025-09-18 08:48:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:48:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:48:50 --> Model "Log_model" initialized
INFO - 2025-09-18 08:48:50 --> Final output sent to browser
DEBUG - 2025-09-18 08:48:50 --> Total execution time: 0.4890
INFO - 2025-09-18 03:48:55 --> Config Class Initialized
INFO - 2025-09-18 03:48:55 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:48:55 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:48:55 --> Utf8 Class Initialized
INFO - 2025-09-18 03:48:55 --> URI Class Initialized
DEBUG - 2025-09-18 03:48:55 --> No URI present. Default controller set.
INFO - 2025-09-18 03:48:55 --> Router Class Initialized
INFO - 2025-09-18 03:48:55 --> Output Class Initialized
INFO - 2025-09-18 03:48:55 --> Security Class Initialized
DEBUG - 2025-09-18 03:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:48:55 --> CSRF cookie sent
INFO - 2025-09-18 03:48:55 --> Input Class Initialized
INFO - 2025-09-18 03:48:55 --> Language Class Initialized
INFO - 2025-09-18 03:48:55 --> Loader Class Initialized
INFO - 2025-09-18 03:48:55 --> Helper loaded: url_helper
INFO - 2025-09-18 03:48:55 --> Helper loaded: text_helper
INFO - 2025-09-18 03:48:55 --> Helper loaded: string_helper
INFO - 2025-09-18 03:48:55 --> Helper loaded: form_helper
INFO - 2025-09-18 03:48:55 --> Helper loaded: download_helper
INFO - 2025-09-18 03:48:55 --> Helper loaded: security_helper
INFO - 2025-09-18 03:48:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:48:55 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:48:55 --> Form Validation Class Initialized
INFO - 2025-09-18 03:48:55 --> Model "User_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:48:55 --> Controller Class Initialized
INFO - 2025-09-18 08:48:55 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Video_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:48:55 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:48:55 --> Pagination Class Initialized
INFO - 2025-09-18 08:48:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:48:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:48:55 --> Model "Log_model" initialized
INFO - 2025-09-18 08:48:55 --> Final output sent to browser
DEBUG - 2025-09-18 08:48:55 --> Total execution time: 0.3048
INFO - 2025-09-18 03:49:03 --> Config Class Initialized
INFO - 2025-09-18 03:49:03 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:49:03 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:49:03 --> Utf8 Class Initialized
INFO - 2025-09-18 03:49:03 --> URI Class Initialized
DEBUG - 2025-09-18 03:49:03 --> No URI present. Default controller set.
INFO - 2025-09-18 03:49:03 --> Router Class Initialized
INFO - 2025-09-18 03:49:03 --> Output Class Initialized
INFO - 2025-09-18 03:49:03 --> Security Class Initialized
DEBUG - 2025-09-18 03:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:49:03 --> CSRF cookie sent
INFO - 2025-09-18 03:49:03 --> Input Class Initialized
INFO - 2025-09-18 03:49:03 --> Language Class Initialized
INFO - 2025-09-18 03:49:03 --> Loader Class Initialized
INFO - 2025-09-18 03:49:03 --> Helper loaded: url_helper
INFO - 2025-09-18 03:49:03 --> Helper loaded: text_helper
INFO - 2025-09-18 03:49:03 --> Helper loaded: string_helper
INFO - 2025-09-18 03:49:03 --> Helper loaded: form_helper
INFO - 2025-09-18 03:49:03 --> Helper loaded: download_helper
INFO - 2025-09-18 03:49:03 --> Helper loaded: security_helper
INFO - 2025-09-18 03:49:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:49:03 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:49:03 --> Form Validation Class Initialized
INFO - 2025-09-18 03:49:03 --> Model "User_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:49:03 --> Controller Class Initialized
INFO - 2025-09-18 08:49:03 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Video_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:49:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:49:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:49:03 --> Pagination Class Initialized
INFO - 2025-09-18 08:49:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:49:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:49:03 --> Model "Log_model" initialized
INFO - 2025-09-18 08:49:04 --> Final output sent to browser
DEBUG - 2025-09-18 08:49:04 --> Total execution time: 0.3044
INFO - 2025-09-18 03:49:18 --> Config Class Initialized
INFO - 2025-09-18 03:49:18 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:49:18 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:49:18 --> Utf8 Class Initialized
INFO - 2025-09-18 03:49:18 --> URI Class Initialized
DEBUG - 2025-09-18 03:49:18 --> No URI present. Default controller set.
INFO - 2025-09-18 03:49:18 --> Router Class Initialized
INFO - 2025-09-18 03:49:18 --> Output Class Initialized
INFO - 2025-09-18 03:49:18 --> Security Class Initialized
DEBUG - 2025-09-18 03:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:49:18 --> CSRF cookie sent
INFO - 2025-09-18 03:49:18 --> Input Class Initialized
INFO - 2025-09-18 03:49:18 --> Language Class Initialized
INFO - 2025-09-18 03:49:18 --> Loader Class Initialized
INFO - 2025-09-18 03:49:18 --> Helper loaded: url_helper
INFO - 2025-09-18 03:49:18 --> Helper loaded: text_helper
INFO - 2025-09-18 03:49:18 --> Helper loaded: string_helper
INFO - 2025-09-18 03:49:18 --> Helper loaded: form_helper
INFO - 2025-09-18 03:49:18 --> Helper loaded: download_helper
INFO - 2025-09-18 03:49:18 --> Helper loaded: security_helper
INFO - 2025-09-18 03:49:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:49:18 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:49:18 --> Form Validation Class Initialized
INFO - 2025-09-18 03:49:18 --> Model "User_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:49:18 --> Controller Class Initialized
INFO - 2025-09-18 08:49:18 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Video_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:49:18 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:49:18 --> Pagination Class Initialized
INFO - 2025-09-18 08:49:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:49:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:49:18 --> Model "Log_model" initialized
INFO - 2025-09-18 08:49:18 --> Final output sent to browser
DEBUG - 2025-09-18 08:49:18 --> Total execution time: 0.3132
INFO - 2025-09-18 03:51:27 --> Config Class Initialized
INFO - 2025-09-18 03:51:27 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:51:27 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:51:27 --> Utf8 Class Initialized
INFO - 2025-09-18 03:51:27 --> URI Class Initialized
DEBUG - 2025-09-18 03:51:27 --> No URI present. Default controller set.
INFO - 2025-09-18 03:51:27 --> Router Class Initialized
INFO - 2025-09-18 03:51:27 --> Output Class Initialized
INFO - 2025-09-18 03:51:27 --> Security Class Initialized
DEBUG - 2025-09-18 03:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:51:27 --> CSRF cookie sent
INFO - 2025-09-18 03:51:27 --> Input Class Initialized
INFO - 2025-09-18 03:51:27 --> Language Class Initialized
INFO - 2025-09-18 03:51:27 --> Loader Class Initialized
INFO - 2025-09-18 03:51:27 --> Helper loaded: url_helper
INFO - 2025-09-18 03:51:27 --> Helper loaded: text_helper
INFO - 2025-09-18 03:51:27 --> Helper loaded: string_helper
INFO - 2025-09-18 03:51:27 --> Helper loaded: form_helper
INFO - 2025-09-18 03:51:27 --> Helper loaded: download_helper
INFO - 2025-09-18 03:51:27 --> Helper loaded: security_helper
INFO - 2025-09-18 03:51:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:51:27 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:51:27 --> Form Validation Class Initialized
INFO - 2025-09-18 03:51:27 --> Model "User_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:51:27 --> Controller Class Initialized
INFO - 2025-09-18 08:51:27 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Video_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:51:27 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:51:27 --> Pagination Class Initialized
INFO - 2025-09-18 08:51:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:51:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:51:27 --> Model "Log_model" initialized
INFO - 2025-09-18 08:51:27 --> Final output sent to browser
DEBUG - 2025-09-18 08:51:27 --> Total execution time: 0.3279
INFO - 2025-09-18 03:51:45 --> Config Class Initialized
INFO - 2025-09-18 03:51:45 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:51:45 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:51:45 --> Utf8 Class Initialized
INFO - 2025-09-18 03:51:45 --> URI Class Initialized
DEBUG - 2025-09-18 03:51:45 --> No URI present. Default controller set.
INFO - 2025-09-18 03:51:45 --> Router Class Initialized
INFO - 2025-09-18 03:51:45 --> Output Class Initialized
INFO - 2025-09-18 03:51:45 --> Security Class Initialized
DEBUG - 2025-09-18 03:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:51:45 --> CSRF cookie sent
INFO - 2025-09-18 03:51:45 --> Input Class Initialized
INFO - 2025-09-18 03:51:45 --> Language Class Initialized
INFO - 2025-09-18 03:51:45 --> Loader Class Initialized
INFO - 2025-09-18 03:51:45 --> Helper loaded: url_helper
INFO - 2025-09-18 03:51:45 --> Helper loaded: text_helper
INFO - 2025-09-18 03:51:45 --> Helper loaded: string_helper
INFO - 2025-09-18 03:51:45 --> Helper loaded: form_helper
INFO - 2025-09-18 03:51:45 --> Helper loaded: download_helper
INFO - 2025-09-18 03:51:45 --> Helper loaded: security_helper
INFO - 2025-09-18 03:51:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:51:45 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:51:45 --> Form Validation Class Initialized
INFO - 2025-09-18 03:51:45 --> Model "User_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:51:45 --> Controller Class Initialized
INFO - 2025-09-18 08:51:45 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Video_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:51:45 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:51:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:51:45 --> Pagination Class Initialized
INFO - 2025-09-18 08:51:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:51:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:51:45 --> Model "Log_model" initialized
INFO - 2025-09-18 08:51:45 --> Final output sent to browser
DEBUG - 2025-09-18 08:51:45 --> Total execution time: 0.3748
INFO - 2025-09-18 03:52:21 --> Config Class Initialized
INFO - 2025-09-18 03:52:21 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:52:21 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:52:21 --> Utf8 Class Initialized
INFO - 2025-09-18 03:52:21 --> URI Class Initialized
DEBUG - 2025-09-18 03:52:21 --> No URI present. Default controller set.
INFO - 2025-09-18 03:52:21 --> Router Class Initialized
INFO - 2025-09-18 03:52:21 --> Output Class Initialized
INFO - 2025-09-18 03:52:21 --> Security Class Initialized
DEBUG - 2025-09-18 03:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:52:21 --> CSRF cookie sent
INFO - 2025-09-18 03:52:21 --> Input Class Initialized
INFO - 2025-09-18 03:52:21 --> Language Class Initialized
INFO - 2025-09-18 03:52:21 --> Loader Class Initialized
INFO - 2025-09-18 03:52:21 --> Helper loaded: url_helper
INFO - 2025-09-18 03:52:21 --> Helper loaded: text_helper
INFO - 2025-09-18 03:52:21 --> Helper loaded: string_helper
INFO - 2025-09-18 03:52:21 --> Helper loaded: form_helper
INFO - 2025-09-18 03:52:21 --> Helper loaded: download_helper
INFO - 2025-09-18 03:52:21 --> Helper loaded: security_helper
INFO - 2025-09-18 03:52:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:52:21 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:52:21 --> Form Validation Class Initialized
INFO - 2025-09-18 03:52:21 --> Model "User_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:52:21 --> Controller Class Initialized
INFO - 2025-09-18 08:52:21 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Video_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:52:21 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:52:21 --> Pagination Class Initialized
INFO - 2025-09-18 08:52:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:52:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:52:21 --> Model "Log_model" initialized
INFO - 2025-09-18 08:52:21 --> Final output sent to browser
DEBUG - 2025-09-18 08:52:21 --> Total execution time: 0.4066
INFO - 2025-09-18 03:52:38 --> Config Class Initialized
INFO - 2025-09-18 03:52:38 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:52:38 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:52:38 --> Utf8 Class Initialized
INFO - 2025-09-18 03:52:38 --> URI Class Initialized
DEBUG - 2025-09-18 03:52:38 --> No URI present. Default controller set.
INFO - 2025-09-18 03:52:38 --> Router Class Initialized
INFO - 2025-09-18 03:52:38 --> Output Class Initialized
INFO - 2025-09-18 03:52:38 --> Security Class Initialized
DEBUG - 2025-09-18 03:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:52:38 --> CSRF cookie sent
INFO - 2025-09-18 03:52:38 --> Input Class Initialized
INFO - 2025-09-18 03:52:38 --> Language Class Initialized
INFO - 2025-09-18 03:52:38 --> Loader Class Initialized
INFO - 2025-09-18 03:52:38 --> Helper loaded: url_helper
INFO - 2025-09-18 03:52:38 --> Helper loaded: text_helper
INFO - 2025-09-18 03:52:38 --> Helper loaded: string_helper
INFO - 2025-09-18 03:52:38 --> Helper loaded: form_helper
INFO - 2025-09-18 03:52:38 --> Helper loaded: download_helper
INFO - 2025-09-18 03:52:38 --> Helper loaded: security_helper
INFO - 2025-09-18 03:52:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:52:38 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:52:38 --> Form Validation Class Initialized
INFO - 2025-09-18 03:52:38 --> Model "User_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:52:38 --> Controller Class Initialized
INFO - 2025-09-18 08:52:38 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Video_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:52:38 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:52:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:52:38 --> Pagination Class Initialized
INFO - 2025-09-18 08:52:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:52:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:52:39 --> Model "Log_model" initialized
INFO - 2025-09-18 08:52:39 --> Final output sent to browser
DEBUG - 2025-09-18 08:52:39 --> Total execution time: 0.3589
INFO - 2025-09-18 03:52:56 --> Config Class Initialized
INFO - 2025-09-18 03:52:56 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:52:56 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:52:56 --> Utf8 Class Initialized
INFO - 2025-09-18 03:52:56 --> URI Class Initialized
DEBUG - 2025-09-18 03:52:56 --> No URI present. Default controller set.
INFO - 2025-09-18 03:52:56 --> Router Class Initialized
INFO - 2025-09-18 03:52:56 --> Output Class Initialized
INFO - 2025-09-18 03:52:56 --> Security Class Initialized
DEBUG - 2025-09-18 03:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:52:56 --> CSRF cookie sent
INFO - 2025-09-18 03:52:56 --> Input Class Initialized
INFO - 2025-09-18 03:52:56 --> Language Class Initialized
INFO - 2025-09-18 03:52:56 --> Loader Class Initialized
INFO - 2025-09-18 03:52:56 --> Helper loaded: url_helper
INFO - 2025-09-18 03:52:56 --> Helper loaded: text_helper
INFO - 2025-09-18 03:52:56 --> Helper loaded: string_helper
INFO - 2025-09-18 03:52:56 --> Helper loaded: form_helper
INFO - 2025-09-18 03:52:56 --> Helper loaded: download_helper
INFO - 2025-09-18 03:52:56 --> Helper loaded: security_helper
INFO - 2025-09-18 03:52:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:52:56 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:52:56 --> Form Validation Class Initialized
INFO - 2025-09-18 03:52:56 --> Model "User_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:52:56 --> Controller Class Initialized
INFO - 2025-09-18 08:52:56 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Video_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:52:56 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:52:56 --> Pagination Class Initialized
INFO - 2025-09-18 08:52:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:52:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:52:56 --> Model "Log_model" initialized
INFO - 2025-09-18 08:52:56 --> Final output sent to browser
DEBUG - 2025-09-18 08:52:56 --> Total execution time: 0.3944
INFO - 2025-09-18 03:53:10 --> Config Class Initialized
INFO - 2025-09-18 03:53:10 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:53:10 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:53:10 --> Utf8 Class Initialized
INFO - 2025-09-18 03:53:10 --> URI Class Initialized
DEBUG - 2025-09-18 03:53:10 --> No URI present. Default controller set.
INFO - 2025-09-18 03:53:10 --> Router Class Initialized
INFO - 2025-09-18 03:53:10 --> Output Class Initialized
INFO - 2025-09-18 03:53:10 --> Security Class Initialized
DEBUG - 2025-09-18 03:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:53:10 --> CSRF cookie sent
INFO - 2025-09-18 03:53:10 --> Input Class Initialized
INFO - 2025-09-18 03:53:10 --> Language Class Initialized
INFO - 2025-09-18 03:53:10 --> Loader Class Initialized
INFO - 2025-09-18 03:53:10 --> Helper loaded: url_helper
INFO - 2025-09-18 03:53:10 --> Helper loaded: text_helper
INFO - 2025-09-18 03:53:10 --> Helper loaded: string_helper
INFO - 2025-09-18 03:53:10 --> Helper loaded: form_helper
INFO - 2025-09-18 03:53:10 --> Helper loaded: download_helper
INFO - 2025-09-18 03:53:10 --> Helper loaded: security_helper
INFO - 2025-09-18 03:53:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:53:10 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:53:10 --> Form Validation Class Initialized
INFO - 2025-09-18 03:53:10 --> Model "User_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:53:10 --> Controller Class Initialized
INFO - 2025-09-18 08:53:10 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Video_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:53:10 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:53:10 --> Pagination Class Initialized
INFO - 2025-09-18 08:53:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:53:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:53:11 --> Model "Log_model" initialized
INFO - 2025-09-18 08:53:11 --> Final output sent to browser
DEBUG - 2025-09-18 08:53:11 --> Total execution time: 0.3539
INFO - 2025-09-18 03:54:07 --> Config Class Initialized
INFO - 2025-09-18 03:54:07 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:54:07 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:54:07 --> Utf8 Class Initialized
INFO - 2025-09-18 03:54:07 --> URI Class Initialized
DEBUG - 2025-09-18 03:54:07 --> No URI present. Default controller set.
INFO - 2025-09-18 03:54:07 --> Router Class Initialized
INFO - 2025-09-18 03:54:07 --> Output Class Initialized
INFO - 2025-09-18 03:54:07 --> Security Class Initialized
DEBUG - 2025-09-18 03:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:54:07 --> CSRF cookie sent
INFO - 2025-09-18 03:54:07 --> Input Class Initialized
INFO - 2025-09-18 03:54:07 --> Language Class Initialized
INFO - 2025-09-18 03:54:07 --> Loader Class Initialized
INFO - 2025-09-18 03:54:07 --> Helper loaded: url_helper
INFO - 2025-09-18 03:54:07 --> Helper loaded: text_helper
INFO - 2025-09-18 03:54:07 --> Helper loaded: string_helper
INFO - 2025-09-18 03:54:07 --> Helper loaded: form_helper
INFO - 2025-09-18 03:54:07 --> Helper loaded: download_helper
INFO - 2025-09-18 03:54:07 --> Helper loaded: security_helper
INFO - 2025-09-18 03:54:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:54:07 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:54:07 --> Form Validation Class Initialized
INFO - 2025-09-18 03:54:07 --> Model "User_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:54:07 --> Controller Class Initialized
INFO - 2025-09-18 08:54:07 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Video_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:54:07 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:54:07 --> Pagination Class Initialized
INFO - 2025-09-18 08:54:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:54:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:54:07 --> Model "Log_model" initialized
INFO - 2025-09-18 08:54:07 --> Final output sent to browser
DEBUG - 2025-09-18 08:54:07 --> Total execution time: 0.3802
INFO - 2025-09-18 03:54:56 --> Config Class Initialized
INFO - 2025-09-18 03:54:56 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:54:56 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:54:56 --> Utf8 Class Initialized
INFO - 2025-09-18 03:54:56 --> URI Class Initialized
INFO - 2025-09-18 03:54:56 --> Router Class Initialized
INFO - 2025-09-18 03:54:56 --> Output Class Initialized
INFO - 2025-09-18 03:54:56 --> Security Class Initialized
DEBUG - 2025-09-18 03:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:54:56 --> CSRF cookie sent
INFO - 2025-09-18 03:54:56 --> Input Class Initialized
INFO - 2025-09-18 03:54:56 --> Language Class Initialized
INFO - 2025-09-18 03:54:56 --> Loader Class Initialized
INFO - 2025-09-18 03:54:56 --> Helper loaded: url_helper
INFO - 2025-09-18 03:54:56 --> Helper loaded: text_helper
INFO - 2025-09-18 03:54:56 --> Helper loaded: string_helper
INFO - 2025-09-18 03:54:56 --> Helper loaded: form_helper
INFO - 2025-09-18 03:54:56 --> Helper loaded: download_helper
INFO - 2025-09-18 03:54:56 --> Helper loaded: security_helper
INFO - 2025-09-18 03:54:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:54:56 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:54:56 --> Form Validation Class Initialized
INFO - 2025-09-18 03:54:56 --> Model "User_model" initialized
INFO - 2025-09-18 08:54:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:54:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:54:56 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:54:56 --> Controller Class Initialized
INFO - 2025-09-18 08:54:56 --> Model "Sdm_model" initialized
INFO - 2025-09-18 08:54:56 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-18 08:54:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-09-18 08:54:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:54:56 --> Model "Log_model" initialized
INFO - 2025-09-18 08:54:56 --> Final output sent to browser
DEBUG - 2025-09-18 08:54:56 --> Total execution time: 0.6500
INFO - 2025-09-18 03:55:00 --> Config Class Initialized
INFO - 2025-09-18 03:55:00 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:55:00 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:55:00 --> Utf8 Class Initialized
INFO - 2025-09-18 03:55:00 --> URI Class Initialized
INFO - 2025-09-18 03:55:00 --> Router Class Initialized
INFO - 2025-09-18 03:55:00 --> Output Class Initialized
INFO - 2025-09-18 03:55:00 --> Security Class Initialized
DEBUG - 2025-09-18 03:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:55:00 --> CSRF cookie sent
INFO - 2025-09-18 03:55:00 --> Input Class Initialized
INFO - 2025-09-18 03:55:00 --> Language Class Initialized
INFO - 2025-09-18 03:55:00 --> Loader Class Initialized
INFO - 2025-09-18 03:55:00 --> Helper loaded: url_helper
INFO - 2025-09-18 03:55:00 --> Helper loaded: text_helper
INFO - 2025-09-18 03:55:00 --> Helper loaded: string_helper
INFO - 2025-09-18 03:55:00 --> Helper loaded: form_helper
INFO - 2025-09-18 03:55:00 --> Helper loaded: download_helper
INFO - 2025-09-18 03:55:00 --> Helper loaded: security_helper
INFO - 2025-09-18 03:55:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:55:00 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:55:00 --> Form Validation Class Initialized
INFO - 2025-09-18 03:55:00 --> Model "User_model" initialized
INFO - 2025-09-18 08:55:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:55:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:55:00 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:55:00 --> Controller Class Initialized
INFO - 2025-09-18 08:55:00 --> Model "Sdm_model" initialized
INFO - 2025-09-18 08:55:00 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-18 08:55:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2025-09-18 08:55:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:55:00 --> Model "Log_model" initialized
INFO - 2025-09-18 08:55:00 --> Final output sent to browser
DEBUG - 2025-09-18 08:55:00 --> Total execution time: 0.2585
INFO - 2025-09-18 03:55:05 --> Config Class Initialized
INFO - 2025-09-18 03:55:05 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:55:05 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:55:05 --> Utf8 Class Initialized
INFO - 2025-09-18 03:55:05 --> URI Class Initialized
INFO - 2025-09-18 03:55:05 --> Router Class Initialized
INFO - 2025-09-18 03:55:05 --> Output Class Initialized
INFO - 2025-09-18 03:55:05 --> Security Class Initialized
DEBUG - 2025-09-18 03:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:55:05 --> CSRF cookie sent
INFO - 2025-09-18 03:55:05 --> Input Class Initialized
INFO - 2025-09-18 03:55:05 --> Language Class Initialized
INFO - 2025-09-18 03:55:05 --> Loader Class Initialized
INFO - 2025-09-18 03:55:05 --> Helper loaded: url_helper
INFO - 2025-09-18 03:55:05 --> Helper loaded: text_helper
INFO - 2025-09-18 03:55:05 --> Helper loaded: string_helper
INFO - 2025-09-18 03:55:05 --> Helper loaded: form_helper
INFO - 2025-09-18 03:55:05 --> Helper loaded: download_helper
INFO - 2025-09-18 03:55:05 --> Helper loaded: security_helper
INFO - 2025-09-18 03:55:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:55:05 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:55:05 --> Form Validation Class Initialized
INFO - 2025-09-18 03:55:05 --> Model "User_model" initialized
INFO - 2025-09-18 08:55:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:55:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:55:05 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:55:05 --> Controller Class Initialized
INFO - 2025-09-18 08:55:05 --> Model "Sdm_model" initialized
INFO - 2025-09-18 08:55:05 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-18 08:55:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-09-18 08:55:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:55:05 --> Model "Log_model" initialized
INFO - 2025-09-18 08:55:05 --> Final output sent to browser
DEBUG - 2025-09-18 08:55:05 --> Total execution time: 0.2328
INFO - 2025-09-18 03:55:12 --> Config Class Initialized
INFO - 2025-09-18 03:55:12 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:55:12 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:55:12 --> Utf8 Class Initialized
INFO - 2025-09-18 03:55:12 --> URI Class Initialized
DEBUG - 2025-09-18 03:55:12 --> No URI present. Default controller set.
INFO - 2025-09-18 03:55:12 --> Router Class Initialized
INFO - 2025-09-18 03:55:12 --> Output Class Initialized
INFO - 2025-09-18 03:55:12 --> Security Class Initialized
DEBUG - 2025-09-18 03:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:55:12 --> CSRF cookie sent
INFO - 2025-09-18 03:55:12 --> Input Class Initialized
INFO - 2025-09-18 03:55:12 --> Language Class Initialized
INFO - 2025-09-18 03:55:12 --> Loader Class Initialized
INFO - 2025-09-18 03:55:12 --> Helper loaded: url_helper
INFO - 2025-09-18 03:55:12 --> Helper loaded: text_helper
INFO - 2025-09-18 03:55:12 --> Helper loaded: string_helper
INFO - 2025-09-18 03:55:12 --> Helper loaded: form_helper
INFO - 2025-09-18 03:55:12 --> Helper loaded: download_helper
INFO - 2025-09-18 03:55:12 --> Helper loaded: security_helper
INFO - 2025-09-18 03:55:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:55:12 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:55:12 --> Form Validation Class Initialized
INFO - 2025-09-18 03:55:12 --> Model "User_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:55:12 --> Controller Class Initialized
INFO - 2025-09-18 08:55:12 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Video_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:55:12 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:55:12 --> Pagination Class Initialized
INFO - 2025-09-18 08:55:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 08:55:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:55:12 --> Model "Log_model" initialized
INFO - 2025-09-18 08:55:12 --> Final output sent to browser
DEBUG - 2025-09-18 08:55:12 --> Total execution time: 0.3733
INFO - 2025-09-18 03:56:26 --> Config Class Initialized
INFO - 2025-09-18 03:56:26 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:56:26 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:56:26 --> Utf8 Class Initialized
INFO - 2025-09-18 03:56:26 --> URI Class Initialized
INFO - 2025-09-18 03:56:26 --> Router Class Initialized
INFO - 2025-09-18 03:56:26 --> Output Class Initialized
INFO - 2025-09-18 03:56:26 --> Security Class Initialized
DEBUG - 2025-09-18 03:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:56:26 --> CSRF cookie sent
INFO - 2025-09-18 03:56:26 --> Input Class Initialized
INFO - 2025-09-18 03:56:26 --> Language Class Initialized
INFO - 2025-09-18 03:56:26 --> Loader Class Initialized
INFO - 2025-09-18 03:56:26 --> Helper loaded: url_helper
INFO - 2025-09-18 03:56:26 --> Helper loaded: text_helper
INFO - 2025-09-18 03:56:26 --> Helper loaded: string_helper
INFO - 2025-09-18 03:56:26 --> Helper loaded: form_helper
INFO - 2025-09-18 03:56:26 --> Helper loaded: download_helper
INFO - 2025-09-18 03:56:26 --> Helper loaded: security_helper
INFO - 2025-09-18 03:56:26 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:56:26 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:56:26 --> Form Validation Class Initialized
INFO - 2025-09-18 03:56:26 --> Model "User_model" initialized
INFO - 2025-09-18 08:56:26 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:56:26 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:56:26 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:56:26 --> Controller Class Initialized
INFO - 2025-09-18 08:56:26 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:56:26 --> Model "Kategori_model" initialized
INFO - 2025-09-18 08:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 08:56:26 --> Pagination Class Initialized
INFO - 2025-09-18 08:56:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2025-09-18 08:56:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:56:26 --> Model "Log_model" initialized
INFO - 2025-09-18 08:56:26 --> Final output sent to browser
DEBUG - 2025-09-18 08:56:26 --> Total execution time: 0.6429
INFO - 2025-09-18 03:56:33 --> Config Class Initialized
INFO - 2025-09-18 03:56:33 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:56:33 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:56:33 --> Utf8 Class Initialized
INFO - 2025-09-18 03:56:33 --> URI Class Initialized
INFO - 2025-09-18 03:56:33 --> Router Class Initialized
INFO - 2025-09-18 03:56:33 --> Output Class Initialized
INFO - 2025-09-18 03:56:33 --> Security Class Initialized
DEBUG - 2025-09-18 03:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:56:33 --> CSRF cookie sent
INFO - 2025-09-18 03:56:33 --> Input Class Initialized
INFO - 2025-09-18 03:56:33 --> Language Class Initialized
INFO - 2025-09-18 03:56:33 --> Loader Class Initialized
INFO - 2025-09-18 03:56:33 --> Helper loaded: url_helper
INFO - 2025-09-18 03:56:33 --> Helper loaded: text_helper
INFO - 2025-09-18 03:56:33 --> Helper loaded: string_helper
INFO - 2025-09-18 03:56:33 --> Helper loaded: form_helper
INFO - 2025-09-18 03:56:33 --> Helper loaded: download_helper
INFO - 2025-09-18 03:56:33 --> Helper loaded: security_helper
INFO - 2025-09-18 03:56:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:56:33 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:56:33 --> Form Validation Class Initialized
INFO - 2025-09-18 03:56:33 --> Model "User_model" initialized
INFO - 2025-09-18 08:56:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:56:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:56:33 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:56:33 --> Controller Class Initialized
INFO - 2025-09-18 08:56:33 --> Model "Pages_model" initialized
INFO - 2025-09-18 08:56:33 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:56:33 --> Model "Download_model" initialized
INFO - 2025-09-18 08:56:33 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 08:56:34 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 08:56:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-18 08:56:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:56:34 --> Model "Log_model" initialized
INFO - 2025-09-18 08:56:34 --> Final output sent to browser
DEBUG - 2025-09-18 08:56:34 --> Total execution time: 0.9869
INFO - 2025-09-18 03:56:46 --> Config Class Initialized
INFO - 2025-09-18 03:56:46 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:56:46 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:56:46 --> Utf8 Class Initialized
INFO - 2025-09-18 03:56:46 --> URI Class Initialized
INFO - 2025-09-18 03:56:46 --> Router Class Initialized
INFO - 2025-09-18 03:56:46 --> Output Class Initialized
INFO - 2025-09-18 03:56:46 --> Security Class Initialized
DEBUG - 2025-09-18 03:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:56:46 --> CSRF cookie sent
INFO - 2025-09-18 03:56:46 --> Input Class Initialized
INFO - 2025-09-18 03:56:46 --> Language Class Initialized
INFO - 2025-09-18 03:56:46 --> Loader Class Initialized
INFO - 2025-09-18 03:56:46 --> Helper loaded: url_helper
INFO - 2025-09-18 03:56:46 --> Helper loaded: text_helper
INFO - 2025-09-18 03:56:46 --> Helper loaded: string_helper
INFO - 2025-09-18 03:56:46 --> Helper loaded: form_helper
INFO - 2025-09-18 03:56:46 --> Helper loaded: download_helper
INFO - 2025-09-18 03:56:46 --> Helper loaded: security_helper
INFO - 2025-09-18 03:56:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:56:46 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:56:46 --> Form Validation Class Initialized
INFO - 2025-09-18 03:56:46 --> Model "User_model" initialized
INFO - 2025-09-18 08:56:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:56:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:56:46 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:56:46 --> Controller Class Initialized
INFO - 2025-09-18 08:56:46 --> Model "Pages_model" initialized
INFO - 2025-09-18 08:56:46 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:56:46 --> Model "Download_model" initialized
INFO - 2025-09-18 08:56:46 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 08:56:46 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 08:56:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-18 08:56:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:56:46 --> Model "Log_model" initialized
INFO - 2025-09-18 08:56:46 --> Final output sent to browser
DEBUG - 2025-09-18 08:56:46 --> Total execution time: 0.3495
INFO - 2025-09-18 03:58:45 --> Config Class Initialized
INFO - 2025-09-18 03:58:45 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:58:45 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:58:45 --> Utf8 Class Initialized
INFO - 2025-09-18 03:58:45 --> URI Class Initialized
INFO - 2025-09-18 03:58:45 --> Router Class Initialized
INFO - 2025-09-18 03:58:45 --> Output Class Initialized
INFO - 2025-09-18 03:58:45 --> Security Class Initialized
DEBUG - 2025-09-18 03:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:58:45 --> CSRF cookie sent
INFO - 2025-09-18 03:58:45 --> Input Class Initialized
INFO - 2025-09-18 03:58:45 --> Language Class Initialized
INFO - 2025-09-18 03:58:45 --> Loader Class Initialized
INFO - 2025-09-18 03:58:45 --> Helper loaded: url_helper
INFO - 2025-09-18 03:58:45 --> Helper loaded: text_helper
INFO - 2025-09-18 03:58:45 --> Helper loaded: string_helper
INFO - 2025-09-18 03:58:45 --> Helper loaded: form_helper
INFO - 2025-09-18 03:58:45 --> Helper loaded: download_helper
INFO - 2025-09-18 03:58:45 --> Helper loaded: security_helper
INFO - 2025-09-18 03:58:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:58:45 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:58:45 --> Form Validation Class Initialized
INFO - 2025-09-18 03:58:45 --> Model "User_model" initialized
INFO - 2025-09-18 08:58:45 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:58:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:58:45 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:58:45 --> Controller Class Initialized
DEBUG - 2025-09-18 08:58:45 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-18 08:58:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-18 08:58:46 --> Model "Log_model" initialized
INFO - 2025-09-18 08:58:46 --> Final output sent to browser
DEBUG - 2025-09-18 08:58:46 --> Total execution time: 0.4845
INFO - 2025-09-18 03:58:52 --> Config Class Initialized
INFO - 2025-09-18 03:58:52 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:58:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:58:52 --> Utf8 Class Initialized
INFO - 2025-09-18 03:58:52 --> URI Class Initialized
INFO - 2025-09-18 03:58:52 --> Router Class Initialized
INFO - 2025-09-18 03:58:52 --> Output Class Initialized
INFO - 2025-09-18 03:58:52 --> Security Class Initialized
DEBUG - 2025-09-18 03:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:58:52 --> CSRF cookie sent
INFO - 2025-09-18 03:58:52 --> CSRF token verified
INFO - 2025-09-18 03:58:52 --> Input Class Initialized
INFO - 2025-09-18 03:58:52 --> Language Class Initialized
INFO - 2025-09-18 03:58:52 --> Loader Class Initialized
INFO - 2025-09-18 03:58:52 --> Helper loaded: url_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: text_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: string_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: form_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: download_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: security_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:58:52 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:58:52 --> Form Validation Class Initialized
INFO - 2025-09-18 03:58:52 --> Model "User_model" initialized
INFO - 2025-09-18 08:58:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:58:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:58:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:58:52 --> Controller Class Initialized
DEBUG - 2025-09-18 08:58:52 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-18 08:58:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 03:58:52 --> Config Class Initialized
INFO - 2025-09-18 03:58:52 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:58:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:58:52 --> Utf8 Class Initialized
INFO - 2025-09-18 03:58:52 --> URI Class Initialized
INFO - 2025-09-18 03:58:52 --> Router Class Initialized
INFO - 2025-09-18 03:58:52 --> Output Class Initialized
INFO - 2025-09-18 03:58:52 --> Security Class Initialized
DEBUG - 2025-09-18 03:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:58:52 --> CSRF cookie sent
INFO - 2025-09-18 03:58:52 --> Input Class Initialized
INFO - 2025-09-18 03:58:52 --> Language Class Initialized
INFO - 2025-09-18 03:58:52 --> Loader Class Initialized
INFO - 2025-09-18 03:58:52 --> Helper loaded: url_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: text_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: string_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: form_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: download_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: security_helper
INFO - 2025-09-18 03:58:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:58:52 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:58:52 --> Form Validation Class Initialized
INFO - 2025-09-18 03:58:52 --> Model "User_model" initialized
INFO - 2025-09-18 08:58:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:58:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:58:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:58:52 --> Controller Class Initialized
INFO - 2025-09-18 08:58:52 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:58:52 --> Model "Staff_model" initialized
INFO - 2025-09-18 08:58:52 --> Model "Dasbor_model" initialized
INFO - 2025-09-18 08:58:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-09-18 08:58:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 08:58:57 --> Model "Log_model" initialized
INFO - 2025-09-18 08:58:57 --> Final output sent to browser
DEBUG - 2025-09-18 08:58:57 --> Total execution time: 5.4716
INFO - 2025-09-18 03:59:04 --> Config Class Initialized
INFO - 2025-09-18 03:59:04 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:59:04 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:59:04 --> Utf8 Class Initialized
INFO - 2025-09-18 03:59:04 --> URI Class Initialized
INFO - 2025-09-18 03:59:04 --> Router Class Initialized
INFO - 2025-09-18 03:59:04 --> Output Class Initialized
INFO - 2025-09-18 03:59:04 --> Security Class Initialized
DEBUG - 2025-09-18 03:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:59:04 --> CSRF cookie sent
INFO - 2025-09-18 03:59:04 --> Input Class Initialized
INFO - 2025-09-18 03:59:04 --> Language Class Initialized
INFO - 2025-09-18 03:59:04 --> Loader Class Initialized
INFO - 2025-09-18 03:59:04 --> Helper loaded: url_helper
INFO - 2025-09-18 03:59:04 --> Helper loaded: text_helper
INFO - 2025-09-18 03:59:04 --> Helper loaded: string_helper
INFO - 2025-09-18 03:59:04 --> Helper loaded: form_helper
INFO - 2025-09-18 03:59:04 --> Helper loaded: download_helper
INFO - 2025-09-18 03:59:04 --> Helper loaded: security_helper
INFO - 2025-09-18 03:59:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:59:04 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:59:05 --> Form Validation Class Initialized
INFO - 2025-09-18 03:59:05 --> Model "User_model" initialized
INFO - 2025-09-18 08:59:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:59:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:59:05 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:59:05 --> Controller Class Initialized
INFO - 2025-09-18 08:59:05 --> Model "Pages_model" initialized
INFO - 2025-09-18 08:59:05 --> Model "Download_model" initialized
INFO - 2025-09-18 08:59:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pages/list.php
INFO - 2025-09-18 08:59:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 08:59:05 --> Model "Log_model" initialized
INFO - 2025-09-18 08:59:05 --> Final output sent to browser
DEBUG - 2025-09-18 08:59:05 --> Total execution time: 1.1406
INFO - 2025-09-18 03:59:06 --> Config Class Initialized
INFO - 2025-09-18 03:59:06 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:59:06 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:59:06 --> Utf8 Class Initialized
INFO - 2025-09-18 03:59:06 --> URI Class Initialized
INFO - 2025-09-18 03:59:06 --> Router Class Initialized
INFO - 2025-09-18 03:59:06 --> Output Class Initialized
INFO - 2025-09-18 03:59:06 --> Security Class Initialized
DEBUG - 2025-09-18 03:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:59:06 --> CSRF cookie sent
INFO - 2025-09-18 03:59:06 --> Input Class Initialized
INFO - 2025-09-18 03:59:06 --> Language Class Initialized
INFO - 2025-09-18 03:59:06 --> Loader Class Initialized
INFO - 2025-09-18 03:59:06 --> Helper loaded: url_helper
INFO - 2025-09-18 03:59:06 --> Helper loaded: text_helper
INFO - 2025-09-18 03:59:06 --> Helper loaded: string_helper
INFO - 2025-09-18 03:59:06 --> Helper loaded: form_helper
INFO - 2025-09-18 03:59:06 --> Helper loaded: download_helper
INFO - 2025-09-18 03:59:06 --> Helper loaded: security_helper
INFO - 2025-09-18 03:59:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:59:06 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:59:06 --> Form Validation Class Initialized
INFO - 2025-09-18 03:59:06 --> Model "User_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:59:06 --> Controller Class Initialized
INFO - 2025-09-18 08:59:06 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Video_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:59:06 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:59:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 08:59:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:59:06 --> Model "Log_model" initialized
INFO - 2025-09-18 08:59:06 --> Final output sent to browser
DEBUG - 2025-09-18 08:59:06 --> Total execution time: 0.2656
INFO - 2025-09-18 03:59:10 --> Config Class Initialized
INFO - 2025-09-18 03:59:10 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:59:10 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:59:10 --> Utf8 Class Initialized
INFO - 2025-09-18 03:59:11 --> URI Class Initialized
INFO - 2025-09-18 03:59:11 --> Router Class Initialized
INFO - 2025-09-18 03:59:11 --> Output Class Initialized
INFO - 2025-09-18 03:59:11 --> Security Class Initialized
DEBUG - 2025-09-18 03:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:59:11 --> CSRF cookie sent
INFO - 2025-09-18 03:59:11 --> Input Class Initialized
INFO - 2025-09-18 03:59:11 --> Language Class Initialized
INFO - 2025-09-18 03:59:11 --> Loader Class Initialized
INFO - 2025-09-18 03:59:11 --> Helper loaded: url_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: text_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: string_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: form_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: download_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: security_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:59:11 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:59:11 --> Form Validation Class Initialized
INFO - 2025-09-18 03:59:11 --> Model "User_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:59:11 --> Controller Class Initialized
INFO - 2025-09-18 08:59:11 --> Model "Pages_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Download_model" initialized
INFO - 2025-09-18 08:59:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pages/edit.php
INFO - 2025-09-18 08:59:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 08:59:11 --> Model "Log_model" initialized
INFO - 2025-09-18 08:59:11 --> Final output sent to browser
DEBUG - 2025-09-18 08:59:11 --> Total execution time: 0.2129
INFO - 2025-09-18 03:59:11 --> Config Class Initialized
INFO - 2025-09-18 03:59:11 --> Hooks Class Initialized
DEBUG - 2025-09-18 03:59:11 --> UTF-8 Support Enabled
INFO - 2025-09-18 03:59:11 --> Utf8 Class Initialized
INFO - 2025-09-18 03:59:11 --> URI Class Initialized
INFO - 2025-09-18 03:59:11 --> Router Class Initialized
INFO - 2025-09-18 03:59:11 --> Output Class Initialized
INFO - 2025-09-18 03:59:11 --> Security Class Initialized
DEBUG - 2025-09-18 03:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 03:59:11 --> CSRF cookie sent
INFO - 2025-09-18 03:59:11 --> Input Class Initialized
INFO - 2025-09-18 03:59:11 --> Language Class Initialized
INFO - 2025-09-18 03:59:11 --> Loader Class Initialized
INFO - 2025-09-18 03:59:11 --> Helper loaded: url_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: text_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: string_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: form_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: download_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: security_helper
INFO - 2025-09-18 03:59:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 03:59:11 --> Database Driver Class Initialized
DEBUG - 2025-09-18 03:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 03:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 03:59:11 --> Form Validation Class Initialized
INFO - 2025-09-18 03:59:11 --> Model "User_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Nav_model" initialized
INFO - 2025-09-18 08:59:11 --> Controller Class Initialized
INFO - 2025-09-18 08:59:11 --> Model "Berita_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Galeri_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Video_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Agenda_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Tautan_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Mitra_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Prodi_model" initialized
INFO - 2025-09-18 08:59:11 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 08:59:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 08:59:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 08:59:11 --> Model "Log_model" initialized
INFO - 2025-09-18 08:59:11 --> Final output sent to browser
DEBUG - 2025-09-18 08:59:11 --> Total execution time: 0.1197
INFO - 2025-09-18 04:00:26 --> Config Class Initialized
INFO - 2025-09-18 04:00:26 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:00:26 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:00:26 --> Utf8 Class Initialized
INFO - 2025-09-18 04:00:26 --> URI Class Initialized
INFO - 2025-09-18 04:00:26 --> Router Class Initialized
INFO - 2025-09-18 04:00:26 --> Output Class Initialized
INFO - 2025-09-18 04:00:26 --> Security Class Initialized
DEBUG - 2025-09-18 04:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:00:26 --> CSRF cookie sent
INFO - 2025-09-18 04:00:26 --> CSRF token verified
INFO - 2025-09-18 04:00:26 --> Input Class Initialized
INFO - 2025-09-18 04:00:26 --> Language Class Initialized
INFO - 2025-09-18 04:00:26 --> Loader Class Initialized
INFO - 2025-09-18 04:00:26 --> Helper loaded: url_helper
INFO - 2025-09-18 04:00:26 --> Helper loaded: text_helper
INFO - 2025-09-18 04:00:26 --> Helper loaded: string_helper
INFO - 2025-09-18 04:00:26 --> Helper loaded: form_helper
INFO - 2025-09-18 04:00:26 --> Helper loaded: download_helper
INFO - 2025-09-18 04:00:26 --> Helper loaded: security_helper
INFO - 2025-09-18 04:00:26 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:00:26 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:00:26 --> Form Validation Class Initialized
INFO - 2025-09-18 04:00:26 --> Model "User_model" initialized
INFO - 2025-09-18 09:00:26 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:00:26 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:00:26 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:00:26 --> Controller Class Initialized
INFO - 2025-09-18 09:00:26 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:00:26 --> Model "Download_model" initialized
INFO - 2025-09-18 09:00:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 04:00:27 --> Config Class Initialized
INFO - 2025-09-18 04:00:27 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:00:27 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:00:27 --> Utf8 Class Initialized
INFO - 2025-09-18 04:00:27 --> URI Class Initialized
INFO - 2025-09-18 04:00:27 --> Router Class Initialized
INFO - 2025-09-18 04:00:27 --> Output Class Initialized
INFO - 2025-09-18 04:00:27 --> Security Class Initialized
DEBUG - 2025-09-18 04:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:00:27 --> CSRF cookie sent
INFO - 2025-09-18 04:00:27 --> Input Class Initialized
INFO - 2025-09-18 04:00:27 --> Language Class Initialized
INFO - 2025-09-18 04:00:27 --> Loader Class Initialized
INFO - 2025-09-18 04:00:27 --> Helper loaded: url_helper
INFO - 2025-09-18 04:00:27 --> Helper loaded: text_helper
INFO - 2025-09-18 04:00:27 --> Helper loaded: string_helper
INFO - 2025-09-18 04:00:27 --> Helper loaded: form_helper
INFO - 2025-09-18 04:00:27 --> Helper loaded: download_helper
INFO - 2025-09-18 04:00:27 --> Helper loaded: security_helper
INFO - 2025-09-18 04:00:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:00:27 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:00:27 --> Form Validation Class Initialized
INFO - 2025-09-18 04:00:27 --> Model "User_model" initialized
INFO - 2025-09-18 09:00:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:00:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:00:27 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:00:27 --> Controller Class Initialized
INFO - 2025-09-18 09:00:27 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:00:27 --> Model "Download_model" initialized
INFO - 2025-09-18 09:00:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pages/list.php
INFO - 2025-09-18 09:00:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 09:00:27 --> Model "Log_model" initialized
INFO - 2025-09-18 09:00:27 --> Final output sent to browser
DEBUG - 2025-09-18 09:00:27 --> Total execution time: 0.1345
INFO - 2025-09-18 04:00:32 --> Config Class Initialized
INFO - 2025-09-18 04:00:32 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:00:32 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:00:32 --> Utf8 Class Initialized
INFO - 2025-09-18 04:00:32 --> URI Class Initialized
DEBUG - 2025-09-18 04:00:32 --> No URI present. Default controller set.
INFO - 2025-09-18 04:00:32 --> Router Class Initialized
INFO - 2025-09-18 04:00:32 --> Output Class Initialized
INFO - 2025-09-18 04:00:32 --> Security Class Initialized
DEBUG - 2025-09-18 04:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:00:32 --> CSRF cookie sent
INFO - 2025-09-18 04:00:32 --> Input Class Initialized
INFO - 2025-09-18 04:00:32 --> Language Class Initialized
INFO - 2025-09-18 04:00:32 --> Loader Class Initialized
INFO - 2025-09-18 04:00:32 --> Helper loaded: url_helper
INFO - 2025-09-18 04:00:32 --> Helper loaded: text_helper
INFO - 2025-09-18 04:00:32 --> Helper loaded: string_helper
INFO - 2025-09-18 04:00:32 --> Helper loaded: form_helper
INFO - 2025-09-18 04:00:32 --> Helper loaded: download_helper
INFO - 2025-09-18 04:00:32 --> Helper loaded: security_helper
INFO - 2025-09-18 04:00:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:00:32 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:00:32 --> Form Validation Class Initialized
INFO - 2025-09-18 04:00:32 --> Model "User_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:00:32 --> Controller Class Initialized
INFO - 2025-09-18 09:00:32 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Video_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:00:32 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:00:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:00:32 --> Pagination Class Initialized
INFO - 2025-09-18 09:00:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:00:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:00:32 --> Model "Log_model" initialized
INFO - 2025-09-18 09:00:32 --> Final output sent to browser
DEBUG - 2025-09-18 09:00:32 --> Total execution time: 0.2303
INFO - 2025-09-18 04:00:37 --> Config Class Initialized
INFO - 2025-09-18 04:00:37 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:00:37 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:00:37 --> Utf8 Class Initialized
INFO - 2025-09-18 04:00:37 --> URI Class Initialized
INFO - 2025-09-18 04:00:37 --> Router Class Initialized
INFO - 2025-09-18 04:00:37 --> Output Class Initialized
INFO - 2025-09-18 04:00:37 --> Security Class Initialized
DEBUG - 2025-09-18 04:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:00:37 --> CSRF cookie sent
INFO - 2025-09-18 04:00:37 --> Input Class Initialized
INFO - 2025-09-18 04:00:37 --> Language Class Initialized
INFO - 2025-09-18 04:00:37 --> Loader Class Initialized
INFO - 2025-09-18 04:00:37 --> Helper loaded: url_helper
INFO - 2025-09-18 04:00:37 --> Helper loaded: text_helper
INFO - 2025-09-18 04:00:37 --> Helper loaded: string_helper
INFO - 2025-09-18 04:00:37 --> Helper loaded: form_helper
INFO - 2025-09-18 04:00:37 --> Helper loaded: download_helper
INFO - 2025-09-18 04:00:37 --> Helper loaded: security_helper
INFO - 2025-09-18 04:00:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:00:37 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:00:37 --> Form Validation Class Initialized
INFO - 2025-09-18 04:00:37 --> Model "User_model" initialized
INFO - 2025-09-18 09:00:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:00:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:00:37 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:00:37 --> Controller Class Initialized
INFO - 2025-09-18 09:00:37 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:00:37 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:00:37 --> Model "Download_model" initialized
INFO - 2025-09-18 09:00:37 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 09:00:37 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 09:00:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-18 09:00:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:00:37 --> Model "Log_model" initialized
INFO - 2025-09-18 09:00:37 --> Final output sent to browser
DEBUG - 2025-09-18 09:00:37 --> Total execution time: 0.1852
INFO - 2025-09-18 04:00:50 --> Config Class Initialized
INFO - 2025-09-18 04:00:50 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:00:50 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:00:50 --> Utf8 Class Initialized
INFO - 2025-09-18 04:00:50 --> URI Class Initialized
INFO - 2025-09-18 04:00:50 --> Router Class Initialized
INFO - 2025-09-18 04:00:50 --> Output Class Initialized
INFO - 2025-09-18 04:00:50 --> Security Class Initialized
DEBUG - 2025-09-18 04:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:00:50 --> CSRF cookie sent
INFO - 2025-09-18 04:00:50 --> Input Class Initialized
INFO - 2025-09-18 04:00:50 --> Language Class Initialized
INFO - 2025-09-18 04:00:50 --> Loader Class Initialized
INFO - 2025-09-18 04:00:50 --> Helper loaded: url_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: text_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: string_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: form_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: download_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: security_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:00:50 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:00:50 --> Form Validation Class Initialized
INFO - 2025-09-18 04:00:50 --> Model "User_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:00:50 --> Controller Class Initialized
INFO - 2025-09-18 09:00:50 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Download_model" initialized
INFO - 2025-09-18 09:00:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pages/edit.php
INFO - 2025-09-18 09:00:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 09:00:50 --> Model "Log_model" initialized
INFO - 2025-09-18 09:00:50 --> Final output sent to browser
DEBUG - 2025-09-18 09:00:50 --> Total execution time: 0.1328
INFO - 2025-09-18 04:00:50 --> Config Class Initialized
INFO - 2025-09-18 04:00:50 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:00:50 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:00:50 --> Utf8 Class Initialized
INFO - 2025-09-18 04:00:50 --> URI Class Initialized
INFO - 2025-09-18 04:00:50 --> Router Class Initialized
INFO - 2025-09-18 04:00:50 --> Output Class Initialized
INFO - 2025-09-18 04:00:50 --> Security Class Initialized
DEBUG - 2025-09-18 04:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:00:50 --> CSRF cookie sent
INFO - 2025-09-18 04:00:50 --> Input Class Initialized
INFO - 2025-09-18 04:00:50 --> Language Class Initialized
INFO - 2025-09-18 04:00:50 --> Loader Class Initialized
INFO - 2025-09-18 04:00:50 --> Helper loaded: url_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: text_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: string_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: form_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: download_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: security_helper
INFO - 2025-09-18 04:00:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:00:50 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:00:50 --> Form Validation Class Initialized
INFO - 2025-09-18 04:00:50 --> Model "User_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:00:50 --> Controller Class Initialized
INFO - 2025-09-18 09:00:50 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Video_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:00:50 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:00:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:00:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:00:50 --> Model "Log_model" initialized
INFO - 2025-09-18 09:00:50 --> Final output sent to browser
DEBUG - 2025-09-18 09:00:50 --> Total execution time: 0.1689
INFO - 2025-09-18 04:04:47 --> Config Class Initialized
INFO - 2025-09-18 04:04:47 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:04:47 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:04:47 --> Utf8 Class Initialized
INFO - 2025-09-18 04:04:47 --> URI Class Initialized
INFO - 2025-09-18 04:04:48 --> Router Class Initialized
INFO - 2025-09-18 04:04:48 --> Output Class Initialized
INFO - 2025-09-18 04:04:48 --> Security Class Initialized
DEBUG - 2025-09-18 04:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:04:48 --> CSRF cookie sent
INFO - 2025-09-18 04:04:48 --> Input Class Initialized
INFO - 2025-09-18 04:04:48 --> Language Class Initialized
INFO - 2025-09-18 04:04:49 --> Loader Class Initialized
INFO - 2025-09-18 04:04:49 --> Helper loaded: url_helper
INFO - 2025-09-18 04:04:49 --> Helper loaded: text_helper
INFO - 2025-09-18 04:04:49 --> Helper loaded: string_helper
INFO - 2025-09-18 04:04:49 --> Helper loaded: form_helper
INFO - 2025-09-18 04:04:49 --> Helper loaded: download_helper
INFO - 2025-09-18 04:04:50 --> Helper loaded: security_helper
INFO - 2025-09-18 04:04:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:04:50 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:04:51 --> Form Validation Class Initialized
INFO - 2025-09-18 04:04:51 --> Model "User_model" initialized
INFO - 2025-09-18 09:04:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:04:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:04:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:04:52 --> Controller Class Initialized
INFO - 2025-09-18 09:04:52 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:04:52 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:04:52 --> Model "Download_model" initialized
INFO - 2025-09-18 09:04:53 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 09:04:53 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 09:04:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-18 09:04:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:04:55 --> Model "Log_model" initialized
INFO - 2025-09-18 09:04:55 --> Final output sent to browser
DEBUG - 2025-09-18 09:04:55 --> Total execution time: 8.5337
INFO - 2025-09-18 04:04:55 --> Config Class Initialized
INFO - 2025-09-18 04:04:55 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:04:55 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:04:55 --> Utf8 Class Initialized
INFO - 2025-09-18 04:04:55 --> URI Class Initialized
INFO - 2025-09-18 04:04:55 --> Router Class Initialized
INFO - 2025-09-18 04:04:55 --> Output Class Initialized
INFO - 2025-09-18 04:04:55 --> Security Class Initialized
DEBUG - 2025-09-18 04:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:04:55 --> CSRF cookie sent
INFO - 2025-09-18 04:04:55 --> Input Class Initialized
INFO - 2025-09-18 04:04:55 --> Language Class Initialized
INFO - 2025-09-18 04:04:55 --> Loader Class Initialized
INFO - 2025-09-18 04:04:55 --> Helper loaded: url_helper
INFO - 2025-09-18 04:04:55 --> Helper loaded: text_helper
INFO - 2025-09-18 04:04:55 --> Helper loaded: string_helper
INFO - 2025-09-18 04:04:55 --> Helper loaded: form_helper
INFO - 2025-09-18 04:04:55 --> Helper loaded: download_helper
INFO - 2025-09-18 04:04:55 --> Helper loaded: security_helper
INFO - 2025-09-18 04:04:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:04:55 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:04:56 --> Form Validation Class Initialized
INFO - 2025-09-18 04:04:56 --> Model "User_model" initialized
INFO - 2025-09-18 09:04:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:04:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:04:56 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:04:56 --> Controller Class Initialized
INFO - 2025-09-18 09:04:56 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:04:56 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:04:56 --> Model "Download_model" initialized
INFO - 2025-09-18 09:04:56 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 09:04:56 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 09:04:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-18 09:04:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:04:56 --> Model "Log_model" initialized
INFO - 2025-09-18 09:04:56 --> Final output sent to browser
DEBUG - 2025-09-18 09:04:56 --> Total execution time: 0.2318
INFO - 2025-09-18 04:07:22 --> Config Class Initialized
INFO - 2025-09-18 04:07:22 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:07:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:07:22 --> Utf8 Class Initialized
INFO - 2025-09-18 04:07:22 --> URI Class Initialized
INFO - 2025-09-18 04:07:22 --> Router Class Initialized
INFO - 2025-09-18 04:07:22 --> Output Class Initialized
INFO - 2025-09-18 04:07:22 --> Security Class Initialized
DEBUG - 2025-09-18 04:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:07:22 --> CSRF cookie sent
INFO - 2025-09-18 04:07:22 --> Input Class Initialized
INFO - 2025-09-18 04:07:22 --> Language Class Initialized
INFO - 2025-09-18 04:07:22 --> Loader Class Initialized
INFO - 2025-09-18 04:07:22 --> Helper loaded: url_helper
INFO - 2025-09-18 04:07:22 --> Helper loaded: text_helper
INFO - 2025-09-18 04:07:22 --> Helper loaded: string_helper
INFO - 2025-09-18 04:07:22 --> Helper loaded: form_helper
INFO - 2025-09-18 04:07:22 --> Helper loaded: download_helper
INFO - 2025-09-18 04:07:22 --> Helper loaded: security_helper
INFO - 2025-09-18 04:07:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:07:22 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:07:22 --> Form Validation Class Initialized
INFO - 2025-09-18 04:07:22 --> Model "User_model" initialized
INFO - 2025-09-18 09:07:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:07:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:07:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:07:22 --> Controller Class Initialized
INFO - 2025-09-18 09:07:22 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:07:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:07:22 --> Model "Download_model" initialized
INFO - 2025-09-18 09:07:22 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 09:07:22 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 09:07:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-18 09:07:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:07:22 --> Model "Log_model" initialized
INFO - 2025-09-18 09:07:22 --> Final output sent to browser
DEBUG - 2025-09-18 09:07:22 --> Total execution time: 0.0657
INFO - 2025-09-18 04:07:25 --> Config Class Initialized
INFO - 2025-09-18 04:07:25 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:07:25 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:07:25 --> Utf8 Class Initialized
INFO - 2025-09-18 04:07:25 --> URI Class Initialized
INFO - 2025-09-18 04:07:25 --> Router Class Initialized
INFO - 2025-09-18 04:07:25 --> Output Class Initialized
INFO - 2025-09-18 04:07:25 --> Security Class Initialized
DEBUG - 2025-09-18 04:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:07:25 --> CSRF cookie sent
INFO - 2025-09-18 04:07:25 --> Input Class Initialized
INFO - 2025-09-18 04:07:25 --> Language Class Initialized
INFO - 2025-09-18 04:07:25 --> Loader Class Initialized
INFO - 2025-09-18 04:07:25 --> Helper loaded: url_helper
INFO - 2025-09-18 04:07:25 --> Helper loaded: text_helper
INFO - 2025-09-18 04:07:25 --> Helper loaded: string_helper
INFO - 2025-09-18 04:07:25 --> Helper loaded: form_helper
INFO - 2025-09-18 04:07:25 --> Helper loaded: download_helper
INFO - 2025-09-18 04:07:25 --> Helper loaded: security_helper
INFO - 2025-09-18 04:07:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:07:25 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:07:25 --> Form Validation Class Initialized
INFO - 2025-09-18 04:07:25 --> Model "User_model" initialized
INFO - 2025-09-18 09:07:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:07:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:07:25 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:07:25 --> Controller Class Initialized
INFO - 2025-09-18 09:07:25 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:07:25 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:07:25 --> Model "Download_model" initialized
INFO - 2025-09-18 09:07:25 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 09:07:25 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 09:07:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-18 09:07:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:07:25 --> Model "Log_model" initialized
INFO - 2025-09-18 09:07:25 --> Final output sent to browser
DEBUG - 2025-09-18 09:07:25 --> Total execution time: 0.0943
INFO - 2025-09-18 04:07:27 --> Config Class Initialized
INFO - 2025-09-18 04:07:27 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:07:27 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:07:27 --> Utf8 Class Initialized
INFO - 2025-09-18 04:07:27 --> URI Class Initialized
INFO - 2025-09-18 04:07:27 --> Router Class Initialized
INFO - 2025-09-18 04:07:27 --> Output Class Initialized
INFO - 2025-09-18 04:07:27 --> Security Class Initialized
DEBUG - 2025-09-18 04:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:07:27 --> CSRF cookie sent
INFO - 2025-09-18 04:07:27 --> Input Class Initialized
INFO - 2025-09-18 04:07:27 --> Language Class Initialized
INFO - 2025-09-18 04:07:27 --> Loader Class Initialized
INFO - 2025-09-18 04:07:27 --> Helper loaded: url_helper
INFO - 2025-09-18 04:07:28 --> Helper loaded: text_helper
INFO - 2025-09-18 04:07:28 --> Helper loaded: string_helper
INFO - 2025-09-18 04:07:28 --> Helper loaded: form_helper
INFO - 2025-09-18 04:07:28 --> Helper loaded: download_helper
INFO - 2025-09-18 04:07:28 --> Helper loaded: security_helper
INFO - 2025-09-18 04:07:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:07:28 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:07:28 --> Form Validation Class Initialized
INFO - 2025-09-18 04:07:28 --> Model "User_model" initialized
INFO - 2025-09-18 09:07:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:07:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:07:28 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:07:28 --> Controller Class Initialized
INFO - 2025-09-18 09:07:28 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:07:28 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:07:28 --> Model "Download_model" initialized
INFO - 2025-09-18 09:07:28 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 09:07:28 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 09:07:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-18 09:07:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:07:28 --> Model "Log_model" initialized
INFO - 2025-09-18 09:07:28 --> Final output sent to browser
DEBUG - 2025-09-18 09:07:28 --> Total execution time: 0.0842
INFO - 2025-09-18 04:07:52 --> Config Class Initialized
INFO - 2025-09-18 04:07:52 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:07:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:07:52 --> Utf8 Class Initialized
INFO - 2025-09-18 04:07:52 --> URI Class Initialized
INFO - 2025-09-18 04:07:52 --> Router Class Initialized
INFO - 2025-09-18 04:07:52 --> Output Class Initialized
INFO - 2025-09-18 04:07:52 --> Security Class Initialized
DEBUG - 2025-09-18 04:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:07:52 --> CSRF cookie sent
INFO - 2025-09-18 04:07:52 --> Input Class Initialized
INFO - 2025-09-18 04:07:52 --> Language Class Initialized
INFO - 2025-09-18 04:07:52 --> Loader Class Initialized
INFO - 2025-09-18 04:07:52 --> Helper loaded: url_helper
INFO - 2025-09-18 04:07:52 --> Helper loaded: text_helper
INFO - 2025-09-18 04:07:52 --> Helper loaded: string_helper
INFO - 2025-09-18 04:07:52 --> Helper loaded: form_helper
INFO - 2025-09-18 04:07:52 --> Helper loaded: download_helper
INFO - 2025-09-18 04:07:52 --> Helper loaded: security_helper
INFO - 2025-09-18 04:07:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:07:52 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:07:52 --> Form Validation Class Initialized
INFO - 2025-09-18 04:07:52 --> Model "User_model" initialized
INFO - 2025-09-18 09:07:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:07:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:07:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:07:52 --> Controller Class Initialized
INFO - 2025-09-18 09:07:52 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:07:52 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:07:52 --> Model "Download_model" initialized
INFO - 2025-09-18 09:07:52 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 09:07:52 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 09:07:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-18 09:07:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:07:52 --> Model "Log_model" initialized
INFO - 2025-09-18 09:07:52 --> Final output sent to browser
DEBUG - 2025-09-18 09:07:52 --> Total execution time: 0.0586
INFO - 2025-09-18 04:08:10 --> Config Class Initialized
INFO - 2025-09-18 04:08:10 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:08:10 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:08:10 --> Utf8 Class Initialized
INFO - 2025-09-18 04:08:10 --> URI Class Initialized
INFO - 2025-09-18 04:08:10 --> Router Class Initialized
INFO - 2025-09-18 04:08:10 --> Output Class Initialized
INFO - 2025-09-18 04:08:10 --> Security Class Initialized
DEBUG - 2025-09-18 04:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:08:10 --> CSRF cookie sent
INFO - 2025-09-18 04:08:10 --> Input Class Initialized
INFO - 2025-09-18 04:08:10 --> Language Class Initialized
INFO - 2025-09-18 04:08:10 --> Loader Class Initialized
INFO - 2025-09-18 04:08:10 --> Helper loaded: url_helper
INFO - 2025-09-18 04:08:10 --> Helper loaded: text_helper
INFO - 2025-09-18 04:08:10 --> Helper loaded: string_helper
INFO - 2025-09-18 04:08:10 --> Helper loaded: form_helper
INFO - 2025-09-18 04:08:10 --> Helper loaded: download_helper
INFO - 2025-09-18 04:08:10 --> Helper loaded: security_helper
INFO - 2025-09-18 04:08:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:08:10 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:08:10 --> Form Validation Class Initialized
INFO - 2025-09-18 04:08:10 --> Model "User_model" initialized
INFO - 2025-09-18 09:08:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:08:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:08:10 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:08:10 --> Controller Class Initialized
INFO - 2025-09-18 09:08:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:08:11 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:08:11 --> Model "Sdm_model" initialized
INFO - 2025-09-18 09:08:11 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 09:08:11 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 0
ERROR - 2025-09-18 09:08:11 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 09:08:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 09:08:12 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 09:08:12 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 09:08:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 09:08:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:08:12 --> Model "Log_model" initialized
INFO - 2025-09-18 09:08:12 --> Final output sent to browser
DEBUG - 2025-09-18 09:08:12 --> Total execution time: 1.5469
INFO - 2025-09-18 04:08:14 --> Config Class Initialized
INFO - 2025-09-18 04:08:14 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:08:14 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:08:14 --> Utf8 Class Initialized
INFO - 2025-09-18 04:08:14 --> URI Class Initialized
INFO - 2025-09-18 04:08:14 --> Router Class Initialized
INFO - 2025-09-18 04:08:14 --> Output Class Initialized
INFO - 2025-09-18 04:08:14 --> Security Class Initialized
DEBUG - 2025-09-18 04:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:08:14 --> CSRF cookie sent
INFO - 2025-09-18 04:08:14 --> Input Class Initialized
INFO - 2025-09-18 04:08:14 --> Language Class Initialized
INFO - 2025-09-18 04:08:14 --> Loader Class Initialized
INFO - 2025-09-18 04:08:14 --> Helper loaded: url_helper
INFO - 2025-09-18 04:08:14 --> Helper loaded: text_helper
INFO - 2025-09-18 04:08:14 --> Helper loaded: string_helper
INFO - 2025-09-18 04:08:14 --> Helper loaded: form_helper
INFO - 2025-09-18 04:08:14 --> Helper loaded: download_helper
INFO - 2025-09-18 04:08:14 --> Helper loaded: security_helper
INFO - 2025-09-18 04:08:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:08:14 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:08:14 --> Form Validation Class Initialized
INFO - 2025-09-18 04:08:14 --> Model "User_model" initialized
INFO - 2025-09-18 09:08:14 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:08:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:08:14 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:08:14 --> Controller Class Initialized
INFO - 2025-09-18 09:08:14 --> Model "Pages_model" initialized
INFO - 2025-09-18 09:08:14 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:08:14 --> Model "Download_model" initialized
INFO - 2025-09-18 09:08:14 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 09:08:14 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 09:08:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-09-18 09:08:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:08:14 --> Model "Log_model" initialized
INFO - 2025-09-18 09:08:14 --> Final output sent to browser
DEBUG - 2025-09-18 09:08:14 --> Total execution time: 0.1209
INFO - 2025-09-18 04:08:31 --> Config Class Initialized
INFO - 2025-09-18 04:08:31 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:08:31 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:08:31 --> Utf8 Class Initialized
INFO - 2025-09-18 04:08:31 --> URI Class Initialized
DEBUG - 2025-09-18 04:08:31 --> No URI present. Default controller set.
INFO - 2025-09-18 04:08:31 --> Router Class Initialized
INFO - 2025-09-18 04:08:31 --> Output Class Initialized
INFO - 2025-09-18 04:08:31 --> Security Class Initialized
DEBUG - 2025-09-18 04:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:08:31 --> CSRF cookie sent
INFO - 2025-09-18 04:08:31 --> Input Class Initialized
INFO - 2025-09-18 04:08:31 --> Language Class Initialized
INFO - 2025-09-18 04:08:31 --> Loader Class Initialized
INFO - 2025-09-18 04:08:31 --> Helper loaded: url_helper
INFO - 2025-09-18 04:08:31 --> Helper loaded: text_helper
INFO - 2025-09-18 04:08:31 --> Helper loaded: string_helper
INFO - 2025-09-18 04:08:31 --> Helper loaded: form_helper
INFO - 2025-09-18 04:08:31 --> Helper loaded: download_helper
INFO - 2025-09-18 04:08:31 --> Helper loaded: security_helper
INFO - 2025-09-18 04:08:31 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:08:31 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:08:31 --> Form Validation Class Initialized
INFO - 2025-09-18 04:08:31 --> Model "User_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:08:31 --> Controller Class Initialized
INFO - 2025-09-18 09:08:31 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Video_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:08:31 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:08:32 --> Pagination Class Initialized
INFO - 2025-09-18 09:08:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:08:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:08:33 --> Model "Log_model" initialized
INFO - 2025-09-18 09:08:33 --> Final output sent to browser
DEBUG - 2025-09-18 09:08:33 --> Total execution time: 2.4869
INFO - 2025-09-18 04:09:00 --> Config Class Initialized
INFO - 2025-09-18 04:09:00 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:09:00 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:09:00 --> Utf8 Class Initialized
INFO - 2025-09-18 04:09:00 --> URI Class Initialized
INFO - 2025-09-18 04:09:00 --> Router Class Initialized
INFO - 2025-09-18 04:09:00 --> Output Class Initialized
INFO - 2025-09-18 04:09:00 --> Security Class Initialized
DEBUG - 2025-09-18 04:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:09:00 --> CSRF cookie sent
INFO - 2025-09-18 04:09:00 --> Input Class Initialized
INFO - 2025-09-18 04:09:00 --> Language Class Initialized
INFO - 2025-09-18 04:09:00 --> Loader Class Initialized
INFO - 2025-09-18 04:09:00 --> Helper loaded: url_helper
INFO - 2025-09-18 04:09:00 --> Helper loaded: text_helper
INFO - 2025-09-18 04:09:00 --> Helper loaded: string_helper
INFO - 2025-09-18 04:09:00 --> Helper loaded: form_helper
INFO - 2025-09-18 04:09:00 --> Helper loaded: download_helper
INFO - 2025-09-18 04:09:00 --> Helper loaded: security_helper
INFO - 2025-09-18 04:09:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:09:00 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:09:00 --> Form Validation Class Initialized
INFO - 2025-09-18 04:09:00 --> Model "User_model" initialized
INFO - 2025-09-18 09:09:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:09:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:09:00 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:09:00 --> Controller Class Initialized
INFO - 2025-09-18 09:09:00 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:09:00 --> Model "Kategori_model" initialized
INFO - 2025-09-18 09:09:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:09:00 --> Pagination Class Initialized
INFO - 2025-09-18 09:09:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2025-09-18 09:09:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:09:00 --> Model "Log_model" initialized
INFO - 2025-09-18 09:09:00 --> Final output sent to browser
DEBUG - 2025-09-18 09:09:00 --> Total execution time: 0.2126
INFO - 2025-09-18 04:09:05 --> Config Class Initialized
INFO - 2025-09-18 04:09:05 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:09:05 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:09:05 --> Utf8 Class Initialized
INFO - 2025-09-18 04:09:05 --> URI Class Initialized
INFO - 2025-09-18 04:09:05 --> Router Class Initialized
INFO - 2025-09-18 04:09:05 --> Output Class Initialized
INFO - 2025-09-18 04:09:05 --> Security Class Initialized
DEBUG - 2025-09-18 04:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:09:05 --> CSRF cookie sent
INFO - 2025-09-18 04:09:05 --> Input Class Initialized
INFO - 2025-09-18 04:09:05 --> Language Class Initialized
INFO - 2025-09-18 04:09:05 --> Loader Class Initialized
INFO - 2025-09-18 04:09:05 --> Helper loaded: url_helper
INFO - 2025-09-18 04:09:05 --> Helper loaded: text_helper
INFO - 2025-09-18 04:09:05 --> Helper loaded: string_helper
INFO - 2025-09-18 04:09:05 --> Helper loaded: form_helper
INFO - 2025-09-18 04:09:05 --> Helper loaded: download_helper
INFO - 2025-09-18 04:09:05 --> Helper loaded: security_helper
INFO - 2025-09-18 04:09:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:09:05 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:09:05 --> Form Validation Class Initialized
INFO - 2025-09-18 04:09:05 --> Model "User_model" initialized
INFO - 2025-09-18 09:09:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:09:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:09:05 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:09:05 --> Controller Class Initialized
INFO - 2025-09-18 09:09:05 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:09:05 --> Model "Kategori_model" initialized
INFO - 2025-09-18 09:09:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/read.php
INFO - 2025-09-18 09:09:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:09:05 --> Model "Log_model" initialized
INFO - 2025-09-18 09:09:05 --> Final output sent to browser
DEBUG - 2025-09-18 09:09:05 --> Total execution time: 0.1653
INFO - 2025-09-18 04:09:19 --> Config Class Initialized
INFO - 2025-09-18 04:09:19 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:09:19 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:09:19 --> Utf8 Class Initialized
INFO - 2025-09-18 04:09:19 --> URI Class Initialized
DEBUG - 2025-09-18 04:09:19 --> No URI present. Default controller set.
INFO - 2025-09-18 04:09:19 --> Router Class Initialized
INFO - 2025-09-18 04:09:19 --> Output Class Initialized
INFO - 2025-09-18 04:09:19 --> Security Class Initialized
DEBUG - 2025-09-18 04:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:09:19 --> CSRF cookie sent
INFO - 2025-09-18 04:09:19 --> Input Class Initialized
INFO - 2025-09-18 04:09:19 --> Language Class Initialized
INFO - 2025-09-18 04:09:19 --> Loader Class Initialized
INFO - 2025-09-18 04:09:19 --> Helper loaded: url_helper
INFO - 2025-09-18 04:09:19 --> Helper loaded: text_helper
INFO - 2025-09-18 04:09:19 --> Helper loaded: string_helper
INFO - 2025-09-18 04:09:19 --> Helper loaded: form_helper
INFO - 2025-09-18 04:09:19 --> Helper loaded: download_helper
INFO - 2025-09-18 04:09:19 --> Helper loaded: security_helper
INFO - 2025-09-18 04:09:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:09:19 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:09:19 --> Form Validation Class Initialized
INFO - 2025-09-18 04:09:19 --> Model "User_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:09:19 --> Controller Class Initialized
INFO - 2025-09-18 09:09:19 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Video_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:09:19 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:09:19 --> Pagination Class Initialized
INFO - 2025-09-18 09:09:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:09:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:09:19 --> Model "Log_model" initialized
INFO - 2025-09-18 09:09:19 --> Final output sent to browser
DEBUG - 2025-09-18 09:09:19 --> Total execution time: 0.1015
INFO - 2025-09-18 04:09:34 --> Config Class Initialized
INFO - 2025-09-18 04:09:34 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:09:34 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:09:34 --> Utf8 Class Initialized
INFO - 2025-09-18 04:09:34 --> URI Class Initialized
DEBUG - 2025-09-18 04:09:34 --> No URI present. Default controller set.
INFO - 2025-09-18 04:09:34 --> Router Class Initialized
INFO - 2025-09-18 04:09:34 --> Output Class Initialized
INFO - 2025-09-18 04:09:34 --> Security Class Initialized
DEBUG - 2025-09-18 04:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:09:34 --> CSRF cookie sent
INFO - 2025-09-18 04:09:34 --> Input Class Initialized
INFO - 2025-09-18 04:09:34 --> Language Class Initialized
INFO - 2025-09-18 04:09:34 --> Loader Class Initialized
INFO - 2025-09-18 04:09:34 --> Helper loaded: url_helper
INFO - 2025-09-18 04:09:34 --> Helper loaded: text_helper
INFO - 2025-09-18 04:09:34 --> Helper loaded: string_helper
INFO - 2025-09-18 04:09:34 --> Helper loaded: form_helper
INFO - 2025-09-18 04:09:34 --> Helper loaded: download_helper
INFO - 2025-09-18 04:09:34 --> Helper loaded: security_helper
INFO - 2025-09-18 04:09:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:09:34 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:09:34 --> Form Validation Class Initialized
INFO - 2025-09-18 04:09:34 --> Model "User_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:09:34 --> Controller Class Initialized
INFO - 2025-09-18 09:09:34 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Video_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:09:34 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:09:34 --> Pagination Class Initialized
INFO - 2025-09-18 09:09:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:09:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:09:34 --> Model "Log_model" initialized
INFO - 2025-09-18 09:09:34 --> Final output sent to browser
DEBUG - 2025-09-18 09:09:34 --> Total execution time: 0.1017
INFO - 2025-09-18 04:11:46 --> Config Class Initialized
INFO - 2025-09-18 04:11:46 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:11:46 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:11:46 --> Utf8 Class Initialized
INFO - 2025-09-18 04:11:46 --> URI Class Initialized
DEBUG - 2025-09-18 04:11:46 --> No URI present. Default controller set.
INFO - 2025-09-18 04:11:46 --> Router Class Initialized
INFO - 2025-09-18 04:11:46 --> Output Class Initialized
INFO - 2025-09-18 04:11:46 --> Security Class Initialized
DEBUG - 2025-09-18 04:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:11:46 --> CSRF cookie sent
INFO - 2025-09-18 04:11:46 --> Input Class Initialized
INFO - 2025-09-18 04:11:46 --> Language Class Initialized
INFO - 2025-09-18 04:11:46 --> Loader Class Initialized
INFO - 2025-09-18 04:11:46 --> Helper loaded: url_helper
INFO - 2025-09-18 04:11:46 --> Helper loaded: text_helper
INFO - 2025-09-18 04:11:46 --> Helper loaded: string_helper
INFO - 2025-09-18 04:11:46 --> Helper loaded: form_helper
INFO - 2025-09-18 04:11:46 --> Helper loaded: download_helper
INFO - 2025-09-18 04:11:46 --> Helper loaded: security_helper
INFO - 2025-09-18 04:11:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:11:46 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:11:46 --> Form Validation Class Initialized
INFO - 2025-09-18 04:11:46 --> Model "User_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:11:46 --> Controller Class Initialized
INFO - 2025-09-18 09:11:46 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Video_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:11:46 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:11:46 --> Pagination Class Initialized
INFO - 2025-09-18 09:11:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:11:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:11:46 --> Model "Log_model" initialized
INFO - 2025-09-18 09:11:46 --> Final output sent to browser
DEBUG - 2025-09-18 09:11:46 --> Total execution time: 0.1615
INFO - 2025-09-18 04:12:30 --> Config Class Initialized
INFO - 2025-09-18 04:12:30 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:12:30 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:12:30 --> Utf8 Class Initialized
INFO - 2025-09-18 04:12:30 --> URI Class Initialized
DEBUG - 2025-09-18 04:12:30 --> No URI present. Default controller set.
INFO - 2025-09-18 04:12:30 --> Router Class Initialized
INFO - 2025-09-18 04:12:30 --> Output Class Initialized
INFO - 2025-09-18 04:12:30 --> Security Class Initialized
DEBUG - 2025-09-18 04:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:12:30 --> CSRF cookie sent
INFO - 2025-09-18 04:12:30 --> Input Class Initialized
INFO - 2025-09-18 04:12:30 --> Language Class Initialized
INFO - 2025-09-18 04:12:30 --> Loader Class Initialized
INFO - 2025-09-18 04:12:30 --> Helper loaded: url_helper
INFO - 2025-09-18 04:12:30 --> Helper loaded: text_helper
INFO - 2025-09-18 04:12:30 --> Helper loaded: string_helper
INFO - 2025-09-18 04:12:30 --> Helper loaded: form_helper
INFO - 2025-09-18 04:12:30 --> Helper loaded: download_helper
INFO - 2025-09-18 04:12:30 --> Helper loaded: security_helper
INFO - 2025-09-18 04:12:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:12:30 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:12:30 --> Form Validation Class Initialized
INFO - 2025-09-18 04:12:30 --> Model "User_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:12:30 --> Controller Class Initialized
INFO - 2025-09-18 09:12:30 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Video_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:12:30 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:12:31 --> Pagination Class Initialized
INFO - 2025-09-18 09:12:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:12:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:12:31 --> Model "Log_model" initialized
INFO - 2025-09-18 09:12:31 --> Final output sent to browser
DEBUG - 2025-09-18 09:12:31 --> Total execution time: 0.1444
INFO - 2025-09-18 04:12:47 --> Config Class Initialized
INFO - 2025-09-18 04:12:47 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:12:47 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:12:47 --> Utf8 Class Initialized
INFO - 2025-09-18 04:12:47 --> URI Class Initialized
DEBUG - 2025-09-18 04:12:47 --> No URI present. Default controller set.
INFO - 2025-09-18 04:12:47 --> Router Class Initialized
INFO - 2025-09-18 04:12:47 --> Output Class Initialized
INFO - 2025-09-18 04:12:47 --> Security Class Initialized
DEBUG - 2025-09-18 04:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:12:47 --> CSRF cookie sent
INFO - 2025-09-18 04:12:47 --> Input Class Initialized
INFO - 2025-09-18 04:12:47 --> Language Class Initialized
INFO - 2025-09-18 04:12:47 --> Loader Class Initialized
INFO - 2025-09-18 04:12:47 --> Helper loaded: url_helper
INFO - 2025-09-18 04:12:47 --> Helper loaded: text_helper
INFO - 2025-09-18 04:12:47 --> Helper loaded: string_helper
INFO - 2025-09-18 04:12:47 --> Helper loaded: form_helper
INFO - 2025-09-18 04:12:47 --> Helper loaded: download_helper
INFO - 2025-09-18 04:12:47 --> Helper loaded: security_helper
INFO - 2025-09-18 04:12:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:12:47 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:12:47 --> Form Validation Class Initialized
INFO - 2025-09-18 04:12:47 --> Model "User_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:12:47 --> Controller Class Initialized
INFO - 2025-09-18 09:12:47 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Video_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:12:47 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:12:47 --> Pagination Class Initialized
INFO - 2025-09-18 09:12:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:12:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:12:47 --> Model "Log_model" initialized
INFO - 2025-09-18 09:12:47 --> Final output sent to browser
DEBUG - 2025-09-18 09:12:47 --> Total execution time: 0.1289
INFO - 2025-09-18 04:13:01 --> Config Class Initialized
INFO - 2025-09-18 04:13:01 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:13:01 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:13:01 --> Utf8 Class Initialized
INFO - 2025-09-18 04:13:01 --> URI Class Initialized
DEBUG - 2025-09-18 04:13:01 --> No URI present. Default controller set.
INFO - 2025-09-18 04:13:01 --> Router Class Initialized
INFO - 2025-09-18 04:13:01 --> Output Class Initialized
INFO - 2025-09-18 04:13:01 --> Security Class Initialized
DEBUG - 2025-09-18 04:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:13:01 --> CSRF cookie sent
INFO - 2025-09-18 04:13:01 --> Input Class Initialized
INFO - 2025-09-18 04:13:01 --> Language Class Initialized
INFO - 2025-09-18 04:13:01 --> Loader Class Initialized
INFO - 2025-09-18 04:13:01 --> Helper loaded: url_helper
INFO - 2025-09-18 04:13:01 --> Helper loaded: text_helper
INFO - 2025-09-18 04:13:01 --> Helper loaded: string_helper
INFO - 2025-09-18 04:13:01 --> Helper loaded: form_helper
INFO - 2025-09-18 04:13:01 --> Helper loaded: download_helper
INFO - 2025-09-18 04:13:01 --> Helper loaded: security_helper
INFO - 2025-09-18 04:13:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:13:01 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:13:01 --> Form Validation Class Initialized
INFO - 2025-09-18 04:13:01 --> Model "User_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:13:01 --> Controller Class Initialized
INFO - 2025-09-18 09:13:01 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Video_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:13:01 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:13:01 --> Pagination Class Initialized
INFO - 2025-09-18 09:13:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:13:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:13:01 --> Model "Log_model" initialized
INFO - 2025-09-18 09:13:01 --> Final output sent to browser
DEBUG - 2025-09-18 09:13:01 --> Total execution time: 0.1467
INFO - 2025-09-18 04:13:03 --> Config Class Initialized
INFO - 2025-09-18 04:13:03 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:13:03 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:13:03 --> Utf8 Class Initialized
INFO - 2025-09-18 04:13:03 --> URI Class Initialized
DEBUG - 2025-09-18 04:13:03 --> No URI present. Default controller set.
INFO - 2025-09-18 04:13:03 --> Router Class Initialized
INFO - 2025-09-18 04:13:03 --> Output Class Initialized
INFO - 2025-09-18 04:13:03 --> Security Class Initialized
DEBUG - 2025-09-18 04:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:13:03 --> CSRF cookie sent
INFO - 2025-09-18 04:13:03 --> Input Class Initialized
INFO - 2025-09-18 04:13:03 --> Language Class Initialized
INFO - 2025-09-18 04:13:03 --> Loader Class Initialized
INFO - 2025-09-18 04:13:03 --> Helper loaded: url_helper
INFO - 2025-09-18 04:13:03 --> Helper loaded: text_helper
INFO - 2025-09-18 04:13:03 --> Helper loaded: string_helper
INFO - 2025-09-18 04:13:03 --> Helper loaded: form_helper
INFO - 2025-09-18 04:13:03 --> Helper loaded: download_helper
INFO - 2025-09-18 04:13:03 --> Helper loaded: security_helper
INFO - 2025-09-18 04:13:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:13:03 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:13:03 --> Form Validation Class Initialized
INFO - 2025-09-18 04:13:03 --> Model "User_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:13:03 --> Controller Class Initialized
INFO - 2025-09-18 09:13:03 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Video_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:13:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:13:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:13:03 --> Pagination Class Initialized
INFO - 2025-09-18 09:13:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:13:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:13:03 --> Model "Log_model" initialized
INFO - 2025-09-18 09:13:03 --> Final output sent to browser
DEBUG - 2025-09-18 09:13:03 --> Total execution time: 0.1040
INFO - 2025-09-18 04:13:12 --> Config Class Initialized
INFO - 2025-09-18 04:13:12 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:13:12 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:13:12 --> Utf8 Class Initialized
INFO - 2025-09-18 04:13:12 --> URI Class Initialized
DEBUG - 2025-09-18 04:13:12 --> No URI present. Default controller set.
INFO - 2025-09-18 04:13:12 --> Router Class Initialized
INFO - 2025-09-18 04:13:12 --> Output Class Initialized
INFO - 2025-09-18 04:13:12 --> Security Class Initialized
DEBUG - 2025-09-18 04:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:13:12 --> CSRF cookie sent
INFO - 2025-09-18 04:13:12 --> Input Class Initialized
INFO - 2025-09-18 04:13:12 --> Language Class Initialized
INFO - 2025-09-18 04:13:12 --> Loader Class Initialized
INFO - 2025-09-18 04:13:12 --> Helper loaded: url_helper
INFO - 2025-09-18 04:13:12 --> Helper loaded: text_helper
INFO - 2025-09-18 04:13:12 --> Helper loaded: string_helper
INFO - 2025-09-18 04:13:12 --> Helper loaded: form_helper
INFO - 2025-09-18 04:13:12 --> Helper loaded: download_helper
INFO - 2025-09-18 04:13:12 --> Helper loaded: security_helper
INFO - 2025-09-18 04:13:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:13:12 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:13:12 --> Form Validation Class Initialized
INFO - 2025-09-18 04:13:12 --> Model "User_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:13:12 --> Controller Class Initialized
INFO - 2025-09-18 09:13:12 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Video_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:13:12 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:13:12 --> Pagination Class Initialized
INFO - 2025-09-18 09:13:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:13:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:13:12 --> Model "Log_model" initialized
INFO - 2025-09-18 09:13:12 --> Final output sent to browser
DEBUG - 2025-09-18 09:13:12 --> Total execution time: 0.0775
INFO - 2025-09-18 04:13:26 --> Config Class Initialized
INFO - 2025-09-18 04:13:26 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:13:26 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:13:26 --> Utf8 Class Initialized
INFO - 2025-09-18 04:13:26 --> URI Class Initialized
DEBUG - 2025-09-18 04:13:26 --> No URI present. Default controller set.
INFO - 2025-09-18 04:13:26 --> Router Class Initialized
INFO - 2025-09-18 04:13:26 --> Output Class Initialized
INFO - 2025-09-18 04:13:26 --> Security Class Initialized
DEBUG - 2025-09-18 04:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:13:26 --> CSRF cookie sent
INFO - 2025-09-18 04:13:26 --> Input Class Initialized
INFO - 2025-09-18 04:13:26 --> Language Class Initialized
INFO - 2025-09-18 04:13:26 --> Loader Class Initialized
INFO - 2025-09-18 04:13:26 --> Helper loaded: url_helper
INFO - 2025-09-18 04:13:26 --> Helper loaded: text_helper
INFO - 2025-09-18 04:13:26 --> Helper loaded: string_helper
INFO - 2025-09-18 04:13:26 --> Helper loaded: form_helper
INFO - 2025-09-18 04:13:26 --> Helper loaded: download_helper
INFO - 2025-09-18 04:13:26 --> Helper loaded: security_helper
INFO - 2025-09-18 04:13:26 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:13:26 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:13:26 --> Form Validation Class Initialized
INFO - 2025-09-18 04:13:26 --> Model "User_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:13:26 --> Controller Class Initialized
INFO - 2025-09-18 09:13:26 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Video_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:13:26 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:13:26 --> Pagination Class Initialized
INFO - 2025-09-18 09:13:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:13:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:13:26 --> Model "Log_model" initialized
INFO - 2025-09-18 09:13:26 --> Final output sent to browser
DEBUG - 2025-09-18 09:13:26 --> Total execution time: 0.1297
INFO - 2025-09-18 04:13:29 --> Config Class Initialized
INFO - 2025-09-18 04:13:29 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:13:29 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:13:29 --> Utf8 Class Initialized
INFO - 2025-09-18 04:13:29 --> URI Class Initialized
DEBUG - 2025-09-18 04:13:29 --> No URI present. Default controller set.
INFO - 2025-09-18 04:13:29 --> Router Class Initialized
INFO - 2025-09-18 04:13:29 --> Output Class Initialized
INFO - 2025-09-18 04:13:29 --> Security Class Initialized
DEBUG - 2025-09-18 04:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:13:29 --> CSRF cookie sent
INFO - 2025-09-18 04:13:29 --> Input Class Initialized
INFO - 2025-09-18 04:13:29 --> Language Class Initialized
INFO - 2025-09-18 04:13:29 --> Loader Class Initialized
INFO - 2025-09-18 04:13:29 --> Helper loaded: url_helper
INFO - 2025-09-18 04:13:29 --> Helper loaded: text_helper
INFO - 2025-09-18 04:13:29 --> Helper loaded: string_helper
INFO - 2025-09-18 04:13:29 --> Helper loaded: form_helper
INFO - 2025-09-18 04:13:29 --> Helper loaded: download_helper
INFO - 2025-09-18 04:13:29 --> Helper loaded: security_helper
INFO - 2025-09-18 04:13:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:13:29 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:13:29 --> Form Validation Class Initialized
INFO - 2025-09-18 04:13:29 --> Model "User_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:13:29 --> Controller Class Initialized
INFO - 2025-09-18 09:13:29 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Video_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:13:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:13:29 --> Pagination Class Initialized
INFO - 2025-09-18 09:13:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:13:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:13:29 --> Model "Log_model" initialized
INFO - 2025-09-18 09:13:29 --> Final output sent to browser
DEBUG - 2025-09-18 09:13:29 --> Total execution time: 0.1883
INFO - 2025-09-18 04:16:00 --> Config Class Initialized
INFO - 2025-09-18 04:16:00 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:16:00 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:16:00 --> Utf8 Class Initialized
INFO - 2025-09-18 04:16:00 --> URI Class Initialized
DEBUG - 2025-09-18 04:16:00 --> No URI present. Default controller set.
INFO - 2025-09-18 04:16:00 --> Router Class Initialized
INFO - 2025-09-18 04:16:00 --> Output Class Initialized
INFO - 2025-09-18 04:16:00 --> Security Class Initialized
DEBUG - 2025-09-18 04:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:16:00 --> CSRF cookie sent
INFO - 2025-09-18 04:16:00 --> Input Class Initialized
INFO - 2025-09-18 04:16:00 --> Language Class Initialized
INFO - 2025-09-18 04:16:00 --> Loader Class Initialized
INFO - 2025-09-18 04:16:00 --> Helper loaded: url_helper
INFO - 2025-09-18 04:16:00 --> Helper loaded: text_helper
INFO - 2025-09-18 04:16:00 --> Helper loaded: string_helper
INFO - 2025-09-18 04:16:00 --> Helper loaded: form_helper
INFO - 2025-09-18 04:16:00 --> Helper loaded: download_helper
INFO - 2025-09-18 04:16:00 --> Helper loaded: security_helper
INFO - 2025-09-18 04:16:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:16:00 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:16:00 --> Form Validation Class Initialized
INFO - 2025-09-18 04:16:00 --> Model "User_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:16:00 --> Controller Class Initialized
INFO - 2025-09-18 09:16:00 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Video_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:16:00 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:16:00 --> Pagination Class Initialized
INFO - 2025-09-18 09:16:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:16:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:16:00 --> Model "Log_model" initialized
INFO - 2025-09-18 09:16:00 --> Final output sent to browser
DEBUG - 2025-09-18 09:16:00 --> Total execution time: 0.2011
INFO - 2025-09-18 04:16:07 --> Config Class Initialized
INFO - 2025-09-18 04:16:07 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:16:07 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:16:07 --> Utf8 Class Initialized
INFO - 2025-09-18 04:16:07 --> URI Class Initialized
DEBUG - 2025-09-18 04:16:07 --> No URI present. Default controller set.
INFO - 2025-09-18 04:16:07 --> Router Class Initialized
INFO - 2025-09-18 04:16:07 --> Output Class Initialized
INFO - 2025-09-18 04:16:07 --> Security Class Initialized
DEBUG - 2025-09-18 04:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:16:07 --> CSRF cookie sent
INFO - 2025-09-18 04:16:07 --> Input Class Initialized
INFO - 2025-09-18 04:16:07 --> Language Class Initialized
INFO - 2025-09-18 04:16:07 --> Loader Class Initialized
INFO - 2025-09-18 04:16:07 --> Helper loaded: url_helper
INFO - 2025-09-18 04:16:07 --> Helper loaded: text_helper
INFO - 2025-09-18 04:16:07 --> Helper loaded: string_helper
INFO - 2025-09-18 04:16:07 --> Helper loaded: form_helper
INFO - 2025-09-18 04:16:07 --> Helper loaded: download_helper
INFO - 2025-09-18 04:16:07 --> Helper loaded: security_helper
INFO - 2025-09-18 04:16:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:16:07 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:16:07 --> Form Validation Class Initialized
INFO - 2025-09-18 04:16:07 --> Model "User_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:16:07 --> Controller Class Initialized
INFO - 2025-09-18 09:16:07 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Video_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:16:07 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:16:07 --> Pagination Class Initialized
INFO - 2025-09-18 09:16:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:16:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:16:07 --> Model "Log_model" initialized
INFO - 2025-09-18 09:16:07 --> Final output sent to browser
DEBUG - 2025-09-18 09:16:07 --> Total execution time: 0.1219
INFO - 2025-09-18 04:16:21 --> Config Class Initialized
INFO - 2025-09-18 04:16:21 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:16:21 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:16:21 --> Utf8 Class Initialized
INFO - 2025-09-18 04:16:21 --> URI Class Initialized
DEBUG - 2025-09-18 04:16:21 --> No URI present. Default controller set.
INFO - 2025-09-18 04:16:21 --> Router Class Initialized
INFO - 2025-09-18 04:16:21 --> Output Class Initialized
INFO - 2025-09-18 04:16:21 --> Security Class Initialized
DEBUG - 2025-09-18 04:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:16:21 --> CSRF cookie sent
INFO - 2025-09-18 04:16:21 --> Input Class Initialized
INFO - 2025-09-18 04:16:21 --> Language Class Initialized
INFO - 2025-09-18 04:16:21 --> Loader Class Initialized
INFO - 2025-09-18 04:16:21 --> Helper loaded: url_helper
INFO - 2025-09-18 04:16:21 --> Helper loaded: text_helper
INFO - 2025-09-18 04:16:21 --> Helper loaded: string_helper
INFO - 2025-09-18 04:16:21 --> Helper loaded: form_helper
INFO - 2025-09-18 04:16:21 --> Helper loaded: download_helper
INFO - 2025-09-18 04:16:21 --> Helper loaded: security_helper
INFO - 2025-09-18 04:16:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:16:21 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:16:21 --> Form Validation Class Initialized
INFO - 2025-09-18 04:16:21 --> Model "User_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:16:21 --> Controller Class Initialized
INFO - 2025-09-18 09:16:21 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Video_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:16:21 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:16:21 --> Pagination Class Initialized
INFO - 2025-09-18 09:16:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:16:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:16:21 --> Model "Log_model" initialized
INFO - 2025-09-18 09:16:21 --> Final output sent to browser
DEBUG - 2025-09-18 09:16:21 --> Total execution time: 0.2132
INFO - 2025-09-18 04:16:23 --> Config Class Initialized
INFO - 2025-09-18 04:16:23 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:16:23 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:16:23 --> Utf8 Class Initialized
INFO - 2025-09-18 04:16:23 --> URI Class Initialized
DEBUG - 2025-09-18 04:16:23 --> No URI present. Default controller set.
INFO - 2025-09-18 04:16:23 --> Router Class Initialized
INFO - 2025-09-18 04:16:23 --> Output Class Initialized
INFO - 2025-09-18 04:16:23 --> Security Class Initialized
DEBUG - 2025-09-18 04:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:16:23 --> CSRF cookie sent
INFO - 2025-09-18 04:16:23 --> Input Class Initialized
INFO - 2025-09-18 04:16:23 --> Language Class Initialized
INFO - 2025-09-18 04:16:23 --> Loader Class Initialized
INFO - 2025-09-18 04:16:23 --> Helper loaded: url_helper
INFO - 2025-09-18 04:16:23 --> Helper loaded: text_helper
INFO - 2025-09-18 04:16:23 --> Helper loaded: string_helper
INFO - 2025-09-18 04:16:23 --> Helper loaded: form_helper
INFO - 2025-09-18 04:16:23 --> Helper loaded: download_helper
INFO - 2025-09-18 04:16:23 --> Helper loaded: security_helper
INFO - 2025-09-18 04:16:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:16:23 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:16:23 --> Form Validation Class Initialized
INFO - 2025-09-18 04:16:23 --> Model "User_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:16:23 --> Controller Class Initialized
INFO - 2025-09-18 09:16:23 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Video_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:16:23 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:16:23 --> Pagination Class Initialized
INFO - 2025-09-18 09:16:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:16:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:16:23 --> Model "Log_model" initialized
INFO - 2025-09-18 09:16:23 --> Final output sent to browser
DEBUG - 2025-09-18 09:16:23 --> Total execution time: 0.1418
INFO - 2025-09-18 04:20:03 --> Config Class Initialized
INFO - 2025-09-18 04:20:03 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:20:03 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:20:03 --> Utf8 Class Initialized
INFO - 2025-09-18 04:20:04 --> URI Class Initialized
DEBUG - 2025-09-18 04:20:04 --> No URI present. Default controller set.
INFO - 2025-09-18 04:20:04 --> Router Class Initialized
INFO - 2025-09-18 04:20:04 --> Output Class Initialized
INFO - 2025-09-18 04:20:04 --> Security Class Initialized
DEBUG - 2025-09-18 04:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:20:04 --> CSRF cookie sent
INFO - 2025-09-18 04:20:04 --> Input Class Initialized
INFO - 2025-09-18 04:20:04 --> Language Class Initialized
INFO - 2025-09-18 04:20:04 --> Loader Class Initialized
INFO - 2025-09-18 04:20:04 --> Helper loaded: url_helper
INFO - 2025-09-18 04:20:04 --> Helper loaded: text_helper
INFO - 2025-09-18 04:20:04 --> Helper loaded: string_helper
INFO - 2025-09-18 04:20:04 --> Helper loaded: form_helper
INFO - 2025-09-18 04:20:04 --> Helper loaded: download_helper
INFO - 2025-09-18 04:20:04 --> Helper loaded: security_helper
INFO - 2025-09-18 04:20:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:20:04 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:20:04 --> Form Validation Class Initialized
INFO - 2025-09-18 04:20:04 --> Model "User_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:20:04 --> Controller Class Initialized
INFO - 2025-09-18 09:20:04 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Video_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:20:04 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:20:04 --> Pagination Class Initialized
INFO - 2025-09-18 09:20:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:20:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:20:04 --> Model "Log_model" initialized
INFO - 2025-09-18 09:20:04 --> Final output sent to browser
DEBUG - 2025-09-18 09:20:04 --> Total execution time: 0.9928
INFO - 2025-09-18 04:20:18 --> Config Class Initialized
INFO - 2025-09-18 04:20:18 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:20:18 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:20:18 --> Utf8 Class Initialized
INFO - 2025-09-18 04:20:18 --> URI Class Initialized
DEBUG - 2025-09-18 04:20:18 --> No URI present. Default controller set.
INFO - 2025-09-18 04:20:18 --> Router Class Initialized
INFO - 2025-09-18 04:20:18 --> Output Class Initialized
INFO - 2025-09-18 04:20:18 --> Security Class Initialized
DEBUG - 2025-09-18 04:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:20:18 --> CSRF cookie sent
INFO - 2025-09-18 04:20:18 --> Input Class Initialized
INFO - 2025-09-18 04:20:18 --> Language Class Initialized
INFO - 2025-09-18 04:20:18 --> Loader Class Initialized
INFO - 2025-09-18 04:20:18 --> Helper loaded: url_helper
INFO - 2025-09-18 04:20:18 --> Helper loaded: text_helper
INFO - 2025-09-18 04:20:18 --> Helper loaded: string_helper
INFO - 2025-09-18 04:20:18 --> Helper loaded: form_helper
INFO - 2025-09-18 04:20:18 --> Helper loaded: download_helper
INFO - 2025-09-18 04:20:18 --> Helper loaded: security_helper
INFO - 2025-09-18 04:20:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:20:18 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:20:19 --> Form Validation Class Initialized
INFO - 2025-09-18 04:20:19 --> Model "User_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:20:19 --> Controller Class Initialized
INFO - 2025-09-18 09:20:19 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Video_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:20:19 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:20:19 --> Pagination Class Initialized
INFO - 2025-09-18 09:20:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:20:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:20:19 --> Model "Log_model" initialized
INFO - 2025-09-18 09:20:19 --> Final output sent to browser
DEBUG - 2025-09-18 09:20:19 --> Total execution time: 0.1938
INFO - 2025-09-18 04:20:21 --> Config Class Initialized
INFO - 2025-09-18 04:20:21 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:20:21 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:20:21 --> Utf8 Class Initialized
INFO - 2025-09-18 04:20:21 --> URI Class Initialized
DEBUG - 2025-09-18 04:20:21 --> No URI present. Default controller set.
INFO - 2025-09-18 04:20:21 --> Router Class Initialized
INFO - 2025-09-18 04:20:21 --> Output Class Initialized
INFO - 2025-09-18 04:20:21 --> Security Class Initialized
DEBUG - 2025-09-18 04:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:20:21 --> CSRF cookie sent
INFO - 2025-09-18 04:20:21 --> Input Class Initialized
INFO - 2025-09-18 04:20:21 --> Language Class Initialized
INFO - 2025-09-18 04:20:21 --> Loader Class Initialized
INFO - 2025-09-18 04:20:21 --> Helper loaded: url_helper
INFO - 2025-09-18 04:20:21 --> Helper loaded: text_helper
INFO - 2025-09-18 04:20:21 --> Helper loaded: string_helper
INFO - 2025-09-18 04:20:21 --> Helper loaded: form_helper
INFO - 2025-09-18 04:20:21 --> Helper loaded: download_helper
INFO - 2025-09-18 04:20:21 --> Helper loaded: security_helper
INFO - 2025-09-18 04:20:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:20:21 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:20:21 --> Form Validation Class Initialized
INFO - 2025-09-18 04:20:21 --> Model "User_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:20:21 --> Controller Class Initialized
INFO - 2025-09-18 09:20:21 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Video_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:20:21 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:20:21 --> Pagination Class Initialized
INFO - 2025-09-18 09:20:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:20:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:20:21 --> Model "Log_model" initialized
INFO - 2025-09-18 09:20:21 --> Final output sent to browser
DEBUG - 2025-09-18 09:20:21 --> Total execution time: 0.1333
INFO - 2025-09-18 04:22:47 --> Config Class Initialized
INFO - 2025-09-18 04:22:47 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:22:47 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:22:47 --> Utf8 Class Initialized
INFO - 2025-09-18 04:22:47 --> URI Class Initialized
DEBUG - 2025-09-18 04:22:47 --> No URI present. Default controller set.
INFO - 2025-09-18 04:22:47 --> Router Class Initialized
INFO - 2025-09-18 04:22:47 --> Output Class Initialized
INFO - 2025-09-18 04:22:47 --> Security Class Initialized
DEBUG - 2025-09-18 04:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:22:47 --> CSRF cookie sent
INFO - 2025-09-18 04:22:47 --> Input Class Initialized
INFO - 2025-09-18 04:22:47 --> Language Class Initialized
INFO - 2025-09-18 04:22:47 --> Loader Class Initialized
INFO - 2025-09-18 04:22:47 --> Helper loaded: url_helper
INFO - 2025-09-18 04:22:47 --> Helper loaded: text_helper
INFO - 2025-09-18 04:22:47 --> Helper loaded: string_helper
INFO - 2025-09-18 04:22:47 --> Helper loaded: form_helper
INFO - 2025-09-18 04:22:47 --> Helper loaded: download_helper
INFO - 2025-09-18 04:22:47 --> Helper loaded: security_helper
INFO - 2025-09-18 04:22:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:22:47 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:22:47 --> Form Validation Class Initialized
INFO - 2025-09-18 04:22:47 --> Model "User_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:22:47 --> Controller Class Initialized
INFO - 2025-09-18 09:22:47 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Video_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:22:47 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:22:47 --> Pagination Class Initialized
INFO - 2025-09-18 09:22:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:22:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:22:47 --> Model "Log_model" initialized
INFO - 2025-09-18 09:22:47 --> Final output sent to browser
DEBUG - 2025-09-18 09:22:47 --> Total execution time: 0.1200
INFO - 2025-09-18 04:22:54 --> Config Class Initialized
INFO - 2025-09-18 04:22:54 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:22:54 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:22:54 --> Utf8 Class Initialized
INFO - 2025-09-18 04:22:54 --> URI Class Initialized
DEBUG - 2025-09-18 04:22:54 --> No URI present. Default controller set.
INFO - 2025-09-18 04:22:54 --> Router Class Initialized
INFO - 2025-09-18 04:22:54 --> Output Class Initialized
INFO - 2025-09-18 04:22:54 --> Security Class Initialized
DEBUG - 2025-09-18 04:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:22:54 --> CSRF cookie sent
INFO - 2025-09-18 04:22:54 --> Input Class Initialized
INFO - 2025-09-18 04:22:54 --> Language Class Initialized
INFO - 2025-09-18 04:22:54 --> Loader Class Initialized
INFO - 2025-09-18 04:22:54 --> Helper loaded: url_helper
INFO - 2025-09-18 04:22:54 --> Helper loaded: text_helper
INFO - 2025-09-18 04:22:54 --> Helper loaded: string_helper
INFO - 2025-09-18 04:22:54 --> Helper loaded: form_helper
INFO - 2025-09-18 04:22:54 --> Helper loaded: download_helper
INFO - 2025-09-18 04:22:54 --> Helper loaded: security_helper
INFO - 2025-09-18 04:22:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:22:54 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:22:54 --> Form Validation Class Initialized
INFO - 2025-09-18 04:22:54 --> Model "User_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:22:54 --> Controller Class Initialized
INFO - 2025-09-18 09:22:54 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Video_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:22:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:22:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:22:54 --> Pagination Class Initialized
INFO - 2025-09-18 09:22:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:22:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:22:54 --> Model "Log_model" initialized
INFO - 2025-09-18 09:22:54 --> Final output sent to browser
DEBUG - 2025-09-18 09:22:54 --> Total execution time: 0.1144
INFO - 2025-09-18 04:23:08 --> Config Class Initialized
INFO - 2025-09-18 04:23:08 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:23:08 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:23:08 --> Utf8 Class Initialized
INFO - 2025-09-18 04:23:08 --> URI Class Initialized
DEBUG - 2025-09-18 04:23:08 --> No URI present. Default controller set.
INFO - 2025-09-18 04:23:08 --> Router Class Initialized
INFO - 2025-09-18 04:23:08 --> Output Class Initialized
INFO - 2025-09-18 04:23:08 --> Security Class Initialized
DEBUG - 2025-09-18 04:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:23:08 --> CSRF cookie sent
INFO - 2025-09-18 04:23:08 --> Input Class Initialized
INFO - 2025-09-18 04:23:08 --> Language Class Initialized
INFO - 2025-09-18 04:23:08 --> Loader Class Initialized
INFO - 2025-09-18 04:23:08 --> Helper loaded: url_helper
INFO - 2025-09-18 04:23:08 --> Helper loaded: text_helper
INFO - 2025-09-18 04:23:08 --> Helper loaded: string_helper
INFO - 2025-09-18 04:23:08 --> Helper loaded: form_helper
INFO - 2025-09-18 04:23:08 --> Helper loaded: download_helper
INFO - 2025-09-18 04:23:08 --> Helper loaded: security_helper
INFO - 2025-09-18 04:23:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:23:08 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:23:08 --> Form Validation Class Initialized
INFO - 2025-09-18 04:23:08 --> Model "User_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:23:08 --> Controller Class Initialized
INFO - 2025-09-18 09:23:08 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Video_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:23:08 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:23:08 --> Pagination Class Initialized
INFO - 2025-09-18 09:23:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:23:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:23:08 --> Model "Log_model" initialized
INFO - 2025-09-18 09:23:08 --> Final output sent to browser
DEBUG - 2025-09-18 09:23:08 --> Total execution time: 0.1249
INFO - 2025-09-18 04:23:11 --> Config Class Initialized
INFO - 2025-09-18 04:23:11 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:23:11 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:23:11 --> Utf8 Class Initialized
INFO - 2025-09-18 04:23:11 --> URI Class Initialized
DEBUG - 2025-09-18 04:23:11 --> No URI present. Default controller set.
INFO - 2025-09-18 04:23:11 --> Router Class Initialized
INFO - 2025-09-18 04:23:11 --> Output Class Initialized
INFO - 2025-09-18 04:23:11 --> Security Class Initialized
DEBUG - 2025-09-18 04:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:23:11 --> CSRF cookie sent
INFO - 2025-09-18 04:23:11 --> Input Class Initialized
INFO - 2025-09-18 04:23:11 --> Language Class Initialized
INFO - 2025-09-18 04:23:11 --> Loader Class Initialized
INFO - 2025-09-18 04:23:11 --> Helper loaded: url_helper
INFO - 2025-09-18 04:23:11 --> Helper loaded: text_helper
INFO - 2025-09-18 04:23:11 --> Helper loaded: string_helper
INFO - 2025-09-18 04:23:11 --> Helper loaded: form_helper
INFO - 2025-09-18 04:23:11 --> Helper loaded: download_helper
INFO - 2025-09-18 04:23:11 --> Helper loaded: security_helper
INFO - 2025-09-18 04:23:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:23:11 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:23:11 --> Form Validation Class Initialized
INFO - 2025-09-18 04:23:11 --> Model "User_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:23:11 --> Controller Class Initialized
INFO - 2025-09-18 09:23:11 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Video_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:23:11 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:23:11 --> Pagination Class Initialized
INFO - 2025-09-18 09:23:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:23:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:23:11 --> Model "Log_model" initialized
INFO - 2025-09-18 09:23:11 --> Final output sent to browser
DEBUG - 2025-09-18 09:23:11 --> Total execution time: 0.1454
INFO - 2025-09-18 04:23:57 --> Config Class Initialized
INFO - 2025-09-18 04:23:57 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:23:57 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:23:57 --> Utf8 Class Initialized
INFO - 2025-09-18 04:23:57 --> URI Class Initialized
DEBUG - 2025-09-18 04:23:57 --> No URI present. Default controller set.
INFO - 2025-09-18 04:23:57 --> Router Class Initialized
INFO - 2025-09-18 04:23:57 --> Output Class Initialized
INFO - 2025-09-18 04:23:57 --> Security Class Initialized
DEBUG - 2025-09-18 04:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:23:57 --> CSRF cookie sent
INFO - 2025-09-18 04:23:57 --> Input Class Initialized
INFO - 2025-09-18 04:23:57 --> Language Class Initialized
INFO - 2025-09-18 04:23:57 --> Loader Class Initialized
INFO - 2025-09-18 04:23:57 --> Helper loaded: url_helper
INFO - 2025-09-18 04:23:57 --> Helper loaded: text_helper
INFO - 2025-09-18 04:23:57 --> Helper loaded: string_helper
INFO - 2025-09-18 04:23:57 --> Helper loaded: form_helper
INFO - 2025-09-18 04:23:57 --> Helper loaded: download_helper
INFO - 2025-09-18 04:23:57 --> Helper loaded: security_helper
INFO - 2025-09-18 04:23:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:23:57 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:23:57 --> Form Validation Class Initialized
INFO - 2025-09-18 04:23:57 --> Model "User_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:23:57 --> Controller Class Initialized
INFO - 2025-09-18 09:23:57 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Video_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:23:57 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:23:57 --> Pagination Class Initialized
INFO - 2025-09-18 09:23:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:23:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:23:57 --> Model "Log_model" initialized
INFO - 2025-09-18 09:23:57 --> Final output sent to browser
DEBUG - 2025-09-18 09:23:57 --> Total execution time: 0.1146
INFO - 2025-09-18 04:24:19 --> Config Class Initialized
INFO - 2025-09-18 04:24:19 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:24:19 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:24:19 --> Utf8 Class Initialized
INFO - 2025-09-18 04:24:19 --> URI Class Initialized
DEBUG - 2025-09-18 04:24:19 --> No URI present. Default controller set.
INFO - 2025-09-18 04:24:19 --> Router Class Initialized
INFO - 2025-09-18 04:24:19 --> Output Class Initialized
INFO - 2025-09-18 04:24:19 --> Security Class Initialized
DEBUG - 2025-09-18 04:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:24:19 --> CSRF cookie sent
INFO - 2025-09-18 04:24:19 --> Input Class Initialized
INFO - 2025-09-18 04:24:19 --> Language Class Initialized
INFO - 2025-09-18 04:24:19 --> Loader Class Initialized
INFO - 2025-09-18 04:24:19 --> Helper loaded: url_helper
INFO - 2025-09-18 04:24:19 --> Helper loaded: text_helper
INFO - 2025-09-18 04:24:19 --> Helper loaded: string_helper
INFO - 2025-09-18 04:24:19 --> Helper loaded: form_helper
INFO - 2025-09-18 04:24:19 --> Helper loaded: download_helper
INFO - 2025-09-18 04:24:19 --> Helper loaded: security_helper
INFO - 2025-09-18 04:24:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:24:19 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:24:19 --> Form Validation Class Initialized
INFO - 2025-09-18 04:24:19 --> Model "User_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:24:19 --> Controller Class Initialized
INFO - 2025-09-18 09:24:19 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Video_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:24:19 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:24:19 --> Pagination Class Initialized
INFO - 2025-09-18 09:24:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:24:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:24:19 --> Model "Log_model" initialized
INFO - 2025-09-18 09:24:19 --> Final output sent to browser
DEBUG - 2025-09-18 09:24:19 --> Total execution time: 0.1190
INFO - 2025-09-18 04:24:33 --> Config Class Initialized
INFO - 2025-09-18 04:24:33 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:24:33 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:24:33 --> Utf8 Class Initialized
INFO - 2025-09-18 04:24:33 --> URI Class Initialized
DEBUG - 2025-09-18 04:24:33 --> No URI present. Default controller set.
INFO - 2025-09-18 04:24:33 --> Router Class Initialized
INFO - 2025-09-18 04:24:33 --> Output Class Initialized
INFO - 2025-09-18 04:24:33 --> Security Class Initialized
DEBUG - 2025-09-18 04:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:24:33 --> CSRF cookie sent
INFO - 2025-09-18 04:24:33 --> Input Class Initialized
INFO - 2025-09-18 04:24:33 --> Language Class Initialized
INFO - 2025-09-18 04:24:33 --> Loader Class Initialized
INFO - 2025-09-18 04:24:33 --> Helper loaded: url_helper
INFO - 2025-09-18 04:24:33 --> Helper loaded: text_helper
INFO - 2025-09-18 04:24:33 --> Helper loaded: string_helper
INFO - 2025-09-18 04:24:33 --> Helper loaded: form_helper
INFO - 2025-09-18 04:24:33 --> Helper loaded: download_helper
INFO - 2025-09-18 04:24:33 --> Helper loaded: security_helper
INFO - 2025-09-18 04:24:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:24:33 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:24:33 --> Form Validation Class Initialized
INFO - 2025-09-18 04:24:33 --> Model "User_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:24:33 --> Controller Class Initialized
INFO - 2025-09-18 09:24:33 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Video_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:24:33 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:24:33 --> Pagination Class Initialized
INFO - 2025-09-18 09:24:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:24:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:24:33 --> Model "Log_model" initialized
INFO - 2025-09-18 09:24:33 --> Final output sent to browser
DEBUG - 2025-09-18 09:24:33 --> Total execution time: 0.1282
INFO - 2025-09-18 04:24:35 --> Config Class Initialized
INFO - 2025-09-18 04:24:35 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:24:35 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:24:35 --> Utf8 Class Initialized
INFO - 2025-09-18 04:24:35 --> URI Class Initialized
DEBUG - 2025-09-18 04:24:35 --> No URI present. Default controller set.
INFO - 2025-09-18 04:24:35 --> Router Class Initialized
INFO - 2025-09-18 04:24:35 --> Output Class Initialized
INFO - 2025-09-18 04:24:35 --> Security Class Initialized
DEBUG - 2025-09-18 04:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:24:35 --> CSRF cookie sent
INFO - 2025-09-18 04:24:35 --> Input Class Initialized
INFO - 2025-09-18 04:24:35 --> Language Class Initialized
INFO - 2025-09-18 04:24:35 --> Loader Class Initialized
INFO - 2025-09-18 04:24:35 --> Helper loaded: url_helper
INFO - 2025-09-18 04:24:35 --> Helper loaded: text_helper
INFO - 2025-09-18 04:24:35 --> Helper loaded: string_helper
INFO - 2025-09-18 04:24:35 --> Helper loaded: form_helper
INFO - 2025-09-18 04:24:35 --> Helper loaded: download_helper
INFO - 2025-09-18 04:24:35 --> Helper loaded: security_helper
INFO - 2025-09-18 04:24:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:24:35 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:24:35 --> Form Validation Class Initialized
INFO - 2025-09-18 04:24:35 --> Model "User_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:24:35 --> Controller Class Initialized
INFO - 2025-09-18 09:24:35 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Video_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:24:35 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:24:35 --> Pagination Class Initialized
INFO - 2025-09-18 09:24:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:24:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:24:35 --> Model "Log_model" initialized
INFO - 2025-09-18 09:24:35 --> Final output sent to browser
DEBUG - 2025-09-18 09:24:35 --> Total execution time: 0.1297
INFO - 2025-09-18 04:34:18 --> Config Class Initialized
INFO - 2025-09-18 04:34:18 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:34:18 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:34:18 --> Utf8 Class Initialized
INFO - 2025-09-18 04:34:18 --> URI Class Initialized
DEBUG - 2025-09-18 04:34:18 --> No URI present. Default controller set.
INFO - 2025-09-18 04:34:18 --> Router Class Initialized
INFO - 2025-09-18 04:34:18 --> Output Class Initialized
INFO - 2025-09-18 04:34:18 --> Security Class Initialized
DEBUG - 2025-09-18 04:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:34:18 --> CSRF cookie sent
INFO - 2025-09-18 04:34:18 --> Input Class Initialized
INFO - 2025-09-18 04:34:18 --> Language Class Initialized
INFO - 2025-09-18 04:34:18 --> Loader Class Initialized
INFO - 2025-09-18 04:34:18 --> Helper loaded: url_helper
INFO - 2025-09-18 04:34:18 --> Helper loaded: text_helper
INFO - 2025-09-18 04:34:18 --> Helper loaded: string_helper
INFO - 2025-09-18 04:34:18 --> Helper loaded: form_helper
INFO - 2025-09-18 04:34:18 --> Helper loaded: download_helper
INFO - 2025-09-18 04:34:18 --> Helper loaded: security_helper
INFO - 2025-09-18 04:34:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:34:18 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:34:18 --> Form Validation Class Initialized
INFO - 2025-09-18 04:34:18 --> Model "User_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:34:18 --> Controller Class Initialized
INFO - 2025-09-18 09:34:18 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Video_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:34:18 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:34:18 --> Pagination Class Initialized
INFO - 2025-09-18 09:34:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:34:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:34:18 --> Model "Log_model" initialized
INFO - 2025-09-18 09:34:18 --> Final output sent to browser
DEBUG - 2025-09-18 09:34:18 --> Total execution time: 0.1062
INFO - 2025-09-18 04:34:34 --> Config Class Initialized
INFO - 2025-09-18 04:34:34 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:34:34 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:34:34 --> Utf8 Class Initialized
INFO - 2025-09-18 04:34:34 --> URI Class Initialized
DEBUG - 2025-09-18 04:34:34 --> No URI present. Default controller set.
INFO - 2025-09-18 04:34:34 --> Router Class Initialized
INFO - 2025-09-18 04:34:34 --> Output Class Initialized
INFO - 2025-09-18 04:34:34 --> Security Class Initialized
DEBUG - 2025-09-18 04:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:34:34 --> CSRF cookie sent
INFO - 2025-09-18 04:34:34 --> Input Class Initialized
INFO - 2025-09-18 04:34:34 --> Language Class Initialized
INFO - 2025-09-18 04:34:34 --> Loader Class Initialized
INFO - 2025-09-18 04:34:34 --> Helper loaded: url_helper
INFO - 2025-09-18 04:34:34 --> Helper loaded: text_helper
INFO - 2025-09-18 04:34:34 --> Helper loaded: string_helper
INFO - 2025-09-18 04:34:34 --> Helper loaded: form_helper
INFO - 2025-09-18 04:34:34 --> Helper loaded: download_helper
INFO - 2025-09-18 04:34:34 --> Helper loaded: security_helper
INFO - 2025-09-18 04:34:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:34:34 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:34:34 --> Form Validation Class Initialized
INFO - 2025-09-18 04:34:34 --> Model "User_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:34:34 --> Controller Class Initialized
INFO - 2025-09-18 09:34:34 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Video_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:34:34 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:34:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:34:34 --> Pagination Class Initialized
INFO - 2025-09-18 09:34:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:34:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:34:34 --> Model "Log_model" initialized
INFO - 2025-09-18 09:34:34 --> Final output sent to browser
DEBUG - 2025-09-18 09:34:34 --> Total execution time: 0.1889
INFO - 2025-09-18 04:34:37 --> Config Class Initialized
INFO - 2025-09-18 04:34:37 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:34:37 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:34:37 --> Utf8 Class Initialized
INFO - 2025-09-18 04:34:37 --> URI Class Initialized
DEBUG - 2025-09-18 04:34:37 --> No URI present. Default controller set.
INFO - 2025-09-18 04:34:37 --> Router Class Initialized
INFO - 2025-09-18 04:34:37 --> Output Class Initialized
INFO - 2025-09-18 04:34:37 --> Security Class Initialized
DEBUG - 2025-09-18 04:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:34:37 --> CSRF cookie sent
INFO - 2025-09-18 04:34:37 --> Input Class Initialized
INFO - 2025-09-18 04:34:37 --> Language Class Initialized
INFO - 2025-09-18 04:34:37 --> Loader Class Initialized
INFO - 2025-09-18 04:34:37 --> Helper loaded: url_helper
INFO - 2025-09-18 04:34:37 --> Helper loaded: text_helper
INFO - 2025-09-18 04:34:37 --> Helper loaded: string_helper
INFO - 2025-09-18 04:34:37 --> Helper loaded: form_helper
INFO - 2025-09-18 04:34:37 --> Helper loaded: download_helper
INFO - 2025-09-18 04:34:37 --> Helper loaded: security_helper
INFO - 2025-09-18 04:34:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:34:37 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:34:37 --> Form Validation Class Initialized
INFO - 2025-09-18 04:34:37 --> Model "User_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:34:37 --> Controller Class Initialized
INFO - 2025-09-18 09:34:37 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Video_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:34:37 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:34:37 --> Pagination Class Initialized
INFO - 2025-09-18 09:34:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:34:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:34:37 --> Model "Log_model" initialized
INFO - 2025-09-18 09:34:37 --> Final output sent to browser
DEBUG - 2025-09-18 09:34:37 --> Total execution time: 0.1707
INFO - 2025-09-18 04:35:52 --> Config Class Initialized
INFO - 2025-09-18 04:35:52 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:35:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:35:52 --> Utf8 Class Initialized
INFO - 2025-09-18 04:35:52 --> URI Class Initialized
DEBUG - 2025-09-18 04:35:52 --> No URI present. Default controller set.
INFO - 2025-09-18 04:35:52 --> Router Class Initialized
INFO - 2025-09-18 04:35:52 --> Output Class Initialized
INFO - 2025-09-18 04:35:52 --> Security Class Initialized
DEBUG - 2025-09-18 04:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:35:52 --> CSRF cookie sent
INFO - 2025-09-18 04:35:52 --> Input Class Initialized
INFO - 2025-09-18 04:35:52 --> Language Class Initialized
INFO - 2025-09-18 04:35:52 --> Loader Class Initialized
INFO - 2025-09-18 04:35:52 --> Helper loaded: url_helper
INFO - 2025-09-18 04:35:52 --> Helper loaded: text_helper
INFO - 2025-09-18 04:35:52 --> Helper loaded: string_helper
INFO - 2025-09-18 04:35:52 --> Helper loaded: form_helper
INFO - 2025-09-18 04:35:52 --> Helper loaded: download_helper
INFO - 2025-09-18 04:35:52 --> Helper loaded: security_helper
INFO - 2025-09-18 04:35:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:35:52 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:35:52 --> Form Validation Class Initialized
INFO - 2025-09-18 04:35:52 --> Model "User_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:35:52 --> Controller Class Initialized
INFO - 2025-09-18 09:35:52 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Video_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:35:52 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:35:52 --> Pagination Class Initialized
INFO - 2025-09-18 09:35:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:35:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:35:52 --> Model "Log_model" initialized
INFO - 2025-09-18 09:35:52 --> Final output sent to browser
DEBUG - 2025-09-18 09:35:52 --> Total execution time: 0.2789
INFO - 2025-09-18 04:36:00 --> Config Class Initialized
INFO - 2025-09-18 04:36:00 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:36:00 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:36:00 --> Utf8 Class Initialized
INFO - 2025-09-18 04:36:00 --> URI Class Initialized
DEBUG - 2025-09-18 04:36:00 --> No URI present. Default controller set.
INFO - 2025-09-18 04:36:00 --> Router Class Initialized
INFO - 2025-09-18 04:36:00 --> Output Class Initialized
INFO - 2025-09-18 04:36:00 --> Security Class Initialized
DEBUG - 2025-09-18 04:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:36:00 --> CSRF cookie sent
INFO - 2025-09-18 04:36:00 --> Input Class Initialized
INFO - 2025-09-18 04:36:00 --> Language Class Initialized
INFO - 2025-09-18 04:36:00 --> Loader Class Initialized
INFO - 2025-09-18 04:36:00 --> Helper loaded: url_helper
INFO - 2025-09-18 04:36:00 --> Helper loaded: text_helper
INFO - 2025-09-18 04:36:00 --> Helper loaded: string_helper
INFO - 2025-09-18 04:36:00 --> Helper loaded: form_helper
INFO - 2025-09-18 04:36:00 --> Helper loaded: download_helper
INFO - 2025-09-18 04:36:00 --> Helper loaded: security_helper
INFO - 2025-09-18 04:36:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:36:00 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:36:00 --> Form Validation Class Initialized
INFO - 2025-09-18 04:36:00 --> Model "User_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:36:00 --> Controller Class Initialized
INFO - 2025-09-18 09:36:00 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Video_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:36:00 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:36:00 --> Pagination Class Initialized
INFO - 2025-09-18 09:36:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:36:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:36:00 --> Model "Log_model" initialized
INFO - 2025-09-18 09:36:00 --> Final output sent to browser
DEBUG - 2025-09-18 09:36:00 --> Total execution time: 0.1220
INFO - 2025-09-18 04:36:14 --> Config Class Initialized
INFO - 2025-09-18 04:36:14 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:36:14 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:36:14 --> Utf8 Class Initialized
INFO - 2025-09-18 04:36:14 --> URI Class Initialized
DEBUG - 2025-09-18 04:36:14 --> No URI present. Default controller set.
INFO - 2025-09-18 04:36:14 --> Router Class Initialized
INFO - 2025-09-18 04:36:14 --> Output Class Initialized
INFO - 2025-09-18 04:36:14 --> Security Class Initialized
DEBUG - 2025-09-18 04:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:36:14 --> CSRF cookie sent
INFO - 2025-09-18 04:36:14 --> Input Class Initialized
INFO - 2025-09-18 04:36:14 --> Language Class Initialized
INFO - 2025-09-18 04:36:14 --> Loader Class Initialized
INFO - 2025-09-18 04:36:14 --> Helper loaded: url_helper
INFO - 2025-09-18 04:36:14 --> Helper loaded: text_helper
INFO - 2025-09-18 04:36:14 --> Helper loaded: string_helper
INFO - 2025-09-18 04:36:14 --> Helper loaded: form_helper
INFO - 2025-09-18 04:36:14 --> Helper loaded: download_helper
INFO - 2025-09-18 04:36:14 --> Helper loaded: security_helper
INFO - 2025-09-18 04:36:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:36:14 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:36:14 --> Form Validation Class Initialized
INFO - 2025-09-18 04:36:14 --> Model "User_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:36:14 --> Controller Class Initialized
INFO - 2025-09-18 09:36:14 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Video_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:36:14 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:36:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:36:14 --> Pagination Class Initialized
INFO - 2025-09-18 09:36:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:36:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:36:14 --> Model "Log_model" initialized
INFO - 2025-09-18 09:36:14 --> Final output sent to browser
DEBUG - 2025-09-18 09:36:14 --> Total execution time: 0.1124
INFO - 2025-09-18 04:36:16 --> Config Class Initialized
INFO - 2025-09-18 04:36:16 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:36:16 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:36:16 --> Utf8 Class Initialized
INFO - 2025-09-18 04:36:16 --> URI Class Initialized
DEBUG - 2025-09-18 04:36:16 --> No URI present. Default controller set.
INFO - 2025-09-18 04:36:16 --> Router Class Initialized
INFO - 2025-09-18 04:36:16 --> Output Class Initialized
INFO - 2025-09-18 04:36:16 --> Security Class Initialized
DEBUG - 2025-09-18 04:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:36:16 --> CSRF cookie sent
INFO - 2025-09-18 04:36:16 --> Input Class Initialized
INFO - 2025-09-18 04:36:16 --> Language Class Initialized
INFO - 2025-09-18 04:36:16 --> Loader Class Initialized
INFO - 2025-09-18 04:36:16 --> Helper loaded: url_helper
INFO - 2025-09-18 04:36:16 --> Helper loaded: text_helper
INFO - 2025-09-18 04:36:16 --> Helper loaded: string_helper
INFO - 2025-09-18 04:36:16 --> Helper loaded: form_helper
INFO - 2025-09-18 04:36:16 --> Helper loaded: download_helper
INFO - 2025-09-18 04:36:16 --> Helper loaded: security_helper
INFO - 2025-09-18 04:36:16 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:36:16 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:36:16 --> Form Validation Class Initialized
INFO - 2025-09-18 04:36:16 --> Model "User_model" initialized
INFO - 2025-09-18 09:36:16 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:36:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:36:16 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:36:16 --> Controller Class Initialized
INFO - 2025-09-18 09:36:16 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:36:16 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:36:16 --> Model "Video_model" initialized
INFO - 2025-09-18 09:36:16 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:36:16 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:36:16 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:36:16 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:36:16 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:36:17 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:36:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:36:17 --> Pagination Class Initialized
INFO - 2025-09-18 09:36:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:36:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:36:17 --> Model "Log_model" initialized
INFO - 2025-09-18 09:36:17 --> Final output sent to browser
DEBUG - 2025-09-18 09:36:17 --> Total execution time: 0.1584
INFO - 2025-09-18 04:37:48 --> Config Class Initialized
INFO - 2025-09-18 04:37:48 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:37:48 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:37:48 --> Utf8 Class Initialized
INFO - 2025-09-18 04:37:48 --> URI Class Initialized
DEBUG - 2025-09-18 04:37:48 --> No URI present. Default controller set.
INFO - 2025-09-18 04:37:48 --> Router Class Initialized
INFO - 2025-09-18 04:37:48 --> Output Class Initialized
INFO - 2025-09-18 04:37:48 --> Security Class Initialized
DEBUG - 2025-09-18 04:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:37:48 --> CSRF cookie sent
INFO - 2025-09-18 04:37:48 --> Input Class Initialized
INFO - 2025-09-18 04:37:48 --> Language Class Initialized
INFO - 2025-09-18 04:37:48 --> Loader Class Initialized
INFO - 2025-09-18 04:37:48 --> Helper loaded: url_helper
INFO - 2025-09-18 04:37:48 --> Helper loaded: text_helper
INFO - 2025-09-18 04:37:48 --> Helper loaded: string_helper
INFO - 2025-09-18 04:37:48 --> Helper loaded: form_helper
INFO - 2025-09-18 04:37:48 --> Helper loaded: download_helper
INFO - 2025-09-18 04:37:48 --> Helper loaded: security_helper
INFO - 2025-09-18 04:37:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:37:48 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:37:48 --> Form Validation Class Initialized
INFO - 2025-09-18 04:37:48 --> Model "User_model" initialized
INFO - 2025-09-18 09:37:48 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:37:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:37:49 --> Controller Class Initialized
INFO - 2025-09-18 09:37:49 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Video_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:37:49 --> Pagination Class Initialized
INFO - 2025-09-18 09:37:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:37:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:37:49 --> Model "Log_model" initialized
INFO - 2025-09-18 09:37:49 --> Final output sent to browser
DEBUG - 2025-09-18 09:37:49 --> Total execution time: 0.1071
INFO - 2025-09-18 04:37:49 --> Config Class Initialized
INFO - 2025-09-18 04:37:49 --> Hooks Class Initialized
INFO - 2025-09-18 04:37:49 --> Config Class Initialized
INFO - 2025-09-18 04:37:49 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:37:49 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:37:49 --> Utf8 Class Initialized
INFO - 2025-09-18 04:37:49 --> URI Class Initialized
DEBUG - 2025-09-18 04:37:49 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:37:49 --> Utf8 Class Initialized
INFO - 2025-09-18 04:37:49 --> Router Class Initialized
INFO - 2025-09-18 04:37:49 --> URI Class Initialized
INFO - 2025-09-18 04:37:49 --> Output Class Initialized
INFO - 2025-09-18 04:37:49 --> Router Class Initialized
INFO - 2025-09-18 04:37:49 --> Security Class Initialized
INFO - 2025-09-18 04:37:49 --> Output Class Initialized
DEBUG - 2025-09-18 04:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:37:49 --> CSRF cookie sent
INFO - 2025-09-18 04:37:49 --> Input Class Initialized
INFO - 2025-09-18 04:37:49 --> Language Class Initialized
INFO - 2025-09-18 04:37:49 --> Security Class Initialized
DEBUG - 2025-09-18 04:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:37:49 --> CSRF cookie sent
INFO - 2025-09-18 04:37:49 --> Input Class Initialized
INFO - 2025-09-18 04:37:49 --> Language Class Initialized
INFO - 2025-09-18 04:37:49 --> Loader Class Initialized
INFO - 2025-09-18 04:37:49 --> Helper loaded: url_helper
INFO - 2025-09-18 04:37:49 --> Loader Class Initialized
INFO - 2025-09-18 04:37:49 --> Helper loaded: text_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: url_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: string_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: text_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: string_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: form_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: download_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: form_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: security_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: download_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: security_helper
INFO - 2025-09-18 04:37:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:37:49 --> Database Driver Class Initialized
INFO - 2025-09-18 04:37:49 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:37:49 --> Form Validation Class Initialized
INFO - 2025-09-18 04:37:49 --> Model "User_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:37:49 --> Controller Class Initialized
INFO - 2025-09-18 09:37:49 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Video_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Testimoni_model" initialized
DEBUG - 2025-09-18 04:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:37:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:37:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:37:49 --> Model "Log_model" initialized
INFO - 2025-09-18 09:37:49 --> Final output sent to browser
DEBUG - 2025-09-18 09:37:49 --> Total execution time: 0.0680
INFO - 2025-09-18 04:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:37:49 --> Form Validation Class Initialized
INFO - 2025-09-18 04:37:49 --> Model "User_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:37:49 --> Controller Class Initialized
INFO - 2025-09-18 09:37:49 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Video_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:37:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:37:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:37:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:37:49 --> Model "Log_model" initialized
INFO - 2025-09-18 09:37:49 --> Final output sent to browser
DEBUG - 2025-09-18 09:37:49 --> Total execution time: 0.1073
INFO - 2025-09-18 04:38:02 --> Config Class Initialized
INFO - 2025-09-18 04:38:02 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:38:02 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:38:02 --> Utf8 Class Initialized
INFO - 2025-09-18 04:38:02 --> URI Class Initialized
DEBUG - 2025-09-18 04:38:02 --> No URI present. Default controller set.
INFO - 2025-09-18 04:38:02 --> Router Class Initialized
INFO - 2025-09-18 04:38:02 --> Output Class Initialized
INFO - 2025-09-18 04:38:02 --> Security Class Initialized
DEBUG - 2025-09-18 04:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:38:02 --> CSRF cookie sent
INFO - 2025-09-18 04:38:02 --> Input Class Initialized
INFO - 2025-09-18 04:38:02 --> Language Class Initialized
INFO - 2025-09-18 04:38:02 --> Loader Class Initialized
INFO - 2025-09-18 04:38:02 --> Helper loaded: url_helper
INFO - 2025-09-18 04:38:02 --> Helper loaded: text_helper
INFO - 2025-09-18 04:38:02 --> Helper loaded: string_helper
INFO - 2025-09-18 04:38:02 --> Helper loaded: form_helper
INFO - 2025-09-18 04:38:02 --> Helper loaded: download_helper
INFO - 2025-09-18 04:38:02 --> Helper loaded: security_helper
INFO - 2025-09-18 04:38:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:38:02 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:38:02 --> Form Validation Class Initialized
INFO - 2025-09-18 04:38:02 --> Model "User_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:38:02 --> Controller Class Initialized
INFO - 2025-09-18 09:38:02 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Video_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:38:02 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:38:02 --> Pagination Class Initialized
INFO - 2025-09-18 09:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:38:03 --> Model "Log_model" initialized
INFO - 2025-09-18 09:38:03 --> Final output sent to browser
DEBUG - 2025-09-18 09:38:03 --> Total execution time: 0.0938
INFO - 2025-09-18 04:38:03 --> Config Class Initialized
INFO - 2025-09-18 04:38:03 --> Hooks Class Initialized
INFO - 2025-09-18 04:38:03 --> Config Class Initialized
DEBUG - 2025-09-18 04:38:03 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:38:03 --> Hooks Class Initialized
INFO - 2025-09-18 04:38:03 --> Utf8 Class Initialized
INFO - 2025-09-18 04:38:03 --> URI Class Initialized
DEBUG - 2025-09-18 04:38:03 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:38:03 --> Utf8 Class Initialized
INFO - 2025-09-18 04:38:03 --> Router Class Initialized
INFO - 2025-09-18 04:38:03 --> URI Class Initialized
INFO - 2025-09-18 04:38:03 --> Output Class Initialized
INFO - 2025-09-18 04:38:03 --> Router Class Initialized
INFO - 2025-09-18 04:38:03 --> Security Class Initialized
INFO - 2025-09-18 04:38:03 --> Output Class Initialized
DEBUG - 2025-09-18 04:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:38:03 --> CSRF cookie sent
INFO - 2025-09-18 04:38:03 --> Input Class Initialized
INFO - 2025-09-18 04:38:03 --> Security Class Initialized
INFO - 2025-09-18 04:38:03 --> Language Class Initialized
DEBUG - 2025-09-18 04:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:38:03 --> CSRF cookie sent
INFO - 2025-09-18 04:38:03 --> Input Class Initialized
INFO - 2025-09-18 04:38:03 --> Loader Class Initialized
INFO - 2025-09-18 04:38:03 --> Language Class Initialized
INFO - 2025-09-18 04:38:03 --> Helper loaded: url_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: text_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: string_helper
INFO - 2025-09-18 04:38:03 --> Loader Class Initialized
INFO - 2025-09-18 04:38:03 --> Helper loaded: form_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: url_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: download_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: security_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: text_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: string_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: form_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: download_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: security_helper
INFO - 2025-09-18 04:38:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:38:03 --> Database Driver Class Initialized
INFO - 2025-09-18 04:38:03 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:38:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-09-18 04:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:38:03 --> Form Validation Class Initialized
INFO - 2025-09-18 04:38:03 --> Model "User_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:38:03 --> Controller Class Initialized
INFO - 2025-09-18 09:38:03 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Video_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:38:03 --> Model "Log_model" initialized
INFO - 2025-09-18 09:38:03 --> Final output sent to browser
DEBUG - 2025-09-18 09:38:03 --> Total execution time: 0.0950
INFO - 2025-09-18 04:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:38:03 --> Form Validation Class Initialized
INFO - 2025-09-18 04:38:03 --> Model "User_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:38:03 --> Controller Class Initialized
INFO - 2025-09-18 09:38:03 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Video_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:38:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:38:03 --> Model "Log_model" initialized
INFO - 2025-09-18 09:38:03 --> Final output sent to browser
DEBUG - 2025-09-18 09:38:03 --> Total execution time: 0.1366
INFO - 2025-09-18 04:38:05 --> Config Class Initialized
INFO - 2025-09-18 04:38:05 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:38:05 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:38:05 --> Utf8 Class Initialized
INFO - 2025-09-18 04:38:05 --> URI Class Initialized
DEBUG - 2025-09-18 04:38:05 --> No URI present. Default controller set.
INFO - 2025-09-18 04:38:05 --> Router Class Initialized
INFO - 2025-09-18 04:38:05 --> Output Class Initialized
INFO - 2025-09-18 04:38:05 --> Security Class Initialized
DEBUG - 2025-09-18 04:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:38:05 --> CSRF cookie sent
INFO - 2025-09-18 04:38:05 --> Input Class Initialized
INFO - 2025-09-18 04:38:05 --> Language Class Initialized
INFO - 2025-09-18 04:38:05 --> Loader Class Initialized
INFO - 2025-09-18 04:38:05 --> Helper loaded: url_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: text_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: string_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: form_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: download_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: security_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:38:05 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:38:05 --> Form Validation Class Initialized
INFO - 2025-09-18 04:38:05 --> Model "User_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:38:05 --> Controller Class Initialized
INFO - 2025-09-18 09:38:05 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Video_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:38:05 --> Pagination Class Initialized
INFO - 2025-09-18 09:38:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:38:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:38:05 --> Model "Log_model" initialized
INFO - 2025-09-18 09:38:05 --> Final output sent to browser
DEBUG - 2025-09-18 09:38:05 --> Total execution time: 0.1321
INFO - 2025-09-18 04:38:05 --> Config Class Initialized
INFO - 2025-09-18 04:38:05 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:38:05 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:38:05 --> Utf8 Class Initialized
INFO - 2025-09-18 04:38:05 --> Config Class Initialized
INFO - 2025-09-18 04:38:05 --> Hooks Class Initialized
INFO - 2025-09-18 04:38:05 --> URI Class Initialized
INFO - 2025-09-18 04:38:05 --> Router Class Initialized
DEBUG - 2025-09-18 04:38:05 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:38:05 --> Utf8 Class Initialized
INFO - 2025-09-18 04:38:05 --> Output Class Initialized
INFO - 2025-09-18 04:38:05 --> URI Class Initialized
INFO - 2025-09-18 04:38:05 --> Security Class Initialized
INFO - 2025-09-18 04:38:05 --> Router Class Initialized
DEBUG - 2025-09-18 04:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:38:05 --> CSRF cookie sent
INFO - 2025-09-18 04:38:05 --> Input Class Initialized
INFO - 2025-09-18 04:38:05 --> Output Class Initialized
INFO - 2025-09-18 04:38:05 --> Language Class Initialized
INFO - 2025-09-18 04:38:05 --> Security Class Initialized
INFO - 2025-09-18 04:38:05 --> Loader Class Initialized
DEBUG - 2025-09-18 04:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:38:05 --> CSRF cookie sent
INFO - 2025-09-18 04:38:05 --> Input Class Initialized
INFO - 2025-09-18 04:38:05 --> Helper loaded: url_helper
INFO - 2025-09-18 04:38:05 --> Language Class Initialized
INFO - 2025-09-18 04:38:05 --> Helper loaded: text_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: string_helper
INFO - 2025-09-18 04:38:05 --> Loader Class Initialized
INFO - 2025-09-18 04:38:05 --> Helper loaded: form_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: url_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: download_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: text_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: security_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: string_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: form_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: download_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: security_helper
INFO - 2025-09-18 04:38:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:38:05 --> Database Driver Class Initialized
INFO - 2025-09-18 04:38:05 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-18 04:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:38:05 --> Form Validation Class Initialized
INFO - 2025-09-18 04:38:05 --> Model "User_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:38:05 --> Controller Class Initialized
INFO - 2025-09-18 09:38:05 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Video_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:38:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:38:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:38:05 --> Model "Log_model" initialized
INFO - 2025-09-18 09:38:05 --> Final output sent to browser
DEBUG - 2025-09-18 09:38:05 --> Total execution time: 0.1001
INFO - 2025-09-18 04:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:38:05 --> Form Validation Class Initialized
INFO - 2025-09-18 04:38:05 --> Model "User_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:38:05 --> Controller Class Initialized
INFO - 2025-09-18 09:38:05 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Video_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:38:05 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:38:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:38:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:38:05 --> Model "Log_model" initialized
INFO - 2025-09-18 09:38:05 --> Final output sent to browser
DEBUG - 2025-09-18 09:38:05 --> Total execution time: 0.1375
INFO - 2025-09-18 04:39:35 --> Config Class Initialized
INFO - 2025-09-18 04:39:35 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:39:35 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:39:35 --> Utf8 Class Initialized
INFO - 2025-09-18 04:39:35 --> URI Class Initialized
DEBUG - 2025-09-18 04:39:35 --> No URI present. Default controller set.
INFO - 2025-09-18 04:39:35 --> Router Class Initialized
INFO - 2025-09-18 04:39:35 --> Output Class Initialized
INFO - 2025-09-18 04:39:35 --> Security Class Initialized
DEBUG - 2025-09-18 04:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:39:35 --> CSRF cookie sent
INFO - 2025-09-18 04:39:35 --> Input Class Initialized
INFO - 2025-09-18 04:39:35 --> Language Class Initialized
INFO - 2025-09-18 04:39:35 --> Loader Class Initialized
INFO - 2025-09-18 04:39:35 --> Helper loaded: url_helper
INFO - 2025-09-18 04:39:35 --> Helper loaded: text_helper
INFO - 2025-09-18 04:39:35 --> Helper loaded: string_helper
INFO - 2025-09-18 04:39:35 --> Helper loaded: form_helper
INFO - 2025-09-18 04:39:35 --> Helper loaded: download_helper
INFO - 2025-09-18 04:39:35 --> Helper loaded: security_helper
INFO - 2025-09-18 04:39:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:39:35 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:39:36 --> Form Validation Class Initialized
INFO - 2025-09-18 04:39:36 --> Model "User_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:39:36 --> Controller Class Initialized
INFO - 2025-09-18 09:39:36 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Video_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:39:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:39:36 --> Pagination Class Initialized
INFO - 2025-09-18 09:39:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:39:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:39:36 --> Model "Log_model" initialized
INFO - 2025-09-18 09:39:36 --> Final output sent to browser
DEBUG - 2025-09-18 09:39:36 --> Total execution time: 0.1326
INFO - 2025-09-18 04:39:36 --> Config Class Initialized
INFO - 2025-09-18 04:39:36 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:39:36 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:39:36 --> Utf8 Class Initialized
INFO - 2025-09-18 04:39:36 --> URI Class Initialized
INFO - 2025-09-18 04:39:36 --> Router Class Initialized
INFO - 2025-09-18 04:39:36 --> Output Class Initialized
INFO - 2025-09-18 04:39:36 --> Security Class Initialized
DEBUG - 2025-09-18 04:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:39:36 --> Config Class Initialized
INFO - 2025-09-18 04:39:36 --> CSRF cookie sent
INFO - 2025-09-18 04:39:36 --> Hooks Class Initialized
INFO - 2025-09-18 04:39:36 --> Input Class Initialized
INFO - 2025-09-18 04:39:36 --> Language Class Initialized
DEBUG - 2025-09-18 04:39:36 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:39:36 --> Utf8 Class Initialized
INFO - 2025-09-18 04:39:36 --> URI Class Initialized
INFO - 2025-09-18 04:39:36 --> Router Class Initialized
INFO - 2025-09-18 04:39:36 --> Loader Class Initialized
INFO - 2025-09-18 04:39:36 --> Output Class Initialized
INFO - 2025-09-18 04:39:36 --> Helper loaded: url_helper
INFO - 2025-09-18 04:39:36 --> Security Class Initialized
INFO - 2025-09-18 04:39:36 --> Helper loaded: text_helper
INFO - 2025-09-18 04:39:36 --> Helper loaded: string_helper
DEBUG - 2025-09-18 04:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:39:36 --> CSRF cookie sent
INFO - 2025-09-18 04:39:36 --> Input Class Initialized
INFO - 2025-09-18 04:39:36 --> Helper loaded: form_helper
INFO - 2025-09-18 04:39:36 --> Language Class Initialized
INFO - 2025-09-18 04:39:36 --> Helper loaded: download_helper
INFO - 2025-09-18 04:39:36 --> Helper loaded: security_helper
INFO - 2025-09-18 04:39:36 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:39:36 --> Loader Class Initialized
INFO - 2025-09-18 04:39:36 --> Helper loaded: url_helper
INFO - 2025-09-18 04:39:36 --> Helper loaded: text_helper
INFO - 2025-09-18 04:39:36 --> Helper loaded: string_helper
INFO - 2025-09-18 04:39:36 --> Helper loaded: form_helper
INFO - 2025-09-18 04:39:36 --> Helper loaded: download_helper
INFO - 2025-09-18 04:39:36 --> Helper loaded: security_helper
INFO - 2025-09-18 04:39:36 --> Database Driver Class Initialized
INFO - 2025-09-18 04:39:36 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:39:36 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-18 04:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:39:36 --> Form Validation Class Initialized
INFO - 2025-09-18 04:39:36 --> Model "User_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:39:36 --> Controller Class Initialized
INFO - 2025-09-18 09:39:36 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Video_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:39:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:39:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:39:36 --> Model "Log_model" initialized
INFO - 2025-09-18 09:39:36 --> Final output sent to browser
DEBUG - 2025-09-18 09:39:36 --> Total execution time: 0.0841
INFO - 2025-09-18 04:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:39:36 --> Form Validation Class Initialized
INFO - 2025-09-18 04:39:36 --> Model "User_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:39:36 --> Controller Class Initialized
INFO - 2025-09-18 09:39:36 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Video_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:39:36 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:39:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:39:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:39:36 --> Model "Log_model" initialized
INFO - 2025-09-18 09:39:36 --> Final output sent to browser
DEBUG - 2025-09-18 09:39:36 --> Total execution time: 0.1382
INFO - 2025-09-18 04:39:49 --> Config Class Initialized
INFO - 2025-09-18 04:39:49 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:39:49 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:39:49 --> Utf8 Class Initialized
INFO - 2025-09-18 04:39:49 --> URI Class Initialized
DEBUG - 2025-09-18 04:39:49 --> No URI present. Default controller set.
INFO - 2025-09-18 04:39:49 --> Router Class Initialized
INFO - 2025-09-18 04:39:49 --> Output Class Initialized
INFO - 2025-09-18 04:39:49 --> Security Class Initialized
DEBUG - 2025-09-18 04:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:39:49 --> CSRF cookie sent
INFO - 2025-09-18 04:39:49 --> Input Class Initialized
INFO - 2025-09-18 04:39:49 --> Language Class Initialized
INFO - 2025-09-18 04:39:49 --> Loader Class Initialized
INFO - 2025-09-18 04:39:49 --> Helper loaded: url_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: text_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: string_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: form_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: download_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: security_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:39:49 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:39:49 --> Form Validation Class Initialized
INFO - 2025-09-18 04:39:49 --> Model "User_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:39:49 --> Controller Class Initialized
INFO - 2025-09-18 09:39:49 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Video_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:39:49 --> Pagination Class Initialized
INFO - 2025-09-18 09:39:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:39:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:39:49 --> Model "Log_model" initialized
INFO - 2025-09-18 09:39:49 --> Final output sent to browser
DEBUG - 2025-09-18 09:39:49 --> Total execution time: 0.1448
INFO - 2025-09-18 04:39:49 --> Config Class Initialized
INFO - 2025-09-18 04:39:49 --> Config Class Initialized
INFO - 2025-09-18 04:39:49 --> Hooks Class Initialized
INFO - 2025-09-18 04:39:49 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:39:49 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:39:49 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:39:49 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:39:49 --> Utf8 Class Initialized
INFO - 2025-09-18 04:39:49 --> URI Class Initialized
INFO - 2025-09-18 04:39:49 --> URI Class Initialized
INFO - 2025-09-18 04:39:49 --> Router Class Initialized
INFO - 2025-09-18 04:39:49 --> Router Class Initialized
INFO - 2025-09-18 04:39:49 --> Output Class Initialized
INFO - 2025-09-18 04:39:49 --> Output Class Initialized
INFO - 2025-09-18 04:39:49 --> Security Class Initialized
INFO - 2025-09-18 04:39:49 --> Security Class Initialized
DEBUG - 2025-09-18 04:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:39:49 --> CSRF cookie sent
INFO - 2025-09-18 04:39:49 --> Input Class Initialized
INFO - 2025-09-18 04:39:49 --> Language Class Initialized
DEBUG - 2025-09-18 04:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:39:49 --> CSRF cookie sent
INFO - 2025-09-18 04:39:49 --> Input Class Initialized
INFO - 2025-09-18 04:39:49 --> Language Class Initialized
INFO - 2025-09-18 04:39:49 --> Loader Class Initialized
INFO - 2025-09-18 04:39:49 --> Helper loaded: url_helper
INFO - 2025-09-18 04:39:49 --> Loader Class Initialized
INFO - 2025-09-18 04:39:49 --> Helper loaded: text_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: url_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: string_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: text_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: string_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: form_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: download_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: form_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: security_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: download_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: security_helper
INFO - 2025-09-18 04:39:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:39:49 --> Database Driver Class Initialized
INFO - 2025-09-18 04:39:49 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:39:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-09-18 04:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:39:49 --> Form Validation Class Initialized
INFO - 2025-09-18 04:39:49 --> Model "User_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:39:49 --> Controller Class Initialized
INFO - 2025-09-18 09:39:49 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Video_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:39:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:39:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:39:49 --> Model "Log_model" initialized
INFO - 2025-09-18 09:39:49 --> Final output sent to browser
DEBUG - 2025-09-18 09:39:49 --> Total execution time: 0.0656
INFO - 2025-09-18 04:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:39:49 --> Form Validation Class Initialized
INFO - 2025-09-18 04:39:49 --> Model "User_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:39:49 --> Controller Class Initialized
INFO - 2025-09-18 09:39:49 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Video_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:39:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:39:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:39:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:39:49 --> Model "Log_model" initialized
INFO - 2025-09-18 09:39:49 --> Final output sent to browser
DEBUG - 2025-09-18 09:39:49 --> Total execution time: 0.1030
INFO - 2025-09-18 04:39:51 --> Config Class Initialized
INFO - 2025-09-18 04:39:51 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:39:51 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:39:51 --> Utf8 Class Initialized
INFO - 2025-09-18 04:39:51 --> URI Class Initialized
DEBUG - 2025-09-18 04:39:51 --> No URI present. Default controller set.
INFO - 2025-09-18 04:39:51 --> Router Class Initialized
INFO - 2025-09-18 04:39:51 --> Output Class Initialized
INFO - 2025-09-18 04:39:51 --> Security Class Initialized
DEBUG - 2025-09-18 04:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:39:51 --> CSRF cookie sent
INFO - 2025-09-18 04:39:51 --> Input Class Initialized
INFO - 2025-09-18 04:39:51 --> Language Class Initialized
INFO - 2025-09-18 04:39:51 --> Loader Class Initialized
INFO - 2025-09-18 04:39:51 --> Helper loaded: url_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: text_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: string_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: form_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: download_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: security_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:39:51 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:39:51 --> Form Validation Class Initialized
INFO - 2025-09-18 04:39:51 --> Model "User_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:39:51 --> Controller Class Initialized
INFO - 2025-09-18 09:39:51 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Video_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:39:51 --> Pagination Class Initialized
INFO - 2025-09-18 09:39:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:39:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:39:51 --> Model "Log_model" initialized
INFO - 2025-09-18 09:39:51 --> Final output sent to browser
DEBUG - 2025-09-18 09:39:51 --> Total execution time: 0.1159
INFO - 2025-09-18 04:39:51 --> Config Class Initialized
INFO - 2025-09-18 04:39:51 --> Hooks Class Initialized
INFO - 2025-09-18 04:39:51 --> Config Class Initialized
INFO - 2025-09-18 04:39:51 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:39:51 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:39:51 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:39:51 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:39:51 --> URI Class Initialized
INFO - 2025-09-18 04:39:51 --> Utf8 Class Initialized
INFO - 2025-09-18 04:39:51 --> Router Class Initialized
INFO - 2025-09-18 04:39:51 --> URI Class Initialized
INFO - 2025-09-18 04:39:51 --> Output Class Initialized
INFO - 2025-09-18 04:39:51 --> Router Class Initialized
INFO - 2025-09-18 04:39:51 --> Security Class Initialized
DEBUG - 2025-09-18 04:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:39:51 --> Output Class Initialized
INFO - 2025-09-18 04:39:51 --> CSRF cookie sent
INFO - 2025-09-18 04:39:51 --> Input Class Initialized
INFO - 2025-09-18 04:39:51 --> Security Class Initialized
INFO - 2025-09-18 04:39:51 --> Language Class Initialized
DEBUG - 2025-09-18 04:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:39:51 --> CSRF cookie sent
INFO - 2025-09-18 04:39:51 --> Input Class Initialized
INFO - 2025-09-18 04:39:51 --> Language Class Initialized
INFO - 2025-09-18 04:39:51 --> Loader Class Initialized
INFO - 2025-09-18 04:39:51 --> Loader Class Initialized
INFO - 2025-09-18 04:39:51 --> Helper loaded: url_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: url_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: text_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: string_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: text_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: form_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: string_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: download_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: security_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: form_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: download_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: security_helper
INFO - 2025-09-18 04:39:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:39:51 --> Database Driver Class Initialized
INFO - 2025-09-18 04:39:51 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:39:51 --> Form Validation Class Initialized
INFO - 2025-09-18 04:39:51 --> Model "User_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:39:51 --> Controller Class Initialized
DEBUG - 2025-09-18 04:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:39:51 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Video_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:39:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:39:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:39:51 --> Model "Log_model" initialized
INFO - 2025-09-18 09:39:51 --> Final output sent to browser
DEBUG - 2025-09-18 09:39:51 --> Total execution time: 0.0914
INFO - 2025-09-18 04:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:39:51 --> Form Validation Class Initialized
INFO - 2025-09-18 04:39:51 --> Model "User_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:39:51 --> Controller Class Initialized
INFO - 2025-09-18 09:39:51 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Video_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:39:51 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:39:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:39:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:39:51 --> Model "Log_model" initialized
INFO - 2025-09-18 09:39:51 --> Final output sent to browser
DEBUG - 2025-09-18 09:39:51 --> Total execution time: 0.1285
INFO - 2025-09-18 04:40:28 --> Config Class Initialized
INFO - 2025-09-18 04:40:28 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:40:28 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:40:28 --> Utf8 Class Initialized
INFO - 2025-09-18 04:40:28 --> URI Class Initialized
INFO - 2025-09-18 04:40:28 --> Router Class Initialized
INFO - 2025-09-18 04:40:28 --> Output Class Initialized
INFO - 2025-09-18 04:40:28 --> Security Class Initialized
DEBUG - 2025-09-18 04:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:40:28 --> CSRF cookie sent
INFO - 2025-09-18 04:40:28 --> Input Class Initialized
INFO - 2025-09-18 04:40:28 --> Language Class Initialized
INFO - 2025-09-18 04:40:28 --> Loader Class Initialized
INFO - 2025-09-18 04:40:28 --> Helper loaded: url_helper
INFO - 2025-09-18 04:40:28 --> Helper loaded: text_helper
INFO - 2025-09-18 04:40:28 --> Helper loaded: string_helper
INFO - 2025-09-18 04:40:28 --> Helper loaded: form_helper
INFO - 2025-09-18 04:40:28 --> Helper loaded: download_helper
INFO - 2025-09-18 04:40:28 --> Helper loaded: security_helper
INFO - 2025-09-18 04:40:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:40:28 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:40:28 --> Form Validation Class Initialized
INFO - 2025-09-18 04:40:28 --> Model "User_model" initialized
INFO - 2025-09-18 09:40:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:40:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:40:28 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:40:28 --> Controller Class Initialized
INFO - 2025-09-18 09:40:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/konfigurasi/logo.php
INFO - 2025-09-18 09:40:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 09:40:29 --> Model "Log_model" initialized
INFO - 2025-09-18 09:40:29 --> Final output sent to browser
DEBUG - 2025-09-18 09:40:29 --> Total execution time: 1.1876
INFO - 2025-09-18 04:40:59 --> Config Class Initialized
INFO - 2025-09-18 04:40:59 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:40:59 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:40:59 --> Utf8 Class Initialized
INFO - 2025-09-18 04:40:59 --> URI Class Initialized
INFO - 2025-09-18 04:40:59 --> Router Class Initialized
INFO - 2025-09-18 04:40:59 --> Output Class Initialized
INFO - 2025-09-18 04:40:59 --> Security Class Initialized
DEBUG - 2025-09-18 04:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:40:59 --> CSRF cookie sent
INFO - 2025-09-18 04:40:59 --> CSRF token verified
INFO - 2025-09-18 04:40:59 --> Input Class Initialized
INFO - 2025-09-18 04:40:59 --> Language Class Initialized
INFO - 2025-09-18 04:40:59 --> Loader Class Initialized
INFO - 2025-09-18 04:40:59 --> Helper loaded: url_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: text_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: string_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: form_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: download_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: security_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:40:59 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:40:59 --> Form Validation Class Initialized
INFO - 2025-09-18 04:40:59 --> Model "User_model" initialized
INFO - 2025-09-18 09:40:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:40:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:40:59 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:40:59 --> Controller Class Initialized
INFO - 2025-09-18 09:40:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 09:40:59 --> Upload Class Initialized
INFO - 2025-09-18 09:40:59 --> Image Lib Class Initialized
INFO - 2025-09-18 09:40:59 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2025-09-18 09:40:59 --> Your server does not support the GD function required to process this type of image.
INFO - 2025-09-18 04:40:59 --> Config Class Initialized
INFO - 2025-09-18 04:40:59 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:40:59 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:40:59 --> Utf8 Class Initialized
INFO - 2025-09-18 04:40:59 --> URI Class Initialized
INFO - 2025-09-18 04:40:59 --> Router Class Initialized
INFO - 2025-09-18 04:40:59 --> Output Class Initialized
INFO - 2025-09-18 04:40:59 --> Security Class Initialized
DEBUG - 2025-09-18 04:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:40:59 --> CSRF cookie sent
INFO - 2025-09-18 04:40:59 --> Input Class Initialized
INFO - 2025-09-18 04:40:59 --> Language Class Initialized
INFO - 2025-09-18 04:40:59 --> Loader Class Initialized
INFO - 2025-09-18 04:40:59 --> Helper loaded: url_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: text_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: string_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: form_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: download_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: security_helper
INFO - 2025-09-18 04:40:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:40:59 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:40:59 --> Form Validation Class Initialized
INFO - 2025-09-18 04:40:59 --> Model "User_model" initialized
INFO - 2025-09-18 09:40:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:40:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:40:59 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:40:59 --> Controller Class Initialized
INFO - 2025-09-18 09:40:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/konfigurasi/logo.php
INFO - 2025-09-18 09:40:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 09:40:59 --> Model "Log_model" initialized
INFO - 2025-09-18 09:40:59 --> Final output sent to browser
DEBUG - 2025-09-18 09:40:59 --> Total execution time: 0.0407
INFO - 2025-09-18 04:41:06 --> Config Class Initialized
INFO - 2025-09-18 04:41:06 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:41:06 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:41:06 --> Utf8 Class Initialized
INFO - 2025-09-18 04:41:06 --> URI Class Initialized
DEBUG - 2025-09-18 04:41:06 --> No URI present. Default controller set.
INFO - 2025-09-18 04:41:06 --> Router Class Initialized
INFO - 2025-09-18 04:41:06 --> Output Class Initialized
INFO - 2025-09-18 04:41:06 --> Security Class Initialized
DEBUG - 2025-09-18 04:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:41:06 --> CSRF cookie sent
INFO - 2025-09-18 04:41:06 --> Input Class Initialized
INFO - 2025-09-18 04:41:06 --> Language Class Initialized
INFO - 2025-09-18 04:41:06 --> Loader Class Initialized
INFO - 2025-09-18 04:41:06 --> Helper loaded: url_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: text_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: string_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: form_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: download_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: security_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:41:06 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:41:06 --> Form Validation Class Initialized
INFO - 2025-09-18 04:41:06 --> Model "User_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:41:06 --> Controller Class Initialized
INFO - 2025-09-18 09:41:06 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Video_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:41:06 --> Pagination Class Initialized
INFO - 2025-09-18 09:41:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:41:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:41:06 --> Model "Log_model" initialized
INFO - 2025-09-18 09:41:06 --> Final output sent to browser
DEBUG - 2025-09-18 09:41:06 --> Total execution time: 0.1235
INFO - 2025-09-18 04:41:06 --> Config Class Initialized
INFO - 2025-09-18 04:41:06 --> Hooks Class Initialized
INFO - 2025-09-18 04:41:06 --> Config Class Initialized
INFO - 2025-09-18 04:41:06 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:41:06 --> UTF-8 Support Enabled
DEBUG - 2025-09-18 04:41:06 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:41:06 --> Utf8 Class Initialized
INFO - 2025-09-18 04:41:06 --> Utf8 Class Initialized
INFO - 2025-09-18 04:41:06 --> URI Class Initialized
INFO - 2025-09-18 04:41:06 --> URI Class Initialized
INFO - 2025-09-18 04:41:06 --> Router Class Initialized
INFO - 2025-09-18 04:41:06 --> Router Class Initialized
INFO - 2025-09-18 04:41:06 --> Output Class Initialized
INFO - 2025-09-18 04:41:06 --> Output Class Initialized
INFO - 2025-09-18 04:41:06 --> Security Class Initialized
INFO - 2025-09-18 04:41:06 --> Security Class Initialized
DEBUG - 2025-09-18 04:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:41:06 --> CSRF cookie sent
INFO - 2025-09-18 04:41:06 --> Input Class Initialized
DEBUG - 2025-09-18 04:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:41:06 --> CSRF cookie sent
INFO - 2025-09-18 04:41:06 --> Language Class Initialized
INFO - 2025-09-18 04:41:06 --> Input Class Initialized
INFO - 2025-09-18 04:41:06 --> Language Class Initialized
INFO - 2025-09-18 04:41:06 --> Loader Class Initialized
INFO - 2025-09-18 04:41:06 --> Helper loaded: url_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: text_helper
INFO - 2025-09-18 04:41:06 --> Loader Class Initialized
INFO - 2025-09-18 04:41:06 --> Helper loaded: string_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: url_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: form_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: text_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: download_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: string_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: security_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: form_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: download_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: security_helper
INFO - 2025-09-18 04:41:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:41:06 --> Database Driver Class Initialized
INFO - 2025-09-18 04:41:06 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-18 04:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:41:06 --> Form Validation Class Initialized
INFO - 2025-09-18 04:41:06 --> Model "User_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:41:06 --> Controller Class Initialized
INFO - 2025-09-18 09:41:06 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Video_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:41:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:41:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:41:06 --> Model "Log_model" initialized
INFO - 2025-09-18 09:41:06 --> Final output sent to browser
DEBUG - 2025-09-18 09:41:06 --> Total execution time: 0.0856
INFO - 2025-09-18 04:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:41:06 --> Form Validation Class Initialized
INFO - 2025-09-18 04:41:06 --> Model "User_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:41:06 --> Controller Class Initialized
INFO - 2025-09-18 09:41:06 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Video_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:41:06 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:41:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:41:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:41:06 --> Model "Log_model" initialized
INFO - 2025-09-18 09:41:06 --> Final output sent to browser
DEBUG - 2025-09-18 09:41:06 --> Total execution time: 0.1247
INFO - 2025-09-18 04:41:19 --> Config Class Initialized
INFO - 2025-09-18 04:41:19 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:41:19 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:41:19 --> Utf8 Class Initialized
INFO - 2025-09-18 04:41:19 --> URI Class Initialized
DEBUG - 2025-09-18 04:41:19 --> No URI present. Default controller set.
INFO - 2025-09-18 04:41:19 --> Router Class Initialized
INFO - 2025-09-18 04:41:19 --> Output Class Initialized
INFO - 2025-09-18 04:41:19 --> Security Class Initialized
DEBUG - 2025-09-18 04:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:41:19 --> CSRF cookie sent
INFO - 2025-09-18 04:41:19 --> Input Class Initialized
INFO - 2025-09-18 04:41:19 --> Language Class Initialized
INFO - 2025-09-18 04:41:19 --> Loader Class Initialized
INFO - 2025-09-18 04:41:19 --> Helper loaded: url_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: text_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: string_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: form_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: download_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: security_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:41:19 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:41:19 --> Form Validation Class Initialized
INFO - 2025-09-18 04:41:19 --> Model "User_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:41:19 --> Controller Class Initialized
INFO - 2025-09-18 09:41:19 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Video_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:41:19 --> Pagination Class Initialized
INFO - 2025-09-18 09:41:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:41:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:41:19 --> Model "Log_model" initialized
INFO - 2025-09-18 09:41:19 --> Final output sent to browser
DEBUG - 2025-09-18 09:41:19 --> Total execution time: 0.1033
INFO - 2025-09-18 04:41:19 --> Config Class Initialized
INFO - 2025-09-18 04:41:19 --> Hooks Class Initialized
INFO - 2025-09-18 04:41:19 --> Config Class Initialized
INFO - 2025-09-18 04:41:19 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:41:19 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:41:19 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:41:19 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:41:19 --> Utf8 Class Initialized
INFO - 2025-09-18 04:41:19 --> URI Class Initialized
INFO - 2025-09-18 04:41:19 --> URI Class Initialized
INFO - 2025-09-18 04:41:19 --> Router Class Initialized
INFO - 2025-09-18 04:41:19 --> Router Class Initialized
INFO - 2025-09-18 04:41:19 --> Output Class Initialized
INFO - 2025-09-18 04:41:19 --> Output Class Initialized
INFO - 2025-09-18 04:41:19 --> Security Class Initialized
INFO - 2025-09-18 04:41:19 --> Security Class Initialized
DEBUG - 2025-09-18 04:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:41:19 --> CSRF cookie sent
INFO - 2025-09-18 04:41:19 --> Input Class Initialized
DEBUG - 2025-09-18 04:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:41:19 --> CSRF cookie sent
INFO - 2025-09-18 04:41:19 --> Language Class Initialized
INFO - 2025-09-18 04:41:19 --> Input Class Initialized
INFO - 2025-09-18 04:41:19 --> Language Class Initialized
INFO - 2025-09-18 04:41:19 --> Loader Class Initialized
INFO - 2025-09-18 04:41:19 --> Loader Class Initialized
INFO - 2025-09-18 04:41:19 --> Helper loaded: url_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: url_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: text_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: text_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: string_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: string_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: form_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: form_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: download_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: download_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: security_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: security_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:41:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:41:19 --> Database Driver Class Initialized
INFO - 2025-09-18 04:41:19 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:41:19 --> Form Validation Class Initialized
INFO - 2025-09-18 04:41:19 --> Model "User_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:41:19 --> Controller Class Initialized
INFO - 2025-09-18 09:41:19 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Video_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Testimoni_model" initialized
DEBUG - 2025-09-18 04:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:41:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:41:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:41:19 --> Model "Log_model" initialized
INFO - 2025-09-18 09:41:19 --> Final output sent to browser
DEBUG - 2025-09-18 09:41:19 --> Total execution time: 0.0621
INFO - 2025-09-18 04:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:41:19 --> Form Validation Class Initialized
INFO - 2025-09-18 04:41:19 --> Model "User_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:41:19 --> Controller Class Initialized
INFO - 2025-09-18 09:41:19 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Video_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:41:19 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:41:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:41:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:41:19 --> Model "Log_model" initialized
INFO - 2025-09-18 09:41:19 --> Final output sent to browser
DEBUG - 2025-09-18 09:41:19 --> Total execution time: 0.0986
INFO - 2025-09-18 04:41:22 --> Config Class Initialized
INFO - 2025-09-18 04:41:22 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:41:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:41:22 --> Utf8 Class Initialized
INFO - 2025-09-18 04:41:22 --> URI Class Initialized
DEBUG - 2025-09-18 04:41:22 --> No URI present. Default controller set.
INFO - 2025-09-18 04:41:22 --> Router Class Initialized
INFO - 2025-09-18 04:41:22 --> Output Class Initialized
INFO - 2025-09-18 04:41:22 --> Security Class Initialized
DEBUG - 2025-09-18 04:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:41:22 --> CSRF cookie sent
INFO - 2025-09-18 04:41:22 --> Input Class Initialized
INFO - 2025-09-18 04:41:22 --> Language Class Initialized
INFO - 2025-09-18 04:41:22 --> Loader Class Initialized
INFO - 2025-09-18 04:41:22 --> Helper loaded: url_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: text_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: string_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: form_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: download_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: security_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:41:22 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:41:22 --> Form Validation Class Initialized
INFO - 2025-09-18 04:41:22 --> Model "User_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:41:22 --> Controller Class Initialized
INFO - 2025-09-18 09:41:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Video_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:41:22 --> Pagination Class Initialized
INFO - 2025-09-18 09:41:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:41:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:41:22 --> Model "Log_model" initialized
INFO - 2025-09-18 09:41:22 --> Final output sent to browser
DEBUG - 2025-09-18 09:41:22 --> Total execution time: 0.1438
INFO - 2025-09-18 04:41:22 --> Config Class Initialized
INFO - 2025-09-18 04:41:22 --> Hooks Class Initialized
INFO - 2025-09-18 04:41:22 --> Config Class Initialized
INFO - 2025-09-18 04:41:22 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:41:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:41:22 --> Utf8 Class Initialized
INFO - 2025-09-18 04:41:22 --> URI Class Initialized
INFO - 2025-09-18 04:41:22 --> Router Class Initialized
DEBUG - 2025-09-18 04:41:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:41:22 --> Utf8 Class Initialized
INFO - 2025-09-18 04:41:22 --> URI Class Initialized
INFO - 2025-09-18 04:41:22 --> Output Class Initialized
INFO - 2025-09-18 04:41:22 --> Router Class Initialized
INFO - 2025-09-18 04:41:22 --> Security Class Initialized
INFO - 2025-09-18 04:41:22 --> Output Class Initialized
DEBUG - 2025-09-18 04:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:41:22 --> CSRF cookie sent
INFO - 2025-09-18 04:41:22 --> Input Class Initialized
INFO - 2025-09-18 04:41:22 --> Security Class Initialized
INFO - 2025-09-18 04:41:22 --> Language Class Initialized
DEBUG - 2025-09-18 04:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:41:22 --> CSRF cookie sent
INFO - 2025-09-18 04:41:22 --> Input Class Initialized
INFO - 2025-09-18 04:41:22 --> Language Class Initialized
INFO - 2025-09-18 04:41:22 --> Loader Class Initialized
INFO - 2025-09-18 04:41:22 --> Helper loaded: url_helper
INFO - 2025-09-18 04:41:22 --> Loader Class Initialized
INFO - 2025-09-18 04:41:22 --> Helper loaded: text_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: string_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: url_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: text_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: form_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: string_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: download_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: security_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: form_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: download_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: security_helper
INFO - 2025-09-18 04:41:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:41:22 --> Database Driver Class Initialized
INFO - 2025-09-18 04:41:22 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:41:22 --> Form Validation Class Initialized
INFO - 2025-09-18 04:41:22 --> Model "User_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:41:22 --> Controller Class Initialized
INFO - 2025-09-18 09:41:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Video_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Mitra_model" initialized
DEBUG - 2025-09-18 04:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:41:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:41:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:41:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:41:22 --> Model "Log_model" initialized
INFO - 2025-09-18 09:41:22 --> Final output sent to browser
DEBUG - 2025-09-18 09:41:22 --> Total execution time: 0.0713
INFO - 2025-09-18 04:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:41:22 --> Form Validation Class Initialized
INFO - 2025-09-18 04:41:22 --> Model "User_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:41:22 --> Controller Class Initialized
INFO - 2025-09-18 09:41:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Video_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:41:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:41:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:41:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:41:22 --> Model "Log_model" initialized
INFO - 2025-09-18 09:41:22 --> Final output sent to browser
DEBUG - 2025-09-18 09:41:22 --> Total execution time: 0.1131
INFO - 2025-09-18 04:44:21 --> Config Class Initialized
INFO - 2025-09-18 04:44:21 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:44:21 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:21 --> Utf8 Class Initialized
INFO - 2025-09-18 04:44:21 --> URI Class Initialized
DEBUG - 2025-09-18 04:44:21 --> No URI present. Default controller set.
INFO - 2025-09-18 04:44:21 --> Router Class Initialized
INFO - 2025-09-18 04:44:21 --> Output Class Initialized
INFO - 2025-09-18 04:44:21 --> Security Class Initialized
DEBUG - 2025-09-18 04:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:21 --> CSRF cookie sent
INFO - 2025-09-18 04:44:21 --> Input Class Initialized
INFO - 2025-09-18 04:44:21 --> Language Class Initialized
INFO - 2025-09-18 04:44:21 --> Loader Class Initialized
INFO - 2025-09-18 04:44:21 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:21 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:21 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:21 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:21 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:21 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:21 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:21 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:21 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:21 --> Controller Class Initialized
INFO - 2025-09-18 09:44:21 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:21 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:44:21 --> Pagination Class Initialized
INFO - 2025-09-18 09:44:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:44:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:22 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:22 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:22 --> Total execution time: 0.0839
INFO - 2025-09-18 04:44:22 --> Config Class Initialized
INFO - 2025-09-18 04:44:22 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:44:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:22 --> Utf8 Class Initialized
INFO - 2025-09-18 04:44:22 --> URI Class Initialized
INFO - 2025-09-18 04:44:22 --> Router Class Initialized
INFO - 2025-09-18 04:44:22 --> Config Class Initialized
INFO - 2025-09-18 04:44:22 --> Hooks Class Initialized
INFO - 2025-09-18 04:44:22 --> Output Class Initialized
INFO - 2025-09-18 04:44:22 --> Security Class Initialized
DEBUG - 2025-09-18 04:44:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:22 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:22 --> CSRF cookie sent
INFO - 2025-09-18 04:44:22 --> Input Class Initialized
INFO - 2025-09-18 04:44:22 --> URI Class Initialized
INFO - 2025-09-18 04:44:22 --> Language Class Initialized
INFO - 2025-09-18 04:44:22 --> Router Class Initialized
INFO - 2025-09-18 04:44:22 --> Output Class Initialized
INFO - 2025-09-18 04:44:22 --> Loader Class Initialized
INFO - 2025-09-18 04:44:22 --> Security Class Initialized
INFO - 2025-09-18 04:44:22 --> Helper loaded: url_helper
DEBUG - 2025-09-18 04:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:22 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:22 --> CSRF cookie sent
INFO - 2025-09-18 04:44:22 --> Input Class Initialized
INFO - 2025-09-18 04:44:22 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:22 --> Language Class Initialized
INFO - 2025-09-18 04:44:22 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:22 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:22 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:22 --> Loader Class Initialized
INFO - 2025-09-18 04:44:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:22 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:22 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:22 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:22 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:22 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:22 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:22 --> Database Driver Class Initialized
INFO - 2025-09-18 04:44:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:22 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:44:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-09-18 04:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:44:22 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:22 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:22 --> Controller Class Initialized
INFO - 2025-09-18 09:44:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:44:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:22 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:22 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:22 --> Total execution time: 0.0899
INFO - 2025-09-18 04:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:22 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:22 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:22 --> Controller Class Initialized
INFO - 2025-09-18 09:44:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:44:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:22 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:22 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:22 --> Total execution time: 0.1272
INFO - 2025-09-18 04:44:34 --> Config Class Initialized
INFO - 2025-09-18 04:44:34 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:44:34 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:34 --> Utf8 Class Initialized
INFO - 2025-09-18 04:44:34 --> URI Class Initialized
DEBUG - 2025-09-18 04:44:34 --> No URI present. Default controller set.
INFO - 2025-09-18 04:44:34 --> Router Class Initialized
INFO - 2025-09-18 04:44:34 --> Output Class Initialized
INFO - 2025-09-18 04:44:34 --> Security Class Initialized
DEBUG - 2025-09-18 04:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:34 --> CSRF cookie sent
INFO - 2025-09-18 04:44:34 --> Input Class Initialized
INFO - 2025-09-18 04:44:34 --> Language Class Initialized
INFO - 2025-09-18 04:44:34 --> Loader Class Initialized
INFO - 2025-09-18 04:44:34 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:35 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:35 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:35 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:35 --> Controller Class Initialized
INFO - 2025-09-18 09:44:35 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:44:35 --> Pagination Class Initialized
INFO - 2025-09-18 09:44:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:44:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:35 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:35 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:35 --> Total execution time: 0.0988
INFO - 2025-09-18 04:44:35 --> Config Class Initialized
INFO - 2025-09-18 04:44:35 --> Hooks Class Initialized
INFO - 2025-09-18 04:44:35 --> Config Class Initialized
INFO - 2025-09-18 04:44:35 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:44:35 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:35 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:44:35 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:35 --> Utf8 Class Initialized
INFO - 2025-09-18 04:44:35 --> URI Class Initialized
INFO - 2025-09-18 04:44:35 --> URI Class Initialized
INFO - 2025-09-18 04:44:35 --> Router Class Initialized
INFO - 2025-09-18 04:44:35 --> Router Class Initialized
INFO - 2025-09-18 04:44:35 --> Output Class Initialized
INFO - 2025-09-18 04:44:35 --> Output Class Initialized
INFO - 2025-09-18 04:44:35 --> Security Class Initialized
INFO - 2025-09-18 04:44:35 --> Security Class Initialized
DEBUG - 2025-09-18 04:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:35 --> CSRF cookie sent
INFO - 2025-09-18 04:44:35 --> Input Class Initialized
INFO - 2025-09-18 04:44:35 --> Language Class Initialized
DEBUG - 2025-09-18 04:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:35 --> CSRF cookie sent
INFO - 2025-09-18 04:44:35 --> Input Class Initialized
INFO - 2025-09-18 04:44:35 --> Language Class Initialized
INFO - 2025-09-18 04:44:35 --> Loader Class Initialized
INFO - 2025-09-18 04:44:35 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:35 --> Loader Class Initialized
INFO - 2025-09-18 04:44:35 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:35 --> Database Driver Class Initialized
INFO - 2025-09-18 04:44:35 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-18 04:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:35 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:35 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:35 --> Controller Class Initialized
INFO - 2025-09-18 09:44:35 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:44:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:35 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:35 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:35 --> Total execution time: 0.0712
INFO - 2025-09-18 04:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:35 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:35 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:35 --> Controller Class Initialized
INFO - 2025-09-18 09:44:35 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:35 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:44:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:35 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:35 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:35 --> Total execution time: 0.1147
INFO - 2025-09-18 04:44:37 --> Config Class Initialized
INFO - 2025-09-18 04:44:37 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:44:37 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:37 --> Utf8 Class Initialized
INFO - 2025-09-18 04:44:37 --> URI Class Initialized
DEBUG - 2025-09-18 04:44:37 --> No URI present. Default controller set.
INFO - 2025-09-18 04:44:37 --> Router Class Initialized
INFO - 2025-09-18 04:44:37 --> Output Class Initialized
INFO - 2025-09-18 04:44:37 --> Security Class Initialized
DEBUG - 2025-09-18 04:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:37 --> CSRF cookie sent
INFO - 2025-09-18 04:44:37 --> Input Class Initialized
INFO - 2025-09-18 04:44:37 --> Language Class Initialized
INFO - 2025-09-18 04:44:37 --> Loader Class Initialized
INFO - 2025-09-18 04:44:37 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:37 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:37 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:37 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:37 --> Controller Class Initialized
INFO - 2025-09-18 09:44:37 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:44:37 --> Pagination Class Initialized
INFO - 2025-09-18 09:44:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:44:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:37 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:37 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:37 --> Total execution time: 0.1333
INFO - 2025-09-18 04:44:37 --> Config Class Initialized
INFO - 2025-09-18 04:44:37 --> Config Class Initialized
INFO - 2025-09-18 04:44:37 --> Hooks Class Initialized
INFO - 2025-09-18 04:44:37 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:44:37 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:37 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:44:37 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:37 --> Utf8 Class Initialized
INFO - 2025-09-18 04:44:37 --> URI Class Initialized
INFO - 2025-09-18 04:44:37 --> URI Class Initialized
INFO - 2025-09-18 04:44:37 --> Router Class Initialized
INFO - 2025-09-18 04:44:37 --> Router Class Initialized
INFO - 2025-09-18 04:44:37 --> Output Class Initialized
INFO - 2025-09-18 04:44:37 --> Security Class Initialized
INFO - 2025-09-18 04:44:37 --> Output Class Initialized
DEBUG - 2025-09-18 04:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:37 --> CSRF cookie sent
INFO - 2025-09-18 04:44:37 --> Input Class Initialized
INFO - 2025-09-18 04:44:37 --> Security Class Initialized
INFO - 2025-09-18 04:44:37 --> Language Class Initialized
DEBUG - 2025-09-18 04:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:37 --> CSRF cookie sent
INFO - 2025-09-18 04:44:37 --> Input Class Initialized
INFO - 2025-09-18 04:44:37 --> Language Class Initialized
INFO - 2025-09-18 04:44:37 --> Loader Class Initialized
INFO - 2025-09-18 04:44:37 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:37 --> Loader Class Initialized
INFO - 2025-09-18 04:44:37 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:37 --> Database Driver Class Initialized
INFO - 2025-09-18 04:44:37 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:37 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:37 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Kunjungan_model" initialized
DEBUG - 2025-09-18 04:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:44:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:37 --> Controller Class Initialized
INFO - 2025-09-18 09:44:37 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:44:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:37 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:37 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:37 --> Total execution time: 0.0829
INFO - 2025-09-18 04:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:37 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:37 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:37 --> Controller Class Initialized
INFO - 2025-09-18 09:44:37 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:37 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:44:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:37 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:37 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:37 --> Total execution time: 0.1142
INFO - 2025-09-18 04:44:54 --> Config Class Initialized
INFO - 2025-09-18 04:44:54 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:44:54 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:54 --> Utf8 Class Initialized
INFO - 2025-09-18 04:44:54 --> URI Class Initialized
DEBUG - 2025-09-18 04:44:54 --> No URI present. Default controller set.
INFO - 2025-09-18 04:44:54 --> Router Class Initialized
INFO - 2025-09-18 04:44:54 --> Output Class Initialized
INFO - 2025-09-18 04:44:54 --> Security Class Initialized
DEBUG - 2025-09-18 04:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:54 --> CSRF cookie sent
INFO - 2025-09-18 04:44:54 --> Input Class Initialized
INFO - 2025-09-18 04:44:54 --> Language Class Initialized
INFO - 2025-09-18 04:44:54 --> Loader Class Initialized
INFO - 2025-09-18 04:44:54 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:54 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:54 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:54 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:54 --> Controller Class Initialized
INFO - 2025-09-18 09:44:54 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:44:54 --> Pagination Class Initialized
INFO - 2025-09-18 09:44:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:44:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:54 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:54 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:54 --> Total execution time: 0.1092
INFO - 2025-09-18 04:44:54 --> Config Class Initialized
INFO - 2025-09-18 04:44:54 --> Hooks Class Initialized
INFO - 2025-09-18 04:44:54 --> Config Class Initialized
INFO - 2025-09-18 04:44:54 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:44:54 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:54 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:44:54 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:44:54 --> Utf8 Class Initialized
INFO - 2025-09-18 04:44:54 --> URI Class Initialized
INFO - 2025-09-18 04:44:54 --> URI Class Initialized
INFO - 2025-09-18 04:44:54 --> Router Class Initialized
INFO - 2025-09-18 04:44:54 --> Router Class Initialized
INFO - 2025-09-18 04:44:54 --> Output Class Initialized
INFO - 2025-09-18 04:44:54 --> Output Class Initialized
INFO - 2025-09-18 04:44:54 --> Security Class Initialized
INFO - 2025-09-18 04:44:54 --> Security Class Initialized
DEBUG - 2025-09-18 04:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:54 --> CSRF cookie sent
INFO - 2025-09-18 04:44:54 --> Input Class Initialized
DEBUG - 2025-09-18 04:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:44:54 --> Language Class Initialized
INFO - 2025-09-18 04:44:54 --> CSRF cookie sent
INFO - 2025-09-18 04:44:54 --> Input Class Initialized
INFO - 2025-09-18 04:44:54 --> Language Class Initialized
INFO - 2025-09-18 04:44:54 --> Loader Class Initialized
INFO - 2025-09-18 04:44:54 --> Loader Class Initialized
INFO - 2025-09-18 04:44:54 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: url_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: text_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: string_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: form_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: download_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: security_helper
INFO - 2025-09-18 04:44:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:44:54 --> Database Driver Class Initialized
INFO - 2025-09-18 04:44:54 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-18 04:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:54 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:54 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:54 --> Controller Class Initialized
INFO - 2025-09-18 09:44:54 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:44:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:54 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:54 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:54 --> Total execution time: 0.0759
INFO - 2025-09-18 04:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:44:54 --> Form Validation Class Initialized
INFO - 2025-09-18 04:44:54 --> Model "User_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:44:54 --> Controller Class Initialized
INFO - 2025-09-18 09:44:54 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Video_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:44:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:44:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:44:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:44:54 --> Model "Log_model" initialized
INFO - 2025-09-18 09:44:54 --> Final output sent to browser
DEBUG - 2025-09-18 09:44:54 --> Total execution time: 0.1073
INFO - 2025-09-18 04:45:01 --> Config Class Initialized
INFO - 2025-09-18 04:45:01 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:45:01 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:45:01 --> Utf8 Class Initialized
INFO - 2025-09-18 04:45:01 --> URI Class Initialized
DEBUG - 2025-09-18 04:45:01 --> No URI present. Default controller set.
INFO - 2025-09-18 04:45:01 --> Router Class Initialized
INFO - 2025-09-18 04:45:01 --> Output Class Initialized
INFO - 2025-09-18 04:45:01 --> Security Class Initialized
DEBUG - 2025-09-18 04:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:45:01 --> CSRF cookie sent
INFO - 2025-09-18 04:45:01 --> Input Class Initialized
INFO - 2025-09-18 04:45:01 --> Language Class Initialized
INFO - 2025-09-18 04:45:01 --> Loader Class Initialized
INFO - 2025-09-18 04:45:01 --> Helper loaded: url_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: text_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: string_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: form_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: download_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: security_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:45:01 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:45:01 --> Form Validation Class Initialized
INFO - 2025-09-18 04:45:01 --> Model "User_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:45:01 --> Controller Class Initialized
INFO - 2025-09-18 09:45:01 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Video_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:45:01 --> Pagination Class Initialized
INFO - 2025-09-18 09:45:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:45:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:45:01 --> Model "Log_model" initialized
INFO - 2025-09-18 09:45:01 --> Final output sent to browser
DEBUG - 2025-09-18 09:45:01 --> Total execution time: 0.1021
INFO - 2025-09-18 04:45:01 --> Config Class Initialized
INFO - 2025-09-18 04:45:01 --> Hooks Class Initialized
INFO - 2025-09-18 04:45:01 --> Config Class Initialized
INFO - 2025-09-18 04:45:01 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:45:01 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:45:01 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:45:01 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:45:01 --> Utf8 Class Initialized
INFO - 2025-09-18 04:45:01 --> URI Class Initialized
INFO - 2025-09-18 04:45:01 --> URI Class Initialized
INFO - 2025-09-18 04:45:01 --> Router Class Initialized
INFO - 2025-09-18 04:45:01 --> Router Class Initialized
INFO - 2025-09-18 04:45:01 --> Output Class Initialized
INFO - 2025-09-18 04:45:01 --> Output Class Initialized
INFO - 2025-09-18 04:45:01 --> Security Class Initialized
INFO - 2025-09-18 04:45:01 --> Security Class Initialized
DEBUG - 2025-09-18 04:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:45:01 --> CSRF cookie sent
INFO - 2025-09-18 04:45:01 --> Input Class Initialized
INFO - 2025-09-18 04:45:01 --> Language Class Initialized
DEBUG - 2025-09-18 04:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:45:01 --> CSRF cookie sent
INFO - 2025-09-18 04:45:01 --> Input Class Initialized
INFO - 2025-09-18 04:45:01 --> Loader Class Initialized
INFO - 2025-09-18 04:45:01 --> Language Class Initialized
INFO - 2025-09-18 04:45:01 --> Helper loaded: url_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: text_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: string_helper
INFO - 2025-09-18 04:45:01 --> Loader Class Initialized
INFO - 2025-09-18 04:45:01 --> Helper loaded: form_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: download_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: security_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: url_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: text_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: string_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: form_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: download_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: security_helper
INFO - 2025-09-18 04:45:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:45:01 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:45:01 --> Database Driver Class Initialized
INFO - 2025-09-18 04:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:45:01 --> Form Validation Class Initialized
INFO - 2025-09-18 04:45:01 --> Model "User_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Kunjungan_model" initialized
DEBUG - 2025-09-18 04:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:45:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:45:01 --> Controller Class Initialized
INFO - 2025-09-18 09:45:01 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Video_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:45:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:45:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:45:01 --> Model "Log_model" initialized
INFO - 2025-09-18 09:45:01 --> Final output sent to browser
DEBUG - 2025-09-18 09:45:01 --> Total execution time: 0.0582
INFO - 2025-09-18 04:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:45:01 --> Form Validation Class Initialized
INFO - 2025-09-18 04:45:01 --> Model "User_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:45:01 --> Controller Class Initialized
INFO - 2025-09-18 09:45:01 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Video_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:45:01 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:45:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:45:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:45:01 --> Model "Log_model" initialized
INFO - 2025-09-18 09:45:01 --> Final output sent to browser
DEBUG - 2025-09-18 09:45:01 --> Total execution time: 0.0895
INFO - 2025-09-18 04:45:14 --> Config Class Initialized
INFO - 2025-09-18 04:45:14 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:45:14 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:45:14 --> Utf8 Class Initialized
INFO - 2025-09-18 04:45:14 --> URI Class Initialized
DEBUG - 2025-09-18 04:45:14 --> No URI present. Default controller set.
INFO - 2025-09-18 04:45:14 --> Router Class Initialized
INFO - 2025-09-18 04:45:14 --> Output Class Initialized
INFO - 2025-09-18 04:45:14 --> Security Class Initialized
DEBUG - 2025-09-18 04:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:45:14 --> CSRF cookie sent
INFO - 2025-09-18 04:45:14 --> Input Class Initialized
INFO - 2025-09-18 04:45:14 --> Language Class Initialized
INFO - 2025-09-18 04:45:14 --> Loader Class Initialized
INFO - 2025-09-18 04:45:14 --> Helper loaded: url_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: text_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: string_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: form_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: download_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: security_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:45:14 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:45:14 --> Form Validation Class Initialized
INFO - 2025-09-18 04:45:14 --> Model "User_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:45:14 --> Controller Class Initialized
INFO - 2025-09-18 09:45:14 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Video_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:45:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:45:14 --> Pagination Class Initialized
INFO - 2025-09-18 09:45:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:45:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:45:14 --> Model "Log_model" initialized
INFO - 2025-09-18 09:45:14 --> Final output sent to browser
DEBUG - 2025-09-18 09:45:14 --> Total execution time: 0.1043
INFO - 2025-09-18 04:45:14 --> Config Class Initialized
INFO - 2025-09-18 04:45:14 --> Config Class Initialized
INFO - 2025-09-18 04:45:14 --> Hooks Class Initialized
INFO - 2025-09-18 04:45:14 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:45:14 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:45:14 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:45:14 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:45:14 --> Utf8 Class Initialized
INFO - 2025-09-18 04:45:14 --> URI Class Initialized
INFO - 2025-09-18 04:45:14 --> URI Class Initialized
INFO - 2025-09-18 04:45:14 --> Router Class Initialized
INFO - 2025-09-18 04:45:14 --> Router Class Initialized
INFO - 2025-09-18 04:45:14 --> Output Class Initialized
INFO - 2025-09-18 04:45:14 --> Output Class Initialized
INFO - 2025-09-18 04:45:14 --> Security Class Initialized
INFO - 2025-09-18 04:45:14 --> Security Class Initialized
DEBUG - 2025-09-18 04:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-18 04:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:45:14 --> CSRF cookie sent
INFO - 2025-09-18 04:45:14 --> CSRF cookie sent
INFO - 2025-09-18 04:45:14 --> Input Class Initialized
INFO - 2025-09-18 04:45:14 --> Input Class Initialized
INFO - 2025-09-18 04:45:14 --> Language Class Initialized
INFO - 2025-09-18 04:45:14 --> Language Class Initialized
INFO - 2025-09-18 04:45:14 --> Loader Class Initialized
INFO - 2025-09-18 04:45:14 --> Loader Class Initialized
INFO - 2025-09-18 04:45:14 --> Helper loaded: url_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: url_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: text_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: text_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: string_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: string_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: form_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: download_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: form_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: security_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: download_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: security_helper
INFO - 2025-09-18 04:45:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:45:14 --> Database Driver Class Initialized
INFO - 2025-09-18 04:45:14 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:45:14 --> Form Validation Class Initialized
INFO - 2025-09-18 04:45:14 --> Model "User_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Kunjungan_model" initialized
DEBUG - 2025-09-18 04:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:45:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:45:14 --> Controller Class Initialized
INFO - 2025-09-18 09:45:14 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Video_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:45:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:45:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:45:14 --> Model "Log_model" initialized
INFO - 2025-09-18 09:45:14 --> Final output sent to browser
DEBUG - 2025-09-18 09:45:14 --> Total execution time: 0.0799
INFO - 2025-09-18 04:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:45:14 --> Form Validation Class Initialized
INFO - 2025-09-18 04:45:14 --> Model "User_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:45:14 --> Controller Class Initialized
INFO - 2025-09-18 09:45:14 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Video_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:45:14 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:45:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:45:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:45:14 --> Model "Log_model" initialized
INFO - 2025-09-18 09:45:14 --> Final output sent to browser
DEBUG - 2025-09-18 09:45:14 --> Total execution time: 0.1029
INFO - 2025-09-18 04:45:17 --> Config Class Initialized
INFO - 2025-09-18 04:45:17 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:45:17 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:45:17 --> Utf8 Class Initialized
INFO - 2025-09-18 04:45:17 --> URI Class Initialized
DEBUG - 2025-09-18 04:45:17 --> No URI present. Default controller set.
INFO - 2025-09-18 04:45:17 --> Router Class Initialized
INFO - 2025-09-18 04:45:17 --> Output Class Initialized
INFO - 2025-09-18 04:45:17 --> Security Class Initialized
DEBUG - 2025-09-18 04:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:45:17 --> CSRF cookie sent
INFO - 2025-09-18 04:45:17 --> Input Class Initialized
INFO - 2025-09-18 04:45:17 --> Language Class Initialized
INFO - 2025-09-18 04:45:17 --> Loader Class Initialized
INFO - 2025-09-18 04:45:17 --> Helper loaded: url_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: text_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: string_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: form_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: download_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: security_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:45:17 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:45:17 --> Form Validation Class Initialized
INFO - 2025-09-18 04:45:17 --> Model "User_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:45:17 --> Controller Class Initialized
INFO - 2025-09-18 09:45:17 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Video_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:45:17 --> Pagination Class Initialized
INFO - 2025-09-18 09:45:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:45:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:45:17 --> Model "Log_model" initialized
INFO - 2025-09-18 09:45:17 --> Final output sent to browser
DEBUG - 2025-09-18 09:45:17 --> Total execution time: 0.1139
INFO - 2025-09-18 04:45:17 --> Config Class Initialized
INFO - 2025-09-18 04:45:17 --> Config Class Initialized
INFO - 2025-09-18 04:45:17 --> Hooks Class Initialized
INFO - 2025-09-18 04:45:17 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:45:17 --> UTF-8 Support Enabled
DEBUG - 2025-09-18 04:45:17 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:45:17 --> Utf8 Class Initialized
INFO - 2025-09-18 04:45:17 --> Utf8 Class Initialized
INFO - 2025-09-18 04:45:17 --> URI Class Initialized
INFO - 2025-09-18 04:45:17 --> URI Class Initialized
INFO - 2025-09-18 04:45:17 --> Router Class Initialized
INFO - 2025-09-18 04:45:17 --> Router Class Initialized
INFO - 2025-09-18 04:45:17 --> Output Class Initialized
INFO - 2025-09-18 04:45:17 --> Output Class Initialized
INFO - 2025-09-18 04:45:17 --> Security Class Initialized
INFO - 2025-09-18 04:45:17 --> Security Class Initialized
DEBUG - 2025-09-18 04:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:45:17 --> CSRF cookie sent
INFO - 2025-09-18 04:45:17 --> Input Class Initialized
DEBUG - 2025-09-18 04:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:45:17 --> CSRF cookie sent
INFO - 2025-09-18 04:45:17 --> Language Class Initialized
INFO - 2025-09-18 04:45:17 --> Input Class Initialized
INFO - 2025-09-18 04:45:17 --> Language Class Initialized
INFO - 2025-09-18 04:45:17 --> Loader Class Initialized
INFO - 2025-09-18 04:45:17 --> Loader Class Initialized
INFO - 2025-09-18 04:45:17 --> Helper loaded: url_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: url_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: text_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: string_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: text_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: string_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: form_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: download_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: form_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: security_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: download_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: security_helper
INFO - 2025-09-18 04:45:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:45:17 --> Database Driver Class Initialized
INFO - 2025-09-18 04:45:17 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:45:17 --> Form Validation Class Initialized
INFO - 2025-09-18 04:45:17 --> Model "User_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:45:17 --> Controller Class Initialized
INFO - 2025-09-18 09:45:17 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Video_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Mitra_model" initialized
DEBUG - 2025-09-18 04:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:45:17 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:45:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:45:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:45:17 --> Model "Log_model" initialized
INFO - 2025-09-18 09:45:17 --> Final output sent to browser
DEBUG - 2025-09-18 09:45:17 --> Total execution time: 0.0702
INFO - 2025-09-18 04:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:45:17 --> Form Validation Class Initialized
INFO - 2025-09-18 04:45:17 --> Model "User_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:45:17 --> Controller Class Initialized
INFO - 2025-09-18 09:45:17 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Video_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:45:17 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:45:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:45:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:45:17 --> Model "Log_model" initialized
INFO - 2025-09-18 09:45:17 --> Final output sent to browser
DEBUG - 2025-09-18 09:45:17 --> Total execution time: 0.1029
INFO - 2025-09-18 04:46:08 --> Config Class Initialized
INFO - 2025-09-18 04:46:08 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:46:08 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:46:08 --> Utf8 Class Initialized
INFO - 2025-09-18 04:46:08 --> URI Class Initialized
DEBUG - 2025-09-18 04:46:08 --> No URI present. Default controller set.
INFO - 2025-09-18 04:46:08 --> Router Class Initialized
INFO - 2025-09-18 04:46:08 --> Output Class Initialized
INFO - 2025-09-18 04:46:08 --> Security Class Initialized
DEBUG - 2025-09-18 04:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:46:08 --> CSRF cookie sent
INFO - 2025-09-18 04:46:08 --> Input Class Initialized
INFO - 2025-09-18 04:46:08 --> Language Class Initialized
INFO - 2025-09-18 04:46:08 --> Loader Class Initialized
INFO - 2025-09-18 04:46:08 --> Helper loaded: url_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: text_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: string_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: form_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: download_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: security_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:46:08 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:46:08 --> Form Validation Class Initialized
INFO - 2025-09-18 04:46:08 --> Model "User_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:46:08 --> Controller Class Initialized
INFO - 2025-09-18 09:46:08 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Video_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:46:08 --> Pagination Class Initialized
INFO - 2025-09-18 09:46:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:46:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:46:08 --> Model "Log_model" initialized
INFO - 2025-09-18 09:46:08 --> Final output sent to browser
DEBUG - 2025-09-18 09:46:08 --> Total execution time: 0.1100
INFO - 2025-09-18 04:46:08 --> Config Class Initialized
INFO - 2025-09-18 04:46:08 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:46:08 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:46:08 --> Utf8 Class Initialized
INFO - 2025-09-18 04:46:08 --> URI Class Initialized
INFO - 2025-09-18 04:46:08 --> Router Class Initialized
INFO - 2025-09-18 04:46:08 --> Output Class Initialized
INFO - 2025-09-18 04:46:08 --> Config Class Initialized
INFO - 2025-09-18 04:46:08 --> Hooks Class Initialized
INFO - 2025-09-18 04:46:08 --> Security Class Initialized
DEBUG - 2025-09-18 04:46:08 --> UTF-8 Support Enabled
DEBUG - 2025-09-18 04:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:46:08 --> Utf8 Class Initialized
INFO - 2025-09-18 04:46:08 --> CSRF cookie sent
INFO - 2025-09-18 04:46:08 --> Input Class Initialized
INFO - 2025-09-18 04:46:08 --> URI Class Initialized
INFO - 2025-09-18 04:46:08 --> Language Class Initialized
INFO - 2025-09-18 04:46:08 --> Router Class Initialized
INFO - 2025-09-18 04:46:08 --> Loader Class Initialized
INFO - 2025-09-18 04:46:08 --> Output Class Initialized
INFO - 2025-09-18 04:46:08 --> Helper loaded: url_helper
INFO - 2025-09-18 04:46:08 --> Security Class Initialized
INFO - 2025-09-18 04:46:08 --> Helper loaded: text_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: string_helper
DEBUG - 2025-09-18 04:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:46:08 --> CSRF cookie sent
INFO - 2025-09-18 04:46:08 --> Input Class Initialized
INFO - 2025-09-18 04:46:08 --> Language Class Initialized
INFO - 2025-09-18 04:46:08 --> Helper loaded: form_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: download_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: security_helper
INFO - 2025-09-18 04:46:08 --> Loader Class Initialized
INFO - 2025-09-18 04:46:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: url_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: text_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: string_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: form_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: download_helper
INFO - 2025-09-18 04:46:08 --> Helper loaded: security_helper
INFO - 2025-09-18 04:46:08 --> Database Driver Class Initialized
INFO - 2025-09-18 04:46:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:46:08 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:46:08 --> Form Validation Class Initialized
INFO - 2025-09-18 04:46:08 --> Model "User_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:46:08 --> Controller Class Initialized
INFO - 2025-09-18 09:46:08 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Video_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Testimoni_model" initialized
DEBUG - 2025-09-18 04:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:46:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:46:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:46:08 --> Model "Log_model" initialized
INFO - 2025-09-18 09:46:08 --> Final output sent to browser
DEBUG - 2025-09-18 09:46:08 --> Total execution time: 0.0697
INFO - 2025-09-18 04:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:46:08 --> Form Validation Class Initialized
INFO - 2025-09-18 04:46:08 --> Model "User_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:46:08 --> Controller Class Initialized
INFO - 2025-09-18 09:46:08 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Video_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:46:08 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:46:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:46:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:46:08 --> Model "Log_model" initialized
INFO - 2025-09-18 09:46:08 --> Final output sent to browser
DEBUG - 2025-09-18 09:46:08 --> Total execution time: 0.0965
INFO - 2025-09-18 04:46:22 --> Config Class Initialized
INFO - 2025-09-18 04:46:22 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:46:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:46:22 --> Utf8 Class Initialized
INFO - 2025-09-18 04:46:22 --> URI Class Initialized
DEBUG - 2025-09-18 04:46:22 --> No URI present. Default controller set.
INFO - 2025-09-18 04:46:22 --> Router Class Initialized
INFO - 2025-09-18 04:46:22 --> Output Class Initialized
INFO - 2025-09-18 04:46:22 --> Security Class Initialized
DEBUG - 2025-09-18 04:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:46:22 --> CSRF cookie sent
INFO - 2025-09-18 04:46:22 --> Input Class Initialized
INFO - 2025-09-18 04:46:22 --> Language Class Initialized
INFO - 2025-09-18 04:46:22 --> Loader Class Initialized
INFO - 2025-09-18 04:46:22 --> Helper loaded: url_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: text_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: string_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: form_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: download_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: security_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:46:22 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:46:22 --> Form Validation Class Initialized
INFO - 2025-09-18 04:46:22 --> Model "User_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:46:22 --> Controller Class Initialized
INFO - 2025-09-18 09:46:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Video_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:46:22 --> Pagination Class Initialized
INFO - 2025-09-18 09:46:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:46:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:46:22 --> Model "Log_model" initialized
INFO - 2025-09-18 09:46:22 --> Final output sent to browser
DEBUG - 2025-09-18 09:46:22 --> Total execution time: 0.0913
INFO - 2025-09-18 04:46:22 --> Config Class Initialized
INFO - 2025-09-18 04:46:22 --> Hooks Class Initialized
INFO - 2025-09-18 04:46:22 --> Config Class Initialized
INFO - 2025-09-18 04:46:22 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:46:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:46:22 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:46:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:46:22 --> Utf8 Class Initialized
INFO - 2025-09-18 04:46:22 --> URI Class Initialized
INFO - 2025-09-18 04:46:22 --> URI Class Initialized
INFO - 2025-09-18 04:46:22 --> Router Class Initialized
INFO - 2025-09-18 04:46:22 --> Router Class Initialized
INFO - 2025-09-18 04:46:22 --> Output Class Initialized
INFO - 2025-09-18 04:46:22 --> Output Class Initialized
INFO - 2025-09-18 04:46:22 --> Security Class Initialized
INFO - 2025-09-18 04:46:22 --> Security Class Initialized
DEBUG - 2025-09-18 04:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-18 04:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:46:22 --> CSRF cookie sent
INFO - 2025-09-18 04:46:22 --> CSRF cookie sent
INFO - 2025-09-18 04:46:22 --> Input Class Initialized
INFO - 2025-09-18 04:46:22 --> Input Class Initialized
INFO - 2025-09-18 04:46:22 --> Language Class Initialized
INFO - 2025-09-18 04:46:22 --> Language Class Initialized
INFO - 2025-09-18 04:46:22 --> Loader Class Initialized
INFO - 2025-09-18 04:46:22 --> Helper loaded: url_helper
INFO - 2025-09-18 04:46:22 --> Loader Class Initialized
INFO - 2025-09-18 04:46:22 --> Helper loaded: text_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: url_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: string_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: text_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: string_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: form_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: download_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: form_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: security_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: download_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: security_helper
INFO - 2025-09-18 04:46:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:46:22 --> Database Driver Class Initialized
INFO - 2025-09-18 04:46:22 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:46:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-09-18 04:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:46:22 --> Form Validation Class Initialized
INFO - 2025-09-18 04:46:22 --> Model "User_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:46:22 --> Controller Class Initialized
INFO - 2025-09-18 09:46:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Video_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:46:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:46:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:46:22 --> Model "Log_model" initialized
INFO - 2025-09-18 09:46:22 --> Final output sent to browser
DEBUG - 2025-09-18 09:46:22 --> Total execution time: 0.0554
INFO - 2025-09-18 04:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:46:22 --> Form Validation Class Initialized
INFO - 2025-09-18 04:46:22 --> Model "User_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:46:22 --> Controller Class Initialized
INFO - 2025-09-18 09:46:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Video_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:46:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:46:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:46:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:46:22 --> Model "Log_model" initialized
INFO - 2025-09-18 09:46:22 --> Final output sent to browser
DEBUG - 2025-09-18 09:46:22 --> Total execution time: 0.0920
INFO - 2025-09-18 04:46:24 --> Config Class Initialized
INFO - 2025-09-18 04:46:24 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:46:24 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:46:24 --> Utf8 Class Initialized
INFO - 2025-09-18 04:46:24 --> URI Class Initialized
DEBUG - 2025-09-18 04:46:24 --> No URI present. Default controller set.
INFO - 2025-09-18 04:46:24 --> Router Class Initialized
INFO - 2025-09-18 04:46:24 --> Output Class Initialized
INFO - 2025-09-18 04:46:24 --> Security Class Initialized
DEBUG - 2025-09-18 04:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:46:24 --> CSRF cookie sent
INFO - 2025-09-18 04:46:24 --> Input Class Initialized
INFO - 2025-09-18 04:46:24 --> Language Class Initialized
INFO - 2025-09-18 04:46:24 --> Loader Class Initialized
INFO - 2025-09-18 04:46:24 --> Helper loaded: url_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: text_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: string_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: form_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: download_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: security_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:46:24 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:46:24 --> Form Validation Class Initialized
INFO - 2025-09-18 04:46:24 --> Model "User_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:46:24 --> Controller Class Initialized
INFO - 2025-09-18 09:46:24 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Video_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:46:24 --> Pagination Class Initialized
INFO - 2025-09-18 09:46:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:46:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:46:24 --> Model "Log_model" initialized
INFO - 2025-09-18 09:46:24 --> Final output sent to browser
DEBUG - 2025-09-18 09:46:24 --> Total execution time: 0.1353
INFO - 2025-09-18 04:46:24 --> Config Class Initialized
INFO - 2025-09-18 04:46:24 --> Hooks Class Initialized
INFO - 2025-09-18 04:46:24 --> Config Class Initialized
INFO - 2025-09-18 04:46:24 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:46:24 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:46:24 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:46:24 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:46:24 --> Utf8 Class Initialized
INFO - 2025-09-18 04:46:24 --> URI Class Initialized
INFO - 2025-09-18 04:46:24 --> URI Class Initialized
INFO - 2025-09-18 04:46:24 --> Router Class Initialized
INFO - 2025-09-18 04:46:24 --> Router Class Initialized
INFO - 2025-09-18 04:46:24 --> Output Class Initialized
INFO - 2025-09-18 04:46:24 --> Output Class Initialized
INFO - 2025-09-18 04:46:24 --> Security Class Initialized
INFO - 2025-09-18 04:46:24 --> Security Class Initialized
DEBUG - 2025-09-18 04:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:46:24 --> CSRF cookie sent
INFO - 2025-09-18 04:46:24 --> Input Class Initialized
DEBUG - 2025-09-18 04:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:46:24 --> CSRF cookie sent
INFO - 2025-09-18 04:46:24 --> Language Class Initialized
INFO - 2025-09-18 04:46:24 --> Input Class Initialized
INFO - 2025-09-18 04:46:24 --> Language Class Initialized
INFO - 2025-09-18 04:46:24 --> Loader Class Initialized
INFO - 2025-09-18 04:46:24 --> Loader Class Initialized
INFO - 2025-09-18 04:46:24 --> Helper loaded: url_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: url_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: text_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: text_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: string_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: string_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: form_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: download_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: form_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: security_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: download_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: security_helper
INFO - 2025-09-18 04:46:24 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:46:24 --> Database Driver Class Initialized
INFO - 2025-09-18 04:46:24 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:46:24 --> Form Validation Class Initialized
INFO - 2025-09-18 04:46:24 --> Model "User_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:46:24 --> Controller Class Initialized
INFO - 2025-09-18 09:46:24 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Video_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Agenda_model" initialized
DEBUG - 2025-09-18 04:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:46:24 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:46:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:46:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:46:24 --> Model "Log_model" initialized
INFO - 2025-09-18 09:46:24 --> Final output sent to browser
DEBUG - 2025-09-18 09:46:24 --> Total execution time: 0.0846
INFO - 2025-09-18 04:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:46:24 --> Form Validation Class Initialized
INFO - 2025-09-18 04:46:24 --> Model "User_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:46:24 --> Controller Class Initialized
INFO - 2025-09-18 09:46:24 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Video_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:46:24 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:46:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:46:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:46:24 --> Model "Log_model" initialized
INFO - 2025-09-18 09:46:24 --> Final output sent to browser
DEBUG - 2025-09-18 09:46:24 --> Total execution time: 0.1271
INFO - 2025-09-18 04:47:13 --> Config Class Initialized
INFO - 2025-09-18 04:47:13 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:47:13 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:47:13 --> Utf8 Class Initialized
INFO - 2025-09-18 04:47:13 --> URI Class Initialized
DEBUG - 2025-09-18 04:47:13 --> No URI present. Default controller set.
INFO - 2025-09-18 04:47:13 --> Router Class Initialized
INFO - 2025-09-18 04:47:13 --> Output Class Initialized
INFO - 2025-09-18 04:47:13 --> Security Class Initialized
DEBUG - 2025-09-18 04:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:47:13 --> CSRF cookie sent
INFO - 2025-09-18 04:47:13 --> Input Class Initialized
INFO - 2025-09-18 04:47:13 --> Language Class Initialized
INFO - 2025-09-18 04:47:13 --> Loader Class Initialized
INFO - 2025-09-18 04:47:13 --> Helper loaded: url_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: text_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: string_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: form_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: download_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: security_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:47:13 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:47:13 --> Form Validation Class Initialized
INFO - 2025-09-18 04:47:13 --> Model "User_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:47:13 --> Controller Class Initialized
INFO - 2025-09-18 09:47:13 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Video_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:47:13 --> Pagination Class Initialized
INFO - 2025-09-18 09:47:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:47:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:47:13 --> Model "Log_model" initialized
INFO - 2025-09-18 09:47:13 --> Final output sent to browser
DEBUG - 2025-09-18 09:47:13 --> Total execution time: 0.0972
INFO - 2025-09-18 04:47:13 --> Config Class Initialized
INFO - 2025-09-18 04:47:13 --> Hooks Class Initialized
INFO - 2025-09-18 04:47:13 --> Config Class Initialized
INFO - 2025-09-18 04:47:13 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:47:13 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:47:13 --> Utf8 Class Initialized
DEBUG - 2025-09-18 04:47:13 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:47:13 --> Utf8 Class Initialized
INFO - 2025-09-18 04:47:13 --> URI Class Initialized
INFO - 2025-09-18 04:47:13 --> URI Class Initialized
INFO - 2025-09-18 04:47:13 --> Router Class Initialized
INFO - 2025-09-18 04:47:13 --> Router Class Initialized
INFO - 2025-09-18 04:47:13 --> Output Class Initialized
INFO - 2025-09-18 04:47:13 --> Output Class Initialized
INFO - 2025-09-18 04:47:13 --> Security Class Initialized
INFO - 2025-09-18 04:47:13 --> Security Class Initialized
DEBUG - 2025-09-18 04:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:47:13 --> CSRF cookie sent
INFO - 2025-09-18 04:47:13 --> Input Class Initialized
DEBUG - 2025-09-18 04:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:47:13 --> CSRF cookie sent
INFO - 2025-09-18 04:47:13 --> Input Class Initialized
INFO - 2025-09-18 04:47:13 --> Language Class Initialized
INFO - 2025-09-18 04:47:13 --> Language Class Initialized
INFO - 2025-09-18 04:47:13 --> Loader Class Initialized
INFO - 2025-09-18 04:47:13 --> Loader Class Initialized
INFO - 2025-09-18 04:47:13 --> Helper loaded: url_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: url_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: text_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: text_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: string_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: string_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: form_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: form_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: download_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: download_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: security_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: security_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:47:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:47:13 --> Database Driver Class Initialized
INFO - 2025-09-18 04:47:13 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:47:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-09-18 04:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:47:13 --> Form Validation Class Initialized
INFO - 2025-09-18 04:47:13 --> Model "User_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:47:13 --> Controller Class Initialized
INFO - 2025-09-18 09:47:13 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Video_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:47:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:47:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:47:13 --> Model "Log_model" initialized
INFO - 2025-09-18 09:47:13 --> Final output sent to browser
DEBUG - 2025-09-18 09:47:13 --> Total execution time: 0.0678
INFO - 2025-09-18 04:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:47:13 --> Form Validation Class Initialized
INFO - 2025-09-18 04:47:13 --> Model "User_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:47:13 --> Controller Class Initialized
INFO - 2025-09-18 09:47:13 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Video_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:47:13 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:47:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 09:47:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:47:13 --> Model "Log_model" initialized
INFO - 2025-09-18 09:47:13 --> Final output sent to browser
DEBUG - 2025-09-18 09:47:13 --> Total execution time: 0.0950
INFO - 2025-09-18 04:47:42 --> Config Class Initialized
INFO - 2025-09-18 04:47:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:47:42 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:47:42 --> Utf8 Class Initialized
INFO - 2025-09-18 04:47:42 --> URI Class Initialized
DEBUG - 2025-09-18 04:47:42 --> No URI present. Default controller set.
INFO - 2025-09-18 04:47:42 --> Router Class Initialized
INFO - 2025-09-18 04:47:42 --> Output Class Initialized
INFO - 2025-09-18 04:47:42 --> Security Class Initialized
DEBUG - 2025-09-18 04:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:47:42 --> CSRF cookie sent
INFO - 2025-09-18 04:47:42 --> Input Class Initialized
INFO - 2025-09-18 04:47:42 --> Language Class Initialized
INFO - 2025-09-18 04:47:42 --> Loader Class Initialized
INFO - 2025-09-18 04:47:42 --> Helper loaded: url_helper
INFO - 2025-09-18 04:47:42 --> Helper loaded: text_helper
INFO - 2025-09-18 04:47:42 --> Helper loaded: string_helper
INFO - 2025-09-18 04:47:42 --> Helper loaded: form_helper
INFO - 2025-09-18 04:47:42 --> Helper loaded: download_helper
INFO - 2025-09-18 04:47:42 --> Helper loaded: security_helper
INFO - 2025-09-18 04:47:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:47:42 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:47:42 --> Form Validation Class Initialized
INFO - 2025-09-18 04:47:42 --> Model "User_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:47:42 --> Controller Class Initialized
INFO - 2025-09-18 09:47:42 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Video_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:47:42 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:47:42 --> Pagination Class Initialized
INFO - 2025-09-18 09:47:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:47:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:47:42 --> Model "Log_model" initialized
INFO - 2025-09-18 09:47:42 --> Final output sent to browser
DEBUG - 2025-09-18 09:47:42 --> Total execution time: 0.1763
INFO - 2025-09-18 04:49:21 --> Config Class Initialized
INFO - 2025-09-18 04:49:21 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:49:21 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:49:21 --> Utf8 Class Initialized
INFO - 2025-09-18 04:49:21 --> URI Class Initialized
DEBUG - 2025-09-18 04:49:21 --> No URI present. Default controller set.
INFO - 2025-09-18 04:49:21 --> Router Class Initialized
INFO - 2025-09-18 04:49:21 --> Output Class Initialized
INFO - 2025-09-18 04:49:21 --> Security Class Initialized
DEBUG - 2025-09-18 04:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:49:21 --> CSRF cookie sent
INFO - 2025-09-18 04:49:21 --> Input Class Initialized
INFO - 2025-09-18 04:49:21 --> Language Class Initialized
INFO - 2025-09-18 04:49:21 --> Loader Class Initialized
INFO - 2025-09-18 04:49:21 --> Helper loaded: url_helper
INFO - 2025-09-18 04:49:21 --> Helper loaded: text_helper
INFO - 2025-09-18 04:49:21 --> Helper loaded: string_helper
INFO - 2025-09-18 04:49:21 --> Helper loaded: form_helper
INFO - 2025-09-18 04:49:21 --> Helper loaded: download_helper
INFO - 2025-09-18 04:49:21 --> Helper loaded: security_helper
INFO - 2025-09-18 04:49:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:49:21 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:49:21 --> Form Validation Class Initialized
INFO - 2025-09-18 04:49:21 --> Model "User_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:49:21 --> Controller Class Initialized
INFO - 2025-09-18 09:49:21 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Video_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:49:21 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:49:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:49:21 --> Pagination Class Initialized
INFO - 2025-09-18 09:49:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:49:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:49:21 --> Model "Log_model" initialized
INFO - 2025-09-18 09:49:21 --> Final output sent to browser
DEBUG - 2025-09-18 09:49:21 --> Total execution time: 0.0969
INFO - 2025-09-18 04:49:36 --> Config Class Initialized
INFO - 2025-09-18 04:49:36 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:49:36 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:49:36 --> Utf8 Class Initialized
INFO - 2025-09-18 04:49:36 --> URI Class Initialized
DEBUG - 2025-09-18 04:49:36 --> No URI present. Default controller set.
INFO - 2025-09-18 04:49:36 --> Router Class Initialized
INFO - 2025-09-18 04:49:36 --> Output Class Initialized
INFO - 2025-09-18 04:49:36 --> Security Class Initialized
DEBUG - 2025-09-18 04:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:49:36 --> CSRF cookie sent
INFO - 2025-09-18 04:49:36 --> Input Class Initialized
INFO - 2025-09-18 04:49:36 --> Language Class Initialized
INFO - 2025-09-18 04:49:36 --> Loader Class Initialized
INFO - 2025-09-18 04:49:36 --> Helper loaded: url_helper
INFO - 2025-09-18 04:49:36 --> Helper loaded: text_helper
INFO - 2025-09-18 04:49:36 --> Helper loaded: string_helper
INFO - 2025-09-18 04:49:36 --> Helper loaded: form_helper
INFO - 2025-09-18 04:49:36 --> Helper loaded: download_helper
INFO - 2025-09-18 04:49:36 --> Helper loaded: security_helper
INFO - 2025-09-18 04:49:36 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:49:36 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:49:36 --> Form Validation Class Initialized
INFO - 2025-09-18 04:49:36 --> Model "User_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:49:36 --> Controller Class Initialized
INFO - 2025-09-18 09:49:36 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Video_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:49:36 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:49:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:49:36 --> Pagination Class Initialized
INFO - 2025-09-18 09:49:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:49:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:49:36 --> Model "Log_model" initialized
INFO - 2025-09-18 09:49:36 --> Final output sent to browser
DEBUG - 2025-09-18 09:49:36 --> Total execution time: 0.1286
INFO - 2025-09-18 04:49:39 --> Config Class Initialized
INFO - 2025-09-18 04:49:39 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:49:39 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:49:39 --> Utf8 Class Initialized
INFO - 2025-09-18 04:49:39 --> URI Class Initialized
DEBUG - 2025-09-18 04:49:39 --> No URI present. Default controller set.
INFO - 2025-09-18 04:49:39 --> Router Class Initialized
INFO - 2025-09-18 04:49:39 --> Output Class Initialized
INFO - 2025-09-18 04:49:39 --> Security Class Initialized
DEBUG - 2025-09-18 04:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:49:39 --> CSRF cookie sent
INFO - 2025-09-18 04:49:39 --> Input Class Initialized
INFO - 2025-09-18 04:49:39 --> Language Class Initialized
INFO - 2025-09-18 04:49:39 --> Loader Class Initialized
INFO - 2025-09-18 04:49:39 --> Helper loaded: url_helper
INFO - 2025-09-18 04:49:39 --> Helper loaded: text_helper
INFO - 2025-09-18 04:49:39 --> Helper loaded: string_helper
INFO - 2025-09-18 04:49:39 --> Helper loaded: form_helper
INFO - 2025-09-18 04:49:39 --> Helper loaded: download_helper
INFO - 2025-09-18 04:49:39 --> Helper loaded: security_helper
INFO - 2025-09-18 04:49:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:49:39 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:49:39 --> Form Validation Class Initialized
INFO - 2025-09-18 04:49:39 --> Model "User_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:49:39 --> Controller Class Initialized
INFO - 2025-09-18 09:49:39 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Video_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:49:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:49:39 --> Pagination Class Initialized
INFO - 2025-09-18 09:49:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:49:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:49:39 --> Model "Log_model" initialized
INFO - 2025-09-18 09:49:39 --> Final output sent to browser
DEBUG - 2025-09-18 09:49:39 --> Total execution time: 0.1587
INFO - 2025-09-18 04:50:18 --> Config Class Initialized
INFO - 2025-09-18 04:50:18 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:50:18 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:50:18 --> Utf8 Class Initialized
INFO - 2025-09-18 04:50:18 --> URI Class Initialized
DEBUG - 2025-09-18 04:50:18 --> No URI present. Default controller set.
INFO - 2025-09-18 04:50:18 --> Router Class Initialized
INFO - 2025-09-18 04:50:18 --> Output Class Initialized
INFO - 2025-09-18 04:50:18 --> Security Class Initialized
DEBUG - 2025-09-18 04:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:50:18 --> CSRF cookie sent
INFO - 2025-09-18 04:50:18 --> Input Class Initialized
INFO - 2025-09-18 04:50:18 --> Language Class Initialized
INFO - 2025-09-18 04:50:18 --> Loader Class Initialized
INFO - 2025-09-18 04:50:18 --> Helper loaded: url_helper
INFO - 2025-09-18 04:50:18 --> Helper loaded: text_helper
INFO - 2025-09-18 04:50:18 --> Helper loaded: string_helper
INFO - 2025-09-18 04:50:18 --> Helper loaded: form_helper
INFO - 2025-09-18 04:50:18 --> Helper loaded: download_helper
INFO - 2025-09-18 04:50:18 --> Helper loaded: security_helper
INFO - 2025-09-18 04:50:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:50:18 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:50:18 --> Form Validation Class Initialized
INFO - 2025-09-18 04:50:18 --> Model "User_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:50:18 --> Controller Class Initialized
INFO - 2025-09-18 09:50:18 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Video_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:50:18 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:50:18 --> Pagination Class Initialized
INFO - 2025-09-18 09:50:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:50:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:50:18 --> Model "Log_model" initialized
INFO - 2025-09-18 09:50:18 --> Final output sent to browser
DEBUG - 2025-09-18 09:50:18 --> Total execution time: 0.1155
INFO - 2025-09-18 04:53:03 --> Config Class Initialized
INFO - 2025-09-18 04:53:03 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:53:03 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:53:03 --> Utf8 Class Initialized
INFO - 2025-09-18 04:53:03 --> URI Class Initialized
DEBUG - 2025-09-18 04:53:03 --> No URI present. Default controller set.
INFO - 2025-09-18 04:53:03 --> Router Class Initialized
INFO - 2025-09-18 04:53:03 --> Output Class Initialized
INFO - 2025-09-18 04:53:03 --> Security Class Initialized
DEBUG - 2025-09-18 04:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:53:03 --> CSRF cookie sent
INFO - 2025-09-18 04:53:03 --> Input Class Initialized
INFO - 2025-09-18 04:53:03 --> Language Class Initialized
INFO - 2025-09-18 04:53:03 --> Loader Class Initialized
INFO - 2025-09-18 04:53:03 --> Helper loaded: url_helper
INFO - 2025-09-18 04:53:03 --> Helper loaded: text_helper
INFO - 2025-09-18 04:53:03 --> Helper loaded: string_helper
INFO - 2025-09-18 04:53:03 --> Helper loaded: form_helper
INFO - 2025-09-18 04:53:03 --> Helper loaded: download_helper
INFO - 2025-09-18 04:53:03 --> Helper loaded: security_helper
INFO - 2025-09-18 04:53:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:53:03 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:53:03 --> Form Validation Class Initialized
INFO - 2025-09-18 04:53:03 --> Model "User_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:53:03 --> Controller Class Initialized
INFO - 2025-09-18 09:53:03 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Video_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:53:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:53:03 --> Pagination Class Initialized
INFO - 2025-09-18 09:53:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:53:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:53:03 --> Model "Log_model" initialized
INFO - 2025-09-18 09:53:03 --> Final output sent to browser
DEBUG - 2025-09-18 09:53:03 --> Total execution time: 0.1244
INFO - 2025-09-18 04:54:42 --> Config Class Initialized
INFO - 2025-09-18 04:54:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:54:42 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:54:42 --> Utf8 Class Initialized
INFO - 2025-09-18 04:54:42 --> URI Class Initialized
DEBUG - 2025-09-18 04:54:42 --> No URI present. Default controller set.
INFO - 2025-09-18 04:54:42 --> Router Class Initialized
INFO - 2025-09-18 04:54:42 --> Output Class Initialized
INFO - 2025-09-18 04:54:42 --> Security Class Initialized
DEBUG - 2025-09-18 04:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:54:42 --> CSRF cookie sent
INFO - 2025-09-18 04:54:42 --> Input Class Initialized
INFO - 2025-09-18 04:54:42 --> Language Class Initialized
INFO - 2025-09-18 04:54:42 --> Loader Class Initialized
INFO - 2025-09-18 04:54:42 --> Helper loaded: url_helper
INFO - 2025-09-18 04:54:42 --> Helper loaded: text_helper
INFO - 2025-09-18 04:54:42 --> Helper loaded: string_helper
INFO - 2025-09-18 04:54:42 --> Helper loaded: form_helper
INFO - 2025-09-18 04:54:42 --> Helper loaded: download_helper
INFO - 2025-09-18 04:54:42 --> Helper loaded: security_helper
INFO - 2025-09-18 04:54:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:54:42 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:54:42 --> Form Validation Class Initialized
INFO - 2025-09-18 04:54:42 --> Model "User_model" initialized
INFO - 2025-09-18 09:54:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:54:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:54:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:54:42 --> Controller Class Initialized
INFO - 2025-09-18 09:54:42 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:54:42 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:54:42 --> Model "Video_model" initialized
INFO - 2025-09-18 09:54:42 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:54:42 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:54:43 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:54:43 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:54:43 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:54:43 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:54:43 --> Pagination Class Initialized
INFO - 2025-09-18 09:54:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:54:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:54:43 --> Model "Log_model" initialized
INFO - 2025-09-18 09:54:43 --> Final output sent to browser
DEBUG - 2025-09-18 09:54:43 --> Total execution time: 0.1263
INFO - 2025-09-18 04:55:11 --> Config Class Initialized
INFO - 2025-09-18 04:55:11 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:55:11 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:55:11 --> Utf8 Class Initialized
INFO - 2025-09-18 04:55:11 --> URI Class Initialized
DEBUG - 2025-09-18 04:55:11 --> No URI present. Default controller set.
INFO - 2025-09-18 04:55:11 --> Router Class Initialized
INFO - 2025-09-18 04:55:11 --> Output Class Initialized
INFO - 2025-09-18 04:55:11 --> Security Class Initialized
DEBUG - 2025-09-18 04:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:55:11 --> CSRF cookie sent
INFO - 2025-09-18 04:55:11 --> Input Class Initialized
INFO - 2025-09-18 04:55:11 --> Language Class Initialized
INFO - 2025-09-18 04:55:11 --> Loader Class Initialized
INFO - 2025-09-18 04:55:11 --> Helper loaded: url_helper
INFO - 2025-09-18 04:55:11 --> Helper loaded: text_helper
INFO - 2025-09-18 04:55:11 --> Helper loaded: string_helper
INFO - 2025-09-18 04:55:11 --> Helper loaded: form_helper
INFO - 2025-09-18 04:55:11 --> Helper loaded: download_helper
INFO - 2025-09-18 04:55:11 --> Helper loaded: security_helper
INFO - 2025-09-18 04:55:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:55:11 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:55:11 --> Form Validation Class Initialized
INFO - 2025-09-18 04:55:11 --> Model "User_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:55:11 --> Controller Class Initialized
INFO - 2025-09-18 09:55:11 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Video_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:55:11 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:55:11 --> Pagination Class Initialized
INFO - 2025-09-18 09:55:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:55:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:55:11 --> Model "Log_model" initialized
INFO - 2025-09-18 09:55:11 --> Final output sent to browser
DEBUG - 2025-09-18 09:55:11 --> Total execution time: 0.1405
INFO - 2025-09-18 04:56:38 --> Config Class Initialized
INFO - 2025-09-18 04:56:38 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:56:38 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:56:38 --> Utf8 Class Initialized
INFO - 2025-09-18 04:56:38 --> URI Class Initialized
DEBUG - 2025-09-18 04:56:38 --> No URI present. Default controller set.
INFO - 2025-09-18 04:56:38 --> Router Class Initialized
INFO - 2025-09-18 04:56:38 --> Output Class Initialized
INFO - 2025-09-18 04:56:38 --> Security Class Initialized
DEBUG - 2025-09-18 04:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:56:38 --> CSRF cookie sent
INFO - 2025-09-18 04:56:38 --> Input Class Initialized
INFO - 2025-09-18 04:56:38 --> Language Class Initialized
INFO - 2025-09-18 04:56:38 --> Loader Class Initialized
INFO - 2025-09-18 04:56:38 --> Helper loaded: url_helper
INFO - 2025-09-18 04:56:38 --> Helper loaded: text_helper
INFO - 2025-09-18 04:56:38 --> Helper loaded: string_helper
INFO - 2025-09-18 04:56:38 --> Helper loaded: form_helper
INFO - 2025-09-18 04:56:38 --> Helper loaded: download_helper
INFO - 2025-09-18 04:56:38 --> Helper loaded: security_helper
INFO - 2025-09-18 04:56:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:56:38 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:56:38 --> Form Validation Class Initialized
INFO - 2025-09-18 04:56:38 --> Model "User_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:56:38 --> Controller Class Initialized
INFO - 2025-09-18 09:56:38 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Video_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:56:38 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:56:38 --> Pagination Class Initialized
INFO - 2025-09-18 09:56:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:56:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:56:38 --> Model "Log_model" initialized
INFO - 2025-09-18 09:56:38 --> Final output sent to browser
DEBUG - 2025-09-18 09:56:38 --> Total execution time: 0.1058
INFO - 2025-09-18 04:56:59 --> Config Class Initialized
INFO - 2025-09-18 04:56:59 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:56:59 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:56:59 --> Utf8 Class Initialized
INFO - 2025-09-18 04:56:59 --> URI Class Initialized
DEBUG - 2025-09-18 04:56:59 --> No URI present. Default controller set.
INFO - 2025-09-18 04:56:59 --> Router Class Initialized
INFO - 2025-09-18 04:56:59 --> Output Class Initialized
INFO - 2025-09-18 04:56:59 --> Security Class Initialized
DEBUG - 2025-09-18 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:56:59 --> CSRF cookie sent
INFO - 2025-09-18 04:56:59 --> Input Class Initialized
INFO - 2025-09-18 04:56:59 --> Language Class Initialized
INFO - 2025-09-18 04:56:59 --> Loader Class Initialized
INFO - 2025-09-18 04:56:59 --> Helper loaded: url_helper
INFO - 2025-09-18 04:56:59 --> Helper loaded: text_helper
INFO - 2025-09-18 04:56:59 --> Helper loaded: string_helper
INFO - 2025-09-18 04:56:59 --> Helper loaded: form_helper
INFO - 2025-09-18 04:56:59 --> Helper loaded: download_helper
INFO - 2025-09-18 04:56:59 --> Helper loaded: security_helper
INFO - 2025-09-18 04:56:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:56:59 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:56:59 --> Form Validation Class Initialized
INFO - 2025-09-18 04:56:59 --> Model "User_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:56:59 --> Controller Class Initialized
INFO - 2025-09-18 09:56:59 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Video_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:56:59 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:57:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:57:00 --> Pagination Class Initialized
INFO - 2025-09-18 09:57:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:57:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:57:00 --> Model "Log_model" initialized
INFO - 2025-09-18 09:57:00 --> Final output sent to browser
DEBUG - 2025-09-18 09:57:00 --> Total execution time: 0.1046
INFO - 2025-09-18 04:57:09 --> Config Class Initialized
INFO - 2025-09-18 04:57:09 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:57:09 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:57:09 --> Utf8 Class Initialized
INFO - 2025-09-18 04:57:09 --> URI Class Initialized
DEBUG - 2025-09-18 04:57:09 --> No URI present. Default controller set.
INFO - 2025-09-18 04:57:09 --> Router Class Initialized
INFO - 2025-09-18 04:57:09 --> Output Class Initialized
INFO - 2025-09-18 04:57:09 --> Security Class Initialized
DEBUG - 2025-09-18 04:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:57:09 --> CSRF cookie sent
INFO - 2025-09-18 04:57:09 --> Input Class Initialized
INFO - 2025-09-18 04:57:09 --> Language Class Initialized
INFO - 2025-09-18 04:57:09 --> Loader Class Initialized
INFO - 2025-09-18 04:57:09 --> Helper loaded: url_helper
INFO - 2025-09-18 04:57:09 --> Helper loaded: text_helper
INFO - 2025-09-18 04:57:09 --> Helper loaded: string_helper
INFO - 2025-09-18 04:57:09 --> Helper loaded: form_helper
INFO - 2025-09-18 04:57:09 --> Helper loaded: download_helper
INFO - 2025-09-18 04:57:09 --> Helper loaded: security_helper
INFO - 2025-09-18 04:57:09 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:57:09 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:57:09 --> Form Validation Class Initialized
INFO - 2025-09-18 04:57:09 --> Model "User_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:57:09 --> Controller Class Initialized
INFO - 2025-09-18 09:57:09 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Video_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:57:09 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:57:09 --> Pagination Class Initialized
INFO - 2025-09-18 09:57:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:57:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:57:09 --> Model "Log_model" initialized
INFO - 2025-09-18 09:57:09 --> Final output sent to browser
DEBUG - 2025-09-18 09:57:09 --> Total execution time: 0.1345
INFO - 2025-09-18 04:59:25 --> Config Class Initialized
INFO - 2025-09-18 04:59:25 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:59:25 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:59:25 --> Utf8 Class Initialized
INFO - 2025-09-18 04:59:25 --> URI Class Initialized
DEBUG - 2025-09-18 04:59:25 --> No URI present. Default controller set.
INFO - 2025-09-18 04:59:25 --> Router Class Initialized
INFO - 2025-09-18 04:59:25 --> Output Class Initialized
INFO - 2025-09-18 04:59:25 --> Security Class Initialized
DEBUG - 2025-09-18 04:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:59:25 --> CSRF cookie sent
INFO - 2025-09-18 04:59:25 --> Input Class Initialized
INFO - 2025-09-18 04:59:25 --> Language Class Initialized
INFO - 2025-09-18 04:59:25 --> Loader Class Initialized
INFO - 2025-09-18 04:59:25 --> Helper loaded: url_helper
INFO - 2025-09-18 04:59:25 --> Helper loaded: text_helper
INFO - 2025-09-18 04:59:25 --> Helper loaded: string_helper
INFO - 2025-09-18 04:59:25 --> Helper loaded: form_helper
INFO - 2025-09-18 04:59:25 --> Helper loaded: download_helper
INFO - 2025-09-18 04:59:25 --> Helper loaded: security_helper
INFO - 2025-09-18 04:59:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:59:25 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:59:25 --> Form Validation Class Initialized
INFO - 2025-09-18 04:59:25 --> Model "User_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:59:25 --> Controller Class Initialized
INFO - 2025-09-18 09:59:25 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Video_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:59:25 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:59:25 --> Pagination Class Initialized
INFO - 2025-09-18 09:59:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:59:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:59:25 --> Model "Log_model" initialized
INFO - 2025-09-18 09:59:25 --> Final output sent to browser
DEBUG - 2025-09-18 09:59:25 --> Total execution time: 0.1063
INFO - 2025-09-18 04:59:54 --> Config Class Initialized
INFO - 2025-09-18 04:59:54 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:59:54 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:59:54 --> Utf8 Class Initialized
INFO - 2025-09-18 04:59:54 --> URI Class Initialized
DEBUG - 2025-09-18 04:59:54 --> No URI present. Default controller set.
INFO - 2025-09-18 04:59:54 --> Router Class Initialized
INFO - 2025-09-18 04:59:54 --> Output Class Initialized
INFO - 2025-09-18 04:59:54 --> Security Class Initialized
DEBUG - 2025-09-18 04:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:59:54 --> CSRF cookie sent
INFO - 2025-09-18 04:59:54 --> Input Class Initialized
INFO - 2025-09-18 04:59:54 --> Language Class Initialized
INFO - 2025-09-18 04:59:54 --> Loader Class Initialized
INFO - 2025-09-18 04:59:54 --> Helper loaded: url_helper
INFO - 2025-09-18 04:59:54 --> Helper loaded: text_helper
INFO - 2025-09-18 04:59:54 --> Helper loaded: string_helper
INFO - 2025-09-18 04:59:54 --> Helper loaded: form_helper
INFO - 2025-09-18 04:59:54 --> Helper loaded: download_helper
INFO - 2025-09-18 04:59:54 --> Helper loaded: security_helper
INFO - 2025-09-18 04:59:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:59:54 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:59:54 --> Form Validation Class Initialized
INFO - 2025-09-18 04:59:54 --> Model "User_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:59:54 --> Controller Class Initialized
INFO - 2025-09-18 09:59:54 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Video_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:59:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:59:54 --> Pagination Class Initialized
INFO - 2025-09-18 09:59:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:59:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:59:54 --> Model "Log_model" initialized
INFO - 2025-09-18 09:59:54 --> Final output sent to browser
DEBUG - 2025-09-18 09:59:54 --> Total execution time: 0.0904
INFO - 2025-09-18 04:59:57 --> Config Class Initialized
INFO - 2025-09-18 04:59:57 --> Hooks Class Initialized
DEBUG - 2025-09-18 04:59:57 --> UTF-8 Support Enabled
INFO - 2025-09-18 04:59:57 --> Utf8 Class Initialized
INFO - 2025-09-18 04:59:57 --> URI Class Initialized
DEBUG - 2025-09-18 04:59:57 --> No URI present. Default controller set.
INFO - 2025-09-18 04:59:57 --> Router Class Initialized
INFO - 2025-09-18 04:59:57 --> Output Class Initialized
INFO - 2025-09-18 04:59:57 --> Security Class Initialized
DEBUG - 2025-09-18 04:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 04:59:57 --> CSRF cookie sent
INFO - 2025-09-18 04:59:57 --> Input Class Initialized
INFO - 2025-09-18 04:59:57 --> Language Class Initialized
INFO - 2025-09-18 04:59:57 --> Loader Class Initialized
INFO - 2025-09-18 04:59:57 --> Helper loaded: url_helper
INFO - 2025-09-18 04:59:57 --> Helper loaded: text_helper
INFO - 2025-09-18 04:59:57 --> Helper loaded: string_helper
INFO - 2025-09-18 04:59:57 --> Helper loaded: form_helper
INFO - 2025-09-18 04:59:57 --> Helper loaded: download_helper
INFO - 2025-09-18 04:59:57 --> Helper loaded: security_helper
INFO - 2025-09-18 04:59:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 04:59:57 --> Database Driver Class Initialized
DEBUG - 2025-09-18 04:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 04:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 04:59:57 --> Form Validation Class Initialized
INFO - 2025-09-18 04:59:57 --> Model "User_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Nav_model" initialized
INFO - 2025-09-18 09:59:57 --> Controller Class Initialized
INFO - 2025-09-18 09:59:57 --> Model "Berita_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Galeri_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Video_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Agenda_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Tautan_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Mitra_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Prodi_model" initialized
INFO - 2025-09-18 09:59:57 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 09:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 09:59:57 --> Pagination Class Initialized
INFO - 2025-09-18 09:59:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 09:59:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 09:59:57 --> Model "Log_model" initialized
INFO - 2025-09-18 09:59:57 --> Final output sent to browser
DEBUG - 2025-09-18 09:59:57 --> Total execution time: 0.1128
INFO - 2025-09-18 05:00:17 --> Config Class Initialized
INFO - 2025-09-18 05:00:17 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:00:17 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:00:17 --> Utf8 Class Initialized
INFO - 2025-09-18 05:00:17 --> URI Class Initialized
INFO - 2025-09-18 05:00:17 --> Router Class Initialized
INFO - 2025-09-18 05:00:17 --> Output Class Initialized
INFO - 2025-09-18 05:00:17 --> Security Class Initialized
DEBUG - 2025-09-18 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:00:17 --> CSRF cookie sent
INFO - 2025-09-18 05:00:17 --> Input Class Initialized
INFO - 2025-09-18 05:00:17 --> Language Class Initialized
INFO - 2025-09-18 05:00:17 --> Loader Class Initialized
INFO - 2025-09-18 05:00:17 --> Helper loaded: url_helper
INFO - 2025-09-18 05:00:17 --> Helper loaded: text_helper
INFO - 2025-09-18 05:00:17 --> Helper loaded: string_helper
INFO - 2025-09-18 05:00:17 --> Helper loaded: form_helper
INFO - 2025-09-18 05:00:17 --> Helper loaded: download_helper
INFO - 2025-09-18 05:00:17 --> Helper loaded: security_helper
INFO - 2025-09-18 05:00:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:00:17 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:00:17 --> Form Validation Class Initialized
INFO - 2025-09-18 05:00:17 --> Model "User_model" initialized
INFO - 2025-09-18 10:00:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:00:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:00:17 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:00:17 --> Controller Class Initialized
INFO - 2025-09-18 10:00:17 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:00:17 --> Model "Staff_model" initialized
INFO - 2025-09-18 10:00:17 --> Model "Dasbor_model" initialized
INFO - 2025-09-18 10:00:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-09-18 10:00:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 10:00:17 --> Model "Log_model" initialized
INFO - 2025-09-18 10:00:17 --> Final output sent to browser
DEBUG - 2025-09-18 10:00:17 --> Total execution time: 0.4634
INFO - 2025-09-18 05:00:39 --> Config Class Initialized
INFO - 2025-09-18 05:00:39 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:00:39 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:00:39 --> Utf8 Class Initialized
INFO - 2025-09-18 05:00:39 --> URI Class Initialized
DEBUG - 2025-09-18 05:00:39 --> No URI present. Default controller set.
INFO - 2025-09-18 05:00:39 --> Router Class Initialized
INFO - 2025-09-18 05:00:39 --> Output Class Initialized
INFO - 2025-09-18 05:00:39 --> Security Class Initialized
DEBUG - 2025-09-18 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:00:39 --> CSRF cookie sent
INFO - 2025-09-18 05:00:39 --> Input Class Initialized
INFO - 2025-09-18 05:00:39 --> Language Class Initialized
INFO - 2025-09-18 05:00:39 --> Loader Class Initialized
INFO - 2025-09-18 05:00:39 --> Helper loaded: url_helper
INFO - 2025-09-18 05:00:39 --> Helper loaded: text_helper
INFO - 2025-09-18 05:00:39 --> Helper loaded: string_helper
INFO - 2025-09-18 05:00:39 --> Helper loaded: form_helper
INFO - 2025-09-18 05:00:39 --> Helper loaded: download_helper
INFO - 2025-09-18 05:00:39 --> Helper loaded: security_helper
INFO - 2025-09-18 05:00:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:00:39 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:00:39 --> Form Validation Class Initialized
INFO - 2025-09-18 05:00:39 --> Model "User_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:00:39 --> Controller Class Initialized
INFO - 2025-09-18 10:00:39 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Video_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:00:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:00:39 --> Pagination Class Initialized
INFO - 2025-09-18 10:00:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:00:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:00:39 --> Model "Log_model" initialized
INFO - 2025-09-18 10:00:39 --> Final output sent to browser
DEBUG - 2025-09-18 10:00:39 --> Total execution time: 0.1151
INFO - 2025-09-18 05:01:46 --> Config Class Initialized
INFO - 2025-09-18 05:01:46 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:01:46 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:01:46 --> Utf8 Class Initialized
INFO - 2025-09-18 05:01:46 --> URI Class Initialized
DEBUG - 2025-09-18 05:01:46 --> No URI present. Default controller set.
INFO - 2025-09-18 05:01:46 --> Router Class Initialized
INFO - 2025-09-18 05:01:46 --> Output Class Initialized
INFO - 2025-09-18 05:01:46 --> Security Class Initialized
DEBUG - 2025-09-18 05:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:01:46 --> CSRF cookie sent
INFO - 2025-09-18 05:01:46 --> Input Class Initialized
INFO - 2025-09-18 05:01:46 --> Language Class Initialized
INFO - 2025-09-18 05:01:46 --> Loader Class Initialized
INFO - 2025-09-18 05:01:46 --> Helper loaded: url_helper
INFO - 2025-09-18 05:01:46 --> Helper loaded: text_helper
INFO - 2025-09-18 05:01:46 --> Helper loaded: string_helper
INFO - 2025-09-18 05:01:46 --> Helper loaded: form_helper
INFO - 2025-09-18 05:01:46 --> Helper loaded: download_helper
INFO - 2025-09-18 05:01:46 --> Helper loaded: security_helper
INFO - 2025-09-18 05:01:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:01:46 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:01:46 --> Form Validation Class Initialized
INFO - 2025-09-18 05:01:46 --> Model "User_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:01:46 --> Controller Class Initialized
INFO - 2025-09-18 10:01:46 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Video_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:01:46 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:01:46 --> Pagination Class Initialized
INFO - 2025-09-18 10:01:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:01:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:01:46 --> Model "Log_model" initialized
INFO - 2025-09-18 10:01:46 --> Final output sent to browser
DEBUG - 2025-09-18 10:01:46 --> Total execution time: 0.1292
INFO - 2025-09-18 05:02:59 --> Config Class Initialized
INFO - 2025-09-18 05:02:59 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:02:59 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:02:59 --> Utf8 Class Initialized
INFO - 2025-09-18 05:02:59 --> URI Class Initialized
INFO - 2025-09-18 05:02:59 --> Router Class Initialized
INFO - 2025-09-18 05:02:59 --> Output Class Initialized
INFO - 2025-09-18 05:02:59 --> Security Class Initialized
DEBUG - 2025-09-18 05:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:02:59 --> CSRF cookie sent
INFO - 2025-09-18 05:02:59 --> Input Class Initialized
INFO - 2025-09-18 05:02:59 --> Language Class Initialized
INFO - 2025-09-18 05:02:59 --> Loader Class Initialized
INFO - 2025-09-18 05:02:59 --> Helper loaded: url_helper
INFO - 2025-09-18 05:02:59 --> Helper loaded: text_helper
INFO - 2025-09-18 05:02:59 --> Helper loaded: string_helper
INFO - 2025-09-18 05:02:59 --> Helper loaded: form_helper
INFO - 2025-09-18 05:02:59 --> Helper loaded: download_helper
INFO - 2025-09-18 05:02:59 --> Helper loaded: security_helper
INFO - 2025-09-18 05:02:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:02:59 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:02:59 --> Form Validation Class Initialized
INFO - 2025-09-18 05:02:59 --> Model "User_model" initialized
INFO - 2025-09-18 10:02:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:02:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:02:59 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:02:59 --> Controller Class Initialized
INFO - 2025-09-18 10:02:59 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:02:59 --> Model "Kategori_model" initialized
INFO - 2025-09-18 10:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:02:59 --> Pagination Class Initialized
INFO - 2025-09-18 10:02:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list_kategori.php
INFO - 2025-09-18 10:02:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:02:59 --> Model "Log_model" initialized
INFO - 2025-09-18 10:02:59 --> Final output sent to browser
DEBUG - 2025-09-18 10:02:59 --> Total execution time: 0.1146
INFO - 2025-09-18 05:03:07 --> Config Class Initialized
INFO - 2025-09-18 05:03:07 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:03:07 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:03:07 --> Utf8 Class Initialized
INFO - 2025-09-18 05:03:07 --> URI Class Initialized
DEBUG - 2025-09-18 05:03:07 --> No URI present. Default controller set.
INFO - 2025-09-18 05:03:07 --> Router Class Initialized
INFO - 2025-09-18 05:03:07 --> Output Class Initialized
INFO - 2025-09-18 05:03:07 --> Security Class Initialized
DEBUG - 2025-09-18 05:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:03:07 --> CSRF cookie sent
INFO - 2025-09-18 05:03:07 --> Input Class Initialized
INFO - 2025-09-18 05:03:07 --> Language Class Initialized
INFO - 2025-09-18 05:03:07 --> Loader Class Initialized
INFO - 2025-09-18 05:03:07 --> Helper loaded: url_helper
INFO - 2025-09-18 05:03:07 --> Helper loaded: text_helper
INFO - 2025-09-18 05:03:07 --> Helper loaded: string_helper
INFO - 2025-09-18 05:03:07 --> Helper loaded: form_helper
INFO - 2025-09-18 05:03:07 --> Helper loaded: download_helper
INFO - 2025-09-18 05:03:07 --> Helper loaded: security_helper
INFO - 2025-09-18 05:03:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:03:07 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:03:07 --> Form Validation Class Initialized
INFO - 2025-09-18 05:03:07 --> Model "User_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:03:07 --> Controller Class Initialized
INFO - 2025-09-18 10:03:07 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Video_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:03:07 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:03:07 --> Pagination Class Initialized
INFO - 2025-09-18 10:03:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:03:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:03:07 --> Model "Log_model" initialized
INFO - 2025-09-18 10:03:07 --> Final output sent to browser
DEBUG - 2025-09-18 10:03:07 --> Total execution time: 0.1035
INFO - 2025-09-18 05:03:22 --> Config Class Initialized
INFO - 2025-09-18 05:03:22 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:03:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:03:22 --> Utf8 Class Initialized
INFO - 2025-09-18 05:03:22 --> URI Class Initialized
DEBUG - 2025-09-18 05:03:22 --> No URI present. Default controller set.
INFO - 2025-09-18 05:03:22 --> Router Class Initialized
INFO - 2025-09-18 05:03:22 --> Output Class Initialized
INFO - 2025-09-18 05:03:22 --> Security Class Initialized
DEBUG - 2025-09-18 05:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:03:22 --> CSRF cookie sent
INFO - 2025-09-18 05:03:22 --> Input Class Initialized
INFO - 2025-09-18 05:03:22 --> Language Class Initialized
INFO - 2025-09-18 05:03:22 --> Loader Class Initialized
INFO - 2025-09-18 05:03:22 --> Helper loaded: url_helper
INFO - 2025-09-18 05:03:22 --> Helper loaded: text_helper
INFO - 2025-09-18 05:03:22 --> Helper loaded: string_helper
INFO - 2025-09-18 05:03:22 --> Helper loaded: form_helper
INFO - 2025-09-18 05:03:22 --> Helper loaded: download_helper
INFO - 2025-09-18 05:03:22 --> Helper loaded: security_helper
INFO - 2025-09-18 05:03:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:03:22 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:03:22 --> Form Validation Class Initialized
INFO - 2025-09-18 05:03:22 --> Model "User_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:03:22 --> Controller Class Initialized
INFO - 2025-09-18 10:03:22 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Video_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:03:22 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:03:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:03:22 --> Pagination Class Initialized
INFO - 2025-09-18 10:03:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:03:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:03:22 --> Model "Log_model" initialized
INFO - 2025-09-18 10:03:22 --> Final output sent to browser
DEBUG - 2025-09-18 10:03:22 --> Total execution time: 0.1222
INFO - 2025-09-18 05:03:54 --> Config Class Initialized
INFO - 2025-09-18 05:03:54 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:03:54 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:03:54 --> Utf8 Class Initialized
INFO - 2025-09-18 05:03:54 --> URI Class Initialized
DEBUG - 2025-09-18 05:03:54 --> No URI present. Default controller set.
INFO - 2025-09-18 05:03:54 --> Router Class Initialized
INFO - 2025-09-18 05:03:54 --> Output Class Initialized
INFO - 2025-09-18 05:03:54 --> Security Class Initialized
DEBUG - 2025-09-18 05:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:03:54 --> CSRF cookie sent
INFO - 2025-09-18 05:03:54 --> Input Class Initialized
INFO - 2025-09-18 05:03:54 --> Language Class Initialized
INFO - 2025-09-18 05:03:54 --> Loader Class Initialized
INFO - 2025-09-18 05:03:54 --> Helper loaded: url_helper
INFO - 2025-09-18 05:03:54 --> Helper loaded: text_helper
INFO - 2025-09-18 05:03:54 --> Helper loaded: string_helper
INFO - 2025-09-18 05:03:54 --> Helper loaded: form_helper
INFO - 2025-09-18 05:03:54 --> Helper loaded: download_helper
INFO - 2025-09-18 05:03:54 --> Helper loaded: security_helper
INFO - 2025-09-18 05:03:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:03:54 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:03:54 --> Form Validation Class Initialized
INFO - 2025-09-18 05:03:54 --> Model "User_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:03:54 --> Controller Class Initialized
INFO - 2025-09-18 10:03:54 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Video_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:03:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:03:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:03:54 --> Pagination Class Initialized
INFO - 2025-09-18 10:03:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:03:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:03:54 --> Model "Log_model" initialized
INFO - 2025-09-18 10:03:54 --> Final output sent to browser
DEBUG - 2025-09-18 10:03:54 --> Total execution time: 0.1071
INFO - 2025-09-18 05:04:10 --> Config Class Initialized
INFO - 2025-09-18 05:04:10 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:04:10 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:04:10 --> Utf8 Class Initialized
INFO - 2025-09-18 05:04:10 --> URI Class Initialized
DEBUG - 2025-09-18 05:04:10 --> No URI present. Default controller set.
INFO - 2025-09-18 05:04:10 --> Router Class Initialized
INFO - 2025-09-18 05:04:10 --> Output Class Initialized
INFO - 2025-09-18 05:04:10 --> Security Class Initialized
DEBUG - 2025-09-18 05:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:04:10 --> CSRF cookie sent
INFO - 2025-09-18 05:04:10 --> Input Class Initialized
INFO - 2025-09-18 05:04:10 --> Language Class Initialized
INFO - 2025-09-18 05:04:10 --> Loader Class Initialized
INFO - 2025-09-18 05:04:10 --> Helper loaded: url_helper
INFO - 2025-09-18 05:04:10 --> Helper loaded: text_helper
INFO - 2025-09-18 05:04:10 --> Helper loaded: string_helper
INFO - 2025-09-18 05:04:10 --> Helper loaded: form_helper
INFO - 2025-09-18 05:04:10 --> Helper loaded: download_helper
INFO - 2025-09-18 05:04:10 --> Helper loaded: security_helper
INFO - 2025-09-18 05:04:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:04:10 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:04:10 --> Form Validation Class Initialized
INFO - 2025-09-18 05:04:10 --> Model "User_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:04:10 --> Controller Class Initialized
INFO - 2025-09-18 10:04:10 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Video_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:04:10 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:04:10 --> Pagination Class Initialized
INFO - 2025-09-18 10:04:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:04:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:04:10 --> Model "Log_model" initialized
INFO - 2025-09-18 10:04:10 --> Final output sent to browser
DEBUG - 2025-09-18 10:04:10 --> Total execution time: 0.0781
INFO - 2025-09-18 05:04:34 --> Config Class Initialized
INFO - 2025-09-18 05:04:34 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:04:34 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:04:34 --> Utf8 Class Initialized
INFO - 2025-09-18 05:04:34 --> URI Class Initialized
DEBUG - 2025-09-18 05:04:34 --> No URI present. Default controller set.
INFO - 2025-09-18 05:04:34 --> Router Class Initialized
INFO - 2025-09-18 05:04:34 --> Output Class Initialized
INFO - 2025-09-18 05:04:34 --> Security Class Initialized
DEBUG - 2025-09-18 05:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:04:34 --> CSRF cookie sent
INFO - 2025-09-18 05:04:34 --> Input Class Initialized
INFO - 2025-09-18 05:04:34 --> Language Class Initialized
INFO - 2025-09-18 05:04:34 --> Loader Class Initialized
INFO - 2025-09-18 05:04:34 --> Helper loaded: url_helper
INFO - 2025-09-18 05:04:34 --> Helper loaded: text_helper
INFO - 2025-09-18 05:04:34 --> Helper loaded: string_helper
INFO - 2025-09-18 05:04:34 --> Helper loaded: form_helper
INFO - 2025-09-18 05:04:34 --> Helper loaded: download_helper
INFO - 2025-09-18 05:04:34 --> Helper loaded: security_helper
INFO - 2025-09-18 05:04:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:04:34 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:04:34 --> Form Validation Class Initialized
INFO - 2025-09-18 05:04:34 --> Model "User_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:04:34 --> Controller Class Initialized
INFO - 2025-09-18 10:04:34 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Video_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:04:34 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:04:34 --> Pagination Class Initialized
INFO - 2025-09-18 10:04:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:04:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:04:34 --> Model "Log_model" initialized
INFO - 2025-09-18 10:04:34 --> Final output sent to browser
DEBUG - 2025-09-18 10:04:34 --> Total execution time: 0.0928
INFO - 2025-09-18 05:04:44 --> Config Class Initialized
INFO - 2025-09-18 05:04:44 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:04:44 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:04:44 --> Utf8 Class Initialized
INFO - 2025-09-18 05:04:44 --> URI Class Initialized
DEBUG - 2025-09-18 05:04:44 --> No URI present. Default controller set.
INFO - 2025-09-18 05:04:44 --> Router Class Initialized
INFO - 2025-09-18 05:04:44 --> Output Class Initialized
INFO - 2025-09-18 05:04:44 --> Security Class Initialized
DEBUG - 2025-09-18 05:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:04:44 --> CSRF cookie sent
INFO - 2025-09-18 05:04:44 --> Input Class Initialized
INFO - 2025-09-18 05:04:44 --> Language Class Initialized
INFO - 2025-09-18 05:04:44 --> Loader Class Initialized
INFO - 2025-09-18 05:04:44 --> Helper loaded: url_helper
INFO - 2025-09-18 05:04:44 --> Helper loaded: text_helper
INFO - 2025-09-18 05:04:44 --> Helper loaded: string_helper
INFO - 2025-09-18 05:04:44 --> Helper loaded: form_helper
INFO - 2025-09-18 05:04:44 --> Helper loaded: download_helper
INFO - 2025-09-18 05:04:44 --> Helper loaded: security_helper
INFO - 2025-09-18 05:04:44 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:04:44 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:04:44 --> Form Validation Class Initialized
INFO - 2025-09-18 05:04:44 --> Model "User_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:04:44 --> Controller Class Initialized
INFO - 2025-09-18 10:04:44 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Video_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:04:44 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:04:44 --> Pagination Class Initialized
INFO - 2025-09-18 10:04:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:04:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:04:44 --> Model "Log_model" initialized
INFO - 2025-09-18 10:04:44 --> Final output sent to browser
DEBUG - 2025-09-18 10:04:44 --> Total execution time: 0.1069
INFO - 2025-09-18 05:04:52 --> Config Class Initialized
INFO - 2025-09-18 05:04:52 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:04:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:04:52 --> Utf8 Class Initialized
INFO - 2025-09-18 05:04:52 --> URI Class Initialized
DEBUG - 2025-09-18 05:04:52 --> No URI present. Default controller set.
INFO - 2025-09-18 05:04:52 --> Router Class Initialized
INFO - 2025-09-18 05:04:52 --> Output Class Initialized
INFO - 2025-09-18 05:04:52 --> Security Class Initialized
DEBUG - 2025-09-18 05:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:04:52 --> CSRF cookie sent
INFO - 2025-09-18 05:04:52 --> Input Class Initialized
INFO - 2025-09-18 05:04:52 --> Language Class Initialized
INFO - 2025-09-18 05:04:52 --> Loader Class Initialized
INFO - 2025-09-18 05:04:52 --> Helper loaded: url_helper
INFO - 2025-09-18 05:04:52 --> Helper loaded: text_helper
INFO - 2025-09-18 05:04:52 --> Helper loaded: string_helper
INFO - 2025-09-18 05:04:52 --> Helper loaded: form_helper
INFO - 2025-09-18 05:04:52 --> Helper loaded: download_helper
INFO - 2025-09-18 05:04:52 --> Helper loaded: security_helper
INFO - 2025-09-18 05:04:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:04:52 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:04:52 --> Form Validation Class Initialized
INFO - 2025-09-18 05:04:52 --> Model "User_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:04:52 --> Controller Class Initialized
INFO - 2025-09-18 10:04:52 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Video_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:04:52 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:04:52 --> Pagination Class Initialized
INFO - 2025-09-18 10:04:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:04:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:04:52 --> Model "Log_model" initialized
INFO - 2025-09-18 10:04:52 --> Final output sent to browser
DEBUG - 2025-09-18 10:04:52 --> Total execution time: 0.1267
INFO - 2025-09-18 05:05:03 --> Config Class Initialized
INFO - 2025-09-18 05:05:03 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:05:03 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:05:03 --> Utf8 Class Initialized
INFO - 2025-09-18 05:05:03 --> URI Class Initialized
DEBUG - 2025-09-18 05:05:03 --> No URI present. Default controller set.
INFO - 2025-09-18 05:05:03 --> Router Class Initialized
INFO - 2025-09-18 05:05:03 --> Output Class Initialized
INFO - 2025-09-18 05:05:03 --> Security Class Initialized
DEBUG - 2025-09-18 05:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:05:03 --> CSRF cookie sent
INFO - 2025-09-18 05:05:03 --> Input Class Initialized
INFO - 2025-09-18 05:05:03 --> Language Class Initialized
INFO - 2025-09-18 05:05:03 --> Loader Class Initialized
INFO - 2025-09-18 05:05:03 --> Helper loaded: url_helper
INFO - 2025-09-18 05:05:03 --> Helper loaded: text_helper
INFO - 2025-09-18 05:05:03 --> Helper loaded: string_helper
INFO - 2025-09-18 05:05:03 --> Helper loaded: form_helper
INFO - 2025-09-18 05:05:03 --> Helper loaded: download_helper
INFO - 2025-09-18 05:05:03 --> Helper loaded: security_helper
INFO - 2025-09-18 05:05:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:05:03 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:05:03 --> Form Validation Class Initialized
INFO - 2025-09-18 05:05:03 --> Model "User_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:05:03 --> Controller Class Initialized
INFO - 2025-09-18 10:05:03 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Video_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:05:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:05:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:05:03 --> Pagination Class Initialized
INFO - 2025-09-18 10:05:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:05:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:05:03 --> Model "Log_model" initialized
INFO - 2025-09-18 10:05:03 --> Final output sent to browser
DEBUG - 2025-09-18 10:05:03 --> Total execution time: 0.0841
INFO - 2025-09-18 05:05:16 --> Config Class Initialized
INFO - 2025-09-18 05:05:16 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:05:16 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:05:16 --> Utf8 Class Initialized
INFO - 2025-09-18 05:05:16 --> URI Class Initialized
DEBUG - 2025-09-18 05:05:16 --> No URI present. Default controller set.
INFO - 2025-09-18 05:05:16 --> Router Class Initialized
INFO - 2025-09-18 05:05:16 --> Output Class Initialized
INFO - 2025-09-18 05:05:16 --> Security Class Initialized
DEBUG - 2025-09-18 05:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:05:16 --> CSRF cookie sent
INFO - 2025-09-18 05:05:16 --> Input Class Initialized
INFO - 2025-09-18 05:05:16 --> Language Class Initialized
INFO - 2025-09-18 05:05:16 --> Loader Class Initialized
INFO - 2025-09-18 05:05:16 --> Helper loaded: url_helper
INFO - 2025-09-18 05:05:16 --> Helper loaded: text_helper
INFO - 2025-09-18 05:05:16 --> Helper loaded: string_helper
INFO - 2025-09-18 05:05:16 --> Helper loaded: form_helper
INFO - 2025-09-18 05:05:16 --> Helper loaded: download_helper
INFO - 2025-09-18 05:05:16 --> Helper loaded: security_helper
INFO - 2025-09-18 05:05:16 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:05:16 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:05:16 --> Form Validation Class Initialized
INFO - 2025-09-18 05:05:16 --> Model "User_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:05:16 --> Controller Class Initialized
INFO - 2025-09-18 10:05:16 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Video_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:05:16 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:05:16 --> Pagination Class Initialized
INFO - 2025-09-18 10:05:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:05:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:05:16 --> Model "Log_model" initialized
INFO - 2025-09-18 10:05:16 --> Final output sent to browser
DEBUG - 2025-09-18 10:05:16 --> Total execution time: 0.0878
INFO - 2025-09-18 05:05:17 --> Config Class Initialized
INFO - 2025-09-18 05:05:17 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:05:17 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:05:17 --> Utf8 Class Initialized
INFO - 2025-09-18 05:05:17 --> URI Class Initialized
DEBUG - 2025-09-18 05:05:17 --> No URI present. Default controller set.
INFO - 2025-09-18 05:05:17 --> Router Class Initialized
INFO - 2025-09-18 05:05:17 --> Output Class Initialized
INFO - 2025-09-18 05:05:17 --> Security Class Initialized
DEBUG - 2025-09-18 05:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:05:17 --> CSRF cookie sent
INFO - 2025-09-18 05:05:17 --> Input Class Initialized
INFO - 2025-09-18 05:05:17 --> Language Class Initialized
INFO - 2025-09-18 05:05:17 --> Loader Class Initialized
INFO - 2025-09-18 05:05:17 --> Helper loaded: url_helper
INFO - 2025-09-18 05:05:17 --> Helper loaded: text_helper
INFO - 2025-09-18 05:05:17 --> Helper loaded: string_helper
INFO - 2025-09-18 05:05:17 --> Helper loaded: form_helper
INFO - 2025-09-18 05:05:17 --> Helper loaded: download_helper
INFO - 2025-09-18 05:05:17 --> Helper loaded: security_helper
INFO - 2025-09-18 05:05:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:05:17 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:05:17 --> Form Validation Class Initialized
INFO - 2025-09-18 05:05:17 --> Model "User_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:05:17 --> Controller Class Initialized
INFO - 2025-09-18 10:05:17 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Video_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:05:17 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:05:17 --> Pagination Class Initialized
INFO - 2025-09-18 10:05:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:05:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:05:17 --> Model "Log_model" initialized
INFO - 2025-09-18 10:05:17 --> Final output sent to browser
DEBUG - 2025-09-18 10:05:17 --> Total execution time: 0.1094
INFO - 2025-09-18 05:06:00 --> Config Class Initialized
INFO - 2025-09-18 05:06:00 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:06:00 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:06:00 --> Utf8 Class Initialized
INFO - 2025-09-18 05:06:00 --> URI Class Initialized
DEBUG - 2025-09-18 05:06:00 --> No URI present. Default controller set.
INFO - 2025-09-18 05:06:00 --> Router Class Initialized
INFO - 2025-09-18 05:06:00 --> Output Class Initialized
INFO - 2025-09-18 05:06:00 --> Security Class Initialized
DEBUG - 2025-09-18 05:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:06:00 --> CSRF cookie sent
INFO - 2025-09-18 05:06:00 --> Input Class Initialized
INFO - 2025-09-18 05:06:00 --> Language Class Initialized
INFO - 2025-09-18 05:06:00 --> Loader Class Initialized
INFO - 2025-09-18 05:06:00 --> Helper loaded: url_helper
INFO - 2025-09-18 05:06:00 --> Helper loaded: text_helper
INFO - 2025-09-18 05:06:00 --> Helper loaded: string_helper
INFO - 2025-09-18 05:06:00 --> Helper loaded: form_helper
INFO - 2025-09-18 05:06:00 --> Helper loaded: download_helper
INFO - 2025-09-18 05:06:00 --> Helper loaded: security_helper
INFO - 2025-09-18 05:06:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:06:00 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:06:00 --> Form Validation Class Initialized
INFO - 2025-09-18 05:06:00 --> Model "User_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:06:00 --> Controller Class Initialized
INFO - 2025-09-18 10:06:00 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Video_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:06:00 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:06:00 --> Pagination Class Initialized
INFO - 2025-09-18 10:06:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:06:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:06:00 --> Model "Log_model" initialized
INFO - 2025-09-18 10:06:00 --> Final output sent to browser
DEBUG - 2025-09-18 10:06:00 --> Total execution time: 0.1127
INFO - 2025-09-18 05:06:13 --> Config Class Initialized
INFO - 2025-09-18 05:06:13 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:06:13 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:06:13 --> Utf8 Class Initialized
INFO - 2025-09-18 05:06:13 --> URI Class Initialized
DEBUG - 2025-09-18 05:06:13 --> No URI present. Default controller set.
INFO - 2025-09-18 05:06:13 --> Router Class Initialized
INFO - 2025-09-18 05:06:13 --> Output Class Initialized
INFO - 2025-09-18 05:06:13 --> Security Class Initialized
DEBUG - 2025-09-18 05:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:06:13 --> CSRF cookie sent
INFO - 2025-09-18 05:06:13 --> Input Class Initialized
INFO - 2025-09-18 05:06:13 --> Language Class Initialized
INFO - 2025-09-18 05:06:13 --> Loader Class Initialized
INFO - 2025-09-18 05:06:13 --> Helper loaded: url_helper
INFO - 2025-09-18 05:06:13 --> Helper loaded: text_helper
INFO - 2025-09-18 05:06:13 --> Helper loaded: string_helper
INFO - 2025-09-18 05:06:13 --> Helper loaded: form_helper
INFO - 2025-09-18 05:06:13 --> Helper loaded: download_helper
INFO - 2025-09-18 05:06:13 --> Helper loaded: security_helper
INFO - 2025-09-18 05:06:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:06:13 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:06:13 --> Form Validation Class Initialized
INFO - 2025-09-18 05:06:13 --> Model "User_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:06:13 --> Controller Class Initialized
INFO - 2025-09-18 10:06:13 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Video_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:06:13 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:06:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:06:13 --> Pagination Class Initialized
INFO - 2025-09-18 10:06:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:06:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:06:13 --> Model "Log_model" initialized
INFO - 2025-09-18 10:06:13 --> Final output sent to browser
DEBUG - 2025-09-18 10:06:13 --> Total execution time: 0.1187
INFO - 2025-09-18 05:06:14 --> Config Class Initialized
INFO - 2025-09-18 05:06:14 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:06:14 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:06:14 --> Utf8 Class Initialized
INFO - 2025-09-18 05:06:14 --> URI Class Initialized
DEBUG - 2025-09-18 05:06:14 --> No URI present. Default controller set.
INFO - 2025-09-18 05:06:14 --> Router Class Initialized
INFO - 2025-09-18 05:06:14 --> Output Class Initialized
INFO - 2025-09-18 05:06:14 --> Security Class Initialized
DEBUG - 2025-09-18 05:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:06:14 --> CSRF cookie sent
INFO - 2025-09-18 05:06:14 --> Input Class Initialized
INFO - 2025-09-18 05:06:14 --> Language Class Initialized
INFO - 2025-09-18 05:06:14 --> Loader Class Initialized
INFO - 2025-09-18 05:06:14 --> Helper loaded: url_helper
INFO - 2025-09-18 05:06:14 --> Helper loaded: text_helper
INFO - 2025-09-18 05:06:14 --> Helper loaded: string_helper
INFO - 2025-09-18 05:06:14 --> Helper loaded: form_helper
INFO - 2025-09-18 05:06:14 --> Helper loaded: download_helper
INFO - 2025-09-18 05:06:14 --> Helper loaded: security_helper
INFO - 2025-09-18 05:06:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:06:14 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:06:14 --> Form Validation Class Initialized
INFO - 2025-09-18 05:06:14 --> Model "User_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:06:14 --> Controller Class Initialized
INFO - 2025-09-18 10:06:14 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Video_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:06:14 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:06:15 --> Pagination Class Initialized
INFO - 2025-09-18 10:06:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:06:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:06:15 --> Model "Log_model" initialized
INFO - 2025-09-18 10:06:15 --> Final output sent to browser
DEBUG - 2025-09-18 10:06:15 --> Total execution time: 0.1166
INFO - 2025-09-18 05:07:39 --> Config Class Initialized
INFO - 2025-09-18 05:07:39 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:07:39 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:07:39 --> Utf8 Class Initialized
INFO - 2025-09-18 05:07:39 --> URI Class Initialized
DEBUG - 2025-09-18 05:07:39 --> No URI present. Default controller set.
INFO - 2025-09-18 05:07:39 --> Router Class Initialized
INFO - 2025-09-18 05:07:39 --> Output Class Initialized
INFO - 2025-09-18 05:07:39 --> Security Class Initialized
DEBUG - 2025-09-18 05:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:07:39 --> CSRF cookie sent
INFO - 2025-09-18 05:07:39 --> Input Class Initialized
INFO - 2025-09-18 05:07:39 --> Language Class Initialized
INFO - 2025-09-18 05:07:39 --> Loader Class Initialized
INFO - 2025-09-18 05:07:39 --> Helper loaded: url_helper
INFO - 2025-09-18 05:07:39 --> Helper loaded: text_helper
INFO - 2025-09-18 05:07:39 --> Helper loaded: string_helper
INFO - 2025-09-18 05:07:39 --> Helper loaded: form_helper
INFO - 2025-09-18 05:07:39 --> Helper loaded: download_helper
INFO - 2025-09-18 05:07:39 --> Helper loaded: security_helper
INFO - 2025-09-18 05:07:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:07:39 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:07:39 --> Form Validation Class Initialized
INFO - 2025-09-18 05:07:39 --> Model "User_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:07:39 --> Controller Class Initialized
INFO - 2025-09-18 10:07:39 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Video_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:07:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:07:39 --> Pagination Class Initialized
INFO - 2025-09-18 10:07:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:07:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:07:39 --> Model "Log_model" initialized
INFO - 2025-09-18 10:07:39 --> Final output sent to browser
DEBUG - 2025-09-18 10:07:39 --> Total execution time: 0.0830
INFO - 2025-09-18 05:07:52 --> Config Class Initialized
INFO - 2025-09-18 05:07:52 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:07:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:07:52 --> Utf8 Class Initialized
INFO - 2025-09-18 05:07:52 --> URI Class Initialized
DEBUG - 2025-09-18 05:07:52 --> No URI present. Default controller set.
INFO - 2025-09-18 05:07:52 --> Router Class Initialized
INFO - 2025-09-18 05:07:52 --> Output Class Initialized
INFO - 2025-09-18 05:07:52 --> Security Class Initialized
DEBUG - 2025-09-18 05:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:07:52 --> CSRF cookie sent
INFO - 2025-09-18 05:07:52 --> Input Class Initialized
INFO - 2025-09-18 05:07:52 --> Language Class Initialized
INFO - 2025-09-18 05:07:52 --> Loader Class Initialized
INFO - 2025-09-18 05:07:52 --> Helper loaded: url_helper
INFO - 2025-09-18 05:07:52 --> Helper loaded: text_helper
INFO - 2025-09-18 05:07:52 --> Helper loaded: string_helper
INFO - 2025-09-18 05:07:52 --> Helper loaded: form_helper
INFO - 2025-09-18 05:07:52 --> Helper loaded: download_helper
INFO - 2025-09-18 05:07:52 --> Helper loaded: security_helper
INFO - 2025-09-18 05:07:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:07:52 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:07:52 --> Form Validation Class Initialized
INFO - 2025-09-18 05:07:52 --> Model "User_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:07:52 --> Controller Class Initialized
INFO - 2025-09-18 10:07:52 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Video_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:07:52 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:07:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:07:52 --> Pagination Class Initialized
INFO - 2025-09-18 10:07:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:07:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:07:52 --> Model "Log_model" initialized
INFO - 2025-09-18 10:07:52 --> Final output sent to browser
DEBUG - 2025-09-18 10:07:52 --> Total execution time: 0.1120
INFO - 2025-09-18 05:07:53 --> Config Class Initialized
INFO - 2025-09-18 05:07:53 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:07:53 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:07:53 --> Utf8 Class Initialized
INFO - 2025-09-18 05:07:53 --> URI Class Initialized
DEBUG - 2025-09-18 05:07:53 --> No URI present. Default controller set.
INFO - 2025-09-18 05:07:53 --> Router Class Initialized
INFO - 2025-09-18 05:07:53 --> Output Class Initialized
INFO - 2025-09-18 05:07:53 --> Security Class Initialized
DEBUG - 2025-09-18 05:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:07:53 --> CSRF cookie sent
INFO - 2025-09-18 05:07:53 --> Input Class Initialized
INFO - 2025-09-18 05:07:53 --> Language Class Initialized
INFO - 2025-09-18 05:07:53 --> Loader Class Initialized
INFO - 2025-09-18 05:07:53 --> Helper loaded: url_helper
INFO - 2025-09-18 05:07:53 --> Helper loaded: text_helper
INFO - 2025-09-18 05:07:53 --> Helper loaded: string_helper
INFO - 2025-09-18 05:07:53 --> Helper loaded: form_helper
INFO - 2025-09-18 05:07:53 --> Helper loaded: download_helper
INFO - 2025-09-18 05:07:53 --> Helper loaded: security_helper
INFO - 2025-09-18 05:07:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:07:53 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:07:53 --> Form Validation Class Initialized
INFO - 2025-09-18 05:07:53 --> Model "User_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:07:53 --> Controller Class Initialized
INFO - 2025-09-18 10:07:53 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Video_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:07:53 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:07:53 --> Pagination Class Initialized
INFO - 2025-09-18 10:07:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:07:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:07:53 --> Model "Log_model" initialized
INFO - 2025-09-18 10:07:53 --> Final output sent to browser
DEBUG - 2025-09-18 10:07:53 --> Total execution time: 0.1073
INFO - 2025-09-18 05:08:05 --> Config Class Initialized
INFO - 2025-09-18 05:08:05 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:08:05 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:08:05 --> Utf8 Class Initialized
INFO - 2025-09-18 05:08:05 --> URI Class Initialized
DEBUG - 2025-09-18 05:08:05 --> No URI present. Default controller set.
INFO - 2025-09-18 05:08:05 --> Router Class Initialized
INFO - 2025-09-18 05:08:05 --> Output Class Initialized
INFO - 2025-09-18 05:08:05 --> Security Class Initialized
DEBUG - 2025-09-18 05:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:08:05 --> CSRF cookie sent
INFO - 2025-09-18 05:08:05 --> Input Class Initialized
INFO - 2025-09-18 05:08:05 --> Language Class Initialized
INFO - 2025-09-18 05:08:05 --> Loader Class Initialized
INFO - 2025-09-18 05:08:05 --> Helper loaded: url_helper
INFO - 2025-09-18 05:08:05 --> Helper loaded: text_helper
INFO - 2025-09-18 05:08:05 --> Helper loaded: string_helper
INFO - 2025-09-18 05:08:05 --> Helper loaded: form_helper
INFO - 2025-09-18 05:08:05 --> Helper loaded: download_helper
INFO - 2025-09-18 05:08:05 --> Helper loaded: security_helper
INFO - 2025-09-18 05:08:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:08:05 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:08:05 --> Form Validation Class Initialized
INFO - 2025-09-18 05:08:05 --> Model "User_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:08:05 --> Controller Class Initialized
INFO - 2025-09-18 10:08:05 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Video_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:08:05 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:08:05 --> Pagination Class Initialized
INFO - 2025-09-18 10:08:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:08:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:08:05 --> Model "Log_model" initialized
INFO - 2025-09-18 10:08:05 --> Final output sent to browser
DEBUG - 2025-09-18 10:08:05 --> Total execution time: 0.0882
INFO - 2025-09-18 05:08:23 --> Config Class Initialized
INFO - 2025-09-18 05:08:23 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:08:23 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:08:23 --> Utf8 Class Initialized
INFO - 2025-09-18 05:08:23 --> URI Class Initialized
INFO - 2025-09-18 05:08:23 --> Router Class Initialized
INFO - 2025-09-18 05:08:23 --> Output Class Initialized
INFO - 2025-09-18 05:08:23 --> Security Class Initialized
DEBUG - 2025-09-18 05:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:08:23 --> CSRF cookie sent
INFO - 2025-09-18 05:08:23 --> Input Class Initialized
INFO - 2025-09-18 05:08:23 --> Language Class Initialized
INFO - 2025-09-18 05:08:23 --> Loader Class Initialized
INFO - 2025-09-18 05:08:23 --> Helper loaded: url_helper
INFO - 2025-09-18 05:08:23 --> Helper loaded: text_helper
INFO - 2025-09-18 05:08:23 --> Helper loaded: string_helper
INFO - 2025-09-18 05:08:23 --> Helper loaded: form_helper
INFO - 2025-09-18 05:08:23 --> Helper loaded: download_helper
INFO - 2025-09-18 05:08:23 --> Helper loaded: security_helper
INFO - 2025-09-18 05:08:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:08:23 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:08:23 --> Form Validation Class Initialized
INFO - 2025-09-18 05:08:23 --> Model "User_model" initialized
INFO - 2025-09-18 10:08:23 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:08:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:08:23 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:08:23 --> Controller Class Initialized
INFO - 2025-09-18 10:08:23 --> Model "Pages_model" initialized
INFO - 2025-09-18 10:08:23 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:08:23 --> Model "Download_model" initialized
INFO - 2025-09-18 10:08:23 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 10:08:23 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 10:08:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-09-18 10:08:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:08:23 --> Model "Log_model" initialized
INFO - 2025-09-18 10:08:23 --> Final output sent to browser
DEBUG - 2025-09-18 10:08:23 --> Total execution time: 0.0632
INFO - 2025-09-18 05:09:47 --> Config Class Initialized
INFO - 2025-09-18 05:09:47 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:09:47 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:09:47 --> Utf8 Class Initialized
INFO - 2025-09-18 05:09:48 --> URI Class Initialized
DEBUG - 2025-09-18 05:09:48 --> No URI present. Default controller set.
INFO - 2025-09-18 05:09:48 --> Router Class Initialized
INFO - 2025-09-18 05:09:48 --> Output Class Initialized
INFO - 2025-09-18 05:09:48 --> Security Class Initialized
DEBUG - 2025-09-18 05:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:09:48 --> CSRF cookie sent
INFO - 2025-09-18 05:09:48 --> Input Class Initialized
INFO - 2025-09-18 05:09:48 --> Language Class Initialized
INFO - 2025-09-18 05:09:48 --> Loader Class Initialized
INFO - 2025-09-18 05:09:48 --> Helper loaded: url_helper
INFO - 2025-09-18 05:09:48 --> Helper loaded: text_helper
INFO - 2025-09-18 05:09:48 --> Helper loaded: string_helper
INFO - 2025-09-18 05:09:48 --> Helper loaded: form_helper
INFO - 2025-09-18 05:09:48 --> Helper loaded: download_helper
INFO - 2025-09-18 05:09:48 --> Helper loaded: security_helper
INFO - 2025-09-18 05:09:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:09:48 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:09:48 --> Form Validation Class Initialized
INFO - 2025-09-18 05:09:48 --> Model "User_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:09:48 --> Controller Class Initialized
INFO - 2025-09-18 10:09:48 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Video_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:09:48 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:09:48 --> Pagination Class Initialized
INFO - 2025-09-18 10:09:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:09:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:09:48 --> Model "Log_model" initialized
INFO - 2025-09-18 10:09:48 --> Final output sent to browser
DEBUG - 2025-09-18 10:09:48 --> Total execution time: 0.1056
INFO - 2025-09-18 05:09:57 --> Config Class Initialized
INFO - 2025-09-18 05:09:57 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:09:57 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:09:57 --> Utf8 Class Initialized
INFO - 2025-09-18 05:09:57 --> URI Class Initialized
DEBUG - 2025-09-18 05:09:57 --> No URI present. Default controller set.
INFO - 2025-09-18 05:09:57 --> Router Class Initialized
INFO - 2025-09-18 05:09:57 --> Output Class Initialized
INFO - 2025-09-18 05:09:57 --> Security Class Initialized
DEBUG - 2025-09-18 05:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:09:57 --> CSRF cookie sent
INFO - 2025-09-18 05:09:57 --> Input Class Initialized
INFO - 2025-09-18 05:09:57 --> Language Class Initialized
INFO - 2025-09-18 05:09:57 --> Loader Class Initialized
INFO - 2025-09-18 05:09:57 --> Helper loaded: url_helper
INFO - 2025-09-18 05:09:57 --> Helper loaded: text_helper
INFO - 2025-09-18 05:09:57 --> Helper loaded: string_helper
INFO - 2025-09-18 05:09:57 --> Helper loaded: form_helper
INFO - 2025-09-18 05:09:57 --> Helper loaded: download_helper
INFO - 2025-09-18 05:09:57 --> Helper loaded: security_helper
INFO - 2025-09-18 05:09:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:09:57 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:09:57 --> Form Validation Class Initialized
INFO - 2025-09-18 05:09:57 --> Model "User_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:09:57 --> Controller Class Initialized
INFO - 2025-09-18 10:09:57 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Video_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:09:57 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:09:57 --> Pagination Class Initialized
INFO - 2025-09-18 10:09:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:09:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:09:57 --> Model "Log_model" initialized
INFO - 2025-09-18 10:09:57 --> Final output sent to browser
DEBUG - 2025-09-18 10:09:57 --> Total execution time: 0.0979
INFO - 2025-09-18 05:10:29 --> Config Class Initialized
INFO - 2025-09-18 05:10:29 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:10:29 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:10:29 --> Utf8 Class Initialized
INFO - 2025-09-18 05:10:29 --> URI Class Initialized
DEBUG - 2025-09-18 05:10:29 --> No URI present. Default controller set.
INFO - 2025-09-18 05:10:29 --> Router Class Initialized
INFO - 2025-09-18 05:10:29 --> Output Class Initialized
INFO - 2025-09-18 05:10:29 --> Security Class Initialized
DEBUG - 2025-09-18 05:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:10:29 --> CSRF cookie sent
INFO - 2025-09-18 05:10:29 --> Input Class Initialized
INFO - 2025-09-18 05:10:29 --> Language Class Initialized
INFO - 2025-09-18 05:10:29 --> Loader Class Initialized
INFO - 2025-09-18 05:10:29 --> Helper loaded: url_helper
INFO - 2025-09-18 05:10:29 --> Helper loaded: text_helper
INFO - 2025-09-18 05:10:29 --> Helper loaded: string_helper
INFO - 2025-09-18 05:10:29 --> Helper loaded: form_helper
INFO - 2025-09-18 05:10:29 --> Helper loaded: download_helper
INFO - 2025-09-18 05:10:29 --> Helper loaded: security_helper
INFO - 2025-09-18 05:10:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:10:29 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:10:29 --> Form Validation Class Initialized
INFO - 2025-09-18 05:10:29 --> Model "User_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:10:29 --> Controller Class Initialized
INFO - 2025-09-18 10:10:29 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Video_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:10:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:10:29 --> Pagination Class Initialized
INFO - 2025-09-18 10:10:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:10:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:10:29 --> Model "Log_model" initialized
INFO - 2025-09-18 10:10:29 --> Final output sent to browser
DEBUG - 2025-09-18 10:10:29 --> Total execution time: 0.0902
INFO - 2025-09-18 05:12:02 --> Config Class Initialized
INFO - 2025-09-18 05:12:02 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:12:02 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:12:02 --> Utf8 Class Initialized
INFO - 2025-09-18 05:12:02 --> URI Class Initialized
DEBUG - 2025-09-18 05:12:02 --> No URI present. Default controller set.
INFO - 2025-09-18 05:12:02 --> Router Class Initialized
INFO - 2025-09-18 05:12:02 --> Output Class Initialized
INFO - 2025-09-18 05:12:02 --> Security Class Initialized
DEBUG - 2025-09-18 05:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:12:02 --> CSRF cookie sent
INFO - 2025-09-18 05:12:02 --> Input Class Initialized
INFO - 2025-09-18 05:12:02 --> Language Class Initialized
INFO - 2025-09-18 05:12:02 --> Loader Class Initialized
INFO - 2025-09-18 05:12:02 --> Helper loaded: url_helper
INFO - 2025-09-18 05:12:02 --> Helper loaded: text_helper
INFO - 2025-09-18 05:12:02 --> Helper loaded: string_helper
INFO - 2025-09-18 05:12:02 --> Helper loaded: form_helper
INFO - 2025-09-18 05:12:02 --> Helper loaded: download_helper
INFO - 2025-09-18 05:12:02 --> Helper loaded: security_helper
INFO - 2025-09-18 05:12:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:12:02 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:12:02 --> Form Validation Class Initialized
INFO - 2025-09-18 05:12:02 --> Model "User_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:12:02 --> Controller Class Initialized
INFO - 2025-09-18 10:12:02 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Video_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:12:02 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:12:02 --> Pagination Class Initialized
INFO - 2025-09-18 10:12:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:12:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:12:02 --> Model "Log_model" initialized
INFO - 2025-09-18 10:12:02 --> Final output sent to browser
DEBUG - 2025-09-18 10:12:02 --> Total execution time: 0.1236
INFO - 2025-09-18 05:12:08 --> Config Class Initialized
INFO - 2025-09-18 05:12:08 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:12:08 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:12:08 --> Utf8 Class Initialized
INFO - 2025-09-18 05:12:08 --> URI Class Initialized
DEBUG - 2025-09-18 05:12:08 --> No URI present. Default controller set.
INFO - 2025-09-18 05:12:08 --> Router Class Initialized
INFO - 2025-09-18 05:12:08 --> Output Class Initialized
INFO - 2025-09-18 05:12:08 --> Security Class Initialized
DEBUG - 2025-09-18 05:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:12:08 --> CSRF cookie sent
INFO - 2025-09-18 05:12:08 --> Input Class Initialized
INFO - 2025-09-18 05:12:08 --> Language Class Initialized
INFO - 2025-09-18 05:12:08 --> Loader Class Initialized
INFO - 2025-09-18 05:12:08 --> Helper loaded: url_helper
INFO - 2025-09-18 05:12:08 --> Helper loaded: text_helper
INFO - 2025-09-18 05:12:08 --> Helper loaded: string_helper
INFO - 2025-09-18 05:12:08 --> Helper loaded: form_helper
INFO - 2025-09-18 05:12:08 --> Helper loaded: download_helper
INFO - 2025-09-18 05:12:08 --> Helper loaded: security_helper
INFO - 2025-09-18 05:12:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:12:08 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:12:08 --> Form Validation Class Initialized
INFO - 2025-09-18 05:12:08 --> Model "User_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:12:08 --> Controller Class Initialized
INFO - 2025-09-18 10:12:08 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Video_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:12:08 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:12:08 --> Pagination Class Initialized
INFO - 2025-09-18 10:12:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:12:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:12:08 --> Model "Log_model" initialized
INFO - 2025-09-18 10:12:08 --> Final output sent to browser
DEBUG - 2025-09-18 10:12:08 --> Total execution time: 0.0817
INFO - 2025-09-18 05:12:13 --> Config Class Initialized
INFO - 2025-09-18 05:12:13 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:12:13 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:12:13 --> Utf8 Class Initialized
INFO - 2025-09-18 05:12:13 --> URI Class Initialized
DEBUG - 2025-09-18 05:12:13 --> No URI present. Default controller set.
INFO - 2025-09-18 05:12:13 --> Router Class Initialized
INFO - 2025-09-18 05:12:13 --> Output Class Initialized
INFO - 2025-09-18 05:12:13 --> Security Class Initialized
DEBUG - 2025-09-18 05:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:12:13 --> CSRF cookie sent
INFO - 2025-09-18 05:12:13 --> Input Class Initialized
INFO - 2025-09-18 05:12:13 --> Language Class Initialized
INFO - 2025-09-18 05:12:13 --> Loader Class Initialized
INFO - 2025-09-18 05:12:13 --> Helper loaded: url_helper
INFO - 2025-09-18 05:12:13 --> Helper loaded: text_helper
INFO - 2025-09-18 05:12:13 --> Helper loaded: string_helper
INFO - 2025-09-18 05:12:13 --> Helper loaded: form_helper
INFO - 2025-09-18 05:12:13 --> Helper loaded: download_helper
INFO - 2025-09-18 05:12:13 --> Helper loaded: security_helper
INFO - 2025-09-18 05:12:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:12:13 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:12:13 --> Form Validation Class Initialized
INFO - 2025-09-18 05:12:13 --> Model "User_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:12:13 --> Controller Class Initialized
INFO - 2025-09-18 10:12:13 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Video_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:12:13 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:12:13 --> Pagination Class Initialized
INFO - 2025-09-18 10:12:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:12:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:12:13 --> Model "Log_model" initialized
INFO - 2025-09-18 10:12:13 --> Final output sent to browser
DEBUG - 2025-09-18 10:12:13 --> Total execution time: 0.1383
INFO - 2025-09-18 05:12:21 --> Config Class Initialized
INFO - 2025-09-18 05:12:21 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:12:21 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:12:21 --> Utf8 Class Initialized
INFO - 2025-09-18 05:12:21 --> URI Class Initialized
DEBUG - 2025-09-18 05:12:21 --> No URI present. Default controller set.
INFO - 2025-09-18 05:12:21 --> Router Class Initialized
INFO - 2025-09-18 05:12:21 --> Output Class Initialized
INFO - 2025-09-18 05:12:21 --> Security Class Initialized
DEBUG - 2025-09-18 05:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:12:21 --> CSRF cookie sent
INFO - 2025-09-18 05:12:21 --> Input Class Initialized
INFO - 2025-09-18 05:12:21 --> Language Class Initialized
INFO - 2025-09-18 05:12:21 --> Loader Class Initialized
INFO - 2025-09-18 05:12:21 --> Helper loaded: url_helper
INFO - 2025-09-18 05:12:21 --> Helper loaded: text_helper
INFO - 2025-09-18 05:12:21 --> Helper loaded: string_helper
INFO - 2025-09-18 05:12:21 --> Helper loaded: form_helper
INFO - 2025-09-18 05:12:21 --> Helper loaded: download_helper
INFO - 2025-09-18 05:12:21 --> Helper loaded: security_helper
INFO - 2025-09-18 05:12:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:12:21 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:12:21 --> Form Validation Class Initialized
INFO - 2025-09-18 05:12:21 --> Model "User_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:12:21 --> Controller Class Initialized
INFO - 2025-09-18 10:12:21 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Video_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:12:21 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:12:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:12:21 --> Pagination Class Initialized
INFO - 2025-09-18 10:12:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:12:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:12:21 --> Model "Log_model" initialized
INFO - 2025-09-18 10:12:21 --> Final output sent to browser
DEBUG - 2025-09-18 10:12:21 --> Total execution time: 0.1242
INFO - 2025-09-18 05:12:29 --> Config Class Initialized
INFO - 2025-09-18 05:12:29 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:12:29 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:12:29 --> Utf8 Class Initialized
INFO - 2025-09-18 05:12:29 --> URI Class Initialized
DEBUG - 2025-09-18 05:12:29 --> No URI present. Default controller set.
INFO - 2025-09-18 05:12:29 --> Router Class Initialized
INFO - 2025-09-18 05:12:29 --> Output Class Initialized
INFO - 2025-09-18 05:12:29 --> Security Class Initialized
DEBUG - 2025-09-18 05:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:12:29 --> CSRF cookie sent
INFO - 2025-09-18 05:12:29 --> Input Class Initialized
INFO - 2025-09-18 05:12:29 --> Language Class Initialized
INFO - 2025-09-18 05:12:29 --> Loader Class Initialized
INFO - 2025-09-18 05:12:29 --> Helper loaded: url_helper
INFO - 2025-09-18 05:12:29 --> Helper loaded: text_helper
INFO - 2025-09-18 05:12:29 --> Helper loaded: string_helper
INFO - 2025-09-18 05:12:29 --> Helper loaded: form_helper
INFO - 2025-09-18 05:12:29 --> Helper loaded: download_helper
INFO - 2025-09-18 05:12:29 --> Helper loaded: security_helper
INFO - 2025-09-18 05:12:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:12:29 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:12:29 --> Form Validation Class Initialized
INFO - 2025-09-18 05:12:29 --> Model "User_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:12:29 --> Controller Class Initialized
INFO - 2025-09-18 10:12:29 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Video_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:12:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:12:29 --> Pagination Class Initialized
INFO - 2025-09-18 10:12:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:12:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:12:29 --> Model "Log_model" initialized
INFO - 2025-09-18 10:12:29 --> Final output sent to browser
DEBUG - 2025-09-18 10:12:29 --> Total execution time: 0.1136
INFO - 2025-09-18 05:12:49 --> Config Class Initialized
INFO - 2025-09-18 05:12:49 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:12:49 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:12:49 --> Utf8 Class Initialized
INFO - 2025-09-18 05:12:49 --> URI Class Initialized
DEBUG - 2025-09-18 05:12:49 --> No URI present. Default controller set.
INFO - 2025-09-18 05:12:49 --> Router Class Initialized
INFO - 2025-09-18 05:12:49 --> Output Class Initialized
INFO - 2025-09-18 05:12:49 --> Security Class Initialized
DEBUG - 2025-09-18 05:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:12:49 --> CSRF cookie sent
INFO - 2025-09-18 05:12:49 --> Input Class Initialized
INFO - 2025-09-18 05:12:49 --> Language Class Initialized
INFO - 2025-09-18 05:12:49 --> Loader Class Initialized
INFO - 2025-09-18 05:12:49 --> Helper loaded: url_helper
INFO - 2025-09-18 05:12:49 --> Helper loaded: text_helper
INFO - 2025-09-18 05:12:49 --> Helper loaded: string_helper
INFO - 2025-09-18 05:12:49 --> Helper loaded: form_helper
INFO - 2025-09-18 05:12:49 --> Helper loaded: download_helper
INFO - 2025-09-18 05:12:49 --> Helper loaded: security_helper
INFO - 2025-09-18 05:12:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:12:49 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:12:49 --> Form Validation Class Initialized
INFO - 2025-09-18 05:12:49 --> Model "User_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:12:49 --> Controller Class Initialized
INFO - 2025-09-18 10:12:49 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Video_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:12:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:12:49 --> Pagination Class Initialized
INFO - 2025-09-18 10:12:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:12:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:12:49 --> Model "Log_model" initialized
INFO - 2025-09-18 10:12:49 --> Final output sent to browser
DEBUG - 2025-09-18 10:12:49 --> Total execution time: 0.1427
INFO - 2025-09-18 05:13:23 --> Config Class Initialized
INFO - 2025-09-18 05:13:23 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:13:23 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:13:23 --> Utf8 Class Initialized
INFO - 2025-09-18 05:13:23 --> URI Class Initialized
DEBUG - 2025-09-18 05:13:23 --> No URI present. Default controller set.
INFO - 2025-09-18 05:13:23 --> Router Class Initialized
INFO - 2025-09-18 05:13:23 --> Output Class Initialized
INFO - 2025-09-18 05:13:23 --> Security Class Initialized
DEBUG - 2025-09-18 05:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:13:23 --> CSRF cookie sent
INFO - 2025-09-18 05:13:23 --> Input Class Initialized
INFO - 2025-09-18 05:13:23 --> Language Class Initialized
INFO - 2025-09-18 05:13:23 --> Loader Class Initialized
INFO - 2025-09-18 05:13:23 --> Helper loaded: url_helper
INFO - 2025-09-18 05:13:23 --> Helper loaded: text_helper
INFO - 2025-09-18 05:13:23 --> Helper loaded: string_helper
INFO - 2025-09-18 05:13:23 --> Helper loaded: form_helper
INFO - 2025-09-18 05:13:23 --> Helper loaded: download_helper
INFO - 2025-09-18 05:13:23 --> Helper loaded: security_helper
INFO - 2025-09-18 05:13:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:13:23 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:13:23 --> Form Validation Class Initialized
INFO - 2025-09-18 05:13:23 --> Model "User_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:13:23 --> Controller Class Initialized
INFO - 2025-09-18 10:13:23 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Video_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:13:23 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:13:23 --> Pagination Class Initialized
INFO - 2025-09-18 10:13:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:13:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:13:23 --> Model "Log_model" initialized
INFO - 2025-09-18 10:13:23 --> Final output sent to browser
DEBUG - 2025-09-18 10:13:23 --> Total execution time: 0.1022
INFO - 2025-09-18 05:13:29 --> Config Class Initialized
INFO - 2025-09-18 05:13:29 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:13:29 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:13:29 --> Utf8 Class Initialized
INFO - 2025-09-18 05:13:29 --> URI Class Initialized
DEBUG - 2025-09-18 05:13:29 --> No URI present. Default controller set.
INFO - 2025-09-18 05:13:29 --> Router Class Initialized
INFO - 2025-09-18 05:13:29 --> Output Class Initialized
INFO - 2025-09-18 05:13:29 --> Security Class Initialized
DEBUG - 2025-09-18 05:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:13:29 --> CSRF cookie sent
INFO - 2025-09-18 05:13:29 --> Input Class Initialized
INFO - 2025-09-18 05:13:29 --> Language Class Initialized
INFO - 2025-09-18 05:13:29 --> Loader Class Initialized
INFO - 2025-09-18 05:13:29 --> Helper loaded: url_helper
INFO - 2025-09-18 05:13:29 --> Helper loaded: text_helper
INFO - 2025-09-18 05:13:29 --> Helper loaded: string_helper
INFO - 2025-09-18 05:13:29 --> Helper loaded: form_helper
INFO - 2025-09-18 05:13:29 --> Helper loaded: download_helper
INFO - 2025-09-18 05:13:29 --> Helper loaded: security_helper
INFO - 2025-09-18 05:13:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:13:29 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:13:29 --> Form Validation Class Initialized
INFO - 2025-09-18 05:13:29 --> Model "User_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:13:29 --> Controller Class Initialized
INFO - 2025-09-18 10:13:29 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Video_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:13:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:13:29 --> Pagination Class Initialized
INFO - 2025-09-18 10:13:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:13:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:13:29 --> Model "Log_model" initialized
INFO - 2025-09-18 10:13:29 --> Final output sent to browser
DEBUG - 2025-09-18 10:13:29 --> Total execution time: 0.1284
INFO - 2025-09-18 05:13:42 --> Config Class Initialized
INFO - 2025-09-18 05:13:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:13:42 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:13:42 --> Utf8 Class Initialized
INFO - 2025-09-18 05:13:42 --> URI Class Initialized
DEBUG - 2025-09-18 05:13:42 --> No URI present. Default controller set.
INFO - 2025-09-18 05:13:42 --> Router Class Initialized
INFO - 2025-09-18 05:13:42 --> Output Class Initialized
INFO - 2025-09-18 05:13:42 --> Security Class Initialized
DEBUG - 2025-09-18 05:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:13:42 --> CSRF cookie sent
INFO - 2025-09-18 05:13:42 --> Input Class Initialized
INFO - 2025-09-18 05:13:42 --> Language Class Initialized
INFO - 2025-09-18 05:13:42 --> Loader Class Initialized
INFO - 2025-09-18 05:13:42 --> Helper loaded: url_helper
INFO - 2025-09-18 05:13:42 --> Helper loaded: text_helper
INFO - 2025-09-18 05:13:42 --> Helper loaded: string_helper
INFO - 2025-09-18 05:13:42 --> Helper loaded: form_helper
INFO - 2025-09-18 05:13:42 --> Helper loaded: download_helper
INFO - 2025-09-18 05:13:42 --> Helper loaded: security_helper
INFO - 2025-09-18 05:13:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:13:42 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:13:42 --> Form Validation Class Initialized
INFO - 2025-09-18 05:13:42 --> Model "User_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:13:42 --> Controller Class Initialized
INFO - 2025-09-18 10:13:42 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Video_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:13:42 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:13:42 --> Pagination Class Initialized
INFO - 2025-09-18 10:13:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:13:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:13:42 --> Model "Log_model" initialized
INFO - 2025-09-18 10:13:42 --> Final output sent to browser
DEBUG - 2025-09-18 10:13:42 --> Total execution time: 0.1079
INFO - 2025-09-18 05:13:52 --> Config Class Initialized
INFO - 2025-09-18 05:13:52 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:13:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:13:52 --> Utf8 Class Initialized
INFO - 2025-09-18 05:13:52 --> URI Class Initialized
DEBUG - 2025-09-18 05:13:52 --> No URI present. Default controller set.
INFO - 2025-09-18 05:13:52 --> Router Class Initialized
INFO - 2025-09-18 05:13:52 --> Output Class Initialized
INFO - 2025-09-18 05:13:52 --> Security Class Initialized
DEBUG - 2025-09-18 05:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:13:52 --> CSRF cookie sent
INFO - 2025-09-18 05:13:52 --> Input Class Initialized
INFO - 2025-09-18 05:13:52 --> Language Class Initialized
INFO - 2025-09-18 05:13:52 --> Loader Class Initialized
INFO - 2025-09-18 05:13:52 --> Helper loaded: url_helper
INFO - 2025-09-18 05:13:52 --> Helper loaded: text_helper
INFO - 2025-09-18 05:13:52 --> Helper loaded: string_helper
INFO - 2025-09-18 05:13:52 --> Helper loaded: form_helper
INFO - 2025-09-18 05:13:52 --> Helper loaded: download_helper
INFO - 2025-09-18 05:13:52 --> Helper loaded: security_helper
INFO - 2025-09-18 05:13:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:13:52 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:13:52 --> Form Validation Class Initialized
INFO - 2025-09-18 05:13:52 --> Model "User_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:13:52 --> Controller Class Initialized
INFO - 2025-09-18 10:13:52 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Video_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:13:52 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:13:52 --> Pagination Class Initialized
INFO - 2025-09-18 10:13:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:13:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:13:52 --> Model "Log_model" initialized
INFO - 2025-09-18 10:13:52 --> Final output sent to browser
DEBUG - 2025-09-18 10:13:52 --> Total execution time: 0.1308
INFO - 2025-09-18 05:14:10 --> Config Class Initialized
INFO - 2025-09-18 05:14:10 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:14:10 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:14:10 --> Utf8 Class Initialized
INFO - 2025-09-18 05:14:10 --> URI Class Initialized
INFO - 2025-09-18 05:14:10 --> Router Class Initialized
INFO - 2025-09-18 05:14:10 --> Output Class Initialized
INFO - 2025-09-18 05:14:10 --> Security Class Initialized
DEBUG - 2025-09-18 05:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:14:10 --> CSRF cookie sent
INFO - 2025-09-18 05:14:10 --> Input Class Initialized
INFO - 2025-09-18 05:14:10 --> Language Class Initialized
INFO - 2025-09-18 05:14:10 --> Loader Class Initialized
INFO - 2025-09-18 05:14:10 --> Helper loaded: url_helper
INFO - 2025-09-18 05:14:10 --> Helper loaded: text_helper
INFO - 2025-09-18 05:14:10 --> Helper loaded: string_helper
INFO - 2025-09-18 05:14:10 --> Helper loaded: form_helper
INFO - 2025-09-18 05:14:10 --> Helper loaded: download_helper
INFO - 2025-09-18 05:14:10 --> Helper loaded: security_helper
INFO - 2025-09-18 05:14:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:14:10 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:14:10 --> Form Validation Class Initialized
INFO - 2025-09-18 05:14:10 --> Model "User_model" initialized
INFO - 2025-09-18 10:14:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:14:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:14:10 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:14:10 --> Controller Class Initialized
INFO - 2025-09-18 10:14:10 --> Model "Sdm_model" initialized
INFO - 2025-09-18 10:14:10 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-18 10:14:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-09-18 10:14:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:14:10 --> Model "Log_model" initialized
INFO - 2025-09-18 10:14:10 --> Final output sent to browser
DEBUG - 2025-09-18 10:14:10 --> Total execution time: 0.2674
INFO - 2025-09-18 05:15:20 --> Config Class Initialized
INFO - 2025-09-18 05:15:20 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:15:20 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:15:20 --> Utf8 Class Initialized
INFO - 2025-09-18 05:15:20 --> URI Class Initialized
INFO - 2025-09-18 05:15:20 --> Router Class Initialized
INFO - 2025-09-18 05:15:20 --> Output Class Initialized
INFO - 2025-09-18 05:15:20 --> Security Class Initialized
DEBUG - 2025-09-18 05:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:15:20 --> CSRF cookie sent
INFO - 2025-09-18 05:15:20 --> Input Class Initialized
INFO - 2025-09-18 05:15:20 --> Language Class Initialized
INFO - 2025-09-18 05:15:20 --> Loader Class Initialized
INFO - 2025-09-18 05:15:20 --> Helper loaded: url_helper
INFO - 2025-09-18 05:15:20 --> Helper loaded: text_helper
INFO - 2025-09-18 05:15:20 --> Helper loaded: string_helper
INFO - 2025-09-18 05:15:20 --> Helper loaded: form_helper
INFO - 2025-09-18 05:15:20 --> Helper loaded: download_helper
INFO - 2025-09-18 05:15:20 --> Helper loaded: security_helper
INFO - 2025-09-18 05:15:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:15:20 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:15:20 --> Form Validation Class Initialized
INFO - 2025-09-18 05:15:20 --> Model "User_model" initialized
INFO - 2025-09-18 10:15:20 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:15:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:15:20 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:15:20 --> Controller Class Initialized
INFO - 2025-09-18 10:15:20 --> Model "Download_model" initialized
INFO - 2025-09-18 10:15:20 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 10:15:20 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 10:15:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2025-09-18 10:15:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:15:20 --> Model "Log_model" initialized
INFO - 2025-09-18 10:15:20 --> Final output sent to browser
DEBUG - 2025-09-18 10:15:20 --> Total execution time: 0.1179
INFO - 2025-09-18 05:15:28 --> Config Class Initialized
INFO - 2025-09-18 05:15:28 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:15:28 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:15:28 --> Utf8 Class Initialized
INFO - 2025-09-18 05:15:28 --> URI Class Initialized
DEBUG - 2025-09-18 05:15:28 --> No URI present. Default controller set.
INFO - 2025-09-18 05:15:28 --> Router Class Initialized
INFO - 2025-09-18 05:15:28 --> Output Class Initialized
INFO - 2025-09-18 05:15:28 --> Security Class Initialized
DEBUG - 2025-09-18 05:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:15:28 --> CSRF cookie sent
INFO - 2025-09-18 05:15:28 --> Input Class Initialized
INFO - 2025-09-18 05:15:28 --> Language Class Initialized
INFO - 2025-09-18 05:15:28 --> Loader Class Initialized
INFO - 2025-09-18 05:15:28 --> Helper loaded: url_helper
INFO - 2025-09-18 05:15:28 --> Helper loaded: text_helper
INFO - 2025-09-18 05:15:28 --> Helper loaded: string_helper
INFO - 2025-09-18 05:15:28 --> Helper loaded: form_helper
INFO - 2025-09-18 05:15:28 --> Helper loaded: download_helper
INFO - 2025-09-18 05:15:28 --> Helper loaded: security_helper
INFO - 2025-09-18 05:15:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:15:28 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:15:28 --> Form Validation Class Initialized
INFO - 2025-09-18 05:15:28 --> Model "User_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:15:28 --> Controller Class Initialized
INFO - 2025-09-18 10:15:28 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Video_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:15:28 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:15:28 --> Pagination Class Initialized
INFO - 2025-09-18 10:15:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:15:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:15:28 --> Model "Log_model" initialized
INFO - 2025-09-18 10:15:28 --> Final output sent to browser
DEBUG - 2025-09-18 10:15:28 --> Total execution time: 0.0802
INFO - 2025-09-18 05:15:41 --> Config Class Initialized
INFO - 2025-09-18 05:15:41 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:15:41 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:15:41 --> Utf8 Class Initialized
INFO - 2025-09-18 05:15:41 --> URI Class Initialized
INFO - 2025-09-18 05:15:41 --> Router Class Initialized
INFO - 2025-09-18 05:15:41 --> Output Class Initialized
INFO - 2025-09-18 05:15:41 --> Security Class Initialized
DEBUG - 2025-09-18 05:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:15:41 --> CSRF cookie sent
INFO - 2025-09-18 05:15:41 --> Input Class Initialized
INFO - 2025-09-18 05:15:41 --> Language Class Initialized
INFO - 2025-09-18 05:15:41 --> Loader Class Initialized
INFO - 2025-09-18 05:15:41 --> Helper loaded: url_helper
INFO - 2025-09-18 05:15:41 --> Helper loaded: text_helper
INFO - 2025-09-18 05:15:41 --> Helper loaded: string_helper
INFO - 2025-09-18 05:15:41 --> Helper loaded: form_helper
INFO - 2025-09-18 05:15:41 --> Helper loaded: download_helper
INFO - 2025-09-18 05:15:41 --> Helper loaded: security_helper
INFO - 2025-09-18 05:15:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:15:41 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:15:41 --> Form Validation Class Initialized
INFO - 2025-09-18 05:15:41 --> Model "User_model" initialized
INFO - 2025-09-18 10:15:41 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:15:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:15:41 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:15:41 --> Controller Class Initialized
INFO - 2025-09-18 10:15:41 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:15:41 --> Model "Kategori_model" initialized
INFO - 2025-09-18 10:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:15:41 --> Pagination Class Initialized
INFO - 2025-09-18 10:15:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2025-09-18 10:15:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:15:41 --> Model "Log_model" initialized
INFO - 2025-09-18 10:15:41 --> Final output sent to browser
DEBUG - 2025-09-18 10:15:41 --> Total execution time: 0.0717
INFO - 2025-09-18 05:15:46 --> Config Class Initialized
INFO - 2025-09-18 05:15:46 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:15:46 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:15:46 --> Utf8 Class Initialized
INFO - 2025-09-18 05:15:46 --> URI Class Initialized
INFO - 2025-09-18 05:15:46 --> Router Class Initialized
INFO - 2025-09-18 05:15:46 --> Output Class Initialized
INFO - 2025-09-18 05:15:46 --> Security Class Initialized
DEBUG - 2025-09-18 05:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:15:46 --> CSRF cookie sent
INFO - 2025-09-18 05:15:46 --> Input Class Initialized
INFO - 2025-09-18 05:15:46 --> Language Class Initialized
INFO - 2025-09-18 05:15:46 --> Loader Class Initialized
INFO - 2025-09-18 05:15:46 --> Helper loaded: url_helper
INFO - 2025-09-18 05:15:46 --> Helper loaded: text_helper
INFO - 2025-09-18 05:15:46 --> Helper loaded: string_helper
INFO - 2025-09-18 05:15:46 --> Helper loaded: form_helper
INFO - 2025-09-18 05:15:46 --> Helper loaded: download_helper
INFO - 2025-09-18 05:15:46 --> Helper loaded: security_helper
INFO - 2025-09-18 05:15:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:15:46 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:15:46 --> Form Validation Class Initialized
INFO - 2025-09-18 05:15:46 --> Model "User_model" initialized
INFO - 2025-09-18 10:15:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:15:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:15:46 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:15:46 --> Controller Class Initialized
INFO - 2025-09-18 10:15:46 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:15:46 --> Model "Kategori_model" initialized
INFO - 2025-09-18 10:15:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/read.php
INFO - 2025-09-18 10:15:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:15:46 --> Model "Log_model" initialized
INFO - 2025-09-18 10:15:46 --> Final output sent to browser
DEBUG - 2025-09-18 10:15:46 --> Total execution time: 0.0501
INFO - 2025-09-18 05:16:09 --> Config Class Initialized
INFO - 2025-09-18 05:16:09 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:16:09 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:16:09 --> Utf8 Class Initialized
INFO - 2025-09-18 05:16:09 --> URI Class Initialized
INFO - 2025-09-18 05:16:09 --> Router Class Initialized
INFO - 2025-09-18 05:16:09 --> Output Class Initialized
INFO - 2025-09-18 05:16:09 --> Security Class Initialized
DEBUG - 2025-09-18 05:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:16:09 --> CSRF cookie sent
INFO - 2025-09-18 05:16:09 --> Input Class Initialized
INFO - 2025-09-18 05:16:09 --> Language Class Initialized
INFO - 2025-09-18 05:16:09 --> Loader Class Initialized
INFO - 2025-09-18 05:16:09 --> Helper loaded: url_helper
INFO - 2025-09-18 05:16:09 --> Helper loaded: text_helper
INFO - 2025-09-18 05:16:09 --> Helper loaded: string_helper
INFO - 2025-09-18 05:16:09 --> Helper loaded: form_helper
INFO - 2025-09-18 05:16:09 --> Helper loaded: download_helper
INFO - 2025-09-18 05:16:09 --> Helper loaded: security_helper
INFO - 2025-09-18 05:16:09 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:16:09 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:16:09 --> Form Validation Class Initialized
INFO - 2025-09-18 05:16:09 --> Model "User_model" initialized
INFO - 2025-09-18 10:16:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:16:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:16:09 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:16:09 --> Controller Class Initialized
INFO - 2025-09-18 10:16:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:16:09 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:16:09 --> Model "Sdm_model" initialized
INFO - 2025-09-18 10:16:09 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 10:16:10 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 0
ERROR - 2025-09-18 10:16:10 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 10:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 10:16:10 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 10:16:10 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 10:16:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 10:16:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:16:10 --> Model "Log_model" initialized
INFO - 2025-09-18 10:16:10 --> Final output sent to browser
DEBUG - 2025-09-18 10:16:10 --> Total execution time: 0.0728
INFO - 2025-09-18 05:16:29 --> Config Class Initialized
INFO - 2025-09-18 05:16:29 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:16:29 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:16:29 --> Utf8 Class Initialized
INFO - 2025-09-18 05:16:29 --> URI Class Initialized
INFO - 2025-09-18 05:16:29 --> Router Class Initialized
INFO - 2025-09-18 05:16:29 --> Output Class Initialized
INFO - 2025-09-18 05:16:29 --> Security Class Initialized
DEBUG - 2025-09-18 05:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:16:29 --> CSRF cookie sent
INFO - 2025-09-18 05:16:29 --> Input Class Initialized
INFO - 2025-09-18 05:16:29 --> Language Class Initialized
INFO - 2025-09-18 05:16:29 --> Loader Class Initialized
INFO - 2025-09-18 05:16:29 --> Helper loaded: url_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: text_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: string_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: form_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: download_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: security_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:16:29 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:16:29 --> Form Validation Class Initialized
INFO - 2025-09-18 05:16:29 --> Model "User_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:16:29 --> Controller Class Initialized
INFO - 2025-09-18 10:16:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Sdm_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 10:16:29 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 10:16:29 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 10:16:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 10:16:29 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 10:16:29 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 10:16:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 10:16:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:16:29 --> Model "Log_model" initialized
INFO - 2025-09-18 10:16:29 --> Final output sent to browser
DEBUG - 2025-09-18 10:16:29 --> Total execution time: 0.0864
INFO - 2025-09-18 05:16:29 --> Config Class Initialized
INFO - 2025-09-18 05:16:29 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:16:29 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:16:29 --> Utf8 Class Initialized
INFO - 2025-09-18 05:16:29 --> URI Class Initialized
INFO - 2025-09-18 05:16:29 --> Config Class Initialized
INFO - 2025-09-18 05:16:29 --> Hooks Class Initialized
INFO - 2025-09-18 05:16:29 --> Router Class Initialized
INFO - 2025-09-18 05:16:29 --> Output Class Initialized
DEBUG - 2025-09-18 05:16:29 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:16:29 --> Utf8 Class Initialized
INFO - 2025-09-18 05:16:29 --> Security Class Initialized
INFO - 2025-09-18 05:16:29 --> URI Class Initialized
DEBUG - 2025-09-18 05:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:16:29 --> CSRF cookie sent
INFO - 2025-09-18 05:16:29 --> Router Class Initialized
INFO - 2025-09-18 05:16:29 --> Input Class Initialized
INFO - 2025-09-18 05:16:29 --> Language Class Initialized
INFO - 2025-09-18 05:16:29 --> Output Class Initialized
INFO - 2025-09-18 05:16:29 --> Security Class Initialized
INFO - 2025-09-18 05:16:29 --> Loader Class Initialized
DEBUG - 2025-09-18 05:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:16:29 --> CSRF cookie sent
INFO - 2025-09-18 05:16:29 --> Input Class Initialized
INFO - 2025-09-18 05:16:29 --> Helper loaded: url_helper
INFO - 2025-09-18 05:16:29 --> Language Class Initialized
INFO - 2025-09-18 05:16:29 --> Helper loaded: text_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: string_helper
INFO - 2025-09-18 05:16:29 --> Loader Class Initialized
INFO - 2025-09-18 05:16:29 --> Helper loaded: form_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: download_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: security_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: url_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: text_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: string_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: form_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: download_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: security_helper
INFO - 2025-09-18 05:16:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:16:29 --> Database Driver Class Initialized
INFO - 2025-09-18 05:16:29 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:16:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-09-18 05:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:16:29 --> Form Validation Class Initialized
INFO - 2025-09-18 05:16:29 --> Model "User_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:16:29 --> Controller Class Initialized
INFO - 2025-09-18 10:16:29 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Video_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:16:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 10:16:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:16:29 --> Model "Log_model" initialized
INFO - 2025-09-18 10:16:29 --> Final output sent to browser
DEBUG - 2025-09-18 10:16:29 --> Total execution time: 0.0559
INFO - 2025-09-18 05:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:16:29 --> Form Validation Class Initialized
INFO - 2025-09-18 05:16:29 --> Model "User_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:16:29 --> Controller Class Initialized
INFO - 2025-09-18 10:16:29 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Video_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:16:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:16:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 10:16:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:16:29 --> Model "Log_model" initialized
INFO - 2025-09-18 10:16:29 --> Final output sent to browser
DEBUG - 2025-09-18 10:16:29 --> Total execution time: 0.0820
INFO - 2025-09-18 05:16:59 --> Config Class Initialized
INFO - 2025-09-18 05:16:59 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:16:59 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:16:59 --> Utf8 Class Initialized
INFO - 2025-09-18 05:16:59 --> URI Class Initialized
DEBUG - 2025-09-18 05:16:59 --> No URI present. Default controller set.
INFO - 2025-09-18 05:16:59 --> Router Class Initialized
INFO - 2025-09-18 05:16:59 --> Output Class Initialized
INFO - 2025-09-18 05:16:59 --> Security Class Initialized
DEBUG - 2025-09-18 05:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:16:59 --> CSRF cookie sent
INFO - 2025-09-18 05:16:59 --> Input Class Initialized
INFO - 2025-09-18 05:16:59 --> Language Class Initialized
INFO - 2025-09-18 05:16:59 --> Loader Class Initialized
INFO - 2025-09-18 05:16:59 --> Helper loaded: url_helper
INFO - 2025-09-18 05:16:59 --> Helper loaded: text_helper
INFO - 2025-09-18 05:16:59 --> Helper loaded: string_helper
INFO - 2025-09-18 05:16:59 --> Helper loaded: form_helper
INFO - 2025-09-18 05:16:59 --> Helper loaded: download_helper
INFO - 2025-09-18 05:16:59 --> Helper loaded: security_helper
INFO - 2025-09-18 05:16:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:16:59 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:16:59 --> Form Validation Class Initialized
INFO - 2025-09-18 05:16:59 --> Model "User_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:16:59 --> Controller Class Initialized
INFO - 2025-09-18 10:16:59 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Video_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:16:59 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:16:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:16:59 --> Pagination Class Initialized
INFO - 2025-09-18 10:16:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:16:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:16:59 --> Model "Log_model" initialized
INFO - 2025-09-18 10:16:59 --> Final output sent to browser
DEBUG - 2025-09-18 10:16:59 --> Total execution time: 0.0966
INFO - 2025-09-18 05:17:13 --> Config Class Initialized
INFO - 2025-09-18 05:17:13 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:17:13 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:17:13 --> Utf8 Class Initialized
INFO - 2025-09-18 05:17:13 --> URI Class Initialized
INFO - 2025-09-18 05:17:13 --> Router Class Initialized
INFO - 2025-09-18 05:17:13 --> Output Class Initialized
INFO - 2025-09-18 05:17:13 --> Security Class Initialized
DEBUG - 2025-09-18 05:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:17:13 --> CSRF cookie sent
INFO - 2025-09-18 05:17:13 --> Input Class Initialized
INFO - 2025-09-18 05:17:13 --> Language Class Initialized
INFO - 2025-09-18 05:17:13 --> Loader Class Initialized
INFO - 2025-09-18 05:17:13 --> Helper loaded: url_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: text_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: string_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: form_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: download_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: security_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:17:13 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:17:13 --> Form Validation Class Initialized
INFO - 2025-09-18 05:17:13 --> Model "User_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:17:13 --> Controller Class Initialized
INFO - 2025-09-18 10:17:13 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Sdm_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 10:17:13 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 10:17:13 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 10:17:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 10:17:13 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 10:17:13 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 10:17:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 10:17:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:17:13 --> Model "Log_model" initialized
INFO - 2025-09-18 10:17:13 --> Final output sent to browser
DEBUG - 2025-09-18 10:17:13 --> Total execution time: 0.0948
INFO - 2025-09-18 05:17:13 --> Config Class Initialized
INFO - 2025-09-18 05:17:13 --> Config Class Initialized
INFO - 2025-09-18 05:17:13 --> Hooks Class Initialized
INFO - 2025-09-18 05:17:13 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2025-09-18 05:17:13 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:17:13 --> Utf8 Class Initialized
INFO - 2025-09-18 05:17:13 --> Utf8 Class Initialized
INFO - 2025-09-18 05:17:13 --> URI Class Initialized
INFO - 2025-09-18 05:17:13 --> URI Class Initialized
INFO - 2025-09-18 05:17:13 --> Router Class Initialized
INFO - 2025-09-18 05:17:13 --> Router Class Initialized
INFO - 2025-09-18 05:17:13 --> Output Class Initialized
INFO - 2025-09-18 05:17:13 --> Output Class Initialized
INFO - 2025-09-18 05:17:13 --> Security Class Initialized
INFO - 2025-09-18 05:17:13 --> Security Class Initialized
DEBUG - 2025-09-18 05:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:17:13 --> CSRF cookie sent
INFO - 2025-09-18 05:17:13 --> Input Class Initialized
INFO - 2025-09-18 05:17:13 --> Language Class Initialized
DEBUG - 2025-09-18 05:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:17:13 --> CSRF cookie sent
INFO - 2025-09-18 05:17:13 --> Input Class Initialized
INFO - 2025-09-18 05:17:13 --> Language Class Initialized
INFO - 2025-09-18 05:17:13 --> Loader Class Initialized
INFO - 2025-09-18 05:17:13 --> Loader Class Initialized
INFO - 2025-09-18 05:17:13 --> Helper loaded: url_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: text_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: url_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: string_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: text_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: form_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: string_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: download_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: security_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: form_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: download_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: security_helper
INFO - 2025-09-18 05:17:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:17:13 --> Database Driver Class Initialized
INFO - 2025-09-18 05:17:13 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-18 05:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:17:13 --> Form Validation Class Initialized
INFO - 2025-09-18 05:17:13 --> Model "User_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:17:13 --> Controller Class Initialized
INFO - 2025-09-18 10:17:13 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Video_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:17:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 10:17:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:17:13 --> Model "Log_model" initialized
INFO - 2025-09-18 10:17:13 --> Final output sent to browser
DEBUG - 2025-09-18 10:17:13 --> Total execution time: 0.0624
INFO - 2025-09-18 05:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:17:13 --> Form Validation Class Initialized
INFO - 2025-09-18 05:17:13 --> Model "User_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:17:13 --> Controller Class Initialized
INFO - 2025-09-18 10:17:13 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Video_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:17:13 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:17:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 10:17:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:17:13 --> Model "Log_model" initialized
INFO - 2025-09-18 10:17:13 --> Final output sent to browser
DEBUG - 2025-09-18 10:17:13 --> Total execution time: 0.0938
INFO - 2025-09-18 05:17:58 --> Config Class Initialized
INFO - 2025-09-18 05:17:58 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:17:58 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:17:58 --> Utf8 Class Initialized
INFO - 2025-09-18 05:17:58 --> URI Class Initialized
DEBUG - 2025-09-18 05:17:58 --> No URI present. Default controller set.
INFO - 2025-09-18 05:17:58 --> Router Class Initialized
INFO - 2025-09-18 05:17:58 --> Output Class Initialized
INFO - 2025-09-18 05:17:58 --> Security Class Initialized
DEBUG - 2025-09-18 05:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:17:58 --> CSRF cookie sent
INFO - 2025-09-18 05:17:58 --> Input Class Initialized
INFO - 2025-09-18 05:17:58 --> Language Class Initialized
INFO - 2025-09-18 05:17:58 --> Loader Class Initialized
INFO - 2025-09-18 05:17:58 --> Helper loaded: url_helper
INFO - 2025-09-18 05:17:58 --> Helper loaded: text_helper
INFO - 2025-09-18 05:17:58 --> Helper loaded: string_helper
INFO - 2025-09-18 05:17:58 --> Helper loaded: form_helper
INFO - 2025-09-18 05:17:58 --> Helper loaded: download_helper
INFO - 2025-09-18 05:17:58 --> Helper loaded: security_helper
INFO - 2025-09-18 05:17:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:17:58 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:17:58 --> Form Validation Class Initialized
INFO - 2025-09-18 05:17:58 --> Model "User_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:17:58 --> Controller Class Initialized
INFO - 2025-09-18 10:17:58 --> Model "Berita_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Galeri_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Video_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Agenda_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Mitra_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Prodi_model" initialized
INFO - 2025-09-18 10:17:58 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 10:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 10:17:58 --> Pagination Class Initialized
INFO - 2025-09-18 10:17:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 10:17:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 10:17:58 --> Model "Log_model" initialized
INFO - 2025-09-18 10:17:58 --> Final output sent to browser
DEBUG - 2025-09-18 10:17:58 --> Total execution time: 0.0972
INFO - 2025-09-18 05:38:19 --> Config Class Initialized
INFO - 2025-09-18 05:38:19 --> Hooks Class Initialized
DEBUG - 2025-09-18 05:38:19 --> UTF-8 Support Enabled
INFO - 2025-09-18 05:38:19 --> Utf8 Class Initialized
INFO - 2025-09-18 05:38:19 --> URI Class Initialized
INFO - 2025-09-18 05:38:19 --> Router Class Initialized
INFO - 2025-09-18 05:38:19 --> Output Class Initialized
INFO - 2025-09-18 05:38:19 --> Security Class Initialized
DEBUG - 2025-09-18 05:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 05:38:19 --> CSRF cookie sent
INFO - 2025-09-18 05:38:19 --> Input Class Initialized
INFO - 2025-09-18 05:38:19 --> Language Class Initialized
INFO - 2025-09-18 05:38:20 --> Loader Class Initialized
INFO - 2025-09-18 05:38:20 --> Helper loaded: url_helper
INFO - 2025-09-18 05:38:20 --> Helper loaded: text_helper
INFO - 2025-09-18 05:38:20 --> Helper loaded: string_helper
INFO - 2025-09-18 05:38:20 --> Helper loaded: form_helper
INFO - 2025-09-18 05:38:20 --> Helper loaded: download_helper
INFO - 2025-09-18 05:38:20 --> Helper loaded: security_helper
INFO - 2025-09-18 05:38:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 05:38:20 --> Database Driver Class Initialized
DEBUG - 2025-09-18 05:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 05:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 05:38:21 --> Form Validation Class Initialized
INFO - 2025-09-18 05:38:21 --> Model "User_model" initialized
INFO - 2025-09-18 10:38:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 10:38:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 10:38:21 --> Model "Nav_model" initialized
INFO - 2025-09-18 10:38:21 --> Controller Class Initialized
INFO - 2025-09-18 10:38:21 --> Model "Tautan_model" initialized
INFO - 2025-09-18 10:38:21 --> Model "Staff_model" initialized
INFO - 2025-09-18 10:38:21 --> Model "Dasbor_model" initialized
INFO - 2025-09-18 10:38:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-09-18 10:38:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 10:38:22 --> Model "Log_model" initialized
INFO - 2025-09-18 10:38:22 --> Final output sent to browser
DEBUG - 2025-09-18 10:38:22 --> Total execution time: 3.6471
INFO - 2025-09-18 06:19:01 --> Config Class Initialized
INFO - 2025-09-18 06:19:01 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:19:01 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:19:01 --> Utf8 Class Initialized
INFO - 2025-09-18 06:19:01 --> URI Class Initialized
DEBUG - 2025-09-18 06:19:01 --> No URI present. Default controller set.
INFO - 2025-09-18 06:19:01 --> Router Class Initialized
INFO - 2025-09-18 06:19:01 --> Output Class Initialized
INFO - 2025-09-18 06:19:01 --> Security Class Initialized
DEBUG - 2025-09-18 06:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:19:01 --> CSRF cookie sent
INFO - 2025-09-18 06:19:01 --> Input Class Initialized
INFO - 2025-09-18 06:19:01 --> Language Class Initialized
INFO - 2025-09-18 06:19:01 --> Loader Class Initialized
INFO - 2025-09-18 06:19:01 --> Helper loaded: url_helper
INFO - 2025-09-18 06:19:01 --> Helper loaded: text_helper
INFO - 2025-09-18 06:19:01 --> Helper loaded: string_helper
INFO - 2025-09-18 06:19:01 --> Helper loaded: form_helper
INFO - 2025-09-18 06:19:01 --> Helper loaded: download_helper
INFO - 2025-09-18 06:19:01 --> Helper loaded: security_helper
INFO - 2025-09-18 06:19:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:19:01 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:19:01 --> Form Validation Class Initialized
INFO - 2025-09-18 06:19:01 --> Model "User_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:19:01 --> Controller Class Initialized
INFO - 2025-09-18 11:19:01 --> Model "Berita_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Galeri_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Video_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Agenda_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Tautan_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Mitra_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Prodi_model" initialized
INFO - 2025-09-18 11:19:01 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 11:19:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 11:19:01 --> Pagination Class Initialized
INFO - 2025-09-18 11:19:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 11:19:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:19:03 --> Model "Log_model" initialized
INFO - 2025-09-18 11:19:03 --> Final output sent to browser
DEBUG - 2025-09-18 11:19:03 --> Total execution time: 2.4394
INFO - 2025-09-18 06:37:07 --> Config Class Initialized
INFO - 2025-09-18 06:37:07 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:37:07 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:37:07 --> Utf8 Class Initialized
INFO - 2025-09-18 06:37:07 --> URI Class Initialized
INFO - 2025-09-18 06:37:07 --> Router Class Initialized
INFO - 2025-09-18 06:37:07 --> Output Class Initialized
INFO - 2025-09-18 06:37:07 --> Security Class Initialized
DEBUG - 2025-09-18 06:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:37:07 --> CSRF cookie sent
INFO - 2025-09-18 06:37:07 --> Input Class Initialized
INFO - 2025-09-18 06:37:07 --> Language Class Initialized
INFO - 2025-09-18 06:37:07 --> Loader Class Initialized
INFO - 2025-09-18 06:37:07 --> Helper loaded: url_helper
INFO - 2025-09-18 06:37:07 --> Helper loaded: text_helper
INFO - 2025-09-18 06:37:07 --> Helper loaded: string_helper
INFO - 2025-09-18 06:37:07 --> Helper loaded: form_helper
INFO - 2025-09-18 06:37:07 --> Helper loaded: download_helper
INFO - 2025-09-18 06:37:07 --> Helper loaded: security_helper
INFO - 2025-09-18 06:37:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:37:07 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:37:07 --> Form Validation Class Initialized
INFO - 2025-09-18 06:37:07 --> Model "User_model" initialized
INFO - 2025-09-18 11:37:07 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:37:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:37:07 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:37:07 --> Controller Class Initialized
INFO - 2025-09-18 11:37:07 --> Model "Prodi_model" initialized
INFO - 2025-09-18 11:37:07 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 11:37:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-18 11:37:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 11:37:07 --> Model "Log_model" initialized
INFO - 2025-09-18 11:37:07 --> Final output sent to browser
DEBUG - 2025-09-18 11:37:07 --> Total execution time: 0.0590
INFO - 2025-09-18 06:38:45 --> Config Class Initialized
INFO - 2025-09-18 06:38:45 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:38:45 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:38:45 --> Utf8 Class Initialized
INFO - 2025-09-18 06:38:45 --> URI Class Initialized
INFO - 2025-09-18 06:38:45 --> Router Class Initialized
INFO - 2025-09-18 06:38:45 --> Output Class Initialized
INFO - 2025-09-18 06:38:45 --> Security Class Initialized
DEBUG - 2025-09-18 06:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:38:45 --> CSRF cookie sent
INFO - 2025-09-18 06:38:45 --> Input Class Initialized
INFO - 2025-09-18 06:38:45 --> Language Class Initialized
INFO - 2025-09-18 06:38:45 --> Loader Class Initialized
INFO - 2025-09-18 06:38:45 --> Helper loaded: url_helper
INFO - 2025-09-18 06:38:45 --> Helper loaded: text_helper
INFO - 2025-09-18 06:38:45 --> Helper loaded: string_helper
INFO - 2025-09-18 06:38:45 --> Helper loaded: form_helper
INFO - 2025-09-18 06:38:45 --> Helper loaded: download_helper
INFO - 2025-09-18 06:38:45 --> Helper loaded: security_helper
INFO - 2025-09-18 06:38:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:38:45 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:38:45 --> Form Validation Class Initialized
INFO - 2025-09-18 06:38:45 --> Model "User_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:38:45 --> Controller Class Initialized
INFO - 2025-09-18 11:38:45 --> Model "Berita_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Galeri_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Video_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Agenda_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Tautan_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Mitra_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Prodi_model" initialized
INFO - 2025-09-18 11:38:45 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 11:38:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 11:38:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:38:45 --> Model "Log_model" initialized
INFO - 2025-09-18 11:38:45 --> Final output sent to browser
DEBUG - 2025-09-18 11:38:45 --> Total execution time: 0.0586
INFO - 2025-09-18 06:38:50 --> Config Class Initialized
INFO - 2025-09-18 06:38:50 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:38:50 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:38:50 --> Utf8 Class Initialized
INFO - 2025-09-18 06:38:50 --> URI Class Initialized
INFO - 2025-09-18 06:38:50 --> Router Class Initialized
INFO - 2025-09-18 06:38:50 --> Output Class Initialized
INFO - 2025-09-18 06:38:50 --> Security Class Initialized
DEBUG - 2025-09-18 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:38:50 --> CSRF cookie sent
INFO - 2025-09-18 06:38:50 --> Input Class Initialized
INFO - 2025-09-18 06:38:50 --> Language Class Initialized
INFO - 2025-09-18 06:38:50 --> Loader Class Initialized
INFO - 2025-09-18 06:38:50 --> Helper loaded: url_helper
INFO - 2025-09-18 06:38:50 --> Helper loaded: text_helper
INFO - 2025-09-18 06:38:50 --> Helper loaded: string_helper
INFO - 2025-09-18 06:38:50 --> Helper loaded: form_helper
INFO - 2025-09-18 06:38:50 --> Helper loaded: download_helper
INFO - 2025-09-18 06:38:50 --> Helper loaded: security_helper
INFO - 2025-09-18 06:38:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:38:50 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:38:50 --> Form Validation Class Initialized
INFO - 2025-09-18 06:38:50 --> Model "User_model" initialized
INFO - 2025-09-18 11:38:50 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:38:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:38:50 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:38:50 --> Controller Class Initialized
INFO - 2025-09-18 11:38:50 --> Model "Download_model" initialized
INFO - 2025-09-18 11:38:50 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 11:38:50 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 11:38:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2025-09-18 11:38:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:38:50 --> Model "Log_model" initialized
INFO - 2025-09-18 11:38:50 --> Final output sent to browser
DEBUG - 2025-09-18 11:38:50 --> Total execution time: 0.0864
INFO - 2025-09-18 06:38:54 --> Config Class Initialized
INFO - 2025-09-18 06:38:54 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:38:54 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:38:54 --> Utf8 Class Initialized
INFO - 2025-09-18 06:38:54 --> URI Class Initialized
INFO - 2025-09-18 06:38:54 --> Router Class Initialized
INFO - 2025-09-18 06:38:54 --> Output Class Initialized
INFO - 2025-09-18 06:38:54 --> Security Class Initialized
DEBUG - 2025-09-18 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:38:54 --> CSRF cookie sent
INFO - 2025-09-18 06:38:54 --> Input Class Initialized
INFO - 2025-09-18 06:38:54 --> Language Class Initialized
INFO - 2025-09-18 06:38:54 --> Loader Class Initialized
INFO - 2025-09-18 06:38:54 --> Helper loaded: url_helper
INFO - 2025-09-18 06:38:54 --> Helper loaded: text_helper
INFO - 2025-09-18 06:38:54 --> Helper loaded: string_helper
INFO - 2025-09-18 06:38:54 --> Helper loaded: form_helper
INFO - 2025-09-18 06:38:54 --> Helper loaded: download_helper
INFO - 2025-09-18 06:38:54 --> Helper loaded: security_helper
INFO - 2025-09-18 06:38:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:38:54 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:38:54 --> Form Validation Class Initialized
INFO - 2025-09-18 06:38:54 --> Model "User_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:38:54 --> Controller Class Initialized
INFO - 2025-09-18 11:38:54 --> Model "Berita_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Galeri_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Video_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Agenda_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Tautan_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Mitra_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Prodi_model" initialized
INFO - 2025-09-18 11:38:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 11:38:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 11:38:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:38:54 --> Model "Log_model" initialized
INFO - 2025-09-18 11:38:54 --> Final output sent to browser
DEBUG - 2025-09-18 11:38:54 --> Total execution time: 0.0602
INFO - 2025-09-18 06:38:59 --> Config Class Initialized
INFO - 2025-09-18 06:38:59 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:38:59 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:38:59 --> Utf8 Class Initialized
INFO - 2025-09-18 06:38:59 --> URI Class Initialized
INFO - 2025-09-18 06:38:59 --> Router Class Initialized
INFO - 2025-09-18 06:38:59 --> Output Class Initialized
INFO - 2025-09-18 06:38:59 --> Security Class Initialized
DEBUG - 2025-09-18 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:38:59 --> CSRF cookie sent
INFO - 2025-09-18 06:38:59 --> Input Class Initialized
INFO - 2025-09-18 06:38:59 --> Language Class Initialized
INFO - 2025-09-18 06:38:59 --> Loader Class Initialized
INFO - 2025-09-18 06:38:59 --> Helper loaded: url_helper
INFO - 2025-09-18 06:38:59 --> Helper loaded: text_helper
INFO - 2025-09-18 06:38:59 --> Helper loaded: string_helper
INFO - 2025-09-18 06:38:59 --> Helper loaded: form_helper
INFO - 2025-09-18 06:38:59 --> Helper loaded: download_helper
INFO - 2025-09-18 06:38:59 --> Helper loaded: security_helper
INFO - 2025-09-18 06:38:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:38:59 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:38:59 --> Form Validation Class Initialized
INFO - 2025-09-18 06:38:59 --> Model "User_model" initialized
INFO - 2025-09-18 11:38:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:38:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:38:59 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:38:59 --> Controller Class Initialized
INFO - 2025-09-18 11:38:59 --> Model "Download_model" initialized
INFO - 2025-09-18 11:38:59 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 11:38:59 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 11:38:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_standardpelayanan.php
INFO - 2025-09-18 11:38:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:38:59 --> Model "Log_model" initialized
INFO - 2025-09-18 11:38:59 --> Final output sent to browser
DEBUG - 2025-09-18 11:38:59 --> Total execution time: 0.0638
INFO - 2025-09-18 06:39:14 --> Config Class Initialized
INFO - 2025-09-18 06:39:14 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:39:14 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:39:14 --> Utf8 Class Initialized
INFO - 2025-09-18 06:39:14 --> URI Class Initialized
INFO - 2025-09-18 06:39:14 --> Router Class Initialized
INFO - 2025-09-18 06:39:14 --> Output Class Initialized
INFO - 2025-09-18 06:39:14 --> Security Class Initialized
DEBUG - 2025-09-18 06:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:39:14 --> CSRF cookie sent
INFO - 2025-09-18 06:39:14 --> Input Class Initialized
INFO - 2025-09-18 06:39:14 --> Language Class Initialized
INFO - 2025-09-18 06:39:14 --> Loader Class Initialized
INFO - 2025-09-18 06:39:14 --> Helper loaded: url_helper
INFO - 2025-09-18 06:39:14 --> Helper loaded: text_helper
INFO - 2025-09-18 06:39:14 --> Helper loaded: string_helper
INFO - 2025-09-18 06:39:14 --> Helper loaded: form_helper
INFO - 2025-09-18 06:39:14 --> Helper loaded: download_helper
INFO - 2025-09-18 06:39:14 --> Helper loaded: security_helper
INFO - 2025-09-18 06:39:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:39:14 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:39:14 --> Form Validation Class Initialized
INFO - 2025-09-18 06:39:14 --> Model "User_model" initialized
INFO - 2025-09-18 11:39:14 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:39:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:39:14 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:39:14 --> Controller Class Initialized
INFO - 2025-09-18 11:39:14 --> Model "Download_model" initialized
INFO - 2025-09-18 11:39:14 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 11:39:14 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 11:39:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2025-09-18 11:39:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:39:14 --> Model "Log_model" initialized
INFO - 2025-09-18 11:39:14 --> Final output sent to browser
DEBUG - 2025-09-18 11:39:14 --> Total execution time: 0.0621
INFO - 2025-09-18 06:39:16 --> Config Class Initialized
INFO - 2025-09-18 06:39:16 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:39:16 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:39:16 --> Utf8 Class Initialized
INFO - 2025-09-18 06:39:16 --> URI Class Initialized
INFO - 2025-09-18 06:39:16 --> Router Class Initialized
INFO - 2025-09-18 06:39:16 --> Output Class Initialized
INFO - 2025-09-18 06:39:16 --> Security Class Initialized
DEBUG - 2025-09-18 06:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:39:16 --> CSRF cookie sent
INFO - 2025-09-18 06:39:16 --> Input Class Initialized
INFO - 2025-09-18 06:39:16 --> Language Class Initialized
INFO - 2025-09-18 06:39:16 --> Loader Class Initialized
INFO - 2025-09-18 06:39:16 --> Helper loaded: url_helper
INFO - 2025-09-18 06:39:16 --> Helper loaded: text_helper
INFO - 2025-09-18 06:39:16 --> Helper loaded: string_helper
INFO - 2025-09-18 06:39:16 --> Helper loaded: form_helper
INFO - 2025-09-18 06:39:16 --> Helper loaded: download_helper
INFO - 2025-09-18 06:39:16 --> Helper loaded: security_helper
INFO - 2025-09-18 06:39:16 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:39:16 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:39:16 --> Form Validation Class Initialized
INFO - 2025-09-18 06:39:16 --> Model "User_model" initialized
INFO - 2025-09-18 11:39:16 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:39:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:39:16 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:39:16 --> Controller Class Initialized
INFO - 2025-09-18 11:39:16 --> Model "Download_model" initialized
INFO - 2025-09-18 11:39:16 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 11:39:16 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 11:39:16 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko\/20100101 Firefox\/143.0","download_id":"196","filename":"dipa-2022.pdf","timestamp":"2025-09-18 11:39:16"}
INFO - 2025-09-18 06:39:35 --> Config Class Initialized
INFO - 2025-09-18 06:39:35 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:39:35 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:39:35 --> Utf8 Class Initialized
INFO - 2025-09-18 06:39:35 --> URI Class Initialized
INFO - 2025-09-18 06:39:35 --> Router Class Initialized
INFO - 2025-09-18 06:39:35 --> Output Class Initialized
INFO - 2025-09-18 06:39:35 --> Security Class Initialized
DEBUG - 2025-09-18 06:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:39:35 --> CSRF cookie sent
INFO - 2025-09-18 06:39:35 --> Input Class Initialized
INFO - 2025-09-18 06:39:35 --> Language Class Initialized
INFO - 2025-09-18 06:39:35 --> Loader Class Initialized
INFO - 2025-09-18 06:39:35 --> Helper loaded: url_helper
INFO - 2025-09-18 06:39:35 --> Helper loaded: text_helper
INFO - 2025-09-18 06:39:35 --> Helper loaded: string_helper
INFO - 2025-09-18 06:39:35 --> Helper loaded: form_helper
INFO - 2025-09-18 06:39:35 --> Helper loaded: download_helper
INFO - 2025-09-18 06:39:35 --> Helper loaded: security_helper
INFO - 2025-09-18 06:39:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:39:35 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:39:35 --> Form Validation Class Initialized
INFO - 2025-09-18 06:39:35 --> Model "User_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:39:35 --> Controller Class Initialized
INFO - 2025-09-18 11:39:35 --> Model "Berita_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Galeri_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Video_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Agenda_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Tautan_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Mitra_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Prodi_model" initialized
INFO - 2025-09-18 11:39:35 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 11:39:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 11:39:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:39:35 --> Model "Log_model" initialized
INFO - 2025-09-18 11:39:35 --> Final output sent to browser
DEBUG - 2025-09-18 11:39:35 --> Total execution time: 0.0606
INFO - 2025-09-18 06:42:10 --> Config Class Initialized
INFO - 2025-09-18 06:42:10 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:42:10 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:42:10 --> Utf8 Class Initialized
INFO - 2025-09-18 06:42:10 --> URI Class Initialized
DEBUG - 2025-09-18 06:42:10 --> No URI present. Default controller set.
INFO - 2025-09-18 06:42:10 --> Router Class Initialized
INFO - 2025-09-18 06:42:10 --> Output Class Initialized
INFO - 2025-09-18 06:42:10 --> Security Class Initialized
DEBUG - 2025-09-18 06:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:42:10 --> CSRF cookie sent
INFO - 2025-09-18 06:42:10 --> Input Class Initialized
INFO - 2025-09-18 06:42:10 --> Language Class Initialized
INFO - 2025-09-18 06:42:10 --> Loader Class Initialized
INFO - 2025-09-18 06:42:10 --> Helper loaded: url_helper
INFO - 2025-09-18 06:42:10 --> Helper loaded: text_helper
INFO - 2025-09-18 06:42:10 --> Helper loaded: string_helper
INFO - 2025-09-18 06:42:10 --> Helper loaded: form_helper
INFO - 2025-09-18 06:42:10 --> Helper loaded: download_helper
INFO - 2025-09-18 06:42:10 --> Helper loaded: security_helper
INFO - 2025-09-18 06:42:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:42:10 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:42:10 --> Form Validation Class Initialized
INFO - 2025-09-18 06:42:10 --> Model "User_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:42:10 --> Controller Class Initialized
INFO - 2025-09-18 11:42:10 --> Model "Berita_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Galeri_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Video_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Agenda_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Tautan_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Mitra_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Prodi_model" initialized
INFO - 2025-09-18 11:42:10 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 11:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 11:42:10 --> Pagination Class Initialized
INFO - 2025-09-18 11:42:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 11:42:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:42:10 --> Model "Log_model" initialized
INFO - 2025-09-18 11:42:10 --> Final output sent to browser
DEBUG - 2025-09-18 11:42:10 --> Total execution time: 0.2658
INFO - 2025-09-18 06:42:22 --> Config Class Initialized
INFO - 2025-09-18 06:42:22 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:42:22 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:42:22 --> Utf8 Class Initialized
INFO - 2025-09-18 06:42:22 --> URI Class Initialized
INFO - 2025-09-18 06:42:22 --> Router Class Initialized
INFO - 2025-09-18 06:42:22 --> Output Class Initialized
INFO - 2025-09-18 06:42:22 --> Security Class Initialized
DEBUG - 2025-09-18 06:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:42:22 --> CSRF cookie sent
INFO - 2025-09-18 06:42:22 --> Input Class Initialized
INFO - 2025-09-18 06:42:22 --> Language Class Initialized
INFO - 2025-09-18 06:42:22 --> Loader Class Initialized
INFO - 2025-09-18 06:42:22 --> Helper loaded: url_helper
INFO - 2025-09-18 06:42:22 --> Helper loaded: text_helper
INFO - 2025-09-18 06:42:22 --> Helper loaded: string_helper
INFO - 2025-09-18 06:42:22 --> Helper loaded: form_helper
INFO - 2025-09-18 06:42:22 --> Helper loaded: download_helper
INFO - 2025-09-18 06:42:22 --> Helper loaded: security_helper
INFO - 2025-09-18 06:42:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:42:22 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:42:22 --> Form Validation Class Initialized
INFO - 2025-09-18 06:42:22 --> Model "User_model" initialized
INFO - 2025-09-18 11:42:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:42:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:42:22 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:42:22 --> Controller Class Initialized
INFO - 2025-09-18 11:42:22 --> Model "Download_model" initialized
INFO - 2025-09-18 11:42:22 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 11:42:22 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 11:42:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_kemahasiswaan.php
INFO - 2025-09-18 11:42:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:42:22 --> Model "Log_model" initialized
INFO - 2025-09-18 11:42:22 --> Final output sent to browser
DEBUG - 2025-09-18 11:42:22 --> Total execution time: 0.0613
INFO - 2025-09-18 06:42:26 --> Config Class Initialized
INFO - 2025-09-18 06:42:26 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:42:26 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:42:26 --> Utf8 Class Initialized
INFO - 2025-09-18 06:42:26 --> URI Class Initialized
INFO - 2025-09-18 06:42:26 --> Router Class Initialized
INFO - 2025-09-18 06:42:26 --> Output Class Initialized
INFO - 2025-09-18 06:42:26 --> Security Class Initialized
DEBUG - 2025-09-18 06:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:42:26 --> CSRF cookie sent
INFO - 2025-09-18 06:42:26 --> Input Class Initialized
INFO - 2025-09-18 06:42:26 --> Language Class Initialized
INFO - 2025-09-18 06:42:27 --> Loader Class Initialized
INFO - 2025-09-18 06:42:27 --> Helper loaded: url_helper
INFO - 2025-09-18 06:42:27 --> Helper loaded: text_helper
INFO - 2025-09-18 06:42:27 --> Helper loaded: string_helper
INFO - 2025-09-18 06:42:27 --> Helper loaded: form_helper
INFO - 2025-09-18 06:42:27 --> Helper loaded: download_helper
INFO - 2025-09-18 06:42:27 --> Helper loaded: security_helper
INFO - 2025-09-18 06:42:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:42:27 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:42:27 --> Form Validation Class Initialized
INFO - 2025-09-18 06:42:27 --> Model "User_model" initialized
INFO - 2025-09-18 11:42:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:42:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:42:27 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:42:27 --> Controller Class Initialized
INFO - 2025-09-18 11:42:27 --> Model "Download_model" initialized
INFO - 2025-09-18 11:42:27 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 11:42:27 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 11:42:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_layananpelanggan.php
INFO - 2025-09-18 11:42:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:42:27 --> Model "Log_model" initialized
INFO - 2025-09-18 11:42:27 --> Final output sent to browser
DEBUG - 2025-09-18 11:42:27 --> Total execution time: 0.0594
INFO - 2025-09-18 06:42:43 --> Config Class Initialized
INFO - 2025-09-18 06:42:43 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:42:43 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:42:43 --> Utf8 Class Initialized
INFO - 2025-09-18 06:42:43 --> URI Class Initialized
INFO - 2025-09-18 06:42:43 --> Router Class Initialized
INFO - 2025-09-18 06:42:43 --> Output Class Initialized
INFO - 2025-09-18 06:42:43 --> Security Class Initialized
DEBUG - 2025-09-18 06:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:42:43 --> CSRF cookie sent
INFO - 2025-09-18 06:42:43 --> Input Class Initialized
INFO - 2025-09-18 06:42:43 --> Language Class Initialized
INFO - 2025-09-18 06:42:43 --> Loader Class Initialized
INFO - 2025-09-18 06:42:43 --> Helper loaded: url_helper
INFO - 2025-09-18 06:42:43 --> Helper loaded: text_helper
INFO - 2025-09-18 06:42:43 --> Helper loaded: string_helper
INFO - 2025-09-18 06:42:43 --> Helper loaded: form_helper
INFO - 2025-09-18 06:42:43 --> Helper loaded: download_helper
INFO - 2025-09-18 06:42:43 --> Helper loaded: security_helper
INFO - 2025-09-18 06:42:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:42:43 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:42:43 --> Form Validation Class Initialized
INFO - 2025-09-18 06:42:43 --> Model "User_model" initialized
INFO - 2025-09-18 11:42:43 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:42:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:42:43 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:42:43 --> Controller Class Initialized
INFO - 2025-09-18 11:42:43 --> Model "Download_model" initialized
INFO - 2025-09-18 11:42:43 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 11:42:43 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 11:42:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2025-09-18 11:42:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:42:43 --> Model "Log_model" initialized
INFO - 2025-09-18 11:42:43 --> Final output sent to browser
DEBUG - 2025-09-18 11:42:43 --> Total execution time: 0.0759
INFO - 2025-09-18 06:44:35 --> Config Class Initialized
INFO - 2025-09-18 06:44:35 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:44:35 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:44:35 --> Utf8 Class Initialized
INFO - 2025-09-18 06:44:35 --> URI Class Initialized
INFO - 2025-09-18 06:44:35 --> Router Class Initialized
INFO - 2025-09-18 06:44:35 --> Output Class Initialized
INFO - 2025-09-18 06:44:35 --> Security Class Initialized
DEBUG - 2025-09-18 06:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:44:35 --> CSRF cookie sent
INFO - 2025-09-18 06:44:35 --> Input Class Initialized
INFO - 2025-09-18 06:44:35 --> Language Class Initialized
INFO - 2025-09-18 06:44:35 --> Loader Class Initialized
INFO - 2025-09-18 06:44:35 --> Helper loaded: url_helper
INFO - 2025-09-18 06:44:35 --> Helper loaded: text_helper
INFO - 2025-09-18 06:44:35 --> Helper loaded: string_helper
INFO - 2025-09-18 06:44:35 --> Helper loaded: form_helper
INFO - 2025-09-18 06:44:35 --> Helper loaded: download_helper
INFO - 2025-09-18 06:44:35 --> Helper loaded: security_helper
INFO - 2025-09-18 06:44:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:44:35 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:44:35 --> Form Validation Class Initialized
INFO - 2025-09-18 06:44:35 --> Model "User_model" initialized
INFO - 2025-09-18 11:44:35 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:44:35 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:44:35 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:44:35 --> Controller Class Initialized
INFO - 2025-09-18 11:44:35 --> Model "Pages_model" initialized
INFO - 2025-09-18 11:44:35 --> Model "Berita_model" initialized
INFO - 2025-09-18 11:44:35 --> Model "Download_model" initialized
INFO - 2025-09-18 11:44:35 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 11:44:35 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 11:44:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-09-18 11:44:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:44:35 --> Model "Log_model" initialized
INFO - 2025-09-18 11:44:35 --> Final output sent to browser
DEBUG - 2025-09-18 11:44:35 --> Total execution time: 0.0501
INFO - 2025-09-18 06:51:39 --> Config Class Initialized
INFO - 2025-09-18 06:51:39 --> Hooks Class Initialized
DEBUG - 2025-09-18 06:51:39 --> UTF-8 Support Enabled
INFO - 2025-09-18 06:51:39 --> Utf8 Class Initialized
INFO - 2025-09-18 06:51:39 --> URI Class Initialized
DEBUG - 2025-09-18 06:51:39 --> No URI present. Default controller set.
INFO - 2025-09-18 06:51:39 --> Router Class Initialized
INFO - 2025-09-18 06:51:39 --> Output Class Initialized
INFO - 2025-09-18 06:51:39 --> Security Class Initialized
DEBUG - 2025-09-18 06:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 06:51:39 --> CSRF cookie sent
INFO - 2025-09-18 06:51:39 --> Input Class Initialized
INFO - 2025-09-18 06:51:39 --> Language Class Initialized
INFO - 2025-09-18 06:51:39 --> Loader Class Initialized
INFO - 2025-09-18 06:51:39 --> Helper loaded: url_helper
INFO - 2025-09-18 06:51:39 --> Helper loaded: text_helper
INFO - 2025-09-18 06:51:39 --> Helper loaded: string_helper
INFO - 2025-09-18 06:51:39 --> Helper loaded: form_helper
INFO - 2025-09-18 06:51:39 --> Helper loaded: download_helper
INFO - 2025-09-18 06:51:39 --> Helper loaded: security_helper
INFO - 2025-09-18 06:51:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 06:51:39 --> Database Driver Class Initialized
DEBUG - 2025-09-18 06:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 06:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 06:51:39 --> Form Validation Class Initialized
INFO - 2025-09-18 06:51:39 --> Model "User_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Nav_model" initialized
INFO - 2025-09-18 11:51:39 --> Controller Class Initialized
INFO - 2025-09-18 11:51:39 --> Model "Berita_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Galeri_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Video_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Agenda_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Tautan_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Mitra_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Prodi_model" initialized
INFO - 2025-09-18 11:51:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 11:51:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 11:51:39 --> Pagination Class Initialized
INFO - 2025-09-18 11:51:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 11:51:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 11:51:39 --> Model "Log_model" initialized
INFO - 2025-09-18 11:51:39 --> Final output sent to browser
DEBUG - 2025-09-18 11:51:39 --> Total execution time: 0.0791
INFO - 2025-09-18 08:10:36 --> Config Class Initialized
INFO - 2025-09-18 08:10:36 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:10:36 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:10:36 --> Utf8 Class Initialized
INFO - 2025-09-18 08:10:36 --> URI Class Initialized
DEBUG - 2025-09-18 08:10:36 --> No URI present. Default controller set.
INFO - 2025-09-18 08:10:36 --> Router Class Initialized
INFO - 2025-09-18 08:10:36 --> Output Class Initialized
INFO - 2025-09-18 08:10:36 --> Security Class Initialized
DEBUG - 2025-09-18 08:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:10:36 --> CSRF cookie sent
INFO - 2025-09-18 08:10:36 --> Input Class Initialized
INFO - 2025-09-18 08:10:36 --> Language Class Initialized
INFO - 2025-09-18 08:10:36 --> Loader Class Initialized
INFO - 2025-09-18 08:10:36 --> Helper loaded: url_helper
INFO - 2025-09-18 08:10:36 --> Helper loaded: text_helper
INFO - 2025-09-18 08:10:36 --> Helper loaded: string_helper
INFO - 2025-09-18 08:10:36 --> Helper loaded: form_helper
INFO - 2025-09-18 08:10:36 --> Helper loaded: download_helper
INFO - 2025-09-18 08:10:36 --> Helper loaded: security_helper
INFO - 2025-09-18 08:10:36 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:10:36 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:10:36 --> Form Validation Class Initialized
INFO - 2025-09-18 08:10:36 --> Model "User_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:10:36 --> Controller Class Initialized
INFO - 2025-09-18 13:10:36 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Video_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:10:36 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 13:10:36 --> Pagination Class Initialized
INFO - 2025-09-18 13:10:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 13:10:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:10:36 --> Model "Log_model" initialized
INFO - 2025-09-18 13:10:36 --> Final output sent to browser
DEBUG - 2025-09-18 13:10:36 --> Total execution time: 0.1111
INFO - 2025-09-18 08:11:09 --> Config Class Initialized
INFO - 2025-09-18 08:11:09 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:11:09 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:11:09 --> Utf8 Class Initialized
INFO - 2025-09-18 08:11:09 --> URI Class Initialized
DEBUG - 2025-09-18 08:11:09 --> No URI present. Default controller set.
INFO - 2025-09-18 08:11:09 --> Router Class Initialized
INFO - 2025-09-18 08:11:09 --> Output Class Initialized
INFO - 2025-09-18 08:11:09 --> Security Class Initialized
DEBUG - 2025-09-18 08:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:11:09 --> CSRF cookie sent
INFO - 2025-09-18 08:11:09 --> Input Class Initialized
INFO - 2025-09-18 08:11:09 --> Language Class Initialized
INFO - 2025-09-18 08:11:09 --> Loader Class Initialized
INFO - 2025-09-18 08:11:09 --> Helper loaded: url_helper
INFO - 2025-09-18 08:11:09 --> Helper loaded: text_helper
INFO - 2025-09-18 08:11:09 --> Helper loaded: string_helper
INFO - 2025-09-18 08:11:09 --> Helper loaded: form_helper
INFO - 2025-09-18 08:11:09 --> Helper loaded: download_helper
INFO - 2025-09-18 08:11:09 --> Helper loaded: security_helper
INFO - 2025-09-18 08:11:09 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:11:09 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:11:09 --> Form Validation Class Initialized
INFO - 2025-09-18 08:11:09 --> Model "User_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:11:09 --> Controller Class Initialized
INFO - 2025-09-18 13:11:09 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Video_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:11:09 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 13:11:09 --> Pagination Class Initialized
INFO - 2025-09-18 13:11:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 13:11:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:11:09 --> Model "Log_model" initialized
INFO - 2025-09-18 13:11:09 --> Final output sent to browser
DEBUG - 2025-09-18 13:11:09 --> Total execution time: 0.2447
INFO - 2025-09-18 08:11:19 --> Config Class Initialized
INFO - 2025-09-18 08:11:19 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:11:19 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:11:19 --> Utf8 Class Initialized
INFO - 2025-09-18 08:11:19 --> URI Class Initialized
DEBUG - 2025-09-18 08:11:19 --> No URI present. Default controller set.
INFO - 2025-09-18 08:11:19 --> Router Class Initialized
INFO - 2025-09-18 08:11:19 --> Output Class Initialized
INFO - 2025-09-18 08:11:19 --> Security Class Initialized
DEBUG - 2025-09-18 08:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:11:19 --> CSRF cookie sent
INFO - 2025-09-18 08:11:19 --> Input Class Initialized
INFO - 2025-09-18 08:11:19 --> Language Class Initialized
INFO - 2025-09-18 08:11:19 --> Loader Class Initialized
INFO - 2025-09-18 08:11:19 --> Helper loaded: url_helper
INFO - 2025-09-18 08:11:19 --> Helper loaded: text_helper
INFO - 2025-09-18 08:11:19 --> Helper loaded: string_helper
INFO - 2025-09-18 08:11:19 --> Helper loaded: form_helper
INFO - 2025-09-18 08:11:19 --> Helper loaded: download_helper
INFO - 2025-09-18 08:11:19 --> Helper loaded: security_helper
INFO - 2025-09-18 08:11:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:11:19 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:11:19 --> Form Validation Class Initialized
INFO - 2025-09-18 08:11:19 --> Model "User_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:11:19 --> Controller Class Initialized
INFO - 2025-09-18 13:11:19 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Video_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:11:19 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:11:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 13:11:19 --> Pagination Class Initialized
INFO - 2025-09-18 13:11:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 13:11:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:11:19 --> Model "Log_model" initialized
INFO - 2025-09-18 13:11:19 --> Final output sent to browser
DEBUG - 2025-09-18 13:11:19 --> Total execution time: 0.3320
INFO - 2025-09-18 08:37:04 --> Config Class Initialized
INFO - 2025-09-18 08:37:04 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:37:04 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:37:04 --> Utf8 Class Initialized
INFO - 2025-09-18 08:37:04 --> URI Class Initialized
INFO - 2025-09-18 08:37:04 --> Router Class Initialized
INFO - 2025-09-18 08:37:04 --> Output Class Initialized
INFO - 2025-09-18 08:37:04 --> Security Class Initialized
DEBUG - 2025-09-18 08:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:37:04 --> CSRF cookie sent
INFO - 2025-09-18 08:37:04 --> Input Class Initialized
INFO - 2025-09-18 08:37:04 --> Language Class Initialized
INFO - 2025-09-18 08:37:04 --> Loader Class Initialized
INFO - 2025-09-18 08:37:04 --> Helper loaded: url_helper
INFO - 2025-09-18 08:37:04 --> Helper loaded: text_helper
INFO - 2025-09-18 08:37:04 --> Helper loaded: string_helper
INFO - 2025-09-18 08:37:04 --> Helper loaded: form_helper
INFO - 2025-09-18 08:37:04 --> Helper loaded: download_helper
INFO - 2025-09-18 08:37:04 --> Helper loaded: security_helper
INFO - 2025-09-18 08:37:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:37:04 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:37:04 --> Form Validation Class Initialized
INFO - 2025-09-18 08:37:04 --> Model "User_model" initialized
INFO - 2025-09-18 13:37:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:37:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:37:04 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:37:04 --> Controller Class Initialized
INFO - 2025-09-18 13:37:04 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:37:04 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:37:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-18 13:37:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 13:37:04 --> Model "Log_model" initialized
INFO - 2025-09-18 13:37:04 --> Final output sent to browser
DEBUG - 2025-09-18 13:37:04 --> Total execution time: 0.1584
INFO - 2025-09-18 08:39:39 --> Config Class Initialized
INFO - 2025-09-18 08:39:39 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:39:39 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:39:39 --> Utf8 Class Initialized
INFO - 2025-09-18 08:39:39 --> URI Class Initialized
INFO - 2025-09-18 08:39:39 --> Router Class Initialized
INFO - 2025-09-18 08:39:39 --> Output Class Initialized
INFO - 2025-09-18 08:39:39 --> Security Class Initialized
DEBUG - 2025-09-18 08:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:39:39 --> CSRF cookie sent
INFO - 2025-09-18 08:39:39 --> Input Class Initialized
INFO - 2025-09-18 08:39:39 --> Language Class Initialized
INFO - 2025-09-18 08:39:39 --> Loader Class Initialized
INFO - 2025-09-18 08:39:39 --> Helper loaded: url_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: text_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: string_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: form_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: download_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: security_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:39:39 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:39:39 --> Form Validation Class Initialized
INFO - 2025-09-18 08:39:39 --> Model "User_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:39:39 --> Controller Class Initialized
INFO - 2025-09-18 13:39:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 13:39:39 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 13:39:39 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:39:39 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 13:39:39 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 13:39:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 13:39:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:39:39 --> Model "Log_model" initialized
INFO - 2025-09-18 13:39:39 --> Final output sent to browser
DEBUG - 2025-09-18 13:39:39 --> Total execution time: 0.2435
INFO - 2025-09-18 08:39:39 --> Config Class Initialized
INFO - 2025-09-18 08:39:39 --> Hooks Class Initialized
INFO - 2025-09-18 08:39:39 --> Config Class Initialized
INFO - 2025-09-18 08:39:39 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:39:39 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:39:39 --> Utf8 Class Initialized
DEBUG - 2025-09-18 08:39:39 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:39:39 --> Utf8 Class Initialized
INFO - 2025-09-18 08:39:39 --> URI Class Initialized
INFO - 2025-09-18 08:39:39 --> URI Class Initialized
INFO - 2025-09-18 08:39:39 --> Router Class Initialized
INFO - 2025-09-18 08:39:39 --> Router Class Initialized
INFO - 2025-09-18 08:39:39 --> Output Class Initialized
INFO - 2025-09-18 08:39:39 --> Output Class Initialized
INFO - 2025-09-18 08:39:39 --> Security Class Initialized
INFO - 2025-09-18 08:39:39 --> Security Class Initialized
DEBUG - 2025-09-18 08:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-18 08:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:39:39 --> CSRF cookie sent
INFO - 2025-09-18 08:39:39 --> CSRF cookie sent
INFO - 2025-09-18 08:39:39 --> Input Class Initialized
INFO - 2025-09-18 08:39:39 --> Input Class Initialized
INFO - 2025-09-18 08:39:39 --> Language Class Initialized
INFO - 2025-09-18 08:39:39 --> Language Class Initialized
INFO - 2025-09-18 08:39:39 --> Loader Class Initialized
INFO - 2025-09-18 08:39:39 --> Loader Class Initialized
INFO - 2025-09-18 08:39:39 --> Helper loaded: url_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: url_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: text_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: text_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: string_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: string_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: form_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: download_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: form_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: download_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: security_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: security_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:39:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:39:39 --> Database Driver Class Initialized
INFO - 2025-09-18 08:39:39 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-18 08:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:39:39 --> Form Validation Class Initialized
INFO - 2025-09-18 08:39:39 --> Model "User_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:39:39 --> Controller Class Initialized
INFO - 2025-09-18 13:39:39 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Video_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:39:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 13:39:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:39:39 --> Model "Log_model" initialized
INFO - 2025-09-18 13:39:39 --> Final output sent to browser
DEBUG - 2025-09-18 13:39:39 --> Total execution time: 0.0990
INFO - 2025-09-18 08:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:39:39 --> Form Validation Class Initialized
INFO - 2025-09-18 08:39:39 --> Model "User_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:39:39 --> Controller Class Initialized
INFO - 2025-09-18 13:39:39 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Video_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:39:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:39:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 13:39:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:39:40 --> Model "Log_model" initialized
INFO - 2025-09-18 13:39:40 --> Final output sent to browser
DEBUG - 2025-09-18 13:39:40 --> Total execution time: 0.1458
INFO - 2025-09-18 08:41:00 --> Config Class Initialized
INFO - 2025-09-18 08:41:00 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:41:00 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:41:00 --> Utf8 Class Initialized
INFO - 2025-09-18 08:41:00 --> URI Class Initialized
DEBUG - 2025-09-18 08:41:00 --> No URI present. Default controller set.
INFO - 2025-09-18 08:41:00 --> Router Class Initialized
INFO - 2025-09-18 08:41:00 --> Output Class Initialized
INFO - 2025-09-18 08:41:00 --> Security Class Initialized
DEBUG - 2025-09-18 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:41:00 --> CSRF cookie sent
INFO - 2025-09-18 08:41:00 --> Input Class Initialized
INFO - 2025-09-18 08:41:00 --> Language Class Initialized
INFO - 2025-09-18 08:41:00 --> Loader Class Initialized
INFO - 2025-09-18 08:41:00 --> Helper loaded: url_helper
INFO - 2025-09-18 08:41:00 --> Helper loaded: text_helper
INFO - 2025-09-18 08:41:00 --> Helper loaded: string_helper
INFO - 2025-09-18 08:41:00 --> Helper loaded: form_helper
INFO - 2025-09-18 08:41:00 --> Helper loaded: download_helper
INFO - 2025-09-18 08:41:00 --> Helper loaded: security_helper
INFO - 2025-09-18 08:41:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:41:00 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:41:00 --> Form Validation Class Initialized
INFO - 2025-09-18 08:41:00 --> Model "User_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:41:00 --> Controller Class Initialized
INFO - 2025-09-18 13:41:00 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Video_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:41:00 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 13:41:00 --> Pagination Class Initialized
INFO - 2025-09-18 13:41:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 13:41:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:41:00 --> Model "Log_model" initialized
INFO - 2025-09-18 13:41:00 --> Final output sent to browser
DEBUG - 2025-09-18 13:41:00 --> Total execution time: 0.2695
INFO - 2025-09-18 08:41:52 --> Config Class Initialized
INFO - 2025-09-18 08:41:52 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:41:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:41:52 --> Utf8 Class Initialized
INFO - 2025-09-18 08:41:52 --> URI Class Initialized
INFO - 2025-09-18 08:41:52 --> Router Class Initialized
INFO - 2025-09-18 08:41:52 --> Output Class Initialized
INFO - 2025-09-18 08:41:52 --> Security Class Initialized
DEBUG - 2025-09-18 08:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:41:52 --> CSRF cookie sent
INFO - 2025-09-18 08:41:52 --> Input Class Initialized
INFO - 2025-09-18 08:41:52 --> Language Class Initialized
INFO - 2025-09-18 08:41:52 --> Loader Class Initialized
INFO - 2025-09-18 08:41:52 --> Helper loaded: url_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: text_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: string_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: form_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: download_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: security_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:41:52 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:41:52 --> Form Validation Class Initialized
INFO - 2025-09-18 08:41:52 --> Model "User_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:41:52 --> Controller Class Initialized
INFO - 2025-09-18 13:41:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 13:41:52 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 0
ERROR - 2025-09-18 13:41:52 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:41:52 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 13:41:52 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 13:41:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 13:41:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:41:52 --> Model "Log_model" initialized
INFO - 2025-09-18 13:41:52 --> Final output sent to browser
DEBUG - 2025-09-18 13:41:52 --> Total execution time: 0.1611
INFO - 2025-09-18 08:41:52 --> Config Class Initialized
INFO - 2025-09-18 08:41:52 --> Hooks Class Initialized
INFO - 2025-09-18 08:41:52 --> Config Class Initialized
INFO - 2025-09-18 08:41:52 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:41:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:41:52 --> Utf8 Class Initialized
INFO - 2025-09-18 08:41:52 --> URI Class Initialized
DEBUG - 2025-09-18 08:41:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:41:52 --> Utf8 Class Initialized
INFO - 2025-09-18 08:41:52 --> Router Class Initialized
INFO - 2025-09-18 08:41:52 --> URI Class Initialized
INFO - 2025-09-18 08:41:52 --> Output Class Initialized
INFO - 2025-09-18 08:41:52 --> Router Class Initialized
INFO - 2025-09-18 08:41:52 --> Security Class Initialized
DEBUG - 2025-09-18 08:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:41:52 --> Output Class Initialized
INFO - 2025-09-18 08:41:52 --> CSRF cookie sent
INFO - 2025-09-18 08:41:52 --> Input Class Initialized
INFO - 2025-09-18 08:41:52 --> Security Class Initialized
INFO - 2025-09-18 08:41:52 --> Language Class Initialized
DEBUG - 2025-09-18 08:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:41:52 --> CSRF cookie sent
INFO - 2025-09-18 08:41:52 --> Input Class Initialized
INFO - 2025-09-18 08:41:52 --> Language Class Initialized
INFO - 2025-09-18 08:41:52 --> Loader Class Initialized
INFO - 2025-09-18 08:41:52 --> Helper loaded: url_helper
INFO - 2025-09-18 08:41:52 --> Loader Class Initialized
INFO - 2025-09-18 08:41:52 --> Helper loaded: text_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: string_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: url_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: text_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: form_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: string_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: download_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: security_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: form_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: download_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: security_helper
INFO - 2025-09-18 08:41:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:41:52 --> Database Driver Class Initialized
INFO - 2025-09-18 08:41:52 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:41:52 --> Form Validation Class Initialized
DEBUG - 2025-09-18 08:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:41:52 --> Model "User_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:41:52 --> Controller Class Initialized
INFO - 2025-09-18 13:41:52 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Video_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:41:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 13:41:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:41:52 --> Model "Log_model" initialized
INFO - 2025-09-18 13:41:52 --> Final output sent to browser
DEBUG - 2025-09-18 13:41:52 --> Total execution time: 0.0942
INFO - 2025-09-18 08:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:41:52 --> Form Validation Class Initialized
INFO - 2025-09-18 08:41:52 --> Model "User_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:41:52 --> Controller Class Initialized
INFO - 2025-09-18 13:41:52 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Video_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:41:52 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:41:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 13:41:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:41:52 --> Model "Log_model" initialized
INFO - 2025-09-18 13:41:52 --> Final output sent to browser
DEBUG - 2025-09-18 13:41:52 --> Total execution time: 0.1347
INFO - 2025-09-18 08:42:30 --> Config Class Initialized
INFO - 2025-09-18 08:42:30 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:42:30 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:42:30 --> Utf8 Class Initialized
INFO - 2025-09-18 08:42:30 --> URI Class Initialized
INFO - 2025-09-18 08:42:30 --> Router Class Initialized
INFO - 2025-09-18 08:42:30 --> Output Class Initialized
INFO - 2025-09-18 08:42:30 --> Security Class Initialized
DEBUG - 2025-09-18 08:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:42:30 --> CSRF cookie sent
INFO - 2025-09-18 08:42:30 --> CSRF token verified
INFO - 2025-09-18 08:42:30 --> Input Class Initialized
INFO - 2025-09-18 08:42:30 --> Language Class Initialized
INFO - 2025-09-18 08:42:30 --> Loader Class Initialized
INFO - 2025-09-18 08:42:30 --> Helper loaded: url_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: text_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: string_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: form_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: download_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: security_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:42:30 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:42:30 --> Form Validation Class Initialized
INFO - 2025-09-18 08:42:30 --> Model "User_model" initialized
INFO - 2025-09-18 13:42:30 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:42:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:42:30 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:42:30 --> Controller Class Initialized
INFO - 2025-09-18 13:42:30 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:42:30 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:42:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 08:42:30 --> Config Class Initialized
INFO - 2025-09-18 08:42:30 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:42:30 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:42:30 --> Utf8 Class Initialized
INFO - 2025-09-18 08:42:30 --> URI Class Initialized
INFO - 2025-09-18 08:42:30 --> Router Class Initialized
INFO - 2025-09-18 08:42:30 --> Output Class Initialized
INFO - 2025-09-18 08:42:30 --> Security Class Initialized
DEBUG - 2025-09-18 08:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:42:30 --> CSRF cookie sent
INFO - 2025-09-18 08:42:30 --> Input Class Initialized
INFO - 2025-09-18 08:42:30 --> Language Class Initialized
INFO - 2025-09-18 08:42:30 --> Loader Class Initialized
INFO - 2025-09-18 08:42:30 --> Helper loaded: url_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: text_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: string_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: form_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: download_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: security_helper
INFO - 2025-09-18 08:42:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:42:30 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:42:30 --> Form Validation Class Initialized
INFO - 2025-09-18 08:42:30 --> Model "User_model" initialized
INFO - 2025-09-18 13:42:30 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:42:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:42:30 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:42:30 --> Controller Class Initialized
INFO - 2025-09-18 13:42:30 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:42:30 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:42:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-18 13:42:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 13:42:30 --> Model "Log_model" initialized
INFO - 2025-09-18 13:42:30 --> Final output sent to browser
DEBUG - 2025-09-18 13:42:30 --> Total execution time: 0.1163
INFO - 2025-09-18 08:42:34 --> Config Class Initialized
INFO - 2025-09-18 08:42:34 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:42:34 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:42:34 --> Utf8 Class Initialized
INFO - 2025-09-18 08:42:34 --> URI Class Initialized
INFO - 2025-09-18 08:42:34 --> Router Class Initialized
INFO - 2025-09-18 08:42:34 --> Output Class Initialized
INFO - 2025-09-18 08:42:34 --> Security Class Initialized
DEBUG - 2025-09-18 08:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:42:34 --> CSRF cookie sent
INFO - 2025-09-18 08:42:34 --> Input Class Initialized
INFO - 2025-09-18 08:42:34 --> Language Class Initialized
INFO - 2025-09-18 08:42:34 --> Loader Class Initialized
INFO - 2025-09-18 08:42:34 --> Helper loaded: url_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: text_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: string_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: form_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: download_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: security_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:42:34 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:42:34 --> Form Validation Class Initialized
INFO - 2025-09-18 08:42:34 --> Model "User_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:42:34 --> Controller Class Initialized
INFO - 2025-09-18 13:42:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 13:42:34 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 0
ERROR - 2025-09-18 13:42:34 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:42:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:42:34 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 13:42:34 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 13:42:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 13:42:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:42:34 --> Model "Log_model" initialized
INFO - 2025-09-18 13:42:34 --> Final output sent to browser
DEBUG - 2025-09-18 13:42:34 --> Total execution time: 0.1727
INFO - 2025-09-18 08:42:34 --> Config Class Initialized
INFO - 2025-09-18 08:42:34 --> Hooks Class Initialized
INFO - 2025-09-18 08:42:34 --> Config Class Initialized
INFO - 2025-09-18 08:42:34 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:42:34 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:42:34 --> Utf8 Class Initialized
DEBUG - 2025-09-18 08:42:34 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:42:34 --> Utf8 Class Initialized
INFO - 2025-09-18 08:42:34 --> URI Class Initialized
INFO - 2025-09-18 08:42:34 --> URI Class Initialized
INFO - 2025-09-18 08:42:34 --> Router Class Initialized
INFO - 2025-09-18 08:42:34 --> Router Class Initialized
INFO - 2025-09-18 08:42:34 --> Output Class Initialized
INFO - 2025-09-18 08:42:34 --> Output Class Initialized
INFO - 2025-09-18 08:42:34 --> Security Class Initialized
INFO - 2025-09-18 08:42:34 --> Security Class Initialized
DEBUG - 2025-09-18 08:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:42:34 --> CSRF cookie sent
DEBUG - 2025-09-18 08:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:42:34 --> Input Class Initialized
INFO - 2025-09-18 08:42:34 --> CSRF cookie sent
INFO - 2025-09-18 08:42:34 --> Input Class Initialized
INFO - 2025-09-18 08:42:34 --> Language Class Initialized
INFO - 2025-09-18 08:42:34 --> Language Class Initialized
INFO - 2025-09-18 08:42:34 --> Loader Class Initialized
INFO - 2025-09-18 08:42:34 --> Loader Class Initialized
INFO - 2025-09-18 08:42:34 --> Helper loaded: url_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: url_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: text_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: text_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: string_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: string_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: form_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: form_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: download_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: download_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: security_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: security_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:42:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:42:34 --> Database Driver Class Initialized
INFO - 2025-09-18 08:42:34 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:42:34 --> Form Validation Class Initialized
INFO - 2025-09-18 08:42:34 --> Model "User_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Kunjungan_model" initialized
DEBUG - 2025-09-18 08:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 13:42:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:42:34 --> Controller Class Initialized
INFO - 2025-09-18 13:42:34 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Video_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:42:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 13:42:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:42:34 --> Model "Log_model" initialized
INFO - 2025-09-18 13:42:34 --> Final output sent to browser
DEBUG - 2025-09-18 13:42:34 --> Total execution time: 0.0992
INFO - 2025-09-18 08:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:42:34 --> Form Validation Class Initialized
INFO - 2025-09-18 08:42:34 --> Model "User_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:42:34 --> Controller Class Initialized
INFO - 2025-09-18 13:42:34 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Video_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:42:34 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:42:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 13:42:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:42:34 --> Model "Log_model" initialized
INFO - 2025-09-18 13:42:34 --> Final output sent to browser
DEBUG - 2025-09-18 13:42:34 --> Total execution time: 0.1407
INFO - 2025-09-18 08:42:41 --> Config Class Initialized
INFO - 2025-09-18 08:42:41 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:42:41 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:42:41 --> Utf8 Class Initialized
INFO - 2025-09-18 08:42:41 --> URI Class Initialized
INFO - 2025-09-18 08:42:41 --> Router Class Initialized
INFO - 2025-09-18 08:42:41 --> Output Class Initialized
INFO - 2025-09-18 08:42:41 --> Security Class Initialized
DEBUG - 2025-09-18 08:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:42:41 --> CSRF cookie sent
INFO - 2025-09-18 08:42:41 --> Input Class Initialized
INFO - 2025-09-18 08:42:41 --> Language Class Initialized
INFO - 2025-09-18 08:42:41 --> Loader Class Initialized
INFO - 2025-09-18 08:42:41 --> Helper loaded: url_helper
INFO - 2025-09-18 08:42:41 --> Helper loaded: text_helper
INFO - 2025-09-18 08:42:41 --> Helper loaded: string_helper
INFO - 2025-09-18 08:42:41 --> Helper loaded: form_helper
INFO - 2025-09-18 08:42:41 --> Helper loaded: download_helper
INFO - 2025-09-18 08:42:41 --> Helper loaded: security_helper
INFO - 2025-09-18 08:42:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:42:41 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:42:41 --> Form Validation Class Initialized
INFO - 2025-09-18 08:42:41 --> Model "User_model" initialized
INFO - 2025-09-18 13:42:41 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:42:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:42:41 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:42:41 --> Controller Class Initialized
INFO - 2025-09-18 13:42:41 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 13:42:42 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 0
ERROR - 2025-09-18 13:42:42 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:42:42 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 13:42:42 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 13:42:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 13:42:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:42:42 --> Model "Log_model" initialized
INFO - 2025-09-18 13:42:42 --> Final output sent to browser
DEBUG - 2025-09-18 13:42:42 --> Total execution time: 0.1625
INFO - 2025-09-18 08:42:42 --> Config Class Initialized
INFO - 2025-09-18 08:42:42 --> Hooks Class Initialized
INFO - 2025-09-18 08:42:42 --> Config Class Initialized
INFO - 2025-09-18 08:42:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:42:42 --> UTF-8 Support Enabled
DEBUG - 2025-09-18 08:42:42 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:42:42 --> Utf8 Class Initialized
INFO - 2025-09-18 08:42:42 --> Utf8 Class Initialized
INFO - 2025-09-18 08:42:42 --> URI Class Initialized
INFO - 2025-09-18 08:42:42 --> URI Class Initialized
INFO - 2025-09-18 08:42:42 --> Router Class Initialized
INFO - 2025-09-18 08:42:42 --> Router Class Initialized
INFO - 2025-09-18 08:42:42 --> Output Class Initialized
INFO - 2025-09-18 08:42:42 --> Output Class Initialized
INFO - 2025-09-18 08:42:42 --> Security Class Initialized
INFO - 2025-09-18 08:42:42 --> Security Class Initialized
DEBUG - 2025-09-18 08:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-18 08:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:42:42 --> CSRF cookie sent
INFO - 2025-09-18 08:42:42 --> CSRF cookie sent
INFO - 2025-09-18 08:42:42 --> Input Class Initialized
INFO - 2025-09-18 08:42:42 --> Input Class Initialized
INFO - 2025-09-18 08:42:42 --> Language Class Initialized
INFO - 2025-09-18 08:42:42 --> Language Class Initialized
INFO - 2025-09-18 08:42:42 --> Loader Class Initialized
INFO - 2025-09-18 08:42:42 --> Loader Class Initialized
INFO - 2025-09-18 08:42:42 --> Helper loaded: url_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: url_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: text_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: text_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: string_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: string_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: form_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: form_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: download_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: download_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: security_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: security_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:42:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:42:42 --> Database Driver Class Initialized
INFO - 2025-09-18 08:42:42 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:42:42 --> Form Validation Class Initialized
INFO - 2025-09-18 08:42:42 --> Model "User_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:42:42 --> Controller Class Initialized
INFO - 2025-09-18 13:42:42 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Video_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Mitra_model" initialized
DEBUG - 2025-09-18 08:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 13:42:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:42:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 13:42:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:42:42 --> Model "Log_model" initialized
INFO - 2025-09-18 13:42:42 --> Final output sent to browser
DEBUG - 2025-09-18 13:42:42 --> Total execution time: 0.0903
INFO - 2025-09-18 08:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:42:42 --> Form Validation Class Initialized
INFO - 2025-09-18 08:42:42 --> Model "User_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:42:42 --> Controller Class Initialized
INFO - 2025-09-18 13:42:42 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Video_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:42:42 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:42:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 13:42:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:42:42 --> Model "Log_model" initialized
INFO - 2025-09-18 13:42:42 --> Final output sent to browser
DEBUG - 2025-09-18 13:42:42 --> Total execution time: 0.1329
INFO - 2025-09-18 08:42:59 --> Config Class Initialized
INFO - 2025-09-18 08:42:59 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:42:59 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:42:59 --> Utf8 Class Initialized
INFO - 2025-09-18 08:42:59 --> URI Class Initialized
INFO - 2025-09-18 08:42:59 --> Router Class Initialized
INFO - 2025-09-18 08:42:59 --> Output Class Initialized
INFO - 2025-09-18 08:42:59 --> Security Class Initialized
DEBUG - 2025-09-18 08:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:42:59 --> CSRF cookie sent
INFO - 2025-09-18 08:42:59 --> Input Class Initialized
INFO - 2025-09-18 08:42:59 --> Language Class Initialized
INFO - 2025-09-18 08:42:59 --> Loader Class Initialized
INFO - 2025-09-18 08:42:59 --> Helper loaded: url_helper
INFO - 2025-09-18 08:42:59 --> Helper loaded: text_helper
INFO - 2025-09-18 08:42:59 --> Helper loaded: string_helper
INFO - 2025-09-18 08:42:59 --> Helper loaded: form_helper
INFO - 2025-09-18 08:42:59 --> Helper loaded: download_helper
INFO - 2025-09-18 08:42:59 --> Helper loaded: security_helper
INFO - 2025-09-18 08:42:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:42:59 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:42:59 --> Form Validation Class Initialized
INFO - 2025-09-18 08:42:59 --> Model "User_model" initialized
INFO - 2025-09-18 13:42:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:42:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:42:59 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:42:59 --> Controller Class Initialized
INFO - 2025-09-18 13:42:59 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:42:59 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:42:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-18 13:42:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 13:42:59 --> Model "Log_model" initialized
INFO - 2025-09-18 13:42:59 --> Final output sent to browser
DEBUG - 2025-09-18 13:42:59 --> Total execution time: 0.1079
INFO - 2025-09-18 08:44:37 --> Config Class Initialized
INFO - 2025-09-18 08:44:37 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:44:37 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:44:37 --> Utf8 Class Initialized
INFO - 2025-09-18 08:44:37 --> URI Class Initialized
INFO - 2025-09-18 08:44:37 --> Router Class Initialized
INFO - 2025-09-18 08:44:37 --> Output Class Initialized
INFO - 2025-09-18 08:44:37 --> Security Class Initialized
DEBUG - 2025-09-18 08:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:44:37 --> CSRF cookie sent
INFO - 2025-09-18 08:44:37 --> CSRF token verified
INFO - 2025-09-18 08:44:37 --> Input Class Initialized
INFO - 2025-09-18 08:44:37 --> Language Class Initialized
INFO - 2025-09-18 08:44:37 --> Loader Class Initialized
INFO - 2025-09-18 08:44:37 --> Helper loaded: url_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: text_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: string_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: form_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: download_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: security_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:44:37 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:44:37 --> Form Validation Class Initialized
INFO - 2025-09-18 08:44:37 --> Model "User_model" initialized
INFO - 2025-09-18 13:44:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:44:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:44:37 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:44:37 --> Controller Class Initialized
INFO - 2025-09-18 13:44:37 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:44:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:44:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 08:44:37 --> Config Class Initialized
INFO - 2025-09-18 08:44:37 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:44:37 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:44:37 --> Utf8 Class Initialized
INFO - 2025-09-18 08:44:37 --> URI Class Initialized
INFO - 2025-09-18 08:44:37 --> Router Class Initialized
INFO - 2025-09-18 08:44:37 --> Output Class Initialized
INFO - 2025-09-18 08:44:37 --> Security Class Initialized
DEBUG - 2025-09-18 08:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:44:37 --> CSRF cookie sent
INFO - 2025-09-18 08:44:37 --> Input Class Initialized
INFO - 2025-09-18 08:44:37 --> Language Class Initialized
INFO - 2025-09-18 08:44:37 --> Loader Class Initialized
INFO - 2025-09-18 08:44:37 --> Helper loaded: url_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: text_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: string_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: form_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: download_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: security_helper
INFO - 2025-09-18 08:44:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:44:37 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:44:37 --> Form Validation Class Initialized
INFO - 2025-09-18 08:44:37 --> Model "User_model" initialized
INFO - 2025-09-18 13:44:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:44:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:44:37 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:44:37 --> Controller Class Initialized
INFO - 2025-09-18 13:44:37 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:44:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:44:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-18 13:44:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 13:44:37 --> Model "Log_model" initialized
INFO - 2025-09-18 13:44:37 --> Final output sent to browser
DEBUG - 2025-09-18 13:44:37 --> Total execution time: 0.1234
INFO - 2025-09-18 08:45:02 --> Config Class Initialized
INFO - 2025-09-18 08:45:02 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:45:02 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:45:02 --> Utf8 Class Initialized
INFO - 2025-09-18 08:45:02 --> URI Class Initialized
INFO - 2025-09-18 08:45:02 --> Router Class Initialized
INFO - 2025-09-18 08:45:02 --> Output Class Initialized
INFO - 2025-09-18 08:45:02 --> Security Class Initialized
DEBUG - 2025-09-18 08:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:45:02 --> CSRF cookie sent
INFO - 2025-09-18 08:45:02 --> Input Class Initialized
INFO - 2025-09-18 08:45:02 --> Language Class Initialized
INFO - 2025-09-18 08:45:02 --> Loader Class Initialized
INFO - 2025-09-18 08:45:02 --> Helper loaded: url_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: text_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: string_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: form_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: download_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: security_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:45:02 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:45:02 --> Form Validation Class Initialized
INFO - 2025-09-18 08:45:02 --> Model "User_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:45:02 --> Controller Class Initialized
INFO - 2025-09-18 13:45:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 13:45:02 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 13:45:02 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:45:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:45:02 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 13:45:02 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 13:45:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 13:45:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:45:02 --> Model "Log_model" initialized
INFO - 2025-09-18 13:45:02 --> Final output sent to browser
DEBUG - 2025-09-18 13:45:02 --> Total execution time: 0.1738
INFO - 2025-09-18 08:45:02 --> Config Class Initialized
INFO - 2025-09-18 08:45:02 --> Config Class Initialized
INFO - 2025-09-18 08:45:02 --> Hooks Class Initialized
INFO - 2025-09-18 08:45:02 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:45:02 --> UTF-8 Support Enabled
DEBUG - 2025-09-18 08:45:02 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:45:02 --> Utf8 Class Initialized
INFO - 2025-09-18 08:45:02 --> Utf8 Class Initialized
INFO - 2025-09-18 08:45:02 --> URI Class Initialized
INFO - 2025-09-18 08:45:02 --> URI Class Initialized
INFO - 2025-09-18 08:45:02 --> Router Class Initialized
INFO - 2025-09-18 08:45:02 --> Router Class Initialized
INFO - 2025-09-18 08:45:02 --> Output Class Initialized
INFO - 2025-09-18 08:45:02 --> Output Class Initialized
INFO - 2025-09-18 08:45:02 --> Security Class Initialized
INFO - 2025-09-18 08:45:02 --> Security Class Initialized
DEBUG - 2025-09-18 08:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:45:02 --> CSRF cookie sent
INFO - 2025-09-18 08:45:02 --> Input Class Initialized
DEBUG - 2025-09-18 08:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:45:02 --> CSRF cookie sent
INFO - 2025-09-18 08:45:02 --> Input Class Initialized
INFO - 2025-09-18 08:45:02 --> Language Class Initialized
INFO - 2025-09-18 08:45:02 --> Language Class Initialized
INFO - 2025-09-18 08:45:02 --> Loader Class Initialized
INFO - 2025-09-18 08:45:02 --> Loader Class Initialized
INFO - 2025-09-18 08:45:02 --> Helper loaded: url_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: url_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: text_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: string_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: text_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: string_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: form_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: form_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: download_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: download_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: security_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: security_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:45:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:45:02 --> Database Driver Class Initialized
INFO - 2025-09-18 08:45:02 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:45:02 --> Form Validation Class Initialized
INFO - 2025-09-18 08:45:02 --> Model "User_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-18 08:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 13:45:02 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:45:02 --> Controller Class Initialized
INFO - 2025-09-18 13:45:02 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Video_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:45:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 13:45:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:45:02 --> Model "Log_model" initialized
INFO - 2025-09-18 13:45:02 --> Final output sent to browser
DEBUG - 2025-09-18 13:45:02 --> Total execution time: 0.0917
INFO - 2025-09-18 08:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:45:02 --> Form Validation Class Initialized
INFO - 2025-09-18 08:45:02 --> Model "User_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:45:02 --> Controller Class Initialized
INFO - 2025-09-18 13:45:02 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Video_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:45:02 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:45:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 13:45:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:45:02 --> Model "Log_model" initialized
INFO - 2025-09-18 13:45:02 --> Final output sent to browser
DEBUG - 2025-09-18 13:45:02 --> Total execution time: 0.1368
INFO - 2025-09-18 08:45:47 --> Config Class Initialized
INFO - 2025-09-18 08:45:47 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:45:47 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:45:47 --> Utf8 Class Initialized
INFO - 2025-09-18 08:45:47 --> URI Class Initialized
INFO - 2025-09-18 08:45:47 --> Router Class Initialized
INFO - 2025-09-18 08:45:47 --> Output Class Initialized
INFO - 2025-09-18 08:45:47 --> Security Class Initialized
DEBUG - 2025-09-18 08:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:45:47 --> CSRF cookie sent
INFO - 2025-09-18 08:45:47 --> Input Class Initialized
INFO - 2025-09-18 08:45:47 --> Language Class Initialized
INFO - 2025-09-18 08:45:47 --> Loader Class Initialized
INFO - 2025-09-18 08:45:47 --> Helper loaded: url_helper
INFO - 2025-09-18 08:45:47 --> Helper loaded: text_helper
INFO - 2025-09-18 08:45:47 --> Helper loaded: string_helper
INFO - 2025-09-18 08:45:47 --> Helper loaded: form_helper
INFO - 2025-09-18 08:45:47 --> Helper loaded: download_helper
INFO - 2025-09-18 08:45:47 --> Helper loaded: security_helper
INFO - 2025-09-18 08:45:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:45:47 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:45:47 --> Form Validation Class Initialized
INFO - 2025-09-18 08:45:47 --> Model "User_model" initialized
INFO - 2025-09-18 13:45:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:45:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:45:47 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:45:47 --> Controller Class Initialized
INFO - 2025-09-18 13:45:47 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:45:47 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:45:47 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:45:47 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 13:45:47 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 13:45:47 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:45:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:45:48 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 13:45:48 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 13:45:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 13:45:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:45:48 --> Model "Log_model" initialized
INFO - 2025-09-18 13:45:48 --> Final output sent to browser
DEBUG - 2025-09-18 13:45:48 --> Total execution time: 0.8323
INFO - 2025-09-18 08:46:15 --> Config Class Initialized
INFO - 2025-09-18 08:46:15 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:46:15 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:46:15 --> Utf8 Class Initialized
INFO - 2025-09-18 08:46:15 --> URI Class Initialized
INFO - 2025-09-18 08:46:15 --> Router Class Initialized
INFO - 2025-09-18 08:46:15 --> Output Class Initialized
INFO - 2025-09-18 08:46:15 --> Security Class Initialized
DEBUG - 2025-09-18 08:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:46:15 --> CSRF cookie sent
INFO - 2025-09-18 08:46:15 --> Input Class Initialized
INFO - 2025-09-18 08:46:15 --> Language Class Initialized
INFO - 2025-09-18 08:46:15 --> Loader Class Initialized
INFO - 2025-09-18 08:46:15 --> Helper loaded: url_helper
INFO - 2025-09-18 08:46:15 --> Helper loaded: text_helper
INFO - 2025-09-18 08:46:15 --> Helper loaded: string_helper
INFO - 2025-09-18 08:46:15 --> Helper loaded: form_helper
INFO - 2025-09-18 08:46:15 --> Helper loaded: download_helper
INFO - 2025-09-18 08:46:15 --> Helper loaded: security_helper
INFO - 2025-09-18 08:46:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:46:15 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:46:15 --> Form Validation Class Initialized
INFO - 2025-09-18 08:46:15 --> Model "User_model" initialized
INFO - 2025-09-18 13:46:15 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:46:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:46:15 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:46:15 --> Controller Class Initialized
INFO - 2025-09-18 13:46:15 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:46:15 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:46:15 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:46:15 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 13:46:15 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 13:46:15 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:46:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:46:15 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 13:46:15 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 13:46:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 13:46:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:46:15 --> Model "Log_model" initialized
INFO - 2025-09-18 13:46:15 --> Final output sent to browser
DEBUG - 2025-09-18 13:46:15 --> Total execution time: 0.8411
INFO - 2025-09-18 08:46:26 --> Config Class Initialized
INFO - 2025-09-18 08:46:26 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:46:26 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:46:26 --> Utf8 Class Initialized
INFO - 2025-09-18 08:46:29 --> Config Class Initialized
INFO - 2025-09-18 08:46:29 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:46:29 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:46:29 --> Utf8 Class Initialized
INFO - 2025-09-18 08:46:29 --> URI Class Initialized
INFO - 2025-09-18 08:46:29 --> Router Class Initialized
INFO - 2025-09-18 08:46:29 --> Output Class Initialized
INFO - 2025-09-18 08:46:29 --> Security Class Initialized
DEBUG - 2025-09-18 08:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:46:29 --> CSRF cookie sent
INFO - 2025-09-18 08:46:29 --> Input Class Initialized
INFO - 2025-09-18 08:46:29 --> Language Class Initialized
INFO - 2025-09-18 08:46:29 --> Loader Class Initialized
INFO - 2025-09-18 08:46:29 --> Helper loaded: url_helper
INFO - 2025-09-18 08:46:29 --> Helper loaded: text_helper
INFO - 2025-09-18 08:46:29 --> Helper loaded: string_helper
INFO - 2025-09-18 08:46:29 --> Helper loaded: form_helper
INFO - 2025-09-18 08:46:29 --> Helper loaded: download_helper
INFO - 2025-09-18 08:46:29 --> Helper loaded: security_helper
INFO - 2025-09-18 08:46:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:46:29 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:46:29 --> Form Validation Class Initialized
INFO - 2025-09-18 08:46:29 --> Model "User_model" initialized
INFO - 2025-09-18 13:46:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:46:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:46:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:46:29 --> Controller Class Initialized
INFO - 2025-09-18 13:46:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:46:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:46:29 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:46:29 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 13:46:29 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 13:46:29 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:46:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:46:29 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 13:46:29 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 13:46:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 13:46:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:46:29 --> Model "Log_model" initialized
INFO - 2025-09-18 13:46:29 --> Final output sent to browser
DEBUG - 2025-09-18 13:46:29 --> Total execution time: 0.2546
INFO - 2025-09-18 08:47:57 --> Config Class Initialized
INFO - 2025-09-18 08:47:57 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:47:57 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:47:57 --> Utf8 Class Initialized
INFO - 2025-09-18 08:47:57 --> URI Class Initialized
INFO - 2025-09-18 08:47:57 --> Router Class Initialized
INFO - 2025-09-18 08:47:57 --> Output Class Initialized
INFO - 2025-09-18 08:47:57 --> Security Class Initialized
DEBUG - 2025-09-18 08:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:47:57 --> CSRF cookie sent
INFO - 2025-09-18 08:47:57 --> Input Class Initialized
INFO - 2025-09-18 08:47:57 --> Language Class Initialized
INFO - 2025-09-18 08:47:57 --> Loader Class Initialized
INFO - 2025-09-18 08:47:57 --> Helper loaded: url_helper
INFO - 2025-09-18 08:47:57 --> Helper loaded: text_helper
INFO - 2025-09-18 08:47:57 --> Helper loaded: string_helper
INFO - 2025-09-18 08:47:57 --> Helper loaded: form_helper
INFO - 2025-09-18 08:47:57 --> Helper loaded: download_helper
INFO - 2025-09-18 08:47:57 --> Helper loaded: security_helper
INFO - 2025-09-18 08:47:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:47:57 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:47:57 --> Form Validation Class Initialized
INFO - 2025-09-18 08:47:57 --> Model "User_model" initialized
INFO - 2025-09-18 13:47:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:47:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:47:57 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:47:57 --> Controller Class Initialized
INFO - 2025-09-18 13:47:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:47:57 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:47:57 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:47:57 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 13:47:57 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 13:47:57 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:47:58 --> Severity: Notice --> Undefined property: stdClass::$slug D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 71
ERROR - 2025-09-18 13:47:58 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 13:47:58 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 13:47:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 13:47:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:47:58 --> Model "Log_model" initialized
INFO - 2025-09-18 13:47:58 --> Final output sent to browser
DEBUG - 2025-09-18 13:47:58 --> Total execution time: 0.5078
INFO - 2025-09-18 08:52:27 --> Config Class Initialized
INFO - 2025-09-18 08:52:27 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:52:27 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:52:27 --> Utf8 Class Initialized
INFO - 2025-09-18 08:52:27 --> URI Class Initialized
INFO - 2025-09-18 08:52:27 --> Router Class Initialized
INFO - 2025-09-18 08:52:27 --> Output Class Initialized
INFO - 2025-09-18 08:52:27 --> Security Class Initialized
DEBUG - 2025-09-18 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:52:27 --> CSRF cookie sent
INFO - 2025-09-18 08:52:27 --> Input Class Initialized
INFO - 2025-09-18 08:52:27 --> Language Class Initialized
INFO - 2025-09-18 08:52:27 --> Loader Class Initialized
INFO - 2025-09-18 08:52:27 --> Helper loaded: url_helper
INFO - 2025-09-18 08:52:27 --> Helper loaded: text_helper
INFO - 2025-09-18 08:52:27 --> Helper loaded: string_helper
INFO - 2025-09-18 08:52:27 --> Helper loaded: form_helper
INFO - 2025-09-18 08:52:27 --> Helper loaded: download_helper
INFO - 2025-09-18 08:52:27 --> Helper loaded: security_helper
INFO - 2025-09-18 08:52:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:52:27 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:52:27 --> Form Validation Class Initialized
INFO - 2025-09-18 08:52:27 --> Model "User_model" initialized
INFO - 2025-09-18 13:52:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:52:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:52:27 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:52:27 --> Controller Class Initialized
INFO - 2025-09-18 13:52:27 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:52:27 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:52:27 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:52:27 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 13:52:27 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 13:52:27 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:52:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 13:52:27 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 13:52:27 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 13:52:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 13:52:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:52:27 --> Model "Log_model" initialized
INFO - 2025-09-18 13:52:27 --> Final output sent to browser
DEBUG - 2025-09-18 13:52:27 --> Total execution time: 0.3974
INFO - 2025-09-18 08:52:30 --> Config Class Initialized
INFO - 2025-09-18 08:52:30 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:52:30 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:52:30 --> Utf8 Class Initialized
INFO - 2025-09-18 08:52:30 --> URI Class Initialized
INFO - 2025-09-18 08:52:30 --> Router Class Initialized
INFO - 2025-09-18 08:52:30 --> Output Class Initialized
INFO - 2025-09-18 08:52:30 --> Security Class Initialized
DEBUG - 2025-09-18 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:52:30 --> CSRF cookie sent
INFO - 2025-09-18 08:52:30 --> Input Class Initialized
INFO - 2025-09-18 08:52:30 --> Language Class Initialized
INFO - 2025-09-18 08:52:30 --> Loader Class Initialized
INFO - 2025-09-18 08:52:30 --> Helper loaded: url_helper
INFO - 2025-09-18 08:52:30 --> Helper loaded: text_helper
INFO - 2025-09-18 08:52:30 --> Helper loaded: string_helper
INFO - 2025-09-18 08:52:30 --> Helper loaded: form_helper
INFO - 2025-09-18 08:52:30 --> Helper loaded: download_helper
INFO - 2025-09-18 08:52:30 --> Helper loaded: security_helper
INFO - 2025-09-18 08:52:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:52:30 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:52:30 --> Form Validation Class Initialized
INFO - 2025-09-18 08:52:30 --> Model "User_model" initialized
INFO - 2025-09-18 13:52:30 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:52:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:52:30 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:52:30 --> Controller Class Initialized
INFO - 2025-09-18 13:52:30 --> Model "Sdm_model" initialized
INFO - 2025-09-18 13:52:30 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-18 13:52:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2025-09-18 13:52:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:52:30 --> Model "Log_model" initialized
INFO - 2025-09-18 13:52:30 --> Final output sent to browser
DEBUG - 2025-09-18 13:52:30 --> Total execution time: 0.1446
INFO - 2025-09-18 08:52:33 --> Config Class Initialized
INFO - 2025-09-18 08:52:33 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:52:34 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:52:34 --> Utf8 Class Initialized
INFO - 2025-09-18 08:52:34 --> URI Class Initialized
DEBUG - 2025-09-18 08:52:34 --> No URI present. Default controller set.
INFO - 2025-09-18 08:52:34 --> Router Class Initialized
INFO - 2025-09-18 08:52:34 --> Output Class Initialized
INFO - 2025-09-18 08:52:34 --> Security Class Initialized
DEBUG - 2025-09-18 08:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:52:34 --> CSRF cookie sent
INFO - 2025-09-18 08:52:34 --> Input Class Initialized
INFO - 2025-09-18 08:52:34 --> Language Class Initialized
INFO - 2025-09-18 08:52:34 --> Loader Class Initialized
INFO - 2025-09-18 08:52:34 --> Helper loaded: url_helper
INFO - 2025-09-18 08:52:34 --> Helper loaded: text_helper
INFO - 2025-09-18 08:52:34 --> Helper loaded: string_helper
INFO - 2025-09-18 08:52:34 --> Helper loaded: form_helper
INFO - 2025-09-18 08:52:34 --> Helper loaded: download_helper
INFO - 2025-09-18 08:52:34 --> Helper loaded: security_helper
INFO - 2025-09-18 08:52:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:52:34 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:52:34 --> Form Validation Class Initialized
INFO - 2025-09-18 08:52:34 --> Model "User_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:52:34 --> Controller Class Initialized
INFO - 2025-09-18 13:52:34 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Video_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:52:34 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:52:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 13:52:34 --> Pagination Class Initialized
INFO - 2025-09-18 13:52:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 13:52:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:52:34 --> Model "Log_model" initialized
INFO - 2025-09-18 13:52:34 --> Final output sent to browser
DEBUG - 2025-09-18 13:52:34 --> Total execution time: 0.3181
INFO - 2025-09-18 08:53:31 --> Config Class Initialized
INFO - 2025-09-18 08:53:31 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:53:31 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:53:31 --> Utf8 Class Initialized
INFO - 2025-09-18 08:53:31 --> URI Class Initialized
DEBUG - 2025-09-18 08:53:31 --> No URI present. Default controller set.
INFO - 2025-09-18 08:53:31 --> Router Class Initialized
INFO - 2025-09-18 08:53:31 --> Output Class Initialized
INFO - 2025-09-18 08:53:31 --> Security Class Initialized
DEBUG - 2025-09-18 08:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:53:31 --> CSRF cookie sent
INFO - 2025-09-18 08:53:31 --> Input Class Initialized
INFO - 2025-09-18 08:53:31 --> Language Class Initialized
INFO - 2025-09-18 08:53:31 --> Loader Class Initialized
INFO - 2025-09-18 08:53:31 --> Helper loaded: url_helper
INFO - 2025-09-18 08:53:31 --> Helper loaded: text_helper
INFO - 2025-09-18 08:53:31 --> Helper loaded: string_helper
INFO - 2025-09-18 08:53:31 --> Helper loaded: form_helper
INFO - 2025-09-18 08:53:31 --> Helper loaded: download_helper
INFO - 2025-09-18 08:53:31 --> Helper loaded: security_helper
INFO - 2025-09-18 08:53:31 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:53:31 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:53:31 --> Form Validation Class Initialized
INFO - 2025-09-18 08:53:31 --> Model "User_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:53:31 --> Controller Class Initialized
INFO - 2025-09-18 13:53:31 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Video_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:53:31 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:53:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 13:53:31 --> Pagination Class Initialized
INFO - 2025-09-18 13:53:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 13:53:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:53:32 --> Model "Log_model" initialized
INFO - 2025-09-18 13:53:32 --> Final output sent to browser
DEBUG - 2025-09-18 13:53:32 --> Total execution time: 0.5777
INFO - 2025-09-18 08:55:40 --> Config Class Initialized
INFO - 2025-09-18 08:55:40 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:55:40 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:55:40 --> Utf8 Class Initialized
INFO - 2025-09-18 08:55:40 --> URI Class Initialized
INFO - 2025-09-18 08:55:40 --> Router Class Initialized
INFO - 2025-09-18 08:55:40 --> Output Class Initialized
INFO - 2025-09-18 08:55:40 --> Security Class Initialized
DEBUG - 2025-09-18 08:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:55:40 --> CSRF cookie sent
INFO - 2025-09-18 08:55:40 --> Input Class Initialized
INFO - 2025-09-18 08:55:40 --> Language Class Initialized
INFO - 2025-09-18 08:55:40 --> Loader Class Initialized
INFO - 2025-09-18 08:55:40 --> Helper loaded: url_helper
INFO - 2025-09-18 08:55:40 --> Helper loaded: text_helper
INFO - 2025-09-18 08:55:40 --> Helper loaded: string_helper
INFO - 2025-09-18 08:55:40 --> Helper loaded: form_helper
INFO - 2025-09-18 08:55:40 --> Helper loaded: download_helper
INFO - 2025-09-18 08:55:40 --> Helper loaded: security_helper
INFO - 2025-09-18 08:55:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:55:40 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:55:40 --> Form Validation Class Initialized
INFO - 2025-09-18 08:55:40 --> Model "User_model" initialized
INFO - 2025-09-18 13:55:40 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:55:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:55:40 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:55:40 --> Controller Class Initialized
INFO - 2025-09-18 13:55:40 --> Model "Pages_model" initialized
INFO - 2025-09-18 13:55:40 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:55:40 --> Model "Download_model" initialized
INFO - 2025-09-18 13:55:40 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 13:55:40 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 13:55:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-09-18 13:55:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:55:40 --> Model "Log_model" initialized
INFO - 2025-09-18 13:55:40 --> Final output sent to browser
DEBUG - 2025-09-18 13:55:40 --> Total execution time: 0.1568
INFO - 2025-09-18 08:55:47 --> Config Class Initialized
INFO - 2025-09-18 08:55:47 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:55:47 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:55:47 --> Utf8 Class Initialized
INFO - 2025-09-18 08:55:47 --> URI Class Initialized
INFO - 2025-09-18 08:55:47 --> Router Class Initialized
INFO - 2025-09-18 08:55:47 --> Output Class Initialized
INFO - 2025-09-18 08:55:47 --> Security Class Initialized
DEBUG - 2025-09-18 08:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:55:47 --> CSRF cookie sent
INFO - 2025-09-18 08:55:47 --> Input Class Initialized
INFO - 2025-09-18 08:55:47 --> Language Class Initialized
INFO - 2025-09-18 08:55:47 --> Loader Class Initialized
INFO - 2025-09-18 08:55:47 --> Helper loaded: url_helper
INFO - 2025-09-18 08:55:47 --> Helper loaded: text_helper
INFO - 2025-09-18 08:55:47 --> Helper loaded: string_helper
INFO - 2025-09-18 08:55:47 --> Helper loaded: form_helper
INFO - 2025-09-18 08:55:47 --> Helper loaded: download_helper
INFO - 2025-09-18 08:55:47 --> Helper loaded: security_helper
INFO - 2025-09-18 08:55:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:55:47 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:55:47 --> Form Validation Class Initialized
INFO - 2025-09-18 08:55:47 --> Model "User_model" initialized
INFO - 2025-09-18 13:55:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:55:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:55:47 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:55:47 --> Controller Class Initialized
INFO - 2025-09-18 13:55:47 --> Model "Download_model" initialized
INFO - 2025-09-18 13:55:47 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 13:55:47 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 13:55:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2025-09-18 13:55:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:55:47 --> Model "Log_model" initialized
INFO - 2025-09-18 13:55:47 --> Final output sent to browser
DEBUG - 2025-09-18 13:55:47 --> Total execution time: 0.1559
INFO - 2025-09-18 08:55:54 --> Config Class Initialized
INFO - 2025-09-18 08:55:54 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:55:54 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:55:54 --> Utf8 Class Initialized
INFO - 2025-09-18 08:55:54 --> URI Class Initialized
INFO - 2025-09-18 08:55:54 --> Router Class Initialized
INFO - 2025-09-18 08:55:54 --> Output Class Initialized
INFO - 2025-09-18 08:55:54 --> Security Class Initialized
DEBUG - 2025-09-18 08:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:55:54 --> CSRF cookie sent
INFO - 2025-09-18 08:55:54 --> Input Class Initialized
INFO - 2025-09-18 08:55:54 --> Language Class Initialized
INFO - 2025-09-18 08:55:54 --> Loader Class Initialized
INFO - 2025-09-18 08:55:54 --> Helper loaded: url_helper
INFO - 2025-09-18 08:55:54 --> Helper loaded: text_helper
INFO - 2025-09-18 08:55:54 --> Helper loaded: string_helper
INFO - 2025-09-18 08:55:54 --> Helper loaded: form_helper
INFO - 2025-09-18 08:55:54 --> Helper loaded: download_helper
INFO - 2025-09-18 08:55:54 --> Helper loaded: security_helper
INFO - 2025-09-18 08:55:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:55:54 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:55:54 --> Form Validation Class Initialized
INFO - 2025-09-18 08:55:54 --> Model "User_model" initialized
INFO - 2025-09-18 13:55:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:55:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:55:54 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:55:54 --> Controller Class Initialized
INFO - 2025-09-18 13:55:54 --> Model "Download_model" initialized
INFO - 2025-09-18 13:55:54 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 13:55:54 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 13:55:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2025-09-18 13:55:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:55:54 --> Model "Log_model" initialized
INFO - 2025-09-18 13:55:54 --> Final output sent to browser
DEBUG - 2025-09-18 13:55:54 --> Total execution time: 0.1531
INFO - 2025-09-18 08:55:57 --> Config Class Initialized
INFO - 2025-09-18 08:55:57 --> Hooks Class Initialized
DEBUG - 2025-09-18 08:55:57 --> UTF-8 Support Enabled
INFO - 2025-09-18 08:55:57 --> Utf8 Class Initialized
INFO - 2025-09-18 08:55:57 --> URI Class Initialized
DEBUG - 2025-09-18 08:55:57 --> No URI present. Default controller set.
INFO - 2025-09-18 08:55:57 --> Router Class Initialized
INFO - 2025-09-18 08:55:57 --> Output Class Initialized
INFO - 2025-09-18 08:55:57 --> Security Class Initialized
DEBUG - 2025-09-18 08:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 08:55:57 --> CSRF cookie sent
INFO - 2025-09-18 08:55:57 --> Input Class Initialized
INFO - 2025-09-18 08:55:57 --> Language Class Initialized
INFO - 2025-09-18 08:55:57 --> Loader Class Initialized
INFO - 2025-09-18 08:55:57 --> Helper loaded: url_helper
INFO - 2025-09-18 08:55:57 --> Helper loaded: text_helper
INFO - 2025-09-18 08:55:57 --> Helper loaded: string_helper
INFO - 2025-09-18 08:55:57 --> Helper loaded: form_helper
INFO - 2025-09-18 08:55:57 --> Helper loaded: download_helper
INFO - 2025-09-18 08:55:57 --> Helper loaded: security_helper
INFO - 2025-09-18 08:55:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 08:55:57 --> Database Driver Class Initialized
DEBUG - 2025-09-18 08:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 08:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 08:55:57 --> Form Validation Class Initialized
INFO - 2025-09-18 08:55:57 --> Model "User_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Nav_model" initialized
INFO - 2025-09-18 13:55:57 --> Controller Class Initialized
INFO - 2025-09-18 13:55:57 --> Model "Berita_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Galeri_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Video_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Agenda_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Tautan_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Mitra_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Prodi_model" initialized
INFO - 2025-09-18 13:55:57 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 13:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 13:55:57 --> Pagination Class Initialized
INFO - 2025-09-18 13:55:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 13:55:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 13:55:57 --> Model "Log_model" initialized
INFO - 2025-09-18 13:55:57 --> Final output sent to browser
DEBUG - 2025-09-18 13:55:57 --> Total execution time: 0.2381
INFO - 2025-09-18 09:00:50 --> Config Class Initialized
INFO - 2025-09-18 09:00:50 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:00:50 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:00:50 --> Utf8 Class Initialized
INFO - 2025-09-18 09:00:50 --> URI Class Initialized
DEBUG - 2025-09-18 09:00:50 --> No URI present. Default controller set.
INFO - 2025-09-18 09:00:50 --> Router Class Initialized
INFO - 2025-09-18 09:00:50 --> Output Class Initialized
INFO - 2025-09-18 09:00:50 --> Security Class Initialized
DEBUG - 2025-09-18 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:00:50 --> CSRF cookie sent
INFO - 2025-09-18 09:00:50 --> Input Class Initialized
INFO - 2025-09-18 09:00:50 --> Language Class Initialized
INFO - 2025-09-18 09:00:50 --> Loader Class Initialized
INFO - 2025-09-18 09:00:50 --> Helper loaded: url_helper
INFO - 2025-09-18 09:00:50 --> Helper loaded: text_helper
INFO - 2025-09-18 09:00:50 --> Helper loaded: string_helper
INFO - 2025-09-18 09:00:50 --> Helper loaded: form_helper
INFO - 2025-09-18 09:00:50 --> Helper loaded: download_helper
INFO - 2025-09-18 09:00:50 --> Helper loaded: security_helper
INFO - 2025-09-18 09:00:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:00:50 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:00:50 --> Form Validation Class Initialized
INFO - 2025-09-18 09:00:50 --> Model "User_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:00:50 --> Controller Class Initialized
INFO - 2025-09-18 14:00:50 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Galeri_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Video_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Agenda_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Tautan_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Mitra_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:00:50 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 14:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 14:00:50 --> Pagination Class Initialized
INFO - 2025-09-18 14:00:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 14:00:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:00:50 --> Model "Log_model" initialized
INFO - 2025-09-18 14:00:50 --> Final output sent to browser
DEBUG - 2025-09-18 14:00:50 --> Total execution time: 0.5237
INFO - 2025-09-18 09:02:05 --> Config Class Initialized
INFO - 2025-09-18 09:02:05 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:02:05 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:02:05 --> Utf8 Class Initialized
INFO - 2025-09-18 09:02:05 --> URI Class Initialized
DEBUG - 2025-09-18 09:02:05 --> No URI present. Default controller set.
INFO - 2025-09-18 09:02:05 --> Router Class Initialized
INFO - 2025-09-18 09:02:05 --> Output Class Initialized
INFO - 2025-09-18 09:02:05 --> Security Class Initialized
DEBUG - 2025-09-18 09:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:02:05 --> CSRF cookie sent
INFO - 2025-09-18 09:02:05 --> Input Class Initialized
INFO - 2025-09-18 09:02:05 --> Language Class Initialized
INFO - 2025-09-18 09:02:05 --> Loader Class Initialized
INFO - 2025-09-18 09:02:05 --> Helper loaded: url_helper
INFO - 2025-09-18 09:02:05 --> Helper loaded: text_helper
INFO - 2025-09-18 09:02:05 --> Helper loaded: string_helper
INFO - 2025-09-18 09:02:05 --> Helper loaded: form_helper
INFO - 2025-09-18 09:02:05 --> Helper loaded: download_helper
INFO - 2025-09-18 09:02:05 --> Helper loaded: security_helper
INFO - 2025-09-18 09:02:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:02:05 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:02:05 --> Form Validation Class Initialized
INFO - 2025-09-18 09:02:05 --> Model "User_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:02:05 --> Controller Class Initialized
INFO - 2025-09-18 14:02:05 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Galeri_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Video_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Agenda_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Tautan_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Mitra_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:02:05 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 14:02:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 14:02:05 --> Pagination Class Initialized
INFO - 2025-09-18 14:02:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 14:02:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:02:05 --> Model "Log_model" initialized
INFO - 2025-09-18 14:02:05 --> Final output sent to browser
DEBUG - 2025-09-18 14:02:05 --> Total execution time: 0.3510
INFO - 2025-09-18 09:03:07 --> Config Class Initialized
INFO - 2025-09-18 09:03:07 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:03:07 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:03:07 --> Utf8 Class Initialized
INFO - 2025-09-18 09:03:07 --> URI Class Initialized
INFO - 2025-09-18 09:03:07 --> Router Class Initialized
INFO - 2025-09-18 09:03:07 --> Output Class Initialized
INFO - 2025-09-18 09:03:07 --> Security Class Initialized
DEBUG - 2025-09-18 09:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:03:07 --> CSRF cookie sent
INFO - 2025-09-18 09:03:07 --> Input Class Initialized
INFO - 2025-09-18 09:03:07 --> Language Class Initialized
INFO - 2025-09-18 09:03:07 --> Loader Class Initialized
INFO - 2025-09-18 09:03:07 --> Helper loaded: url_helper
INFO - 2025-09-18 09:03:07 --> Helper loaded: text_helper
INFO - 2025-09-18 09:03:07 --> Helper loaded: string_helper
INFO - 2025-09-18 09:03:07 --> Helper loaded: form_helper
INFO - 2025-09-18 09:03:07 --> Helper loaded: download_helper
INFO - 2025-09-18 09:03:07 --> Helper loaded: security_helper
INFO - 2025-09-18 09:03:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:03:07 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:03:07 --> Form Validation Class Initialized
INFO - 2025-09-18 09:03:07 --> Model "User_model" initialized
INFO - 2025-09-18 14:03:07 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:03:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:03:07 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:03:07 --> Controller Class Initialized
INFO - 2025-09-18 14:03:07 --> Model "Magazine_model" initialized
INFO - 2025-09-18 14:03:07 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:03:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\magazine/list.php
INFO - 2025-09-18 14:03:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:03:07 --> Model "Log_model" initialized
INFO - 2025-09-18 14:03:07 --> Final output sent to browser
DEBUG - 2025-09-18 14:03:07 --> Total execution time: 0.1259
INFO - 2025-09-18 09:03:28 --> Config Class Initialized
INFO - 2025-09-18 09:03:28 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:03:28 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:03:28 --> Utf8 Class Initialized
INFO - 2025-09-18 09:03:28 --> URI Class Initialized
DEBUG - 2025-09-18 09:03:28 --> No URI present. Default controller set.
INFO - 2025-09-18 09:03:28 --> Router Class Initialized
INFO - 2025-09-18 09:03:28 --> Output Class Initialized
INFO - 2025-09-18 09:03:28 --> Security Class Initialized
DEBUG - 2025-09-18 09:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:03:28 --> CSRF cookie sent
INFO - 2025-09-18 09:03:28 --> Input Class Initialized
INFO - 2025-09-18 09:03:28 --> Language Class Initialized
INFO - 2025-09-18 09:03:28 --> Loader Class Initialized
INFO - 2025-09-18 09:03:28 --> Helper loaded: url_helper
INFO - 2025-09-18 09:03:28 --> Helper loaded: text_helper
INFO - 2025-09-18 09:03:28 --> Helper loaded: string_helper
INFO - 2025-09-18 09:03:28 --> Helper loaded: form_helper
INFO - 2025-09-18 09:03:28 --> Helper loaded: download_helper
INFO - 2025-09-18 09:03:28 --> Helper loaded: security_helper
INFO - 2025-09-18 09:03:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:03:28 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:03:29 --> Form Validation Class Initialized
INFO - 2025-09-18 09:03:29 --> Model "User_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:03:29 --> Controller Class Initialized
INFO - 2025-09-18 14:03:29 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Galeri_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Video_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Agenda_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Tautan_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Mitra_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:03:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 14:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 14:03:29 --> Pagination Class Initialized
INFO - 2025-09-18 14:03:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 14:03:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:03:29 --> Model "Log_model" initialized
INFO - 2025-09-18 14:03:29 --> Final output sent to browser
DEBUG - 2025-09-18 14:03:29 --> Total execution time: 0.3576
INFO - 2025-09-18 09:03:42 --> Config Class Initialized
INFO - 2025-09-18 09:03:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:03:42 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:03:42 --> Utf8 Class Initialized
INFO - 2025-09-18 09:03:42 --> URI Class Initialized
INFO - 2025-09-18 09:03:42 --> Router Class Initialized
INFO - 2025-09-18 09:03:42 --> Output Class Initialized
INFO - 2025-09-18 09:03:42 --> Security Class Initialized
DEBUG - 2025-09-18 09:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:03:42 --> CSRF cookie sent
INFO - 2025-09-18 09:03:42 --> Input Class Initialized
INFO - 2025-09-18 09:03:42 --> Language Class Initialized
INFO - 2025-09-18 09:03:42 --> Loader Class Initialized
INFO - 2025-09-18 09:03:42 --> Helper loaded: url_helper
INFO - 2025-09-18 09:03:42 --> Helper loaded: text_helper
INFO - 2025-09-18 09:03:42 --> Helper loaded: string_helper
INFO - 2025-09-18 09:03:42 --> Helper loaded: form_helper
INFO - 2025-09-18 09:03:42 --> Helper loaded: download_helper
INFO - 2025-09-18 09:03:42 --> Helper loaded: security_helper
INFO - 2025-09-18 09:03:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:03:42 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:03:42 --> Form Validation Class Initialized
INFO - 2025-09-18 09:03:42 --> Model "User_model" initialized
INFO - 2025-09-18 14:03:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:03:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:03:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:03:42 --> Controller Class Initialized
INFO - 2025-09-18 14:03:42 --> Model "Pages_model" initialized
INFO - 2025-09-18 14:03:42 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:03:42 --> Model "Download_model" initialized
INFO - 2025-09-18 14:03:42 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 14:03:42 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 14:03:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/alumni.php
INFO - 2025-09-18 14:03:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:03:42 --> Model "Log_model" initialized
INFO - 2025-09-18 14:03:42 --> Final output sent to browser
DEBUG - 2025-09-18 14:03:42 --> Total execution time: 0.1560
INFO - 2025-09-18 09:03:51 --> Config Class Initialized
INFO - 2025-09-18 09:03:51 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:03:51 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:03:51 --> Utf8 Class Initialized
INFO - 2025-09-18 09:03:51 --> URI Class Initialized
INFO - 2025-09-18 09:03:51 --> Router Class Initialized
INFO - 2025-09-18 09:03:51 --> Output Class Initialized
INFO - 2025-09-18 09:03:51 --> Security Class Initialized
DEBUG - 2025-09-18 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:03:51 --> CSRF cookie sent
INFO - 2025-09-18 09:03:51 --> Input Class Initialized
INFO - 2025-09-18 09:03:51 --> Language Class Initialized
INFO - 2025-09-18 09:03:51 --> Loader Class Initialized
INFO - 2025-09-18 09:03:51 --> Helper loaded: url_helper
INFO - 2025-09-18 09:03:51 --> Helper loaded: text_helper
INFO - 2025-09-18 09:03:51 --> Helper loaded: string_helper
INFO - 2025-09-18 09:03:51 --> Helper loaded: form_helper
INFO - 2025-09-18 09:03:51 --> Helper loaded: download_helper
INFO - 2025-09-18 09:03:51 --> Helper loaded: security_helper
INFO - 2025-09-18 09:03:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:03:51 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:03:51 --> Form Validation Class Initialized
INFO - 2025-09-18 09:03:51 --> Model "User_model" initialized
INFO - 2025-09-18 14:03:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:03:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:03:51 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:03:51 --> Controller Class Initialized
INFO - 2025-09-18 14:03:51 --> Model "Pages_model" initialized
INFO - 2025-09-18 14:03:51 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:03:51 --> Model "Download_model" initialized
INFO - 2025-09-18 14:03:51 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 14:03:51 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 14:03:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-09-18 14:03:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:03:51 --> Model "Log_model" initialized
INFO - 2025-09-18 14:03:51 --> Final output sent to browser
DEBUG - 2025-09-18 14:03:51 --> Total execution time: 0.1390
INFO - 2025-09-18 09:04:20 --> Config Class Initialized
INFO - 2025-09-18 09:04:20 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:04:20 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:04:20 --> Utf8 Class Initialized
INFO - 2025-09-18 09:04:20 --> URI Class Initialized
INFO - 2025-09-18 09:04:20 --> Router Class Initialized
INFO - 2025-09-18 09:04:20 --> Output Class Initialized
INFO - 2025-09-18 09:04:20 --> Security Class Initialized
DEBUG - 2025-09-18 09:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:04:20 --> CSRF cookie sent
INFO - 2025-09-18 09:04:20 --> Input Class Initialized
INFO - 2025-09-18 09:04:20 --> Language Class Initialized
INFO - 2025-09-18 09:04:20 --> Loader Class Initialized
INFO - 2025-09-18 09:04:20 --> Helper loaded: url_helper
INFO - 2025-09-18 09:04:20 --> Helper loaded: text_helper
INFO - 2025-09-18 09:04:20 --> Helper loaded: string_helper
INFO - 2025-09-18 09:04:20 --> Helper loaded: form_helper
INFO - 2025-09-18 09:04:20 --> Helper loaded: download_helper
INFO - 2025-09-18 09:04:20 --> Helper loaded: security_helper
INFO - 2025-09-18 09:04:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:04:20 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:04:20 --> Form Validation Class Initialized
INFO - 2025-09-18 09:04:20 --> Model "User_model" initialized
INFO - 2025-09-18 14:04:20 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:04:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:04:20 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:04:20 --> Controller Class Initialized
INFO - 2025-09-18 14:04:20 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:04:20 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:04:20 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:04:20 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 14:04:20 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 14:04:20 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:04:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:04:20 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 14:04:20 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 14:04:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 14:04:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:04:20 --> Model "Log_model" initialized
INFO - 2025-09-18 14:04:20 --> Final output sent to browser
DEBUG - 2025-09-18 14:04:20 --> Total execution time: 0.2260
INFO - 2025-09-18 09:04:57 --> Config Class Initialized
INFO - 2025-09-18 09:04:57 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:04:57 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:04:57 --> Utf8 Class Initialized
INFO - 2025-09-18 09:04:57 --> URI Class Initialized
INFO - 2025-09-18 09:04:57 --> Router Class Initialized
INFO - 2025-09-18 09:04:57 --> Output Class Initialized
INFO - 2025-09-18 09:04:57 --> Security Class Initialized
DEBUG - 2025-09-18 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:04:57 --> CSRF cookie sent
INFO - 2025-09-18 09:04:57 --> Input Class Initialized
INFO - 2025-09-18 09:04:57 --> Language Class Initialized
INFO - 2025-09-18 09:04:57 --> Loader Class Initialized
INFO - 2025-09-18 09:04:57 --> Helper loaded: url_helper
INFO - 2025-09-18 09:04:57 --> Helper loaded: text_helper
INFO - 2025-09-18 09:04:57 --> Helper loaded: string_helper
INFO - 2025-09-18 09:04:57 --> Helper loaded: form_helper
INFO - 2025-09-18 09:04:57 --> Helper loaded: download_helper
INFO - 2025-09-18 09:04:57 --> Helper loaded: security_helper
INFO - 2025-09-18 09:04:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:04:57 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:04:57 --> Form Validation Class Initialized
INFO - 2025-09-18 09:04:57 --> Model "User_model" initialized
INFO - 2025-09-18 14:04:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:04:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:04:57 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:04:57 --> Controller Class Initialized
INFO - 2025-09-18 14:04:57 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:04:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:04:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-18 14:04:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:04:57 --> Model "Log_model" initialized
INFO - 2025-09-18 14:04:57 --> Final output sent to browser
DEBUG - 2025-09-18 14:04:57 --> Total execution time: 0.2571
INFO - 2025-09-18 09:05:06 --> Config Class Initialized
INFO - 2025-09-18 09:05:06 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:05:06 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:05:06 --> Utf8 Class Initialized
INFO - 2025-09-18 09:05:06 --> URI Class Initialized
INFO - 2025-09-18 09:05:06 --> Router Class Initialized
INFO - 2025-09-18 09:05:06 --> Output Class Initialized
INFO - 2025-09-18 09:05:06 --> Security Class Initialized
DEBUG - 2025-09-18 09:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:05:06 --> CSRF cookie sent
INFO - 2025-09-18 09:05:06 --> CSRF token verified
INFO - 2025-09-18 09:05:06 --> Input Class Initialized
INFO - 2025-09-18 09:05:06 --> Language Class Initialized
INFO - 2025-09-18 09:05:06 --> Loader Class Initialized
INFO - 2025-09-18 09:05:06 --> Helper loaded: url_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: text_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: string_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: form_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: download_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: security_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:05:06 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:05:06 --> Form Validation Class Initialized
INFO - 2025-09-18 09:05:06 --> Model "User_model" initialized
INFO - 2025-09-18 14:05:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:05:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:05:06 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:05:06 --> Controller Class Initialized
INFO - 2025-09-18 14:05:06 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:05:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:05:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 09:05:06 --> Config Class Initialized
INFO - 2025-09-18 09:05:06 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:05:06 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:05:06 --> Utf8 Class Initialized
INFO - 2025-09-18 09:05:06 --> URI Class Initialized
INFO - 2025-09-18 09:05:06 --> Router Class Initialized
INFO - 2025-09-18 09:05:06 --> Output Class Initialized
INFO - 2025-09-18 09:05:06 --> Security Class Initialized
DEBUG - 2025-09-18 09:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:05:06 --> CSRF cookie sent
INFO - 2025-09-18 09:05:06 --> Input Class Initialized
INFO - 2025-09-18 09:05:06 --> Language Class Initialized
INFO - 2025-09-18 09:05:06 --> Loader Class Initialized
INFO - 2025-09-18 09:05:06 --> Helper loaded: url_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: text_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: string_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: form_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: download_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: security_helper
INFO - 2025-09-18 09:05:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:05:06 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:05:06 --> Form Validation Class Initialized
INFO - 2025-09-18 09:05:06 --> Model "User_model" initialized
INFO - 2025-09-18 14:05:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:05:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:05:06 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:05:06 --> Controller Class Initialized
INFO - 2025-09-18 14:05:06 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:05:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:05:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-18 14:05:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:05:06 --> Model "Log_model" initialized
INFO - 2025-09-18 14:05:06 --> Final output sent to browser
DEBUG - 2025-09-18 14:05:06 --> Total execution time: 0.1468
INFO - 2025-09-18 09:05:12 --> Config Class Initialized
INFO - 2025-09-18 09:05:12 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:05:12 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:05:12 --> Utf8 Class Initialized
INFO - 2025-09-18 09:05:12 --> URI Class Initialized
INFO - 2025-09-18 09:05:12 --> Router Class Initialized
INFO - 2025-09-18 09:05:12 --> Output Class Initialized
INFO - 2025-09-18 09:05:12 --> Security Class Initialized
DEBUG - 2025-09-18 09:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:05:12 --> CSRF cookie sent
INFO - 2025-09-18 09:05:12 --> Input Class Initialized
INFO - 2025-09-18 09:05:12 --> Language Class Initialized
INFO - 2025-09-18 09:05:12 --> Loader Class Initialized
INFO - 2025-09-18 09:05:12 --> Helper loaded: url_helper
INFO - 2025-09-18 09:05:12 --> Helper loaded: text_helper
INFO - 2025-09-18 09:05:12 --> Helper loaded: string_helper
INFO - 2025-09-18 09:05:12 --> Helper loaded: form_helper
INFO - 2025-09-18 09:05:12 --> Helper loaded: download_helper
INFO - 2025-09-18 09:05:12 --> Helper loaded: security_helper
INFO - 2025-09-18 09:05:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:05:12 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:05:12 --> Form Validation Class Initialized
INFO - 2025-09-18 09:05:12 --> Model "User_model" initialized
INFO - 2025-09-18 14:05:12 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:05:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:05:12 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:05:12 --> Controller Class Initialized
INFO - 2025-09-18 14:05:12 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:05:12 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:05:12 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:05:12 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 14:05:12 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 14:05:12 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:05:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:05:12 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 14:05:12 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 14:05:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 14:05:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:05:12 --> Model "Log_model" initialized
INFO - 2025-09-18 14:05:12 --> Final output sent to browser
DEBUG - 2025-09-18 14:05:12 --> Total execution time: 0.1606
INFO - 2025-09-18 09:09:24 --> Config Class Initialized
INFO - 2025-09-18 09:09:24 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:09:24 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:09:24 --> Utf8 Class Initialized
INFO - 2025-09-18 09:09:24 --> URI Class Initialized
INFO - 2025-09-18 09:09:24 --> Router Class Initialized
INFO - 2025-09-18 09:09:24 --> Output Class Initialized
INFO - 2025-09-18 09:09:24 --> Security Class Initialized
DEBUG - 2025-09-18 09:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:09:24 --> CSRF cookie sent
INFO - 2025-09-18 09:09:24 --> Input Class Initialized
INFO - 2025-09-18 09:09:24 --> Language Class Initialized
INFO - 2025-09-18 09:09:24 --> Loader Class Initialized
INFO - 2025-09-18 09:09:24 --> Helper loaded: url_helper
INFO - 2025-09-18 09:09:24 --> Helper loaded: text_helper
INFO - 2025-09-18 09:09:24 --> Helper loaded: string_helper
INFO - 2025-09-18 09:09:24 --> Helper loaded: form_helper
INFO - 2025-09-18 09:09:24 --> Helper loaded: download_helper
INFO - 2025-09-18 09:09:24 --> Helper loaded: security_helper
INFO - 2025-09-18 09:09:24 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:09:24 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:09:24 --> Form Validation Class Initialized
INFO - 2025-09-18 09:09:24 --> Model "User_model" initialized
INFO - 2025-09-18 14:09:24 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:09:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:09:24 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:09:24 --> Controller Class Initialized
INFO - 2025-09-18 14:09:24 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:09:24 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:09:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-18 14:09:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:09:24 --> Model "Log_model" initialized
INFO - 2025-09-18 14:09:24 --> Final output sent to browser
DEBUG - 2025-09-18 14:09:24 --> Total execution time: 0.0890
INFO - 2025-09-18 09:09:42 --> Config Class Initialized
INFO - 2025-09-18 09:09:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:09:42 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:09:42 --> Utf8 Class Initialized
INFO - 2025-09-18 09:09:42 --> URI Class Initialized
INFO - 2025-09-18 09:09:42 --> Router Class Initialized
INFO - 2025-09-18 09:09:42 --> Output Class Initialized
INFO - 2025-09-18 09:09:42 --> Security Class Initialized
DEBUG - 2025-09-18 09:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:09:42 --> CSRF cookie sent
INFO - 2025-09-18 09:09:42 --> CSRF token verified
INFO - 2025-09-18 09:09:42 --> Input Class Initialized
INFO - 2025-09-18 09:09:42 --> Language Class Initialized
INFO - 2025-09-18 09:09:42 --> Loader Class Initialized
INFO - 2025-09-18 09:09:42 --> Helper loaded: url_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: text_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: string_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: form_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: download_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: security_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:09:42 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:09:42 --> Form Validation Class Initialized
INFO - 2025-09-18 09:09:42 --> Model "User_model" initialized
INFO - 2025-09-18 14:09:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:09:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:09:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:09:42 --> Controller Class Initialized
INFO - 2025-09-18 14:09:42 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:09:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:09:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 09:09:42 --> Config Class Initialized
INFO - 2025-09-18 09:09:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:09:42 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:09:42 --> Utf8 Class Initialized
INFO - 2025-09-18 09:09:42 --> URI Class Initialized
INFO - 2025-09-18 09:09:42 --> Router Class Initialized
INFO - 2025-09-18 09:09:42 --> Output Class Initialized
INFO - 2025-09-18 09:09:42 --> Security Class Initialized
DEBUG - 2025-09-18 09:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:09:42 --> CSRF cookie sent
INFO - 2025-09-18 09:09:42 --> Input Class Initialized
INFO - 2025-09-18 09:09:42 --> Language Class Initialized
INFO - 2025-09-18 09:09:42 --> Loader Class Initialized
INFO - 2025-09-18 09:09:42 --> Helper loaded: url_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: text_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: string_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: form_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: download_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: security_helper
INFO - 2025-09-18 09:09:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:09:42 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:09:42 --> Form Validation Class Initialized
INFO - 2025-09-18 09:09:42 --> Model "User_model" initialized
INFO - 2025-09-18 14:09:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:09:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:09:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:09:42 --> Controller Class Initialized
INFO - 2025-09-18 14:09:42 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:09:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:09:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-18 14:09:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:09:42 --> Model "Log_model" initialized
INFO - 2025-09-18 14:09:42 --> Final output sent to browser
DEBUG - 2025-09-18 14:09:42 --> Total execution time: 0.1157
INFO - 2025-09-18 09:09:44 --> Config Class Initialized
INFO - 2025-09-18 09:09:44 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:09:44 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:09:44 --> Utf8 Class Initialized
INFO - 2025-09-18 09:09:44 --> URI Class Initialized
INFO - 2025-09-18 09:09:44 --> Router Class Initialized
INFO - 2025-09-18 09:09:44 --> Output Class Initialized
INFO - 2025-09-18 09:09:44 --> Security Class Initialized
DEBUG - 2025-09-18 09:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:09:44 --> CSRF cookie sent
INFO - 2025-09-18 09:09:44 --> Input Class Initialized
INFO - 2025-09-18 09:09:44 --> Language Class Initialized
INFO - 2025-09-18 09:09:44 --> Loader Class Initialized
INFO - 2025-09-18 09:09:44 --> Helper loaded: url_helper
INFO - 2025-09-18 09:09:44 --> Helper loaded: text_helper
INFO - 2025-09-18 09:09:44 --> Helper loaded: string_helper
INFO - 2025-09-18 09:09:44 --> Helper loaded: form_helper
INFO - 2025-09-18 09:09:44 --> Helper loaded: download_helper
INFO - 2025-09-18 09:09:44 --> Helper loaded: security_helper
INFO - 2025-09-18 09:09:44 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:09:44 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:09:44 --> Form Validation Class Initialized
INFO - 2025-09-18 09:09:44 --> Model "User_model" initialized
INFO - 2025-09-18 14:09:44 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:09:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:09:44 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:09:44 --> Controller Class Initialized
INFO - 2025-09-18 14:09:44 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:09:44 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:09:44 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:09:44 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 14:09:44 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 14:09:44 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:09:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:09:44 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 14:09:44 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 14:09:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 14:09:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:09:44 --> Model "Log_model" initialized
INFO - 2025-09-18 14:09:44 --> Final output sent to browser
DEBUG - 2025-09-18 14:09:44 --> Total execution time: 0.1562
INFO - 2025-09-18 09:09:59 --> Config Class Initialized
INFO - 2025-09-18 09:09:59 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:09:59 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:09:59 --> Utf8 Class Initialized
INFO - 2025-09-18 09:09:59 --> URI Class Initialized
INFO - 2025-09-18 09:09:59 --> Router Class Initialized
INFO - 2025-09-18 09:09:59 --> Output Class Initialized
INFO - 2025-09-18 09:09:59 --> Security Class Initialized
DEBUG - 2025-09-18 09:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:09:59 --> CSRF cookie sent
INFO - 2025-09-18 09:09:59 --> Input Class Initialized
INFO - 2025-09-18 09:09:59 --> Language Class Initialized
INFO - 2025-09-18 09:09:59 --> Loader Class Initialized
INFO - 2025-09-18 09:09:59 --> Helper loaded: url_helper
INFO - 2025-09-18 09:09:59 --> Helper loaded: text_helper
INFO - 2025-09-18 09:09:59 --> Helper loaded: string_helper
INFO - 2025-09-18 09:09:59 --> Helper loaded: form_helper
INFO - 2025-09-18 09:09:59 --> Helper loaded: download_helper
INFO - 2025-09-18 09:09:59 --> Helper loaded: security_helper
INFO - 2025-09-18 09:09:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:09:59 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:09:59 --> Form Validation Class Initialized
INFO - 2025-09-18 09:09:59 --> Model "User_model" initialized
INFO - 2025-09-18 14:09:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:09:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:09:59 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:09:59 --> Controller Class Initialized
INFO - 2025-09-18 14:09:59 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:09:59 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:09:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-18 14:09:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:09:59 --> Model "Log_model" initialized
INFO - 2025-09-18 14:09:59 --> Final output sent to browser
DEBUG - 2025-09-18 14:09:59 --> Total execution time: 0.1941
INFO - 2025-09-18 09:10:37 --> Config Class Initialized
INFO - 2025-09-18 09:10:37 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:10:37 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:10:37 --> Utf8 Class Initialized
INFO - 2025-09-18 09:10:37 --> URI Class Initialized
INFO - 2025-09-18 09:10:37 --> Router Class Initialized
INFO - 2025-09-18 09:10:37 --> Output Class Initialized
INFO - 2025-09-18 09:10:37 --> Security Class Initialized
DEBUG - 2025-09-18 09:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:10:37 --> CSRF cookie sent
INFO - 2025-09-18 09:10:37 --> CSRF token verified
INFO - 2025-09-18 09:10:37 --> Input Class Initialized
INFO - 2025-09-18 09:10:37 --> Language Class Initialized
INFO - 2025-09-18 09:10:37 --> Loader Class Initialized
INFO - 2025-09-18 09:10:37 --> Helper loaded: url_helper
INFO - 2025-09-18 09:10:37 --> Helper loaded: text_helper
INFO - 2025-09-18 09:10:37 --> Helper loaded: string_helper
INFO - 2025-09-18 09:10:37 --> Helper loaded: form_helper
INFO - 2025-09-18 09:10:37 --> Helper loaded: download_helper
INFO - 2025-09-18 09:10:37 --> Helper loaded: security_helper
INFO - 2025-09-18 09:10:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:10:37 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:10:37 --> Form Validation Class Initialized
INFO - 2025-09-18 09:10:37 --> Model "User_model" initialized
INFO - 2025-09-18 14:10:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:10:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:10:37 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:10:37 --> Controller Class Initialized
INFO - 2025-09-18 14:10:37 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:10:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:10:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 09:10:38 --> Config Class Initialized
INFO - 2025-09-18 09:10:38 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:10:38 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:10:38 --> Utf8 Class Initialized
INFO - 2025-09-18 09:10:38 --> URI Class Initialized
INFO - 2025-09-18 09:10:38 --> Router Class Initialized
INFO - 2025-09-18 09:10:38 --> Output Class Initialized
INFO - 2025-09-18 09:10:38 --> Security Class Initialized
DEBUG - 2025-09-18 09:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:10:38 --> CSRF cookie sent
INFO - 2025-09-18 09:10:38 --> Input Class Initialized
INFO - 2025-09-18 09:10:38 --> Language Class Initialized
INFO - 2025-09-18 09:10:38 --> Loader Class Initialized
INFO - 2025-09-18 09:10:38 --> Helper loaded: url_helper
INFO - 2025-09-18 09:10:38 --> Helper loaded: text_helper
INFO - 2025-09-18 09:10:38 --> Helper loaded: string_helper
INFO - 2025-09-18 09:10:38 --> Helper loaded: form_helper
INFO - 2025-09-18 09:10:38 --> Helper loaded: download_helper
INFO - 2025-09-18 09:10:38 --> Helper loaded: security_helper
INFO - 2025-09-18 09:10:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:10:38 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:10:38 --> Form Validation Class Initialized
INFO - 2025-09-18 09:10:38 --> Model "User_model" initialized
INFO - 2025-09-18 14:10:38 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:10:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:10:38 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:10:38 --> Controller Class Initialized
INFO - 2025-09-18 14:10:38 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:10:38 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:10:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-18 14:10:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:10:38 --> Model "Log_model" initialized
INFO - 2025-09-18 14:10:38 --> Final output sent to browser
DEBUG - 2025-09-18 14:10:38 --> Total execution time: 0.1200
INFO - 2025-09-18 09:10:42 --> Config Class Initialized
INFO - 2025-09-18 09:10:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:10:42 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:10:42 --> Utf8 Class Initialized
INFO - 2025-09-18 09:10:42 --> URI Class Initialized
INFO - 2025-09-18 09:10:42 --> Router Class Initialized
INFO - 2025-09-18 09:10:42 --> Output Class Initialized
INFO - 2025-09-18 09:10:42 --> Security Class Initialized
DEBUG - 2025-09-18 09:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:10:42 --> CSRF cookie sent
INFO - 2025-09-18 09:10:42 --> Input Class Initialized
INFO - 2025-09-18 09:10:42 --> Language Class Initialized
INFO - 2025-09-18 09:10:42 --> Loader Class Initialized
INFO - 2025-09-18 09:10:42 --> Helper loaded: url_helper
INFO - 2025-09-18 09:10:42 --> Helper loaded: text_helper
INFO - 2025-09-18 09:10:42 --> Helper loaded: string_helper
INFO - 2025-09-18 09:10:42 --> Helper loaded: form_helper
INFO - 2025-09-18 09:10:42 --> Helper loaded: download_helper
INFO - 2025-09-18 09:10:42 --> Helper loaded: security_helper
INFO - 2025-09-18 09:10:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:10:42 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:10:42 --> Form Validation Class Initialized
INFO - 2025-09-18 09:10:42 --> Model "User_model" initialized
INFO - 2025-09-18 14:10:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:10:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:10:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:10:42 --> Controller Class Initialized
INFO - 2025-09-18 14:10:42 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:10:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:10:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-18 14:10:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:10:42 --> Model "Log_model" initialized
INFO - 2025-09-18 14:10:42 --> Final output sent to browser
DEBUG - 2025-09-18 14:10:42 --> Total execution time: 0.1284
INFO - 2025-09-18 09:11:57 --> Config Class Initialized
INFO - 2025-09-18 09:11:57 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:11:57 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:11:57 --> Utf8 Class Initialized
INFO - 2025-09-18 09:11:57 --> URI Class Initialized
INFO - 2025-09-18 09:11:57 --> Router Class Initialized
INFO - 2025-09-18 09:11:57 --> Output Class Initialized
INFO - 2025-09-18 09:11:57 --> Security Class Initialized
DEBUG - 2025-09-18 09:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:11:57 --> CSRF cookie sent
INFO - 2025-09-18 09:11:57 --> Input Class Initialized
INFO - 2025-09-18 09:11:57 --> Language Class Initialized
INFO - 2025-09-18 09:11:57 --> Loader Class Initialized
INFO - 2025-09-18 09:11:57 --> Helper loaded: url_helper
INFO - 2025-09-18 09:11:57 --> Helper loaded: text_helper
INFO - 2025-09-18 09:11:57 --> Helper loaded: string_helper
INFO - 2025-09-18 09:11:57 --> Helper loaded: form_helper
INFO - 2025-09-18 09:11:57 --> Helper loaded: download_helper
INFO - 2025-09-18 09:11:57 --> Helper loaded: security_helper
INFO - 2025-09-18 09:11:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:11:57 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:11:57 --> Form Validation Class Initialized
INFO - 2025-09-18 09:11:57 --> Model "User_model" initialized
INFO - 2025-09-18 14:11:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:11:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:11:57 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:11:57 --> Controller Class Initialized
INFO - 2025-09-18 14:11:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:11:57 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:11:57 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:11:57 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 14:11:57 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 0
ERROR - 2025-09-18 14:11:58 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:11:58 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 14:11:58 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 14:11:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 14:11:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:11:58 --> Model "Log_model" initialized
INFO - 2025-09-18 14:11:58 --> Final output sent to browser
DEBUG - 2025-09-18 14:11:58 --> Total execution time: 0.2569
INFO - 2025-09-18 09:13:16 --> Config Class Initialized
INFO - 2025-09-18 09:13:16 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:13:16 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:13:16 --> Utf8 Class Initialized
INFO - 2025-09-18 09:13:16 --> URI Class Initialized
INFO - 2025-09-18 09:13:16 --> Router Class Initialized
INFO - 2025-09-18 09:13:16 --> Output Class Initialized
INFO - 2025-09-18 09:13:16 --> Security Class Initialized
DEBUG - 2025-09-18 09:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:13:16 --> CSRF cookie sent
INFO - 2025-09-18 09:13:16 --> Input Class Initialized
INFO - 2025-09-18 09:13:16 --> Language Class Initialized
INFO - 2025-09-18 09:13:16 --> Loader Class Initialized
INFO - 2025-09-18 09:13:16 --> Helper loaded: url_helper
INFO - 2025-09-18 09:13:16 --> Helper loaded: text_helper
INFO - 2025-09-18 09:13:16 --> Helper loaded: string_helper
INFO - 2025-09-18 09:13:16 --> Helper loaded: form_helper
INFO - 2025-09-18 09:13:16 --> Helper loaded: download_helper
INFO - 2025-09-18 09:13:16 --> Helper loaded: security_helper
INFO - 2025-09-18 09:13:16 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:13:16 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:13:16 --> Form Validation Class Initialized
INFO - 2025-09-18 09:13:16 --> Model "User_model" initialized
INFO - 2025-09-18 14:13:16 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:13:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:13:16 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:13:16 --> Controller Class Initialized
INFO - 2025-09-18 14:13:16 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:13:16 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:13:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-18 14:13:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:13:16 --> Model "Log_model" initialized
INFO - 2025-09-18 14:13:16 --> Final output sent to browser
DEBUG - 2025-09-18 14:13:16 --> Total execution time: 0.1645
INFO - 2025-09-18 09:15:34 --> Config Class Initialized
INFO - 2025-09-18 09:15:34 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:15:34 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:15:34 --> Utf8 Class Initialized
INFO - 2025-09-18 09:15:34 --> URI Class Initialized
INFO - 2025-09-18 09:15:34 --> Router Class Initialized
INFO - 2025-09-18 09:15:34 --> Output Class Initialized
INFO - 2025-09-18 09:15:34 --> Security Class Initialized
DEBUG - 2025-09-18 09:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:15:34 --> CSRF cookie sent
INFO - 2025-09-18 09:15:34 --> Input Class Initialized
INFO - 2025-09-18 09:15:34 --> Language Class Initialized
INFO - 2025-09-18 09:15:34 --> Loader Class Initialized
INFO - 2025-09-18 09:15:34 --> Helper loaded: url_helper
INFO - 2025-09-18 09:15:34 --> Helper loaded: text_helper
INFO - 2025-09-18 09:15:34 --> Helper loaded: string_helper
INFO - 2025-09-18 09:15:34 --> Helper loaded: form_helper
INFO - 2025-09-18 09:15:34 --> Helper loaded: download_helper
INFO - 2025-09-18 09:15:34 --> Helper loaded: security_helper
INFO - 2025-09-18 09:15:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:15:34 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:15:34 --> Form Validation Class Initialized
INFO - 2025-09-18 09:15:34 --> Model "User_model" initialized
INFO - 2025-09-18 14:15:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:15:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:15:34 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:15:34 --> Controller Class Initialized
INFO - 2025-09-18 14:15:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:15:34 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:15:34 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:15:34 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 14:15:34 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 0
ERROR - 2025-09-18 14:15:35 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:15:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:15:35 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 14:15:35 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 14:15:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 14:15:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:15:35 --> Model "Log_model" initialized
INFO - 2025-09-18 14:15:35 --> Final output sent to browser
DEBUG - 2025-09-18 14:15:35 --> Total execution time: 0.9438
INFO - 2025-09-18 09:26:11 --> Config Class Initialized
INFO - 2025-09-18 09:26:11 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:26:11 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:26:11 --> Utf8 Class Initialized
INFO - 2025-09-18 09:26:11 --> URI Class Initialized
INFO - 2025-09-18 09:26:11 --> Router Class Initialized
INFO - 2025-09-18 09:26:11 --> Output Class Initialized
INFO - 2025-09-18 09:26:11 --> Security Class Initialized
DEBUG - 2025-09-18 09:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:26:11 --> CSRF cookie sent
INFO - 2025-09-18 09:26:11 --> CSRF token verified
INFO - 2025-09-18 09:26:11 --> Input Class Initialized
INFO - 2025-09-18 09:26:11 --> Language Class Initialized
INFO - 2025-09-18 09:26:11 --> Loader Class Initialized
INFO - 2025-09-18 09:26:11 --> Helper loaded: url_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: text_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: string_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: form_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: download_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: security_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:26:11 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:26:11 --> Form Validation Class Initialized
INFO - 2025-09-18 09:26:11 --> Model "User_model" initialized
INFO - 2025-09-18 14:26:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:26:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:26:11 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:26:11 --> Controller Class Initialized
INFO - 2025-09-18 14:26:11 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:26:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:26:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 09:26:11 --> Config Class Initialized
INFO - 2025-09-18 09:26:11 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:26:11 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:26:11 --> Utf8 Class Initialized
INFO - 2025-09-18 09:26:11 --> URI Class Initialized
INFO - 2025-09-18 09:26:11 --> Router Class Initialized
INFO - 2025-09-18 09:26:11 --> Output Class Initialized
INFO - 2025-09-18 09:26:11 --> Security Class Initialized
DEBUG - 2025-09-18 09:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:26:11 --> CSRF cookie sent
INFO - 2025-09-18 09:26:11 --> Input Class Initialized
INFO - 2025-09-18 09:26:11 --> Language Class Initialized
INFO - 2025-09-18 09:26:11 --> Loader Class Initialized
INFO - 2025-09-18 09:26:11 --> Helper loaded: url_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: text_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: string_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: form_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: download_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: security_helper
INFO - 2025-09-18 09:26:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:26:11 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:26:11 --> Form Validation Class Initialized
INFO - 2025-09-18 09:26:11 --> Model "User_model" initialized
INFO - 2025-09-18 14:26:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:26:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:26:11 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:26:11 --> Controller Class Initialized
INFO - 2025-09-18 14:26:11 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:26:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:26:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-18 14:26:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:26:11 --> Model "Log_model" initialized
INFO - 2025-09-18 14:26:11 --> Final output sent to browser
DEBUG - 2025-09-18 14:26:11 --> Total execution time: 0.1380
INFO - 2025-09-18 09:26:15 --> Config Class Initialized
INFO - 2025-09-18 09:26:15 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:26:15 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:26:15 --> Utf8 Class Initialized
INFO - 2025-09-18 09:26:15 --> URI Class Initialized
INFO - 2025-09-18 09:26:15 --> Router Class Initialized
INFO - 2025-09-18 09:26:15 --> Output Class Initialized
INFO - 2025-09-18 09:26:15 --> Security Class Initialized
DEBUG - 2025-09-18 09:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:26:15 --> CSRF cookie sent
INFO - 2025-09-18 09:26:15 --> Input Class Initialized
INFO - 2025-09-18 09:26:15 --> Language Class Initialized
INFO - 2025-09-18 09:26:15 --> Loader Class Initialized
INFO - 2025-09-18 09:26:15 --> Helper loaded: url_helper
INFO - 2025-09-18 09:26:15 --> Helper loaded: text_helper
INFO - 2025-09-18 09:26:15 --> Helper loaded: string_helper
INFO - 2025-09-18 09:26:15 --> Helper loaded: form_helper
INFO - 2025-09-18 09:26:15 --> Helper loaded: download_helper
INFO - 2025-09-18 09:26:15 --> Helper loaded: security_helper
INFO - 2025-09-18 09:26:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:26:15 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:26:15 --> Form Validation Class Initialized
INFO - 2025-09-18 09:26:15 --> Model "User_model" initialized
INFO - 2025-09-18 14:26:15 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:26:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:26:15 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:26:15 --> Controller Class Initialized
INFO - 2025-09-18 14:26:15 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:26:15 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:26:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-18 14:26:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:26:15 --> Model "Log_model" initialized
INFO - 2025-09-18 14:26:15 --> Final output sent to browser
DEBUG - 2025-09-18 14:26:15 --> Total execution time: 0.1524
INFO - 2025-09-18 09:35:46 --> Config Class Initialized
INFO - 2025-09-18 09:35:46 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:35:46 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:35:46 --> Utf8 Class Initialized
INFO - 2025-09-18 09:35:46 --> URI Class Initialized
INFO - 2025-09-18 09:35:46 --> Router Class Initialized
INFO - 2025-09-18 09:35:46 --> Output Class Initialized
INFO - 2025-09-18 09:35:46 --> Security Class Initialized
DEBUG - 2025-09-18 09:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:35:46 --> CSRF cookie sent
INFO - 2025-09-18 09:35:46 --> CSRF token verified
INFO - 2025-09-18 09:35:46 --> Input Class Initialized
INFO - 2025-09-18 09:35:46 --> Language Class Initialized
INFO - 2025-09-18 09:35:46 --> Loader Class Initialized
INFO - 2025-09-18 09:35:46 --> Helper loaded: url_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: text_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: string_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: form_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: download_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: security_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:35:46 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:35:46 --> Form Validation Class Initialized
INFO - 2025-09-18 09:35:46 --> Model "User_model" initialized
INFO - 2025-09-18 14:35:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:35:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:35:46 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:35:46 --> Controller Class Initialized
INFO - 2025-09-18 14:35:46 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:35:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:35:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 09:35:46 --> Config Class Initialized
INFO - 2025-09-18 09:35:46 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:35:46 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:35:46 --> Utf8 Class Initialized
INFO - 2025-09-18 09:35:46 --> URI Class Initialized
INFO - 2025-09-18 09:35:46 --> Router Class Initialized
INFO - 2025-09-18 09:35:46 --> Output Class Initialized
INFO - 2025-09-18 09:35:46 --> Security Class Initialized
DEBUG - 2025-09-18 09:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:35:46 --> CSRF cookie sent
INFO - 2025-09-18 09:35:46 --> Input Class Initialized
INFO - 2025-09-18 09:35:46 --> Language Class Initialized
INFO - 2025-09-18 09:35:46 --> Loader Class Initialized
INFO - 2025-09-18 09:35:46 --> Helper loaded: url_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: text_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: string_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: form_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: download_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: security_helper
INFO - 2025-09-18 09:35:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:35:46 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:35:46 --> Form Validation Class Initialized
INFO - 2025-09-18 09:35:46 --> Model "User_model" initialized
INFO - 2025-09-18 14:35:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:35:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:35:46 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:35:46 --> Controller Class Initialized
INFO - 2025-09-18 14:35:46 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:35:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:35:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-18 14:35:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:35:46 --> Model "Log_model" initialized
INFO - 2025-09-18 14:35:46 --> Final output sent to browser
DEBUG - 2025-09-18 14:35:46 --> Total execution time: 0.1065
INFO - 2025-09-18 09:35:52 --> Config Class Initialized
INFO - 2025-09-18 09:35:52 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:35:52 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:35:52 --> Utf8 Class Initialized
INFO - 2025-09-18 09:35:52 --> URI Class Initialized
INFO - 2025-09-18 09:35:52 --> Router Class Initialized
INFO - 2025-09-18 09:35:52 --> Output Class Initialized
INFO - 2025-09-18 09:35:52 --> Security Class Initialized
DEBUG - 2025-09-18 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:35:52 --> CSRF cookie sent
INFO - 2025-09-18 09:35:52 --> Input Class Initialized
INFO - 2025-09-18 09:35:52 --> Language Class Initialized
INFO - 2025-09-18 09:35:52 --> Loader Class Initialized
INFO - 2025-09-18 09:35:52 --> Helper loaded: url_helper
INFO - 2025-09-18 09:35:52 --> Helper loaded: text_helper
INFO - 2025-09-18 09:35:52 --> Helper loaded: string_helper
INFO - 2025-09-18 09:35:52 --> Helper loaded: form_helper
INFO - 2025-09-18 09:35:52 --> Helper loaded: download_helper
INFO - 2025-09-18 09:35:52 --> Helper loaded: security_helper
INFO - 2025-09-18 09:35:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:35:52 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:35:52 --> Form Validation Class Initialized
INFO - 2025-09-18 09:35:52 --> Model "User_model" initialized
INFO - 2025-09-18 14:35:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:35:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:35:52 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:35:52 --> Controller Class Initialized
INFO - 2025-09-18 14:35:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:35:52 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:35:52 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:35:52 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 14:35:52 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 14:35:52 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:35:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:35:52 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 14:35:52 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 14:35:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 14:35:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:35:52 --> Model "Log_model" initialized
INFO - 2025-09-18 14:35:52 --> Final output sent to browser
DEBUG - 2025-09-18 14:35:52 --> Total execution time: 0.1601
INFO - 2025-09-18 09:37:15 --> Config Class Initialized
INFO - 2025-09-18 09:37:15 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:37:15 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:37:15 --> Utf8 Class Initialized
INFO - 2025-09-18 09:37:15 --> URI Class Initialized
INFO - 2025-09-18 09:37:15 --> Router Class Initialized
INFO - 2025-09-18 09:37:15 --> Output Class Initialized
INFO - 2025-09-18 09:37:15 --> Security Class Initialized
DEBUG - 2025-09-18 09:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:37:15 --> CSRF cookie sent
INFO - 2025-09-18 09:37:15 --> Input Class Initialized
INFO - 2025-09-18 09:37:15 --> Language Class Initialized
INFO - 2025-09-18 09:37:15 --> Loader Class Initialized
INFO - 2025-09-18 09:37:15 --> Helper loaded: url_helper
INFO - 2025-09-18 09:37:15 --> Helper loaded: text_helper
INFO - 2025-09-18 09:37:15 --> Helper loaded: string_helper
INFO - 2025-09-18 09:37:15 --> Helper loaded: form_helper
INFO - 2025-09-18 09:37:15 --> Helper loaded: download_helper
INFO - 2025-09-18 09:37:15 --> Helper loaded: security_helper
INFO - 2025-09-18 09:37:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:37:15 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:37:15 --> Form Validation Class Initialized
INFO - 2025-09-18 09:37:15 --> Model "User_model" initialized
INFO - 2025-09-18 14:37:15 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:37:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:37:15 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:37:15 --> Controller Class Initialized
INFO - 2025-09-18 14:37:15 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:37:15 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:37:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-18 14:37:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:37:16 --> Model "Log_model" initialized
INFO - 2025-09-18 14:37:16 --> Final output sent to browser
DEBUG - 2025-09-18 14:37:16 --> Total execution time: 0.1308
INFO - 2025-09-18 09:37:21 --> Config Class Initialized
INFO - 2025-09-18 09:37:21 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:37:21 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:37:21 --> Utf8 Class Initialized
INFO - 2025-09-18 09:37:21 --> URI Class Initialized
INFO - 2025-09-18 09:37:21 --> Router Class Initialized
INFO - 2025-09-18 09:37:21 --> Output Class Initialized
INFO - 2025-09-18 09:37:21 --> Security Class Initialized
DEBUG - 2025-09-18 09:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:37:21 --> CSRF cookie sent
INFO - 2025-09-18 09:37:21 --> Input Class Initialized
INFO - 2025-09-18 09:37:21 --> Language Class Initialized
INFO - 2025-09-18 09:37:21 --> Loader Class Initialized
INFO - 2025-09-18 09:37:21 --> Helper loaded: url_helper
INFO - 2025-09-18 09:37:21 --> Helper loaded: text_helper
INFO - 2025-09-18 09:37:21 --> Helper loaded: string_helper
INFO - 2025-09-18 09:37:21 --> Helper loaded: form_helper
INFO - 2025-09-18 09:37:21 --> Helper loaded: download_helper
INFO - 2025-09-18 09:37:21 --> Helper loaded: security_helper
INFO - 2025-09-18 09:37:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:37:21 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:37:21 --> Form Validation Class Initialized
INFO - 2025-09-18 09:37:21 --> Model "User_model" initialized
INFO - 2025-09-18 14:37:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:37:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:37:21 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:37:21 --> Controller Class Initialized
INFO - 2025-09-18 14:37:21 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:37:21 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:37:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-18 14:37:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 14:37:21 --> Model "Log_model" initialized
INFO - 2025-09-18 14:37:21 --> Final output sent to browser
DEBUG - 2025-09-18 14:37:21 --> Total execution time: 0.1240
INFO - 2025-09-18 09:41:16 --> Config Class Initialized
INFO - 2025-09-18 09:41:16 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:41:16 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:41:16 --> Utf8 Class Initialized
INFO - 2025-09-18 09:41:16 --> URI Class Initialized
INFO - 2025-09-18 09:41:16 --> Router Class Initialized
INFO - 2025-09-18 09:41:16 --> Output Class Initialized
INFO - 2025-09-18 09:41:16 --> Security Class Initialized
DEBUG - 2025-09-18 09:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:41:16 --> CSRF cookie sent
INFO - 2025-09-18 09:41:16 --> Input Class Initialized
INFO - 2025-09-18 09:41:16 --> Language Class Initialized
INFO - 2025-09-18 09:41:16 --> Loader Class Initialized
INFO - 2025-09-18 09:41:16 --> Helper loaded: url_helper
INFO - 2025-09-18 09:41:16 --> Helper loaded: text_helper
INFO - 2025-09-18 09:41:16 --> Helper loaded: string_helper
INFO - 2025-09-18 09:41:16 --> Helper loaded: form_helper
INFO - 2025-09-18 09:41:16 --> Helper loaded: download_helper
INFO - 2025-09-18 09:41:16 --> Helper loaded: security_helper
INFO - 2025-09-18 09:41:16 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:41:16 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:41:16 --> Form Validation Class Initialized
INFO - 2025-09-18 09:41:16 --> Model "User_model" initialized
INFO - 2025-09-18 14:41:16 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:41:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:41:16 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:41:16 --> Controller Class Initialized
INFO - 2025-09-18 14:41:16 --> Model "Pusat_model" initialized
INFO - 2025-09-18 14:41:16 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:41:16 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:41:16 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-18 14:41:16 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-09-18 14:41:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-18 14:41:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:41:16 --> Model "Log_model" initialized
INFO - 2025-09-18 14:41:16 --> Final output sent to browser
DEBUG - 2025-09-18 14:41:16 --> Total execution time: 0.2601
INFO - 2025-09-18 09:41:35 --> Config Class Initialized
INFO - 2025-09-18 09:41:35 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:41:35 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:41:35 --> Utf8 Class Initialized
INFO - 2025-09-18 09:41:35 --> URI Class Initialized
INFO - 2025-09-18 09:41:35 --> Router Class Initialized
INFO - 2025-09-18 09:41:35 --> Output Class Initialized
INFO - 2025-09-18 09:41:35 --> Security Class Initialized
DEBUG - 2025-09-18 09:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:41:35 --> CSRF cookie sent
INFO - 2025-09-18 09:41:35 --> Input Class Initialized
INFO - 2025-09-18 09:41:35 --> Language Class Initialized
INFO - 2025-09-18 09:41:35 --> Loader Class Initialized
INFO - 2025-09-18 09:41:35 --> Helper loaded: url_helper
INFO - 2025-09-18 09:41:35 --> Helper loaded: text_helper
INFO - 2025-09-18 09:41:35 --> Helper loaded: string_helper
INFO - 2025-09-18 09:41:35 --> Helper loaded: form_helper
INFO - 2025-09-18 09:41:35 --> Helper loaded: download_helper
INFO - 2025-09-18 09:41:35 --> Helper loaded: security_helper
INFO - 2025-09-18 09:41:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:41:35 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:41:35 --> Form Validation Class Initialized
INFO - 2025-09-18 09:41:35 --> Model "User_model" initialized
INFO - 2025-09-18 14:41:35 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:41:35 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:41:35 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:41:35 --> Controller Class Initialized
INFO - 2025-09-18 14:41:35 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:41:35 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:41:35 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:41:35 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 14:41:35 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 14:41:35 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:41:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:41:35 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 14:41:35 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 14:41:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 14:41:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:41:35 --> Model "Log_model" initialized
INFO - 2025-09-18 14:41:35 --> Final output sent to browser
DEBUG - 2025-09-18 14:41:35 --> Total execution time: 0.2269
INFO - 2025-09-18 09:41:44 --> Config Class Initialized
INFO - 2025-09-18 09:41:44 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:41:44 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:41:44 --> Utf8 Class Initialized
INFO - 2025-09-18 09:41:44 --> URI Class Initialized
INFO - 2025-09-18 09:41:44 --> Router Class Initialized
INFO - 2025-09-18 09:41:44 --> Output Class Initialized
INFO - 2025-09-18 09:41:44 --> Security Class Initialized
DEBUG - 2025-09-18 09:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:41:44 --> CSRF cookie sent
INFO - 2025-09-18 09:41:44 --> Input Class Initialized
INFO - 2025-09-18 09:41:44 --> Language Class Initialized
INFO - 2025-09-18 09:41:44 --> Loader Class Initialized
INFO - 2025-09-18 09:41:44 --> Helper loaded: url_helper
INFO - 2025-09-18 09:41:44 --> Helper loaded: text_helper
INFO - 2025-09-18 09:41:44 --> Helper loaded: string_helper
INFO - 2025-09-18 09:41:44 --> Helper loaded: form_helper
INFO - 2025-09-18 09:41:44 --> Helper loaded: download_helper
INFO - 2025-09-18 09:41:44 --> Helper loaded: security_helper
INFO - 2025-09-18 09:41:44 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:41:44 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:41:44 --> Form Validation Class Initialized
INFO - 2025-09-18 09:41:44 --> Model "User_model" initialized
INFO - 2025-09-18 14:41:44 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:41:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:41:44 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:41:44 --> Controller Class Initialized
INFO - 2025-09-18 14:41:44 --> Model "Pusat_model" initialized
INFO - 2025-09-18 14:41:44 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:41:44 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:41:44 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-18 14:41:44 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-09-18 14:41:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-18 14:41:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:41:44 --> Model "Log_model" initialized
INFO - 2025-09-18 14:41:44 --> Final output sent to browser
DEBUG - 2025-09-18 14:41:44 --> Total execution time: 0.1684
INFO - 2025-09-18 09:42:19 --> Config Class Initialized
INFO - 2025-09-18 09:42:19 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:42:19 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:42:19 --> Utf8 Class Initialized
INFO - 2025-09-18 09:42:19 --> URI Class Initialized
INFO - 2025-09-18 09:42:19 --> Router Class Initialized
INFO - 2025-09-18 09:42:19 --> Output Class Initialized
INFO - 2025-09-18 09:42:19 --> Security Class Initialized
DEBUG - 2025-09-18 09:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:42:19 --> CSRF cookie sent
INFO - 2025-09-18 09:42:19 --> Input Class Initialized
INFO - 2025-09-18 09:42:19 --> Language Class Initialized
INFO - 2025-09-18 09:42:19 --> Loader Class Initialized
INFO - 2025-09-18 09:42:19 --> Helper loaded: url_helper
INFO - 2025-09-18 09:42:19 --> Helper loaded: text_helper
INFO - 2025-09-18 09:42:19 --> Helper loaded: string_helper
INFO - 2025-09-18 09:42:19 --> Helper loaded: form_helper
INFO - 2025-09-18 09:42:19 --> Helper loaded: download_helper
INFO - 2025-09-18 09:42:19 --> Helper loaded: security_helper
INFO - 2025-09-18 09:42:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:42:19 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:42:19 --> Form Validation Class Initialized
INFO - 2025-09-18 09:42:19 --> Model "User_model" initialized
INFO - 2025-09-18 14:42:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:42:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:42:19 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:42:19 --> Controller Class Initialized
INFO - 2025-09-18 14:42:19 --> Model "Pusat_model" initialized
INFO - 2025-09-18 14:42:19 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:42:19 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:42:19 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-18 14:42:19 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-09-18 14:42:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-18 14:42:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:42:19 --> Model "Log_model" initialized
INFO - 2025-09-18 14:42:19 --> Final output sent to browser
DEBUG - 2025-09-18 14:42:19 --> Total execution time: 0.1997
INFO - 2025-09-18 09:55:31 --> Config Class Initialized
INFO - 2025-09-18 09:55:31 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:55:31 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:55:31 --> Utf8 Class Initialized
INFO - 2025-09-18 09:55:31 --> URI Class Initialized
INFO - 2025-09-18 09:55:31 --> Router Class Initialized
INFO - 2025-09-18 09:55:31 --> Output Class Initialized
INFO - 2025-09-18 09:55:31 --> Security Class Initialized
DEBUG - 2025-09-18 09:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:55:31 --> CSRF cookie sent
INFO - 2025-09-18 09:55:31 --> Input Class Initialized
INFO - 2025-09-18 09:55:31 --> Language Class Initialized
INFO - 2025-09-18 09:55:31 --> Loader Class Initialized
INFO - 2025-09-18 09:55:31 --> Helper loaded: url_helper
INFO - 2025-09-18 09:55:31 --> Helper loaded: text_helper
INFO - 2025-09-18 09:55:31 --> Helper loaded: string_helper
INFO - 2025-09-18 09:55:31 --> Helper loaded: form_helper
INFO - 2025-09-18 09:55:31 --> Helper loaded: download_helper
INFO - 2025-09-18 09:55:31 --> Helper loaded: security_helper
INFO - 2025-09-18 09:55:31 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:55:31 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:55:31 --> Form Validation Class Initialized
INFO - 2025-09-18 09:55:31 --> Model "User_model" initialized
INFO - 2025-09-18 14:55:31 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:55:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:55:31 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:55:31 --> Controller Class Initialized
INFO - 2025-09-18 14:55:31 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:55:31 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:55:31 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:55:31 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 14:55:31 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 14:55:31 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:55:31 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 14:55:31 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 14:55:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 14:55:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:55:31 --> Model "Log_model" initialized
INFO - 2025-09-18 14:55:31 --> Final output sent to browser
DEBUG - 2025-09-18 14:55:31 --> Total execution time: 0.2223
INFO - 2025-09-18 09:55:38 --> Config Class Initialized
INFO - 2025-09-18 09:55:38 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:55:38 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:55:38 --> Utf8 Class Initialized
INFO - 2025-09-18 09:55:38 --> URI Class Initialized
INFO - 2025-09-18 09:55:38 --> Router Class Initialized
INFO - 2025-09-18 09:55:38 --> Output Class Initialized
INFO - 2025-09-18 09:55:38 --> Security Class Initialized
DEBUG - 2025-09-18 09:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:55:38 --> CSRF cookie sent
INFO - 2025-09-18 09:55:38 --> Input Class Initialized
INFO - 2025-09-18 09:55:38 --> Language Class Initialized
INFO - 2025-09-18 09:55:38 --> Loader Class Initialized
INFO - 2025-09-18 09:55:38 --> Helper loaded: url_helper
INFO - 2025-09-18 09:55:38 --> Helper loaded: text_helper
INFO - 2025-09-18 09:55:38 --> Helper loaded: string_helper
INFO - 2025-09-18 09:55:38 --> Helper loaded: form_helper
INFO - 2025-09-18 09:55:38 --> Helper loaded: download_helper
INFO - 2025-09-18 09:55:38 --> Helper loaded: security_helper
INFO - 2025-09-18 09:55:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:55:38 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:55:38 --> Form Validation Class Initialized
INFO - 2025-09-18 09:55:38 --> Model "User_model" initialized
INFO - 2025-09-18 14:55:38 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:55:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:55:38 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:55:38 --> Controller Class Initialized
INFO - 2025-09-18 14:55:38 --> Model "Pages_model" initialized
INFO - 2025-09-18 14:55:38 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:55:38 --> Model "Download_model" initialized
INFO - 2025-09-18 14:55:38 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 14:55:38 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 14:55:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-09-18 14:55:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:55:38 --> Model "Log_model" initialized
INFO - 2025-09-18 14:55:38 --> Final output sent to browser
DEBUG - 2025-09-18 14:55:38 --> Total execution time: 0.1923
INFO - 2025-09-18 09:56:04 --> Config Class Initialized
INFO - 2025-09-18 09:56:04 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:56:04 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:56:04 --> Utf8 Class Initialized
INFO - 2025-09-18 09:56:04 --> URI Class Initialized
INFO - 2025-09-18 09:56:04 --> Router Class Initialized
INFO - 2025-09-18 09:56:04 --> Output Class Initialized
INFO - 2025-09-18 09:56:04 --> Security Class Initialized
DEBUG - 2025-09-18 09:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:56:04 --> CSRF cookie sent
INFO - 2025-09-18 09:56:04 --> Input Class Initialized
INFO - 2025-09-18 09:56:04 --> Language Class Initialized
INFO - 2025-09-18 09:56:04 --> Loader Class Initialized
INFO - 2025-09-18 09:56:04 --> Helper loaded: url_helper
INFO - 2025-09-18 09:56:04 --> Helper loaded: text_helper
INFO - 2025-09-18 09:56:04 --> Helper loaded: string_helper
INFO - 2025-09-18 09:56:04 --> Helper loaded: form_helper
INFO - 2025-09-18 09:56:04 --> Helper loaded: download_helper
INFO - 2025-09-18 09:56:04 --> Helper loaded: security_helper
INFO - 2025-09-18 09:56:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:56:04 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:56:04 --> Form Validation Class Initialized
INFO - 2025-09-18 09:56:04 --> Model "User_model" initialized
INFO - 2025-09-18 14:56:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:56:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:56:04 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:56:04 --> Controller Class Initialized
INFO - 2025-09-18 14:56:04 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:56:04 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:56:04 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:56:04 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 14:56:04 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 14:56:04 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:56:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:56:04 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 14:56:04 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 14:56:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 14:56:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:56:04 --> Model "Log_model" initialized
INFO - 2025-09-18 14:56:04 --> Final output sent to browser
DEBUG - 2025-09-18 14:56:04 --> Total execution time: 0.1866
INFO - 2025-09-18 09:56:28 --> Config Class Initialized
INFO - 2025-09-18 09:56:28 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:56:28 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:56:28 --> Utf8 Class Initialized
INFO - 2025-09-18 09:56:28 --> URI Class Initialized
DEBUG - 2025-09-18 09:56:28 --> No URI present. Default controller set.
INFO - 2025-09-18 09:56:28 --> Router Class Initialized
INFO - 2025-09-18 09:56:28 --> Output Class Initialized
INFO - 2025-09-18 09:56:28 --> Security Class Initialized
DEBUG - 2025-09-18 09:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:56:28 --> CSRF cookie sent
INFO - 2025-09-18 09:56:28 --> Input Class Initialized
INFO - 2025-09-18 09:56:28 --> Language Class Initialized
INFO - 2025-09-18 09:56:28 --> Loader Class Initialized
INFO - 2025-09-18 09:56:28 --> Helper loaded: url_helper
INFO - 2025-09-18 09:56:28 --> Helper loaded: text_helper
INFO - 2025-09-18 09:56:28 --> Helper loaded: string_helper
INFO - 2025-09-18 09:56:28 --> Helper loaded: form_helper
INFO - 2025-09-18 09:56:28 --> Helper loaded: download_helper
INFO - 2025-09-18 09:56:28 --> Helper loaded: security_helper
INFO - 2025-09-18 09:56:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:56:29 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:56:29 --> Form Validation Class Initialized
INFO - 2025-09-18 09:56:29 --> Model "User_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:56:29 --> Controller Class Initialized
INFO - 2025-09-18 14:56:29 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Galeri_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Video_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Agenda_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Tautan_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Mitra_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:56:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 14:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 14:56:29 --> Pagination Class Initialized
INFO - 2025-09-18 14:56:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 14:56:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:56:29 --> Model "Log_model" initialized
INFO - 2025-09-18 14:56:29 --> Final output sent to browser
DEBUG - 2025-09-18 14:56:29 --> Total execution time: 0.2762
INFO - 2025-09-18 09:57:56 --> Config Class Initialized
INFO - 2025-09-18 09:57:56 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:57:56 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:57:56 --> Utf8 Class Initialized
INFO - 2025-09-18 09:57:56 --> URI Class Initialized
INFO - 2025-09-18 09:57:56 --> Router Class Initialized
INFO - 2025-09-18 09:57:56 --> Output Class Initialized
INFO - 2025-09-18 09:57:56 --> Security Class Initialized
DEBUG - 2025-09-18 09:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:57:56 --> CSRF cookie sent
INFO - 2025-09-18 09:57:56 --> Input Class Initialized
INFO - 2025-09-18 09:57:56 --> Language Class Initialized
INFO - 2025-09-18 09:57:56 --> Loader Class Initialized
INFO - 2025-09-18 09:57:56 --> Helper loaded: url_helper
INFO - 2025-09-18 09:57:56 --> Helper loaded: text_helper
INFO - 2025-09-18 09:57:56 --> Helper loaded: string_helper
INFO - 2025-09-18 09:57:56 --> Helper loaded: form_helper
INFO - 2025-09-18 09:57:56 --> Helper loaded: download_helper
INFO - 2025-09-18 09:57:56 --> Helper loaded: security_helper
INFO - 2025-09-18 09:57:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:57:56 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:57:56 --> Form Validation Class Initialized
INFO - 2025-09-18 09:57:56 --> Model "User_model" initialized
INFO - 2025-09-18 14:57:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:57:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:57:56 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:57:56 --> Controller Class Initialized
INFO - 2025-09-18 14:57:56 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:57:56 --> Model "Kategori_model" initialized
INFO - 2025-09-18 14:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 14:57:56 --> Pagination Class Initialized
INFO - 2025-09-18 14:57:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2025-09-18 14:57:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:57:56 --> Model "Log_model" initialized
INFO - 2025-09-18 14:57:56 --> Final output sent to browser
DEBUG - 2025-09-18 14:57:56 --> Total execution time: 0.1235
INFO - 2025-09-18 09:58:00 --> Config Class Initialized
INFO - 2025-09-18 09:58:00 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:58:00 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:58:00 --> Utf8 Class Initialized
INFO - 2025-09-18 09:58:00 --> URI Class Initialized
INFO - 2025-09-18 09:58:00 --> Router Class Initialized
INFO - 2025-09-18 09:58:00 --> Output Class Initialized
INFO - 2025-09-18 09:58:00 --> Security Class Initialized
DEBUG - 2025-09-18 09:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:58:00 --> CSRF cookie sent
INFO - 2025-09-18 09:58:00 --> Input Class Initialized
INFO - 2025-09-18 09:58:00 --> Language Class Initialized
INFO - 2025-09-18 09:58:00 --> Loader Class Initialized
INFO - 2025-09-18 09:58:00 --> Helper loaded: url_helper
INFO - 2025-09-18 09:58:00 --> Helper loaded: text_helper
INFO - 2025-09-18 09:58:00 --> Helper loaded: string_helper
INFO - 2025-09-18 09:58:00 --> Helper loaded: form_helper
INFO - 2025-09-18 09:58:00 --> Helper loaded: download_helper
INFO - 2025-09-18 09:58:00 --> Helper loaded: security_helper
INFO - 2025-09-18 09:58:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:58:00 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:58:00 --> Form Validation Class Initialized
INFO - 2025-09-18 09:58:00 --> Model "User_model" initialized
INFO - 2025-09-18 14:58:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:58:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:58:00 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:58:00 --> Controller Class Initialized
INFO - 2025-09-18 14:58:00 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:58:00 --> Model "Kategori_model" initialized
INFO - 2025-09-18 14:58:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 14:58:00 --> Pagination Class Initialized
INFO - 2025-09-18 14:58:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2025-09-18 14:58:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:58:00 --> Model "Log_model" initialized
INFO - 2025-09-18 14:58:00 --> Final output sent to browser
DEBUG - 2025-09-18 14:58:00 --> Total execution time: 0.2097
INFO - 2025-09-18 09:58:04 --> Config Class Initialized
INFO - 2025-09-18 09:58:04 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:58:04 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:58:04 --> Utf8 Class Initialized
INFO - 2025-09-18 09:58:04 --> URI Class Initialized
INFO - 2025-09-18 09:58:04 --> Router Class Initialized
INFO - 2025-09-18 09:58:04 --> Output Class Initialized
INFO - 2025-09-18 09:58:04 --> Security Class Initialized
DEBUG - 2025-09-18 09:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:58:04 --> CSRF cookie sent
INFO - 2025-09-18 09:58:04 --> Input Class Initialized
INFO - 2025-09-18 09:58:04 --> Language Class Initialized
INFO - 2025-09-18 09:58:04 --> Loader Class Initialized
INFO - 2025-09-18 09:58:04 --> Helper loaded: url_helper
INFO - 2025-09-18 09:58:04 --> Helper loaded: text_helper
INFO - 2025-09-18 09:58:04 --> Helper loaded: string_helper
INFO - 2025-09-18 09:58:04 --> Helper loaded: form_helper
INFO - 2025-09-18 09:58:04 --> Helper loaded: download_helper
INFO - 2025-09-18 09:58:04 --> Helper loaded: security_helper
INFO - 2025-09-18 09:58:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:58:04 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:58:04 --> Form Validation Class Initialized
INFO - 2025-09-18 09:58:04 --> Model "User_model" initialized
INFO - 2025-09-18 14:58:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:58:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:58:04 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:58:04 --> Controller Class Initialized
INFO - 2025-09-18 14:58:04 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:58:04 --> Model "Kategori_model" initialized
INFO - 2025-09-18 14:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 14:58:04 --> Pagination Class Initialized
INFO - 2025-09-18 14:58:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2025-09-18 14:58:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:58:04 --> Model "Log_model" initialized
INFO - 2025-09-18 14:58:04 --> Final output sent to browser
DEBUG - 2025-09-18 14:58:04 --> Total execution time: 0.1043
INFO - 2025-09-18 09:58:27 --> Config Class Initialized
INFO - 2025-09-18 09:58:27 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:58:27 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:58:27 --> Utf8 Class Initialized
INFO - 2025-09-18 09:58:27 --> URI Class Initialized
INFO - 2025-09-18 09:58:27 --> Router Class Initialized
INFO - 2025-09-18 09:58:27 --> Output Class Initialized
INFO - 2025-09-18 09:58:27 --> Security Class Initialized
DEBUG - 2025-09-18 09:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:58:27 --> CSRF cookie sent
INFO - 2025-09-18 09:58:27 --> Input Class Initialized
INFO - 2025-09-18 09:58:27 --> Language Class Initialized
INFO - 2025-09-18 09:58:27 --> Loader Class Initialized
INFO - 2025-09-18 09:58:27 --> Helper loaded: url_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: text_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: string_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: form_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: download_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: security_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:58:27 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:58:27 --> Form Validation Class Initialized
INFO - 2025-09-18 09:58:27 --> Model "User_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:58:27 --> Controller Class Initialized
INFO - 2025-09-18 14:58:27 --> Model "Pages_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Download_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 14:58:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-09-18 14:58:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:58:27 --> Model "Log_model" initialized
INFO - 2025-09-18 14:58:27 --> Final output sent to browser
DEBUG - 2025-09-18 14:58:27 --> Total execution time: 0.1526
INFO - 2025-09-18 09:58:27 --> Config Class Initialized
INFO - 2025-09-18 09:58:27 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:58:27 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:58:27 --> Utf8 Class Initialized
INFO - 2025-09-18 09:58:27 --> URI Class Initialized
INFO - 2025-09-18 09:58:27 --> Router Class Initialized
INFO - 2025-09-18 09:58:27 --> Output Class Initialized
INFO - 2025-09-18 09:58:27 --> Security Class Initialized
DEBUG - 2025-09-18 09:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:58:27 --> CSRF cookie sent
INFO - 2025-09-18 09:58:27 --> Input Class Initialized
INFO - 2025-09-18 09:58:27 --> Language Class Initialized
INFO - 2025-09-18 09:58:27 --> Loader Class Initialized
INFO - 2025-09-18 09:58:27 --> Helper loaded: url_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: text_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: string_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: form_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: download_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: security_helper
INFO - 2025-09-18 09:58:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:58:27 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:58:27 --> Form Validation Class Initialized
INFO - 2025-09-18 09:58:27 --> Model "User_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:58:27 --> Controller Class Initialized
INFO - 2025-09-18 14:58:27 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Galeri_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Video_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Agenda_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Tautan_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Mitra_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:58:27 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 14:58:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 14:58:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:58:27 --> Model "Log_model" initialized
INFO - 2025-09-18 14:58:27 --> Final output sent to browser
DEBUG - 2025-09-18 14:58:27 --> Total execution time: 0.1135
INFO - 2025-09-18 09:58:55 --> Config Class Initialized
INFO - 2025-09-18 09:58:55 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:58:55 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:58:55 --> Utf8 Class Initialized
INFO - 2025-09-18 09:58:55 --> URI Class Initialized
INFO - 2025-09-18 09:58:55 --> Router Class Initialized
INFO - 2025-09-18 09:58:55 --> Output Class Initialized
INFO - 2025-09-18 09:58:55 --> Security Class Initialized
DEBUG - 2025-09-18 09:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:58:55 --> CSRF cookie sent
INFO - 2025-09-18 09:58:55 --> Input Class Initialized
INFO - 2025-09-18 09:58:55 --> Language Class Initialized
INFO - 2025-09-18 09:58:55 --> Loader Class Initialized
INFO - 2025-09-18 09:58:55 --> Helper loaded: url_helper
INFO - 2025-09-18 09:58:55 --> Helper loaded: text_helper
INFO - 2025-09-18 09:58:55 --> Helper loaded: string_helper
INFO - 2025-09-18 09:58:55 --> Helper loaded: form_helper
INFO - 2025-09-18 09:58:55 --> Helper loaded: download_helper
INFO - 2025-09-18 09:58:55 --> Helper loaded: security_helper
INFO - 2025-09-18 09:58:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:58:55 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:58:55 --> Form Validation Class Initialized
INFO - 2025-09-18 09:58:55 --> Model "User_model" initialized
INFO - 2025-09-18 14:58:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:58:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:58:55 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:58:55 --> Controller Class Initialized
INFO - 2025-09-18 14:58:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 14:58:55 --> Model "Prodi_model" initialized
INFO - 2025-09-18 14:58:55 --> Model "Sdm_model" initialized
INFO - 2025-09-18 14:58:55 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-18 14:58:55 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-18 14:58:55 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:58:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-18 14:58:55 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-18 14:58:55 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-18 14:58:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-18 14:58:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:58:55 --> Model "Log_model" initialized
INFO - 2025-09-18 14:58:55 --> Final output sent to browser
DEBUG - 2025-09-18 14:58:55 --> Total execution time: 0.2220
INFO - 2025-09-18 09:59:48 --> Config Class Initialized
INFO - 2025-09-18 09:59:48 --> Hooks Class Initialized
DEBUG - 2025-09-18 09:59:48 --> UTF-8 Support Enabled
INFO - 2025-09-18 09:59:48 --> Utf8 Class Initialized
INFO - 2025-09-18 09:59:48 --> URI Class Initialized
INFO - 2025-09-18 09:59:48 --> Router Class Initialized
INFO - 2025-09-18 09:59:48 --> Output Class Initialized
INFO - 2025-09-18 09:59:48 --> Security Class Initialized
DEBUG - 2025-09-18 09:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 09:59:48 --> CSRF cookie sent
INFO - 2025-09-18 09:59:48 --> Input Class Initialized
INFO - 2025-09-18 09:59:48 --> Language Class Initialized
INFO - 2025-09-18 09:59:48 --> Loader Class Initialized
INFO - 2025-09-18 09:59:48 --> Helper loaded: url_helper
INFO - 2025-09-18 09:59:48 --> Helper loaded: text_helper
INFO - 2025-09-18 09:59:48 --> Helper loaded: string_helper
INFO - 2025-09-18 09:59:48 --> Helper loaded: form_helper
INFO - 2025-09-18 09:59:48 --> Helper loaded: download_helper
INFO - 2025-09-18 09:59:48 --> Helper loaded: security_helper
INFO - 2025-09-18 09:59:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 09:59:48 --> Database Driver Class Initialized
DEBUG - 2025-09-18 09:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 09:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 09:59:48 --> Form Validation Class Initialized
INFO - 2025-09-18 09:59:48 --> Model "User_model" initialized
INFO - 2025-09-18 14:59:48 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 14:59:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 14:59:48 --> Model "Nav_model" initialized
INFO - 2025-09-18 14:59:48 --> Controller Class Initialized
INFO - 2025-09-18 14:59:48 --> Model "Pages_model" initialized
INFO - 2025-09-18 14:59:48 --> Model "Berita_model" initialized
INFO - 2025-09-18 14:59:48 --> Model "Download_model" initialized
INFO - 2025-09-18 14:59:48 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 14:59:48 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 14:59:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-09-18 14:59:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 14:59:48 --> Model "Log_model" initialized
INFO - 2025-09-18 14:59:48 --> Final output sent to browser
DEBUG - 2025-09-18 14:59:48 --> Total execution time: 0.2555
INFO - 2025-09-18 10:00:42 --> Config Class Initialized
INFO - 2025-09-18 10:00:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:00:42 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:00:42 --> Utf8 Class Initialized
INFO - 2025-09-18 10:00:42 --> URI Class Initialized
INFO - 2025-09-18 10:00:42 --> Router Class Initialized
INFO - 2025-09-18 10:00:42 --> Output Class Initialized
INFO - 2025-09-18 10:00:42 --> Security Class Initialized
DEBUG - 2025-09-18 10:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:00:42 --> CSRF cookie sent
INFO - 2025-09-18 10:00:42 --> Input Class Initialized
INFO - 2025-09-18 10:00:42 --> Language Class Initialized
INFO - 2025-09-18 10:00:42 --> Loader Class Initialized
INFO - 2025-09-18 10:00:42 --> Helper loaded: url_helper
INFO - 2025-09-18 10:00:42 --> Helper loaded: text_helper
INFO - 2025-09-18 10:00:42 --> Helper loaded: string_helper
INFO - 2025-09-18 10:00:42 --> Helper loaded: form_helper
INFO - 2025-09-18 10:00:42 --> Helper loaded: download_helper
INFO - 2025-09-18 10:00:42 --> Helper loaded: security_helper
INFO - 2025-09-18 10:00:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:00:42 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:00:42 --> Form Validation Class Initialized
INFO - 2025-09-18 10:00:42 --> Model "User_model" initialized
INFO - 2025-09-18 15:00:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:00:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:00:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:00:42 --> Controller Class Initialized
INFO - 2025-09-18 15:00:42 --> Model "Pages_model" initialized
INFO - 2025-09-18 15:00:42 --> Model "Download_model" initialized
INFO - 2025-09-18 15:00:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pages/list.php
INFO - 2025-09-18 15:00:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:00:42 --> Model "Log_model" initialized
INFO - 2025-09-18 15:00:42 --> Final output sent to browser
DEBUG - 2025-09-18 15:00:42 --> Total execution time: 0.0993
INFO - 2025-09-18 10:00:42 --> Config Class Initialized
INFO - 2025-09-18 10:00:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:00:43 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:00:43 --> Utf8 Class Initialized
INFO - 2025-09-18 10:00:43 --> URI Class Initialized
INFO - 2025-09-18 10:00:43 --> Router Class Initialized
INFO - 2025-09-18 10:00:43 --> Output Class Initialized
INFO - 2025-09-18 10:00:43 --> Security Class Initialized
DEBUG - 2025-09-18 10:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:00:43 --> CSRF cookie sent
INFO - 2025-09-18 10:00:43 --> Input Class Initialized
INFO - 2025-09-18 10:00:43 --> Language Class Initialized
INFO - 2025-09-18 10:00:43 --> Loader Class Initialized
INFO - 2025-09-18 10:00:43 --> Helper loaded: url_helper
INFO - 2025-09-18 10:00:43 --> Helper loaded: text_helper
INFO - 2025-09-18 10:00:43 --> Helper loaded: string_helper
INFO - 2025-09-18 10:00:43 --> Helper loaded: form_helper
INFO - 2025-09-18 10:00:43 --> Helper loaded: download_helper
INFO - 2025-09-18 10:00:43 --> Helper loaded: security_helper
INFO - 2025-09-18 10:00:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:00:43 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:00:43 --> Form Validation Class Initialized
INFO - 2025-09-18 10:00:43 --> Model "User_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:00:43 --> Controller Class Initialized
INFO - 2025-09-18 15:00:43 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Video_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:00:43 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:00:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 15:00:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:00:43 --> Model "Log_model" initialized
INFO - 2025-09-18 15:00:43 --> Final output sent to browser
DEBUG - 2025-09-18 15:00:43 --> Total execution time: 0.1375
INFO - 2025-09-18 10:00:47 --> Config Class Initialized
INFO - 2025-09-18 10:00:47 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:00:47 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:00:47 --> Utf8 Class Initialized
INFO - 2025-09-18 10:00:47 --> URI Class Initialized
INFO - 2025-09-18 10:00:47 --> Router Class Initialized
INFO - 2025-09-18 10:00:47 --> Output Class Initialized
INFO - 2025-09-18 10:00:47 --> Security Class Initialized
DEBUG - 2025-09-18 10:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:00:47 --> CSRF cookie sent
INFO - 2025-09-18 10:00:47 --> Input Class Initialized
INFO - 2025-09-18 10:00:47 --> Language Class Initialized
INFO - 2025-09-18 10:00:47 --> Loader Class Initialized
INFO - 2025-09-18 10:00:47 --> Helper loaded: url_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: text_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: string_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: form_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: download_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: security_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:00:47 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:00:47 --> Form Validation Class Initialized
INFO - 2025-09-18 10:00:47 --> Model "User_model" initialized
INFO - 2025-09-18 15:00:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:00:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:00:47 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:00:47 --> Controller Class Initialized
INFO - 2025-09-18 15:00:47 --> Model "Pages_model" initialized
INFO - 2025-09-18 15:00:47 --> Model "Download_model" initialized
INFO - 2025-09-18 15:00:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pages/edit.php
INFO - 2025-09-18 15:00:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:00:47 --> Model "Log_model" initialized
INFO - 2025-09-18 15:00:47 --> Final output sent to browser
DEBUG - 2025-09-18 15:00:47 --> Total execution time: 0.1776
INFO - 2025-09-18 10:00:47 --> Config Class Initialized
INFO - 2025-09-18 10:00:47 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:00:47 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:00:47 --> Utf8 Class Initialized
INFO - 2025-09-18 10:00:47 --> URI Class Initialized
INFO - 2025-09-18 10:00:47 --> Router Class Initialized
INFO - 2025-09-18 10:00:47 --> Output Class Initialized
INFO - 2025-09-18 10:00:47 --> Security Class Initialized
DEBUG - 2025-09-18 10:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:00:47 --> CSRF cookie sent
INFO - 2025-09-18 10:00:47 --> Input Class Initialized
INFO - 2025-09-18 10:00:47 --> Language Class Initialized
INFO - 2025-09-18 10:00:47 --> Loader Class Initialized
INFO - 2025-09-18 10:00:47 --> Helper loaded: url_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: text_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: string_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: form_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: download_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: security_helper
INFO - 2025-09-18 10:00:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:00:47 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:00:48 --> Form Validation Class Initialized
INFO - 2025-09-18 10:00:48 --> Model "User_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:00:48 --> Controller Class Initialized
INFO - 2025-09-18 15:00:48 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Video_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:00:48 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:00:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 15:00:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:00:48 --> Model "Log_model" initialized
INFO - 2025-09-18 15:00:48 --> Final output sent to browser
DEBUG - 2025-09-18 15:00:48 --> Total execution time: 0.1087
INFO - 2025-09-18 10:01:28 --> Config Class Initialized
INFO - 2025-09-18 10:01:28 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:01:28 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:01:28 --> Utf8 Class Initialized
INFO - 2025-09-18 10:01:28 --> URI Class Initialized
INFO - 2025-09-18 10:01:28 --> Router Class Initialized
INFO - 2025-09-18 10:01:28 --> Output Class Initialized
INFO - 2025-09-18 10:01:28 --> Security Class Initialized
DEBUG - 2025-09-18 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:01:28 --> CSRF cookie sent
INFO - 2025-09-18 10:01:28 --> CSRF token verified
INFO - 2025-09-18 10:01:28 --> Input Class Initialized
INFO - 2025-09-18 10:01:28 --> Language Class Initialized
INFO - 2025-09-18 10:01:28 --> Loader Class Initialized
INFO - 2025-09-18 10:01:28 --> Helper loaded: url_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: text_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: string_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: form_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: download_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: security_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:01:28 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:01:28 --> Form Validation Class Initialized
INFO - 2025-09-18 10:01:28 --> Model "User_model" initialized
INFO - 2025-09-18 15:01:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:01:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:01:28 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:01:28 --> Controller Class Initialized
INFO - 2025-09-18 15:01:28 --> Model "Pages_model" initialized
INFO - 2025-09-18 15:01:28 --> Model "Download_model" initialized
INFO - 2025-09-18 15:01:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 10:01:28 --> Config Class Initialized
INFO - 2025-09-18 10:01:28 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:01:28 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:01:28 --> Utf8 Class Initialized
INFO - 2025-09-18 10:01:28 --> URI Class Initialized
INFO - 2025-09-18 10:01:28 --> Router Class Initialized
INFO - 2025-09-18 10:01:28 --> Output Class Initialized
INFO - 2025-09-18 10:01:28 --> Security Class Initialized
DEBUG - 2025-09-18 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:01:28 --> CSRF cookie sent
INFO - 2025-09-18 10:01:28 --> Input Class Initialized
INFO - 2025-09-18 10:01:28 --> Language Class Initialized
INFO - 2025-09-18 10:01:28 --> Loader Class Initialized
INFO - 2025-09-18 10:01:28 --> Helper loaded: url_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: text_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: string_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: form_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: download_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: security_helper
INFO - 2025-09-18 10:01:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:01:28 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:01:28 --> Form Validation Class Initialized
INFO - 2025-09-18 10:01:28 --> Model "User_model" initialized
INFO - 2025-09-18 15:01:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:01:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:01:28 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:01:28 --> Controller Class Initialized
INFO - 2025-09-18 15:01:28 --> Model "Pages_model" initialized
INFO - 2025-09-18 15:01:28 --> Model "Download_model" initialized
INFO - 2025-09-18 15:01:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pages/list.php
INFO - 2025-09-18 15:01:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:01:29 --> Model "Log_model" initialized
INFO - 2025-09-18 15:01:29 --> Final output sent to browser
DEBUG - 2025-09-18 15:01:29 --> Total execution time: 0.1198
INFO - 2025-09-18 10:01:29 --> Config Class Initialized
INFO - 2025-09-18 10:01:29 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:01:29 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:01:29 --> Utf8 Class Initialized
INFO - 2025-09-18 10:01:29 --> URI Class Initialized
INFO - 2025-09-18 10:01:29 --> Router Class Initialized
INFO - 2025-09-18 10:01:29 --> Output Class Initialized
INFO - 2025-09-18 10:01:29 --> Security Class Initialized
DEBUG - 2025-09-18 10:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:01:29 --> CSRF cookie sent
INFO - 2025-09-18 10:01:29 --> Input Class Initialized
INFO - 2025-09-18 10:01:29 --> Language Class Initialized
INFO - 2025-09-18 10:01:29 --> Loader Class Initialized
INFO - 2025-09-18 10:01:29 --> Helper loaded: url_helper
INFO - 2025-09-18 10:01:29 --> Helper loaded: text_helper
INFO - 2025-09-18 10:01:29 --> Helper loaded: string_helper
INFO - 2025-09-18 10:01:29 --> Helper loaded: form_helper
INFO - 2025-09-18 10:01:29 --> Helper loaded: download_helper
INFO - 2025-09-18 10:01:29 --> Helper loaded: security_helper
INFO - 2025-09-18 10:01:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:01:29 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:01:29 --> Form Validation Class Initialized
INFO - 2025-09-18 10:01:29 --> Model "User_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:01:29 --> Controller Class Initialized
INFO - 2025-09-18 15:01:29 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Video_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:01:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:01:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-18 15:01:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:01:29 --> Model "Log_model" initialized
INFO - 2025-09-18 15:01:29 --> Final output sent to browser
DEBUG - 2025-09-18 15:01:29 --> Total execution time: 0.1449
INFO - 2025-09-18 10:01:33 --> Config Class Initialized
INFO - 2025-09-18 10:01:33 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:01:33 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:01:33 --> Utf8 Class Initialized
INFO - 2025-09-18 10:01:33 --> URI Class Initialized
INFO - 2025-09-18 10:01:33 --> Router Class Initialized
INFO - 2025-09-18 10:01:33 --> Output Class Initialized
INFO - 2025-09-18 10:01:33 --> Security Class Initialized
DEBUG - 2025-09-18 10:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:01:33 --> CSRF cookie sent
INFO - 2025-09-18 10:01:33 --> Input Class Initialized
INFO - 2025-09-18 10:01:33 --> Language Class Initialized
INFO - 2025-09-18 10:01:33 --> Loader Class Initialized
INFO - 2025-09-18 10:01:33 --> Helper loaded: url_helper
INFO - 2025-09-18 10:01:33 --> Helper loaded: text_helper
INFO - 2025-09-18 10:01:33 --> Helper loaded: string_helper
INFO - 2025-09-18 10:01:33 --> Helper loaded: form_helper
INFO - 2025-09-18 10:01:33 --> Helper loaded: download_helper
INFO - 2025-09-18 10:01:33 --> Helper loaded: security_helper
INFO - 2025-09-18 10:01:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:01:33 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:01:33 --> Form Validation Class Initialized
INFO - 2025-09-18 10:01:33 --> Model "User_model" initialized
INFO - 2025-09-18 15:01:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:01:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:01:33 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:01:33 --> Controller Class Initialized
INFO - 2025-09-18 15:01:33 --> Model "Pages_model" initialized
INFO - 2025-09-18 15:01:33 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:01:33 --> Model "Download_model" initialized
INFO - 2025-09-18 15:01:33 --> Model "Kategori_download_model" initialized
INFO - 2025-09-18 15:01:33 --> Model "Jenis_download_model" initialized
INFO - 2025-09-18 15:01:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-09-18 15:01:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:01:33 --> Model "Log_model" initialized
INFO - 2025-09-18 15:01:33 --> Final output sent to browser
DEBUG - 2025-09-18 15:01:33 --> Total execution time: 0.1599
INFO - 2025-09-18 10:01:44 --> Config Class Initialized
INFO - 2025-09-18 10:01:44 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:01:44 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:01:44 --> Utf8 Class Initialized
INFO - 2025-09-18 10:01:44 --> URI Class Initialized
DEBUG - 2025-09-18 10:01:44 --> No URI present. Default controller set.
INFO - 2025-09-18 10:01:44 --> Router Class Initialized
INFO - 2025-09-18 10:01:44 --> Output Class Initialized
INFO - 2025-09-18 10:01:44 --> Security Class Initialized
DEBUG - 2025-09-18 10:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:01:44 --> CSRF cookie sent
INFO - 2025-09-18 10:01:44 --> Input Class Initialized
INFO - 2025-09-18 10:01:44 --> Language Class Initialized
INFO - 2025-09-18 10:01:44 --> Loader Class Initialized
INFO - 2025-09-18 10:01:44 --> Helper loaded: url_helper
INFO - 2025-09-18 10:01:44 --> Helper loaded: text_helper
INFO - 2025-09-18 10:01:44 --> Helper loaded: string_helper
INFO - 2025-09-18 10:01:44 --> Helper loaded: form_helper
INFO - 2025-09-18 10:01:44 --> Helper loaded: download_helper
INFO - 2025-09-18 10:01:44 --> Helper loaded: security_helper
INFO - 2025-09-18 10:01:44 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:01:44 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:01:44 --> Form Validation Class Initialized
INFO - 2025-09-18 10:01:44 --> Model "User_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:01:44 --> Controller Class Initialized
INFO - 2025-09-18 15:01:44 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Video_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:01:44 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:01:44 --> Pagination Class Initialized
INFO - 2025-09-18 15:01:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:01:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:01:44 --> Model "Log_model" initialized
INFO - 2025-09-18 15:01:44 --> Final output sent to browser
DEBUG - 2025-09-18 15:01:44 --> Total execution time: 0.2668
INFO - 2025-09-18 10:02:27 --> Config Class Initialized
INFO - 2025-09-18 10:02:27 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:02:27 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:02:27 --> Utf8 Class Initialized
INFO - 2025-09-18 10:02:27 --> URI Class Initialized
DEBUG - 2025-09-18 10:02:27 --> No URI present. Default controller set.
INFO - 2025-09-18 10:02:27 --> Router Class Initialized
INFO - 2025-09-18 10:02:27 --> Output Class Initialized
INFO - 2025-09-18 10:02:27 --> Security Class Initialized
DEBUG - 2025-09-18 10:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:02:27 --> CSRF cookie sent
INFO - 2025-09-18 10:02:27 --> Input Class Initialized
INFO - 2025-09-18 10:02:27 --> Language Class Initialized
INFO - 2025-09-18 10:02:27 --> Loader Class Initialized
INFO - 2025-09-18 10:02:27 --> Helper loaded: url_helper
INFO - 2025-09-18 10:02:27 --> Helper loaded: text_helper
INFO - 2025-09-18 10:02:27 --> Helper loaded: string_helper
INFO - 2025-09-18 10:02:27 --> Helper loaded: form_helper
INFO - 2025-09-18 10:02:27 --> Helper loaded: download_helper
INFO - 2025-09-18 10:02:27 --> Helper loaded: security_helper
INFO - 2025-09-18 10:02:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:02:27 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:02:27 --> Form Validation Class Initialized
INFO - 2025-09-18 10:02:27 --> Model "User_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:02:27 --> Controller Class Initialized
INFO - 2025-09-18 15:02:27 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Video_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:02:27 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:02:27 --> Pagination Class Initialized
INFO - 2025-09-18 15:02:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:02:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:02:27 --> Model "Log_model" initialized
INFO - 2025-09-18 15:02:27 --> Final output sent to browser
DEBUG - 2025-09-18 15:02:27 --> Total execution time: 0.2660
INFO - 2025-09-18 10:10:58 --> Config Class Initialized
INFO - 2025-09-18 10:10:58 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:10:58 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:10:58 --> Utf8 Class Initialized
INFO - 2025-09-18 10:10:58 --> URI Class Initialized
DEBUG - 2025-09-18 10:10:58 --> No URI present. Default controller set.
INFO - 2025-09-18 10:10:58 --> Router Class Initialized
INFO - 2025-09-18 10:10:58 --> Output Class Initialized
INFO - 2025-09-18 10:10:58 --> Security Class Initialized
DEBUG - 2025-09-18 10:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:10:58 --> CSRF cookie sent
INFO - 2025-09-18 10:10:58 --> Input Class Initialized
INFO - 2025-09-18 10:10:58 --> Language Class Initialized
INFO - 2025-09-18 10:10:58 --> Loader Class Initialized
INFO - 2025-09-18 10:10:58 --> Helper loaded: url_helper
INFO - 2025-09-18 10:10:58 --> Helper loaded: text_helper
INFO - 2025-09-18 10:10:58 --> Helper loaded: string_helper
INFO - 2025-09-18 10:10:58 --> Helper loaded: form_helper
INFO - 2025-09-18 10:10:58 --> Helper loaded: download_helper
INFO - 2025-09-18 10:10:58 --> Helper loaded: security_helper
INFO - 2025-09-18 10:10:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:10:58 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:10:58 --> Form Validation Class Initialized
INFO - 2025-09-18 10:10:58 --> Model "User_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:10:58 --> Controller Class Initialized
INFO - 2025-09-18 15:10:58 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Video_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:10:58 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:10:59 --> Pagination Class Initialized
INFO - 2025-09-18 15:10:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:10:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:10:59 --> Model "Log_model" initialized
INFO - 2025-09-18 15:10:59 --> Final output sent to browser
DEBUG - 2025-09-18 15:10:59 --> Total execution time: 0.2133
INFO - 2025-09-18 10:11:33 --> Config Class Initialized
INFO - 2025-09-18 10:11:33 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:11:33 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:11:33 --> Utf8 Class Initialized
INFO - 2025-09-18 10:11:33 --> URI Class Initialized
DEBUG - 2025-09-18 10:11:33 --> No URI present. Default controller set.
INFO - 2025-09-18 10:11:33 --> Router Class Initialized
INFO - 2025-09-18 10:11:33 --> Output Class Initialized
INFO - 2025-09-18 10:11:33 --> Security Class Initialized
DEBUG - 2025-09-18 10:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:11:33 --> CSRF cookie sent
INFO - 2025-09-18 10:11:33 --> Input Class Initialized
INFO - 2025-09-18 10:11:33 --> Language Class Initialized
INFO - 2025-09-18 10:11:33 --> Loader Class Initialized
INFO - 2025-09-18 10:11:33 --> Helper loaded: url_helper
INFO - 2025-09-18 10:11:33 --> Helper loaded: text_helper
INFO - 2025-09-18 10:11:33 --> Helper loaded: string_helper
INFO - 2025-09-18 10:11:33 --> Helper loaded: form_helper
INFO - 2025-09-18 10:11:33 --> Helper loaded: download_helper
INFO - 2025-09-18 10:11:33 --> Helper loaded: security_helper
INFO - 2025-09-18 10:11:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:11:33 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:11:33 --> Form Validation Class Initialized
INFO - 2025-09-18 10:11:33 --> Model "User_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:11:33 --> Controller Class Initialized
INFO - 2025-09-18 15:11:33 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Video_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:11:33 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:11:33 --> Pagination Class Initialized
INFO - 2025-09-18 15:11:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:11:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:11:33 --> Model "Log_model" initialized
INFO - 2025-09-18 15:11:33 --> Final output sent to browser
DEBUG - 2025-09-18 15:11:33 --> Total execution time: 0.2983
INFO - 2025-09-18 10:13:28 --> Config Class Initialized
INFO - 2025-09-18 10:13:28 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:13:28 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:13:28 --> Utf8 Class Initialized
INFO - 2025-09-18 10:13:28 --> URI Class Initialized
INFO - 2025-09-18 10:13:28 --> Router Class Initialized
INFO - 2025-09-18 10:13:28 --> Output Class Initialized
INFO - 2025-09-18 10:13:28 --> Security Class Initialized
DEBUG - 2025-09-18 10:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:13:28 --> CSRF cookie sent
INFO - 2025-09-18 10:13:28 --> Input Class Initialized
INFO - 2025-09-18 10:13:28 --> Language Class Initialized
INFO - 2025-09-18 10:13:28 --> Loader Class Initialized
INFO - 2025-09-18 10:13:28 --> Helper loaded: url_helper
INFO - 2025-09-18 10:13:28 --> Helper loaded: text_helper
INFO - 2025-09-18 10:13:28 --> Helper loaded: string_helper
INFO - 2025-09-18 10:13:28 --> Helper loaded: form_helper
INFO - 2025-09-18 10:13:28 --> Helper loaded: download_helper
INFO - 2025-09-18 10:13:28 --> Helper loaded: security_helper
INFO - 2025-09-18 10:13:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:13:28 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:13:28 --> Form Validation Class Initialized
INFO - 2025-09-18 10:13:28 --> Model "User_model" initialized
INFO - 2025-09-18 15:13:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:13:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:13:28 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:13:28 --> Controller Class Initialized
INFO - 2025-09-18 15:13:28 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:13:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pusat/list.php
INFO - 2025-09-18 15:13:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:13:28 --> Model "Log_model" initialized
INFO - 2025-09-18 15:13:28 --> Final output sent to browser
DEBUG - 2025-09-18 15:13:28 --> Total execution time: 0.1515
INFO - 2025-09-18 10:13:33 --> Config Class Initialized
INFO - 2025-09-18 10:13:33 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:13:33 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:13:33 --> Utf8 Class Initialized
INFO - 2025-09-18 10:13:33 --> URI Class Initialized
INFO - 2025-09-18 10:13:33 --> Router Class Initialized
INFO - 2025-09-18 10:13:33 --> Output Class Initialized
INFO - 2025-09-18 10:13:33 --> Security Class Initialized
DEBUG - 2025-09-18 10:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:13:33 --> CSRF cookie sent
INFO - 2025-09-18 10:13:33 --> Input Class Initialized
INFO - 2025-09-18 10:13:33 --> Language Class Initialized
INFO - 2025-09-18 10:13:33 --> Loader Class Initialized
INFO - 2025-09-18 10:13:33 --> Helper loaded: url_helper
INFO - 2025-09-18 10:13:33 --> Helper loaded: text_helper
INFO - 2025-09-18 10:13:33 --> Helper loaded: string_helper
INFO - 2025-09-18 10:13:33 --> Helper loaded: form_helper
INFO - 2025-09-18 10:13:33 --> Helper loaded: download_helper
INFO - 2025-09-18 10:13:33 --> Helper loaded: security_helper
INFO - 2025-09-18 10:13:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:13:33 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:13:33 --> Form Validation Class Initialized
INFO - 2025-09-18 10:13:33 --> Model "User_model" initialized
INFO - 2025-09-18 15:13:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:13:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:13:33 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:13:33 --> Controller Class Initialized
INFO - 2025-09-18 15:13:33 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:13:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pusat/edit.php
INFO - 2025-09-18 15:13:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:13:33 --> Model "Log_model" initialized
INFO - 2025-09-18 15:13:33 --> Final output sent to browser
DEBUG - 2025-09-18 15:13:33 --> Total execution time: 0.0942
INFO - 2025-09-18 10:13:45 --> Config Class Initialized
INFO - 2025-09-18 10:13:45 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:13:45 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:13:45 --> Utf8 Class Initialized
INFO - 2025-09-18 10:13:45 --> URI Class Initialized
INFO - 2025-09-18 10:13:45 --> Router Class Initialized
INFO - 2025-09-18 10:13:45 --> Output Class Initialized
INFO - 2025-09-18 10:13:45 --> Security Class Initialized
DEBUG - 2025-09-18 10:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:13:45 --> CSRF cookie sent
INFO - 2025-09-18 10:14:03 --> Config Class Initialized
INFO - 2025-09-18 10:14:03 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:14:03 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:14:03 --> Utf8 Class Initialized
INFO - 2025-09-18 10:14:03 --> URI Class Initialized
INFO - 2025-09-18 10:14:03 --> Router Class Initialized
INFO - 2025-09-18 10:14:03 --> Output Class Initialized
INFO - 2025-09-18 10:14:03 --> Security Class Initialized
DEBUG - 2025-09-18 10:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:14:04 --> CSRF cookie sent
INFO - 2025-09-18 10:14:04 --> CSRF token verified
INFO - 2025-09-18 10:14:04 --> Input Class Initialized
INFO - 2025-09-18 10:14:04 --> Language Class Initialized
INFO - 2025-09-18 10:14:04 --> Loader Class Initialized
INFO - 2025-09-18 10:14:04 --> Helper loaded: url_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: text_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: string_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: form_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: download_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: security_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:14:04 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:14:04 --> Form Validation Class Initialized
INFO - 2025-09-18 10:14:04 --> Model "User_model" initialized
INFO - 2025-09-18 15:14:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:14:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:14:04 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:14:04 --> Controller Class Initialized
INFO - 2025-09-18 15:14:04 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:14:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 15:14:04 --> Upload Class Initialized
INFO - 2025-09-18 15:14:04 --> Language file loaded: language/english/upload_lang.php
INFO - 2025-09-18 15:14:04 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2025-09-18 10:14:04 --> Config Class Initialized
INFO - 2025-09-18 10:14:04 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:14:04 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:14:04 --> Utf8 Class Initialized
INFO - 2025-09-18 10:14:04 --> URI Class Initialized
INFO - 2025-09-18 10:14:04 --> Router Class Initialized
INFO - 2025-09-18 10:14:04 --> Output Class Initialized
INFO - 2025-09-18 10:14:04 --> Security Class Initialized
DEBUG - 2025-09-18 10:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:14:04 --> CSRF cookie sent
INFO - 2025-09-18 10:14:04 --> Input Class Initialized
INFO - 2025-09-18 10:14:04 --> Language Class Initialized
INFO - 2025-09-18 10:14:04 --> Loader Class Initialized
INFO - 2025-09-18 10:14:04 --> Helper loaded: url_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: text_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: string_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: form_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: download_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: security_helper
INFO - 2025-09-18 10:14:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:14:04 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:14:04 --> Form Validation Class Initialized
INFO - 2025-09-18 10:14:04 --> Model "User_model" initialized
INFO - 2025-09-18 15:14:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:14:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:14:04 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:14:04 --> Controller Class Initialized
INFO - 2025-09-18 15:14:04 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:14:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pusat/list.php
INFO - 2025-09-18 15:14:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:14:04 --> Model "Log_model" initialized
INFO - 2025-09-18 15:14:04 --> Final output sent to browser
DEBUG - 2025-09-18 15:14:04 --> Total execution time: 0.1284
INFO - 2025-09-18 10:16:03 --> Config Class Initialized
INFO - 2025-09-18 10:16:03 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:16:03 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:16:03 --> Utf8 Class Initialized
INFO - 2025-09-18 10:16:03 --> URI Class Initialized
INFO - 2025-09-18 10:16:03 --> Router Class Initialized
INFO - 2025-09-18 10:16:03 --> Output Class Initialized
INFO - 2025-09-18 10:16:03 --> Security Class Initialized
DEBUG - 2025-09-18 10:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:16:03 --> CSRF cookie sent
INFO - 2025-09-18 10:16:03 --> Input Class Initialized
INFO - 2025-09-18 10:16:03 --> Language Class Initialized
INFO - 2025-09-18 10:16:03 --> Loader Class Initialized
INFO - 2025-09-18 10:16:03 --> Helper loaded: url_helper
INFO - 2025-09-18 10:16:03 --> Helper loaded: text_helper
INFO - 2025-09-18 10:16:03 --> Helper loaded: string_helper
INFO - 2025-09-18 10:16:03 --> Helper loaded: form_helper
INFO - 2025-09-18 10:16:03 --> Helper loaded: download_helper
INFO - 2025-09-18 10:16:03 --> Helper loaded: security_helper
INFO - 2025-09-18 10:16:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:16:03 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:16:03 --> Form Validation Class Initialized
INFO - 2025-09-18 10:16:03 --> Model "User_model" initialized
INFO - 2025-09-18 15:16:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:16:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:16:03 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:16:03 --> Controller Class Initialized
INFO - 2025-09-18 15:16:03 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:16:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pusat/edit.php
INFO - 2025-09-18 15:16:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:16:03 --> Model "Log_model" initialized
INFO - 2025-09-18 15:16:03 --> Final output sent to browser
DEBUG - 2025-09-18 15:16:03 --> Total execution time: 0.0753
INFO - 2025-09-18 10:16:12 --> Config Class Initialized
INFO - 2025-09-18 10:16:12 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:16:12 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:16:12 --> Utf8 Class Initialized
INFO - 2025-09-18 10:16:12 --> URI Class Initialized
INFO - 2025-09-18 10:16:12 --> Router Class Initialized
INFO - 2025-09-18 10:16:12 --> Output Class Initialized
INFO - 2025-09-18 10:16:12 --> Security Class Initialized
DEBUG - 2025-09-18 10:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:16:12 --> CSRF cookie sent
INFO - 2025-09-18 10:16:12 --> CSRF token verified
INFO - 2025-09-18 10:16:12 --> Input Class Initialized
INFO - 2025-09-18 10:16:12 --> Language Class Initialized
INFO - 2025-09-18 10:16:12 --> Loader Class Initialized
INFO - 2025-09-18 10:16:12 --> Helper loaded: url_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: text_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: string_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: form_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: download_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: security_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:16:12 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:16:12 --> Form Validation Class Initialized
INFO - 2025-09-18 10:16:12 --> Model "User_model" initialized
INFO - 2025-09-18 15:16:12 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:16:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:16:12 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:16:12 --> Controller Class Initialized
INFO - 2025-09-18 15:16:12 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:16:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 15:16:12 --> Upload Class Initialized
INFO - 2025-09-18 10:16:12 --> Config Class Initialized
INFO - 2025-09-18 10:16:12 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:16:12 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:16:12 --> Utf8 Class Initialized
INFO - 2025-09-18 10:16:12 --> URI Class Initialized
INFO - 2025-09-18 10:16:12 --> Router Class Initialized
INFO - 2025-09-18 10:16:12 --> Output Class Initialized
INFO - 2025-09-18 10:16:12 --> Security Class Initialized
DEBUG - 2025-09-18 10:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:16:12 --> CSRF cookie sent
INFO - 2025-09-18 10:16:12 --> Input Class Initialized
INFO - 2025-09-18 10:16:12 --> Language Class Initialized
INFO - 2025-09-18 10:16:12 --> Loader Class Initialized
INFO - 2025-09-18 10:16:12 --> Helper loaded: url_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: text_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: string_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: form_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: download_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: security_helper
INFO - 2025-09-18 10:16:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:16:12 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:16:12 --> Form Validation Class Initialized
INFO - 2025-09-18 10:16:12 --> Model "User_model" initialized
INFO - 2025-09-18 15:16:12 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:16:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:16:12 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:16:12 --> Controller Class Initialized
INFO - 2025-09-18 15:16:12 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:16:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pusat/list.php
INFO - 2025-09-18 15:16:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:16:12 --> Model "Log_model" initialized
INFO - 2025-09-18 15:16:12 --> Final output sent to browser
DEBUG - 2025-09-18 15:16:12 --> Total execution time: 0.0591
INFO - 2025-09-18 10:16:17 --> Config Class Initialized
INFO - 2025-09-18 10:16:17 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:16:17 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:16:17 --> Utf8 Class Initialized
INFO - 2025-09-18 10:16:17 --> URI Class Initialized
INFO - 2025-09-18 10:16:17 --> Router Class Initialized
INFO - 2025-09-18 10:16:17 --> Output Class Initialized
INFO - 2025-09-18 10:16:17 --> Security Class Initialized
DEBUG - 2025-09-18 10:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:16:17 --> CSRF cookie sent
INFO - 2025-09-18 10:16:17 --> Input Class Initialized
INFO - 2025-09-18 10:16:17 --> Language Class Initialized
INFO - 2025-09-18 10:16:17 --> Loader Class Initialized
INFO - 2025-09-18 10:16:17 --> Helper loaded: url_helper
INFO - 2025-09-18 10:16:17 --> Helper loaded: text_helper
INFO - 2025-09-18 10:16:17 --> Helper loaded: string_helper
INFO - 2025-09-18 10:16:17 --> Helper loaded: form_helper
INFO - 2025-09-18 10:16:17 --> Helper loaded: download_helper
INFO - 2025-09-18 10:16:17 --> Helper loaded: security_helper
INFO - 2025-09-18 10:16:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:16:17 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:16:17 --> Form Validation Class Initialized
INFO - 2025-09-18 10:16:17 --> Model "User_model" initialized
INFO - 2025-09-18 15:16:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:16:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:16:17 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:16:17 --> Controller Class Initialized
INFO - 2025-09-18 15:16:17 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:16:17 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:16:17 --> Model "Sdm_model" initialized
INFO - 2025-09-18 15:16:17 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-18 15:16:17 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-09-18 15:16:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-18 15:16:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:16:17 --> Model "Log_model" initialized
INFO - 2025-09-18 15:16:17 --> Final output sent to browser
DEBUG - 2025-09-18 15:16:17 --> Total execution time: 0.0990
INFO - 2025-09-18 10:17:10 --> Config Class Initialized
INFO - 2025-09-18 10:17:10 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:17:10 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:17:10 --> Utf8 Class Initialized
INFO - 2025-09-18 10:17:10 --> URI Class Initialized
DEBUG - 2025-09-18 10:17:10 --> No URI present. Default controller set.
INFO - 2025-09-18 10:17:10 --> Router Class Initialized
INFO - 2025-09-18 10:17:10 --> Output Class Initialized
INFO - 2025-09-18 10:17:10 --> Security Class Initialized
DEBUG - 2025-09-18 10:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:17:10 --> CSRF cookie sent
INFO - 2025-09-18 10:17:10 --> Input Class Initialized
INFO - 2025-09-18 10:17:10 --> Language Class Initialized
INFO - 2025-09-18 10:17:10 --> Loader Class Initialized
INFO - 2025-09-18 10:17:10 --> Helper loaded: url_helper
INFO - 2025-09-18 10:17:10 --> Helper loaded: text_helper
INFO - 2025-09-18 10:17:10 --> Helper loaded: string_helper
INFO - 2025-09-18 10:17:10 --> Helper loaded: form_helper
INFO - 2025-09-18 10:17:10 --> Helper loaded: download_helper
INFO - 2025-09-18 10:17:10 --> Helper loaded: security_helper
INFO - 2025-09-18 10:17:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:17:10 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:17:10 --> Form Validation Class Initialized
INFO - 2025-09-18 10:17:10 --> Model "User_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:17:10 --> Controller Class Initialized
INFO - 2025-09-18 15:17:10 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Video_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:17:10 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:17:10 --> Pagination Class Initialized
INFO - 2025-09-18 15:17:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:17:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:17:10 --> Model "Log_model" initialized
INFO - 2025-09-18 15:17:10 --> Final output sent to browser
DEBUG - 2025-09-18 15:17:10 --> Total execution time: 0.1321
INFO - 2025-09-18 10:18:45 --> Config Class Initialized
INFO - 2025-09-18 10:18:45 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:18:45 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:18:45 --> Utf8 Class Initialized
INFO - 2025-09-18 10:18:45 --> URI Class Initialized
INFO - 2025-09-18 10:18:45 --> Router Class Initialized
INFO - 2025-09-18 10:18:45 --> Output Class Initialized
INFO - 2025-09-18 10:18:45 --> Security Class Initialized
DEBUG - 2025-09-18 10:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:18:45 --> CSRF cookie sent
INFO - 2025-09-18 10:18:45 --> Input Class Initialized
INFO - 2025-09-18 10:18:45 --> Language Class Initialized
INFO - 2025-09-18 10:18:45 --> Loader Class Initialized
INFO - 2025-09-18 10:18:45 --> Helper loaded: url_helper
INFO - 2025-09-18 10:18:45 --> Helper loaded: text_helper
INFO - 2025-09-18 10:18:45 --> Helper loaded: string_helper
INFO - 2025-09-18 10:18:45 --> Helper loaded: form_helper
INFO - 2025-09-18 10:18:45 --> Helper loaded: download_helper
INFO - 2025-09-18 10:18:45 --> Helper loaded: security_helper
INFO - 2025-09-18 10:18:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:18:45 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:18:45 --> Form Validation Class Initialized
INFO - 2025-09-18 10:18:45 --> Model "User_model" initialized
INFO - 2025-09-18 15:18:45 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:18:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:18:45 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:18:45 --> Controller Class Initialized
INFO - 2025-09-18 15:18:45 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:18:45 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:18:45 --> Model "Sdm_model" initialized
INFO - 2025-09-18 15:18:45 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-18 15:18:45 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-09-18 15:18:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-18 15:18:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:18:45 --> Model "Log_model" initialized
INFO - 2025-09-18 15:18:45 --> Final output sent to browser
DEBUG - 2025-09-18 15:18:45 --> Total execution time: 0.0906
INFO - 2025-09-18 10:19:54 --> Config Class Initialized
INFO - 2025-09-18 10:19:54 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:19:54 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:19:54 --> Utf8 Class Initialized
INFO - 2025-09-18 10:19:54 --> URI Class Initialized
INFO - 2025-09-18 10:19:54 --> Router Class Initialized
INFO - 2025-09-18 10:19:54 --> Output Class Initialized
INFO - 2025-09-18 10:19:54 --> Security Class Initialized
DEBUG - 2025-09-18 10:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:19:54 --> CSRF cookie sent
INFO - 2025-09-18 10:19:54 --> Input Class Initialized
INFO - 2025-09-18 10:19:54 --> Language Class Initialized
INFO - 2025-09-18 10:19:54 --> Loader Class Initialized
INFO - 2025-09-18 10:19:54 --> Helper loaded: url_helper
INFO - 2025-09-18 10:19:54 --> Helper loaded: text_helper
INFO - 2025-09-18 10:19:54 --> Helper loaded: string_helper
INFO - 2025-09-18 10:19:54 --> Helper loaded: form_helper
INFO - 2025-09-18 10:19:54 --> Helper loaded: download_helper
INFO - 2025-09-18 10:19:54 --> Helper loaded: security_helper
INFO - 2025-09-18 10:19:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:19:54 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:19:54 --> Form Validation Class Initialized
INFO - 2025-09-18 10:19:54 --> Model "User_model" initialized
INFO - 2025-09-18 15:19:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:19:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:19:54 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:19:54 --> Controller Class Initialized
INFO - 2025-09-18 15:19:54 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:19:54 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:19:54 --> Model "Sdm_model" initialized
INFO - 2025-09-18 15:19:54 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-18 15:19:54 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-09-18 15:19:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-18 15:19:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:19:54 --> Model "Log_model" initialized
INFO - 2025-09-18 15:19:54 --> Final output sent to browser
DEBUG - 2025-09-18 15:19:54 --> Total execution time: 0.0708
INFO - 2025-09-18 10:20:42 --> Config Class Initialized
INFO - 2025-09-18 10:20:42 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:20:42 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:20:42 --> Utf8 Class Initialized
INFO - 2025-09-18 10:20:42 --> URI Class Initialized
INFO - 2025-09-18 10:20:42 --> Router Class Initialized
INFO - 2025-09-18 10:20:42 --> Output Class Initialized
INFO - 2025-09-18 10:20:42 --> Security Class Initialized
DEBUG - 2025-09-18 10:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:20:42 --> CSRF cookie sent
INFO - 2025-09-18 10:20:42 --> Input Class Initialized
INFO - 2025-09-18 10:20:42 --> Language Class Initialized
INFO - 2025-09-18 10:20:42 --> Loader Class Initialized
INFO - 2025-09-18 10:20:42 --> Helper loaded: url_helper
INFO - 2025-09-18 10:20:42 --> Helper loaded: text_helper
INFO - 2025-09-18 10:20:42 --> Helper loaded: string_helper
INFO - 2025-09-18 10:20:42 --> Helper loaded: form_helper
INFO - 2025-09-18 10:20:42 --> Helper loaded: download_helper
INFO - 2025-09-18 10:20:42 --> Helper loaded: security_helper
INFO - 2025-09-18 10:20:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:20:42 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:20:42 --> Form Validation Class Initialized
INFO - 2025-09-18 10:20:42 --> Model "User_model" initialized
INFO - 2025-09-18 15:20:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:20:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:20:42 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:20:42 --> Controller Class Initialized
INFO - 2025-09-18 15:20:42 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:20:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pusat/edit.php
INFO - 2025-09-18 15:20:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:20:42 --> Model "Log_model" initialized
INFO - 2025-09-18 15:20:42 --> Final output sent to browser
DEBUG - 2025-09-18 15:20:42 --> Total execution time: 0.0789
INFO - 2025-09-18 10:20:55 --> Config Class Initialized
INFO - 2025-09-18 10:20:55 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:20:55 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:20:55 --> Utf8 Class Initialized
INFO - 2025-09-18 10:20:55 --> URI Class Initialized
INFO - 2025-09-18 10:20:55 --> Router Class Initialized
INFO - 2025-09-18 10:20:55 --> Output Class Initialized
INFO - 2025-09-18 10:20:55 --> Security Class Initialized
DEBUG - 2025-09-18 10:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:20:55 --> CSRF cookie sent
INFO - 2025-09-18 10:20:55 --> CSRF token verified
INFO - 2025-09-18 10:20:55 --> Input Class Initialized
INFO - 2025-09-18 10:20:55 --> Language Class Initialized
INFO - 2025-09-18 10:20:55 --> Loader Class Initialized
INFO - 2025-09-18 10:20:55 --> Helper loaded: url_helper
INFO - 2025-09-18 10:20:55 --> Helper loaded: text_helper
INFO - 2025-09-18 10:20:55 --> Helper loaded: string_helper
INFO - 2025-09-18 10:20:55 --> Helper loaded: form_helper
INFO - 2025-09-18 10:20:55 --> Helper loaded: download_helper
INFO - 2025-09-18 10:20:55 --> Helper loaded: security_helper
INFO - 2025-09-18 10:20:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:20:55 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:20:55 --> Form Validation Class Initialized
INFO - 2025-09-18 10:20:55 --> Model "User_model" initialized
INFO - 2025-09-18 15:20:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:20:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:20:55 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:20:55 --> Controller Class Initialized
INFO - 2025-09-18 15:20:55 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:20:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 15:20:55 --> Upload Class Initialized
INFO - 2025-09-18 10:20:55 --> Config Class Initialized
INFO - 2025-09-18 10:20:55 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:20:55 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:20:55 --> Utf8 Class Initialized
INFO - 2025-09-18 10:20:55 --> URI Class Initialized
INFO - 2025-09-18 10:20:56 --> Router Class Initialized
INFO - 2025-09-18 10:20:56 --> Output Class Initialized
INFO - 2025-09-18 10:20:56 --> Security Class Initialized
DEBUG - 2025-09-18 10:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:20:56 --> CSRF cookie sent
INFO - 2025-09-18 10:20:56 --> Input Class Initialized
INFO - 2025-09-18 10:20:56 --> Language Class Initialized
INFO - 2025-09-18 10:20:56 --> Loader Class Initialized
INFO - 2025-09-18 10:20:56 --> Helper loaded: url_helper
INFO - 2025-09-18 10:20:56 --> Helper loaded: text_helper
INFO - 2025-09-18 10:20:56 --> Helper loaded: string_helper
INFO - 2025-09-18 10:20:56 --> Helper loaded: form_helper
INFO - 2025-09-18 10:20:56 --> Helper loaded: download_helper
INFO - 2025-09-18 10:20:56 --> Helper loaded: security_helper
INFO - 2025-09-18 10:20:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:20:56 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:20:56 --> Form Validation Class Initialized
INFO - 2025-09-18 10:20:56 --> Model "User_model" initialized
INFO - 2025-09-18 15:20:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:20:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:20:56 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:20:56 --> Controller Class Initialized
INFO - 2025-09-18 15:20:56 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:20:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pusat/list.php
INFO - 2025-09-18 15:20:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:20:56 --> Model "Log_model" initialized
INFO - 2025-09-18 15:20:56 --> Final output sent to browser
DEBUG - 2025-09-18 15:20:56 --> Total execution time: 0.0564
INFO - 2025-09-18 10:21:13 --> Config Class Initialized
INFO - 2025-09-18 10:21:13 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:21:13 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:21:13 --> Utf8 Class Initialized
INFO - 2025-09-18 10:21:13 --> URI Class Initialized
INFO - 2025-09-18 10:21:13 --> Router Class Initialized
INFO - 2025-09-18 10:21:13 --> Output Class Initialized
INFO - 2025-09-18 10:21:13 --> Security Class Initialized
DEBUG - 2025-09-18 10:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:21:13 --> CSRF cookie sent
INFO - 2025-09-18 10:21:13 --> Input Class Initialized
INFO - 2025-09-18 10:21:13 --> Language Class Initialized
INFO - 2025-09-18 10:21:13 --> Loader Class Initialized
INFO - 2025-09-18 10:21:13 --> Helper loaded: url_helper
INFO - 2025-09-18 10:21:13 --> Helper loaded: text_helper
INFO - 2025-09-18 10:21:13 --> Helper loaded: string_helper
INFO - 2025-09-18 10:21:13 --> Helper loaded: form_helper
INFO - 2025-09-18 10:21:13 --> Helper loaded: download_helper
INFO - 2025-09-18 10:21:13 --> Helper loaded: security_helper
INFO - 2025-09-18 10:21:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:21:13 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:21:13 --> Form Validation Class Initialized
INFO - 2025-09-18 10:21:13 --> Model "User_model" initialized
INFO - 2025-09-18 15:21:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:21:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:21:13 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:21:13 --> Controller Class Initialized
INFO - 2025-09-18 15:21:13 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:21:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pusat/edit.php
INFO - 2025-09-18 15:21:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:21:13 --> Model "Log_model" initialized
INFO - 2025-09-18 15:21:13 --> Final output sent to browser
DEBUG - 2025-09-18 15:21:13 --> Total execution time: 0.0650
INFO - 2025-09-18 10:21:23 --> Config Class Initialized
INFO - 2025-09-18 10:21:23 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:21:23 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:21:23 --> Utf8 Class Initialized
INFO - 2025-09-18 10:21:23 --> URI Class Initialized
INFO - 2025-09-18 10:21:23 --> Router Class Initialized
INFO - 2025-09-18 10:21:23 --> Output Class Initialized
INFO - 2025-09-18 10:21:23 --> Security Class Initialized
DEBUG - 2025-09-18 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:21:23 --> CSRF cookie sent
INFO - 2025-09-18 10:21:23 --> CSRF token verified
INFO - 2025-09-18 10:21:23 --> Input Class Initialized
INFO - 2025-09-18 10:21:23 --> Language Class Initialized
INFO - 2025-09-18 10:21:23 --> Loader Class Initialized
INFO - 2025-09-18 10:21:23 --> Helper loaded: url_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: text_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: string_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: form_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: download_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: security_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:21:23 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:21:23 --> Form Validation Class Initialized
INFO - 2025-09-18 10:21:23 --> Model "User_model" initialized
INFO - 2025-09-18 15:21:23 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:21:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:21:23 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:21:23 --> Controller Class Initialized
INFO - 2025-09-18 15:21:23 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:21:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-18 15:21:23 --> Upload Class Initialized
INFO - 2025-09-18 10:21:23 --> Config Class Initialized
INFO - 2025-09-18 10:21:23 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:21:23 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:21:23 --> Utf8 Class Initialized
INFO - 2025-09-18 10:21:23 --> URI Class Initialized
INFO - 2025-09-18 10:21:23 --> Router Class Initialized
INFO - 2025-09-18 10:21:23 --> Output Class Initialized
INFO - 2025-09-18 10:21:23 --> Security Class Initialized
DEBUG - 2025-09-18 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:21:23 --> CSRF cookie sent
INFO - 2025-09-18 10:21:23 --> Input Class Initialized
INFO - 2025-09-18 10:21:23 --> Language Class Initialized
INFO - 2025-09-18 10:21:23 --> Loader Class Initialized
INFO - 2025-09-18 10:21:23 --> Helper loaded: url_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: text_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: string_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: form_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: download_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: security_helper
INFO - 2025-09-18 10:21:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:21:23 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:21:23 --> Form Validation Class Initialized
INFO - 2025-09-18 10:21:23 --> Model "User_model" initialized
INFO - 2025-09-18 15:21:23 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:21:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:21:23 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:21:23 --> Controller Class Initialized
INFO - 2025-09-18 15:21:23 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:21:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pusat/list.php
INFO - 2025-09-18 15:21:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-18 15:21:23 --> Model "Log_model" initialized
INFO - 2025-09-18 15:21:23 --> Final output sent to browser
DEBUG - 2025-09-18 15:21:23 --> Total execution time: 0.0711
INFO - 2025-09-18 10:21:27 --> Config Class Initialized
INFO - 2025-09-18 10:21:27 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:21:27 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:21:27 --> Utf8 Class Initialized
INFO - 2025-09-18 10:21:27 --> URI Class Initialized
INFO - 2025-09-18 10:21:27 --> Router Class Initialized
INFO - 2025-09-18 10:21:27 --> Output Class Initialized
INFO - 2025-09-18 10:21:27 --> Security Class Initialized
DEBUG - 2025-09-18 10:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:21:27 --> CSRF cookie sent
INFO - 2025-09-18 10:21:27 --> Input Class Initialized
INFO - 2025-09-18 10:21:27 --> Language Class Initialized
INFO - 2025-09-18 10:21:27 --> Loader Class Initialized
INFO - 2025-09-18 10:21:27 --> Helper loaded: url_helper
INFO - 2025-09-18 10:21:27 --> Helper loaded: text_helper
INFO - 2025-09-18 10:21:27 --> Helper loaded: string_helper
INFO - 2025-09-18 10:21:27 --> Helper loaded: form_helper
INFO - 2025-09-18 10:21:27 --> Helper loaded: download_helper
INFO - 2025-09-18 10:21:27 --> Helper loaded: security_helper
INFO - 2025-09-18 10:21:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:21:27 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:21:27 --> Form Validation Class Initialized
INFO - 2025-09-18 10:21:27 --> Model "User_model" initialized
INFO - 2025-09-18 15:21:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:21:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:21:27 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:21:27 --> Controller Class Initialized
INFO - 2025-09-18 15:21:27 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:21:27 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:21:27 --> Model "Sdm_model" initialized
INFO - 2025-09-18 15:21:27 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-18 15:21:27 --> Query SDM berhasil untuk pusat: Pusat Penelitian dan Pengabdian Masyarakat, Total: 1
INFO - 2025-09-18 15:21:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-18 15:21:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:21:27 --> Model "Log_model" initialized
INFO - 2025-09-18 15:21:27 --> Final output sent to browser
DEBUG - 2025-09-18 15:21:27 --> Total execution time: 0.1058
INFO - 2025-09-18 10:22:24 --> Config Class Initialized
INFO - 2025-09-18 10:22:24 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:22:24 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:22:24 --> Utf8 Class Initialized
INFO - 2025-09-18 10:22:24 --> URI Class Initialized
INFO - 2025-09-18 10:22:24 --> Router Class Initialized
INFO - 2025-09-18 10:22:24 --> Output Class Initialized
INFO - 2025-09-18 10:22:24 --> Security Class Initialized
DEBUG - 2025-09-18 10:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:22:24 --> CSRF cookie sent
INFO - 2025-09-18 10:22:24 --> Input Class Initialized
INFO - 2025-09-18 10:22:24 --> Language Class Initialized
INFO - 2025-09-18 10:22:24 --> Loader Class Initialized
INFO - 2025-09-18 10:22:24 --> Helper loaded: url_helper
INFO - 2025-09-18 10:22:24 --> Helper loaded: text_helper
INFO - 2025-09-18 10:22:24 --> Helper loaded: string_helper
INFO - 2025-09-18 10:22:24 --> Helper loaded: form_helper
INFO - 2025-09-18 10:22:24 --> Helper loaded: download_helper
INFO - 2025-09-18 10:22:24 --> Helper loaded: security_helper
INFO - 2025-09-18 10:22:24 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:22:24 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:22:24 --> Form Validation Class Initialized
INFO - 2025-09-18 10:22:24 --> Model "User_model" initialized
INFO - 2025-09-18 15:22:24 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:22:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:22:24 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:22:24 --> Controller Class Initialized
INFO - 2025-09-18 15:22:24 --> Model "Pusat_model" initialized
INFO - 2025-09-18 15:22:24 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:22:24 --> Model "Sdm_model" initialized
INFO - 2025-09-18 15:22:24 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-18 15:22:24 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-09-18 15:22:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-18 15:22:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:22:24 --> Model "Log_model" initialized
INFO - 2025-09-18 15:22:24 --> Final output sent to browser
DEBUG - 2025-09-18 15:22:24 --> Total execution time: 0.1033
INFO - 2025-09-18 10:22:40 --> Config Class Initialized
INFO - 2025-09-18 10:22:40 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:22:40 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:22:40 --> Utf8 Class Initialized
INFO - 2025-09-18 10:22:40 --> URI Class Initialized
INFO - 2025-09-18 10:22:40 --> Router Class Initialized
INFO - 2025-09-18 10:22:40 --> Output Class Initialized
INFO - 2025-09-18 10:22:40 --> Security Class Initialized
DEBUG - 2025-09-18 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:22:40 --> CSRF cookie sent
INFO - 2025-09-18 10:22:40 --> Input Class Initialized
INFO - 2025-09-18 10:22:40 --> Language Class Initialized
INFO - 2025-09-18 10:22:40 --> Loader Class Initialized
INFO - 2025-09-18 10:22:40 --> Helper loaded: url_helper
INFO - 2025-09-18 10:22:40 --> Helper loaded: text_helper
INFO - 2025-09-18 10:22:40 --> Helper loaded: string_helper
INFO - 2025-09-18 10:22:40 --> Helper loaded: form_helper
INFO - 2025-09-18 10:22:40 --> Helper loaded: download_helper
INFO - 2025-09-18 10:22:40 --> Helper loaded: security_helper
INFO - 2025-09-18 10:22:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:22:40 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:22:40 --> Form Validation Class Initialized
INFO - 2025-09-18 10:22:40 --> Model "User_model" initialized
INFO - 2025-09-18 15:22:40 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:22:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:22:40 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:22:40 --> Controller Class Initialized
INFO - 2025-09-18 15:22:40 --> Model "Sdm_model" initialized
INFO - 2025-09-18 15:22:40 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-18 15:22:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-09-18 15:22:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:22:40 --> Model "Log_model" initialized
INFO - 2025-09-18 15:22:40 --> Final output sent to browser
DEBUG - 2025-09-18 15:22:40 --> Total execution time: 0.0872
INFO - 2025-09-18 10:31:41 --> Config Class Initialized
INFO - 2025-09-18 10:31:41 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:31:41 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:31:41 --> Utf8 Class Initialized
INFO - 2025-09-18 10:31:41 --> URI Class Initialized
DEBUG - 2025-09-18 10:31:41 --> No URI present. Default controller set.
INFO - 2025-09-18 10:31:41 --> Router Class Initialized
INFO - 2025-09-18 10:31:41 --> Output Class Initialized
INFO - 2025-09-18 10:31:41 --> Security Class Initialized
DEBUG - 2025-09-18 10:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:31:41 --> CSRF cookie sent
INFO - 2025-09-18 10:31:41 --> Input Class Initialized
INFO - 2025-09-18 10:31:41 --> Language Class Initialized
INFO - 2025-09-18 10:31:41 --> Loader Class Initialized
INFO - 2025-09-18 10:31:41 --> Helper loaded: url_helper
INFO - 2025-09-18 10:31:41 --> Helper loaded: text_helper
INFO - 2025-09-18 10:31:41 --> Helper loaded: string_helper
INFO - 2025-09-18 10:31:41 --> Helper loaded: form_helper
INFO - 2025-09-18 10:31:41 --> Helper loaded: download_helper
INFO - 2025-09-18 10:31:41 --> Helper loaded: security_helper
INFO - 2025-09-18 10:31:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:31:41 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:31:41 --> Form Validation Class Initialized
INFO - 2025-09-18 10:31:41 --> Model "User_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:31:41 --> Controller Class Initialized
INFO - 2025-09-18 15:31:41 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Video_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:31:41 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:31:41 --> Pagination Class Initialized
INFO - 2025-09-18 15:31:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:31:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:31:41 --> Model "Log_model" initialized
INFO - 2025-09-18 15:31:41 --> Final output sent to browser
DEBUG - 2025-09-18 15:31:41 --> Total execution time: 0.1222
INFO - 2025-09-18 10:31:55 --> Config Class Initialized
INFO - 2025-09-18 10:31:55 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:31:55 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:31:55 --> Utf8 Class Initialized
INFO - 2025-09-18 10:31:55 --> URI Class Initialized
DEBUG - 2025-09-18 10:31:55 --> No URI present. Default controller set.
INFO - 2025-09-18 10:31:55 --> Router Class Initialized
INFO - 2025-09-18 10:31:55 --> Output Class Initialized
INFO - 2025-09-18 10:31:55 --> Security Class Initialized
DEBUG - 2025-09-18 10:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:31:55 --> CSRF cookie sent
INFO - 2025-09-18 10:31:55 --> Input Class Initialized
INFO - 2025-09-18 10:31:55 --> Language Class Initialized
INFO - 2025-09-18 10:31:55 --> Loader Class Initialized
INFO - 2025-09-18 10:31:55 --> Helper loaded: url_helper
INFO - 2025-09-18 10:31:55 --> Helper loaded: text_helper
INFO - 2025-09-18 10:31:55 --> Helper loaded: string_helper
INFO - 2025-09-18 10:31:55 --> Helper loaded: form_helper
INFO - 2025-09-18 10:31:55 --> Helper loaded: download_helper
INFO - 2025-09-18 10:31:55 --> Helper loaded: security_helper
INFO - 2025-09-18 10:31:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:31:55 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:31:55 --> Form Validation Class Initialized
INFO - 2025-09-18 10:31:55 --> Model "User_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:31:55 --> Controller Class Initialized
INFO - 2025-09-18 15:31:55 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Video_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:31:55 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:31:55 --> Pagination Class Initialized
INFO - 2025-09-18 15:31:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:31:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:31:55 --> Model "Log_model" initialized
INFO - 2025-09-18 15:31:55 --> Final output sent to browser
DEBUG - 2025-09-18 15:31:55 --> Total execution time: 0.1173
INFO - 2025-09-18 10:32:08 --> Config Class Initialized
INFO - 2025-09-18 10:32:08 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:32:08 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:32:08 --> Utf8 Class Initialized
INFO - 2025-09-18 10:32:08 --> URI Class Initialized
DEBUG - 2025-09-18 10:32:08 --> No URI present. Default controller set.
INFO - 2025-09-18 10:32:08 --> Router Class Initialized
INFO - 2025-09-18 10:32:08 --> Output Class Initialized
INFO - 2025-09-18 10:32:08 --> Security Class Initialized
DEBUG - 2025-09-18 10:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:32:08 --> CSRF cookie sent
INFO - 2025-09-18 10:32:08 --> Input Class Initialized
INFO - 2025-09-18 10:32:08 --> Language Class Initialized
INFO - 2025-09-18 10:32:08 --> Loader Class Initialized
INFO - 2025-09-18 10:32:08 --> Helper loaded: url_helper
INFO - 2025-09-18 10:32:08 --> Helper loaded: text_helper
INFO - 2025-09-18 10:32:08 --> Helper loaded: string_helper
INFO - 2025-09-18 10:32:08 --> Helper loaded: form_helper
INFO - 2025-09-18 10:32:08 --> Helper loaded: download_helper
INFO - 2025-09-18 10:32:08 --> Helper loaded: security_helper
INFO - 2025-09-18 10:32:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:32:08 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:32:08 --> Form Validation Class Initialized
INFO - 2025-09-18 10:32:08 --> Model "User_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:32:08 --> Controller Class Initialized
INFO - 2025-09-18 15:32:08 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Video_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:32:08 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:32:08 --> Pagination Class Initialized
INFO - 2025-09-18 15:32:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:32:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:32:08 --> Model "Log_model" initialized
INFO - 2025-09-18 15:32:08 --> Final output sent to browser
DEBUG - 2025-09-18 15:32:08 --> Total execution time: 0.1370
INFO - 2025-09-18 10:32:10 --> Config Class Initialized
INFO - 2025-09-18 10:32:10 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:32:10 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:32:10 --> Utf8 Class Initialized
INFO - 2025-09-18 10:32:10 --> URI Class Initialized
DEBUG - 2025-09-18 10:32:10 --> No URI present. Default controller set.
INFO - 2025-09-18 10:32:10 --> Router Class Initialized
INFO - 2025-09-18 10:32:10 --> Output Class Initialized
INFO - 2025-09-18 10:32:10 --> Security Class Initialized
DEBUG - 2025-09-18 10:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:32:10 --> CSRF cookie sent
INFO - 2025-09-18 10:32:10 --> Input Class Initialized
INFO - 2025-09-18 10:32:10 --> Language Class Initialized
INFO - 2025-09-18 10:32:10 --> Loader Class Initialized
INFO - 2025-09-18 10:32:10 --> Helper loaded: url_helper
INFO - 2025-09-18 10:32:10 --> Helper loaded: text_helper
INFO - 2025-09-18 10:32:10 --> Helper loaded: string_helper
INFO - 2025-09-18 10:32:10 --> Helper loaded: form_helper
INFO - 2025-09-18 10:32:10 --> Helper loaded: download_helper
INFO - 2025-09-18 10:32:10 --> Helper loaded: security_helper
INFO - 2025-09-18 10:32:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:32:10 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:32:10 --> Form Validation Class Initialized
INFO - 2025-09-18 10:32:10 --> Model "User_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:32:10 --> Controller Class Initialized
INFO - 2025-09-18 15:32:10 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Video_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:32:10 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:32:10 --> Pagination Class Initialized
INFO - 2025-09-18 15:32:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:32:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:32:10 --> Model "Log_model" initialized
INFO - 2025-09-18 15:32:10 --> Final output sent to browser
DEBUG - 2025-09-18 15:32:10 --> Total execution time: 0.1418
INFO - 2025-09-18 10:32:18 --> Config Class Initialized
INFO - 2025-09-18 10:32:18 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:32:18 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:32:18 --> Utf8 Class Initialized
INFO - 2025-09-18 10:32:18 --> URI Class Initialized
DEBUG - 2025-09-18 10:32:18 --> No URI present. Default controller set.
INFO - 2025-09-18 10:32:18 --> Router Class Initialized
INFO - 2025-09-18 10:32:18 --> Output Class Initialized
INFO - 2025-09-18 10:32:18 --> Security Class Initialized
DEBUG - 2025-09-18 10:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:32:18 --> CSRF cookie sent
INFO - 2025-09-18 10:32:18 --> Input Class Initialized
INFO - 2025-09-18 10:32:18 --> Language Class Initialized
INFO - 2025-09-18 10:32:18 --> Loader Class Initialized
INFO - 2025-09-18 10:32:18 --> Helper loaded: url_helper
INFO - 2025-09-18 10:32:18 --> Helper loaded: text_helper
INFO - 2025-09-18 10:32:18 --> Helper loaded: string_helper
INFO - 2025-09-18 10:32:18 --> Helper loaded: form_helper
INFO - 2025-09-18 10:32:18 --> Helper loaded: download_helper
INFO - 2025-09-18 10:32:18 --> Helper loaded: security_helper
INFO - 2025-09-18 10:32:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:32:18 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:32:18 --> Form Validation Class Initialized
INFO - 2025-09-18 10:32:18 --> Model "User_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:32:18 --> Controller Class Initialized
INFO - 2025-09-18 15:32:18 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Video_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:32:18 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:32:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:32:18 --> Pagination Class Initialized
INFO - 2025-09-18 15:32:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:32:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:32:18 --> Model "Log_model" initialized
INFO - 2025-09-18 15:32:18 --> Final output sent to browser
DEBUG - 2025-09-18 15:32:18 --> Total execution time: 0.1115
INFO - 2025-09-18 10:32:31 --> Config Class Initialized
INFO - 2025-09-18 10:32:31 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:32:31 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:32:31 --> Utf8 Class Initialized
INFO - 2025-09-18 10:32:31 --> URI Class Initialized
DEBUG - 2025-09-18 10:32:31 --> No URI present. Default controller set.
INFO - 2025-09-18 10:32:31 --> Router Class Initialized
INFO - 2025-09-18 10:32:31 --> Output Class Initialized
INFO - 2025-09-18 10:32:31 --> Security Class Initialized
DEBUG - 2025-09-18 10:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:32:31 --> CSRF cookie sent
INFO - 2025-09-18 10:32:31 --> Input Class Initialized
INFO - 2025-09-18 10:32:31 --> Language Class Initialized
INFO - 2025-09-18 10:32:31 --> Loader Class Initialized
INFO - 2025-09-18 10:32:31 --> Helper loaded: url_helper
INFO - 2025-09-18 10:32:31 --> Helper loaded: text_helper
INFO - 2025-09-18 10:32:31 --> Helper loaded: string_helper
INFO - 2025-09-18 10:32:31 --> Helper loaded: form_helper
INFO - 2025-09-18 10:32:31 --> Helper loaded: download_helper
INFO - 2025-09-18 10:32:31 --> Helper loaded: security_helper
INFO - 2025-09-18 10:32:31 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:32:31 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:32:31 --> Form Validation Class Initialized
INFO - 2025-09-18 10:32:31 --> Model "User_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:32:31 --> Controller Class Initialized
INFO - 2025-09-18 15:32:31 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Video_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:32:31 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:32:31 --> Pagination Class Initialized
INFO - 2025-09-18 15:32:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:32:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:32:31 --> Model "Log_model" initialized
INFO - 2025-09-18 15:32:31 --> Final output sent to browser
DEBUG - 2025-09-18 15:32:31 --> Total execution time: 0.1526
INFO - 2025-09-18 10:32:32 --> Config Class Initialized
INFO - 2025-09-18 10:32:32 --> Hooks Class Initialized
DEBUG - 2025-09-18 10:32:32 --> UTF-8 Support Enabled
INFO - 2025-09-18 10:32:32 --> Utf8 Class Initialized
INFO - 2025-09-18 10:32:32 --> URI Class Initialized
DEBUG - 2025-09-18 10:32:32 --> No URI present. Default controller set.
INFO - 2025-09-18 10:32:32 --> Router Class Initialized
INFO - 2025-09-18 10:32:32 --> Output Class Initialized
INFO - 2025-09-18 10:32:32 --> Security Class Initialized
DEBUG - 2025-09-18 10:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-18 10:32:32 --> CSRF cookie sent
INFO - 2025-09-18 10:32:32 --> Input Class Initialized
INFO - 2025-09-18 10:32:32 --> Language Class Initialized
INFO - 2025-09-18 10:32:32 --> Loader Class Initialized
INFO - 2025-09-18 10:32:32 --> Helper loaded: url_helper
INFO - 2025-09-18 10:32:32 --> Helper loaded: text_helper
INFO - 2025-09-18 10:32:32 --> Helper loaded: string_helper
INFO - 2025-09-18 10:32:32 --> Helper loaded: form_helper
INFO - 2025-09-18 10:32:32 --> Helper loaded: download_helper
INFO - 2025-09-18 10:32:32 --> Helper loaded: security_helper
INFO - 2025-09-18 10:32:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-18 10:32:32 --> Database Driver Class Initialized
DEBUG - 2025-09-18 10:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-18 10:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-18 10:32:33 --> Form Validation Class Initialized
INFO - 2025-09-18 10:32:33 --> Model "User_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Nav_model" initialized
INFO - 2025-09-18 15:32:33 --> Controller Class Initialized
INFO - 2025-09-18 15:32:33 --> Model "Berita_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Galeri_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Video_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Agenda_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Tautan_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Mitra_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Jurusan_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Prodi_model" initialized
INFO - 2025-09-18 15:32:33 --> Model "Testimoni_model" initialized
INFO - 2025-09-18 15:32:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-18 15:32:33 --> Pagination Class Initialized
INFO - 2025-09-18 15:32:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-18 15:32:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-18 15:32:33 --> Model "Log_model" initialized
INFO - 2025-09-18 15:32:33 --> Final output sent to browser
DEBUG - 2025-09-18 15:32:33 --> Total execution time: 0.1624
