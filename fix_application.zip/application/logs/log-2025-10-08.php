<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-08 03:34:58 --> Config Class Initialized
INFO - 2025-10-08 03:34:58 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:34:59 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:34:59 --> Utf8 Class Initialized
INFO - 2025-10-08 03:34:59 --> URI Class Initialized
DEBUG - 2025-10-08 03:34:59 --> No URI present. Default controller set.
INFO - 2025-10-08 03:34:59 --> Router Class Initialized
INFO - 2025-10-08 03:34:59 --> Output Class Initialized
INFO - 2025-10-08 03:34:59 --> Security Class Initialized
DEBUG - 2025-10-08 03:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:34:59 --> CSRF cookie sent
INFO - 2025-10-08 03:34:59 --> Input Class Initialized
INFO - 2025-10-08 03:35:00 --> Language Class Initialized
INFO - 2025-10-08 03:35:00 --> Loader Class Initialized
INFO - 2025-10-08 03:35:00 --> Helper loaded: url_helper
INFO - 2025-10-08 03:35:00 --> Helper loaded: text_helper
INFO - 2025-10-08 03:35:00 --> Helper loaded: string_helper
INFO - 2025-10-08 03:35:00 --> Helper loaded: form_helper
INFO - 2025-10-08 03:35:00 --> Helper loaded: download_helper
INFO - 2025-10-08 03:35:00 --> Helper loaded: security_helper
INFO - 2025-10-08 03:35:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:35:01 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:35:01 --> Form Validation Class Initialized
INFO - 2025-10-08 03:35:01 --> Model "User_model" initialized
INFO - 2025-10-08 08:35:01 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:35:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:35:02 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:35:02 --> Controller Class Initialized
INFO - 2025-10-08 08:35:02 --> Model "Berita_model" initialized
INFO - 2025-10-08 08:35:02 --> Model "Galeri_model" initialized
INFO - 2025-10-08 08:35:02 --> Model "Video_model" initialized
INFO - 2025-10-08 08:35:02 --> Model "Agenda_model" initialized
INFO - 2025-10-08 08:35:02 --> Model "Tautan_model" initialized
INFO - 2025-10-08 08:35:02 --> Model "Mitra_model" initialized
INFO - 2025-10-08 08:35:02 --> Model "Jurusan_model" initialized
INFO - 2025-10-08 08:35:02 --> Model "Prodi_model" initialized
INFO - 2025-10-08 08:35:02 --> Model "Testimoni_model" initialized
INFO - 2025-10-08 08:35:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-08 08:35:02 --> Pagination Class Initialized
INFO - 2025-10-08 08:35:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-08 08:35:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-08 08:35:04 --> Model "Log_model" initialized
INFO - 2025-10-08 08:35:04 --> Final output sent to browser
DEBUG - 2025-10-08 08:35:04 --> Total execution time: 6.4829
INFO - 2025-10-08 03:35:21 --> Config Class Initialized
INFO - 2025-10-08 03:35:21 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:35:21 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:35:21 --> Utf8 Class Initialized
INFO - 2025-10-08 03:35:21 --> URI Class Initialized
INFO - 2025-10-08 03:35:21 --> Router Class Initialized
INFO - 2025-10-08 03:35:21 --> Output Class Initialized
INFO - 2025-10-08 03:35:21 --> Security Class Initialized
DEBUG - 2025-10-08 03:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:35:21 --> CSRF cookie sent
INFO - 2025-10-08 03:35:21 --> Input Class Initialized
INFO - 2025-10-08 03:35:21 --> Language Class Initialized
INFO - 2025-10-08 03:35:22 --> Loader Class Initialized
INFO - 2025-10-08 03:35:22 --> Helper loaded: url_helper
INFO - 2025-10-08 03:35:22 --> Helper loaded: text_helper
INFO - 2025-10-08 03:35:22 --> Helper loaded: string_helper
INFO - 2025-10-08 03:35:22 --> Helper loaded: form_helper
INFO - 2025-10-08 03:35:22 --> Helper loaded: download_helper
INFO - 2025-10-08 03:35:22 --> Helper loaded: security_helper
INFO - 2025-10-08 03:35:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:35:22 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:35:22 --> Form Validation Class Initialized
INFO - 2025-10-08 03:35:22 --> Model "User_model" initialized
INFO - 2025-10-08 08:35:22 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:35:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:35:22 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:35:22 --> Controller Class Initialized
DEBUG - 2025-10-08 08:35:22 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-10-08 08:35:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-10-08 08:35:22 --> Model "Log_model" initialized
INFO - 2025-10-08 08:35:22 --> Final output sent to browser
DEBUG - 2025-10-08 08:35:22 --> Total execution time: 0.5147
INFO - 2025-10-08 03:35:28 --> Config Class Initialized
INFO - 2025-10-08 03:35:28 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:35:28 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:35:28 --> Utf8 Class Initialized
INFO - 2025-10-08 03:35:28 --> URI Class Initialized
INFO - 2025-10-08 03:35:28 --> Router Class Initialized
INFO - 2025-10-08 03:35:28 --> Output Class Initialized
INFO - 2025-10-08 03:35:28 --> Security Class Initialized
DEBUG - 2025-10-08 03:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:35:28 --> CSRF cookie sent
INFO - 2025-10-08 03:35:28 --> CSRF token verified
INFO - 2025-10-08 03:35:28 --> Input Class Initialized
INFO - 2025-10-08 03:35:28 --> Language Class Initialized
INFO - 2025-10-08 03:35:28 --> Loader Class Initialized
INFO - 2025-10-08 03:35:28 --> Helper loaded: url_helper
INFO - 2025-10-08 03:35:28 --> Helper loaded: text_helper
INFO - 2025-10-08 03:35:28 --> Helper loaded: string_helper
INFO - 2025-10-08 03:35:28 --> Helper loaded: form_helper
INFO - 2025-10-08 03:35:28 --> Helper loaded: download_helper
INFO - 2025-10-08 03:35:28 --> Helper loaded: security_helper
INFO - 2025-10-08 03:35:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:35:28 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:35:28 --> Form Validation Class Initialized
INFO - 2025-10-08 03:35:28 --> Model "User_model" initialized
INFO - 2025-10-08 08:35:28 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:35:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:35:28 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:35:28 --> Controller Class Initialized
DEBUG - 2025-10-08 08:35:28 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-10-08 08:35:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-08 03:35:28 --> Config Class Initialized
INFO - 2025-10-08 03:35:28 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:35:29 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:35:29 --> Utf8 Class Initialized
INFO - 2025-10-08 03:35:29 --> URI Class Initialized
INFO - 2025-10-08 03:35:29 --> Router Class Initialized
INFO - 2025-10-08 03:35:29 --> Output Class Initialized
INFO - 2025-10-08 03:35:29 --> Security Class Initialized
DEBUG - 2025-10-08 03:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:35:29 --> CSRF cookie sent
INFO - 2025-10-08 03:35:29 --> Input Class Initialized
INFO - 2025-10-08 03:35:29 --> Language Class Initialized
INFO - 2025-10-08 03:35:29 --> Loader Class Initialized
INFO - 2025-10-08 03:35:29 --> Helper loaded: url_helper
INFO - 2025-10-08 03:35:29 --> Helper loaded: text_helper
INFO - 2025-10-08 03:35:29 --> Helper loaded: string_helper
INFO - 2025-10-08 03:35:29 --> Helper loaded: form_helper
INFO - 2025-10-08 03:35:29 --> Helper loaded: download_helper
INFO - 2025-10-08 03:35:29 --> Helper loaded: security_helper
INFO - 2025-10-08 03:35:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:35:29 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:35:29 --> Form Validation Class Initialized
INFO - 2025-10-08 03:35:29 --> Model "User_model" initialized
INFO - 2025-10-08 08:35:29 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:35:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:35:29 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:35:29 --> Controller Class Initialized
INFO - 2025-10-08 08:35:29 --> Model "Tautan_model" initialized
INFO - 2025-10-08 08:35:29 --> Model "Staff_model" initialized
INFO - 2025-10-08 08:35:29 --> Model "Dasbor_model" initialized
INFO - 2025-10-08 08:35:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-10-08 08:35:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-08 08:35:34 --> Model "Log_model" initialized
INFO - 2025-10-08 08:35:34 --> Final output sent to browser
DEBUG - 2025-10-08 08:35:34 --> Total execution time: 5.1000
INFO - 2025-10-08 03:35:42 --> Config Class Initialized
INFO - 2025-10-08 03:35:42 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:35:42 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:35:42 --> Utf8 Class Initialized
INFO - 2025-10-08 03:35:42 --> URI Class Initialized
INFO - 2025-10-08 03:35:42 --> Router Class Initialized
INFO - 2025-10-08 03:35:42 --> Output Class Initialized
INFO - 2025-10-08 03:35:42 --> Security Class Initialized
DEBUG - 2025-10-08 03:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:35:42 --> CSRF cookie sent
INFO - 2025-10-08 03:35:42 --> Input Class Initialized
INFO - 2025-10-08 03:35:42 --> Language Class Initialized
INFO - 2025-10-08 03:35:42 --> Loader Class Initialized
INFO - 2025-10-08 03:35:42 --> Helper loaded: url_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: text_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: string_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: form_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: download_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: security_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:35:42 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:35:42 --> Form Validation Class Initialized
INFO - 2025-10-08 03:35:42 --> Model "User_model" initialized
INFO - 2025-10-08 08:35:42 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:35:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:35:42 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:35:42 --> Controller Class Initialized
INFO - 2025-10-08 08:35:42 --> Model "Log_model" initialized
INFO - 2025-10-08 08:35:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-10-08 08:35:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-08 08:35:42 --> Model "Log_model" initialized
INFO - 2025-10-08 08:35:42 --> Final output sent to browser
DEBUG - 2025-10-08 08:35:42 --> Total execution time: 0.3161
INFO - 2025-10-08 03:35:42 --> Config Class Initialized
INFO - 2025-10-08 03:35:42 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:35:42 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:35:42 --> Utf8 Class Initialized
INFO - 2025-10-08 03:35:42 --> URI Class Initialized
INFO - 2025-10-08 03:35:42 --> Router Class Initialized
INFO - 2025-10-08 03:35:42 --> Output Class Initialized
INFO - 2025-10-08 03:35:42 --> Security Class Initialized
DEBUG - 2025-10-08 03:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:35:42 --> CSRF cookie sent
INFO - 2025-10-08 03:35:42 --> CSRF token verified
INFO - 2025-10-08 03:35:42 --> Input Class Initialized
INFO - 2025-10-08 03:35:42 --> Language Class Initialized
INFO - 2025-10-08 03:35:42 --> Loader Class Initialized
INFO - 2025-10-08 03:35:42 --> Helper loaded: url_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: text_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: string_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: form_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: download_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: security_helper
INFO - 2025-10-08 03:35:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:35:42 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:35:42 --> Form Validation Class Initialized
INFO - 2025-10-08 03:35:42 --> Model "User_model" initialized
INFO - 2025-10-08 08:35:42 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:35:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:35:42 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:35:42 --> Controller Class Initialized
INFO - 2025-10-08 08:35:42 --> Model "Log_model" initialized
INFO - 2025-10-08 08:35:43 --> Model "Log_model" initialized
INFO - 2025-10-08 08:35:43 --> Final output sent to browser
DEBUG - 2025-10-08 08:35:43 --> Total execution time: 0.4808
INFO - 2025-10-08 03:39:42 --> Config Class Initialized
INFO - 2025-10-08 03:39:42 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:39:42 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:39:42 --> Utf8 Class Initialized
INFO - 2025-10-08 03:39:42 --> URI Class Initialized
INFO - 2025-10-08 03:39:42 --> Router Class Initialized
INFO - 2025-10-08 03:39:42 --> Output Class Initialized
INFO - 2025-10-08 03:39:42 --> Security Class Initialized
DEBUG - 2025-10-08 03:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:39:42 --> CSRF cookie sent
INFO - 2025-10-08 03:39:42 --> Input Class Initialized
INFO - 2025-10-08 03:39:42 --> Language Class Initialized
ERROR - 2025-10-08 03:39:42 --> Severity: error --> Exception: syntax error, unexpected '.', expecting variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\dev_jkt3\application\controllers\admin\Log.php 67
INFO - 2025-10-08 03:39:57 --> Config Class Initialized
INFO - 2025-10-08 03:39:57 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:39:57 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:39:57 --> Utf8 Class Initialized
INFO - 2025-10-08 03:39:57 --> URI Class Initialized
INFO - 2025-10-08 03:39:57 --> Router Class Initialized
INFO - 2025-10-08 03:39:57 --> Output Class Initialized
INFO - 2025-10-08 03:39:57 --> Security Class Initialized
DEBUG - 2025-10-08 03:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:39:57 --> CSRF cookie sent
INFO - 2025-10-08 03:39:57 --> Input Class Initialized
INFO - 2025-10-08 03:39:57 --> Language Class Initialized
ERROR - 2025-10-08 03:39:57 --> Severity: error --> Exception: syntax error, unexpected '.', expecting variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\dev_jkt3\application\controllers\admin\Log.php 67
INFO - 2025-10-08 03:41:00 --> Config Class Initialized
INFO - 2025-10-08 03:41:00 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:41:00 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:41:00 --> Utf8 Class Initialized
INFO - 2025-10-08 03:41:00 --> URI Class Initialized
INFO - 2025-10-08 03:41:00 --> Router Class Initialized
INFO - 2025-10-08 03:41:00 --> Output Class Initialized
INFO - 2025-10-08 03:41:00 --> Security Class Initialized
DEBUG - 2025-10-08 03:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:41:00 --> CSRF cookie sent
INFO - 2025-10-08 03:41:00 --> Input Class Initialized
INFO - 2025-10-08 03:41:00 --> Language Class Initialized
INFO - 2025-10-08 03:41:00 --> Loader Class Initialized
INFO - 2025-10-08 03:41:00 --> Helper loaded: url_helper
INFO - 2025-10-08 03:41:00 --> Helper loaded: text_helper
INFO - 2025-10-08 03:41:00 --> Helper loaded: string_helper
INFO - 2025-10-08 03:41:00 --> Helper loaded: form_helper
INFO - 2025-10-08 03:41:00 --> Helper loaded: download_helper
INFO - 2025-10-08 03:41:00 --> Helper loaded: security_helper
INFO - 2025-10-08 03:41:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:41:00 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:41:00 --> Form Validation Class Initialized
INFO - 2025-10-08 03:41:00 --> Model "User_model" initialized
INFO - 2025-10-08 08:41:00 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:41:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:41:00 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:41:00 --> Controller Class Initialized
INFO - 2025-10-08 08:41:00 --> Model "Log_model" initialized
INFO - 2025-10-08 08:41:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-10-08 08:41:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-08 08:41:03 --> Model "Log_model" initialized
INFO - 2025-10-08 08:41:03 --> Final output sent to browser
DEBUG - 2025-10-08 08:41:03 --> Total execution time: 2.5737
INFO - 2025-10-08 03:41:04 --> Config Class Initialized
INFO - 2025-10-08 03:41:04 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:41:04 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:41:04 --> Utf8 Class Initialized
INFO - 2025-10-08 03:41:04 --> URI Class Initialized
INFO - 2025-10-08 03:41:04 --> Router Class Initialized
INFO - 2025-10-08 03:41:04 --> Output Class Initialized
INFO - 2025-10-08 03:41:04 --> Security Class Initialized
DEBUG - 2025-10-08 03:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:41:04 --> CSRF cookie sent
INFO - 2025-10-08 03:41:04 --> CSRF token verified
INFO - 2025-10-08 03:41:04 --> Input Class Initialized
INFO - 2025-10-08 03:41:04 --> Language Class Initialized
INFO - 2025-10-08 03:41:04 --> Loader Class Initialized
INFO - 2025-10-08 03:41:04 --> Helper loaded: url_helper
INFO - 2025-10-08 03:41:04 --> Helper loaded: text_helper
INFO - 2025-10-08 03:41:04 --> Helper loaded: string_helper
INFO - 2025-10-08 03:41:04 --> Helper loaded: form_helper
INFO - 2025-10-08 03:41:04 --> Helper loaded: download_helper
INFO - 2025-10-08 03:41:04 --> Helper loaded: security_helper
INFO - 2025-10-08 03:41:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:41:04 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:41:04 --> Form Validation Class Initialized
INFO - 2025-10-08 03:41:04 --> Model "User_model" initialized
INFO - 2025-10-08 08:41:04 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:41:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:41:04 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:41:04 --> Controller Class Initialized
INFO - 2025-10-08 08:41:04 --> Model "Log_model" initialized
INFO - 2025-10-08 08:41:04 --> Model "Log_model" initialized
INFO - 2025-10-08 08:41:04 --> Final output sent to browser
DEBUG - 2025-10-08 08:41:04 --> Total execution time: 0.5159
INFO - 2025-10-08 03:41:12 --> Config Class Initialized
INFO - 2025-10-08 03:41:12 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:41:12 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:41:12 --> Utf8 Class Initialized
INFO - 2025-10-08 03:41:12 --> URI Class Initialized
INFO - 2025-10-08 03:41:12 --> Router Class Initialized
INFO - 2025-10-08 03:41:12 --> Output Class Initialized
INFO - 2025-10-08 03:41:12 --> Security Class Initialized
DEBUG - 2025-10-08 03:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:41:12 --> CSRF cookie sent
INFO - 2025-10-08 03:41:12 --> Input Class Initialized
INFO - 2025-10-08 03:41:12 --> Language Class Initialized
INFO - 2025-10-08 03:41:12 --> Loader Class Initialized
INFO - 2025-10-08 03:41:12 --> Helper loaded: url_helper
INFO - 2025-10-08 03:41:12 --> Helper loaded: text_helper
INFO - 2025-10-08 03:41:12 --> Helper loaded: string_helper
INFO - 2025-10-08 03:41:12 --> Helper loaded: form_helper
INFO - 2025-10-08 03:41:12 --> Helper loaded: download_helper
INFO - 2025-10-08 03:41:12 --> Helper loaded: security_helper
INFO - 2025-10-08 03:41:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:41:12 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:41:12 --> Form Validation Class Initialized
INFO - 2025-10-08 03:41:12 --> Model "User_model" initialized
INFO - 2025-10-08 08:41:12 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:41:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:41:12 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:41:12 --> Controller Class Initialized
INFO - 2025-10-08 08:41:12 --> Model "Log_model" initialized
ERROR - 2025-10-08 08:41:12 --> Severity: Notice --> Undefined property: Activity::$M_settings D:\xampp\htdocs\dev_jkt3\application\controllers\admin\Activity.php 21
ERROR - 2025-10-08 08:41:12 --> Severity: error --> Exception: Call to a member function get_all_settings() on null D:\xampp\htdocs\dev_jkt3\application\controllers\admin\Activity.php 21
INFO - 2025-10-08 03:42:33 --> Config Class Initialized
INFO - 2025-10-08 03:42:33 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:42:33 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:42:33 --> Utf8 Class Initialized
INFO - 2025-10-08 03:42:33 --> URI Class Initialized
INFO - 2025-10-08 03:42:33 --> Router Class Initialized
INFO - 2025-10-08 03:42:33 --> Output Class Initialized
INFO - 2025-10-08 03:42:33 --> Security Class Initialized
DEBUG - 2025-10-08 03:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:42:33 --> CSRF cookie sent
INFO - 2025-10-08 03:42:33 --> Input Class Initialized
INFO - 2025-10-08 03:42:33 --> Language Class Initialized
INFO - 2025-10-08 03:42:33 --> Loader Class Initialized
INFO - 2025-10-08 03:42:33 --> Helper loaded: url_helper
INFO - 2025-10-08 03:42:33 --> Helper loaded: text_helper
INFO - 2025-10-08 03:42:33 --> Helper loaded: string_helper
INFO - 2025-10-08 03:42:33 --> Helper loaded: form_helper
INFO - 2025-10-08 03:42:33 --> Helper loaded: download_helper
INFO - 2025-10-08 03:42:33 --> Helper loaded: security_helper
INFO - 2025-10-08 03:42:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:42:33 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:42:33 --> Form Validation Class Initialized
INFO - 2025-10-08 03:42:33 --> Model "User_model" initialized
INFO - 2025-10-08 08:42:33 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:42:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:42:33 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:42:33 --> Controller Class Initialized
INFO - 2025-10-08 08:42:33 --> Model "Log_model" initialized
INFO - 2025-10-08 03:43:14 --> Config Class Initialized
INFO - 2025-10-08 03:43:14 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:43:14 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:43:14 --> Utf8 Class Initialized
INFO - 2025-10-08 03:43:14 --> URI Class Initialized
INFO - 2025-10-08 03:43:14 --> Router Class Initialized
INFO - 2025-10-08 03:43:14 --> Output Class Initialized
INFO - 2025-10-08 03:43:14 --> Security Class Initialized
DEBUG - 2025-10-08 03:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:43:14 --> CSRF cookie sent
INFO - 2025-10-08 03:43:14 --> Input Class Initialized
INFO - 2025-10-08 03:43:14 --> Language Class Initialized
INFO - 2025-10-08 03:43:14 --> Loader Class Initialized
INFO - 2025-10-08 03:43:14 --> Helper loaded: url_helper
INFO - 2025-10-08 03:43:14 --> Helper loaded: text_helper
INFO - 2025-10-08 03:43:14 --> Helper loaded: string_helper
INFO - 2025-10-08 03:43:14 --> Helper loaded: form_helper
INFO - 2025-10-08 03:43:14 --> Helper loaded: download_helper
INFO - 2025-10-08 03:43:14 --> Helper loaded: security_helper
INFO - 2025-10-08 03:43:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:43:14 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:43:14 --> Form Validation Class Initialized
INFO - 2025-10-08 03:43:14 --> Model "User_model" initialized
INFO - 2025-10-08 08:43:14 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:43:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:43:14 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:43:14 --> Controller Class Initialized
INFO - 2025-10-08 08:43:14 --> Model "Log_model" initialized
INFO - 2025-10-08 03:43:22 --> Config Class Initialized
INFO - 2025-10-08 03:43:22 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:43:22 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:43:22 --> Utf8 Class Initialized
INFO - 2025-10-08 03:43:22 --> URI Class Initialized
INFO - 2025-10-08 03:43:22 --> Router Class Initialized
INFO - 2025-10-08 03:43:22 --> Output Class Initialized
INFO - 2025-10-08 03:43:22 --> Security Class Initialized
DEBUG - 2025-10-08 03:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:43:22 --> CSRF cookie sent
INFO - 2025-10-08 03:43:22 --> Input Class Initialized
INFO - 2025-10-08 03:43:22 --> Language Class Initialized
INFO - 2025-10-08 03:43:22 --> Loader Class Initialized
INFO - 2025-10-08 03:43:22 --> Helper loaded: url_helper
INFO - 2025-10-08 03:43:22 --> Helper loaded: text_helper
INFO - 2025-10-08 03:43:22 --> Helper loaded: string_helper
INFO - 2025-10-08 03:43:22 --> Helper loaded: form_helper
INFO - 2025-10-08 03:43:22 --> Helper loaded: download_helper
INFO - 2025-10-08 03:43:22 --> Helper loaded: security_helper
INFO - 2025-10-08 03:43:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:43:22 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:43:22 --> Form Validation Class Initialized
INFO - 2025-10-08 03:43:22 --> Model "User_model" initialized
INFO - 2025-10-08 08:43:22 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:43:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:43:22 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:43:22 --> Controller Class Initialized
INFO - 2025-10-08 08:43:22 --> Model "Log_model" initialized
INFO - 2025-10-08 08:43:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-10-08 08:43:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-08 08:43:22 --> Model "Log_model" initialized
INFO - 2025-10-08 08:43:22 --> Final output sent to browser
DEBUG - 2025-10-08 08:43:22 --> Total execution time: 0.1592
INFO - 2025-10-08 03:43:23 --> Config Class Initialized
INFO - 2025-10-08 03:43:23 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:43:23 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:43:23 --> Utf8 Class Initialized
INFO - 2025-10-08 03:43:23 --> URI Class Initialized
INFO - 2025-10-08 03:43:23 --> Router Class Initialized
INFO - 2025-10-08 03:43:23 --> Output Class Initialized
INFO - 2025-10-08 03:43:23 --> Security Class Initialized
DEBUG - 2025-10-08 03:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:43:23 --> CSRF cookie sent
INFO - 2025-10-08 03:43:23 --> CSRF token verified
INFO - 2025-10-08 03:43:23 --> Input Class Initialized
INFO - 2025-10-08 03:43:23 --> Language Class Initialized
INFO - 2025-10-08 03:43:23 --> Loader Class Initialized
INFO - 2025-10-08 03:43:23 --> Helper loaded: url_helper
INFO - 2025-10-08 03:43:23 --> Helper loaded: text_helper
INFO - 2025-10-08 03:43:23 --> Helper loaded: string_helper
INFO - 2025-10-08 03:43:23 --> Helper loaded: form_helper
INFO - 2025-10-08 03:43:23 --> Helper loaded: download_helper
INFO - 2025-10-08 03:43:23 --> Helper loaded: security_helper
INFO - 2025-10-08 03:43:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:43:23 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:43:23 --> Form Validation Class Initialized
INFO - 2025-10-08 03:43:23 --> Model "User_model" initialized
INFO - 2025-10-08 08:43:23 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:43:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:43:23 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:43:23 --> Controller Class Initialized
INFO - 2025-10-08 08:43:23 --> Model "Log_model" initialized
INFO - 2025-10-08 08:43:23 --> Model "Log_model" initialized
INFO - 2025-10-08 08:43:23 --> Final output sent to browser
DEBUG - 2025-10-08 08:43:23 --> Total execution time: 0.4747
INFO - 2025-10-08 03:43:25 --> Config Class Initialized
INFO - 2025-10-08 03:43:25 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:43:25 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:43:25 --> Utf8 Class Initialized
INFO - 2025-10-08 03:43:25 --> URI Class Initialized
INFO - 2025-10-08 03:43:25 --> Router Class Initialized
INFO - 2025-10-08 03:43:25 --> Output Class Initialized
INFO - 2025-10-08 03:43:25 --> Security Class Initialized
DEBUG - 2025-10-08 03:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:43:25 --> CSRF cookie sent
INFO - 2025-10-08 03:43:25 --> Input Class Initialized
INFO - 2025-10-08 03:43:25 --> Language Class Initialized
INFO - 2025-10-08 03:43:25 --> Loader Class Initialized
INFO - 2025-10-08 03:43:25 --> Helper loaded: url_helper
INFO - 2025-10-08 03:43:25 --> Helper loaded: text_helper
INFO - 2025-10-08 03:43:25 --> Helper loaded: string_helper
INFO - 2025-10-08 03:43:25 --> Helper loaded: form_helper
INFO - 2025-10-08 03:43:25 --> Helper loaded: download_helper
INFO - 2025-10-08 03:43:25 --> Helper loaded: security_helper
INFO - 2025-10-08 03:43:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:43:25 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:43:25 --> Form Validation Class Initialized
INFO - 2025-10-08 03:43:25 --> Model "User_model" initialized
INFO - 2025-10-08 08:43:25 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:43:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:43:25 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:43:25 --> Controller Class Initialized
INFO - 2025-10-08 08:43:25 --> Model "Log_model" initialized
INFO - 2025-10-08 08:43:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-10-08 08:43:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-08 08:43:25 --> Model "Log_model" initialized
INFO - 2025-10-08 08:43:25 --> Final output sent to browser
DEBUG - 2025-10-08 08:43:25 --> Total execution time: 0.1188
INFO - 2025-10-08 03:43:25 --> Config Class Initialized
INFO - 2025-10-08 03:43:25 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:43:25 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:43:26 --> Utf8 Class Initialized
INFO - 2025-10-08 03:43:26 --> URI Class Initialized
INFO - 2025-10-08 03:43:26 --> Router Class Initialized
INFO - 2025-10-08 03:43:26 --> Output Class Initialized
INFO - 2025-10-08 03:43:26 --> Security Class Initialized
DEBUG - 2025-10-08 03:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:43:26 --> CSRF cookie sent
INFO - 2025-10-08 03:43:26 --> CSRF token verified
INFO - 2025-10-08 03:43:26 --> Input Class Initialized
INFO - 2025-10-08 03:43:26 --> Language Class Initialized
INFO - 2025-10-08 03:43:26 --> Loader Class Initialized
INFO - 2025-10-08 03:43:26 --> Helper loaded: url_helper
INFO - 2025-10-08 03:43:26 --> Helper loaded: text_helper
INFO - 2025-10-08 03:43:26 --> Helper loaded: string_helper
INFO - 2025-10-08 03:43:26 --> Helper loaded: form_helper
INFO - 2025-10-08 03:43:26 --> Helper loaded: download_helper
INFO - 2025-10-08 03:43:26 --> Helper loaded: security_helper
INFO - 2025-10-08 03:43:26 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:43:26 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:43:26 --> Form Validation Class Initialized
INFO - 2025-10-08 03:43:26 --> Model "User_model" initialized
INFO - 2025-10-08 08:43:26 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:43:26 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:43:26 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:43:26 --> Controller Class Initialized
INFO - 2025-10-08 08:43:26 --> Model "Log_model" initialized
INFO - 2025-10-08 08:43:26 --> Model "Log_model" initialized
INFO - 2025-10-08 08:43:26 --> Final output sent to browser
DEBUG - 2025-10-08 08:43:26 --> Total execution time: 0.3614
INFO - 2025-10-08 03:43:28 --> Config Class Initialized
INFO - 2025-10-08 03:43:28 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:43:28 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:43:28 --> Utf8 Class Initialized
INFO - 2025-10-08 03:43:28 --> URI Class Initialized
INFO - 2025-10-08 03:43:28 --> Router Class Initialized
INFO - 2025-10-08 03:43:28 --> Output Class Initialized
INFO - 2025-10-08 03:43:28 --> Security Class Initialized
DEBUG - 2025-10-08 03:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:43:28 --> CSRF cookie sent
INFO - 2025-10-08 03:43:28 --> Input Class Initialized
INFO - 2025-10-08 03:43:28 --> Language Class Initialized
INFO - 2025-10-08 03:43:28 --> Loader Class Initialized
INFO - 2025-10-08 03:43:28 --> Helper loaded: url_helper
INFO - 2025-10-08 03:43:28 --> Helper loaded: text_helper
INFO - 2025-10-08 03:43:28 --> Helper loaded: string_helper
INFO - 2025-10-08 03:43:28 --> Helper loaded: form_helper
INFO - 2025-10-08 03:43:28 --> Helper loaded: download_helper
INFO - 2025-10-08 03:43:28 --> Helper loaded: security_helper
INFO - 2025-10-08 03:43:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:43:28 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:43:28 --> Form Validation Class Initialized
INFO - 2025-10-08 03:43:28 --> Model "User_model" initialized
INFO - 2025-10-08 08:43:28 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:43:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:43:28 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:43:28 --> Controller Class Initialized
INFO - 2025-10-08 08:43:28 --> Model "Log_model" initialized
INFO - 2025-10-08 03:44:39 --> Config Class Initialized
INFO - 2025-10-08 03:44:39 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:44:39 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:44:39 --> Utf8 Class Initialized
INFO - 2025-10-08 03:44:39 --> URI Class Initialized
INFO - 2025-10-08 03:44:39 --> Router Class Initialized
INFO - 2025-10-08 03:44:39 --> Output Class Initialized
INFO - 2025-10-08 03:44:39 --> Security Class Initialized
DEBUG - 2025-10-08 03:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:44:39 --> CSRF cookie sent
INFO - 2025-10-08 03:44:39 --> Input Class Initialized
INFO - 2025-10-08 03:44:39 --> Language Class Initialized
INFO - 2025-10-08 03:44:39 --> Loader Class Initialized
INFO - 2025-10-08 03:44:39 --> Helper loaded: url_helper
INFO - 2025-10-08 03:44:39 --> Helper loaded: text_helper
INFO - 2025-10-08 03:44:39 --> Helper loaded: string_helper
INFO - 2025-10-08 03:44:39 --> Helper loaded: form_helper
INFO - 2025-10-08 03:44:39 --> Helper loaded: download_helper
INFO - 2025-10-08 03:44:39 --> Helper loaded: security_helper
INFO - 2025-10-08 03:44:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:44:39 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:44:39 --> Form Validation Class Initialized
INFO - 2025-10-08 03:44:39 --> Model "User_model" initialized
INFO - 2025-10-08 08:44:39 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:44:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:44:39 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:44:39 --> Controller Class Initialized
INFO - 2025-10-08 08:44:39 --> Model "Log_model" initialized
INFO - 2025-10-08 03:45:23 --> Config Class Initialized
INFO - 2025-10-08 03:45:23 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:45:23 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:45:23 --> Utf8 Class Initialized
INFO - 2025-10-08 03:45:23 --> URI Class Initialized
INFO - 2025-10-08 03:45:23 --> Router Class Initialized
INFO - 2025-10-08 03:45:23 --> Output Class Initialized
INFO - 2025-10-08 03:45:23 --> Security Class Initialized
DEBUG - 2025-10-08 03:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:45:23 --> CSRF cookie sent
INFO - 2025-10-08 03:45:23 --> Input Class Initialized
INFO - 2025-10-08 03:45:23 --> Language Class Initialized
INFO - 2025-10-08 03:45:23 --> Loader Class Initialized
INFO - 2025-10-08 03:45:23 --> Helper loaded: url_helper
INFO - 2025-10-08 03:45:23 --> Helper loaded: text_helper
INFO - 2025-10-08 03:45:23 --> Helper loaded: string_helper
INFO - 2025-10-08 03:45:23 --> Helper loaded: form_helper
INFO - 2025-10-08 03:45:23 --> Helper loaded: download_helper
INFO - 2025-10-08 03:45:23 --> Helper loaded: security_helper
INFO - 2025-10-08 03:45:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:45:23 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:45:23 --> Form Validation Class Initialized
INFO - 2025-10-08 03:45:23 --> Model "User_model" initialized
INFO - 2025-10-08 08:45:23 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:45:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:45:23 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:45:23 --> Controller Class Initialized
INFO - 2025-10-08 08:45:23 --> Model "Log_model" initialized
INFO - 2025-10-08 08:45:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/activity.php
INFO - 2025-10-08 08:45:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-08 08:45:23 --> Model "Log_model" initialized
INFO - 2025-10-08 08:45:23 --> Final output sent to browser
DEBUG - 2025-10-08 08:45:23 --> Total execution time: 0.1088
INFO - 2025-10-08 03:45:24 --> Config Class Initialized
INFO - 2025-10-08 03:45:24 --> Hooks Class Initialized
DEBUG - 2025-10-08 03:45:24 --> UTF-8 Support Enabled
INFO - 2025-10-08 03:45:24 --> Utf8 Class Initialized
INFO - 2025-10-08 03:45:24 --> URI Class Initialized
INFO - 2025-10-08 03:45:24 --> Router Class Initialized
INFO - 2025-10-08 03:45:24 --> Output Class Initialized
INFO - 2025-10-08 03:45:24 --> Security Class Initialized
DEBUG - 2025-10-08 03:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-08 03:45:24 --> CSRF cookie sent
INFO - 2025-10-08 03:45:24 --> CSRF token verified
INFO - 2025-10-08 03:45:24 --> Input Class Initialized
INFO - 2025-10-08 03:45:24 --> Language Class Initialized
INFO - 2025-10-08 03:45:24 --> Loader Class Initialized
INFO - 2025-10-08 03:45:24 --> Helper loaded: url_helper
INFO - 2025-10-08 03:45:24 --> Helper loaded: text_helper
INFO - 2025-10-08 03:45:24 --> Helper loaded: string_helper
INFO - 2025-10-08 03:45:24 --> Helper loaded: form_helper
INFO - 2025-10-08 03:45:24 --> Helper loaded: download_helper
INFO - 2025-10-08 03:45:24 --> Helper loaded: security_helper
INFO - 2025-10-08 03:45:24 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-08 03:45:24 --> Database Driver Class Initialized
DEBUG - 2025-10-08 03:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-08 03:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-08 03:45:24 --> Form Validation Class Initialized
INFO - 2025-10-08 03:45:24 --> Model "User_model" initialized
INFO - 2025-10-08 08:45:24 --> Model "Kunjungan_model" initialized
INFO - 2025-10-08 08:45:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-08 08:45:24 --> Model "Nav_model" initialized
INFO - 2025-10-08 08:45:24 --> Controller Class Initialized
INFO - 2025-10-08 08:45:24 --> Model "Log_model" initialized
DEBUG - 2025-10-08 08:45:24 --> CSRF Token dari request POST: TIDAK ADA
DEBUG - 2025-10-08 08:45:24 --> CSRF Token yang valid: 5ae125f06986c1d3b587d1888f0c06ab
DEBUG - 2025-10-08 08:45:24 --> Session CSRF Token: 
ERROR - 2025-10-08 08:45:24 --> CSRF Token kosong, periksa apakah dikirim dari frontend.
