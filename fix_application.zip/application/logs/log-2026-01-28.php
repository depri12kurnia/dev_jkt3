<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-28 02:56:44 --> Config Class Initialized
INFO - 2026-01-28 02:56:44 --> Hooks Class Initialized
DEBUG - 2026-01-28 02:56:45 --> UTF-8 Support Enabled
INFO - 2026-01-28 02:56:45 --> Utf8 Class Initialized
INFO - 2026-01-28 02:56:45 --> URI Class Initialized
DEBUG - 2026-01-28 02:56:45 --> No URI present. Default controller set.
INFO - 2026-01-28 02:56:45 --> Router Class Initialized
INFO - 2026-01-28 02:56:45 --> Output Class Initialized
INFO - 2026-01-28 02:56:45 --> Security Class Initialized
DEBUG - 2026-01-28 02:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-28 02:56:45 --> CSRF cookie sent
INFO - 2026-01-28 02:56:45 --> Input Class Initialized
INFO - 2026-01-28 02:56:45 --> Language Class Initialized
INFO - 2026-01-28 02:56:45 --> Loader Class Initialized
INFO - 2026-01-28 02:56:45 --> Helper loaded: url_helper
INFO - 2026-01-28 02:56:46 --> Helper loaded: text_helper
INFO - 2026-01-28 02:56:46 --> Helper loaded: string_helper
INFO - 2026-01-28 02:56:46 --> Helper loaded: form_helper
INFO - 2026-01-28 02:56:46 --> Helper loaded: download_helper
INFO - 2026-01-28 02:56:46 --> Helper loaded: security_helper
INFO - 2026-01-28 02:56:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-28 02:56:46 --> Database Driver Class Initialized
DEBUG - 2026-01-28 02:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-28 02:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-28 02:56:46 --> Form Validation Class Initialized
INFO - 2026-01-28 02:56:47 --> Model "User_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Kunjungan_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Nav_model" initialized
INFO - 2026-01-28 08:56:47 --> Controller Class Initialized
INFO - 2026-01-28 08:56:47 --> Model "Berita_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Galeri_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Video_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Agenda_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Tautan_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Mitra_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Jurusan_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Prodi_model" initialized
INFO - 2026-01-28 08:56:47 --> Model "Testimoni_model" initialized
INFO - 2026-01-28 08:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-28 08:56:48 --> Pagination Class Initialized
INFO - 2026-01-28 08:56:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-28 08:56:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-28 08:56:51 --> Model "Log_model" initialized
INFO - 2026-01-28 08:56:51 --> Final output sent to browser
DEBUG - 2026-01-28 08:56:51 --> Total execution time: 6.4975
INFO - 2026-01-28 03:16:25 --> Config Class Initialized
INFO - 2026-01-28 03:16:25 --> Hooks Class Initialized
DEBUG - 2026-01-28 03:16:25 --> UTF-8 Support Enabled
INFO - 2026-01-28 03:16:25 --> Utf8 Class Initialized
INFO - 2026-01-28 03:16:25 --> URI Class Initialized
DEBUG - 2026-01-28 03:16:25 --> No URI present. Default controller set.
INFO - 2026-01-28 03:16:25 --> Router Class Initialized
INFO - 2026-01-28 03:16:25 --> Output Class Initialized
INFO - 2026-01-28 03:16:25 --> Security Class Initialized
DEBUG - 2026-01-28 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-28 03:16:25 --> CSRF cookie sent
INFO - 2026-01-28 03:16:25 --> Input Class Initialized
INFO - 2026-01-28 03:16:25 --> Language Class Initialized
INFO - 2026-01-28 03:16:25 --> Loader Class Initialized
INFO - 2026-01-28 03:16:25 --> Helper loaded: url_helper
INFO - 2026-01-28 03:16:25 --> Helper loaded: text_helper
INFO - 2026-01-28 03:16:25 --> Helper loaded: string_helper
INFO - 2026-01-28 03:16:25 --> Helper loaded: form_helper
INFO - 2026-01-28 03:16:25 --> Helper loaded: download_helper
INFO - 2026-01-28 03:16:25 --> Helper loaded: security_helper
INFO - 2026-01-28 03:16:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-28 03:16:25 --> Database Driver Class Initialized
DEBUG - 2026-01-28 03:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-28 03:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-28 03:16:25 --> Form Validation Class Initialized
INFO - 2026-01-28 03:16:25 --> Model "User_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Nav_model" initialized
INFO - 2026-01-28 09:16:25 --> Controller Class Initialized
INFO - 2026-01-28 09:16:25 --> Model "Berita_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Galeri_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Video_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Agenda_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Tautan_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Mitra_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Jurusan_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Prodi_model" initialized
INFO - 2026-01-28 09:16:25 --> Model "Testimoni_model" initialized
INFO - 2026-01-28 09:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-28 09:16:25 --> Pagination Class Initialized
INFO - 2026-01-28 09:16:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-28 09:16:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-28 09:16:25 --> Model "Log_model" initialized
INFO - 2026-01-28 09:16:25 --> Final output sent to browser
DEBUG - 2026-01-28 09:16:25 --> Total execution time: 0.2530
INFO - 2026-01-28 03:16:36 --> Config Class Initialized
INFO - 2026-01-28 03:16:36 --> Hooks Class Initialized
DEBUG - 2026-01-28 03:16:36 --> UTF-8 Support Enabled
INFO - 2026-01-28 03:16:36 --> Utf8 Class Initialized
INFO - 2026-01-28 03:16:36 --> URI Class Initialized
DEBUG - 2026-01-28 03:16:36 --> No URI present. Default controller set.
INFO - 2026-01-28 03:16:36 --> Router Class Initialized
INFO - 2026-01-28 03:16:36 --> Output Class Initialized
INFO - 2026-01-28 03:16:36 --> Security Class Initialized
DEBUG - 2026-01-28 03:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-28 03:16:36 --> CSRF cookie sent
INFO - 2026-01-28 03:16:36 --> Input Class Initialized
INFO - 2026-01-28 03:16:36 --> Language Class Initialized
INFO - 2026-01-28 03:16:36 --> Loader Class Initialized
INFO - 2026-01-28 03:16:36 --> Helper loaded: url_helper
INFO - 2026-01-28 03:16:36 --> Helper loaded: text_helper
INFO - 2026-01-28 03:16:36 --> Helper loaded: string_helper
INFO - 2026-01-28 03:16:36 --> Helper loaded: form_helper
INFO - 2026-01-28 03:16:36 --> Helper loaded: download_helper
INFO - 2026-01-28 03:16:36 --> Helper loaded: security_helper
INFO - 2026-01-28 03:16:36 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-28 03:16:36 --> Database Driver Class Initialized
DEBUG - 2026-01-28 03:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-28 03:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-28 03:16:36 --> Form Validation Class Initialized
INFO - 2026-01-28 03:16:36 --> Model "User_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Kunjungan_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Nav_model" initialized
INFO - 2026-01-28 09:16:36 --> Controller Class Initialized
INFO - 2026-01-28 09:16:36 --> Model "Berita_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Galeri_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Video_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Agenda_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Tautan_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Mitra_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Jurusan_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Prodi_model" initialized
INFO - 2026-01-28 09:16:36 --> Model "Testimoni_model" initialized
INFO - 2026-01-28 09:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-28 09:16:36 --> Pagination Class Initialized
INFO - 2026-01-28 09:16:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-28 09:16:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-28 09:16:36 --> Model "Log_model" initialized
INFO - 2026-01-28 09:16:36 --> Final output sent to browser
DEBUG - 2026-01-28 09:16:36 --> Total execution time: 0.2907
INFO - 2026-01-28 03:17:42 --> Config Class Initialized
INFO - 2026-01-28 03:17:42 --> Hooks Class Initialized
DEBUG - 2026-01-28 03:17:42 --> UTF-8 Support Enabled
INFO - 2026-01-28 03:17:42 --> Utf8 Class Initialized
INFO - 2026-01-28 03:17:42 --> URI Class Initialized
DEBUG - 2026-01-28 03:17:42 --> No URI present. Default controller set.
INFO - 2026-01-28 03:17:42 --> Router Class Initialized
INFO - 2026-01-28 03:17:42 --> Output Class Initialized
INFO - 2026-01-28 03:17:42 --> Security Class Initialized
DEBUG - 2026-01-28 03:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-28 03:17:42 --> CSRF cookie sent
INFO - 2026-01-28 03:17:42 --> Input Class Initialized
INFO - 2026-01-28 03:17:42 --> Language Class Initialized
INFO - 2026-01-28 03:17:42 --> Loader Class Initialized
INFO - 2026-01-28 03:17:42 --> Helper loaded: url_helper
INFO - 2026-01-28 03:17:42 --> Helper loaded: text_helper
INFO - 2026-01-28 03:17:42 --> Helper loaded: string_helper
INFO - 2026-01-28 03:17:42 --> Helper loaded: form_helper
INFO - 2026-01-28 03:17:42 --> Helper loaded: download_helper
INFO - 2026-01-28 03:17:42 --> Helper loaded: security_helper
INFO - 2026-01-28 03:17:42 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-28 03:17:42 --> Database Driver Class Initialized
DEBUG - 2026-01-28 03:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-28 03:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-28 03:17:42 --> Form Validation Class Initialized
INFO - 2026-01-28 03:17:42 --> Model "User_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Kunjungan_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Nav_model" initialized
INFO - 2026-01-28 09:17:42 --> Controller Class Initialized
INFO - 2026-01-28 09:17:42 --> Model "Berita_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Galeri_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Video_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Agenda_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Tautan_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Mitra_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Jurusan_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Prodi_model" initialized
INFO - 2026-01-28 09:17:42 --> Model "Testimoni_model" initialized
INFO - 2026-01-28 09:17:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-28 09:17:42 --> Pagination Class Initialized
INFO - 2026-01-28 09:17:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-28 09:17:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-28 09:17:42 --> Model "Log_model" initialized
INFO - 2026-01-28 09:17:42 --> Final output sent to browser
DEBUG - 2026-01-28 09:17:42 --> Total execution time: 0.2583
INFO - 2026-01-28 03:30:03 --> Config Class Initialized
INFO - 2026-01-28 03:30:03 --> Hooks Class Initialized
DEBUG - 2026-01-28 03:30:03 --> UTF-8 Support Enabled
INFO - 2026-01-28 03:30:03 --> Utf8 Class Initialized
INFO - 2026-01-28 03:30:03 --> URI Class Initialized
DEBUG - 2026-01-28 03:30:03 --> No URI present. Default controller set.
INFO - 2026-01-28 03:30:03 --> Router Class Initialized
INFO - 2026-01-28 03:30:03 --> Output Class Initialized
INFO - 2026-01-28 03:30:03 --> Security Class Initialized
DEBUG - 2026-01-28 03:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-28 03:30:03 --> CSRF cookie sent
INFO - 2026-01-28 03:30:03 --> Input Class Initialized
INFO - 2026-01-28 03:30:03 --> Language Class Initialized
INFO - 2026-01-28 03:30:03 --> Loader Class Initialized
INFO - 2026-01-28 03:30:03 --> Helper loaded: url_helper
INFO - 2026-01-28 03:30:03 --> Helper loaded: text_helper
INFO - 2026-01-28 03:30:03 --> Helper loaded: string_helper
INFO - 2026-01-28 03:30:03 --> Helper loaded: form_helper
INFO - 2026-01-28 03:30:03 --> Helper loaded: download_helper
INFO - 2026-01-28 03:30:03 --> Helper loaded: security_helper
INFO - 2026-01-28 03:30:03 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-28 03:30:03 --> Database Driver Class Initialized
DEBUG - 2026-01-28 03:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-28 03:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-28 03:30:03 --> Form Validation Class Initialized
INFO - 2026-01-28 03:30:03 --> Model "User_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Kunjungan_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Nav_model" initialized
INFO - 2026-01-28 09:30:03 --> Controller Class Initialized
INFO - 2026-01-28 09:30:03 --> Model "Berita_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Galeri_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Video_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Agenda_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Tautan_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Mitra_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Jurusan_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Prodi_model" initialized
INFO - 2026-01-28 09:30:03 --> Model "Testimoni_model" initialized
INFO - 2026-01-28 09:30:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-28 09:30:03 --> Pagination Class Initialized
INFO - 2026-01-28 09:30:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-28 09:30:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-28 09:30:04 --> Model "Log_model" initialized
INFO - 2026-01-28 09:30:04 --> Final output sent to browser
DEBUG - 2026-01-28 09:30:04 --> Total execution time: 0.2896
