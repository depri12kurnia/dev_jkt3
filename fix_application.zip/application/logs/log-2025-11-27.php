<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-27 09:13:31 --> Config Class Initialized
INFO - 2025-11-27 09:13:31 --> Hooks Class Initialized
DEBUG - 2025-11-27 09:13:32 --> UTF-8 Support Enabled
INFO - 2025-11-27 09:13:32 --> Utf8 Class Initialized
INFO - 2025-11-27 09:13:32 --> URI Class Initialized
DEBUG - 2025-11-27 09:13:32 --> No URI present. Default controller set.
INFO - 2025-11-27 09:13:32 --> Router Class Initialized
INFO - 2025-11-27 09:13:32 --> Output Class Initialized
INFO - 2025-11-27 09:13:32 --> Security Class Initialized
DEBUG - 2025-11-27 09:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-27 09:13:32 --> CSRF cookie sent
INFO - 2025-11-27 09:13:32 --> Input Class Initialized
INFO - 2025-11-27 09:13:32 --> Language Class Initialized
INFO - 2025-11-27 09:13:32 --> Loader Class Initialized
INFO - 2025-11-27 09:13:32 --> Helper loaded: url_helper
INFO - 2025-11-27 09:13:32 --> Helper loaded: text_helper
INFO - 2025-11-27 09:13:32 --> Helper loaded: string_helper
INFO - 2025-11-27 09:13:33 --> Helper loaded: form_helper
INFO - 2025-11-27 09:13:33 --> Helper loaded: download_helper
INFO - 2025-11-27 09:13:33 --> Helper loaded: security_helper
INFO - 2025-11-27 09:13:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-27 09:13:33 --> Database Driver Class Initialized
DEBUG - 2025-11-27 09:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-27 09:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-27 09:13:33 --> Form Validation Class Initialized
INFO - 2025-11-27 09:13:33 --> Model "User_model" initialized
INFO - 2025-11-27 15:13:33 --> Model "Kunjungan_model" initialized
INFO - 2025-11-27 15:13:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-27 15:13:34 --> Model "Nav_model" initialized
INFO - 2025-11-27 15:13:34 --> Controller Class Initialized
INFO - 2025-11-27 15:13:34 --> Model "Berita_model" initialized
INFO - 2025-11-27 15:13:34 --> Model "Galeri_model" initialized
INFO - 2025-11-27 15:13:34 --> Model "Video_model" initialized
INFO - 2025-11-27 15:13:34 --> Model "Agenda_model" initialized
INFO - 2025-11-27 15:13:34 --> Model "Tautan_model" initialized
INFO - 2025-11-27 15:13:34 --> Model "Mitra_model" initialized
INFO - 2025-11-27 15:13:34 --> Model "Jurusan_model" initialized
INFO - 2025-11-27 15:13:34 --> Model "Prodi_model" initialized
INFO - 2025-11-27 15:13:34 --> Model "Testimoni_model" initialized
INFO - 2025-11-27 15:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-27 15:13:35 --> Pagination Class Initialized
INFO - 2025-11-27 15:13:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-27 15:13:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-27 15:13:38 --> Model "Log_model" initialized
INFO - 2025-11-27 15:13:38 --> Final output sent to browser
DEBUG - 2025-11-27 15:13:38 --> Total execution time: 6.4367
INFO - 2025-11-27 09:14:24 --> Config Class Initialized
INFO - 2025-11-27 09:14:24 --> Hooks Class Initialized
DEBUG - 2025-11-27 09:14:24 --> UTF-8 Support Enabled
INFO - 2025-11-27 09:14:24 --> Utf8 Class Initialized
INFO - 2025-11-27 09:14:24 --> URI Class Initialized
DEBUG - 2025-11-27 09:14:24 --> No URI present. Default controller set.
INFO - 2025-11-27 09:14:24 --> Router Class Initialized
INFO - 2025-11-27 09:14:24 --> Output Class Initialized
INFO - 2025-11-27 09:14:24 --> Security Class Initialized
DEBUG - 2025-11-27 09:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-27 09:14:24 --> CSRF cookie sent
INFO - 2025-11-27 09:14:24 --> Input Class Initialized
INFO - 2025-11-27 09:14:24 --> Language Class Initialized
INFO - 2025-11-27 09:14:24 --> Loader Class Initialized
INFO - 2025-11-27 09:14:24 --> Helper loaded: url_helper
INFO - 2025-11-27 09:14:24 --> Helper loaded: text_helper
INFO - 2025-11-27 09:14:24 --> Helper loaded: string_helper
INFO - 2025-11-27 09:14:24 --> Helper loaded: form_helper
INFO - 2025-11-27 09:14:24 --> Helper loaded: download_helper
INFO - 2025-11-27 09:14:24 --> Helper loaded: security_helper
INFO - 2025-11-27 09:14:24 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-27 09:14:24 --> Database Driver Class Initialized
DEBUG - 2025-11-27 09:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-27 09:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-27 09:14:24 --> Form Validation Class Initialized
INFO - 2025-11-27 09:14:24 --> Model "User_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Kunjungan_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Nav_model" initialized
INFO - 2025-11-27 15:14:24 --> Controller Class Initialized
INFO - 2025-11-27 15:14:24 --> Model "Berita_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Galeri_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Video_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Agenda_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Tautan_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Mitra_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Jurusan_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Prodi_model" initialized
INFO - 2025-11-27 15:14:24 --> Model "Testimoni_model" initialized
INFO - 2025-11-27 15:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-27 15:14:24 --> Pagination Class Initialized
INFO - 2025-11-27 15:14:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-27 15:14:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-27 15:14:24 --> Model "Log_model" initialized
INFO - 2025-11-27 15:14:24 --> Final output sent to browser
DEBUG - 2025-11-27 15:14:24 --> Total execution time: 0.2766
INFO - 2025-11-27 09:14:32 --> Config Class Initialized
INFO - 2025-11-27 09:14:32 --> Hooks Class Initialized
DEBUG - 2025-11-27 09:14:32 --> UTF-8 Support Enabled
INFO - 2025-11-27 09:14:32 --> Utf8 Class Initialized
INFO - 2025-11-27 09:14:32 --> URI Class Initialized
DEBUG - 2025-11-27 09:14:32 --> No URI present. Default controller set.
INFO - 2025-11-27 09:14:32 --> Router Class Initialized
INFO - 2025-11-27 09:14:32 --> Output Class Initialized
INFO - 2025-11-27 09:14:32 --> Security Class Initialized
DEBUG - 2025-11-27 09:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-27 09:14:32 --> CSRF cookie sent
INFO - 2025-11-27 09:14:32 --> Input Class Initialized
INFO - 2025-11-27 09:14:32 --> Language Class Initialized
INFO - 2025-11-27 09:14:32 --> Loader Class Initialized
INFO - 2025-11-27 09:14:32 --> Helper loaded: url_helper
INFO - 2025-11-27 09:14:32 --> Helper loaded: text_helper
INFO - 2025-11-27 09:14:32 --> Helper loaded: string_helper
INFO - 2025-11-27 09:14:32 --> Helper loaded: form_helper
INFO - 2025-11-27 09:14:32 --> Helper loaded: download_helper
INFO - 2025-11-27 09:14:32 --> Helper loaded: security_helper
INFO - 2025-11-27 09:14:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-27 09:14:32 --> Database Driver Class Initialized
DEBUG - 2025-11-27 09:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-27 09:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-27 09:14:32 --> Form Validation Class Initialized
INFO - 2025-11-27 09:14:32 --> Model "User_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Kunjungan_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Nav_model" initialized
INFO - 2025-11-27 15:14:32 --> Controller Class Initialized
INFO - 2025-11-27 15:14:32 --> Model "Berita_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Galeri_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Video_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Agenda_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Tautan_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Mitra_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Jurusan_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Prodi_model" initialized
INFO - 2025-11-27 15:14:32 --> Model "Testimoni_model" initialized
INFO - 2025-11-27 15:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-27 15:14:32 --> Pagination Class Initialized
INFO - 2025-11-27 15:14:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-27 15:14:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-27 15:14:32 --> Model "Log_model" initialized
INFO - 2025-11-27 15:14:32 --> Final output sent to browser
DEBUG - 2025-11-27 15:14:32 --> Total execution time: 0.2507
INFO - 2025-11-27 09:14:48 --> Config Class Initialized
INFO - 2025-11-27 09:14:48 --> Hooks Class Initialized
DEBUG - 2025-11-27 09:14:48 --> UTF-8 Support Enabled
INFO - 2025-11-27 09:14:48 --> Utf8 Class Initialized
INFO - 2025-11-27 09:14:48 --> URI Class Initialized
INFO - 2025-11-27 09:14:48 --> Router Class Initialized
INFO - 2025-11-27 09:14:48 --> Output Class Initialized
INFO - 2025-11-27 09:14:48 --> Security Class Initialized
DEBUG - 2025-11-27 09:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-27 09:14:48 --> CSRF cookie sent
INFO - 2025-11-27 09:14:48 --> Input Class Initialized
INFO - 2025-11-27 09:14:48 --> Language Class Initialized
INFO - 2025-11-27 09:14:48 --> Loader Class Initialized
INFO - 2025-11-27 09:14:48 --> Helper loaded: url_helper
INFO - 2025-11-27 09:14:48 --> Helper loaded: text_helper
INFO - 2025-11-27 09:14:48 --> Helper loaded: string_helper
INFO - 2025-11-27 09:14:48 --> Helper loaded: form_helper
INFO - 2025-11-27 09:14:48 --> Helper loaded: download_helper
INFO - 2025-11-27 09:14:48 --> Helper loaded: security_helper
INFO - 2025-11-27 09:14:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-27 09:14:48 --> Database Driver Class Initialized
DEBUG - 2025-11-27 09:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-27 09:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-27 09:14:48 --> Form Validation Class Initialized
INFO - 2025-11-27 09:14:48 --> Model "User_model" initialized
INFO - 2025-11-27 15:14:48 --> Model "Kunjungan_model" initialized
INFO - 2025-11-27 15:14:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-27 15:14:48 --> Model "Nav_model" initialized
INFO - 2025-11-27 15:14:48 --> Controller Class Initialized
INFO - 2025-11-27 15:14:48 --> Model "Berita_model" initialized
INFO - 2025-11-27 15:14:48 --> Model "Kategori_model" initialized
INFO - 2025-11-27 15:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-27 15:14:48 --> Pagination Class Initialized
INFO - 2025-11-27 15:14:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2025-11-27 15:14:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-27 15:14:48 --> Model "Log_model" initialized
INFO - 2025-11-27 15:14:48 --> Final output sent to browser
DEBUG - 2025-11-27 15:14:48 --> Total execution time: 0.3149
INFO - 2025-11-27 09:14:54 --> Config Class Initialized
INFO - 2025-11-27 09:14:54 --> Hooks Class Initialized
DEBUG - 2025-11-27 09:14:54 --> UTF-8 Support Enabled
INFO - 2025-11-27 09:14:54 --> Utf8 Class Initialized
INFO - 2025-11-27 09:14:54 --> URI Class Initialized
INFO - 2025-11-27 09:14:54 --> Router Class Initialized
INFO - 2025-11-27 09:14:54 --> Output Class Initialized
INFO - 2025-11-27 09:14:54 --> Security Class Initialized
DEBUG - 2025-11-27 09:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-27 09:14:54 --> CSRF cookie sent
INFO - 2025-11-27 09:14:54 --> Input Class Initialized
INFO - 2025-11-27 09:14:54 --> Language Class Initialized
INFO - 2025-11-27 09:14:54 --> Loader Class Initialized
INFO - 2025-11-27 09:14:54 --> Helper loaded: url_helper
INFO - 2025-11-27 09:14:54 --> Helper loaded: text_helper
INFO - 2025-11-27 09:14:54 --> Helper loaded: string_helper
INFO - 2025-11-27 09:14:54 --> Helper loaded: form_helper
INFO - 2025-11-27 09:14:54 --> Helper loaded: download_helper
INFO - 2025-11-27 09:14:54 --> Helper loaded: security_helper
INFO - 2025-11-27 09:14:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-27 09:14:54 --> Database Driver Class Initialized
DEBUG - 2025-11-27 09:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-27 09:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-27 09:14:54 --> Form Validation Class Initialized
INFO - 2025-11-27 09:14:54 --> Model "User_model" initialized
INFO - 2025-11-27 15:14:54 --> Model "Kunjungan_model" initialized
INFO - 2025-11-27 15:14:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-27 15:14:54 --> Model "Nav_model" initialized
INFO - 2025-11-27 15:14:54 --> Controller Class Initialized
INFO - 2025-11-27 15:14:54 --> Model "Berita_model" initialized
INFO - 2025-11-27 15:14:54 --> Model "Kategori_model" initialized
INFO - 2025-11-27 15:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-27 15:14:54 --> Pagination Class Initialized
INFO - 2025-11-27 15:14:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2025-11-27 15:14:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-27 15:14:54 --> Model "Log_model" initialized
INFO - 2025-11-27 15:14:54 --> Final output sent to browser
DEBUG - 2025-11-27 15:14:54 --> Total execution time: 0.1131
INFO - 2025-11-27 09:14:59 --> Config Class Initialized
INFO - 2025-11-27 09:14:59 --> Hooks Class Initialized
DEBUG - 2025-11-27 09:14:59 --> UTF-8 Support Enabled
INFO - 2025-11-27 09:14:59 --> Utf8 Class Initialized
INFO - 2025-11-27 09:14:59 --> URI Class Initialized
INFO - 2025-11-27 09:14:59 --> Router Class Initialized
INFO - 2025-11-27 09:14:59 --> Output Class Initialized
INFO - 2025-11-27 09:14:59 --> Security Class Initialized
DEBUG - 2025-11-27 09:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-27 09:14:59 --> CSRF cookie sent
INFO - 2025-11-27 09:14:59 --> Input Class Initialized
INFO - 2025-11-27 09:14:59 --> Language Class Initialized
INFO - 2025-11-27 09:14:59 --> Loader Class Initialized
INFO - 2025-11-27 09:14:59 --> Helper loaded: url_helper
INFO - 2025-11-27 09:14:59 --> Helper loaded: text_helper
INFO - 2025-11-27 09:14:59 --> Helper loaded: string_helper
INFO - 2025-11-27 09:14:59 --> Helper loaded: form_helper
INFO - 2025-11-27 09:14:59 --> Helper loaded: download_helper
INFO - 2025-11-27 09:14:59 --> Helper loaded: security_helper
INFO - 2025-11-27 09:14:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-27 09:14:59 --> Database Driver Class Initialized
DEBUG - 2025-11-27 09:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-27 09:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-27 09:14:59 --> Form Validation Class Initialized
INFO - 2025-11-27 09:14:59 --> Model "User_model" initialized
INFO - 2025-11-27 15:14:59 --> Model "Kunjungan_model" initialized
INFO - 2025-11-27 15:14:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-27 15:14:59 --> Model "Nav_model" initialized
INFO - 2025-11-27 15:14:59 --> Controller Class Initialized
INFO - 2025-11-27 15:14:59 --> Model "Berita_model" initialized
INFO - 2025-11-27 15:14:59 --> Model "Kategori_model" initialized
INFO - 2025-11-27 15:14:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/read.php
INFO - 2025-11-27 15:14:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-27 15:14:59 --> Model "Log_model" initialized
INFO - 2025-11-27 15:14:59 --> Final output sent to browser
DEBUG - 2025-11-27 15:14:59 --> Total execution time: 0.1670
