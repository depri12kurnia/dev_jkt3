<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-09-25 03:26:34 --> Config Class Initialized
INFO - 2025-09-25 03:26:34 --> Hooks Class Initialized
DEBUG - 2025-09-25 03:26:34 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:26:34 --> Utf8 Class Initialized
INFO - 2025-09-25 03:26:34 --> URI Class Initialized
DEBUG - 2025-09-25 03:26:34 --> No URI present. Default controller set.
INFO - 2025-09-25 03:26:34 --> Router Class Initialized
INFO - 2025-09-25 03:26:34 --> Output Class Initialized
INFO - 2025-09-25 03:26:35 --> Security Class Initialized
DEBUG - 2025-09-25 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:26:35 --> CSRF cookie sent
INFO - 2025-09-25 03:26:35 --> Input Class Initialized
INFO - 2025-09-25 03:26:35 --> Language Class Initialized
INFO - 2025-09-25 03:26:35 --> Loader Class Initialized
INFO - 2025-09-25 03:26:35 --> Helper loaded: url_helper
INFO - 2025-09-25 03:26:35 --> Helper loaded: text_helper
INFO - 2025-09-25 03:26:35 --> Helper loaded: string_helper
INFO - 2025-09-25 03:26:35 --> Helper loaded: form_helper
INFO - 2025-09-25 03:26:35 --> Helper loaded: download_helper
INFO - 2025-09-25 03:26:35 --> Helper loaded: security_helper
INFO - 2025-09-25 03:26:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 03:26:36 --> Database Driver Class Initialized
DEBUG - 2025-09-25 03:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 03:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:26:36 --> Form Validation Class Initialized
INFO - 2025-09-25 03:26:36 --> Model "User_model" initialized
INFO - 2025-09-25 08:26:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 08:26:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:26:37 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:26:37 --> Controller Class Initialized
INFO - 2025-09-25 08:26:37 --> Model "Berita_model" initialized
INFO - 2025-09-25 08:26:37 --> Model "Galeri_model" initialized
INFO - 2025-09-25 08:26:37 --> Model "Video_model" initialized
INFO - 2025-09-25 08:26:37 --> Model "Agenda_model" initialized
INFO - 2025-09-25 08:26:37 --> Model "Tautan_model" initialized
INFO - 2025-09-25 08:26:37 --> Model "Mitra_model" initialized
INFO - 2025-09-25 08:26:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 08:26:38 --> Model "Prodi_model" initialized
INFO - 2025-09-25 08:26:38 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 08:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-25 08:26:38 --> Pagination Class Initialized
INFO - 2025-09-25 08:26:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-25 08:26:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 08:26:41 --> Model "Log_model" initialized
INFO - 2025-09-25 08:26:41 --> Final output sent to browser
DEBUG - 2025-09-25 08:26:41 --> Total execution time: 7.0231
INFO - 2025-09-25 03:26:41 --> Config Class Initialized
INFO - 2025-09-25 03:26:41 --> Hooks Class Initialized
INFO - 2025-09-25 03:26:41 --> Config Class Initialized
INFO - 2025-09-25 03:26:41 --> Hooks Class Initialized
DEBUG - 2025-09-25 03:26:41 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:26:41 --> Utf8 Class Initialized
INFO - 2025-09-25 03:26:41 --> Config Class Initialized
INFO - 2025-09-25 03:26:41 --> Hooks Class Initialized
INFO - 2025-09-25 03:26:41 --> Config Class Initialized
INFO - 2025-09-25 03:26:41 --> Hooks Class Initialized
INFO - 2025-09-25 03:26:41 --> URI Class Initialized
DEBUG - 2025-09-25 03:26:41 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:26:41 --> Utf8 Class Initialized
INFO - 2025-09-25 03:26:41 --> Router Class Initialized
DEBUG - 2025-09-25 03:26:41 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:26:41 --> Utf8 Class Initialized
INFO - 2025-09-25 03:26:41 --> URI Class Initialized
DEBUG - 2025-09-25 03:26:41 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:26:41 --> Utf8 Class Initialized
INFO - 2025-09-25 03:26:41 --> URI Class Initialized
INFO - 2025-09-25 03:26:41 --> URI Class Initialized
INFO - 2025-09-25 03:26:41 --> Router Class Initialized
INFO - 2025-09-25 03:26:41 --> Output Class Initialized
INFO - 2025-09-25 03:26:41 --> Router Class Initialized
INFO - 2025-09-25 03:26:41 --> Security Class Initialized
INFO - 2025-09-25 03:26:41 --> Router Class Initialized
INFO - 2025-09-25 03:26:41 --> Output Class Initialized
DEBUG - 2025-09-25 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:26:41 --> CSRF cookie sent
INFO - 2025-09-25 03:26:41 --> Input Class Initialized
INFO - 2025-09-25 03:26:41 --> Output Class Initialized
INFO - 2025-09-25 03:26:41 --> Output Class Initialized
INFO - 2025-09-25 03:26:41 --> Security Class Initialized
INFO - 2025-09-25 03:26:41 --> Language Class Initialized
INFO - 2025-09-25 03:26:41 --> Security Class Initialized
DEBUG - 2025-09-25 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:26:41 --> Security Class Initialized
INFO - 2025-09-25 03:26:41 --> CSRF cookie sent
INFO - 2025-09-25 03:26:41 --> Input Class Initialized
INFO - 2025-09-25 03:26:41 --> Loader Class Initialized
DEBUG - 2025-09-25 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:26:41 --> Language Class Initialized
INFO - 2025-09-25 03:26:41 --> CSRF cookie sent
DEBUG - 2025-09-25 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:26:41 --> Input Class Initialized
INFO - 2025-09-25 03:26:41 --> CSRF cookie sent
INFO - 2025-09-25 03:26:41 --> Input Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: url_helper
INFO - 2025-09-25 03:26:41 --> Language Class Initialized
INFO - 2025-09-25 03:26:41 --> Language Class Initialized
INFO - 2025-09-25 03:26:41 --> Loader Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: text_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: url_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: string_helper
INFO - 2025-09-25 03:26:41 --> Loader Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: text_helper
INFO - 2025-09-25 03:26:41 --> Loader Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: form_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: url_helper
INFO - 2025-09-25 03:26:41 --> Config Class Initialized
INFO - 2025-09-25 03:26:41 --> Hooks Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: string_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: download_helper
INFO - 2025-09-25 03:26:41 --> Config Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: text_helper
INFO - 2025-09-25 03:26:41 --> Hooks Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: url_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: security_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: string_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: form_helper
DEBUG - 2025-09-25 03:26:41 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:26:41 --> Utf8 Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: text_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: download_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: form_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: string_helper
DEBUG - 2025-09-25 03:26:41 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:26:41 --> Helper loaded: security_helper
INFO - 2025-09-25 03:26:41 --> URI Class Initialized
INFO - 2025-09-25 03:26:41 --> Utf8 Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: download_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: form_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: security_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: download_helper
INFO - 2025-09-25 03:26:41 --> URI Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: security_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 03:26:41 --> Router Class Initialized
INFO - 2025-09-25 03:26:41 --> Database Driver Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 03:26:41 --> Router Class Initialized
INFO - 2025-09-25 03:26:41 --> Output Class Initialized
INFO - 2025-09-25 03:26:41 --> Database Driver Class Initialized
INFO - 2025-09-25 03:26:41 --> Security Class Initialized
INFO - 2025-09-25 03:26:41 --> Output Class Initialized
DEBUG - 2025-09-25 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:26:41 --> CSRF cookie sent
INFO - 2025-09-25 03:26:41 --> Input Class Initialized
INFO - 2025-09-25 03:26:41 --> Language Class Initialized
DEBUG - 2025-09-25 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 03:26:41 --> Security Class Initialized
INFO - 2025-09-25 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:26:41 --> Database Driver Class Initialized
DEBUG - 2025-09-25 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:26:41 --> Loader Class Initialized
INFO - 2025-09-25 03:26:41 --> Form Validation Class Initialized
INFO - 2025-09-25 03:26:41 --> CSRF cookie sent
INFO - 2025-09-25 03:26:41 --> Input Class Initialized
INFO - 2025-09-25 03:26:41 --> Database Driver Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: url_helper
INFO - 2025-09-25 03:26:41 --> Model "User_model" initialized
INFO - 2025-09-25 03:26:41 --> Language Class Initialized
INFO - 2025-09-25 08:26:41 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: text_helper
INFO - 2025-09-25 03:26:41 --> Loader Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: string_helper
INFO - 2025-09-25 08:26:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:26:41 --> Controller Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: form_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: url_helper
INFO - 2025-09-25 08:26:41 --> Model "Berita_model" initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: download_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: security_helper
INFO - 2025-09-25 08:26:41 --> Model "Galeri_model" initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: text_helper
INFO - 2025-09-25 03:26:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 08:26:41 --> Model "Video_model" initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: string_helper
INFO - 2025-09-25 08:26:41 --> Model "Agenda_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Tautan_model" initialized
DEBUG - 2025-09-25 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 03:26:41 --> Helper loaded: form_helper
INFO - 2025-09-25 08:26:41 --> Model "Mitra_model" initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: download_helper
INFO - 2025-09-25 08:26:41 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: security_helper
INFO - 2025-09-25 03:26:41 --> Database Driver Class Initialized
INFO - 2025-09-25 03:26:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 08:26:41 --> Model "Prodi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Testimoni_model" initialized
DEBUG - 2025-09-25 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 03:26:41 --> Database Driver Class Initialized
DEBUG - 2025-09-25 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-25 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 08:26:41 --> Model "Log_model" initialized
INFO - 2025-09-25 08:26:41 --> Final output sent to browser
DEBUG - 2025-09-25 08:26:41 --> Total execution time: 0.0927
INFO - 2025-09-25 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:26:41 --> Form Validation Class Initialized
INFO - 2025-09-25 03:26:41 --> Model "User_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Kunjungan_model" initialized
DEBUG - 2025-09-25 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 08:26:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:26:41 --> Controller Class Initialized
INFO - 2025-09-25 08:26:41 --> Model "Berita_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Galeri_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Video_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Agenda_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Tautan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Mitra_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Prodi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 08:26:41 --> Model "Log_model" initialized
INFO - 2025-09-25 08:26:41 --> Final output sent to browser
DEBUG - 2025-09-25 08:26:41 --> Total execution time: 0.1112
INFO - 2025-09-25 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:26:41 --> Form Validation Class Initialized
INFO - 2025-09-25 03:26:41 --> Model "User_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:26:41 --> Controller Class Initialized
INFO - 2025-09-25 08:26:41 --> Model "Berita_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Galeri_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Video_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Agenda_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Tautan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Mitra_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Prodi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 08:26:41 --> Model "Log_model" initialized
INFO - 2025-09-25 08:26:41 --> Final output sent to browser
DEBUG - 2025-09-25 08:26:41 --> Total execution time: 0.1460
INFO - 2025-09-25 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:26:41 --> Form Validation Class Initialized
INFO - 2025-09-25 03:26:41 --> Model "User_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:26:41 --> Controller Class Initialized
INFO - 2025-09-25 08:26:41 --> Model "Berita_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Galeri_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Video_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Agenda_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Tautan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Mitra_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Prodi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 08:26:41 --> Model "Log_model" initialized
INFO - 2025-09-25 08:26:41 --> Final output sent to browser
DEBUG - 2025-09-25 08:26:41 --> Total execution time: 0.1790
INFO - 2025-09-25 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:26:41 --> Form Validation Class Initialized
INFO - 2025-09-25 03:26:41 --> Model "User_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:26:41 --> Controller Class Initialized
INFO - 2025-09-25 08:26:41 --> Model "Berita_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Galeri_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Video_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Agenda_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Tautan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Mitra_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Prodi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 08:26:41 --> Model "Log_model" initialized
INFO - 2025-09-25 08:26:41 --> Final output sent to browser
DEBUG - 2025-09-25 08:26:41 --> Total execution time: 0.1842
INFO - 2025-09-25 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:26:41 --> Form Validation Class Initialized
INFO - 2025-09-25 03:26:41 --> Model "User_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:26:41 --> Controller Class Initialized
INFO - 2025-09-25 08:26:41 --> Model "Berita_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Galeri_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Video_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Agenda_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Tautan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Mitra_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Prodi_model" initialized
INFO - 2025-09-25 08:26:41 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 08:26:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 08:26:41 --> Model "Log_model" initialized
INFO - 2025-09-25 08:26:41 --> Final output sent to browser
DEBUG - 2025-09-25 08:26:41 --> Total execution time: 0.2185
INFO - 2025-09-25 03:35:54 --> Config Class Initialized
INFO - 2025-09-25 03:35:54 --> Hooks Class Initialized
DEBUG - 2025-09-25 03:35:54 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:35:54 --> Utf8 Class Initialized
INFO - 2025-09-25 03:35:54 --> URI Class Initialized
INFO - 2025-09-25 03:35:54 --> Router Class Initialized
INFO - 2025-09-25 03:35:54 --> Output Class Initialized
INFO - 2025-09-25 03:35:54 --> Security Class Initialized
DEBUG - 2025-09-25 03:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:35:54 --> CSRF cookie sent
INFO - 2025-09-25 03:35:54 --> Input Class Initialized
INFO - 2025-09-25 03:35:54 --> Language Class Initialized
INFO - 2025-09-25 03:35:54 --> Loader Class Initialized
INFO - 2025-09-25 03:35:54 --> Helper loaded: url_helper
INFO - 2025-09-25 03:35:54 --> Helper loaded: text_helper
INFO - 2025-09-25 03:35:54 --> Helper loaded: string_helper
INFO - 2025-09-25 03:35:54 --> Helper loaded: form_helper
INFO - 2025-09-25 03:35:54 --> Helper loaded: download_helper
INFO - 2025-09-25 03:35:54 --> Helper loaded: security_helper
INFO - 2025-09-25 03:35:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 03:35:54 --> Database Driver Class Initialized
DEBUG - 2025-09-25 03:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 03:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:35:54 --> Form Validation Class Initialized
INFO - 2025-09-25 03:35:54 --> Model "User_model" initialized
INFO - 2025-09-25 08:35:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 08:35:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:35:54 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:35:54 --> Controller Class Initialized
DEBUG - 2025-09-25 08:35:54 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-25 08:35:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-25 08:35:54 --> Model "Log_model" initialized
INFO - 2025-09-25 08:35:54 --> Final output sent to browser
DEBUG - 2025-09-25 08:35:54 --> Total execution time: 0.0946
INFO - 2025-09-25 03:36:00 --> Config Class Initialized
INFO - 2025-09-25 03:36:00 --> Hooks Class Initialized
DEBUG - 2025-09-25 03:36:00 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:36:00 --> Utf8 Class Initialized
INFO - 2025-09-25 03:36:00 --> URI Class Initialized
INFO - 2025-09-25 03:36:00 --> Router Class Initialized
INFO - 2025-09-25 03:36:00 --> Output Class Initialized
INFO - 2025-09-25 03:36:00 --> Security Class Initialized
DEBUG - 2025-09-25 03:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:36:00 --> CSRF cookie sent
INFO - 2025-09-25 03:36:00 --> CSRF token verified
INFO - 2025-09-25 03:36:00 --> Input Class Initialized
INFO - 2025-09-25 03:36:00 --> Language Class Initialized
INFO - 2025-09-25 03:36:00 --> Loader Class Initialized
INFO - 2025-09-25 03:36:00 --> Helper loaded: url_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: text_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: string_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: form_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: download_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: security_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 03:36:00 --> Database Driver Class Initialized
DEBUG - 2025-09-25 03:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 03:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:36:00 --> Form Validation Class Initialized
INFO - 2025-09-25 03:36:00 --> Model "User_model" initialized
INFO - 2025-09-25 08:36:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 08:36:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:36:00 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:36:00 --> Controller Class Initialized
DEBUG - 2025-09-25 08:36:00 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-25 08:36:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-25 03:36:00 --> Config Class Initialized
INFO - 2025-09-25 03:36:00 --> Hooks Class Initialized
DEBUG - 2025-09-25 03:36:00 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:36:00 --> Utf8 Class Initialized
INFO - 2025-09-25 03:36:00 --> URI Class Initialized
INFO - 2025-09-25 03:36:00 --> Router Class Initialized
INFO - 2025-09-25 03:36:00 --> Output Class Initialized
INFO - 2025-09-25 03:36:00 --> Security Class Initialized
DEBUG - 2025-09-25 03:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:36:00 --> CSRF cookie sent
INFO - 2025-09-25 03:36:00 --> Input Class Initialized
INFO - 2025-09-25 03:36:00 --> Language Class Initialized
INFO - 2025-09-25 03:36:00 --> Loader Class Initialized
INFO - 2025-09-25 03:36:00 --> Helper loaded: url_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: text_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: string_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: form_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: download_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: security_helper
INFO - 2025-09-25 03:36:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 03:36:00 --> Database Driver Class Initialized
DEBUG - 2025-09-25 03:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 03:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:36:00 --> Form Validation Class Initialized
INFO - 2025-09-25 03:36:00 --> Model "User_model" initialized
INFO - 2025-09-25 08:36:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 08:36:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:36:00 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:36:00 --> Controller Class Initialized
INFO - 2025-09-25 08:36:00 --> Model "Tautan_model" initialized
INFO - 2025-09-25 08:36:00 --> Model "Staff_model" initialized
INFO - 2025-09-25 08:36:00 --> Model "Dasbor_model" initialized
INFO - 2025-09-25 08:36:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-09-25 08:36:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-25 08:36:01 --> Model "Log_model" initialized
INFO - 2025-09-25 08:36:01 --> Final output sent to browser
DEBUG - 2025-09-25 08:36:01 --> Total execution time: 1.4664
INFO - 2025-09-25 03:36:05 --> Config Class Initialized
INFO - 2025-09-25 03:36:05 --> Hooks Class Initialized
DEBUG - 2025-09-25 03:36:05 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:36:05 --> Utf8 Class Initialized
INFO - 2025-09-25 03:36:05 --> URI Class Initialized
INFO - 2025-09-25 03:36:05 --> Router Class Initialized
INFO - 2025-09-25 03:36:05 --> Output Class Initialized
INFO - 2025-09-25 03:36:05 --> Security Class Initialized
DEBUG - 2025-09-25 03:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:36:05 --> CSRF cookie sent
INFO - 2025-09-25 03:36:05 --> Input Class Initialized
INFO - 2025-09-25 03:36:05 --> Language Class Initialized
INFO - 2025-09-25 03:36:06 --> Loader Class Initialized
INFO - 2025-09-25 03:36:06 --> Helper loaded: url_helper
INFO - 2025-09-25 03:36:06 --> Helper loaded: text_helper
INFO - 2025-09-25 03:36:06 --> Helper loaded: string_helper
INFO - 2025-09-25 03:36:06 --> Helper loaded: form_helper
INFO - 2025-09-25 03:36:06 --> Helper loaded: download_helper
INFO - 2025-09-25 03:36:06 --> Helper loaded: security_helper
INFO - 2025-09-25 03:36:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 03:36:06 --> Database Driver Class Initialized
DEBUG - 2025-09-25 03:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 03:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:36:06 --> Form Validation Class Initialized
INFO - 2025-09-25 03:36:06 --> Model "User_model" initialized
INFO - 2025-09-25 08:36:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 08:36:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:36:06 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:36:06 --> Controller Class Initialized
INFO - 2025-09-25 08:36:06 --> Model "Agenda_model" initialized
INFO - 2025-09-25 08:36:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/agenda/list.php
INFO - 2025-09-25 08:36:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-25 08:36:06 --> Model "Log_model" initialized
INFO - 2025-09-25 08:36:06 --> Final output sent to browser
DEBUG - 2025-09-25 08:36:06 --> Total execution time: 0.1552
INFO - 2025-09-25 03:36:08 --> Config Class Initialized
INFO - 2025-09-25 03:36:08 --> Hooks Class Initialized
DEBUG - 2025-09-25 03:36:08 --> UTF-8 Support Enabled
INFO - 2025-09-25 03:36:08 --> Utf8 Class Initialized
INFO - 2025-09-25 03:36:08 --> URI Class Initialized
INFO - 2025-09-25 03:36:08 --> Router Class Initialized
INFO - 2025-09-25 03:36:08 --> Output Class Initialized
INFO - 2025-09-25 03:36:08 --> Security Class Initialized
DEBUG - 2025-09-25 03:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 03:36:08 --> CSRF cookie sent
INFO - 2025-09-25 03:36:08 --> Input Class Initialized
INFO - 2025-09-25 03:36:08 --> Language Class Initialized
INFO - 2025-09-25 03:36:08 --> Loader Class Initialized
INFO - 2025-09-25 03:36:08 --> Helper loaded: url_helper
INFO - 2025-09-25 03:36:08 --> Helper loaded: text_helper
INFO - 2025-09-25 03:36:08 --> Helper loaded: string_helper
INFO - 2025-09-25 03:36:08 --> Helper loaded: form_helper
INFO - 2025-09-25 03:36:08 --> Helper loaded: download_helper
INFO - 2025-09-25 03:36:08 --> Helper loaded: security_helper
INFO - 2025-09-25 03:36:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 03:36:08 --> Database Driver Class Initialized
DEBUG - 2025-09-25 03:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 03:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 03:36:08 --> Form Validation Class Initialized
INFO - 2025-09-25 03:36:08 --> Model "User_model" initialized
INFO - 2025-09-25 08:36:08 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 08:36:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 08:36:08 --> Model "Nav_model" initialized
INFO - 2025-09-25 08:36:08 --> Controller Class Initialized
INFO - 2025-09-25 08:36:08 --> Model "Agenda_model" initialized
INFO - 2025-09-25 08:36:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/agenda/edit.php
INFO - 2025-09-25 08:36:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-25 08:36:08 --> Model "Log_model" initialized
INFO - 2025-09-25 08:36:08 --> Final output sent to browser
DEBUG - 2025-09-25 08:36:08 --> Total execution time: 0.0800
INFO - 2025-09-25 05:37:32 --> Config Class Initialized
INFO - 2025-09-25 05:37:32 --> Hooks Class Initialized
DEBUG - 2025-09-25 05:37:33 --> UTF-8 Support Enabled
INFO - 2025-09-25 05:37:33 --> Utf8 Class Initialized
INFO - 2025-09-25 05:37:33 --> URI Class Initialized
DEBUG - 2025-09-25 05:37:33 --> No URI present. Default controller set.
INFO - 2025-09-25 05:37:33 --> Router Class Initialized
INFO - 2025-09-25 05:37:33 --> Output Class Initialized
INFO - 2025-09-25 05:37:33 --> Security Class Initialized
DEBUG - 2025-09-25 05:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 05:37:33 --> CSRF cookie sent
INFO - 2025-09-25 05:37:33 --> Input Class Initialized
INFO - 2025-09-25 05:37:33 --> Language Class Initialized
INFO - 2025-09-25 05:37:34 --> Loader Class Initialized
INFO - 2025-09-25 05:37:34 --> Helper loaded: url_helper
INFO - 2025-09-25 05:37:34 --> Helper loaded: text_helper
INFO - 2025-09-25 05:37:34 --> Helper loaded: string_helper
INFO - 2025-09-25 05:37:34 --> Helper loaded: form_helper
INFO - 2025-09-25 05:37:34 --> Helper loaded: download_helper
INFO - 2025-09-25 05:37:34 --> Helper loaded: security_helper
INFO - 2025-09-25 05:37:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 05:37:35 --> Database Driver Class Initialized
DEBUG - 2025-09-25 05:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 05:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 05:37:35 --> Form Validation Class Initialized
INFO - 2025-09-25 05:37:35 --> Model "User_model" initialized
INFO - 2025-09-25 10:37:36 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 10:37:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 10:37:36 --> Model "Nav_model" initialized
INFO - 2025-09-25 10:37:36 --> Controller Class Initialized
INFO - 2025-09-25 10:37:36 --> Model "Berita_model" initialized
INFO - 2025-09-25 10:37:36 --> Model "Galeri_model" initialized
INFO - 2025-09-25 10:37:36 --> Model "Video_model" initialized
INFO - 2025-09-25 10:37:36 --> Model "Agenda_model" initialized
INFO - 2025-09-25 10:37:36 --> Model "Tautan_model" initialized
INFO - 2025-09-25 10:37:36 --> Model "Mitra_model" initialized
INFO - 2025-09-25 10:37:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 10:37:37 --> Model "Prodi_model" initialized
INFO - 2025-09-25 10:37:37 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 10:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-25 10:37:37 --> Pagination Class Initialized
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 10:37:39 --> Model "Log_model" initialized
INFO - 2025-09-25 10:37:39 --> Final output sent to browser
DEBUG - 2025-09-25 10:37:39 --> Total execution time: 6.9901
INFO - 2025-09-25 05:37:39 --> Config Class Initialized
INFO - 2025-09-25 05:37:39 --> Config Class Initialized
INFO - 2025-09-25 05:37:39 --> Hooks Class Initialized
INFO - 2025-09-25 05:37:39 --> Hooks Class Initialized
INFO - 2025-09-25 05:37:39 --> Config Class Initialized
INFO - 2025-09-25 05:37:39 --> Hooks Class Initialized
INFO - 2025-09-25 05:37:39 --> Config Class Initialized
INFO - 2025-09-25 05:37:39 --> Config Class Initialized
INFO - 2025-09-25 05:37:39 --> Config Class Initialized
INFO - 2025-09-25 05:37:39 --> Hooks Class Initialized
INFO - 2025-09-25 05:37:39 --> Hooks Class Initialized
INFO - 2025-09-25 05:37:39 --> Hooks Class Initialized
DEBUG - 2025-09-25 05:37:39 --> UTF-8 Support Enabled
INFO - 2025-09-25 05:37:39 --> Utf8 Class Initialized
DEBUG - 2025-09-25 05:37:39 --> UTF-8 Support Enabled
INFO - 2025-09-25 05:37:39 --> Utf8 Class Initialized
INFO - 2025-09-25 05:37:39 --> URI Class Initialized
INFO - 2025-09-25 05:37:39 --> URI Class Initialized
INFO - 2025-09-25 05:37:39 --> Router Class Initialized
DEBUG - 2025-09-25 05:37:39 --> UTF-8 Support Enabled
DEBUG - 2025-09-25 05:37:39 --> UTF-8 Support Enabled
INFO - 2025-09-25 05:37:39 --> Utf8 Class Initialized
DEBUG - 2025-09-25 05:37:39 --> UTF-8 Support Enabled
INFO - 2025-09-25 05:37:39 --> Utf8 Class Initialized
INFO - 2025-09-25 05:37:39 --> Router Class Initialized
INFO - 2025-09-25 05:37:39 --> Utf8 Class Initialized
DEBUG - 2025-09-25 05:37:39 --> UTF-8 Support Enabled
INFO - 2025-09-25 05:37:39 --> Utf8 Class Initialized
INFO - 2025-09-25 05:37:39 --> Output Class Initialized
INFO - 2025-09-25 05:37:39 --> URI Class Initialized
INFO - 2025-09-25 05:37:39 --> URI Class Initialized
INFO - 2025-09-25 05:37:39 --> URI Class Initialized
INFO - 2025-09-25 05:37:39 --> Output Class Initialized
INFO - 2025-09-25 05:37:39 --> URI Class Initialized
INFO - 2025-09-25 05:37:39 --> Router Class Initialized
INFO - 2025-09-25 05:37:39 --> Security Class Initialized
INFO - 2025-09-25 05:37:39 --> Router Class Initialized
INFO - 2025-09-25 05:37:39 --> Security Class Initialized
INFO - 2025-09-25 05:37:39 --> Router Class Initialized
INFO - 2025-09-25 05:37:39 --> Router Class Initialized
DEBUG - 2025-09-25 05:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 05:37:39 --> CSRF cookie sent
INFO - 2025-09-25 05:37:39 --> Output Class Initialized
INFO - 2025-09-25 05:37:39 --> Input Class Initialized
INFO - 2025-09-25 05:37:39 --> Output Class Initialized
DEBUG - 2025-09-25 05:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 05:37:39 --> CSRF cookie sent
INFO - 2025-09-25 05:37:39 --> Language Class Initialized
INFO - 2025-09-25 05:37:39 --> Input Class Initialized
INFO - 2025-09-25 05:37:39 --> Security Class Initialized
INFO - 2025-09-25 05:37:39 --> Output Class Initialized
INFO - 2025-09-25 05:37:39 --> Output Class Initialized
INFO - 2025-09-25 05:37:39 --> Security Class Initialized
INFO - 2025-09-25 05:37:39 --> Language Class Initialized
DEBUG - 2025-09-25 05:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 05:37:39 --> Security Class Initialized
INFO - 2025-09-25 05:37:39 --> CSRF cookie sent
DEBUG - 2025-09-25 05:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 05:37:39 --> Security Class Initialized
INFO - 2025-09-25 05:37:39 --> Loader Class Initialized
INFO - 2025-09-25 05:37:39 --> Input Class Initialized
INFO - 2025-09-25 05:37:39 --> CSRF cookie sent
INFO - 2025-09-25 05:37:39 --> Input Class Initialized
INFO - 2025-09-25 05:37:39 --> Loader Class Initialized
DEBUG - 2025-09-25 05:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 05:37:39 --> Language Class Initialized
DEBUG - 2025-09-25 05:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 05:37:39 --> Helper loaded: url_helper
INFO - 2025-09-25 05:37:39 --> Language Class Initialized
INFO - 2025-09-25 05:37:39 --> CSRF cookie sent
INFO - 2025-09-25 05:37:39 --> Helper loaded: url_helper
INFO - 2025-09-25 05:37:39 --> CSRF cookie sent
INFO - 2025-09-25 05:37:39 --> Input Class Initialized
INFO - 2025-09-25 05:37:39 --> Input Class Initialized
INFO - 2025-09-25 05:37:39 --> Helper loaded: text_helper
INFO - 2025-09-25 05:37:39 --> Language Class Initialized
INFO - 2025-09-25 05:37:39 --> Helper loaded: text_helper
INFO - 2025-09-25 05:37:39 --> Language Class Initialized
INFO - 2025-09-25 05:37:39 --> Loader Class Initialized
INFO - 2025-09-25 05:37:39 --> Helper loaded: string_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: string_helper
INFO - 2025-09-25 05:37:39 --> Loader Class Initialized
INFO - 2025-09-25 05:37:39 --> Helper loaded: url_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: form_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: form_helper
INFO - 2025-09-25 05:37:39 --> Loader Class Initialized
INFO - 2025-09-25 05:37:39 --> Helper loaded: download_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: url_helper
INFO - 2025-09-25 05:37:39 --> Loader Class Initialized
INFO - 2025-09-25 05:37:39 --> Helper loaded: text_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: download_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: url_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: security_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: string_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: security_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: text_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: text_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: url_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: string_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: string_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: form_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: text_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: form_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: download_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: string_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: form_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: download_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: security_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: download_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: security_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: form_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: security_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: download_helper
INFO - 2025-09-25 05:37:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 05:37:39 --> Database Driver Class Initialized
INFO - 2025-09-25 05:37:39 --> Helper loaded: security_helper
INFO - 2025-09-25 05:37:39 --> Database Driver Class Initialized
INFO - 2025-09-25 05:37:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 05:37:39 --> Database Driver Class Initialized
DEBUG - 2025-09-25 05:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-25 05:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 05:37:39 --> Database Driver Class Initialized
INFO - 2025-09-25 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 05:37:39 --> Database Driver Class Initialized
INFO - 2025-09-25 05:37:39 --> Database Driver Class Initialized
INFO - 2025-09-25 05:37:39 --> Form Validation Class Initialized
DEBUG - 2025-09-25 05:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-25 05:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 05:37:39 --> Model "User_model" initialized
DEBUG - 2025-09-25 05:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 10:37:39 --> Model "Kunjungan_model" initialized
DEBUG - 2025-09-25 05:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 10:37:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Nav_model" initialized
INFO - 2025-09-25 10:37:39 --> Controller Class Initialized
INFO - 2025-09-25 10:37:39 --> Model "Berita_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Galeri_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Video_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Agenda_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Tautan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Mitra_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Prodi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 10:37:39 --> Model "Log_model" initialized
INFO - 2025-09-25 10:37:39 --> Final output sent to browser
DEBUG - 2025-09-25 10:37:39 --> Total execution time: 0.0803
INFO - 2025-09-25 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 05:37:39 --> Form Validation Class Initialized
INFO - 2025-09-25 05:37:39 --> Model "User_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Nav_model" initialized
INFO - 2025-09-25 10:37:39 --> Controller Class Initialized
INFO - 2025-09-25 10:37:39 --> Model "Berita_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Galeri_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Video_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Agenda_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Tautan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Mitra_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Prodi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 10:37:39 --> Model "Log_model" initialized
INFO - 2025-09-25 10:37:39 --> Final output sent to browser
DEBUG - 2025-09-25 10:37:39 --> Total execution time: 0.1079
INFO - 2025-09-25 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 05:37:39 --> Form Validation Class Initialized
INFO - 2025-09-25 05:37:39 --> Model "User_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Nav_model" initialized
INFO - 2025-09-25 10:37:39 --> Controller Class Initialized
INFO - 2025-09-25 10:37:39 --> Model "Berita_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Galeri_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Video_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Agenda_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Tautan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Mitra_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Prodi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 10:37:39 --> Model "Log_model" initialized
INFO - 2025-09-25 10:37:39 --> Final output sent to browser
DEBUG - 2025-09-25 10:37:39 --> Total execution time: 0.1346
INFO - 2025-09-25 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 05:37:39 --> Form Validation Class Initialized
INFO - 2025-09-25 05:37:39 --> Model "User_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Nav_model" initialized
INFO - 2025-09-25 10:37:39 --> Controller Class Initialized
INFO - 2025-09-25 10:37:39 --> Model "Berita_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Galeri_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Video_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Agenda_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Tautan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Mitra_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Prodi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 10:37:39 --> Model "Log_model" initialized
INFO - 2025-09-25 10:37:39 --> Final output sent to browser
DEBUG - 2025-09-25 10:37:39 --> Total execution time: 0.1601
INFO - 2025-09-25 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 05:37:39 --> Form Validation Class Initialized
INFO - 2025-09-25 05:37:39 --> Model "User_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Nav_model" initialized
INFO - 2025-09-25 10:37:39 --> Controller Class Initialized
INFO - 2025-09-25 10:37:39 --> Model "Berita_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Galeri_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Video_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Agenda_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Tautan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Mitra_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Prodi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 10:37:39 --> Model "Log_model" initialized
INFO - 2025-09-25 10:37:39 --> Final output sent to browser
DEBUG - 2025-09-25 10:37:39 --> Total execution time: 0.1883
INFO - 2025-09-25 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 05:37:39 --> Form Validation Class Initialized
INFO - 2025-09-25 05:37:39 --> Model "User_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Nav_model" initialized
INFO - 2025-09-25 10:37:39 --> Controller Class Initialized
INFO - 2025-09-25 10:37:39 --> Model "Berita_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Galeri_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Video_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Agenda_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Tautan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Mitra_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Prodi_model" initialized
INFO - 2025-09-25 10:37:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-25 10:37:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 10:37:39 --> Model "Log_model" initialized
INFO - 2025-09-25 10:37:39 --> Final output sent to browser
DEBUG - 2025-09-25 10:37:39 --> Total execution time: 0.2150
INFO - 2025-09-25 10:24:49 --> Config Class Initialized
INFO - 2025-09-25 10:24:49 --> Hooks Class Initialized
DEBUG - 2025-09-25 10:24:50 --> UTF-8 Support Enabled
INFO - 2025-09-25 10:24:50 --> Utf8 Class Initialized
INFO - 2025-09-25 10:24:50 --> URI Class Initialized
INFO - 2025-09-25 10:24:50 --> Router Class Initialized
INFO - 2025-09-25 10:24:50 --> Output Class Initialized
INFO - 2025-09-25 10:24:50 --> Security Class Initialized
DEBUG - 2025-09-25 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-25 10:24:50 --> CSRF cookie sent
INFO - 2025-09-25 10:24:50 --> Input Class Initialized
INFO - 2025-09-25 10:24:50 --> Language Class Initialized
INFO - 2025-09-25 10:24:51 --> Loader Class Initialized
INFO - 2025-09-25 10:24:51 --> Helper loaded: url_helper
INFO - 2025-09-25 10:24:51 --> Helper loaded: text_helper
INFO - 2025-09-25 10:24:51 --> Helper loaded: string_helper
INFO - 2025-09-25 10:24:51 --> Helper loaded: form_helper
INFO - 2025-09-25 10:24:51 --> Helper loaded: download_helper
INFO - 2025-09-25 10:24:51 --> Helper loaded: security_helper
INFO - 2025-09-25 10:24:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-25 10:24:52 --> Database Driver Class Initialized
DEBUG - 2025-09-25 10:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-25 10:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-25 10:24:52 --> Form Validation Class Initialized
INFO - 2025-09-25 10:24:53 --> Model "User_model" initialized
INFO - 2025-09-25 15:24:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-25 15:24:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-25 15:24:53 --> Model "Nav_model" initialized
INFO - 2025-09-25 15:24:53 --> Controller Class Initialized
INFO - 2025-09-25 15:24:53 --> Model "Download_model" initialized
INFO - 2025-09-25 15:24:53 --> Model "Kategori_download_model" initialized
INFO - 2025-09-25 15:24:53 --> Model "Jenis_download_model" initialized
INFO - 2025-09-25 15:24:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2025-09-25 15:24:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-25 15:24:54 --> Model "Log_model" initialized
INFO - 2025-09-25 15:24:54 --> Final output sent to browser
DEBUG - 2025-09-25 15:24:54 --> Total execution time: 5.3883
