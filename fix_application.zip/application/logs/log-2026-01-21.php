<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-21 02:41:21 --> Config Class Initialized
INFO - 2026-01-21 02:41:21 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:41:21 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:41:21 --> Utf8 Class Initialized
INFO - 2026-01-21 02:41:21 --> URI Class Initialized
DEBUG - 2026-01-21 02:41:21 --> No URI present. Default controller set.
INFO - 2026-01-21 02:41:21 --> Router Class Initialized
INFO - 2026-01-21 02:41:22 --> Output Class Initialized
INFO - 2026-01-21 02:41:22 --> Security Class Initialized
DEBUG - 2026-01-21 02:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:41:22 --> CSRF cookie sent
INFO - 2026-01-21 02:41:22 --> Input Class Initialized
INFO - 2026-01-21 02:41:22 --> Language Class Initialized
INFO - 2026-01-21 02:41:22 --> Loader Class Initialized
INFO - 2026-01-21 02:41:22 --> Helper loaded: url_helper
INFO - 2026-01-21 02:41:22 --> Helper loaded: text_helper
INFO - 2026-01-21 02:41:22 --> Helper loaded: string_helper
INFO - 2026-01-21 02:41:22 --> Helper loaded: form_helper
INFO - 2026-01-21 02:41:22 --> Helper loaded: download_helper
INFO - 2026-01-21 02:41:23 --> Helper loaded: security_helper
INFO - 2026-01-21 02:41:23 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:41:23 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:41:23 --> Form Validation Class Initialized
INFO - 2026-01-21 02:41:23 --> Model "User_model" initialized
INFO - 2026-01-21 08:41:23 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:41:24 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:41:24 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:41:24 --> Controller Class Initialized
INFO - 2026-01-21 08:41:24 --> Model "Berita_model" initialized
INFO - 2026-01-21 08:41:24 --> Model "Galeri_model" initialized
INFO - 2026-01-21 08:41:24 --> Model "Video_model" initialized
INFO - 2026-01-21 08:41:25 --> Model "Agenda_model" initialized
INFO - 2026-01-21 08:41:25 --> Model "Tautan_model" initialized
INFO - 2026-01-21 08:41:25 --> Model "Mitra_model" initialized
INFO - 2026-01-21 08:41:25 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 08:41:25 --> Model "Prodi_model" initialized
INFO - 2026-01-21 08:41:25 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 08:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 08:41:26 --> Pagination Class Initialized
INFO - 2026-01-21 08:41:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 08:41:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:41:29 --> Model "Log_model" initialized
INFO - 2026-01-21 08:41:29 --> Final output sent to browser
DEBUG - 2026-01-21 08:41:29 --> Total execution time: 8.7142
INFO - 2026-01-21 02:41:55 --> Config Class Initialized
INFO - 2026-01-21 02:41:55 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:41:55 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:41:55 --> Utf8 Class Initialized
INFO - 2026-01-21 02:41:55 --> URI Class Initialized
INFO - 2026-01-21 02:41:55 --> Router Class Initialized
INFO - 2026-01-21 02:41:55 --> Output Class Initialized
INFO - 2026-01-21 02:41:55 --> Security Class Initialized
DEBUG - 2026-01-21 02:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:41:55 --> CSRF cookie sent
INFO - 2026-01-21 02:41:55 --> Input Class Initialized
INFO - 2026-01-21 02:41:55 --> Language Class Initialized
INFO - 2026-01-21 02:41:55 --> Loader Class Initialized
INFO - 2026-01-21 02:41:55 --> Helper loaded: url_helper
INFO - 2026-01-21 02:41:55 --> Helper loaded: text_helper
INFO - 2026-01-21 02:41:55 --> Helper loaded: string_helper
INFO - 2026-01-21 02:41:55 --> Helper loaded: form_helper
INFO - 2026-01-21 02:41:55 --> Helper loaded: download_helper
INFO - 2026-01-21 02:41:55 --> Helper loaded: security_helper
INFO - 2026-01-21 02:41:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:41:55 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:41:55 --> Form Validation Class Initialized
INFO - 2026-01-21 02:41:55 --> Model "User_model" initialized
INFO - 2026-01-21 08:41:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:41:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:41:55 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:41:55 --> Controller Class Initialized
INFO - 2026-01-21 08:41:55 --> Model "Sdm_model" initialized
INFO - 2026-01-21 08:41:55 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-21 08:41:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-21 08:41:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:41:56 --> Model "Log_model" initialized
INFO - 2026-01-21 08:41:56 --> Final output sent to browser
DEBUG - 2026-01-21 08:41:56 --> Total execution time: 0.8003
INFO - 2026-01-21 02:42:03 --> Config Class Initialized
INFO - 2026-01-21 02:42:03 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:42:03 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:42:03 --> Utf8 Class Initialized
INFO - 2026-01-21 02:42:03 --> URI Class Initialized
INFO - 2026-01-21 02:42:03 --> Router Class Initialized
INFO - 2026-01-21 02:42:03 --> Output Class Initialized
INFO - 2026-01-21 02:42:03 --> Security Class Initialized
DEBUG - 2026-01-21 02:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:42:03 --> CSRF cookie sent
INFO - 2026-01-21 02:42:03 --> Input Class Initialized
INFO - 2026-01-21 02:42:03 --> Language Class Initialized
INFO - 2026-01-21 02:42:03 --> Loader Class Initialized
INFO - 2026-01-21 02:42:03 --> Helper loaded: url_helper
INFO - 2026-01-21 02:42:03 --> Helper loaded: text_helper
INFO - 2026-01-21 02:42:03 --> Helper loaded: string_helper
INFO - 2026-01-21 02:42:03 --> Helper loaded: form_helper
INFO - 2026-01-21 02:42:03 --> Helper loaded: download_helper
INFO - 2026-01-21 02:42:03 --> Helper loaded: security_helper
INFO - 2026-01-21 02:42:03 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:42:03 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:42:03 --> Form Validation Class Initialized
INFO - 2026-01-21 02:42:03 --> Model "User_model" initialized
INFO - 2026-01-21 08:42:03 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:42:03 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:42:03 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:42:03 --> Controller Class Initialized
INFO - 2026-01-21 08:42:03 --> Model "Sdm_model" initialized
INFO - 2026-01-21 08:42:03 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-21 08:42:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2026-01-21 08:42:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:42:03 --> Model "Log_model" initialized
INFO - 2026-01-21 08:42:04 --> Final output sent to browser
DEBUG - 2026-01-21 08:42:04 --> Total execution time: 0.1753
INFO - 2026-01-21 02:42:08 --> Config Class Initialized
INFO - 2026-01-21 02:42:08 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:42:08 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:42:08 --> Utf8 Class Initialized
INFO - 2026-01-21 02:42:08 --> URI Class Initialized
INFO - 2026-01-21 02:42:08 --> Router Class Initialized
INFO - 2026-01-21 02:42:08 --> Output Class Initialized
INFO - 2026-01-21 02:42:08 --> Security Class Initialized
DEBUG - 2026-01-21 02:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:42:08 --> CSRF cookie sent
INFO - 2026-01-21 02:42:08 --> Input Class Initialized
INFO - 2026-01-21 02:42:08 --> Language Class Initialized
INFO - 2026-01-21 02:42:08 --> Loader Class Initialized
INFO - 2026-01-21 02:42:08 --> Helper loaded: url_helper
INFO - 2026-01-21 02:42:08 --> Helper loaded: text_helper
INFO - 2026-01-21 02:42:08 --> Helper loaded: string_helper
INFO - 2026-01-21 02:42:08 --> Helper loaded: form_helper
INFO - 2026-01-21 02:42:08 --> Helper loaded: download_helper
INFO - 2026-01-21 02:42:08 --> Helper loaded: security_helper
INFO - 2026-01-21 02:42:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:42:08 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:42:08 --> Form Validation Class Initialized
INFO - 2026-01-21 02:42:08 --> Model "User_model" initialized
INFO - 2026-01-21 08:42:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:42:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:42:08 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:42:08 --> Controller Class Initialized
INFO - 2026-01-21 08:42:08 --> Model "Sdm_model" initialized
INFO - 2026-01-21 08:42:08 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-21 08:42:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-21 08:42:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:42:08 --> Model "Log_model" initialized
INFO - 2026-01-21 08:42:08 --> Final output sent to browser
DEBUG - 2026-01-21 08:42:08 --> Total execution time: 0.1296
INFO - 2026-01-21 02:43:13 --> Config Class Initialized
INFO - 2026-01-21 02:43:13 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:43:13 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:43:13 --> Utf8 Class Initialized
INFO - 2026-01-21 02:43:13 --> URI Class Initialized
INFO - 2026-01-21 02:43:13 --> Router Class Initialized
INFO - 2026-01-21 02:43:13 --> Output Class Initialized
INFO - 2026-01-21 02:43:13 --> Security Class Initialized
DEBUG - 2026-01-21 02:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:43:13 --> CSRF cookie sent
INFO - 2026-01-21 02:43:13 --> Input Class Initialized
INFO - 2026-01-21 02:43:13 --> Language Class Initialized
INFO - 2026-01-21 02:43:13 --> Loader Class Initialized
INFO - 2026-01-21 02:43:13 --> Helper loaded: url_helper
INFO - 2026-01-21 02:43:13 --> Helper loaded: text_helper
INFO - 2026-01-21 02:43:13 --> Helper loaded: string_helper
INFO - 2026-01-21 02:43:13 --> Helper loaded: form_helper
INFO - 2026-01-21 02:43:13 --> Helper loaded: download_helper
INFO - 2026-01-21 02:43:13 --> Helper loaded: security_helper
INFO - 2026-01-21 02:43:13 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:43:13 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:43:13 --> Form Validation Class Initialized
INFO - 2026-01-21 02:43:13 --> Model "User_model" initialized
INFO - 2026-01-21 08:43:13 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:43:13 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:43:13 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:43:13 --> Controller Class Initialized
INFO - 2026-01-21 08:43:13 --> Model "Sdm_model" initialized
INFO - 2026-01-21 08:43:13 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-21 08:43:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-21 08:43:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:43:13 --> Model "Log_model" initialized
INFO - 2026-01-21 08:43:13 --> Final output sent to browser
DEBUG - 2026-01-21 08:43:13 --> Total execution time: 0.4062
INFO - 2026-01-21 02:43:27 --> Config Class Initialized
INFO - 2026-01-21 02:43:27 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:43:27 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:43:27 --> Utf8 Class Initialized
INFO - 2026-01-21 02:43:27 --> URI Class Initialized
INFO - 2026-01-21 02:43:27 --> Router Class Initialized
INFO - 2026-01-21 02:43:27 --> Output Class Initialized
INFO - 2026-01-21 02:43:27 --> Security Class Initialized
DEBUG - 2026-01-21 02:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:43:27 --> CSRF cookie sent
INFO - 2026-01-21 02:43:27 --> Input Class Initialized
INFO - 2026-01-21 02:43:27 --> Language Class Initialized
INFO - 2026-01-21 02:43:27 --> Loader Class Initialized
INFO - 2026-01-21 02:43:27 --> Helper loaded: url_helper
INFO - 2026-01-21 02:43:27 --> Helper loaded: text_helper
INFO - 2026-01-21 02:43:27 --> Helper loaded: string_helper
INFO - 2026-01-21 02:43:27 --> Helper loaded: form_helper
INFO - 2026-01-21 02:43:27 --> Helper loaded: download_helper
INFO - 2026-01-21 02:43:27 --> Helper loaded: security_helper
INFO - 2026-01-21 02:43:27 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:43:27 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:43:27 --> Form Validation Class Initialized
INFO - 2026-01-21 02:43:27 --> Model "User_model" initialized
INFO - 2026-01-21 08:43:27 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:43:27 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:43:27 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:43:27 --> Controller Class Initialized
INFO - 2026-01-21 08:43:27 --> Model "Sdm_model" initialized
INFO - 2026-01-21 08:43:27 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-21 08:43:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-21 08:43:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:43:28 --> Model "Log_model" initialized
INFO - 2026-01-21 08:43:28 --> Final output sent to browser
DEBUG - 2026-01-21 08:43:28 --> Total execution time: 0.9565
INFO - 2026-01-21 02:43:31 --> Config Class Initialized
INFO - 2026-01-21 02:43:31 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:43:31 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:43:31 --> Utf8 Class Initialized
INFO - 2026-01-21 02:43:31 --> URI Class Initialized
INFO - 2026-01-21 02:43:31 --> Router Class Initialized
INFO - 2026-01-21 02:43:31 --> Output Class Initialized
INFO - 2026-01-21 02:43:31 --> Security Class Initialized
DEBUG - 2026-01-21 02:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:43:31 --> CSRF cookie sent
INFO - 2026-01-21 02:43:31 --> Input Class Initialized
INFO - 2026-01-21 02:43:31 --> Language Class Initialized
INFO - 2026-01-21 02:43:31 --> Loader Class Initialized
INFO - 2026-01-21 02:43:31 --> Helper loaded: url_helper
INFO - 2026-01-21 02:43:31 --> Helper loaded: text_helper
INFO - 2026-01-21 02:43:31 --> Helper loaded: string_helper
INFO - 2026-01-21 02:43:31 --> Helper loaded: form_helper
INFO - 2026-01-21 02:43:31 --> Helper loaded: download_helper
INFO - 2026-01-21 02:43:31 --> Helper loaded: security_helper
INFO - 2026-01-21 02:43:31 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:43:31 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:43:31 --> Form Validation Class Initialized
INFO - 2026-01-21 02:43:31 --> Model "User_model" initialized
INFO - 2026-01-21 08:43:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:43:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:43:31 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:43:31 --> Controller Class Initialized
INFO - 2026-01-21 08:43:31 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 08:43:31 --> Model "Prodi_model" initialized
INFO - 2026-01-21 08:43:31 --> Model "Sdm_model" initialized
INFO - 2026-01-21 08:43:31 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 08:43:31 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-21 08:43:31 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 08:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 08:43:31 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-21 08:43:31 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-21 08:43:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-21 08:43:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:43:31 --> Model "Log_model" initialized
INFO - 2026-01-21 08:43:32 --> Final output sent to browser
DEBUG - 2026-01-21 08:43:32 --> Total execution time: 0.3155
INFO - 2026-01-21 02:44:04 --> Config Class Initialized
INFO - 2026-01-21 02:44:04 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:44:04 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:44:04 --> Utf8 Class Initialized
INFO - 2026-01-21 02:44:04 --> URI Class Initialized
INFO - 2026-01-21 02:44:04 --> Router Class Initialized
INFO - 2026-01-21 02:44:04 --> Output Class Initialized
INFO - 2026-01-21 02:44:04 --> Security Class Initialized
DEBUG - 2026-01-21 02:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:44:04 --> CSRF cookie sent
INFO - 2026-01-21 02:44:04 --> Input Class Initialized
INFO - 2026-01-21 02:44:04 --> Language Class Initialized
INFO - 2026-01-21 02:44:04 --> Loader Class Initialized
INFO - 2026-01-21 02:44:04 --> Helper loaded: url_helper
INFO - 2026-01-21 02:44:04 --> Helper loaded: text_helper
INFO - 2026-01-21 02:44:04 --> Helper loaded: string_helper
INFO - 2026-01-21 02:44:04 --> Helper loaded: form_helper
INFO - 2026-01-21 02:44:04 --> Helper loaded: download_helper
INFO - 2026-01-21 02:44:04 --> Helper loaded: security_helper
INFO - 2026-01-21 02:44:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:44:04 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:44:04 --> Form Validation Class Initialized
INFO - 2026-01-21 02:44:04 --> Model "User_model" initialized
INFO - 2026-01-21 08:44:04 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:44:04 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:44:04 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:44:04 --> Controller Class Initialized
INFO - 2026-01-21 08:44:04 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 08:44:04 --> Model "Prodi_model" initialized
INFO - 2026-01-21 08:44:04 --> Model "Sdm_model" initialized
INFO - 2026-01-21 08:44:04 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 08:44:04 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-21 08:44:04 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 08:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 08:44:04 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-21 08:44:04 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-21 08:44:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-21 08:44:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:44:04 --> Model "Log_model" initialized
INFO - 2026-01-21 08:44:04 --> Final output sent to browser
DEBUG - 2026-01-21 08:44:04 --> Total execution time: 0.2415
INFO - 2026-01-21 02:44:47 --> Config Class Initialized
INFO - 2026-01-21 02:44:47 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:44:47 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:44:47 --> Utf8 Class Initialized
INFO - 2026-01-21 02:44:47 --> URI Class Initialized
INFO - 2026-01-21 02:44:47 --> Router Class Initialized
INFO - 2026-01-21 02:44:47 --> Output Class Initialized
INFO - 2026-01-21 02:44:47 --> Security Class Initialized
DEBUG - 2026-01-21 02:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:44:47 --> CSRF cookie sent
INFO - 2026-01-21 02:44:47 --> Input Class Initialized
INFO - 2026-01-21 02:44:47 --> Language Class Initialized
INFO - 2026-01-21 02:44:47 --> Loader Class Initialized
INFO - 2026-01-21 02:44:47 --> Helper loaded: url_helper
INFO - 2026-01-21 02:44:47 --> Helper loaded: text_helper
INFO - 2026-01-21 02:44:47 --> Helper loaded: string_helper
INFO - 2026-01-21 02:44:47 --> Helper loaded: form_helper
INFO - 2026-01-21 02:44:47 --> Helper loaded: download_helper
INFO - 2026-01-21 02:44:47 --> Helper loaded: security_helper
INFO - 2026-01-21 02:44:47 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:44:47 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:44:47 --> Form Validation Class Initialized
INFO - 2026-01-21 02:44:47 --> Model "User_model" initialized
INFO - 2026-01-21 08:44:47 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:44:47 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:44:47 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:44:47 --> Controller Class Initialized
DEBUG - 2026-01-21 08:44:47 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-21 08:44:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-21 08:44:47 --> Model "Log_model" initialized
INFO - 2026-01-21 08:44:47 --> Final output sent to browser
DEBUG - 2026-01-21 08:44:47 --> Total execution time: 0.1603
INFO - 2026-01-21 02:45:07 --> Config Class Initialized
INFO - 2026-01-21 02:45:07 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:45:07 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:45:07 --> Utf8 Class Initialized
INFO - 2026-01-21 02:45:07 --> URI Class Initialized
INFO - 2026-01-21 02:45:07 --> Router Class Initialized
INFO - 2026-01-21 02:45:07 --> Output Class Initialized
INFO - 2026-01-21 02:45:07 --> Security Class Initialized
DEBUG - 2026-01-21 02:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:45:07 --> CSRF cookie sent
INFO - 2026-01-21 02:45:07 --> CSRF token verified
INFO - 2026-01-21 02:45:07 --> Input Class Initialized
INFO - 2026-01-21 02:45:07 --> Language Class Initialized
INFO - 2026-01-21 02:45:07 --> Loader Class Initialized
INFO - 2026-01-21 02:45:07 --> Helper loaded: url_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: text_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: string_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: form_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: download_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: security_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:45:07 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:45:07 --> Form Validation Class Initialized
INFO - 2026-01-21 02:45:07 --> Model "User_model" initialized
INFO - 2026-01-21 08:45:07 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:45:07 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:45:07 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:45:07 --> Controller Class Initialized
DEBUG - 2026-01-21 08:45:07 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-21 08:45:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-21 02:45:07 --> Config Class Initialized
INFO - 2026-01-21 02:45:07 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:45:07 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:45:07 --> Utf8 Class Initialized
INFO - 2026-01-21 02:45:07 --> URI Class Initialized
INFO - 2026-01-21 02:45:07 --> Router Class Initialized
INFO - 2026-01-21 02:45:07 --> Output Class Initialized
INFO - 2026-01-21 02:45:07 --> Security Class Initialized
DEBUG - 2026-01-21 02:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:45:07 --> CSRF cookie sent
INFO - 2026-01-21 02:45:07 --> Input Class Initialized
INFO - 2026-01-21 02:45:07 --> Language Class Initialized
INFO - 2026-01-21 02:45:07 --> Loader Class Initialized
INFO - 2026-01-21 02:45:07 --> Helper loaded: url_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: text_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: string_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: form_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: download_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: security_helper
INFO - 2026-01-21 02:45:07 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:45:07 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:45:07 --> Form Validation Class Initialized
INFO - 2026-01-21 02:45:07 --> Model "User_model" initialized
INFO - 2026-01-21 08:45:07 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:45:07 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:45:07 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:45:07 --> Controller Class Initialized
DEBUG - 2026-01-21 08:45:07 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-21 08:45:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-21 08:45:07 --> Model "Log_model" initialized
INFO - 2026-01-21 08:45:07 --> Final output sent to browser
DEBUG - 2026-01-21 08:45:07 --> Total execution time: 0.1330
INFO - 2026-01-21 02:45:17 --> Config Class Initialized
INFO - 2026-01-21 02:45:17 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:45:17 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:45:17 --> Utf8 Class Initialized
INFO - 2026-01-21 02:45:17 --> URI Class Initialized
INFO - 2026-01-21 02:45:17 --> Router Class Initialized
INFO - 2026-01-21 02:45:17 --> Output Class Initialized
INFO - 2026-01-21 02:45:17 --> Security Class Initialized
DEBUG - 2026-01-21 02:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:45:17 --> CSRF cookie sent
INFO - 2026-01-21 02:45:17 --> CSRF token verified
INFO - 2026-01-21 02:45:17 --> Input Class Initialized
INFO - 2026-01-21 02:45:17 --> Language Class Initialized
INFO - 2026-01-21 02:45:17 --> Loader Class Initialized
INFO - 2026-01-21 02:45:17 --> Helper loaded: url_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: text_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: string_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: form_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: download_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: security_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:45:17 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:45:17 --> Form Validation Class Initialized
INFO - 2026-01-21 02:45:17 --> Model "User_model" initialized
INFO - 2026-01-21 08:45:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:45:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:45:17 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:45:17 --> Controller Class Initialized
DEBUG - 2026-01-21 08:45:17 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-21 08:45:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-21 02:45:17 --> Config Class Initialized
INFO - 2026-01-21 02:45:17 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:45:17 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:45:17 --> Utf8 Class Initialized
INFO - 2026-01-21 02:45:17 --> URI Class Initialized
INFO - 2026-01-21 02:45:17 --> Router Class Initialized
INFO - 2026-01-21 02:45:17 --> Output Class Initialized
INFO - 2026-01-21 02:45:17 --> Security Class Initialized
DEBUG - 2026-01-21 02:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:45:17 --> CSRF cookie sent
INFO - 2026-01-21 02:45:17 --> Input Class Initialized
INFO - 2026-01-21 02:45:17 --> Language Class Initialized
INFO - 2026-01-21 02:45:17 --> Loader Class Initialized
INFO - 2026-01-21 02:45:17 --> Helper loaded: url_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: text_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: string_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: form_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: download_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: security_helper
INFO - 2026-01-21 02:45:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:45:17 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:45:17 --> Form Validation Class Initialized
INFO - 2026-01-21 02:45:17 --> Model "User_model" initialized
INFO - 2026-01-21 08:45:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:45:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:45:17 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:45:17 --> Controller Class Initialized
DEBUG - 2026-01-21 08:45:17 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-21 08:45:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-21 08:45:17 --> Model "Log_model" initialized
INFO - 2026-01-21 08:45:17 --> Final output sent to browser
DEBUG - 2026-01-21 08:45:17 --> Total execution time: 0.1327
INFO - 2026-01-21 02:45:25 --> Config Class Initialized
INFO - 2026-01-21 02:45:25 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:45:25 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:45:25 --> Utf8 Class Initialized
INFO - 2026-01-21 02:45:25 --> URI Class Initialized
INFO - 2026-01-21 02:45:25 --> Router Class Initialized
INFO - 2026-01-21 02:45:25 --> Output Class Initialized
INFO - 2026-01-21 02:45:25 --> Security Class Initialized
DEBUG - 2026-01-21 02:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:45:25 --> CSRF cookie sent
INFO - 2026-01-21 02:45:25 --> CSRF token verified
INFO - 2026-01-21 02:45:25 --> Input Class Initialized
INFO - 2026-01-21 02:45:25 --> Language Class Initialized
INFO - 2026-01-21 02:45:25 --> Loader Class Initialized
INFO - 2026-01-21 02:45:25 --> Helper loaded: url_helper
INFO - 2026-01-21 02:45:25 --> Helper loaded: text_helper
INFO - 2026-01-21 02:45:25 --> Helper loaded: string_helper
INFO - 2026-01-21 02:45:25 --> Helper loaded: form_helper
INFO - 2026-01-21 02:45:25 --> Helper loaded: download_helper
INFO - 2026-01-21 02:45:25 --> Helper loaded: security_helper
INFO - 2026-01-21 02:45:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:45:25 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:45:25 --> Form Validation Class Initialized
INFO - 2026-01-21 02:45:25 --> Model "User_model" initialized
INFO - 2026-01-21 08:45:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:45:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:45:25 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:45:25 --> Controller Class Initialized
DEBUG - 2026-01-21 08:45:25 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-21 08:45:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-21 02:45:26 --> Config Class Initialized
INFO - 2026-01-21 02:45:26 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:45:26 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:45:26 --> Utf8 Class Initialized
INFO - 2026-01-21 02:45:26 --> URI Class Initialized
INFO - 2026-01-21 02:45:26 --> Router Class Initialized
INFO - 2026-01-21 02:45:26 --> Output Class Initialized
INFO - 2026-01-21 02:45:26 --> Security Class Initialized
DEBUG - 2026-01-21 02:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:45:26 --> CSRF cookie sent
INFO - 2026-01-21 02:45:26 --> Input Class Initialized
INFO - 2026-01-21 02:45:26 --> Language Class Initialized
INFO - 2026-01-21 02:45:26 --> Loader Class Initialized
INFO - 2026-01-21 02:45:26 --> Helper loaded: url_helper
INFO - 2026-01-21 02:45:26 --> Helper loaded: text_helper
INFO - 2026-01-21 02:45:26 --> Helper loaded: string_helper
INFO - 2026-01-21 02:45:26 --> Helper loaded: form_helper
INFO - 2026-01-21 02:45:26 --> Helper loaded: download_helper
INFO - 2026-01-21 02:45:26 --> Helper loaded: security_helper
INFO - 2026-01-21 02:45:26 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:45:26 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:45:26 --> Form Validation Class Initialized
INFO - 2026-01-21 02:45:26 --> Model "User_model" initialized
INFO - 2026-01-21 08:45:26 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:45:26 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:45:26 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:45:26 --> Controller Class Initialized
INFO - 2026-01-21 08:45:26 --> Model "Tautan_model" initialized
INFO - 2026-01-21 08:45:26 --> Model "Staff_model" initialized
INFO - 2026-01-21 08:45:26 --> Model "Dasbor_model" initialized
INFO - 2026-01-21 08:45:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2026-01-21 08:45:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 08:45:26 --> Model "Log_model" initialized
INFO - 2026-01-21 08:45:26 --> Final output sent to browser
DEBUG - 2026-01-21 08:45:26 --> Total execution time: 0.9075
INFO - 2026-01-21 02:45:34 --> Config Class Initialized
INFO - 2026-01-21 02:45:34 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:45:34 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:45:34 --> Utf8 Class Initialized
INFO - 2026-01-21 02:45:34 --> URI Class Initialized
INFO - 2026-01-21 02:45:34 --> Router Class Initialized
INFO - 2026-01-21 02:45:34 --> Output Class Initialized
INFO - 2026-01-21 02:45:34 --> Security Class Initialized
DEBUG - 2026-01-21 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:45:34 --> CSRF cookie sent
INFO - 2026-01-21 02:45:34 --> Input Class Initialized
INFO - 2026-01-21 02:45:34 --> Language Class Initialized
INFO - 2026-01-21 02:45:34 --> Loader Class Initialized
INFO - 2026-01-21 02:45:34 --> Helper loaded: url_helper
INFO - 2026-01-21 02:45:34 --> Helper loaded: text_helper
INFO - 2026-01-21 02:45:34 --> Helper loaded: string_helper
INFO - 2026-01-21 02:45:34 --> Helper loaded: form_helper
INFO - 2026-01-21 02:45:34 --> Helper loaded: download_helper
INFO - 2026-01-21 02:45:34 --> Helper loaded: security_helper
INFO - 2026-01-21 02:45:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:45:34 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:45:34 --> Form Validation Class Initialized
INFO - 2026-01-21 02:45:34 --> Model "User_model" initialized
INFO - 2026-01-21 08:45:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:45:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:45:34 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:45:34 --> Controller Class Initialized
INFO - 2026-01-21 08:45:34 --> Model "Prodi_model" initialized
INFO - 2026-01-21 08:45:34 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 08:45:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-21 08:45:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 08:45:34 --> Model "Log_model" initialized
INFO - 2026-01-21 08:45:34 --> Final output sent to browser
DEBUG - 2026-01-21 08:45:34 --> Total execution time: 0.1489
INFO - 2026-01-21 02:45:40 --> Config Class Initialized
INFO - 2026-01-21 02:45:40 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:45:40 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:45:40 --> Utf8 Class Initialized
INFO - 2026-01-21 02:45:40 --> URI Class Initialized
INFO - 2026-01-21 02:45:40 --> Router Class Initialized
INFO - 2026-01-21 02:45:40 --> Output Class Initialized
INFO - 2026-01-21 02:45:40 --> Security Class Initialized
DEBUG - 2026-01-21 02:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:45:40 --> CSRF cookie sent
INFO - 2026-01-21 02:45:40 --> Input Class Initialized
INFO - 2026-01-21 02:45:40 --> Language Class Initialized
INFO - 2026-01-21 02:45:40 --> Loader Class Initialized
INFO - 2026-01-21 02:45:40 --> Helper loaded: url_helper
INFO - 2026-01-21 02:45:40 --> Helper loaded: text_helper
INFO - 2026-01-21 02:45:40 --> Helper loaded: string_helper
INFO - 2026-01-21 02:45:40 --> Helper loaded: form_helper
INFO - 2026-01-21 02:45:40 --> Helper loaded: download_helper
INFO - 2026-01-21 02:45:40 --> Helper loaded: security_helper
INFO - 2026-01-21 02:45:40 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:45:40 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:45:40 --> Form Validation Class Initialized
INFO - 2026-01-21 02:45:40 --> Model "User_model" initialized
INFO - 2026-01-21 08:45:40 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:45:40 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:45:40 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:45:40 --> Controller Class Initialized
INFO - 2026-01-21 08:45:40 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 08:45:40 --> Model "Prodi_model" initialized
INFO - 2026-01-21 08:45:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2026-01-21 08:45:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 08:45:40 --> Model "Log_model" initialized
INFO - 2026-01-21 08:45:40 --> Final output sent to browser
DEBUG - 2026-01-21 08:45:40 --> Total execution time: 0.1506
INFO - 2026-01-21 02:45:43 --> Config Class Initialized
INFO - 2026-01-21 02:45:43 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:45:43 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:45:43 --> Utf8 Class Initialized
INFO - 2026-01-21 02:45:43 --> URI Class Initialized
INFO - 2026-01-21 02:45:43 --> Router Class Initialized
INFO - 2026-01-21 02:45:43 --> Output Class Initialized
INFO - 2026-01-21 02:45:43 --> Security Class Initialized
DEBUG - 2026-01-21 02:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:45:43 --> CSRF cookie sent
INFO - 2026-01-21 02:45:43 --> Input Class Initialized
INFO - 2026-01-21 02:45:43 --> Language Class Initialized
INFO - 2026-01-21 02:45:43 --> Loader Class Initialized
INFO - 2026-01-21 02:45:43 --> Helper loaded: url_helper
INFO - 2026-01-21 02:45:43 --> Helper loaded: text_helper
INFO - 2026-01-21 02:45:43 --> Helper loaded: string_helper
INFO - 2026-01-21 02:45:43 --> Helper loaded: form_helper
INFO - 2026-01-21 02:45:43 --> Helper loaded: download_helper
INFO - 2026-01-21 02:45:43 --> Helper loaded: security_helper
INFO - 2026-01-21 02:45:43 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:45:43 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:45:43 --> Form Validation Class Initialized
INFO - 2026-01-21 02:45:43 --> Model "User_model" initialized
INFO - 2026-01-21 08:45:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:45:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:45:43 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:45:43 --> Controller Class Initialized
INFO - 2026-01-21 08:45:43 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 08:45:43 --> Model "Prodi_model" initialized
INFO - 2026-01-21 08:45:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2026-01-21 08:45:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 08:45:43 --> Model "Log_model" initialized
INFO - 2026-01-21 08:45:43 --> Final output sent to browser
DEBUG - 2026-01-21 08:45:43 --> Total execution time: 0.1472
INFO - 2026-01-21 02:47:10 --> Config Class Initialized
INFO - 2026-01-21 02:47:10 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:47:10 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:47:10 --> Utf8 Class Initialized
INFO - 2026-01-21 02:47:10 --> URI Class Initialized
INFO - 2026-01-21 02:47:10 --> Router Class Initialized
INFO - 2026-01-21 02:47:10 --> Output Class Initialized
INFO - 2026-01-21 02:47:10 --> Security Class Initialized
DEBUG - 2026-01-21 02:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:47:10 --> CSRF cookie sent
INFO - 2026-01-21 02:47:10 --> Input Class Initialized
INFO - 2026-01-21 02:47:10 --> Language Class Initialized
INFO - 2026-01-21 02:47:10 --> Loader Class Initialized
INFO - 2026-01-21 02:47:10 --> Helper loaded: url_helper
INFO - 2026-01-21 02:47:10 --> Helper loaded: text_helper
INFO - 2026-01-21 02:47:10 --> Helper loaded: string_helper
INFO - 2026-01-21 02:47:10 --> Helper loaded: form_helper
INFO - 2026-01-21 02:47:10 --> Helper loaded: download_helper
INFO - 2026-01-21 02:47:10 --> Helper loaded: security_helper
INFO - 2026-01-21 02:47:10 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:47:10 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:47:10 --> Form Validation Class Initialized
INFO - 2026-01-21 02:47:10 --> Model "User_model" initialized
INFO - 2026-01-21 08:47:10 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:47:10 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:47:10 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:47:10 --> Controller Class Initialized
INFO - 2026-01-21 08:47:10 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 08:47:10 --> Model "Prodi_model" initialized
INFO - 2026-01-21 08:47:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2026-01-21 08:47:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 08:47:10 --> Model "Log_model" initialized
INFO - 2026-01-21 08:47:10 --> Final output sent to browser
DEBUG - 2026-01-21 08:47:10 --> Total execution time: 0.1500
INFO - 2026-01-21 02:48:07 --> Config Class Initialized
INFO - 2026-01-21 02:48:07 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:48:07 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:48:07 --> Utf8 Class Initialized
INFO - 2026-01-21 02:48:07 --> URI Class Initialized
INFO - 2026-01-21 02:48:07 --> Router Class Initialized
INFO - 2026-01-21 02:48:07 --> Output Class Initialized
INFO - 2026-01-21 02:48:07 --> Security Class Initialized
DEBUG - 2026-01-21 02:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:48:07 --> CSRF cookie sent
INFO - 2026-01-21 02:48:07 --> Input Class Initialized
INFO - 2026-01-21 02:48:07 --> Language Class Initialized
INFO - 2026-01-21 02:48:07 --> Loader Class Initialized
INFO - 2026-01-21 02:48:07 --> Helper loaded: url_helper
INFO - 2026-01-21 02:48:07 --> Helper loaded: text_helper
INFO - 2026-01-21 02:48:07 --> Helper loaded: string_helper
INFO - 2026-01-21 02:48:07 --> Helper loaded: form_helper
INFO - 2026-01-21 02:48:07 --> Helper loaded: download_helper
INFO - 2026-01-21 02:48:07 --> Helper loaded: security_helper
INFO - 2026-01-21 02:48:07 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:48:07 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:48:07 --> Form Validation Class Initialized
INFO - 2026-01-21 02:48:07 --> Model "User_model" initialized
INFO - 2026-01-21 08:48:07 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:48:07 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:48:07 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:48:07 --> Controller Class Initialized
INFO - 2026-01-21 08:48:07 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 08:48:07 --> Model "Prodi_model" initialized
INFO - 2026-01-21 08:48:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2026-01-21 08:48:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 08:48:07 --> Model "Log_model" initialized
INFO - 2026-01-21 08:48:07 --> Final output sent to browser
DEBUG - 2026-01-21 08:48:07 --> Total execution time: 0.1625
INFO - 2026-01-21 02:50:50 --> Config Class Initialized
INFO - 2026-01-21 02:50:50 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:50:50 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:50:50 --> Utf8 Class Initialized
INFO - 2026-01-21 02:50:50 --> URI Class Initialized
INFO - 2026-01-21 02:50:50 --> Router Class Initialized
INFO - 2026-01-21 02:50:50 --> Output Class Initialized
INFO - 2026-01-21 02:50:50 --> Security Class Initialized
DEBUG - 2026-01-21 02:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:50:50 --> CSRF cookie sent
INFO - 2026-01-21 02:50:50 --> Input Class Initialized
INFO - 2026-01-21 02:50:50 --> Language Class Initialized
INFO - 2026-01-21 02:50:50 --> Loader Class Initialized
INFO - 2026-01-21 02:50:50 --> Helper loaded: url_helper
INFO - 2026-01-21 02:50:50 --> Helper loaded: text_helper
INFO - 2026-01-21 02:50:50 --> Helper loaded: string_helper
INFO - 2026-01-21 02:50:50 --> Helper loaded: form_helper
INFO - 2026-01-21 02:50:50 --> Helper loaded: download_helper
INFO - 2026-01-21 02:50:50 --> Helper loaded: security_helper
INFO - 2026-01-21 02:50:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:50:50 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:50:50 --> Form Validation Class Initialized
INFO - 2026-01-21 02:50:50 --> Model "User_model" initialized
INFO - 2026-01-21 08:50:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:50:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:50:50 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:50:50 --> Controller Class Initialized
INFO - 2026-01-21 08:50:50 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 08:50:50 --> Model "Prodi_model" initialized
INFO - 2026-01-21 08:50:50 --> Model "Sdm_model" initialized
INFO - 2026-01-21 08:50:50 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 08:50:50 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-21 08:50:50 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 08:50:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 08:50:50 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-21 08:50:50 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-21 08:50:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-21 08:50:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:50:50 --> Model "Log_model" initialized
INFO - 2026-01-21 08:50:50 --> Final output sent to browser
DEBUG - 2026-01-21 08:50:50 --> Total execution time: 0.5564
INFO - 2026-01-21 02:51:32 --> Config Class Initialized
INFO - 2026-01-21 02:51:32 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:51:32 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:51:32 --> Utf8 Class Initialized
INFO - 2026-01-21 02:51:32 --> URI Class Initialized
INFO - 2026-01-21 02:51:32 --> Router Class Initialized
INFO - 2026-01-21 02:51:32 --> Output Class Initialized
INFO - 2026-01-21 02:51:32 --> Security Class Initialized
DEBUG - 2026-01-21 02:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:51:32 --> CSRF cookie sent
INFO - 2026-01-21 02:51:32 --> Input Class Initialized
INFO - 2026-01-21 02:51:32 --> Language Class Initialized
INFO - 2026-01-21 02:51:32 --> Loader Class Initialized
INFO - 2026-01-21 02:51:32 --> Helper loaded: url_helper
INFO - 2026-01-21 02:51:32 --> Helper loaded: text_helper
INFO - 2026-01-21 02:51:32 --> Helper loaded: string_helper
INFO - 2026-01-21 02:51:32 --> Helper loaded: form_helper
INFO - 2026-01-21 02:51:32 --> Helper loaded: download_helper
INFO - 2026-01-21 02:51:32 --> Helper loaded: security_helper
INFO - 2026-01-21 02:51:32 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:51:32 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:51:32 --> Form Validation Class Initialized
INFO - 2026-01-21 02:51:32 --> Model "User_model" initialized
INFO - 2026-01-21 08:51:32 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:51:32 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:51:32 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:51:32 --> Controller Class Initialized
INFO - 2026-01-21 08:51:32 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 08:51:32 --> Model "Prodi_model" initialized
INFO - 2026-01-21 08:51:32 --> Model "Sdm_model" initialized
INFO - 2026-01-21 08:51:32 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 08:51:32 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-21 08:51:33 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 08:51:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 08:51:33 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-21 08:51:33 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-21 08:51:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-21 08:51:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:51:33 --> Model "Log_model" initialized
INFO - 2026-01-21 08:51:33 --> Final output sent to browser
DEBUG - 2026-01-21 08:51:33 --> Total execution time: 0.5355
INFO - 2026-01-21 02:51:54 --> Config Class Initialized
INFO - 2026-01-21 02:51:54 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:51:54 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:51:54 --> Utf8 Class Initialized
INFO - 2026-01-21 02:51:54 --> URI Class Initialized
INFO - 2026-01-21 02:51:54 --> Router Class Initialized
INFO - 2026-01-21 02:51:54 --> Output Class Initialized
INFO - 2026-01-21 02:51:54 --> Security Class Initialized
DEBUG - 2026-01-21 02:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:51:55 --> CSRF cookie sent
INFO - 2026-01-21 02:51:55 --> Input Class Initialized
INFO - 2026-01-21 02:51:55 --> Language Class Initialized
INFO - 2026-01-21 02:51:55 --> Loader Class Initialized
INFO - 2026-01-21 02:51:55 --> Helper loaded: url_helper
INFO - 2026-01-21 02:51:55 --> Helper loaded: text_helper
INFO - 2026-01-21 02:51:55 --> Helper loaded: string_helper
INFO - 2026-01-21 02:51:55 --> Helper loaded: form_helper
INFO - 2026-01-21 02:51:55 --> Helper loaded: download_helper
INFO - 2026-01-21 02:51:55 --> Helper loaded: security_helper
INFO - 2026-01-21 02:51:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:51:55 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:51:55 --> Form Validation Class Initialized
INFO - 2026-01-21 02:51:55 --> Model "User_model" initialized
INFO - 2026-01-21 08:51:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:51:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:51:55 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:51:55 --> Controller Class Initialized
INFO - 2026-01-21 08:51:55 --> Model "Download_model" initialized
INFO - 2026-01-21 08:51:55 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:51:55 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:51:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 08:51:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:51:55 --> Model "Log_model" initialized
INFO - 2026-01-21 08:51:55 --> Final output sent to browser
DEBUG - 2026-01-21 08:51:55 --> Total execution time: 0.2178
INFO - 2026-01-21 02:51:56 --> Config Class Initialized
INFO - 2026-01-21 02:51:56 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:51:56 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:51:56 --> Utf8 Class Initialized
INFO - 2026-01-21 02:51:56 --> URI Class Initialized
INFO - 2026-01-21 02:51:56 --> Router Class Initialized
INFO - 2026-01-21 02:51:56 --> Output Class Initialized
INFO - 2026-01-21 02:51:56 --> Security Class Initialized
DEBUG - 2026-01-21 02:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:51:56 --> CSRF cookie sent
INFO - 2026-01-21 02:51:56 --> Input Class Initialized
INFO - 2026-01-21 02:51:56 --> Language Class Initialized
INFO - 2026-01-21 02:51:56 --> Loader Class Initialized
INFO - 2026-01-21 02:51:56 --> Helper loaded: url_helper
INFO - 2026-01-21 02:51:56 --> Helper loaded: text_helper
INFO - 2026-01-21 02:51:56 --> Helper loaded: string_helper
INFO - 2026-01-21 02:51:56 --> Helper loaded: form_helper
INFO - 2026-01-21 02:51:56 --> Helper loaded: download_helper
INFO - 2026-01-21 02:51:56 --> Helper loaded: security_helper
INFO - 2026-01-21 02:51:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:51:56 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:51:56 --> Form Validation Class Initialized
INFO - 2026-01-21 02:51:56 --> Model "User_model" initialized
INFO - 2026-01-21 08:51:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:51:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:51:56 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:51:56 --> Controller Class Initialized
INFO - 2026-01-21 08:51:56 --> Model "Download_model" initialized
INFO - 2026-01-21 08:51:56 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:51:56 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:51:56 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 08:51:56"}
INFO - 2026-01-21 02:55:34 --> Config Class Initialized
INFO - 2026-01-21 02:55:34 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:55:34 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:55:34 --> Utf8 Class Initialized
INFO - 2026-01-21 02:55:34 --> URI Class Initialized
INFO - 2026-01-21 02:55:34 --> Router Class Initialized
INFO - 2026-01-21 02:55:34 --> Output Class Initialized
INFO - 2026-01-21 02:55:34 --> Security Class Initialized
DEBUG - 2026-01-21 02:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:55:34 --> CSRF cookie sent
INFO - 2026-01-21 02:55:34 --> Input Class Initialized
INFO - 2026-01-21 02:55:34 --> Language Class Initialized
INFO - 2026-01-21 02:55:34 --> Loader Class Initialized
INFO - 2026-01-21 02:55:34 --> Helper loaded: url_helper
INFO - 2026-01-21 02:55:34 --> Helper loaded: text_helper
INFO - 2026-01-21 02:55:34 --> Helper loaded: string_helper
INFO - 2026-01-21 02:55:34 --> Helper loaded: form_helper
INFO - 2026-01-21 02:55:34 --> Helper loaded: download_helper
INFO - 2026-01-21 02:55:34 --> Helper loaded: security_helper
INFO - 2026-01-21 02:55:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:55:34 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:55:34 --> Form Validation Class Initialized
INFO - 2026-01-21 02:55:34 --> Model "User_model" initialized
INFO - 2026-01-21 08:55:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:55:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:55:34 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:55:34 --> Controller Class Initialized
INFO - 2026-01-21 08:55:34 --> Model "Download_model" initialized
INFO - 2026-01-21 08:55:34 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:55:34 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:55:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 08:55:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:55:34 --> Model "Log_model" initialized
INFO - 2026-01-21 08:55:34 --> Final output sent to browser
DEBUG - 2026-01-21 08:55:34 --> Total execution time: 0.4139
INFO - 2026-01-21 02:55:49 --> Config Class Initialized
INFO - 2026-01-21 02:55:49 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:55:49 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:55:49 --> Utf8 Class Initialized
INFO - 2026-01-21 02:55:49 --> URI Class Initialized
INFO - 2026-01-21 02:55:49 --> Router Class Initialized
INFO - 2026-01-21 02:55:49 --> Output Class Initialized
INFO - 2026-01-21 02:55:49 --> Security Class Initialized
DEBUG - 2026-01-21 02:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:55:49 --> CSRF cookie sent
INFO - 2026-01-21 02:55:49 --> Input Class Initialized
INFO - 2026-01-21 02:55:49 --> Language Class Initialized
INFO - 2026-01-21 02:55:49 --> Loader Class Initialized
INFO - 2026-01-21 02:55:49 --> Helper loaded: url_helper
INFO - 2026-01-21 02:55:49 --> Helper loaded: text_helper
INFO - 2026-01-21 02:55:49 --> Helper loaded: string_helper
INFO - 2026-01-21 02:55:49 --> Helper loaded: form_helper
INFO - 2026-01-21 02:55:49 --> Helper loaded: download_helper
INFO - 2026-01-21 02:55:49 --> Helper loaded: security_helper
INFO - 2026-01-21 02:55:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:55:50 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:55:50 --> Form Validation Class Initialized
INFO - 2026-01-21 02:55:50 --> Model "User_model" initialized
INFO - 2026-01-21 08:55:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:55:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:55:50 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:55:50 --> Controller Class Initialized
INFO - 2026-01-21 08:55:50 --> Model "Download_model" initialized
INFO - 2026-01-21 08:55:50 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:55:50 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:55:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 08:55:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:55:50 --> Model "Log_model" initialized
INFO - 2026-01-21 08:55:50 --> Final output sent to browser
DEBUG - 2026-01-21 08:55:50 --> Total execution time: 0.1696
INFO - 2026-01-21 02:58:43 --> Config Class Initialized
INFO - 2026-01-21 02:58:43 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:58:43 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:58:43 --> Utf8 Class Initialized
INFO - 2026-01-21 02:58:43 --> URI Class Initialized
INFO - 2026-01-21 02:58:43 --> Router Class Initialized
INFO - 2026-01-21 02:58:43 --> Output Class Initialized
INFO - 2026-01-21 02:58:43 --> Security Class Initialized
DEBUG - 2026-01-21 02:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:58:43 --> CSRF cookie sent
INFO - 2026-01-21 02:58:43 --> Input Class Initialized
INFO - 2026-01-21 02:58:43 --> Language Class Initialized
INFO - 2026-01-21 02:58:43 --> Loader Class Initialized
INFO - 2026-01-21 02:58:43 --> Helper loaded: url_helper
INFO - 2026-01-21 02:58:43 --> Helper loaded: text_helper
INFO - 2026-01-21 02:58:43 --> Helper loaded: string_helper
INFO - 2026-01-21 02:58:43 --> Helper loaded: form_helper
INFO - 2026-01-21 02:58:43 --> Helper loaded: download_helper
INFO - 2026-01-21 02:58:43 --> Helper loaded: security_helper
INFO - 2026-01-21 02:58:43 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:58:43 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:58:43 --> Form Validation Class Initialized
INFO - 2026-01-21 02:58:43 --> Model "User_model" initialized
INFO - 2026-01-21 08:58:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:58:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:58:43 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:58:43 --> Controller Class Initialized
INFO - 2026-01-21 08:58:43 --> Model "Download_model" initialized
INFO - 2026-01-21 08:58:43 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:58:43 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:58:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 08:58:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:58:43 --> Model "Log_model" initialized
INFO - 2026-01-21 08:58:43 --> Final output sent to browser
DEBUG - 2026-01-21 08:58:43 --> Total execution time: 0.5421
INFO - 2026-01-21 02:58:46 --> Config Class Initialized
INFO - 2026-01-21 02:58:46 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:58:46 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:58:46 --> Utf8 Class Initialized
INFO - 2026-01-21 02:58:46 --> URI Class Initialized
INFO - 2026-01-21 02:58:46 --> Router Class Initialized
INFO - 2026-01-21 02:58:46 --> Output Class Initialized
INFO - 2026-01-21 02:58:46 --> Security Class Initialized
DEBUG - 2026-01-21 02:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:58:46 --> CSRF cookie sent
INFO - 2026-01-21 02:58:46 --> Input Class Initialized
INFO - 2026-01-21 02:58:46 --> Language Class Initialized
INFO - 2026-01-21 02:58:46 --> Loader Class Initialized
INFO - 2026-01-21 02:58:46 --> Helper loaded: url_helper
INFO - 2026-01-21 02:58:46 --> Helper loaded: text_helper
INFO - 2026-01-21 02:58:46 --> Helper loaded: string_helper
INFO - 2026-01-21 02:58:46 --> Helper loaded: form_helper
INFO - 2026-01-21 02:58:46 --> Helper loaded: download_helper
INFO - 2026-01-21 02:58:46 --> Helper loaded: security_helper
INFO - 2026-01-21 02:58:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:58:46 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:58:46 --> Form Validation Class Initialized
INFO - 2026-01-21 02:58:46 --> Model "User_model" initialized
INFO - 2026-01-21 08:58:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:58:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:58:46 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:58:46 --> Controller Class Initialized
INFO - 2026-01-21 08:58:46 --> Model "Download_model" initialized
INFO - 2026-01-21 08:58:46 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:58:46 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:58:46 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 08:58:46"}
INFO - 2026-01-21 02:59:15 --> Config Class Initialized
INFO - 2026-01-21 02:59:15 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:59:15 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:59:15 --> Utf8 Class Initialized
INFO - 2026-01-21 02:59:15 --> URI Class Initialized
INFO - 2026-01-21 02:59:15 --> Router Class Initialized
INFO - 2026-01-21 02:59:15 --> Output Class Initialized
INFO - 2026-01-21 02:59:15 --> Security Class Initialized
DEBUG - 2026-01-21 02:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:59:15 --> CSRF cookie sent
INFO - 2026-01-21 02:59:15 --> Input Class Initialized
INFO - 2026-01-21 02:59:15 --> Language Class Initialized
INFO - 2026-01-21 02:59:15 --> Loader Class Initialized
INFO - 2026-01-21 02:59:15 --> Helper loaded: url_helper
INFO - 2026-01-21 02:59:15 --> Helper loaded: text_helper
INFO - 2026-01-21 02:59:15 --> Helper loaded: string_helper
INFO - 2026-01-21 02:59:15 --> Helper loaded: form_helper
INFO - 2026-01-21 02:59:15 --> Helper loaded: download_helper
INFO - 2026-01-21 02:59:15 --> Helper loaded: security_helper
INFO - 2026-01-21 02:59:15 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:59:15 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:59:15 --> Form Validation Class Initialized
INFO - 2026-01-21 02:59:15 --> Model "User_model" initialized
INFO - 2026-01-21 08:59:15 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:59:15 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:59:15 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:59:15 --> Controller Class Initialized
INFO - 2026-01-21 08:59:15 --> Model "Download_model" initialized
INFO - 2026-01-21 08:59:15 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:59:15 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:59:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 08:59:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:59:15 --> Model "Log_model" initialized
INFO - 2026-01-21 08:59:15 --> Final output sent to browser
DEBUG - 2026-01-21 08:59:15 --> Total execution time: 0.3853
INFO - 2026-01-21 02:59:50 --> Config Class Initialized
INFO - 2026-01-21 02:59:50 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:59:50 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:59:50 --> Utf8 Class Initialized
INFO - 2026-01-21 02:59:50 --> URI Class Initialized
INFO - 2026-01-21 02:59:50 --> Router Class Initialized
INFO - 2026-01-21 02:59:50 --> Output Class Initialized
INFO - 2026-01-21 02:59:50 --> Security Class Initialized
DEBUG - 2026-01-21 02:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:59:50 --> CSRF cookie sent
INFO - 2026-01-21 02:59:50 --> Input Class Initialized
INFO - 2026-01-21 02:59:50 --> Language Class Initialized
INFO - 2026-01-21 02:59:50 --> Loader Class Initialized
INFO - 2026-01-21 02:59:50 --> Helper loaded: url_helper
INFO - 2026-01-21 02:59:50 --> Helper loaded: text_helper
INFO - 2026-01-21 02:59:50 --> Helper loaded: string_helper
INFO - 2026-01-21 02:59:50 --> Helper loaded: form_helper
INFO - 2026-01-21 02:59:50 --> Helper loaded: download_helper
INFO - 2026-01-21 02:59:50 --> Helper loaded: security_helper
INFO - 2026-01-21 02:59:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:59:51 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:59:51 --> Form Validation Class Initialized
INFO - 2026-01-21 02:59:51 --> Model "User_model" initialized
INFO - 2026-01-21 08:59:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:59:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:59:51 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:59:51 --> Controller Class Initialized
INFO - 2026-01-21 08:59:51 --> Model "Download_model" initialized
INFO - 2026-01-21 08:59:51 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:59:51 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:59:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 08:59:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 08:59:51 --> Model "Log_model" initialized
INFO - 2026-01-21 08:59:51 --> Final output sent to browser
DEBUG - 2026-01-21 08:59:51 --> Total execution time: 0.4672
INFO - 2026-01-21 02:59:53 --> Config Class Initialized
INFO - 2026-01-21 02:59:53 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:59:53 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:59:53 --> Utf8 Class Initialized
INFO - 2026-01-21 02:59:53 --> URI Class Initialized
INFO - 2026-01-21 02:59:53 --> Router Class Initialized
INFO - 2026-01-21 02:59:53 --> Output Class Initialized
INFO - 2026-01-21 02:59:53 --> Security Class Initialized
DEBUG - 2026-01-21 02:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:59:53 --> CSRF cookie sent
INFO - 2026-01-21 02:59:53 --> Input Class Initialized
INFO - 2026-01-21 02:59:53 --> Language Class Initialized
INFO - 2026-01-21 02:59:53 --> Loader Class Initialized
INFO - 2026-01-21 02:59:53 --> Helper loaded: url_helper
INFO - 2026-01-21 02:59:53 --> Helper loaded: text_helper
INFO - 2026-01-21 02:59:53 --> Helper loaded: string_helper
INFO - 2026-01-21 02:59:53 --> Helper loaded: form_helper
INFO - 2026-01-21 02:59:53 --> Helper loaded: download_helper
INFO - 2026-01-21 02:59:53 --> Helper loaded: security_helper
INFO - 2026-01-21 02:59:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:59:53 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:59:53 --> Form Validation Class Initialized
INFO - 2026-01-21 02:59:53 --> Model "User_model" initialized
INFO - 2026-01-21 08:59:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:59:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:59:53 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:59:53 --> Controller Class Initialized
INFO - 2026-01-21 08:59:53 --> Model "Download_model" initialized
INFO - 2026-01-21 08:59:53 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:59:53 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:59:53 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 08:59:53"}
INFO - 2026-01-21 02:59:55 --> Config Class Initialized
INFO - 2026-01-21 02:59:55 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:59:55 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:59:55 --> Utf8 Class Initialized
INFO - 2026-01-21 02:59:55 --> URI Class Initialized
INFO - 2026-01-21 02:59:55 --> Router Class Initialized
INFO - 2026-01-21 02:59:55 --> Output Class Initialized
INFO - 2026-01-21 02:59:55 --> Security Class Initialized
DEBUG - 2026-01-21 02:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:59:55 --> CSRF cookie sent
INFO - 2026-01-21 02:59:55 --> Input Class Initialized
INFO - 2026-01-21 02:59:55 --> Language Class Initialized
INFO - 2026-01-21 02:59:55 --> Loader Class Initialized
INFO - 2026-01-21 02:59:55 --> Helper loaded: url_helper
INFO - 2026-01-21 02:59:55 --> Helper loaded: text_helper
INFO - 2026-01-21 02:59:55 --> Helper loaded: string_helper
INFO - 2026-01-21 02:59:55 --> Helper loaded: form_helper
INFO - 2026-01-21 02:59:55 --> Helper loaded: download_helper
INFO - 2026-01-21 02:59:55 --> Helper loaded: security_helper
INFO - 2026-01-21 02:59:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:59:55 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:59:55 --> Form Validation Class Initialized
INFO - 2026-01-21 02:59:55 --> Model "User_model" initialized
INFO - 2026-01-21 08:59:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:59:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:59:55 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:59:55 --> Controller Class Initialized
INFO - 2026-01-21 08:59:55 --> Model "Download_model" initialized
INFO - 2026-01-21 08:59:55 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:59:55 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:59:55 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 08:59:55"}
INFO - 2026-01-21 02:59:56 --> Config Class Initialized
INFO - 2026-01-21 02:59:56 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:59:56 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:59:56 --> Utf8 Class Initialized
INFO - 2026-01-21 02:59:56 --> URI Class Initialized
INFO - 2026-01-21 02:59:56 --> Router Class Initialized
INFO - 2026-01-21 02:59:56 --> Output Class Initialized
INFO - 2026-01-21 02:59:56 --> Security Class Initialized
DEBUG - 2026-01-21 02:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:59:56 --> CSRF cookie sent
INFO - 2026-01-21 02:59:56 --> Input Class Initialized
INFO - 2026-01-21 02:59:56 --> Language Class Initialized
INFO - 2026-01-21 02:59:56 --> Loader Class Initialized
INFO - 2026-01-21 02:59:56 --> Helper loaded: url_helper
INFO - 2026-01-21 02:59:56 --> Helper loaded: text_helper
INFO - 2026-01-21 02:59:56 --> Helper loaded: string_helper
INFO - 2026-01-21 02:59:56 --> Helper loaded: form_helper
INFO - 2026-01-21 02:59:56 --> Helper loaded: download_helper
INFO - 2026-01-21 02:59:56 --> Helper loaded: security_helper
INFO - 2026-01-21 02:59:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:59:56 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:59:56 --> Form Validation Class Initialized
INFO - 2026-01-21 02:59:56 --> Model "User_model" initialized
INFO - 2026-01-21 08:59:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:59:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:59:56 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:59:56 --> Controller Class Initialized
INFO - 2026-01-21 08:59:56 --> Model "Download_model" initialized
INFO - 2026-01-21 08:59:56 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:59:56 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:59:56 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 08:59:56"}
INFO - 2026-01-21 02:59:58 --> Config Class Initialized
INFO - 2026-01-21 02:59:58 --> Hooks Class Initialized
DEBUG - 2026-01-21 02:59:58 --> UTF-8 Support Enabled
INFO - 2026-01-21 02:59:58 --> Utf8 Class Initialized
INFO - 2026-01-21 02:59:58 --> URI Class Initialized
INFO - 2026-01-21 02:59:58 --> Router Class Initialized
INFO - 2026-01-21 02:59:58 --> Output Class Initialized
INFO - 2026-01-21 02:59:58 --> Security Class Initialized
DEBUG - 2026-01-21 02:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 02:59:58 --> CSRF cookie sent
INFO - 2026-01-21 02:59:58 --> Input Class Initialized
INFO - 2026-01-21 02:59:58 --> Language Class Initialized
INFO - 2026-01-21 02:59:58 --> Loader Class Initialized
INFO - 2026-01-21 02:59:58 --> Helper loaded: url_helper
INFO - 2026-01-21 02:59:58 --> Helper loaded: text_helper
INFO - 2026-01-21 02:59:58 --> Helper loaded: string_helper
INFO - 2026-01-21 02:59:58 --> Helper loaded: form_helper
INFO - 2026-01-21 02:59:58 --> Helper loaded: download_helper
INFO - 2026-01-21 02:59:58 --> Helper loaded: security_helper
INFO - 2026-01-21 02:59:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 02:59:58 --> Database Driver Class Initialized
DEBUG - 2026-01-21 02:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 02:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 02:59:59 --> Form Validation Class Initialized
INFO - 2026-01-21 02:59:59 --> Model "User_model" initialized
INFO - 2026-01-21 08:59:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 08:59:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 08:59:59 --> Model "Nav_model" initialized
INFO - 2026-01-21 08:59:59 --> Controller Class Initialized
INFO - 2026-01-21 08:59:59 --> Model "Download_model" initialized
INFO - 2026-01-21 08:59:59 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 08:59:59 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 08:59:59 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 08:59:59"}
INFO - 2026-01-21 03:00:09 --> Config Class Initialized
INFO - 2026-01-21 03:00:09 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:00:09 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:00:09 --> Utf8 Class Initialized
INFO - 2026-01-21 03:00:09 --> URI Class Initialized
INFO - 2026-01-21 03:00:09 --> Router Class Initialized
INFO - 2026-01-21 03:00:09 --> Output Class Initialized
INFO - 2026-01-21 03:00:09 --> Security Class Initialized
DEBUG - 2026-01-21 03:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:00:09 --> CSRF cookie sent
INFO - 2026-01-21 03:00:09 --> Input Class Initialized
INFO - 2026-01-21 03:00:09 --> Language Class Initialized
INFO - 2026-01-21 03:00:09 --> Loader Class Initialized
INFO - 2026-01-21 03:00:09 --> Helper loaded: url_helper
INFO - 2026-01-21 03:00:09 --> Helper loaded: text_helper
INFO - 2026-01-21 03:00:09 --> Helper loaded: string_helper
INFO - 2026-01-21 03:00:09 --> Helper loaded: form_helper
INFO - 2026-01-21 03:00:09 --> Helper loaded: download_helper
INFO - 2026-01-21 03:00:09 --> Helper loaded: security_helper
INFO - 2026-01-21 03:00:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:00:09 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:00:09 --> Form Validation Class Initialized
INFO - 2026-01-21 03:00:09 --> Model "User_model" initialized
INFO - 2026-01-21 09:00:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:00:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:00:09 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:00:09 --> Controller Class Initialized
INFO - 2026-01-21 09:00:09 --> Model "Download_model" initialized
INFO - 2026-01-21 09:00:09 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:00:09 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:00:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:00:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:00:09 --> Model "Log_model" initialized
INFO - 2026-01-21 09:00:09 --> Final output sent to browser
DEBUG - 2026-01-21 09:00:09 --> Total execution time: 0.1879
INFO - 2026-01-21 03:00:12 --> Config Class Initialized
INFO - 2026-01-21 03:00:12 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:00:12 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:00:12 --> Utf8 Class Initialized
INFO - 2026-01-21 03:00:12 --> URI Class Initialized
INFO - 2026-01-21 03:00:12 --> Router Class Initialized
INFO - 2026-01-21 03:00:12 --> Output Class Initialized
INFO - 2026-01-21 03:00:12 --> Security Class Initialized
DEBUG - 2026-01-21 03:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:00:12 --> CSRF cookie sent
INFO - 2026-01-21 03:00:12 --> Input Class Initialized
INFO - 2026-01-21 03:00:12 --> Language Class Initialized
INFO - 2026-01-21 03:00:12 --> Loader Class Initialized
INFO - 2026-01-21 03:00:12 --> Helper loaded: url_helper
INFO - 2026-01-21 03:00:12 --> Helper loaded: text_helper
INFO - 2026-01-21 03:00:12 --> Helper loaded: string_helper
INFO - 2026-01-21 03:00:12 --> Helper loaded: form_helper
INFO - 2026-01-21 03:00:12 --> Helper loaded: download_helper
INFO - 2026-01-21 03:00:12 --> Helper loaded: security_helper
INFO - 2026-01-21 03:00:12 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:00:12 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:00:12 --> Form Validation Class Initialized
INFO - 2026-01-21 03:00:12 --> Model "User_model" initialized
INFO - 2026-01-21 09:00:12 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:00:12 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:00:12 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:00:12 --> Controller Class Initialized
INFO - 2026-01-21 09:00:12 --> Model "Download_model" initialized
INFO - 2026-01-21 09:00:12 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:00:12 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:00:12 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:00:12"}
INFO - 2026-01-21 03:00:14 --> Config Class Initialized
INFO - 2026-01-21 03:00:14 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:00:14 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:00:14 --> Utf8 Class Initialized
INFO - 2026-01-21 03:00:14 --> URI Class Initialized
INFO - 2026-01-21 03:00:14 --> Router Class Initialized
INFO - 2026-01-21 03:00:14 --> Output Class Initialized
INFO - 2026-01-21 03:00:14 --> Security Class Initialized
DEBUG - 2026-01-21 03:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:00:14 --> CSRF cookie sent
INFO - 2026-01-21 03:00:14 --> Input Class Initialized
INFO - 2026-01-21 03:00:14 --> Language Class Initialized
INFO - 2026-01-21 03:00:14 --> Loader Class Initialized
INFO - 2026-01-21 03:00:14 --> Helper loaded: url_helper
INFO - 2026-01-21 03:00:14 --> Helper loaded: text_helper
INFO - 2026-01-21 03:00:14 --> Helper loaded: string_helper
INFO - 2026-01-21 03:00:14 --> Helper loaded: form_helper
INFO - 2026-01-21 03:00:14 --> Helper loaded: download_helper
INFO - 2026-01-21 03:00:14 --> Helper loaded: security_helper
INFO - 2026-01-21 03:00:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:00:14 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:00:14 --> Form Validation Class Initialized
INFO - 2026-01-21 03:00:14 --> Model "User_model" initialized
INFO - 2026-01-21 09:00:14 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:00:14 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:00:14 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:00:14 --> Controller Class Initialized
INFO - 2026-01-21 09:00:14 --> Model "Download_model" initialized
INFO - 2026-01-21 09:00:14 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:00:14 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:00:14 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:00:14"}
INFO - 2026-01-21 03:00:17 --> Config Class Initialized
INFO - 2026-01-21 03:00:17 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:00:17 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:00:17 --> Utf8 Class Initialized
INFO - 2026-01-21 03:00:17 --> URI Class Initialized
INFO - 2026-01-21 03:00:17 --> Router Class Initialized
INFO - 2026-01-21 03:00:17 --> Output Class Initialized
INFO - 2026-01-21 03:00:17 --> Security Class Initialized
DEBUG - 2026-01-21 03:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:00:17 --> CSRF cookie sent
INFO - 2026-01-21 03:00:17 --> Input Class Initialized
INFO - 2026-01-21 03:00:17 --> Language Class Initialized
INFO - 2026-01-21 03:00:17 --> Loader Class Initialized
INFO - 2026-01-21 03:00:17 --> Helper loaded: url_helper
INFO - 2026-01-21 03:00:17 --> Helper loaded: text_helper
INFO - 2026-01-21 03:00:17 --> Helper loaded: string_helper
INFO - 2026-01-21 03:00:17 --> Helper loaded: form_helper
INFO - 2026-01-21 03:00:17 --> Helper loaded: download_helper
INFO - 2026-01-21 03:00:17 --> Helper loaded: security_helper
INFO - 2026-01-21 03:00:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:00:17 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:00:17 --> Form Validation Class Initialized
INFO - 2026-01-21 03:00:17 --> Model "User_model" initialized
INFO - 2026-01-21 09:00:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:00:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:00:17 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:00:17 --> Controller Class Initialized
INFO - 2026-01-21 09:00:17 --> Model "Download_model" initialized
INFO - 2026-01-21 09:00:17 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:00:17 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:00:17 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:00:17"}
INFO - 2026-01-21 03:00:18 --> Config Class Initialized
INFO - 2026-01-21 03:00:18 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:00:18 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:00:18 --> Utf8 Class Initialized
INFO - 2026-01-21 03:00:18 --> URI Class Initialized
INFO - 2026-01-21 03:00:18 --> Router Class Initialized
INFO - 2026-01-21 03:00:18 --> Output Class Initialized
INFO - 2026-01-21 03:00:18 --> Security Class Initialized
DEBUG - 2026-01-21 03:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:00:18 --> CSRF cookie sent
INFO - 2026-01-21 03:00:18 --> Input Class Initialized
INFO - 2026-01-21 03:00:18 --> Language Class Initialized
INFO - 2026-01-21 03:00:18 --> Loader Class Initialized
INFO - 2026-01-21 03:00:18 --> Helper loaded: url_helper
INFO - 2026-01-21 03:00:18 --> Helper loaded: text_helper
INFO - 2026-01-21 03:00:18 --> Helper loaded: string_helper
INFO - 2026-01-21 03:00:18 --> Helper loaded: form_helper
INFO - 2026-01-21 03:00:18 --> Helper loaded: download_helper
INFO - 2026-01-21 03:00:18 --> Helper loaded: security_helper
INFO - 2026-01-21 03:00:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:00:18 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:00:18 --> Form Validation Class Initialized
INFO - 2026-01-21 03:00:18 --> Model "User_model" initialized
INFO - 2026-01-21 09:00:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:00:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:00:18 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:00:18 --> Controller Class Initialized
INFO - 2026-01-21 09:00:18 --> Model "Download_model" initialized
INFO - 2026-01-21 09:00:18 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:00:18 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:00:18 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:00:18"}
INFO - 2026-01-21 03:02:12 --> Config Class Initialized
INFO - 2026-01-21 03:02:12 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:02:12 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:02:12 --> Utf8 Class Initialized
INFO - 2026-01-21 03:02:12 --> URI Class Initialized
INFO - 2026-01-21 03:02:12 --> Router Class Initialized
INFO - 2026-01-21 03:02:12 --> Output Class Initialized
INFO - 2026-01-21 03:02:12 --> Security Class Initialized
DEBUG - 2026-01-21 03:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:02:12 --> CSRF cookie sent
INFO - 2026-01-21 03:02:12 --> Input Class Initialized
INFO - 2026-01-21 03:02:12 --> Language Class Initialized
INFO - 2026-01-21 03:02:12 --> Loader Class Initialized
INFO - 2026-01-21 03:02:12 --> Helper loaded: url_helper
INFO - 2026-01-21 03:02:12 --> Helper loaded: text_helper
INFO - 2026-01-21 03:02:12 --> Helper loaded: string_helper
INFO - 2026-01-21 03:02:12 --> Helper loaded: form_helper
INFO - 2026-01-21 03:02:12 --> Helper loaded: download_helper
INFO - 2026-01-21 03:02:12 --> Helper loaded: security_helper
INFO - 2026-01-21 03:02:12 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:02:12 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:02:12 --> Form Validation Class Initialized
INFO - 2026-01-21 03:02:12 --> Model "User_model" initialized
INFO - 2026-01-21 09:02:12 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:02:12 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:02:12 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:02:12 --> Controller Class Initialized
INFO - 2026-01-21 09:02:12 --> Model "Download_model" initialized
INFO - 2026-01-21 09:02:12 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:02:12 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:02:12 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"205","filename":"Perjanjian_Kinerja_Poltekkes-PPK_BLU_2022.pdf","timestamp":"2026-01-21 09:02:12"}
INFO - 2026-01-21 03:02:55 --> Config Class Initialized
INFO - 2026-01-21 03:02:55 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:02:55 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:02:55 --> Utf8 Class Initialized
INFO - 2026-01-21 03:02:55 --> URI Class Initialized
INFO - 2026-01-21 03:02:55 --> Router Class Initialized
INFO - 2026-01-21 03:02:55 --> Output Class Initialized
INFO - 2026-01-21 03:02:55 --> Security Class Initialized
DEBUG - 2026-01-21 03:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:02:55 --> CSRF cookie sent
INFO - 2026-01-21 03:02:55 --> Input Class Initialized
INFO - 2026-01-21 03:02:55 --> Language Class Initialized
INFO - 2026-01-21 03:02:55 --> Loader Class Initialized
INFO - 2026-01-21 03:02:55 --> Helper loaded: url_helper
INFO - 2026-01-21 03:02:55 --> Helper loaded: text_helper
INFO - 2026-01-21 03:02:55 --> Helper loaded: string_helper
INFO - 2026-01-21 03:02:55 --> Helper loaded: form_helper
INFO - 2026-01-21 03:02:55 --> Helper loaded: download_helper
INFO - 2026-01-21 03:02:55 --> Helper loaded: security_helper
INFO - 2026-01-21 03:02:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:02:55 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:02:55 --> Form Validation Class Initialized
INFO - 2026-01-21 03:02:55 --> Model "User_model" initialized
INFO - 2026-01-21 09:02:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:02:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:02:55 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:02:55 --> Controller Class Initialized
INFO - 2026-01-21 09:02:55 --> Model "Download_model" initialized
INFO - 2026-01-21 09:02:55 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:02:55 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:02:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:02:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:02:56 --> Model "Log_model" initialized
INFO - 2026-01-21 09:02:56 --> Final output sent to browser
DEBUG - 2026-01-21 09:02:56 --> Total execution time: 0.4005
INFO - 2026-01-21 03:05:01 --> Config Class Initialized
INFO - 2026-01-21 03:05:01 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:05:01 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:05:01 --> Utf8 Class Initialized
INFO - 2026-01-21 03:05:01 --> URI Class Initialized
INFO - 2026-01-21 03:05:01 --> Router Class Initialized
INFO - 2026-01-21 03:05:01 --> Output Class Initialized
INFO - 2026-01-21 03:05:01 --> Security Class Initialized
DEBUG - 2026-01-21 03:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:05:01 --> CSRF cookie sent
INFO - 2026-01-21 03:05:01 --> Input Class Initialized
INFO - 2026-01-21 03:05:01 --> Language Class Initialized
INFO - 2026-01-21 03:05:01 --> Loader Class Initialized
INFO - 2026-01-21 03:05:01 --> Helper loaded: url_helper
INFO - 2026-01-21 03:05:01 --> Helper loaded: text_helper
INFO - 2026-01-21 03:05:01 --> Helper loaded: string_helper
INFO - 2026-01-21 03:05:01 --> Helper loaded: form_helper
INFO - 2026-01-21 03:05:01 --> Helper loaded: download_helper
INFO - 2026-01-21 03:05:01 --> Helper loaded: security_helper
INFO - 2026-01-21 03:05:01 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:05:01 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:05:01 --> Form Validation Class Initialized
INFO - 2026-01-21 03:05:01 --> Model "User_model" initialized
INFO - 2026-01-21 09:05:01 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:05:01 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:05:01 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:05:01 --> Controller Class Initialized
INFO - 2026-01-21 09:05:01 --> Model "Download_model" initialized
INFO - 2026-01-21 09:05:01 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:05:01 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:05:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:05:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:05:02 --> Model "Log_model" initialized
INFO - 2026-01-21 09:05:02 --> Final output sent to browser
DEBUG - 2026-01-21 09:05:02 --> Total execution time: 0.4911
INFO - 2026-01-21 03:05:06 --> Config Class Initialized
INFO - 2026-01-21 03:05:06 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:05:06 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:05:06 --> Utf8 Class Initialized
INFO - 2026-01-21 03:05:06 --> URI Class Initialized
INFO - 2026-01-21 03:05:06 --> Router Class Initialized
INFO - 2026-01-21 03:05:06 --> Output Class Initialized
INFO - 2026-01-21 03:05:06 --> Security Class Initialized
DEBUG - 2026-01-21 03:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:05:06 --> CSRF cookie sent
INFO - 2026-01-21 03:05:06 --> Input Class Initialized
INFO - 2026-01-21 03:05:06 --> Language Class Initialized
INFO - 2026-01-21 03:05:06 --> Loader Class Initialized
INFO - 2026-01-21 03:05:06 --> Helper loaded: url_helper
INFO - 2026-01-21 03:05:06 --> Helper loaded: text_helper
INFO - 2026-01-21 03:05:06 --> Helper loaded: string_helper
INFO - 2026-01-21 03:05:06 --> Helper loaded: form_helper
INFO - 2026-01-21 03:05:06 --> Helper loaded: download_helper
INFO - 2026-01-21 03:05:06 --> Helper loaded: security_helper
INFO - 2026-01-21 03:05:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:05:06 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:05:06 --> Form Validation Class Initialized
INFO - 2026-01-21 03:05:06 --> Model "User_model" initialized
INFO - 2026-01-21 09:05:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:05:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:05:06 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:05:06 --> Controller Class Initialized
INFO - 2026-01-21 09:05:06 --> Model "Download_model" initialized
INFO - 2026-01-21 09:05:06 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:05:06 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:05:06 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:05:06"}
INFO - 2026-01-21 03:05:28 --> Config Class Initialized
INFO - 2026-01-21 03:05:28 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:05:28 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:05:28 --> Utf8 Class Initialized
INFO - 2026-01-21 03:05:28 --> URI Class Initialized
INFO - 2026-01-21 03:05:28 --> Router Class Initialized
INFO - 2026-01-21 03:05:28 --> Output Class Initialized
INFO - 2026-01-21 03:05:28 --> Security Class Initialized
DEBUG - 2026-01-21 03:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:05:28 --> CSRF cookie sent
INFO - 2026-01-21 03:05:28 --> Input Class Initialized
INFO - 2026-01-21 03:05:28 --> Language Class Initialized
INFO - 2026-01-21 03:05:28 --> Loader Class Initialized
INFO - 2026-01-21 03:05:28 --> Helper loaded: url_helper
INFO - 2026-01-21 03:05:28 --> Helper loaded: text_helper
INFO - 2026-01-21 03:05:28 --> Helper loaded: string_helper
INFO - 2026-01-21 03:05:28 --> Helper loaded: form_helper
INFO - 2026-01-21 03:05:28 --> Helper loaded: download_helper
INFO - 2026-01-21 03:05:28 --> Helper loaded: security_helper
INFO - 2026-01-21 03:05:28 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:05:28 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:05:28 --> Form Validation Class Initialized
INFO - 2026-01-21 03:05:28 --> Model "User_model" initialized
INFO - 2026-01-21 09:05:28 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:05:28 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:05:28 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:05:28 --> Controller Class Initialized
INFO - 2026-01-21 09:05:28 --> Model "Download_model" initialized
INFO - 2026-01-21 09:05:28 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:05:28 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:05:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:05:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:05:28 --> Model "Log_model" initialized
INFO - 2026-01-21 09:05:28 --> Final output sent to browser
DEBUG - 2026-01-21 09:05:28 --> Total execution time: 0.1926
INFO - 2026-01-21 03:05:30 --> Config Class Initialized
INFO - 2026-01-21 03:05:30 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:05:30 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:05:30 --> Utf8 Class Initialized
INFO - 2026-01-21 03:05:30 --> URI Class Initialized
INFO - 2026-01-21 03:05:30 --> Router Class Initialized
INFO - 2026-01-21 03:05:30 --> Output Class Initialized
INFO - 2026-01-21 03:05:30 --> Security Class Initialized
DEBUG - 2026-01-21 03:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:05:30 --> CSRF cookie sent
INFO - 2026-01-21 03:05:30 --> Input Class Initialized
INFO - 2026-01-21 03:05:30 --> Language Class Initialized
INFO - 2026-01-21 03:05:30 --> Loader Class Initialized
INFO - 2026-01-21 03:05:30 --> Helper loaded: url_helper
INFO - 2026-01-21 03:05:30 --> Helper loaded: text_helper
INFO - 2026-01-21 03:05:30 --> Helper loaded: string_helper
INFO - 2026-01-21 03:05:30 --> Helper loaded: form_helper
INFO - 2026-01-21 03:05:30 --> Helper loaded: download_helper
INFO - 2026-01-21 03:05:30 --> Helper loaded: security_helper
INFO - 2026-01-21 03:05:30 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:05:30 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:05:30 --> Form Validation Class Initialized
INFO - 2026-01-21 03:05:30 --> Model "User_model" initialized
INFO - 2026-01-21 09:05:30 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:05:30 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:05:30 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:05:30 --> Controller Class Initialized
INFO - 2026-01-21 09:05:30 --> Model "Download_model" initialized
INFO - 2026-01-21 09:05:30 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:05:30 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:05:30 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:05:30"}
INFO - 2026-01-21 03:07:47 --> Config Class Initialized
INFO - 2026-01-21 03:07:47 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:07:47 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:07:47 --> Utf8 Class Initialized
INFO - 2026-01-21 03:07:47 --> URI Class Initialized
INFO - 2026-01-21 03:07:47 --> Router Class Initialized
INFO - 2026-01-21 03:07:47 --> Output Class Initialized
INFO - 2026-01-21 03:07:47 --> Security Class Initialized
DEBUG - 2026-01-21 03:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:07:47 --> CSRF cookie sent
INFO - 2026-01-21 03:07:47 --> Input Class Initialized
INFO - 2026-01-21 03:07:47 --> Language Class Initialized
INFO - 2026-01-21 03:07:47 --> Loader Class Initialized
INFO - 2026-01-21 03:07:47 --> Helper loaded: url_helper
INFO - 2026-01-21 03:07:47 --> Helper loaded: text_helper
INFO - 2026-01-21 03:07:47 --> Helper loaded: string_helper
INFO - 2026-01-21 03:07:47 --> Helper loaded: form_helper
INFO - 2026-01-21 03:07:47 --> Helper loaded: download_helper
INFO - 2026-01-21 03:07:47 --> Helper loaded: security_helper
INFO - 2026-01-21 03:07:47 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:07:47 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:07:47 --> Form Validation Class Initialized
INFO - 2026-01-21 03:07:47 --> Model "User_model" initialized
INFO - 2026-01-21 09:07:47 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:07:47 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:07:47 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:07:47 --> Controller Class Initialized
INFO - 2026-01-21 09:07:47 --> Model "Download_model" initialized
INFO - 2026-01-21 09:07:47 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:07:47 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:07:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:07:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:07:47 --> Model "Log_model" initialized
INFO - 2026-01-21 09:07:47 --> Final output sent to browser
DEBUG - 2026-01-21 09:07:47 --> Total execution time: 0.4818
INFO - 2026-01-21 03:07:49 --> Config Class Initialized
INFO - 2026-01-21 03:07:49 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:07:49 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:07:49 --> Utf8 Class Initialized
INFO - 2026-01-21 03:07:49 --> URI Class Initialized
INFO - 2026-01-21 03:07:49 --> Router Class Initialized
INFO - 2026-01-21 03:07:49 --> Output Class Initialized
INFO - 2026-01-21 03:07:49 --> Security Class Initialized
DEBUG - 2026-01-21 03:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:07:49 --> CSRF cookie sent
INFO - 2026-01-21 03:07:49 --> Input Class Initialized
INFO - 2026-01-21 03:07:49 --> Language Class Initialized
INFO - 2026-01-21 03:07:49 --> Loader Class Initialized
INFO - 2026-01-21 03:07:49 --> Helper loaded: url_helper
INFO - 2026-01-21 03:07:49 --> Helper loaded: text_helper
INFO - 2026-01-21 03:07:49 --> Helper loaded: string_helper
INFO - 2026-01-21 03:07:50 --> Helper loaded: form_helper
INFO - 2026-01-21 03:07:50 --> Helper loaded: download_helper
INFO - 2026-01-21 03:07:50 --> Helper loaded: security_helper
INFO - 2026-01-21 03:07:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:07:50 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:07:50 --> Form Validation Class Initialized
INFO - 2026-01-21 03:07:50 --> Model "User_model" initialized
INFO - 2026-01-21 09:07:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:07:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:07:50 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:07:50 --> Controller Class Initialized
INFO - 2026-01-21 09:07:50 --> Model "Download_model" initialized
INFO - 2026-01-21 09:07:50 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:07:50 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:07:50 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:07:50"}
INFO - 2026-01-21 03:08:48 --> Config Class Initialized
INFO - 2026-01-21 03:08:48 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:08:48 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:08:48 --> Utf8 Class Initialized
INFO - 2026-01-21 03:08:48 --> URI Class Initialized
INFO - 2026-01-21 03:08:48 --> Router Class Initialized
INFO - 2026-01-21 03:08:48 --> Output Class Initialized
INFO - 2026-01-21 03:08:48 --> Security Class Initialized
DEBUG - 2026-01-21 03:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:08:48 --> CSRF cookie sent
INFO - 2026-01-21 03:08:48 --> Input Class Initialized
INFO - 2026-01-21 03:08:48 --> Language Class Initialized
INFO - 2026-01-21 03:08:48 --> Loader Class Initialized
INFO - 2026-01-21 03:08:48 --> Helper loaded: url_helper
INFO - 2026-01-21 03:08:48 --> Helper loaded: text_helper
INFO - 2026-01-21 03:08:48 --> Helper loaded: string_helper
INFO - 2026-01-21 03:08:48 --> Helper loaded: form_helper
INFO - 2026-01-21 03:08:48 --> Helper loaded: download_helper
INFO - 2026-01-21 03:08:48 --> Helper loaded: security_helper
INFO - 2026-01-21 03:08:48 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:08:48 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:08:48 --> Form Validation Class Initialized
INFO - 2026-01-21 03:08:48 --> Model "User_model" initialized
INFO - 2026-01-21 09:08:48 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:08:48 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:08:48 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:08:48 --> Controller Class Initialized
INFO - 2026-01-21 09:08:48 --> Model "Download_model" initialized
INFO - 2026-01-21 09:08:48 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:08:48 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:08:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:08:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:08:48 --> Model "Log_model" initialized
INFO - 2026-01-21 09:08:48 --> Final output sent to browser
DEBUG - 2026-01-21 09:08:48 --> Total execution time: 0.2816
INFO - 2026-01-21 03:09:07 --> Config Class Initialized
INFO - 2026-01-21 03:09:07 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:09:07 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:09:07 --> Utf8 Class Initialized
INFO - 2026-01-21 03:09:07 --> URI Class Initialized
INFO - 2026-01-21 03:09:07 --> Router Class Initialized
INFO - 2026-01-21 03:09:07 --> Output Class Initialized
INFO - 2026-01-21 03:09:07 --> Security Class Initialized
DEBUG - 2026-01-21 03:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:09:07 --> CSRF cookie sent
INFO - 2026-01-21 03:09:07 --> Input Class Initialized
INFO - 2026-01-21 03:09:07 --> Language Class Initialized
INFO - 2026-01-21 03:09:07 --> Loader Class Initialized
INFO - 2026-01-21 03:09:07 --> Helper loaded: url_helper
INFO - 2026-01-21 03:09:07 --> Helper loaded: text_helper
INFO - 2026-01-21 03:09:07 --> Helper loaded: string_helper
INFO - 2026-01-21 03:09:07 --> Helper loaded: form_helper
INFO - 2026-01-21 03:09:07 --> Helper loaded: download_helper
INFO - 2026-01-21 03:09:07 --> Helper loaded: security_helper
INFO - 2026-01-21 03:09:07 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:09:07 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:09:07 --> Form Validation Class Initialized
INFO - 2026-01-21 03:09:07 --> Model "User_model" initialized
INFO - 2026-01-21 09:09:07 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:09:07 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:09:07 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:09:07 --> Controller Class Initialized
INFO - 2026-01-21 09:09:07 --> Model "Download_model" initialized
INFO - 2026-01-21 09:09:07 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:09:07 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:09:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:09:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:09:08 --> Model "Log_model" initialized
INFO - 2026-01-21 09:09:08 --> Final output sent to browser
DEBUG - 2026-01-21 09:09:08 --> Total execution time: 0.9917
INFO - 2026-01-21 03:09:11 --> Config Class Initialized
INFO - 2026-01-21 03:09:11 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:09:11 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:09:11 --> Utf8 Class Initialized
INFO - 2026-01-21 03:09:11 --> URI Class Initialized
INFO - 2026-01-21 03:09:11 --> Router Class Initialized
INFO - 2026-01-21 03:09:11 --> Output Class Initialized
INFO - 2026-01-21 03:09:11 --> Security Class Initialized
DEBUG - 2026-01-21 03:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:09:11 --> CSRF cookie sent
INFO - 2026-01-21 03:09:11 --> Input Class Initialized
INFO - 2026-01-21 03:09:11 --> Language Class Initialized
INFO - 2026-01-21 03:09:11 --> Loader Class Initialized
INFO - 2026-01-21 03:09:11 --> Helper loaded: url_helper
INFO - 2026-01-21 03:09:11 --> Helper loaded: text_helper
INFO - 2026-01-21 03:09:11 --> Helper loaded: string_helper
INFO - 2026-01-21 03:09:11 --> Helper loaded: form_helper
INFO - 2026-01-21 03:09:11 --> Helper loaded: download_helper
INFO - 2026-01-21 03:09:11 --> Helper loaded: security_helper
INFO - 2026-01-21 03:09:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:09:11 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:09:11 --> Form Validation Class Initialized
INFO - 2026-01-21 03:09:11 --> Model "User_model" initialized
INFO - 2026-01-21 09:09:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:09:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:09:11 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:09:11 --> Controller Class Initialized
INFO - 2026-01-21 09:09:11 --> Model "Download_model" initialized
INFO - 2026-01-21 09:09:11 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:09:11 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:09:11 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"181","filename":"UNDANG-UNDANG_NO_14_TAHUN_2005_TENTANG_GURU_DAN_DOSEN.pdf","timestamp":"2026-01-21 09:09:11"}
INFO - 2026-01-21 03:09:21 --> Config Class Initialized
INFO - 2026-01-21 03:09:21 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:09:21 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:09:21 --> Utf8 Class Initialized
INFO - 2026-01-21 03:09:21 --> URI Class Initialized
INFO - 2026-01-21 03:09:21 --> Router Class Initialized
INFO - 2026-01-21 03:09:21 --> Output Class Initialized
INFO - 2026-01-21 03:09:21 --> Security Class Initialized
DEBUG - 2026-01-21 03:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:09:21 --> CSRF cookie sent
INFO - 2026-01-21 03:09:21 --> Input Class Initialized
INFO - 2026-01-21 03:09:21 --> Language Class Initialized
INFO - 2026-01-21 03:09:21 --> Loader Class Initialized
INFO - 2026-01-21 03:09:21 --> Helper loaded: url_helper
INFO - 2026-01-21 03:09:21 --> Helper loaded: text_helper
INFO - 2026-01-21 03:09:21 --> Helper loaded: string_helper
INFO - 2026-01-21 03:09:21 --> Helper loaded: form_helper
INFO - 2026-01-21 03:09:21 --> Helper loaded: download_helper
INFO - 2026-01-21 03:09:21 --> Helper loaded: security_helper
INFO - 2026-01-21 03:09:21 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:09:21 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:09:21 --> Form Validation Class Initialized
INFO - 2026-01-21 03:09:21 --> Model "User_model" initialized
INFO - 2026-01-21 09:09:21 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:09:21 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:09:21 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:09:21 --> Controller Class Initialized
INFO - 2026-01-21 09:09:21 --> Model "Download_model" initialized
INFO - 2026-01-21 09:09:21 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:09:21 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:09:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:09:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:09:21 --> Model "Log_model" initialized
INFO - 2026-01-21 09:09:21 --> Final output sent to browser
DEBUG - 2026-01-21 09:09:21 --> Total execution time: 0.2140
INFO - 2026-01-21 03:09:30 --> Config Class Initialized
INFO - 2026-01-21 03:09:30 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:09:30 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:09:30 --> Utf8 Class Initialized
INFO - 2026-01-21 03:09:30 --> URI Class Initialized
INFO - 2026-01-21 03:09:30 --> Router Class Initialized
INFO - 2026-01-21 03:09:30 --> Output Class Initialized
INFO - 2026-01-21 03:09:30 --> Security Class Initialized
DEBUG - 2026-01-21 03:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:09:30 --> CSRF cookie sent
INFO - 2026-01-21 03:09:30 --> Input Class Initialized
INFO - 2026-01-21 03:09:30 --> Language Class Initialized
INFO - 2026-01-21 03:09:30 --> Loader Class Initialized
INFO - 2026-01-21 03:09:30 --> Helper loaded: url_helper
INFO - 2026-01-21 03:09:30 --> Helper loaded: text_helper
INFO - 2026-01-21 03:09:30 --> Helper loaded: string_helper
INFO - 2026-01-21 03:09:30 --> Helper loaded: form_helper
INFO - 2026-01-21 03:09:30 --> Helper loaded: download_helper
INFO - 2026-01-21 03:09:30 --> Helper loaded: security_helper
INFO - 2026-01-21 03:09:30 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:09:30 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:09:30 --> Form Validation Class Initialized
INFO - 2026-01-21 03:09:30 --> Model "User_model" initialized
INFO - 2026-01-21 09:09:30 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:09:30 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:09:30 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:09:30 --> Controller Class Initialized
INFO - 2026-01-21 09:09:30 --> Model "Download_model" initialized
INFO - 2026-01-21 09:09:30 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:09:30 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:09:30 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:09:30"}
INFO - 2026-01-21 03:09:39 --> Config Class Initialized
INFO - 2026-01-21 03:09:39 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:09:39 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:09:39 --> Utf8 Class Initialized
INFO - 2026-01-21 03:09:39 --> URI Class Initialized
INFO - 2026-01-21 03:09:39 --> Router Class Initialized
INFO - 2026-01-21 03:09:39 --> Output Class Initialized
INFO - 2026-01-21 03:09:39 --> Security Class Initialized
DEBUG - 2026-01-21 03:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:09:39 --> CSRF cookie sent
INFO - 2026-01-21 03:09:39 --> Input Class Initialized
INFO - 2026-01-21 03:09:39 --> Language Class Initialized
INFO - 2026-01-21 03:09:39 --> Loader Class Initialized
INFO - 2026-01-21 03:09:39 --> Helper loaded: url_helper
INFO - 2026-01-21 03:09:39 --> Helper loaded: text_helper
INFO - 2026-01-21 03:09:39 --> Helper loaded: string_helper
INFO - 2026-01-21 03:09:39 --> Helper loaded: form_helper
INFO - 2026-01-21 03:09:39 --> Helper loaded: download_helper
INFO - 2026-01-21 03:09:39 --> Helper loaded: security_helper
INFO - 2026-01-21 03:09:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:09:39 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:09:39 --> Form Validation Class Initialized
INFO - 2026-01-21 03:09:39 --> Model "User_model" initialized
INFO - 2026-01-21 09:09:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:09:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:09:39 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:09:39 --> Controller Class Initialized
INFO - 2026-01-21 09:09:39 --> Model "Download_model" initialized
INFO - 2026-01-21 09:09:39 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:09:39 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:09:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:09:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:09:40 --> Model "Log_model" initialized
INFO - 2026-01-21 09:09:40 --> Final output sent to browser
DEBUG - 2026-01-21 09:09:40 --> Total execution time: 0.1948
INFO - 2026-01-21 03:09:41 --> Config Class Initialized
INFO - 2026-01-21 03:09:41 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:09:41 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:09:41 --> Utf8 Class Initialized
INFO - 2026-01-21 03:09:41 --> URI Class Initialized
INFO - 2026-01-21 03:09:41 --> Router Class Initialized
INFO - 2026-01-21 03:09:41 --> Output Class Initialized
INFO - 2026-01-21 03:09:41 --> Security Class Initialized
DEBUG - 2026-01-21 03:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:09:41 --> CSRF cookie sent
INFO - 2026-01-21 03:09:41 --> Input Class Initialized
INFO - 2026-01-21 03:09:41 --> Language Class Initialized
INFO - 2026-01-21 03:09:41 --> Loader Class Initialized
INFO - 2026-01-21 03:09:41 --> Helper loaded: url_helper
INFO - 2026-01-21 03:09:41 --> Helper loaded: text_helper
INFO - 2026-01-21 03:09:41 --> Helper loaded: string_helper
INFO - 2026-01-21 03:09:41 --> Helper loaded: form_helper
INFO - 2026-01-21 03:09:41 --> Helper loaded: download_helper
INFO - 2026-01-21 03:09:41 --> Helper loaded: security_helper
INFO - 2026-01-21 03:09:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:09:41 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:09:41 --> Form Validation Class Initialized
INFO - 2026-01-21 03:09:41 --> Model "User_model" initialized
INFO - 2026-01-21 09:09:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:09:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:09:41 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:09:41 --> Controller Class Initialized
INFO - 2026-01-21 09:09:41 --> Model "Download_model" initialized
INFO - 2026-01-21 09:09:41 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:09:41 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:09:41 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:09:41"}
INFO - 2026-01-21 03:09:59 --> Config Class Initialized
INFO - 2026-01-21 03:09:59 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:09:59 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:09:59 --> Utf8 Class Initialized
INFO - 2026-01-21 03:09:59 --> URI Class Initialized
INFO - 2026-01-21 03:09:59 --> Router Class Initialized
INFO - 2026-01-21 03:09:59 --> Output Class Initialized
INFO - 2026-01-21 03:09:59 --> Security Class Initialized
DEBUG - 2026-01-21 03:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:09:59 --> CSRF cookie sent
INFO - 2026-01-21 03:09:59 --> Input Class Initialized
INFO - 2026-01-21 03:09:59 --> Language Class Initialized
INFO - 2026-01-21 03:09:59 --> Loader Class Initialized
INFO - 2026-01-21 03:09:59 --> Helper loaded: url_helper
INFO - 2026-01-21 03:09:59 --> Helper loaded: text_helper
INFO - 2026-01-21 03:09:59 --> Helper loaded: string_helper
INFO - 2026-01-21 03:09:59 --> Helper loaded: form_helper
INFO - 2026-01-21 03:09:59 --> Helper loaded: download_helper
INFO - 2026-01-21 03:09:59 --> Helper loaded: security_helper
INFO - 2026-01-21 03:09:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:10:00 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:10:00 --> Form Validation Class Initialized
INFO - 2026-01-21 03:10:00 --> Model "User_model" initialized
INFO - 2026-01-21 09:10:00 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:10:00 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:10:00 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:10:00 --> Controller Class Initialized
INFO - 2026-01-21 09:10:00 --> Model "Download_model" initialized
INFO - 2026-01-21 09:10:00 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:10:00 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:10:00 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:10:00"}
INFO - 2026-01-21 03:11:47 --> Config Class Initialized
INFO - 2026-01-21 03:11:47 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:11:47 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:11:47 --> Utf8 Class Initialized
INFO - 2026-01-21 03:11:47 --> URI Class Initialized
INFO - 2026-01-21 03:11:47 --> Router Class Initialized
INFO - 2026-01-21 03:11:47 --> Output Class Initialized
INFO - 2026-01-21 03:11:47 --> Security Class Initialized
DEBUG - 2026-01-21 03:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:11:47 --> CSRF cookie sent
INFO - 2026-01-21 03:11:47 --> Input Class Initialized
INFO - 2026-01-21 03:11:47 --> Language Class Initialized
INFO - 2026-01-21 03:11:47 --> Loader Class Initialized
INFO - 2026-01-21 03:11:47 --> Helper loaded: url_helper
INFO - 2026-01-21 03:11:47 --> Helper loaded: text_helper
INFO - 2026-01-21 03:11:47 --> Helper loaded: string_helper
INFO - 2026-01-21 03:11:47 --> Helper loaded: form_helper
INFO - 2026-01-21 03:11:47 --> Helper loaded: download_helper
INFO - 2026-01-21 03:11:47 --> Helper loaded: security_helper
INFO - 2026-01-21 03:11:47 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:11:47 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:11:47 --> Form Validation Class Initialized
INFO - 2026-01-21 03:11:47 --> Model "User_model" initialized
INFO - 2026-01-21 09:11:47 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:11:47 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:11:47 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:11:47 --> Controller Class Initialized
INFO - 2026-01-21 09:11:47 --> Model "Download_model" initialized
INFO - 2026-01-21 09:11:47 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:11:47 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:11:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:11:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:11:48 --> Model "Log_model" initialized
INFO - 2026-01-21 09:11:48 --> Final output sent to browser
DEBUG - 2026-01-21 09:11:48 --> Total execution time: 0.4737
INFO - 2026-01-21 03:12:00 --> Config Class Initialized
INFO - 2026-01-21 03:12:00 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:12:00 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:12:00 --> Utf8 Class Initialized
INFO - 2026-01-21 03:12:00 --> URI Class Initialized
INFO - 2026-01-21 03:12:00 --> Router Class Initialized
INFO - 2026-01-21 03:12:00 --> Output Class Initialized
INFO - 2026-01-21 03:12:00 --> Security Class Initialized
DEBUG - 2026-01-21 03:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:12:00 --> CSRF cookie sent
INFO - 2026-01-21 03:12:00 --> Input Class Initialized
INFO - 2026-01-21 03:12:00 --> Language Class Initialized
INFO - 2026-01-21 03:12:00 --> Loader Class Initialized
INFO - 2026-01-21 03:12:00 --> Helper loaded: url_helper
INFO - 2026-01-21 03:12:00 --> Helper loaded: text_helper
INFO - 2026-01-21 03:12:00 --> Helper loaded: string_helper
INFO - 2026-01-21 03:12:00 --> Helper loaded: form_helper
INFO - 2026-01-21 03:12:00 --> Helper loaded: download_helper
INFO - 2026-01-21 03:12:00 --> Helper loaded: security_helper
INFO - 2026-01-21 03:12:00 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:12:00 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:12:00 --> Form Validation Class Initialized
INFO - 2026-01-21 03:12:00 --> Model "User_model" initialized
INFO - 2026-01-21 09:12:00 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:12:00 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:12:00 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:12:00 --> Controller Class Initialized
INFO - 2026-01-21 09:12:00 --> Model "Download_model" initialized
INFO - 2026-01-21 09:12:00 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:12:00 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:12:00 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"103","filename":"Piagam_Penghargaan_IKPA.pdf","timestamp":"2026-01-21 09:12:00"}
INFO - 2026-01-21 03:12:19 --> Config Class Initialized
INFO - 2026-01-21 03:12:19 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:12:19 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:12:19 --> Utf8 Class Initialized
INFO - 2026-01-21 03:12:19 --> URI Class Initialized
DEBUG - 2026-01-21 03:12:19 --> No URI present. Default controller set.
INFO - 2026-01-21 03:12:19 --> Router Class Initialized
INFO - 2026-01-21 03:12:19 --> Output Class Initialized
INFO - 2026-01-21 03:12:19 --> Security Class Initialized
DEBUG - 2026-01-21 03:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:12:19 --> CSRF cookie sent
INFO - 2026-01-21 03:12:19 --> Input Class Initialized
INFO - 2026-01-21 03:12:19 --> Language Class Initialized
INFO - 2026-01-21 03:12:19 --> Loader Class Initialized
INFO - 2026-01-21 03:12:19 --> Helper loaded: url_helper
INFO - 2026-01-21 03:12:19 --> Helper loaded: text_helper
INFO - 2026-01-21 03:12:19 --> Helper loaded: string_helper
INFO - 2026-01-21 03:12:19 --> Helper loaded: form_helper
INFO - 2026-01-21 03:12:19 --> Helper loaded: download_helper
INFO - 2026-01-21 03:12:19 --> Helper loaded: security_helper
INFO - 2026-01-21 03:12:19 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:12:19 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:12:19 --> Form Validation Class Initialized
INFO - 2026-01-21 03:12:19 --> Model "User_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:12:19 --> Controller Class Initialized
INFO - 2026-01-21 09:12:19 --> Model "Berita_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Galeri_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Video_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Agenda_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Tautan_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Mitra_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:12:19 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 09:12:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 09:12:19 --> Pagination Class Initialized
INFO - 2026-01-21 09:12:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 09:12:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:12:19 --> Model "Log_model" initialized
INFO - 2026-01-21 09:12:19 --> Final output sent to browser
DEBUG - 2026-01-21 09:12:19 --> Total execution time: 0.2691
INFO - 2026-01-21 03:12:45 --> Config Class Initialized
INFO - 2026-01-21 03:12:45 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:12:45 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:12:45 --> Utf8 Class Initialized
INFO - 2026-01-21 03:12:45 --> URI Class Initialized
INFO - 2026-01-21 03:12:45 --> Router Class Initialized
INFO - 2026-01-21 03:12:45 --> Output Class Initialized
INFO - 2026-01-21 03:12:45 --> Security Class Initialized
DEBUG - 2026-01-21 03:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:12:45 --> CSRF cookie sent
INFO - 2026-01-21 03:12:45 --> Input Class Initialized
INFO - 2026-01-21 03:12:45 --> Language Class Initialized
INFO - 2026-01-21 03:12:45 --> Loader Class Initialized
INFO - 2026-01-21 03:12:45 --> Helper loaded: url_helper
INFO - 2026-01-21 03:12:45 --> Helper loaded: text_helper
INFO - 2026-01-21 03:12:45 --> Helper loaded: string_helper
INFO - 2026-01-21 03:12:45 --> Helper loaded: form_helper
INFO - 2026-01-21 03:12:45 --> Helper loaded: download_helper
INFO - 2026-01-21 03:12:45 --> Helper loaded: security_helper
INFO - 2026-01-21 03:12:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:12:45 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:12:45 --> Form Validation Class Initialized
INFO - 2026-01-21 03:12:46 --> Model "User_model" initialized
INFO - 2026-01-21 09:12:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:12:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:12:46 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:12:46 --> Controller Class Initialized
INFO - 2026-01-21 09:12:46 --> Model "Pages_model" initialized
INFO - 2026-01-21 09:12:46 --> Model "Berita_model" initialized
INFO - 2026-01-21 09:12:46 --> Model "Download_model" initialized
INFO - 2026-01-21 09:12:46 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:12:46 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:12:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2026-01-21 09:12:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:12:46 --> Model "Log_model" initialized
INFO - 2026-01-21 09:12:46 --> Final output sent to browser
DEBUG - 2026-01-21 09:12:46 --> Total execution time: 0.1930
INFO - 2026-01-21 03:12:58 --> Config Class Initialized
INFO - 2026-01-21 03:12:58 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:12:58 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:12:58 --> Utf8 Class Initialized
INFO - 2026-01-21 03:12:58 --> URI Class Initialized
INFO - 2026-01-21 03:12:58 --> Router Class Initialized
INFO - 2026-01-21 03:12:58 --> Output Class Initialized
INFO - 2026-01-21 03:12:58 --> Security Class Initialized
DEBUG - 2026-01-21 03:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:12:58 --> CSRF cookie sent
INFO - 2026-01-21 03:12:58 --> Input Class Initialized
INFO - 2026-01-21 03:12:58 --> Language Class Initialized
INFO - 2026-01-21 03:12:58 --> Loader Class Initialized
INFO - 2026-01-21 03:12:58 --> Helper loaded: url_helper
INFO - 2026-01-21 03:12:58 --> Helper loaded: text_helper
INFO - 2026-01-21 03:12:58 --> Helper loaded: string_helper
INFO - 2026-01-21 03:12:58 --> Helper loaded: form_helper
INFO - 2026-01-21 03:12:58 --> Helper loaded: download_helper
INFO - 2026-01-21 03:12:58 --> Helper loaded: security_helper
INFO - 2026-01-21 03:12:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:12:58 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:12:58 --> Form Validation Class Initialized
INFO - 2026-01-21 03:12:58 --> Model "User_model" initialized
INFO - 2026-01-21 09:12:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:12:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:12:58 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:12:58 --> Controller Class Initialized
INFO - 2026-01-21 09:12:58 --> Model "Pusat_model" initialized
INFO - 2026-01-21 09:12:58 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:12:58 --> Model "Sdm_model" initialized
INFO - 2026-01-21 09:12:58 --> Model "Sdm_pusat_model" initialized
INFO - 2026-01-21 09:12:58 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2026-01-21 09:12:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2026-01-21 09:12:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:12:58 --> Model "Log_model" initialized
INFO - 2026-01-21 09:12:58 --> Final output sent to browser
DEBUG - 2026-01-21 09:12:58 --> Total execution time: 0.1745
INFO - 2026-01-21 03:13:08 --> Config Class Initialized
INFO - 2026-01-21 03:13:08 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:13:08 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:13:08 --> Utf8 Class Initialized
INFO - 2026-01-21 03:13:08 --> URI Class Initialized
INFO - 2026-01-21 03:13:08 --> Router Class Initialized
INFO - 2026-01-21 03:13:08 --> Output Class Initialized
INFO - 2026-01-21 03:13:08 --> Security Class Initialized
DEBUG - 2026-01-21 03:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:13:08 --> CSRF cookie sent
INFO - 2026-01-21 03:13:08 --> Input Class Initialized
INFO - 2026-01-21 03:13:08 --> Language Class Initialized
INFO - 2026-01-21 03:13:08 --> Loader Class Initialized
INFO - 2026-01-21 03:13:08 --> Helper loaded: url_helper
INFO - 2026-01-21 03:13:08 --> Helper loaded: text_helper
INFO - 2026-01-21 03:13:08 --> Helper loaded: string_helper
INFO - 2026-01-21 03:13:08 --> Helper loaded: form_helper
INFO - 2026-01-21 03:13:08 --> Helper loaded: download_helper
INFO - 2026-01-21 03:13:08 --> Helper loaded: security_helper
INFO - 2026-01-21 03:13:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:13:08 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:13:08 --> Form Validation Class Initialized
INFO - 2026-01-21 03:13:08 --> Model "User_model" initialized
INFO - 2026-01-21 09:13:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:13:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:13:08 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:13:08 --> Controller Class Initialized
INFO - 2026-01-21 09:13:08 --> Model "Unit_model" initialized
INFO - 2026-01-21 09:13:08 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:13:08 --> Model "Sdm_model" initialized
INFO - 2026-01-21 09:13:08 --> Model "Sdm_unit_model" initialized
INFO - 2026-01-21 09:13:08 --> Query SDM berhasil untuk unit: Unit Pengelola Usaha, Total: 1
INFO - 2026-01-21 09:13:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\unit/list.php
INFO - 2026-01-21 09:13:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:13:08 --> Model "Log_model" initialized
INFO - 2026-01-21 09:13:08 --> Final output sent to browser
DEBUG - 2026-01-21 09:13:08 --> Total execution time: 0.2052
INFO - 2026-01-21 03:13:20 --> Config Class Initialized
INFO - 2026-01-21 03:13:20 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:13:20 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:13:20 --> Utf8 Class Initialized
INFO - 2026-01-21 03:13:20 --> URI Class Initialized
INFO - 2026-01-21 03:13:20 --> Router Class Initialized
INFO - 2026-01-21 03:13:20 --> Output Class Initialized
INFO - 2026-01-21 03:13:20 --> Security Class Initialized
DEBUG - 2026-01-21 03:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:13:20 --> CSRF cookie sent
INFO - 2026-01-21 03:13:20 --> Input Class Initialized
INFO - 2026-01-21 03:13:20 --> Language Class Initialized
INFO - 2026-01-21 03:13:20 --> Loader Class Initialized
INFO - 2026-01-21 03:13:20 --> Helper loaded: url_helper
INFO - 2026-01-21 03:13:20 --> Helper loaded: text_helper
INFO - 2026-01-21 03:13:20 --> Helper loaded: string_helper
INFO - 2026-01-21 03:13:20 --> Helper loaded: form_helper
INFO - 2026-01-21 03:13:20 --> Helper loaded: download_helper
INFO - 2026-01-21 03:13:20 --> Helper loaded: security_helper
INFO - 2026-01-21 03:13:20 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:13:20 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:13:20 --> Form Validation Class Initialized
INFO - 2026-01-21 03:13:20 --> Model "User_model" initialized
INFO - 2026-01-21 09:13:20 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:13:20 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:13:20 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:13:20 --> Controller Class Initialized
INFO - 2026-01-21 09:13:20 --> Model "Sdm_model" initialized
INFO - 2026-01-21 09:13:20 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-21 09:13:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-21 09:13:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:13:20 --> Model "Log_model" initialized
INFO - 2026-01-21 09:13:20 --> Final output sent to browser
DEBUG - 2026-01-21 09:13:20 --> Total execution time: 0.1849
INFO - 2026-01-21 03:13:29 --> Config Class Initialized
INFO - 2026-01-21 03:13:29 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:13:29 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:13:29 --> Utf8 Class Initialized
INFO - 2026-01-21 03:13:29 --> URI Class Initialized
INFO - 2026-01-21 03:13:29 --> Router Class Initialized
INFO - 2026-01-21 03:13:29 --> Output Class Initialized
INFO - 2026-01-21 03:13:29 --> Security Class Initialized
DEBUG - 2026-01-21 03:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:13:29 --> CSRF cookie sent
INFO - 2026-01-21 03:13:29 --> Input Class Initialized
INFO - 2026-01-21 03:13:29 --> Language Class Initialized
INFO - 2026-01-21 03:13:29 --> Loader Class Initialized
INFO - 2026-01-21 03:13:29 --> Helper loaded: url_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: text_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: string_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: form_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: download_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: security_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:13:29 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:13:29 --> Form Validation Class Initialized
INFO - 2026-01-21 03:13:29 --> Model "User_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:13:29 --> Controller Class Initialized
INFO - 2026-01-21 09:13:29 --> Model "Pages_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Berita_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Download_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:13:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-21 09:13:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:13:29 --> Model "Log_model" initialized
INFO - 2026-01-21 09:13:29 --> Final output sent to browser
DEBUG - 2026-01-21 09:13:29 --> Total execution time: 0.1696
INFO - 2026-01-21 03:13:29 --> Config Class Initialized
INFO - 2026-01-21 03:13:29 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:13:29 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:13:29 --> Utf8 Class Initialized
INFO - 2026-01-21 03:13:29 --> URI Class Initialized
INFO - 2026-01-21 03:13:29 --> Router Class Initialized
INFO - 2026-01-21 03:13:29 --> Output Class Initialized
INFO - 2026-01-21 03:13:29 --> Security Class Initialized
DEBUG - 2026-01-21 03:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:13:29 --> CSRF cookie sent
INFO - 2026-01-21 03:13:29 --> Input Class Initialized
INFO - 2026-01-21 03:13:29 --> Language Class Initialized
INFO - 2026-01-21 03:13:29 --> Loader Class Initialized
INFO - 2026-01-21 03:13:29 --> Helper loaded: url_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: text_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: string_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: form_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: download_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: security_helper
INFO - 2026-01-21 03:13:29 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:13:29 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:13:29 --> Form Validation Class Initialized
INFO - 2026-01-21 03:13:29 --> Model "User_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:13:29 --> Controller Class Initialized
INFO - 2026-01-21 09:13:29 --> Model "Berita_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Galeri_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Video_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Agenda_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Tautan_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Mitra_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:13:29 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 09:13:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-21 09:13:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:13:29 --> Model "Log_model" initialized
INFO - 2026-01-21 09:13:29 --> Final output sent to browser
DEBUG - 2026-01-21 09:13:29 --> Total execution time: 0.1115
INFO - 2026-01-21 03:13:38 --> Config Class Initialized
INFO - 2026-01-21 03:13:38 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:13:38 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:13:38 --> Utf8 Class Initialized
INFO - 2026-01-21 03:13:38 --> URI Class Initialized
INFO - 2026-01-21 03:13:38 --> Router Class Initialized
INFO - 2026-01-21 03:13:38 --> Output Class Initialized
INFO - 2026-01-21 03:13:38 --> Security Class Initialized
DEBUG - 2026-01-21 03:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:13:38 --> CSRF cookie sent
INFO - 2026-01-21 03:13:38 --> Input Class Initialized
INFO - 2026-01-21 03:13:38 --> Language Class Initialized
INFO - 2026-01-21 03:13:39 --> Loader Class Initialized
INFO - 2026-01-21 03:13:39 --> Helper loaded: url_helper
INFO - 2026-01-21 03:13:39 --> Helper loaded: text_helper
INFO - 2026-01-21 03:13:39 --> Helper loaded: string_helper
INFO - 2026-01-21 03:13:39 --> Helper loaded: form_helper
INFO - 2026-01-21 03:13:39 --> Helper loaded: download_helper
INFO - 2026-01-21 03:13:39 --> Helper loaded: security_helper
INFO - 2026-01-21 03:13:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:13:39 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:13:39 --> Form Validation Class Initialized
INFO - 2026-01-21 03:13:39 --> Model "User_model" initialized
INFO - 2026-01-21 09:13:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:13:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:13:39 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:13:39 --> Controller Class Initialized
INFO - 2026-01-21 09:13:39 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 09:13:39 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:13:39 --> Model "Sdm_model" initialized
INFO - 2026-01-21 09:13:39 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 09:13:39 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-21 09:13:39 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 09:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 09:13:39 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-21 09:13:39 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-21 09:13:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-21 09:13:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:13:39 --> Model "Log_model" initialized
INFO - 2026-01-21 09:13:39 --> Final output sent to browser
DEBUG - 2026-01-21 09:13:39 --> Total execution time: 0.1686
INFO - 2026-01-21 03:13:51 --> Config Class Initialized
INFO - 2026-01-21 03:13:51 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:13:51 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:13:51 --> Utf8 Class Initialized
INFO - 2026-01-21 03:13:51 --> URI Class Initialized
INFO - 2026-01-21 03:13:51 --> Router Class Initialized
INFO - 2026-01-21 03:13:51 --> Output Class Initialized
INFO - 2026-01-21 03:13:51 --> Security Class Initialized
DEBUG - 2026-01-21 03:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:13:51 --> CSRF cookie sent
INFO - 2026-01-21 03:13:51 --> Input Class Initialized
INFO - 2026-01-21 03:13:51 --> Language Class Initialized
INFO - 2026-01-21 03:13:51 --> Loader Class Initialized
INFO - 2026-01-21 03:13:51 --> Helper loaded: url_helper
INFO - 2026-01-21 03:13:51 --> Helper loaded: text_helper
INFO - 2026-01-21 03:13:51 --> Helper loaded: string_helper
INFO - 2026-01-21 03:13:51 --> Helper loaded: form_helper
INFO - 2026-01-21 03:13:51 --> Helper loaded: download_helper
INFO - 2026-01-21 03:13:51 --> Helper loaded: security_helper
INFO - 2026-01-21 03:13:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:13:51 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:13:51 --> Form Validation Class Initialized
INFO - 2026-01-21 03:13:51 --> Model "User_model" initialized
INFO - 2026-01-21 09:13:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:13:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:13:51 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:13:51 --> Controller Class Initialized
INFO - 2026-01-21 09:13:51 --> Model "Sdm_model" initialized
INFO - 2026-01-21 09:13:51 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-21 09:13:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2026-01-21 09:13:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:13:51 --> Model "Log_model" initialized
INFO - 2026-01-21 09:13:51 --> Final output sent to browser
DEBUG - 2026-01-21 09:13:51 --> Total execution time: 0.1513
INFO - 2026-01-21 03:13:54 --> Config Class Initialized
INFO - 2026-01-21 03:13:54 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:13:54 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:13:54 --> Utf8 Class Initialized
INFO - 2026-01-21 03:13:54 --> URI Class Initialized
INFO - 2026-01-21 03:13:54 --> Router Class Initialized
INFO - 2026-01-21 03:13:54 --> Output Class Initialized
INFO - 2026-01-21 03:13:54 --> Security Class Initialized
DEBUG - 2026-01-21 03:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:13:54 --> CSRF cookie sent
INFO - 2026-01-21 03:13:54 --> Input Class Initialized
INFO - 2026-01-21 03:13:54 --> Language Class Initialized
INFO - 2026-01-21 03:13:54 --> Loader Class Initialized
INFO - 2026-01-21 03:13:54 --> Helper loaded: url_helper
INFO - 2026-01-21 03:13:54 --> Helper loaded: text_helper
INFO - 2026-01-21 03:13:54 --> Helper loaded: string_helper
INFO - 2026-01-21 03:13:54 --> Helper loaded: form_helper
INFO - 2026-01-21 03:13:54 --> Helper loaded: download_helper
INFO - 2026-01-21 03:13:54 --> Helper loaded: security_helper
INFO - 2026-01-21 03:13:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:13:54 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:13:54 --> Form Validation Class Initialized
INFO - 2026-01-21 03:13:54 --> Model "User_model" initialized
INFO - 2026-01-21 09:13:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:13:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:13:54 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:13:54 --> Controller Class Initialized
INFO - 2026-01-21 09:13:54 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 09:13:54 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:13:54 --> Model "Sdm_model" initialized
INFO - 2026-01-21 09:13:54 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 09:13:55 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-21 09:13:55 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 09:13:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 09:13:55 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-21 09:13:55 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-21 09:13:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-21 09:13:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:13:55 --> Model "Log_model" initialized
INFO - 2026-01-21 09:13:55 --> Final output sent to browser
DEBUG - 2026-01-21 09:13:55 --> Total execution time: 0.2037
INFO - 2026-01-21 03:13:59 --> Config Class Initialized
INFO - 2026-01-21 03:13:59 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:13:59 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:13:59 --> Utf8 Class Initialized
INFO - 2026-01-21 03:13:59 --> URI Class Initialized
DEBUG - 2026-01-21 03:13:59 --> No URI present. Default controller set.
INFO - 2026-01-21 03:13:59 --> Router Class Initialized
INFO - 2026-01-21 03:13:59 --> Output Class Initialized
INFO - 2026-01-21 03:13:59 --> Security Class Initialized
DEBUG - 2026-01-21 03:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:13:59 --> CSRF cookie sent
INFO - 2026-01-21 03:13:59 --> Input Class Initialized
INFO - 2026-01-21 03:13:59 --> Language Class Initialized
INFO - 2026-01-21 03:13:59 --> Loader Class Initialized
INFO - 2026-01-21 03:13:59 --> Helper loaded: url_helper
INFO - 2026-01-21 03:13:59 --> Helper loaded: text_helper
INFO - 2026-01-21 03:13:59 --> Helper loaded: string_helper
INFO - 2026-01-21 03:13:59 --> Helper loaded: form_helper
INFO - 2026-01-21 03:13:59 --> Helper loaded: download_helper
INFO - 2026-01-21 03:13:59 --> Helper loaded: security_helper
INFO - 2026-01-21 03:13:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:13:59 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:13:59 --> Form Validation Class Initialized
INFO - 2026-01-21 03:13:59 --> Model "User_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:13:59 --> Controller Class Initialized
INFO - 2026-01-21 09:13:59 --> Model "Berita_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Galeri_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Video_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Agenda_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Tautan_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Mitra_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:13:59 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 09:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 09:13:59 --> Pagination Class Initialized
INFO - 2026-01-21 09:13:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 09:13:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:13:59 --> Model "Log_model" initialized
INFO - 2026-01-21 09:13:59 --> Final output sent to browser
DEBUG - 2026-01-21 09:13:59 --> Total execution time: 0.2385
INFO - 2026-01-21 03:14:21 --> Config Class Initialized
INFO - 2026-01-21 03:14:21 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:14:21 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:14:21 --> Utf8 Class Initialized
INFO - 2026-01-21 03:14:21 --> URI Class Initialized
INFO - 2026-01-21 03:14:21 --> Router Class Initialized
INFO - 2026-01-21 03:14:21 --> Output Class Initialized
INFO - 2026-01-21 03:14:21 --> Security Class Initialized
DEBUG - 2026-01-21 03:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:14:21 --> CSRF cookie sent
INFO - 2026-01-21 03:14:21 --> Input Class Initialized
INFO - 2026-01-21 03:14:21 --> Language Class Initialized
INFO - 2026-01-21 03:14:21 --> Loader Class Initialized
INFO - 2026-01-21 03:14:21 --> Helper loaded: url_helper
INFO - 2026-01-21 03:14:21 --> Helper loaded: text_helper
INFO - 2026-01-21 03:14:21 --> Helper loaded: string_helper
INFO - 2026-01-21 03:14:21 --> Helper loaded: form_helper
INFO - 2026-01-21 03:14:21 --> Helper loaded: download_helper
INFO - 2026-01-21 03:14:21 --> Helper loaded: security_helper
INFO - 2026-01-21 03:14:21 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:14:21 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:14:21 --> Form Validation Class Initialized
INFO - 2026-01-21 03:14:21 --> Model "User_model" initialized
INFO - 2026-01-21 09:14:21 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:14:21 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:14:21 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:14:21 --> Controller Class Initialized
INFO - 2026-01-21 09:14:21 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:14:21 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 09:14:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-21 09:14:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 09:14:21 --> Model "Log_model" initialized
INFO - 2026-01-21 09:14:21 --> Final output sent to browser
DEBUG - 2026-01-21 09:14:21 --> Total execution time: 0.1634
INFO - 2026-01-21 03:14:23 --> Config Class Initialized
INFO - 2026-01-21 03:14:23 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:14:23 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:14:23 --> Utf8 Class Initialized
INFO - 2026-01-21 03:14:23 --> URI Class Initialized
INFO - 2026-01-21 03:14:23 --> Router Class Initialized
INFO - 2026-01-21 03:14:23 --> Output Class Initialized
INFO - 2026-01-21 03:14:23 --> Security Class Initialized
DEBUG - 2026-01-21 03:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:14:23 --> CSRF cookie sent
INFO - 2026-01-21 03:14:23 --> Input Class Initialized
INFO - 2026-01-21 03:14:23 --> Language Class Initialized
INFO - 2026-01-21 03:14:23 --> Loader Class Initialized
INFO - 2026-01-21 03:14:23 --> Helper loaded: url_helper
INFO - 2026-01-21 03:14:23 --> Helper loaded: text_helper
INFO - 2026-01-21 03:14:23 --> Helper loaded: string_helper
INFO - 2026-01-21 03:14:23 --> Helper loaded: form_helper
INFO - 2026-01-21 03:14:23 --> Helper loaded: download_helper
INFO - 2026-01-21 03:14:23 --> Helper loaded: security_helper
INFO - 2026-01-21 03:14:23 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:14:23 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:14:24 --> Form Validation Class Initialized
INFO - 2026-01-21 03:14:24 --> Model "User_model" initialized
INFO - 2026-01-21 09:14:24 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:14:24 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:14:24 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:14:24 --> Controller Class Initialized
INFO - 2026-01-21 09:14:24 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:14:24 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 09:14:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-21 09:14:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 09:14:24 --> Model "Log_model" initialized
INFO - 2026-01-21 09:14:24 --> Final output sent to browser
DEBUG - 2026-01-21 09:14:24 --> Total execution time: 0.1324
INFO - 2026-01-21 03:14:36 --> Config Class Initialized
INFO - 2026-01-21 03:14:36 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:14:36 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:14:36 --> Utf8 Class Initialized
INFO - 2026-01-21 03:14:36 --> URI Class Initialized
INFO - 2026-01-21 03:14:36 --> Router Class Initialized
INFO - 2026-01-21 03:14:36 --> Output Class Initialized
INFO - 2026-01-21 03:14:36 --> Security Class Initialized
DEBUG - 2026-01-21 03:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:14:36 --> CSRF cookie sent
INFO - 2026-01-21 03:14:36 --> Input Class Initialized
INFO - 2026-01-21 03:14:36 --> Language Class Initialized
INFO - 2026-01-21 03:14:36 --> Loader Class Initialized
INFO - 2026-01-21 03:14:36 --> Helper loaded: url_helper
INFO - 2026-01-21 03:14:36 --> Helper loaded: text_helper
INFO - 2026-01-21 03:14:36 --> Helper loaded: string_helper
INFO - 2026-01-21 03:14:36 --> Helper loaded: form_helper
INFO - 2026-01-21 03:14:36 --> Helper loaded: download_helper
INFO - 2026-01-21 03:14:36 --> Helper loaded: security_helper
INFO - 2026-01-21 03:14:36 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:14:36 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:14:36 --> Form Validation Class Initialized
INFO - 2026-01-21 03:14:36 --> Model "User_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:14:36 --> Controller Class Initialized
INFO - 2026-01-21 09:14:36 --> Model "Berita_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Galeri_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Video_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Agenda_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Tautan_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Mitra_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:14:36 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 09:14:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-21 09:14:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:14:36 --> Model "Log_model" initialized
INFO - 2026-01-21 09:14:36 --> Final output sent to browser
DEBUG - 2026-01-21 09:14:36 --> Total execution time: 0.1526
INFO - 2026-01-21 03:14:50 --> Config Class Initialized
INFO - 2026-01-21 03:14:50 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:14:50 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:14:50 --> Utf8 Class Initialized
INFO - 2026-01-21 03:14:50 --> URI Class Initialized
INFO - 2026-01-21 03:14:50 --> Router Class Initialized
INFO - 2026-01-21 03:14:50 --> Output Class Initialized
INFO - 2026-01-21 03:14:50 --> Security Class Initialized
DEBUG - 2026-01-21 03:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:14:50 --> CSRF cookie sent
INFO - 2026-01-21 03:14:50 --> Input Class Initialized
INFO - 2026-01-21 03:14:50 --> Language Class Initialized
INFO - 2026-01-21 03:14:50 --> Loader Class Initialized
INFO - 2026-01-21 03:14:50 --> Helper loaded: url_helper
INFO - 2026-01-21 03:14:50 --> Helper loaded: text_helper
INFO - 2026-01-21 03:14:50 --> Helper loaded: string_helper
INFO - 2026-01-21 03:14:50 --> Helper loaded: form_helper
INFO - 2026-01-21 03:14:50 --> Helper loaded: download_helper
INFO - 2026-01-21 03:14:50 --> Helper loaded: security_helper
INFO - 2026-01-21 03:14:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:14:50 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:14:50 --> Form Validation Class Initialized
INFO - 2026-01-21 03:14:50 --> Model "User_model" initialized
INFO - 2026-01-21 09:14:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:14:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:14:50 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:14:50 --> Controller Class Initialized
INFO - 2026-01-21 09:14:50 --> Model "Tautan_model" initialized
INFO - 2026-01-21 09:14:50 --> Model "Staff_model" initialized
INFO - 2026-01-21 09:14:50 --> Model "Dasbor_model" initialized
INFO - 2026-01-21 09:14:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2026-01-21 09:14:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 09:14:51 --> Model "Log_model" initialized
INFO - 2026-01-21 09:14:51 --> Final output sent to browser
DEBUG - 2026-01-21 09:14:51 --> Total execution time: 0.9687
INFO - 2026-01-21 03:27:26 --> Config Class Initialized
INFO - 2026-01-21 03:27:26 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:27:26 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:27:26 --> Utf8 Class Initialized
INFO - 2026-01-21 03:27:26 --> URI Class Initialized
INFO - 2026-01-21 03:27:26 --> Router Class Initialized
INFO - 2026-01-21 03:27:26 --> Output Class Initialized
INFO - 2026-01-21 03:27:27 --> Security Class Initialized
DEBUG - 2026-01-21 03:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:27:27 --> CSRF cookie sent
INFO - 2026-01-21 03:27:27 --> Input Class Initialized
INFO - 2026-01-21 03:27:27 --> Language Class Initialized
INFO - 2026-01-21 03:27:27 --> Loader Class Initialized
INFO - 2026-01-21 03:27:27 --> Helper loaded: url_helper
INFO - 2026-01-21 03:27:27 --> Helper loaded: text_helper
INFO - 2026-01-21 03:27:27 --> Helper loaded: string_helper
INFO - 2026-01-21 03:27:27 --> Helper loaded: form_helper
INFO - 2026-01-21 03:27:28 --> Helper loaded: download_helper
INFO - 2026-01-21 03:27:28 --> Helper loaded: security_helper
INFO - 2026-01-21 03:27:28 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:27:28 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:27:29 --> Form Validation Class Initialized
INFO - 2026-01-21 03:27:30 --> Model "User_model" initialized
INFO - 2026-01-21 09:27:30 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:27:30 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:27:30 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:27:30 --> Controller Class Initialized
INFO - 2026-01-21 09:27:30 --> Model "Pages_model" initialized
INFO - 2026-01-21 09:27:31 --> Model "Berita_model" initialized
INFO - 2026-01-21 09:27:31 --> Model "Download_model" initialized
INFO - 2026-01-21 09:27:31 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:27:31 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:27:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-21 09:27:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:27:32 --> Model "Log_model" initialized
INFO - 2026-01-21 09:27:32 --> Final output sent to browser
DEBUG - 2026-01-21 09:27:32 --> Total execution time: 6.7372
INFO - 2026-01-21 03:27:59 --> Config Class Initialized
INFO - 2026-01-21 03:27:59 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:27:59 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:27:59 --> Utf8 Class Initialized
INFO - 2026-01-21 03:27:59 --> URI Class Initialized
DEBUG - 2026-01-21 03:27:59 --> No URI present. Default controller set.
INFO - 2026-01-21 03:27:59 --> Router Class Initialized
INFO - 2026-01-21 03:27:59 --> Output Class Initialized
INFO - 2026-01-21 03:27:59 --> Security Class Initialized
DEBUG - 2026-01-21 03:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:27:59 --> CSRF cookie sent
INFO - 2026-01-21 03:27:59 --> Input Class Initialized
INFO - 2026-01-21 03:27:59 --> Language Class Initialized
INFO - 2026-01-21 03:27:59 --> Loader Class Initialized
INFO - 2026-01-21 03:27:59 --> Helper loaded: url_helper
INFO - 2026-01-21 03:27:59 --> Helper loaded: text_helper
INFO - 2026-01-21 03:27:59 --> Helper loaded: string_helper
INFO - 2026-01-21 03:27:59 --> Helper loaded: form_helper
INFO - 2026-01-21 03:27:59 --> Helper loaded: download_helper
INFO - 2026-01-21 03:27:59 --> Helper loaded: security_helper
INFO - 2026-01-21 03:27:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:27:59 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:27:59 --> Form Validation Class Initialized
INFO - 2026-01-21 03:27:59 --> Model "User_model" initialized
INFO - 2026-01-21 09:27:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:27:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:27:59 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:27:59 --> Controller Class Initialized
INFO - 2026-01-21 09:27:59 --> Model "Berita_model" initialized
INFO - 2026-01-21 09:28:00 --> Model "Galeri_model" initialized
INFO - 2026-01-21 09:28:00 --> Model "Video_model" initialized
INFO - 2026-01-21 09:28:00 --> Model "Agenda_model" initialized
INFO - 2026-01-21 09:28:00 --> Model "Tautan_model" initialized
INFO - 2026-01-21 09:28:00 --> Model "Mitra_model" initialized
INFO - 2026-01-21 09:28:00 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 09:28:00 --> Model "Prodi_model" initialized
INFO - 2026-01-21 09:28:00 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 09:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 09:28:00 --> Pagination Class Initialized
INFO - 2026-01-21 09:28:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 09:28:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:28:03 --> Model "Log_model" initialized
INFO - 2026-01-21 09:28:03 --> Final output sent to browser
DEBUG - 2026-01-21 09:28:03 --> Total execution time: 3.3364
INFO - 2026-01-21 03:28:25 --> Config Class Initialized
INFO - 2026-01-21 03:28:25 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:28:25 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:28:25 --> Utf8 Class Initialized
INFO - 2026-01-21 03:28:25 --> URI Class Initialized
INFO - 2026-01-21 03:28:25 --> Router Class Initialized
INFO - 2026-01-21 03:28:25 --> Output Class Initialized
INFO - 2026-01-21 03:28:25 --> Security Class Initialized
DEBUG - 2026-01-21 03:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:28:25 --> CSRF cookie sent
INFO - 2026-01-21 03:28:25 --> Input Class Initialized
INFO - 2026-01-21 03:28:25 --> Language Class Initialized
INFO - 2026-01-21 03:28:25 --> Loader Class Initialized
INFO - 2026-01-21 03:28:25 --> Helper loaded: url_helper
INFO - 2026-01-21 03:28:25 --> Helper loaded: text_helper
INFO - 2026-01-21 03:28:25 --> Helper loaded: string_helper
INFO - 2026-01-21 03:28:25 --> Helper loaded: form_helper
INFO - 2026-01-21 03:28:25 --> Helper loaded: download_helper
INFO - 2026-01-21 03:28:25 --> Helper loaded: security_helper
INFO - 2026-01-21 03:28:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:28:25 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:28:25 --> Form Validation Class Initialized
INFO - 2026-01-21 03:28:25 --> Model "User_model" initialized
INFO - 2026-01-21 09:28:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:28:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:28:25 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:28:25 --> Controller Class Initialized
INFO - 2026-01-21 09:28:25 --> Model "Pages_model" initialized
INFO - 2026-01-21 09:28:25 --> Model "Berita_model" initialized
INFO - 2026-01-21 09:28:25 --> Model "Download_model" initialized
INFO - 2026-01-21 09:28:25 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:28:25 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:28:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2026-01-21 09:28:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:28:26 --> Model "Log_model" initialized
INFO - 2026-01-21 09:28:26 --> Final output sent to browser
DEBUG - 2026-01-21 09:28:26 --> Total execution time: 0.4222
INFO - 2026-01-21 03:28:33 --> Config Class Initialized
INFO - 2026-01-21 03:28:33 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:28:33 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:28:33 --> Utf8 Class Initialized
INFO - 2026-01-21 03:28:33 --> URI Class Initialized
INFO - 2026-01-21 03:28:34 --> Router Class Initialized
INFO - 2026-01-21 03:28:34 --> Output Class Initialized
INFO - 2026-01-21 03:28:34 --> Security Class Initialized
DEBUG - 2026-01-21 03:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:28:34 --> CSRF cookie sent
INFO - 2026-01-21 03:28:34 --> Input Class Initialized
INFO - 2026-01-21 03:28:34 --> Language Class Initialized
INFO - 2026-01-21 03:28:34 --> Loader Class Initialized
INFO - 2026-01-21 03:28:34 --> Helper loaded: url_helper
INFO - 2026-01-21 03:28:34 --> Helper loaded: text_helper
INFO - 2026-01-21 03:28:34 --> Helper loaded: string_helper
INFO - 2026-01-21 03:28:34 --> Helper loaded: form_helper
INFO - 2026-01-21 03:28:34 --> Helper loaded: download_helper
INFO - 2026-01-21 03:28:34 --> Helper loaded: security_helper
INFO - 2026-01-21 03:28:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:28:34 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:28:34 --> Form Validation Class Initialized
INFO - 2026-01-21 03:28:34 --> Model "User_model" initialized
INFO - 2026-01-21 09:28:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:28:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:28:34 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:28:34 --> Controller Class Initialized
INFO - 2026-01-21 09:28:34 --> Model "Download_model" initialized
INFO - 2026-01-21 09:28:34 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:28:34 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\monev/list.php
INFO - 2026-01-21 09:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:28:34 --> Model "Log_model" initialized
INFO - 2026-01-21 09:28:34 --> Final output sent to browser
DEBUG - 2026-01-21 09:28:34 --> Total execution time: 0.2476
INFO - 2026-01-21 03:43:50 --> Config Class Initialized
INFO - 2026-01-21 03:43:50 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:43:50 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:43:50 --> Utf8 Class Initialized
INFO - 2026-01-21 03:43:50 --> URI Class Initialized
INFO - 2026-01-21 03:43:50 --> Router Class Initialized
INFO - 2026-01-21 03:43:50 --> Output Class Initialized
INFO - 2026-01-21 03:43:50 --> Security Class Initialized
DEBUG - 2026-01-21 03:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:43:50 --> CSRF cookie sent
INFO - 2026-01-21 03:43:50 --> Input Class Initialized
INFO - 2026-01-21 03:43:50 --> Language Class Initialized
INFO - 2026-01-21 03:43:50 --> Loader Class Initialized
INFO - 2026-01-21 03:43:50 --> Helper loaded: url_helper
INFO - 2026-01-21 03:43:50 --> Helper loaded: text_helper
INFO - 2026-01-21 03:43:50 --> Helper loaded: string_helper
INFO - 2026-01-21 03:43:50 --> Helper loaded: form_helper
INFO - 2026-01-21 03:43:50 --> Helper loaded: download_helper
INFO - 2026-01-21 03:43:50 --> Helper loaded: security_helper
INFO - 2026-01-21 03:43:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:43:50 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:43:50 --> Form Validation Class Initialized
INFO - 2026-01-21 03:43:50 --> Model "User_model" initialized
INFO - 2026-01-21 09:43:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:43:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:43:50 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:43:50 --> Controller Class Initialized
INFO - 2026-01-21 09:43:50 --> Model "Download_model" initialized
INFO - 2026-01-21 09:43:50 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:43:50 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:43:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:43:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:43:50 --> Model "Log_model" initialized
INFO - 2026-01-21 09:43:50 --> Final output sent to browser
DEBUG - 2026-01-21 09:43:50 --> Total execution time: 0.5731
INFO - 2026-01-21 03:43:52 --> Config Class Initialized
INFO - 2026-01-21 03:43:52 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:43:52 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:43:52 --> Utf8 Class Initialized
INFO - 2026-01-21 03:43:52 --> URI Class Initialized
INFO - 2026-01-21 03:43:52 --> Router Class Initialized
INFO - 2026-01-21 03:43:52 --> Output Class Initialized
INFO - 2026-01-21 03:43:52 --> Security Class Initialized
DEBUG - 2026-01-21 03:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:43:52 --> CSRF cookie sent
INFO - 2026-01-21 03:43:52 --> Input Class Initialized
INFO - 2026-01-21 03:43:52 --> Language Class Initialized
INFO - 2026-01-21 03:43:52 --> Loader Class Initialized
INFO - 2026-01-21 03:43:52 --> Helper loaded: url_helper
INFO - 2026-01-21 03:43:52 --> Helper loaded: text_helper
INFO - 2026-01-21 03:43:52 --> Helper loaded: string_helper
INFO - 2026-01-21 03:43:52 --> Helper loaded: form_helper
INFO - 2026-01-21 03:43:52 --> Helper loaded: download_helper
INFO - 2026-01-21 03:43:52 --> Helper loaded: security_helper
INFO - 2026-01-21 03:43:52 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:43:52 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:43:52 --> Form Validation Class Initialized
INFO - 2026-01-21 03:43:52 --> Model "User_model" initialized
INFO - 2026-01-21 09:43:52 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:43:52 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:43:52 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:43:52 --> Controller Class Initialized
INFO - 2026-01-21 09:43:52 --> Model "Download_model" initialized
INFO - 2026-01-21 09:43:52 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:43:52 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:43:53 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-21 09:43:53"}
INFO - 2026-01-21 03:45:25 --> Config Class Initialized
INFO - 2026-01-21 03:45:25 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:45:25 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:45:25 --> Utf8 Class Initialized
INFO - 2026-01-21 03:45:25 --> URI Class Initialized
INFO - 2026-01-21 03:45:25 --> Router Class Initialized
INFO - 2026-01-21 03:45:25 --> Output Class Initialized
INFO - 2026-01-21 03:45:25 --> Security Class Initialized
DEBUG - 2026-01-21 03:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:45:25 --> CSRF cookie sent
INFO - 2026-01-21 03:45:25 --> Input Class Initialized
INFO - 2026-01-21 03:45:25 --> Language Class Initialized
INFO - 2026-01-21 03:45:25 --> Loader Class Initialized
INFO - 2026-01-21 03:45:25 --> Helper loaded: url_helper
INFO - 2026-01-21 03:45:25 --> Helper loaded: text_helper
INFO - 2026-01-21 03:45:25 --> Helper loaded: string_helper
INFO - 2026-01-21 03:45:25 --> Helper loaded: form_helper
INFO - 2026-01-21 03:45:25 --> Helper loaded: download_helper
INFO - 2026-01-21 03:45:25 --> Helper loaded: security_helper
INFO - 2026-01-21 03:45:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:45:25 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:45:25 --> Form Validation Class Initialized
INFO - 2026-01-21 03:45:25 --> Model "User_model" initialized
INFO - 2026-01-21 09:45:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:45:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:45:25 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:45:25 --> Controller Class Initialized
INFO - 2026-01-21 09:45:25 --> Model "Download_model" initialized
INFO - 2026-01-21 09:45:25 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:45:25 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:45:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:45:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:45:26 --> Model "Log_model" initialized
INFO - 2026-01-21 09:45:26 --> Final output sent to browser
DEBUG - 2026-01-21 09:45:26 --> Total execution time: 0.4928
INFO - 2026-01-21 03:46:42 --> Config Class Initialized
INFO - 2026-01-21 03:46:42 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:46:42 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:46:42 --> Utf8 Class Initialized
INFO - 2026-01-21 03:46:42 --> URI Class Initialized
INFO - 2026-01-21 03:46:42 --> Router Class Initialized
INFO - 2026-01-21 03:46:42 --> Output Class Initialized
INFO - 2026-01-21 03:46:42 --> Security Class Initialized
DEBUG - 2026-01-21 03:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:46:42 --> CSRF cookie sent
INFO - 2026-01-21 03:46:42 --> Input Class Initialized
INFO - 2026-01-21 03:46:42 --> Language Class Initialized
INFO - 2026-01-21 03:46:42 --> Loader Class Initialized
INFO - 2026-01-21 03:46:42 --> Helper loaded: url_helper
INFO - 2026-01-21 03:46:42 --> Helper loaded: text_helper
INFO - 2026-01-21 03:46:42 --> Helper loaded: string_helper
INFO - 2026-01-21 03:46:42 --> Helper loaded: form_helper
INFO - 2026-01-21 03:46:42 --> Helper loaded: download_helper
INFO - 2026-01-21 03:46:42 --> Helper loaded: security_helper
INFO - 2026-01-21 03:46:42 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:46:42 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:46:42 --> Form Validation Class Initialized
INFO - 2026-01-21 03:46:42 --> Model "User_model" initialized
INFO - 2026-01-21 09:46:42 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:46:42 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:46:42 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:46:42 --> Controller Class Initialized
INFO - 2026-01-21 09:46:42 --> Model "Download_model" initialized
INFO - 2026-01-21 09:46:42 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:46:42 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:46:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:46:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:46:42 --> Model "Log_model" initialized
INFO - 2026-01-21 09:46:42 --> Final output sent to browser
DEBUG - 2026-01-21 09:46:42 --> Total execution time: 0.4843
INFO - 2026-01-21 03:47:27 --> Config Class Initialized
INFO - 2026-01-21 03:47:27 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:47:27 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:47:27 --> Utf8 Class Initialized
INFO - 2026-01-21 03:47:27 --> URI Class Initialized
INFO - 2026-01-21 03:47:27 --> Router Class Initialized
INFO - 2026-01-21 03:47:27 --> Output Class Initialized
INFO - 2026-01-21 03:47:27 --> Security Class Initialized
DEBUG - 2026-01-21 03:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:47:27 --> CSRF cookie sent
INFO - 2026-01-21 03:47:27 --> Input Class Initialized
INFO - 2026-01-21 03:47:27 --> Language Class Initialized
INFO - 2026-01-21 03:47:27 --> Loader Class Initialized
INFO - 2026-01-21 03:47:27 --> Helper loaded: url_helper
INFO - 2026-01-21 03:47:27 --> Helper loaded: text_helper
INFO - 2026-01-21 03:47:27 --> Helper loaded: string_helper
INFO - 2026-01-21 03:47:27 --> Helper loaded: form_helper
INFO - 2026-01-21 03:47:27 --> Helper loaded: download_helper
INFO - 2026-01-21 03:47:27 --> Helper loaded: security_helper
INFO - 2026-01-21 03:47:27 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:47:28 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:47:28 --> Form Validation Class Initialized
INFO - 2026-01-21 03:47:28 --> Model "User_model" initialized
INFO - 2026-01-21 09:47:28 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:47:28 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:47:28 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:47:28 --> Controller Class Initialized
INFO - 2026-01-21 09:47:28 --> Model "Download_model" initialized
INFO - 2026-01-21 09:47:28 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:47:28 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:47:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:47:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:47:28 --> Model "Log_model" initialized
INFO - 2026-01-21 09:47:28 --> Final output sent to browser
DEBUG - 2026-01-21 09:47:28 --> Total execution time: 0.5077
INFO - 2026-01-21 03:53:22 --> Config Class Initialized
INFO - 2026-01-21 03:53:22 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:53:22 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:53:22 --> Utf8 Class Initialized
INFO - 2026-01-21 03:53:22 --> URI Class Initialized
INFO - 2026-01-21 03:53:22 --> Router Class Initialized
INFO - 2026-01-21 03:53:22 --> Output Class Initialized
INFO - 2026-01-21 03:53:22 --> Security Class Initialized
DEBUG - 2026-01-21 03:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:53:22 --> CSRF cookie sent
INFO - 2026-01-21 03:53:22 --> Input Class Initialized
INFO - 2026-01-21 03:53:22 --> Language Class Initialized
INFO - 2026-01-21 03:53:22 --> Loader Class Initialized
INFO - 2026-01-21 03:53:22 --> Helper loaded: url_helper
INFO - 2026-01-21 03:53:22 --> Helper loaded: text_helper
INFO - 2026-01-21 03:53:22 --> Helper loaded: string_helper
INFO - 2026-01-21 03:53:22 --> Helper loaded: form_helper
INFO - 2026-01-21 03:53:22 --> Helper loaded: download_helper
INFO - 2026-01-21 03:53:22 --> Helper loaded: security_helper
INFO - 2026-01-21 03:53:22 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:53:22 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:53:22 --> Form Validation Class Initialized
INFO - 2026-01-21 03:53:22 --> Model "User_model" initialized
INFO - 2026-01-21 09:53:22 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:53:22 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:53:22 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:53:22 --> Controller Class Initialized
INFO - 2026-01-21 09:53:22 --> Model "Download_model" initialized
INFO - 2026-01-21 09:53:22 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:53:22 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:53:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-21 09:53:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:53:22 --> Model "Log_model" initialized
INFO - 2026-01-21 09:53:22 --> Final output sent to browser
DEBUG - 2026-01-21 09:53:22 --> Total execution time: 0.1877
INFO - 2026-01-21 03:54:14 --> Config Class Initialized
INFO - 2026-01-21 03:54:14 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:54:14 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:54:14 --> Utf8 Class Initialized
INFO - 2026-01-21 03:54:14 --> URI Class Initialized
INFO - 2026-01-21 03:54:14 --> Router Class Initialized
INFO - 2026-01-21 03:54:14 --> Output Class Initialized
INFO - 2026-01-21 03:54:14 --> Security Class Initialized
DEBUG - 2026-01-21 03:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:54:14 --> CSRF cookie sent
INFO - 2026-01-21 03:54:14 --> Input Class Initialized
INFO - 2026-01-21 03:54:14 --> Language Class Initialized
INFO - 2026-01-21 03:54:14 --> Loader Class Initialized
INFO - 2026-01-21 03:54:14 --> Helper loaded: url_helper
INFO - 2026-01-21 03:54:14 --> Helper loaded: text_helper
INFO - 2026-01-21 03:54:14 --> Helper loaded: string_helper
INFO - 2026-01-21 03:54:14 --> Helper loaded: form_helper
INFO - 2026-01-21 03:54:14 --> Helper loaded: download_helper
INFO - 2026-01-21 03:54:14 --> Helper loaded: security_helper
INFO - 2026-01-21 03:54:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:54:14 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:54:14 --> Form Validation Class Initialized
INFO - 2026-01-21 03:54:14 --> Model "User_model" initialized
INFO - 2026-01-21 09:54:14 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:54:14 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:54:14 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:54:14 --> Controller Class Initialized
INFO - 2026-01-21 09:54:14 --> Model "Download_model" initialized
INFO - 2026-01-21 09:54:14 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:54:14 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:54:14 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"181","filename":"UNDANG-UNDANG_NO_14_TAHUN_2005_TENTANG_GURU_DAN_DOSEN.pdf","timestamp":"2026-01-21 09:54:14"}
INFO - 2026-01-21 03:54:20 --> Config Class Initialized
INFO - 2026-01-21 03:54:20 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:54:20 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:54:20 --> Utf8 Class Initialized
INFO - 2026-01-21 03:54:20 --> URI Class Initialized
INFO - 2026-01-21 03:54:20 --> Router Class Initialized
INFO - 2026-01-21 03:54:20 --> Output Class Initialized
INFO - 2026-01-21 03:54:20 --> Security Class Initialized
DEBUG - 2026-01-21 03:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:54:20 --> CSRF cookie sent
INFO - 2026-01-21 03:54:20 --> Input Class Initialized
INFO - 2026-01-21 03:54:20 --> Language Class Initialized
INFO - 2026-01-21 03:54:20 --> Loader Class Initialized
INFO - 2026-01-21 03:54:20 --> Helper loaded: url_helper
INFO - 2026-01-21 03:54:20 --> Helper loaded: text_helper
INFO - 2026-01-21 03:54:20 --> Helper loaded: string_helper
INFO - 2026-01-21 03:54:20 --> Helper loaded: form_helper
INFO - 2026-01-21 03:54:20 --> Helper loaded: download_helper
INFO - 2026-01-21 03:54:20 --> Helper loaded: security_helper
INFO - 2026-01-21 03:54:20 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:54:20 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:54:20 --> Form Validation Class Initialized
INFO - 2026-01-21 03:54:20 --> Model "User_model" initialized
INFO - 2026-01-21 09:54:20 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:54:20 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:54:20 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:54:20 --> Controller Class Initialized
INFO - 2026-01-21 09:54:20 --> Model "Download_model" initialized
INFO - 2026-01-21 09:54:20 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:54:20 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:54:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_standardpelayanan.php
INFO - 2026-01-21 09:54:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:54:21 --> Model "Log_model" initialized
INFO - 2026-01-21 09:54:21 --> Final output sent to browser
DEBUG - 2026-01-21 09:54:21 --> Total execution time: 0.3889
INFO - 2026-01-21 03:54:23 --> Config Class Initialized
INFO - 2026-01-21 03:54:23 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:54:23 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:54:23 --> Utf8 Class Initialized
INFO - 2026-01-21 03:54:23 --> URI Class Initialized
INFO - 2026-01-21 03:54:23 --> Router Class Initialized
INFO - 2026-01-21 03:54:23 --> Output Class Initialized
INFO - 2026-01-21 03:54:23 --> Security Class Initialized
DEBUG - 2026-01-21 03:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:54:23 --> CSRF cookie sent
INFO - 2026-01-21 03:54:23 --> Input Class Initialized
INFO - 2026-01-21 03:54:23 --> Language Class Initialized
INFO - 2026-01-21 03:54:23 --> Loader Class Initialized
INFO - 2026-01-21 03:54:23 --> Helper loaded: url_helper
INFO - 2026-01-21 03:54:23 --> Helper loaded: text_helper
INFO - 2026-01-21 03:54:23 --> Helper loaded: string_helper
INFO - 2026-01-21 03:54:23 --> Helper loaded: form_helper
INFO - 2026-01-21 03:54:23 --> Helper loaded: download_helper
INFO - 2026-01-21 03:54:23 --> Helper loaded: security_helper
INFO - 2026-01-21 03:54:23 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:54:23 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:54:23 --> Form Validation Class Initialized
INFO - 2026-01-21 03:54:23 --> Model "User_model" initialized
INFO - 2026-01-21 09:54:23 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:54:23 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:54:23 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:54:23 --> Controller Class Initialized
INFO - 2026-01-21 09:54:23 --> Model "Download_model" initialized
INFO - 2026-01-21 09:54:23 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:54:23 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:54:23 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"115","filename":"Standar_Pelayanan_Penyelenggaraan_Wisuda.pdf","timestamp":"2026-01-21 09:54:23"}
INFO - 2026-01-21 03:56:58 --> Config Class Initialized
INFO - 2026-01-21 03:56:58 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:56:58 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:56:58 --> Utf8 Class Initialized
INFO - 2026-01-21 03:56:58 --> URI Class Initialized
INFO - 2026-01-21 03:56:58 --> Router Class Initialized
INFO - 2026-01-21 03:56:58 --> Output Class Initialized
INFO - 2026-01-21 03:56:58 --> Security Class Initialized
DEBUG - 2026-01-21 03:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:56:58 --> CSRF cookie sent
INFO - 2026-01-21 03:56:58 --> Input Class Initialized
INFO - 2026-01-21 03:56:58 --> Language Class Initialized
INFO - 2026-01-21 03:56:58 --> Loader Class Initialized
INFO - 2026-01-21 03:56:58 --> Helper loaded: url_helper
INFO - 2026-01-21 03:56:58 --> Helper loaded: text_helper
INFO - 2026-01-21 03:56:58 --> Helper loaded: string_helper
INFO - 2026-01-21 03:56:58 --> Helper loaded: form_helper
INFO - 2026-01-21 03:56:58 --> Helper loaded: download_helper
INFO - 2026-01-21 03:56:58 --> Helper loaded: security_helper
INFO - 2026-01-21 03:56:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:56:58 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:56:58 --> Form Validation Class Initialized
INFO - 2026-01-21 03:56:58 --> Model "User_model" initialized
INFO - 2026-01-21 09:56:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:56:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:56:58 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:56:58 --> Controller Class Initialized
INFO - 2026-01-21 09:56:58 --> Model "Download_model" initialized
INFO - 2026-01-21 09:56:58 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:56:58 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:56:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_standardpelayanan.php
INFO - 2026-01-21 09:56:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:56:58 --> Model "Log_model" initialized
INFO - 2026-01-21 09:56:58 --> Final output sent to browser
DEBUG - 2026-01-21 09:56:58 --> Total execution time: 0.1835
INFO - 2026-01-21 03:58:09 --> Config Class Initialized
INFO - 2026-01-21 03:58:09 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:58:09 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:58:09 --> Utf8 Class Initialized
INFO - 2026-01-21 03:58:09 --> URI Class Initialized
INFO - 2026-01-21 03:58:09 --> Router Class Initialized
INFO - 2026-01-21 03:58:09 --> Output Class Initialized
INFO - 2026-01-21 03:58:09 --> Security Class Initialized
DEBUG - 2026-01-21 03:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:58:09 --> CSRF cookie sent
INFO - 2026-01-21 03:58:09 --> Input Class Initialized
INFO - 2026-01-21 03:58:09 --> Language Class Initialized
INFO - 2026-01-21 03:58:09 --> Loader Class Initialized
INFO - 2026-01-21 03:58:09 --> Helper loaded: url_helper
INFO - 2026-01-21 03:58:09 --> Helper loaded: text_helper
INFO - 2026-01-21 03:58:09 --> Helper loaded: string_helper
INFO - 2026-01-21 03:58:09 --> Helper loaded: form_helper
INFO - 2026-01-21 03:58:09 --> Helper loaded: download_helper
INFO - 2026-01-21 03:58:09 --> Helper loaded: security_helper
INFO - 2026-01-21 03:58:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:58:09 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:58:09 --> Form Validation Class Initialized
INFO - 2026-01-21 03:58:09 --> Model "User_model" initialized
INFO - 2026-01-21 09:58:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:58:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:58:09 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:58:09 --> Controller Class Initialized
INFO - 2026-01-21 09:58:09 --> Model "Download_model" initialized
INFO - 2026-01-21 09:58:09 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:58:09 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:58:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akademik.php
INFO - 2026-01-21 09:58:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:58:09 --> Model "Log_model" initialized
INFO - 2026-01-21 09:58:09 --> Final output sent to browser
DEBUG - 2026-01-21 09:58:09 --> Total execution time: 0.2081
INFO - 2026-01-21 03:58:16 --> Config Class Initialized
INFO - 2026-01-21 03:58:16 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:58:16 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:58:16 --> Utf8 Class Initialized
INFO - 2026-01-21 03:58:16 --> URI Class Initialized
INFO - 2026-01-21 03:58:16 --> Router Class Initialized
INFO - 2026-01-21 03:58:16 --> Output Class Initialized
INFO - 2026-01-21 03:58:16 --> Security Class Initialized
DEBUG - 2026-01-21 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:58:16 --> CSRF cookie sent
INFO - 2026-01-21 03:58:16 --> Input Class Initialized
INFO - 2026-01-21 03:58:16 --> Language Class Initialized
INFO - 2026-01-21 03:58:16 --> Loader Class Initialized
INFO - 2026-01-21 03:58:16 --> Helper loaded: url_helper
INFO - 2026-01-21 03:58:16 --> Helper loaded: text_helper
INFO - 2026-01-21 03:58:16 --> Helper loaded: string_helper
INFO - 2026-01-21 03:58:16 --> Helper loaded: form_helper
INFO - 2026-01-21 03:58:16 --> Helper loaded: download_helper
INFO - 2026-01-21 03:58:16 --> Helper loaded: security_helper
INFO - 2026-01-21 03:58:16 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:58:16 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:58:16 --> Form Validation Class Initialized
INFO - 2026-01-21 03:58:16 --> Model "User_model" initialized
INFO - 2026-01-21 09:58:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:58:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:58:16 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:58:16 --> Controller Class Initialized
INFO - 2026-01-21 09:58:16 --> Model "Download_model" initialized
INFO - 2026-01-21 09:58:16 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:58:16 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:58:16 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"145","filename":"Pelayanan_Pengajuan_Surat_Keterangan_Verifikasi_Ijazah.pdf","timestamp":"2026-01-21 09:58:16"}
INFO - 2026-01-21 03:58:18 --> Config Class Initialized
INFO - 2026-01-21 03:58:18 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:58:18 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:58:18 --> Utf8 Class Initialized
INFO - 2026-01-21 03:58:18 --> URI Class Initialized
INFO - 2026-01-21 03:58:18 --> Router Class Initialized
INFO - 2026-01-21 03:58:18 --> Output Class Initialized
INFO - 2026-01-21 03:58:18 --> Security Class Initialized
DEBUG - 2026-01-21 03:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:58:18 --> CSRF cookie sent
INFO - 2026-01-21 03:58:18 --> Input Class Initialized
INFO - 2026-01-21 03:58:18 --> Language Class Initialized
INFO - 2026-01-21 03:58:18 --> Loader Class Initialized
INFO - 2026-01-21 03:58:18 --> Helper loaded: url_helper
INFO - 2026-01-21 03:58:18 --> Helper loaded: text_helper
INFO - 2026-01-21 03:58:18 --> Helper loaded: string_helper
INFO - 2026-01-21 03:58:18 --> Helper loaded: form_helper
INFO - 2026-01-21 03:58:18 --> Helper loaded: download_helper
INFO - 2026-01-21 03:58:18 --> Helper loaded: security_helper
INFO - 2026-01-21 03:58:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:58:18 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:58:18 --> Form Validation Class Initialized
INFO - 2026-01-21 03:58:18 --> Model "User_model" initialized
INFO - 2026-01-21 09:58:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:58:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:58:18 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:58:18 --> Controller Class Initialized
INFO - 2026-01-21 09:58:18 --> Model "Download_model" initialized
INFO - 2026-01-21 09:58:18 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:58:18 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:58:18 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"146","filename":"Pelayanan_Pengisian_Kartu_Rencana_Studi_(KRS).pdf","timestamp":"2026-01-21 09:58:18"}
INFO - 2026-01-21 03:59:25 --> Config Class Initialized
INFO - 2026-01-21 03:59:25 --> Hooks Class Initialized
DEBUG - 2026-01-21 03:59:25 --> UTF-8 Support Enabled
INFO - 2026-01-21 03:59:25 --> Utf8 Class Initialized
INFO - 2026-01-21 03:59:25 --> URI Class Initialized
INFO - 2026-01-21 03:59:25 --> Router Class Initialized
INFO - 2026-01-21 03:59:25 --> Output Class Initialized
INFO - 2026-01-21 03:59:25 --> Security Class Initialized
DEBUG - 2026-01-21 03:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 03:59:25 --> CSRF cookie sent
INFO - 2026-01-21 03:59:25 --> Input Class Initialized
INFO - 2026-01-21 03:59:25 --> Language Class Initialized
INFO - 2026-01-21 03:59:25 --> Loader Class Initialized
INFO - 2026-01-21 03:59:25 --> Helper loaded: url_helper
INFO - 2026-01-21 03:59:25 --> Helper loaded: text_helper
INFO - 2026-01-21 03:59:25 --> Helper loaded: string_helper
INFO - 2026-01-21 03:59:25 --> Helper loaded: form_helper
INFO - 2026-01-21 03:59:25 --> Helper loaded: download_helper
INFO - 2026-01-21 03:59:25 --> Helper loaded: security_helper
INFO - 2026-01-21 03:59:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 03:59:25 --> Database Driver Class Initialized
DEBUG - 2026-01-21 03:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 03:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 03:59:25 --> Form Validation Class Initialized
INFO - 2026-01-21 03:59:25 --> Model "User_model" initialized
INFO - 2026-01-21 09:59:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 09:59:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 09:59:25 --> Model "Nav_model" initialized
INFO - 2026-01-21 09:59:25 --> Controller Class Initialized
INFO - 2026-01-21 09:59:25 --> Model "Download_model" initialized
INFO - 2026-01-21 09:59:25 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 09:59:25 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 09:59:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-21 09:59:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 09:59:25 --> Model "Log_model" initialized
INFO - 2026-01-21 09:59:25 --> Final output sent to browser
DEBUG - 2026-01-21 09:59:25 --> Total execution time: 0.2988
INFO - 2026-01-21 04:00:01 --> Config Class Initialized
INFO - 2026-01-21 04:00:01 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:00:01 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:00:01 --> Utf8 Class Initialized
INFO - 2026-01-21 04:00:01 --> URI Class Initialized
INFO - 2026-01-21 04:00:01 --> Router Class Initialized
INFO - 2026-01-21 04:00:01 --> Output Class Initialized
INFO - 2026-01-21 04:00:01 --> Security Class Initialized
DEBUG - 2026-01-21 04:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:00:01 --> CSRF cookie sent
INFO - 2026-01-21 04:00:01 --> Input Class Initialized
INFO - 2026-01-21 04:00:01 --> Language Class Initialized
INFO - 2026-01-21 04:00:01 --> Loader Class Initialized
INFO - 2026-01-21 04:00:01 --> Helper loaded: url_helper
INFO - 2026-01-21 04:00:01 --> Helper loaded: text_helper
INFO - 2026-01-21 04:00:01 --> Helper loaded: string_helper
INFO - 2026-01-21 04:00:01 --> Helper loaded: form_helper
INFO - 2026-01-21 04:00:01 --> Helper loaded: download_helper
INFO - 2026-01-21 04:00:01 --> Helper loaded: security_helper
INFO - 2026-01-21 04:00:01 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:00:01 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:00:01 --> Form Validation Class Initialized
INFO - 2026-01-21 04:00:01 --> Model "User_model" initialized
INFO - 2026-01-21 10:00:01 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:00:01 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:00:01 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:00:01 --> Controller Class Initialized
INFO - 2026-01-21 10:00:01 --> Model "Download_model" initialized
INFO - 2026-01-21 10:00:01 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:00:01 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:00:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_kemahasiswaan.php
INFO - 2026-01-21 10:00:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:00:01 --> Model "Log_model" initialized
INFO - 2026-01-21 10:00:01 --> Final output sent to browser
DEBUG - 2026-01-21 10:00:01 --> Total execution time: 0.2574
INFO - 2026-01-21 04:03:36 --> Config Class Initialized
INFO - 2026-01-21 04:03:36 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:03:36 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:03:36 --> Utf8 Class Initialized
INFO - 2026-01-21 04:03:36 --> URI Class Initialized
INFO - 2026-01-21 04:03:36 --> Router Class Initialized
INFO - 2026-01-21 04:03:36 --> Output Class Initialized
INFO - 2026-01-21 04:03:36 --> Security Class Initialized
DEBUG - 2026-01-21 04:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:03:36 --> CSRF cookie sent
INFO - 2026-01-21 04:03:36 --> Input Class Initialized
INFO - 2026-01-21 04:03:36 --> Language Class Initialized
INFO - 2026-01-21 04:03:36 --> Loader Class Initialized
INFO - 2026-01-21 04:03:36 --> Helper loaded: url_helper
INFO - 2026-01-21 04:03:36 --> Helper loaded: text_helper
INFO - 2026-01-21 04:03:36 --> Helper loaded: string_helper
INFO - 2026-01-21 04:03:36 --> Helper loaded: form_helper
INFO - 2026-01-21 04:03:36 --> Helper loaded: download_helper
INFO - 2026-01-21 04:03:36 --> Helper loaded: security_helper
INFO - 2026-01-21 04:03:36 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:03:36 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:03:36 --> Form Validation Class Initialized
INFO - 2026-01-21 04:03:36 --> Model "User_model" initialized
INFO - 2026-01-21 10:03:36 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:03:36 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:03:36 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:03:36 --> Controller Class Initialized
INFO - 2026-01-21 10:03:36 --> Model "Download_model" initialized
INFO - 2026-01-21 10:03:36 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:03:36 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:03:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-21 10:03:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:03:36 --> Model "Log_model" initialized
INFO - 2026-01-21 10:03:36 --> Final output sent to browser
DEBUG - 2026-01-21 10:03:36 --> Total execution time: 0.3682
INFO - 2026-01-21 04:03:40 --> Config Class Initialized
INFO - 2026-01-21 04:03:40 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:03:40 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:03:40 --> Utf8 Class Initialized
INFO - 2026-01-21 04:03:40 --> URI Class Initialized
INFO - 2026-01-21 04:03:40 --> Router Class Initialized
INFO - 2026-01-21 04:03:40 --> Output Class Initialized
INFO - 2026-01-21 04:03:40 --> Security Class Initialized
DEBUG - 2026-01-21 04:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:03:40 --> CSRF cookie sent
INFO - 2026-01-21 04:03:40 --> Input Class Initialized
INFO - 2026-01-21 04:03:40 --> Language Class Initialized
INFO - 2026-01-21 04:03:40 --> Loader Class Initialized
INFO - 2026-01-21 04:03:40 --> Helper loaded: url_helper
INFO - 2026-01-21 04:03:40 --> Helper loaded: text_helper
INFO - 2026-01-21 04:03:40 --> Helper loaded: string_helper
INFO - 2026-01-21 04:03:40 --> Helper loaded: form_helper
INFO - 2026-01-21 04:03:40 --> Helper loaded: download_helper
INFO - 2026-01-21 04:03:40 --> Helper loaded: security_helper
INFO - 2026-01-21 04:03:40 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:03:40 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:03:40 --> Form Validation Class Initialized
INFO - 2026-01-21 04:03:40 --> Model "User_model" initialized
INFO - 2026-01-21 10:03:40 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:03:40 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:03:40 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:03:40 --> Controller Class Initialized
INFO - 2026-01-21 10:03:40 --> Model "Download_model" initialized
INFO - 2026-01-21 10:03:40 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:03:40 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:03:40 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"208","filename":"SERTIFIKAT_AIPT_2023-2027.pdf","timestamp":"2026-01-21 10:03:40"}
INFO - 2026-01-21 04:03:46 --> Config Class Initialized
INFO - 2026-01-21 04:03:46 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:03:46 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:03:46 --> Utf8 Class Initialized
INFO - 2026-01-21 04:03:46 --> URI Class Initialized
INFO - 2026-01-21 04:03:46 --> Router Class Initialized
INFO - 2026-01-21 04:03:46 --> Output Class Initialized
INFO - 2026-01-21 04:03:46 --> Security Class Initialized
DEBUG - 2026-01-21 04:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:03:46 --> CSRF cookie sent
INFO - 2026-01-21 04:03:46 --> Input Class Initialized
INFO - 2026-01-21 04:03:46 --> Language Class Initialized
INFO - 2026-01-21 04:03:46 --> Loader Class Initialized
INFO - 2026-01-21 04:03:46 --> Helper loaded: url_helper
INFO - 2026-01-21 04:03:46 --> Helper loaded: text_helper
INFO - 2026-01-21 04:03:46 --> Helper loaded: string_helper
INFO - 2026-01-21 04:03:46 --> Helper loaded: form_helper
INFO - 2026-01-21 04:03:46 --> Helper loaded: download_helper
INFO - 2026-01-21 04:03:46 --> Helper loaded: security_helper
INFO - 2026-01-21 04:03:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:03:46 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:03:46 --> Form Validation Class Initialized
INFO - 2026-01-21 04:03:46 --> Model "User_model" initialized
INFO - 2026-01-21 10:03:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:03:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:03:46 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:03:46 --> Controller Class Initialized
INFO - 2026-01-21 10:03:46 --> Model "Download_model" initialized
INFO - 2026-01-21 10:03:46 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:03:46 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:03:46 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"10","filename":"Sertifikat_Akreditasi_Keperawatan_Persahabatan_2004-2008.pdf","timestamp":"2026-01-21 10:03:46"}
INFO - 2026-01-21 04:03:58 --> Config Class Initialized
INFO - 2026-01-21 04:03:58 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:03:58 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:03:58 --> Utf8 Class Initialized
INFO - 2026-01-21 04:03:58 --> URI Class Initialized
INFO - 2026-01-21 04:03:58 --> Router Class Initialized
INFO - 2026-01-21 04:03:58 --> Output Class Initialized
INFO - 2026-01-21 04:03:58 --> Security Class Initialized
DEBUG - 2026-01-21 04:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:03:58 --> CSRF cookie sent
INFO - 2026-01-21 04:03:58 --> Input Class Initialized
INFO - 2026-01-21 04:03:58 --> Language Class Initialized
INFO - 2026-01-21 04:03:58 --> Loader Class Initialized
INFO - 2026-01-21 04:03:58 --> Helper loaded: url_helper
INFO - 2026-01-21 04:03:58 --> Helper loaded: text_helper
INFO - 2026-01-21 04:03:58 --> Helper loaded: string_helper
INFO - 2026-01-21 04:03:58 --> Helper loaded: form_helper
INFO - 2026-01-21 04:03:58 --> Helper loaded: download_helper
INFO - 2026-01-21 04:03:58 --> Helper loaded: security_helper
INFO - 2026-01-21 04:03:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:03:58 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:03:58 --> Form Validation Class Initialized
INFO - 2026-01-21 04:03:58 --> Model "User_model" initialized
INFO - 2026-01-21 10:03:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:03:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:03:58 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:03:58 --> Controller Class Initialized
INFO - 2026-01-21 10:03:58 --> Model "Download_model" initialized
INFO - 2026-01-21 10:03:58 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:03:58 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:03:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-21 10:03:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:03:58 --> Model "Log_model" initialized
INFO - 2026-01-21 10:03:58 --> Final output sent to browser
DEBUG - 2026-01-21 10:03:58 --> Total execution time: 0.1413
INFO - 2026-01-21 04:04:22 --> Config Class Initialized
INFO - 2026-01-21 04:04:22 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:04:22 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:04:22 --> Utf8 Class Initialized
INFO - 2026-01-21 04:04:22 --> URI Class Initialized
INFO - 2026-01-21 04:04:22 --> Router Class Initialized
INFO - 2026-01-21 04:04:22 --> Output Class Initialized
INFO - 2026-01-21 04:04:22 --> Security Class Initialized
DEBUG - 2026-01-21 04:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:04:22 --> CSRF cookie sent
INFO - 2026-01-21 04:04:22 --> Input Class Initialized
INFO - 2026-01-21 04:04:22 --> Language Class Initialized
INFO - 2026-01-21 04:04:22 --> Loader Class Initialized
INFO - 2026-01-21 04:04:22 --> Helper loaded: url_helper
INFO - 2026-01-21 04:04:22 --> Helper loaded: text_helper
INFO - 2026-01-21 04:04:22 --> Helper loaded: string_helper
INFO - 2026-01-21 04:04:22 --> Helper loaded: form_helper
INFO - 2026-01-21 04:04:22 --> Helper loaded: download_helper
INFO - 2026-01-21 04:04:22 --> Helper loaded: security_helper
INFO - 2026-01-21 04:04:22 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:04:22 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:04:22 --> Form Validation Class Initialized
INFO - 2026-01-21 04:04:22 --> Model "User_model" initialized
INFO - 2026-01-21 10:04:22 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:04:22 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:04:22 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:04:22 --> Controller Class Initialized
INFO - 2026-01-21 10:04:22 --> Model "Download_model" initialized
INFO - 2026-01-21 10:04:22 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:04:22 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:04:22 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit\/605.1.15 (KHTML, like Gecko) Version\/14.0.3 Mobile\/15E148 Safari\/604.1","download_id":"208","filename":"SERTIFIKAT_AIPT_2023-2027.pdf","timestamp":"2026-01-21 10:04:22"}
INFO - 2026-01-21 04:04:43 --> Config Class Initialized
INFO - 2026-01-21 04:04:43 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:04:43 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:04:43 --> Utf8 Class Initialized
INFO - 2026-01-21 04:04:43 --> URI Class Initialized
INFO - 2026-01-21 04:04:43 --> Router Class Initialized
INFO - 2026-01-21 04:04:43 --> Output Class Initialized
INFO - 2026-01-21 04:04:43 --> Security Class Initialized
DEBUG - 2026-01-21 04:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:04:43 --> CSRF cookie sent
INFO - 2026-01-21 04:04:43 --> Input Class Initialized
INFO - 2026-01-21 04:04:43 --> Language Class Initialized
INFO - 2026-01-21 04:04:43 --> Loader Class Initialized
INFO - 2026-01-21 04:04:43 --> Helper loaded: url_helper
INFO - 2026-01-21 04:04:43 --> Helper loaded: text_helper
INFO - 2026-01-21 04:04:43 --> Helper loaded: string_helper
INFO - 2026-01-21 04:04:43 --> Helper loaded: form_helper
INFO - 2026-01-21 04:04:43 --> Helper loaded: download_helper
INFO - 2026-01-21 04:04:43 --> Helper loaded: security_helper
INFO - 2026-01-21 04:04:43 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:04:43 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:04:43 --> Form Validation Class Initialized
INFO - 2026-01-21 04:04:43 --> Model "User_model" initialized
INFO - 2026-01-21 10:04:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:04:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:04:43 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:04:43 --> Controller Class Initialized
INFO - 2026-01-21 10:04:43 --> Model "Download_model" initialized
INFO - 2026-01-21 10:04:43 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:04:43 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:04:43 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit\/605.1.15 (KHTML, like Gecko) Version\/14.0.3 Mobile\/15E148 Safari\/604.1","download_id":"25","filename":"Sertifikat_Akreditasi_Diploma_Tiga_Kebidanan_2015-2020.pdf","timestamp":"2026-01-21 10:04:43"}
INFO - 2026-01-21 04:05:56 --> Config Class Initialized
INFO - 2026-01-21 04:05:56 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:05:56 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:05:56 --> Utf8 Class Initialized
INFO - 2026-01-21 04:05:56 --> URI Class Initialized
INFO - 2026-01-21 04:05:56 --> Router Class Initialized
INFO - 2026-01-21 04:05:56 --> Output Class Initialized
INFO - 2026-01-21 04:05:56 --> Security Class Initialized
DEBUG - 2026-01-21 04:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:05:56 --> CSRF cookie sent
INFO - 2026-01-21 04:05:56 --> Input Class Initialized
INFO - 2026-01-21 04:05:56 --> Language Class Initialized
INFO - 2026-01-21 04:05:56 --> Loader Class Initialized
INFO - 2026-01-21 04:05:56 --> Helper loaded: url_helper
INFO - 2026-01-21 04:05:56 --> Helper loaded: text_helper
INFO - 2026-01-21 04:05:56 --> Helper loaded: string_helper
INFO - 2026-01-21 04:05:56 --> Helper loaded: form_helper
INFO - 2026-01-21 04:05:56 --> Helper loaded: download_helper
INFO - 2026-01-21 04:05:56 --> Helper loaded: security_helper
INFO - 2026-01-21 04:05:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:05:56 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:05:56 --> Form Validation Class Initialized
INFO - 2026-01-21 04:05:56 --> Model "User_model" initialized
INFO - 2026-01-21 10:05:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:05:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:05:56 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:05:56 --> Controller Class Initialized
INFO - 2026-01-21 10:05:56 --> Model "Download_model" initialized
INFO - 2026-01-21 10:05:56 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:05:56 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:05:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-21 10:05:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:05:56 --> Model "Log_model" initialized
INFO - 2026-01-21 10:05:56 --> Final output sent to browser
DEBUG - 2026-01-21 10:05:56 --> Total execution time: 0.2179
INFO - 2026-01-21 04:05:58 --> Config Class Initialized
INFO - 2026-01-21 04:05:58 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:05:58 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:05:58 --> Utf8 Class Initialized
INFO - 2026-01-21 04:05:58 --> URI Class Initialized
INFO - 2026-01-21 04:05:58 --> Router Class Initialized
INFO - 2026-01-21 04:05:58 --> Output Class Initialized
INFO - 2026-01-21 04:05:58 --> Security Class Initialized
DEBUG - 2026-01-21 04:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:05:58 --> CSRF cookie sent
INFO - 2026-01-21 04:05:58 --> Input Class Initialized
INFO - 2026-01-21 04:05:58 --> Language Class Initialized
INFO - 2026-01-21 04:05:58 --> Loader Class Initialized
INFO - 2026-01-21 04:05:58 --> Helper loaded: url_helper
INFO - 2026-01-21 04:05:58 --> Helper loaded: text_helper
INFO - 2026-01-21 04:05:58 --> Helper loaded: string_helper
INFO - 2026-01-21 04:05:58 --> Helper loaded: form_helper
INFO - 2026-01-21 04:05:58 --> Helper loaded: download_helper
INFO - 2026-01-21 04:05:58 --> Helper loaded: security_helper
INFO - 2026-01-21 04:05:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:05:58 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:05:58 --> Form Validation Class Initialized
INFO - 2026-01-21 04:05:58 --> Model "User_model" initialized
INFO - 2026-01-21 10:05:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:05:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:05:58 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:05:58 --> Controller Class Initialized
INFO - 2026-01-21 10:05:58 --> Model "Download_model" initialized
INFO - 2026-01-21 10:05:58 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:05:58 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:05:58 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit\/605.1.15 (KHTML, like Gecko) Version\/14.0.3 Mobile\/15E148 Safari\/604.1","download_id":"208","filename":"SERTIFIKAT_AIPT_2023-2027.pdf","timestamp":"2026-01-21 10:05:58"}
INFO - 2026-01-21 04:06:05 --> Config Class Initialized
INFO - 2026-01-21 04:06:05 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:06:05 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:06:05 --> Utf8 Class Initialized
INFO - 2026-01-21 04:06:05 --> URI Class Initialized
INFO - 2026-01-21 04:06:05 --> Router Class Initialized
INFO - 2026-01-21 04:06:05 --> Output Class Initialized
INFO - 2026-01-21 04:06:05 --> Security Class Initialized
DEBUG - 2026-01-21 04:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:06:05 --> CSRF cookie sent
INFO - 2026-01-21 04:06:05 --> Input Class Initialized
INFO - 2026-01-21 04:06:05 --> Language Class Initialized
INFO - 2026-01-21 04:06:05 --> Loader Class Initialized
INFO - 2026-01-21 04:06:05 --> Helper loaded: url_helper
INFO - 2026-01-21 04:06:05 --> Helper loaded: text_helper
INFO - 2026-01-21 04:06:05 --> Helper loaded: string_helper
INFO - 2026-01-21 04:06:05 --> Helper loaded: form_helper
INFO - 2026-01-21 04:06:05 --> Helper loaded: download_helper
INFO - 2026-01-21 04:06:05 --> Helper loaded: security_helper
INFO - 2026-01-21 04:06:05 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:06:05 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:06:05 --> Form Validation Class Initialized
INFO - 2026-01-21 04:06:05 --> Model "User_model" initialized
INFO - 2026-01-21 10:06:05 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:06:05 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:06:05 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:06:05 --> Controller Class Initialized
INFO - 2026-01-21 10:06:05 --> Model "Download_model" initialized
INFO - 2026-01-21 10:06:05 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:06:05 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:06:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-21 10:06:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:06:05 --> Model "Log_model" initialized
INFO - 2026-01-21 10:06:05 --> Final output sent to browser
DEBUG - 2026-01-21 10:06:05 --> Total execution time: 0.1098
INFO - 2026-01-21 04:06:07 --> Config Class Initialized
INFO - 2026-01-21 04:06:07 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:06:07 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:06:07 --> Utf8 Class Initialized
INFO - 2026-01-21 04:06:07 --> URI Class Initialized
INFO - 2026-01-21 04:06:07 --> Router Class Initialized
INFO - 2026-01-21 04:06:07 --> Output Class Initialized
INFO - 2026-01-21 04:06:07 --> Security Class Initialized
DEBUG - 2026-01-21 04:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:06:07 --> CSRF cookie sent
INFO - 2026-01-21 04:06:07 --> Input Class Initialized
INFO - 2026-01-21 04:06:07 --> Language Class Initialized
INFO - 2026-01-21 04:06:07 --> Loader Class Initialized
INFO - 2026-01-21 04:06:07 --> Helper loaded: url_helper
INFO - 2026-01-21 04:06:07 --> Helper loaded: text_helper
INFO - 2026-01-21 04:06:07 --> Helper loaded: string_helper
INFO - 2026-01-21 04:06:07 --> Helper loaded: form_helper
INFO - 2026-01-21 04:06:07 --> Helper loaded: download_helper
INFO - 2026-01-21 04:06:07 --> Helper loaded: security_helper
INFO - 2026-01-21 04:06:07 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:06:07 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:06:07 --> Form Validation Class Initialized
INFO - 2026-01-21 04:06:07 --> Model "User_model" initialized
INFO - 2026-01-21 10:06:07 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:06:07 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:06:07 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:06:07 --> Controller Class Initialized
INFO - 2026-01-21 10:06:07 --> Model "Download_model" initialized
INFO - 2026-01-21 10:06:07 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:06:07 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:06:07 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko\/20100101 Firefox\/147.0","download_id":"208","filename":"SERTIFIKAT_AIPT_2023-2027.pdf","timestamp":"2026-01-21 10:06:07"}
INFO - 2026-01-21 04:06:15 --> Config Class Initialized
INFO - 2026-01-21 04:06:15 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:06:15 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:06:15 --> Utf8 Class Initialized
INFO - 2026-01-21 04:06:15 --> URI Class Initialized
INFO - 2026-01-21 04:06:15 --> Router Class Initialized
INFO - 2026-01-21 04:06:15 --> Output Class Initialized
INFO - 2026-01-21 04:06:15 --> Security Class Initialized
DEBUG - 2026-01-21 04:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:06:16 --> CSRF cookie sent
INFO - 2026-01-21 04:06:16 --> Input Class Initialized
INFO - 2026-01-21 04:06:16 --> Language Class Initialized
INFO - 2026-01-21 04:06:16 --> Loader Class Initialized
INFO - 2026-01-21 04:06:16 --> Helper loaded: url_helper
INFO - 2026-01-21 04:06:16 --> Helper loaded: text_helper
INFO - 2026-01-21 04:06:16 --> Helper loaded: string_helper
INFO - 2026-01-21 04:06:16 --> Helper loaded: form_helper
INFO - 2026-01-21 04:06:16 --> Helper loaded: download_helper
INFO - 2026-01-21 04:06:16 --> Helper loaded: security_helper
INFO - 2026-01-21 04:06:16 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:06:16 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:06:16 --> Form Validation Class Initialized
INFO - 2026-01-21 04:06:16 --> Model "User_model" initialized
INFO - 2026-01-21 10:06:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:06:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:06:16 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:06:16 --> Controller Class Initialized
INFO - 2026-01-21 10:06:16 --> Model "Download_model" initialized
INFO - 2026-01-21 10:06:16 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:06:16 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:06:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-21 10:06:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:06:16 --> Model "Log_model" initialized
INFO - 2026-01-21 10:06:16 --> Final output sent to browser
DEBUG - 2026-01-21 10:06:16 --> Total execution time: 0.1360
INFO - 2026-01-21 04:06:19 --> Config Class Initialized
INFO - 2026-01-21 04:06:19 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:06:19 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:06:19 --> Utf8 Class Initialized
INFO - 2026-01-21 04:06:19 --> URI Class Initialized
INFO - 2026-01-21 04:06:19 --> Router Class Initialized
INFO - 2026-01-21 04:06:19 --> Output Class Initialized
INFO - 2026-01-21 04:06:19 --> Security Class Initialized
DEBUG - 2026-01-21 04:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:06:19 --> CSRF cookie sent
INFO - 2026-01-21 04:06:19 --> Input Class Initialized
INFO - 2026-01-21 04:06:19 --> Language Class Initialized
INFO - 2026-01-21 04:06:19 --> Loader Class Initialized
INFO - 2026-01-21 04:06:19 --> Helper loaded: url_helper
INFO - 2026-01-21 04:06:19 --> Helper loaded: text_helper
INFO - 2026-01-21 04:06:19 --> Helper loaded: string_helper
INFO - 2026-01-21 04:06:19 --> Helper loaded: form_helper
INFO - 2026-01-21 04:06:19 --> Helper loaded: download_helper
INFO - 2026-01-21 04:06:19 --> Helper loaded: security_helper
INFO - 2026-01-21 04:06:19 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:06:19 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:06:19 --> Form Validation Class Initialized
INFO - 2026-01-21 04:06:19 --> Model "User_model" initialized
INFO - 2026-01-21 10:06:19 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:06:19 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:06:19 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:06:19 --> Controller Class Initialized
INFO - 2026-01-21 10:06:19 --> Model "Download_model" initialized
INFO - 2026-01-21 10:06:19 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:06:19 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:06:19 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit\/605.1.15 (KHTML, like Gecko) Version\/14.0.3 Mobile\/15E148 Safari\/604.1","download_id":"12","filename":"Sertifikat_Akreditasi_Diploma_Tiga_Keperawatan_Kimia_2010-2014.pdf","timestamp":"2026-01-21 10:06:19"}
INFO - 2026-01-21 04:06:25 --> Config Class Initialized
INFO - 2026-01-21 04:06:25 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:06:25 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:06:25 --> Utf8 Class Initialized
INFO - 2026-01-21 04:06:25 --> URI Class Initialized
INFO - 2026-01-21 04:06:25 --> Router Class Initialized
INFO - 2026-01-21 04:06:25 --> Output Class Initialized
INFO - 2026-01-21 04:06:25 --> Security Class Initialized
DEBUG - 2026-01-21 04:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:06:25 --> CSRF cookie sent
INFO - 2026-01-21 04:06:25 --> Input Class Initialized
INFO - 2026-01-21 04:06:25 --> Language Class Initialized
INFO - 2026-01-21 04:06:25 --> Loader Class Initialized
INFO - 2026-01-21 04:06:25 --> Helper loaded: url_helper
INFO - 2026-01-21 04:06:25 --> Helper loaded: text_helper
INFO - 2026-01-21 04:06:25 --> Helper loaded: string_helper
INFO - 2026-01-21 04:06:25 --> Helper loaded: form_helper
INFO - 2026-01-21 04:06:25 --> Helper loaded: download_helper
INFO - 2026-01-21 04:06:25 --> Helper loaded: security_helper
INFO - 2026-01-21 04:06:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:06:25 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:06:25 --> Form Validation Class Initialized
INFO - 2026-01-21 04:06:25 --> Model "User_model" initialized
INFO - 2026-01-21 10:06:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:06:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:06:25 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:06:25 --> Controller Class Initialized
INFO - 2026-01-21 10:06:25 --> Model "Download_model" initialized
INFO - 2026-01-21 10:06:25 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:06:25 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:06:25 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit\/605.1.15 (KHTML, like Gecko) Version\/14.0.3 Mobile\/15E148 Safari\/604.1","download_id":"23","filename":"Sertifikat_Akreditasi_Diploma_Tiga_Teknologi_Laboratorium_Medis_2020-2025.pdf","timestamp":"2026-01-21 10:06:25"}
INFO - 2026-01-21 04:06:40 --> Config Class Initialized
INFO - 2026-01-21 04:06:40 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:06:40 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:06:40 --> Utf8 Class Initialized
INFO - 2026-01-21 04:06:40 --> URI Class Initialized
INFO - 2026-01-21 04:06:40 --> Router Class Initialized
INFO - 2026-01-21 04:06:40 --> Output Class Initialized
INFO - 2026-01-21 04:06:40 --> Security Class Initialized
DEBUG - 2026-01-21 04:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:06:40 --> CSRF cookie sent
INFO - 2026-01-21 04:06:40 --> Input Class Initialized
INFO - 2026-01-21 04:06:40 --> Language Class Initialized
INFO - 2026-01-21 04:06:40 --> Loader Class Initialized
INFO - 2026-01-21 04:06:40 --> Helper loaded: url_helper
INFO - 2026-01-21 04:06:40 --> Helper loaded: text_helper
INFO - 2026-01-21 04:06:40 --> Helper loaded: string_helper
INFO - 2026-01-21 04:06:40 --> Helper loaded: form_helper
INFO - 2026-01-21 04:06:40 --> Helper loaded: download_helper
INFO - 2026-01-21 04:06:40 --> Helper loaded: security_helper
INFO - 2026-01-21 04:06:40 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:06:40 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:06:40 --> Form Validation Class Initialized
INFO - 2026-01-21 04:06:40 --> Model "User_model" initialized
INFO - 2026-01-21 10:06:40 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:06:40 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:06:40 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:06:40 --> Controller Class Initialized
INFO - 2026-01-21 10:06:40 --> Model "Download_model" initialized
INFO - 2026-01-21 10:06:40 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:06:40 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:06:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-21 10:06:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:06:41 --> Model "Log_model" initialized
INFO - 2026-01-21 10:06:41 --> Final output sent to browser
DEBUG - 2026-01-21 10:06:41 --> Total execution time: 0.1075
INFO - 2026-01-21 04:06:53 --> Config Class Initialized
INFO - 2026-01-21 04:06:53 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:06:53 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:06:53 --> Utf8 Class Initialized
INFO - 2026-01-21 04:06:53 --> URI Class Initialized
INFO - 2026-01-21 04:06:53 --> Router Class Initialized
INFO - 2026-01-21 04:06:53 --> Output Class Initialized
INFO - 2026-01-21 04:06:53 --> Security Class Initialized
DEBUG - 2026-01-21 04:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:06:53 --> CSRF cookie sent
INFO - 2026-01-21 04:06:53 --> Input Class Initialized
INFO - 2026-01-21 04:06:53 --> Language Class Initialized
INFO - 2026-01-21 04:06:53 --> Loader Class Initialized
INFO - 2026-01-21 04:06:53 --> Helper loaded: url_helper
INFO - 2026-01-21 04:06:53 --> Helper loaded: text_helper
INFO - 2026-01-21 04:06:53 --> Helper loaded: string_helper
INFO - 2026-01-21 04:06:53 --> Helper loaded: form_helper
INFO - 2026-01-21 04:06:53 --> Helper loaded: download_helper
INFO - 2026-01-21 04:06:53 --> Helper loaded: security_helper
INFO - 2026-01-21 04:06:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:06:53 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:06:53 --> Form Validation Class Initialized
INFO - 2026-01-21 04:06:53 --> Model "User_model" initialized
INFO - 2026-01-21 10:06:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:06:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:06:53 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:06:53 --> Controller Class Initialized
INFO - 2026-01-21 10:06:53 --> Model "Download_model" initialized
INFO - 2026-01-21 10:06:53 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:06:53 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:06:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-21 10:06:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:06:53 --> Model "Log_model" initialized
INFO - 2026-01-21 10:06:53 --> Final output sent to browser
DEBUG - 2026-01-21 10:06:53 --> Total execution time: 0.1104
INFO - 2026-01-21 04:12:09 --> Config Class Initialized
INFO - 2026-01-21 04:12:09 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:12:09 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:12:09 --> Utf8 Class Initialized
INFO - 2026-01-21 04:12:09 --> URI Class Initialized
INFO - 2026-01-21 04:12:09 --> Router Class Initialized
INFO - 2026-01-21 04:12:09 --> Output Class Initialized
INFO - 2026-01-21 04:12:09 --> Security Class Initialized
DEBUG - 2026-01-21 04:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:12:09 --> CSRF cookie sent
INFO - 2026-01-21 04:12:09 --> Input Class Initialized
INFO - 2026-01-21 04:12:09 --> Language Class Initialized
INFO - 2026-01-21 04:12:09 --> Loader Class Initialized
INFO - 2026-01-21 04:12:09 --> Helper loaded: url_helper
INFO - 2026-01-21 04:12:09 --> Helper loaded: text_helper
INFO - 2026-01-21 04:12:09 --> Helper loaded: string_helper
INFO - 2026-01-21 04:12:09 --> Helper loaded: form_helper
INFO - 2026-01-21 04:12:09 --> Helper loaded: download_helper
INFO - 2026-01-21 04:12:09 --> Helper loaded: security_helper
INFO - 2026-01-21 04:12:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:12:09 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:12:09 --> Form Validation Class Initialized
INFO - 2026-01-21 04:12:09 --> Model "User_model" initialized
INFO - 2026-01-21 10:12:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:12:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:12:09 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:12:09 --> Controller Class Initialized
INFO - 2026-01-21 10:12:09 --> Model "Pages_model" initialized
INFO - 2026-01-21 10:12:09 --> Model "Berita_model" initialized
INFO - 2026-01-21 10:12:09 --> Model "Download_model" initialized
INFO - 2026-01-21 10:12:09 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:12:09 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:12:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/alumni.php
INFO - 2026-01-21 10:12:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:12:09 --> Model "Log_model" initialized
INFO - 2026-01-21 10:12:09 --> Final output sent to browser
DEBUG - 2026-01-21 10:12:09 --> Total execution time: 0.1241
INFO - 2026-01-21 04:12:44 --> Config Class Initialized
INFO - 2026-01-21 04:12:44 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:12:44 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:12:44 --> Utf8 Class Initialized
INFO - 2026-01-21 04:12:44 --> URI Class Initialized
INFO - 2026-01-21 04:12:44 --> Router Class Initialized
INFO - 2026-01-21 04:12:44 --> Output Class Initialized
INFO - 2026-01-21 04:12:44 --> Security Class Initialized
DEBUG - 2026-01-21 04:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:12:44 --> CSRF cookie sent
INFO - 2026-01-21 04:12:44 --> Input Class Initialized
INFO - 2026-01-21 04:12:44 --> Language Class Initialized
INFO - 2026-01-21 04:12:45 --> Loader Class Initialized
INFO - 2026-01-21 04:12:45 --> Helper loaded: url_helper
INFO - 2026-01-21 04:12:45 --> Helper loaded: text_helper
INFO - 2026-01-21 04:12:45 --> Helper loaded: string_helper
INFO - 2026-01-21 04:12:45 --> Helper loaded: form_helper
INFO - 2026-01-21 04:12:45 --> Helper loaded: download_helper
INFO - 2026-01-21 04:12:45 --> Helper loaded: security_helper
INFO - 2026-01-21 04:12:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:12:45 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:12:45 --> Form Validation Class Initialized
INFO - 2026-01-21 04:12:45 --> Model "User_model" initialized
INFO - 2026-01-21 10:12:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:12:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:12:45 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:12:45 --> Controller Class Initialized
INFO - 2026-01-21 10:12:45 --> Model "Unit_model" initialized
INFO - 2026-01-21 10:12:45 --> Model "Prodi_model" initialized
INFO - 2026-01-21 10:12:45 --> Model "Sdm_model" initialized
INFO - 2026-01-21 10:12:45 --> Model "Sdm_unit_model" initialized
INFO - 2026-01-21 10:12:45 --> Query SDM berhasil untuk unit: Unit Pengembangan Bahasa, Total: 1
INFO - 2026-01-21 10:12:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\unit/list.php
INFO - 2026-01-21 10:12:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:12:45 --> Model "Log_model" initialized
INFO - 2026-01-21 10:12:45 --> Final output sent to browser
DEBUG - 2026-01-21 10:12:45 --> Total execution time: 0.6436
INFO - 2026-01-21 04:12:54 --> Config Class Initialized
INFO - 2026-01-21 04:12:54 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:12:54 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:12:54 --> Utf8 Class Initialized
INFO - 2026-01-21 04:12:54 --> URI Class Initialized
DEBUG - 2026-01-21 04:12:54 --> No URI present. Default controller set.
INFO - 2026-01-21 04:12:54 --> Router Class Initialized
INFO - 2026-01-21 04:12:54 --> Output Class Initialized
INFO - 2026-01-21 04:12:54 --> Security Class Initialized
DEBUG - 2026-01-21 04:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:12:54 --> CSRF cookie sent
INFO - 2026-01-21 04:12:54 --> Input Class Initialized
INFO - 2026-01-21 04:12:54 --> Language Class Initialized
INFO - 2026-01-21 04:12:54 --> Loader Class Initialized
INFO - 2026-01-21 04:12:54 --> Helper loaded: url_helper
INFO - 2026-01-21 04:12:54 --> Helper loaded: text_helper
INFO - 2026-01-21 04:12:54 --> Helper loaded: string_helper
INFO - 2026-01-21 04:12:54 --> Helper loaded: form_helper
INFO - 2026-01-21 04:12:54 --> Helper loaded: download_helper
INFO - 2026-01-21 04:12:54 --> Helper loaded: security_helper
INFO - 2026-01-21 04:12:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:12:54 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:12:54 --> Form Validation Class Initialized
INFO - 2026-01-21 04:12:54 --> Model "User_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:12:54 --> Controller Class Initialized
INFO - 2026-01-21 10:12:54 --> Model "Berita_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Galeri_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Video_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Agenda_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Tautan_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Mitra_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Prodi_model" initialized
INFO - 2026-01-21 10:12:54 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 10:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 10:12:55 --> Pagination Class Initialized
INFO - 2026-01-21 10:12:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 10:12:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:12:55 --> Model "Log_model" initialized
INFO - 2026-01-21 10:12:55 --> Final output sent to browser
DEBUG - 2026-01-21 10:12:55 --> Total execution time: 0.2159
INFO - 2026-01-21 04:17:52 --> Config Class Initialized
INFO - 2026-01-21 04:17:52 --> Hooks Class Initialized
DEBUG - 2026-01-21 04:17:52 --> UTF-8 Support Enabled
INFO - 2026-01-21 04:17:52 --> Utf8 Class Initialized
INFO - 2026-01-21 04:17:52 --> URI Class Initialized
INFO - 2026-01-21 04:17:52 --> Router Class Initialized
INFO - 2026-01-21 04:17:52 --> Output Class Initialized
INFO - 2026-01-21 04:17:52 --> Security Class Initialized
DEBUG - 2026-01-21 04:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 04:17:52 --> CSRF cookie sent
INFO - 2026-01-21 04:17:52 --> Input Class Initialized
INFO - 2026-01-21 04:17:52 --> Language Class Initialized
INFO - 2026-01-21 04:17:52 --> Loader Class Initialized
INFO - 2026-01-21 04:17:52 --> Helper loaded: url_helper
INFO - 2026-01-21 04:17:52 --> Helper loaded: text_helper
INFO - 2026-01-21 04:17:52 --> Helper loaded: string_helper
INFO - 2026-01-21 04:17:52 --> Helper loaded: form_helper
INFO - 2026-01-21 04:17:52 --> Helper loaded: download_helper
INFO - 2026-01-21 04:17:52 --> Helper loaded: security_helper
INFO - 2026-01-21 04:17:52 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 04:17:52 --> Database Driver Class Initialized
DEBUG - 2026-01-21 04:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 04:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 04:17:52 --> Form Validation Class Initialized
INFO - 2026-01-21 04:17:52 --> Model "User_model" initialized
INFO - 2026-01-21 10:17:52 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 10:17:52 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 10:17:52 --> Model "Nav_model" initialized
INFO - 2026-01-21 10:17:52 --> Controller Class Initialized
INFO - 2026-01-21 10:17:52 --> Model "Pages_model" initialized
INFO - 2026-01-21 10:17:52 --> Model "Berita_model" initialized
INFO - 2026-01-21 10:17:52 --> Model "Download_model" initialized
INFO - 2026-01-21 10:17:52 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 10:17:52 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 10:17:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-21 10:17:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 10:17:52 --> Model "Log_model" initialized
INFO - 2026-01-21 10:17:52 --> Final output sent to browser
DEBUG - 2026-01-21 10:17:52 --> Total execution time: 0.1278
INFO - 2026-01-21 07:06:29 --> Config Class Initialized
INFO - 2026-01-21 07:06:29 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:06:29 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:06:29 --> Utf8 Class Initialized
INFO - 2026-01-21 07:06:29 --> URI Class Initialized
DEBUG - 2026-01-21 07:06:29 --> No URI present. Default controller set.
INFO - 2026-01-21 07:06:29 --> Router Class Initialized
INFO - 2026-01-21 07:06:30 --> Output Class Initialized
INFO - 2026-01-21 07:06:30 --> Security Class Initialized
DEBUG - 2026-01-21 07:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:06:30 --> CSRF cookie sent
INFO - 2026-01-21 07:06:30 --> Input Class Initialized
INFO - 2026-01-21 07:06:30 --> Language Class Initialized
INFO - 2026-01-21 07:06:30 --> Loader Class Initialized
INFO - 2026-01-21 07:06:30 --> Helper loaded: url_helper
INFO - 2026-01-21 07:06:30 --> Helper loaded: text_helper
INFO - 2026-01-21 07:06:30 --> Helper loaded: string_helper
INFO - 2026-01-21 07:06:30 --> Helper loaded: form_helper
INFO - 2026-01-21 07:06:30 --> Helper loaded: download_helper
INFO - 2026-01-21 07:06:30 --> Helper loaded: security_helper
INFO - 2026-01-21 07:06:30 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:06:31 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:06:31 --> Form Validation Class Initialized
INFO - 2026-01-21 07:06:31 --> Model "User_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:06:31 --> Controller Class Initialized
INFO - 2026-01-21 13:06:31 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Video_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:06:31 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:06:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:06:31 --> Pagination Class Initialized
INFO - 2026-01-21 13:06:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:06:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:06:34 --> Model "Log_model" initialized
INFO - 2026-01-21 13:06:34 --> Final output sent to browser
DEBUG - 2026-01-21 13:06:34 --> Total execution time: 5.0448
INFO - 2026-01-21 07:06:38 --> Config Class Initialized
INFO - 2026-01-21 07:06:38 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:06:38 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:06:38 --> Utf8 Class Initialized
INFO - 2026-01-21 07:06:38 --> URI Class Initialized
DEBUG - 2026-01-21 07:06:38 --> No URI present. Default controller set.
INFO - 2026-01-21 07:06:38 --> Router Class Initialized
INFO - 2026-01-21 07:06:38 --> Output Class Initialized
INFO - 2026-01-21 07:06:39 --> Security Class Initialized
DEBUG - 2026-01-21 07:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:06:39 --> CSRF cookie sent
INFO - 2026-01-21 07:06:39 --> Input Class Initialized
INFO - 2026-01-21 07:06:39 --> Language Class Initialized
INFO - 2026-01-21 07:06:39 --> Loader Class Initialized
INFO - 2026-01-21 07:06:39 --> Helper loaded: url_helper
INFO - 2026-01-21 07:06:39 --> Helper loaded: text_helper
INFO - 2026-01-21 07:06:39 --> Helper loaded: string_helper
INFO - 2026-01-21 07:06:39 --> Helper loaded: form_helper
INFO - 2026-01-21 07:06:39 --> Helper loaded: download_helper
INFO - 2026-01-21 07:06:39 --> Helper loaded: security_helper
INFO - 2026-01-21 07:06:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:06:39 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:06:39 --> Form Validation Class Initialized
INFO - 2026-01-21 07:06:39 --> Model "User_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:06:39 --> Controller Class Initialized
INFO - 2026-01-21 13:06:39 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Video_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:06:39 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:06:39 --> Pagination Class Initialized
INFO - 2026-01-21 13:06:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:06:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:06:39 --> Model "Log_model" initialized
INFO - 2026-01-21 13:06:39 --> Final output sent to browser
DEBUG - 2026-01-21 13:06:39 --> Total execution time: 0.2671
INFO - 2026-01-21 07:06:53 --> Config Class Initialized
INFO - 2026-01-21 07:06:53 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:06:53 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:06:53 --> Utf8 Class Initialized
INFO - 2026-01-21 07:06:53 --> URI Class Initialized
DEBUG - 2026-01-21 07:06:53 --> No URI present. Default controller set.
INFO - 2026-01-21 07:06:53 --> Router Class Initialized
INFO - 2026-01-21 07:06:53 --> Output Class Initialized
INFO - 2026-01-21 07:06:53 --> Security Class Initialized
DEBUG - 2026-01-21 07:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:06:53 --> CSRF cookie sent
INFO - 2026-01-21 07:06:53 --> Input Class Initialized
INFO - 2026-01-21 07:06:53 --> Language Class Initialized
INFO - 2026-01-21 07:06:53 --> Loader Class Initialized
INFO - 2026-01-21 07:06:53 --> Helper loaded: url_helper
INFO - 2026-01-21 07:06:53 --> Helper loaded: text_helper
INFO - 2026-01-21 07:06:53 --> Helper loaded: string_helper
INFO - 2026-01-21 07:06:53 --> Helper loaded: form_helper
INFO - 2026-01-21 07:06:53 --> Helper loaded: download_helper
INFO - 2026-01-21 07:06:53 --> Helper loaded: security_helper
INFO - 2026-01-21 07:06:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:06:53 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:06:53 --> Form Validation Class Initialized
INFO - 2026-01-21 07:06:53 --> Model "User_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:06:53 --> Controller Class Initialized
INFO - 2026-01-21 13:06:53 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Video_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:06:53 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:06:53 --> Pagination Class Initialized
INFO - 2026-01-21 13:06:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:06:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:06:53 --> Model "Log_model" initialized
INFO - 2026-01-21 13:06:53 --> Final output sent to browser
DEBUG - 2026-01-21 13:06:53 --> Total execution time: 0.1742
INFO - 2026-01-21 07:07:05 --> Config Class Initialized
INFO - 2026-01-21 07:07:05 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:07:05 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:07:05 --> Utf8 Class Initialized
INFO - 2026-01-21 07:07:05 --> URI Class Initialized
DEBUG - 2026-01-21 07:07:05 --> No URI present. Default controller set.
INFO - 2026-01-21 07:07:05 --> Router Class Initialized
INFO - 2026-01-21 07:07:05 --> Output Class Initialized
INFO - 2026-01-21 07:07:05 --> Security Class Initialized
DEBUG - 2026-01-21 07:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:07:05 --> CSRF cookie sent
INFO - 2026-01-21 07:07:05 --> Input Class Initialized
INFO - 2026-01-21 07:07:05 --> Language Class Initialized
INFO - 2026-01-21 07:07:05 --> Loader Class Initialized
INFO - 2026-01-21 07:07:05 --> Helper loaded: url_helper
INFO - 2026-01-21 07:07:05 --> Helper loaded: text_helper
INFO - 2026-01-21 07:07:05 --> Helper loaded: string_helper
INFO - 2026-01-21 07:07:05 --> Helper loaded: form_helper
INFO - 2026-01-21 07:07:05 --> Helper loaded: download_helper
INFO - 2026-01-21 07:07:05 --> Helper loaded: security_helper
INFO - 2026-01-21 07:07:05 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:07:05 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:07:05 --> Form Validation Class Initialized
INFO - 2026-01-21 07:07:05 --> Model "User_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:07:05 --> Controller Class Initialized
INFO - 2026-01-21 13:07:05 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Video_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:07:05 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:07:06 --> Pagination Class Initialized
INFO - 2026-01-21 13:07:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:07:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:07:06 --> Model "Log_model" initialized
INFO - 2026-01-21 13:07:06 --> Final output sent to browser
DEBUG - 2026-01-21 13:07:06 --> Total execution time: 0.2128
INFO - 2026-01-21 07:07:08 --> Config Class Initialized
INFO - 2026-01-21 07:07:08 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:07:08 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:07:08 --> Utf8 Class Initialized
INFO - 2026-01-21 07:07:08 --> URI Class Initialized
DEBUG - 2026-01-21 07:07:08 --> No URI present. Default controller set.
INFO - 2026-01-21 07:07:08 --> Router Class Initialized
INFO - 2026-01-21 07:07:08 --> Output Class Initialized
INFO - 2026-01-21 07:07:08 --> Security Class Initialized
DEBUG - 2026-01-21 07:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:07:08 --> CSRF cookie sent
INFO - 2026-01-21 07:07:08 --> Input Class Initialized
INFO - 2026-01-21 07:07:08 --> Language Class Initialized
INFO - 2026-01-21 07:07:08 --> Loader Class Initialized
INFO - 2026-01-21 07:07:08 --> Helper loaded: url_helper
INFO - 2026-01-21 07:07:08 --> Helper loaded: text_helper
INFO - 2026-01-21 07:07:08 --> Helper loaded: string_helper
INFO - 2026-01-21 07:07:08 --> Helper loaded: form_helper
INFO - 2026-01-21 07:07:08 --> Helper loaded: download_helper
INFO - 2026-01-21 07:07:08 --> Helper loaded: security_helper
INFO - 2026-01-21 07:07:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:07:08 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:07:08 --> Form Validation Class Initialized
INFO - 2026-01-21 07:07:08 --> Model "User_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:07:08 --> Controller Class Initialized
INFO - 2026-01-21 13:07:08 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Video_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:07:08 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:07:08 --> Pagination Class Initialized
INFO - 2026-01-21 13:07:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:07:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:07:08 --> Model "Log_model" initialized
INFO - 2026-01-21 13:07:08 --> Final output sent to browser
DEBUG - 2026-01-21 13:07:08 --> Total execution time: 0.1944
INFO - 2026-01-21 07:07:21 --> Config Class Initialized
INFO - 2026-01-21 07:07:21 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:07:21 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:07:21 --> Utf8 Class Initialized
INFO - 2026-01-21 07:07:21 --> URI Class Initialized
DEBUG - 2026-01-21 07:07:21 --> No URI present. Default controller set.
INFO - 2026-01-21 07:07:21 --> Router Class Initialized
INFO - 2026-01-21 07:07:21 --> Output Class Initialized
INFO - 2026-01-21 07:07:21 --> Security Class Initialized
DEBUG - 2026-01-21 07:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:07:21 --> CSRF cookie sent
INFO - 2026-01-21 07:07:21 --> Input Class Initialized
INFO - 2026-01-21 07:07:21 --> Language Class Initialized
INFO - 2026-01-21 07:07:21 --> Loader Class Initialized
INFO - 2026-01-21 07:07:21 --> Helper loaded: url_helper
INFO - 2026-01-21 07:07:21 --> Helper loaded: text_helper
INFO - 2026-01-21 07:07:21 --> Helper loaded: string_helper
INFO - 2026-01-21 07:07:21 --> Helper loaded: form_helper
INFO - 2026-01-21 07:07:21 --> Helper loaded: download_helper
INFO - 2026-01-21 07:07:21 --> Helper loaded: security_helper
INFO - 2026-01-21 07:07:21 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:07:21 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:07:21 --> Form Validation Class Initialized
INFO - 2026-01-21 07:07:21 --> Model "User_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:07:21 --> Controller Class Initialized
INFO - 2026-01-21 13:07:21 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Video_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:07:21 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:07:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:07:21 --> Pagination Class Initialized
INFO - 2026-01-21 13:07:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:07:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:07:21 --> Model "Log_model" initialized
INFO - 2026-01-21 13:07:21 --> Final output sent to browser
DEBUG - 2026-01-21 13:07:21 --> Total execution time: 0.1634
INFO - 2026-01-21 07:07:33 --> Config Class Initialized
INFO - 2026-01-21 07:07:33 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:07:33 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:07:33 --> Utf8 Class Initialized
INFO - 2026-01-21 07:07:33 --> URI Class Initialized
DEBUG - 2026-01-21 07:07:33 --> No URI present. Default controller set.
INFO - 2026-01-21 07:07:33 --> Router Class Initialized
INFO - 2026-01-21 07:07:33 --> Output Class Initialized
INFO - 2026-01-21 07:07:33 --> Security Class Initialized
DEBUG - 2026-01-21 07:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:07:33 --> CSRF cookie sent
INFO - 2026-01-21 07:07:33 --> Input Class Initialized
INFO - 2026-01-21 07:07:33 --> Language Class Initialized
INFO - 2026-01-21 07:07:33 --> Loader Class Initialized
INFO - 2026-01-21 07:07:33 --> Helper loaded: url_helper
INFO - 2026-01-21 07:07:33 --> Helper loaded: text_helper
INFO - 2026-01-21 07:07:33 --> Helper loaded: string_helper
INFO - 2026-01-21 07:07:33 --> Helper loaded: form_helper
INFO - 2026-01-21 07:07:33 --> Helper loaded: download_helper
INFO - 2026-01-21 07:07:33 --> Helper loaded: security_helper
INFO - 2026-01-21 07:07:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:07:33 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:07:33 --> Form Validation Class Initialized
INFO - 2026-01-21 07:07:33 --> Model "User_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:07:33 --> Controller Class Initialized
INFO - 2026-01-21 13:07:33 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Video_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:07:33 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:07:33 --> Pagination Class Initialized
INFO - 2026-01-21 13:07:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:07:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:07:33 --> Model "Log_model" initialized
INFO - 2026-01-21 13:07:33 --> Final output sent to browser
DEBUG - 2026-01-21 13:07:33 --> Total execution time: 0.1904
INFO - 2026-01-21 07:07:35 --> Config Class Initialized
INFO - 2026-01-21 07:07:35 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:07:35 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:07:35 --> Utf8 Class Initialized
INFO - 2026-01-21 07:07:35 --> URI Class Initialized
DEBUG - 2026-01-21 07:07:35 --> No URI present. Default controller set.
INFO - 2026-01-21 07:07:35 --> Router Class Initialized
INFO - 2026-01-21 07:07:35 --> Output Class Initialized
INFO - 2026-01-21 07:07:35 --> Security Class Initialized
DEBUG - 2026-01-21 07:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:07:35 --> CSRF cookie sent
INFO - 2026-01-21 07:07:35 --> Input Class Initialized
INFO - 2026-01-21 07:07:35 --> Language Class Initialized
INFO - 2026-01-21 07:07:35 --> Loader Class Initialized
INFO - 2026-01-21 07:07:35 --> Helper loaded: url_helper
INFO - 2026-01-21 07:07:35 --> Helper loaded: text_helper
INFO - 2026-01-21 07:07:35 --> Helper loaded: string_helper
INFO - 2026-01-21 07:07:35 --> Helper loaded: form_helper
INFO - 2026-01-21 07:07:35 --> Helper loaded: download_helper
INFO - 2026-01-21 07:07:35 --> Helper loaded: security_helper
INFO - 2026-01-21 07:07:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:07:35 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:07:35 --> Form Validation Class Initialized
INFO - 2026-01-21 07:07:35 --> Model "User_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:07:35 --> Controller Class Initialized
INFO - 2026-01-21 13:07:35 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Video_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:07:35 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:07:35 --> Pagination Class Initialized
INFO - 2026-01-21 13:07:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:07:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:07:35 --> Model "Log_model" initialized
INFO - 2026-01-21 13:07:35 --> Final output sent to browser
DEBUG - 2026-01-21 13:07:35 --> Total execution time: 0.2409
INFO - 2026-01-21 07:08:26 --> Config Class Initialized
INFO - 2026-01-21 07:08:26 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:08:26 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:08:26 --> Utf8 Class Initialized
INFO - 2026-01-21 07:08:26 --> URI Class Initialized
INFO - 2026-01-21 07:08:26 --> Router Class Initialized
INFO - 2026-01-21 07:08:26 --> Output Class Initialized
INFO - 2026-01-21 07:08:26 --> Security Class Initialized
DEBUG - 2026-01-21 07:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:08:26 --> CSRF cookie sent
INFO - 2026-01-21 07:08:26 --> Input Class Initialized
INFO - 2026-01-21 07:08:26 --> Language Class Initialized
INFO - 2026-01-21 07:08:26 --> Loader Class Initialized
INFO - 2026-01-21 07:08:26 --> Helper loaded: url_helper
INFO - 2026-01-21 07:08:26 --> Helper loaded: text_helper
INFO - 2026-01-21 07:08:26 --> Helper loaded: string_helper
INFO - 2026-01-21 07:08:26 --> Helper loaded: form_helper
INFO - 2026-01-21 07:08:26 --> Helper loaded: download_helper
INFO - 2026-01-21 07:08:26 --> Helper loaded: security_helper
INFO - 2026-01-21 07:08:26 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:08:26 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:08:26 --> Form Validation Class Initialized
INFO - 2026-01-21 07:08:26 --> Model "User_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:08:26 --> Controller Class Initialized
INFO - 2026-01-21 13:08:26 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Video_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:08:26 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:08:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-21 13:08:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:08:26 --> Model "Log_model" initialized
INFO - 2026-01-21 13:08:26 --> Final output sent to browser
DEBUG - 2026-01-21 13:08:26 --> Total execution time: 0.1297
INFO - 2026-01-21 07:08:32 --> Config Class Initialized
INFO - 2026-01-21 07:08:32 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:08:32 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:08:32 --> Utf8 Class Initialized
INFO - 2026-01-21 07:08:32 --> URI Class Initialized
INFO - 2026-01-21 07:08:32 --> Router Class Initialized
INFO - 2026-01-21 07:08:32 --> Output Class Initialized
INFO - 2026-01-21 07:08:32 --> Security Class Initialized
DEBUG - 2026-01-21 07:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:08:32 --> CSRF cookie sent
INFO - 2026-01-21 07:08:32 --> Input Class Initialized
INFO - 2026-01-21 07:08:32 --> Language Class Initialized
INFO - 2026-01-21 07:08:32 --> Loader Class Initialized
INFO - 2026-01-21 07:08:32 --> Helper loaded: url_helper
INFO - 2026-01-21 07:08:32 --> Helper loaded: text_helper
INFO - 2026-01-21 07:08:32 --> Helper loaded: string_helper
INFO - 2026-01-21 07:08:32 --> Helper loaded: form_helper
INFO - 2026-01-21 07:08:32 --> Helper loaded: download_helper
INFO - 2026-01-21 07:08:32 --> Helper loaded: security_helper
INFO - 2026-01-21 07:08:32 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:08:32 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:08:32 --> Form Validation Class Initialized
INFO - 2026-01-21 07:08:32 --> Model "User_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:08:32 --> Controller Class Initialized
INFO - 2026-01-21 13:08:32 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Video_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:08:32 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:08:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-21 13:08:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:08:32 --> Model "Log_model" initialized
INFO - 2026-01-21 13:08:32 --> Final output sent to browser
DEBUG - 2026-01-21 13:08:32 --> Total execution time: 0.1886
INFO - 2026-01-21 07:08:37 --> Config Class Initialized
INFO - 2026-01-21 07:08:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:08:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:08:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:08:37 --> URI Class Initialized
DEBUG - 2026-01-21 07:08:37 --> No URI present. Default controller set.
INFO - 2026-01-21 07:08:37 --> Router Class Initialized
INFO - 2026-01-21 07:08:37 --> Output Class Initialized
INFO - 2026-01-21 07:08:37 --> Security Class Initialized
DEBUG - 2026-01-21 07:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:08:37 --> CSRF cookie sent
INFO - 2026-01-21 07:08:37 --> Input Class Initialized
INFO - 2026-01-21 07:08:37 --> Language Class Initialized
INFO - 2026-01-21 07:08:37 --> Loader Class Initialized
INFO - 2026-01-21 07:08:37 --> Helper loaded: url_helper
INFO - 2026-01-21 07:08:37 --> Helper loaded: text_helper
INFO - 2026-01-21 07:08:37 --> Helper loaded: string_helper
INFO - 2026-01-21 07:08:37 --> Helper loaded: form_helper
INFO - 2026-01-21 07:08:37 --> Helper loaded: download_helper
INFO - 2026-01-21 07:08:37 --> Helper loaded: security_helper
INFO - 2026-01-21 07:08:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:08:37 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:08:37 --> Form Validation Class Initialized
INFO - 2026-01-21 07:08:37 --> Model "User_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:08:37 --> Controller Class Initialized
INFO - 2026-01-21 13:08:37 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Video_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:08:37 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:08:37 --> Pagination Class Initialized
INFO - 2026-01-21 13:08:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:08:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:08:37 --> Model "Log_model" initialized
INFO - 2026-01-21 13:08:37 --> Final output sent to browser
DEBUG - 2026-01-21 13:08:37 --> Total execution time: 0.2331
INFO - 2026-01-21 07:08:41 --> Config Class Initialized
INFO - 2026-01-21 07:08:41 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:08:41 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:08:41 --> Utf8 Class Initialized
INFO - 2026-01-21 07:08:41 --> URI Class Initialized
INFO - 2026-01-21 07:08:41 --> Router Class Initialized
INFO - 2026-01-21 07:08:41 --> Output Class Initialized
INFO - 2026-01-21 07:08:41 --> Security Class Initialized
DEBUG - 2026-01-21 07:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:08:41 --> CSRF cookie sent
INFO - 2026-01-21 07:08:41 --> Input Class Initialized
INFO - 2026-01-21 07:08:41 --> Language Class Initialized
INFO - 2026-01-21 07:08:41 --> Loader Class Initialized
INFO - 2026-01-21 07:08:41 --> Helper loaded: url_helper
INFO - 2026-01-21 07:08:41 --> Helper loaded: text_helper
INFO - 2026-01-21 07:08:41 --> Helper loaded: string_helper
INFO - 2026-01-21 07:08:41 --> Helper loaded: form_helper
INFO - 2026-01-21 07:08:41 --> Helper loaded: download_helper
INFO - 2026-01-21 07:08:41 --> Helper loaded: security_helper
INFO - 2026-01-21 07:08:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:08:41 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:08:41 --> Form Validation Class Initialized
INFO - 2026-01-21 07:08:41 --> Model "User_model" initialized
INFO - 2026-01-21 13:08:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:08:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:08:41 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:08:41 --> Controller Class Initialized
DEBUG - 2026-01-21 13:08:41 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-21 13:08:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-21 13:08:41 --> Model "Log_model" initialized
INFO - 2026-01-21 13:08:41 --> Final output sent to browser
DEBUG - 2026-01-21 13:08:41 --> Total execution time: 0.3742
INFO - 2026-01-21 07:08:49 --> Config Class Initialized
INFO - 2026-01-21 07:08:49 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:08:49 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:08:49 --> Utf8 Class Initialized
INFO - 2026-01-21 07:08:49 --> URI Class Initialized
INFO - 2026-01-21 07:08:49 --> Router Class Initialized
INFO - 2026-01-21 07:08:49 --> Output Class Initialized
INFO - 2026-01-21 07:08:49 --> Security Class Initialized
DEBUG - 2026-01-21 07:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:08:49 --> CSRF cookie sent
INFO - 2026-01-21 07:08:49 --> CSRF token verified
INFO - 2026-01-21 07:08:49 --> Input Class Initialized
INFO - 2026-01-21 07:08:49 --> Language Class Initialized
INFO - 2026-01-21 07:08:49 --> Loader Class Initialized
INFO - 2026-01-21 07:08:49 --> Helper loaded: url_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: text_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: string_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: form_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: download_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: security_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:08:49 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:08:49 --> Form Validation Class Initialized
INFO - 2026-01-21 07:08:49 --> Model "User_model" initialized
INFO - 2026-01-21 13:08:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:08:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:08:49 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:08:49 --> Controller Class Initialized
DEBUG - 2026-01-21 13:08:49 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-21 13:08:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-21 07:08:49 --> Config Class Initialized
INFO - 2026-01-21 07:08:49 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:08:49 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:08:49 --> Utf8 Class Initialized
INFO - 2026-01-21 07:08:49 --> URI Class Initialized
INFO - 2026-01-21 07:08:49 --> Router Class Initialized
INFO - 2026-01-21 07:08:49 --> Output Class Initialized
INFO - 2026-01-21 07:08:49 --> Security Class Initialized
DEBUG - 2026-01-21 07:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:08:49 --> CSRF cookie sent
INFO - 2026-01-21 07:08:49 --> Input Class Initialized
INFO - 2026-01-21 07:08:49 --> Language Class Initialized
INFO - 2026-01-21 07:08:49 --> Loader Class Initialized
INFO - 2026-01-21 07:08:49 --> Helper loaded: url_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: text_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: string_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: form_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: download_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: security_helper
INFO - 2026-01-21 07:08:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:08:49 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:08:49 --> Form Validation Class Initialized
INFO - 2026-01-21 07:08:49 --> Model "User_model" initialized
INFO - 2026-01-21 13:08:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:08:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:08:49 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:08:49 --> Controller Class Initialized
INFO - 2026-01-21 13:08:49 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:08:49 --> Model "Staff_model" initialized
INFO - 2026-01-21 13:08:49 --> Model "Dasbor_model" initialized
INFO - 2026-01-21 13:08:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2026-01-21 13:08:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 13:08:51 --> Model "Log_model" initialized
INFO - 2026-01-21 13:08:51 --> Final output sent to browser
DEBUG - 2026-01-21 13:08:51 --> Total execution time: 2.2009
INFO - 2026-01-21 07:08:57 --> Config Class Initialized
INFO - 2026-01-21 07:08:57 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:08:57 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:08:57 --> Utf8 Class Initialized
INFO - 2026-01-21 07:08:57 --> URI Class Initialized
INFO - 2026-01-21 07:08:57 --> Router Class Initialized
INFO - 2026-01-21 07:08:57 --> Output Class Initialized
INFO - 2026-01-21 07:08:57 --> Security Class Initialized
DEBUG - 2026-01-21 07:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:08:57 --> CSRF cookie sent
INFO - 2026-01-21 07:08:57 --> Input Class Initialized
INFO - 2026-01-21 07:08:57 --> Language Class Initialized
INFO - 2026-01-21 07:08:57 --> Loader Class Initialized
INFO - 2026-01-21 07:08:57 --> Helper loaded: url_helper
INFO - 2026-01-21 07:08:57 --> Helper loaded: text_helper
INFO - 2026-01-21 07:08:57 --> Helper loaded: string_helper
INFO - 2026-01-21 07:08:57 --> Helper loaded: form_helper
INFO - 2026-01-21 07:08:57 --> Helper loaded: download_helper
INFO - 2026-01-21 07:08:57 --> Helper loaded: security_helper
INFO - 2026-01-21 07:08:57 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:08:57 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:08:57 --> Form Validation Class Initialized
INFO - 2026-01-21 07:08:57 --> Model "User_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:08:57 --> Controller Class Initialized
INFO - 2026-01-21 13:08:57 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Video_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:08:57 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:08:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-21 13:08:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:08:57 --> Model "Log_model" initialized
INFO - 2026-01-21 13:08:57 --> Final output sent to browser
DEBUG - 2026-01-21 13:08:57 --> Total execution time: 0.1257
INFO - 2026-01-21 07:09:10 --> Config Class Initialized
INFO - 2026-01-21 07:09:10 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:09:10 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:09:10 --> Utf8 Class Initialized
INFO - 2026-01-21 07:09:10 --> URI Class Initialized
INFO - 2026-01-21 07:09:10 --> Router Class Initialized
INFO - 2026-01-21 07:09:10 --> Output Class Initialized
INFO - 2026-01-21 07:09:10 --> Security Class Initialized
DEBUG - 2026-01-21 07:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:09:10 --> CSRF cookie sent
INFO - 2026-01-21 07:09:10 --> Input Class Initialized
INFO - 2026-01-21 07:09:10 --> Language Class Initialized
INFO - 2026-01-21 07:09:10 --> Loader Class Initialized
INFO - 2026-01-21 07:09:10 --> Helper loaded: url_helper
INFO - 2026-01-21 07:09:10 --> Helper loaded: text_helper
INFO - 2026-01-21 07:09:10 --> Helper loaded: string_helper
INFO - 2026-01-21 07:09:10 --> Helper loaded: form_helper
INFO - 2026-01-21 07:09:10 --> Helper loaded: download_helper
INFO - 2026-01-21 07:09:10 --> Helper loaded: security_helper
INFO - 2026-01-21 07:09:10 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:09:10 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:09:10 --> Form Validation Class Initialized
INFO - 2026-01-21 07:09:10 --> Model "User_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:09:10 --> Controller Class Initialized
INFO - 2026-01-21 13:09:10 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Video_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:09:10 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:09:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-21 13:09:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:09:10 --> Model "Log_model" initialized
INFO - 2026-01-21 13:09:10 --> Final output sent to browser
DEBUG - 2026-01-21 13:09:10 --> Total execution time: 0.1499
INFO - 2026-01-21 07:09:15 --> Config Class Initialized
INFO - 2026-01-21 07:09:15 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:09:15 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:09:15 --> Utf8 Class Initialized
INFO - 2026-01-21 07:09:15 --> URI Class Initialized
INFO - 2026-01-21 07:09:15 --> Router Class Initialized
INFO - 2026-01-21 07:09:15 --> Output Class Initialized
INFO - 2026-01-21 07:09:15 --> Security Class Initialized
DEBUG - 2026-01-21 07:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:09:15 --> CSRF cookie sent
INFO - 2026-01-21 07:09:15 --> Input Class Initialized
INFO - 2026-01-21 07:09:15 --> Language Class Initialized
INFO - 2026-01-21 07:09:15 --> Loader Class Initialized
INFO - 2026-01-21 07:09:15 --> Helper loaded: url_helper
INFO - 2026-01-21 07:09:15 --> Helper loaded: text_helper
INFO - 2026-01-21 07:09:15 --> Helper loaded: string_helper
INFO - 2026-01-21 07:09:15 --> Helper loaded: form_helper
INFO - 2026-01-21 07:09:15 --> Helper loaded: download_helper
INFO - 2026-01-21 07:09:15 --> Helper loaded: security_helper
INFO - 2026-01-21 07:09:15 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:09:15 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:09:15 --> Form Validation Class Initialized
INFO - 2026-01-21 07:09:15 --> Model "User_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:09:15 --> Controller Class Initialized
INFO - 2026-01-21 13:09:15 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Video_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:09:15 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:09:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-21 13:09:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:09:15 --> Model "Log_model" initialized
INFO - 2026-01-21 13:09:15 --> Final output sent to browser
DEBUG - 2026-01-21 13:09:15 --> Total execution time: 0.2200
INFO - 2026-01-21 07:09:37 --> Config Class Initialized
INFO - 2026-01-21 07:09:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:09:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:09:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:09:37 --> URI Class Initialized
INFO - 2026-01-21 07:09:37 --> Router Class Initialized
INFO - 2026-01-21 07:09:37 --> Output Class Initialized
INFO - 2026-01-21 07:09:37 --> Security Class Initialized
DEBUG - 2026-01-21 07:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:09:37 --> CSRF cookie sent
INFO - 2026-01-21 07:09:37 --> Input Class Initialized
INFO - 2026-01-21 07:09:37 --> Language Class Initialized
INFO - 2026-01-21 07:09:37 --> Loader Class Initialized
INFO - 2026-01-21 07:09:37 --> Helper loaded: url_helper
INFO - 2026-01-21 07:09:37 --> Helper loaded: text_helper
INFO - 2026-01-21 07:09:37 --> Helper loaded: string_helper
INFO - 2026-01-21 07:09:37 --> Helper loaded: form_helper
INFO - 2026-01-21 07:09:37 --> Helper loaded: download_helper
INFO - 2026-01-21 07:09:37 --> Helper loaded: security_helper
INFO - 2026-01-21 07:09:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:09:37 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:09:37 --> Form Validation Class Initialized
INFO - 2026-01-21 07:09:37 --> Model "User_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:09:37 --> Controller Class Initialized
INFO - 2026-01-21 13:09:37 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Video_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:09:37 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:09:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-21 13:09:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:09:37 --> Model "Log_model" initialized
INFO - 2026-01-21 13:09:37 --> Final output sent to browser
DEBUG - 2026-01-21 13:09:37 --> Total execution time: 0.1750
INFO - 2026-01-21 07:09:58 --> Config Class Initialized
INFO - 2026-01-21 07:09:58 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:09:58 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:09:58 --> Utf8 Class Initialized
INFO - 2026-01-21 07:09:58 --> URI Class Initialized
INFO - 2026-01-21 07:09:58 --> Router Class Initialized
INFO - 2026-01-21 07:09:58 --> Output Class Initialized
INFO - 2026-01-21 07:09:58 --> Security Class Initialized
DEBUG - 2026-01-21 07:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:09:58 --> CSRF cookie sent
INFO - 2026-01-21 07:09:58 --> Input Class Initialized
INFO - 2026-01-21 07:09:58 --> Language Class Initialized
INFO - 2026-01-21 07:09:58 --> Loader Class Initialized
INFO - 2026-01-21 07:09:58 --> Helper loaded: url_helper
INFO - 2026-01-21 07:09:58 --> Helper loaded: text_helper
INFO - 2026-01-21 07:09:58 --> Helper loaded: string_helper
INFO - 2026-01-21 07:09:58 --> Helper loaded: form_helper
INFO - 2026-01-21 07:09:58 --> Helper loaded: download_helper
INFO - 2026-01-21 07:09:58 --> Helper loaded: security_helper
INFO - 2026-01-21 07:09:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:09:58 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:09:58 --> Form Validation Class Initialized
INFO - 2026-01-21 07:09:58 --> Model "User_model" initialized
INFO - 2026-01-21 13:09:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:09:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:09:58 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:09:58 --> Controller Class Initialized
INFO - 2026-01-21 13:09:58 --> Model "Sitemap_model" initialized
INFO - 2026-01-21 13:09:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_alumni.php
INFO - 2026-01-21 13:09:58 --> Model "Log_model" initialized
INFO - 2026-01-21 13:09:58 --> Final output sent to browser
DEBUG - 2026-01-21 13:09:58 --> Total execution time: 0.2636
INFO - 2026-01-21 07:10:42 --> Config Class Initialized
INFO - 2026-01-21 07:10:42 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:10:42 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:10:42 --> Utf8 Class Initialized
INFO - 2026-01-21 07:10:42 --> URI Class Initialized
INFO - 2026-01-21 07:10:42 --> Router Class Initialized
INFO - 2026-01-21 07:10:42 --> Output Class Initialized
INFO - 2026-01-21 07:10:42 --> Security Class Initialized
DEBUG - 2026-01-21 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:10:42 --> CSRF cookie sent
INFO - 2026-01-21 07:10:42 --> Input Class Initialized
INFO - 2026-01-21 07:10:42 --> Language Class Initialized
INFO - 2026-01-21 07:10:42 --> Loader Class Initialized
INFO - 2026-01-21 07:10:42 --> Helper loaded: url_helper
INFO - 2026-01-21 07:10:42 --> Helper loaded: text_helper
INFO - 2026-01-21 07:10:42 --> Helper loaded: string_helper
INFO - 2026-01-21 07:10:42 --> Helper loaded: form_helper
INFO - 2026-01-21 07:10:42 --> Helper loaded: download_helper
INFO - 2026-01-21 07:10:42 --> Helper loaded: security_helper
INFO - 2026-01-21 07:10:42 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:10:42 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:10:42 --> Form Validation Class Initialized
INFO - 2026-01-21 07:10:42 --> Model "User_model" initialized
INFO - 2026-01-21 13:10:42 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:10:42 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:10:42 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:10:42 --> Controller Class Initialized
INFO - 2026-01-21 13:10:42 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:10:43 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-21 13:10:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-21 13:10:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:10:43 --> Model "Log_model" initialized
INFO - 2026-01-21 13:10:43 --> Final output sent to browser
DEBUG - 2026-01-21 13:10:43 --> Total execution time: 0.5244
INFO - 2026-01-21 07:10:49 --> Config Class Initialized
INFO - 2026-01-21 07:10:49 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:10:49 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:10:49 --> Utf8 Class Initialized
INFO - 2026-01-21 07:10:49 --> URI Class Initialized
INFO - 2026-01-21 07:10:49 --> Router Class Initialized
INFO - 2026-01-21 07:10:49 --> Output Class Initialized
INFO - 2026-01-21 07:10:49 --> Security Class Initialized
DEBUG - 2026-01-21 07:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:10:49 --> CSRF cookie sent
INFO - 2026-01-21 07:10:49 --> Input Class Initialized
INFO - 2026-01-21 07:10:49 --> Language Class Initialized
INFO - 2026-01-21 07:10:49 --> Loader Class Initialized
INFO - 2026-01-21 07:10:49 --> Helper loaded: url_helper
INFO - 2026-01-21 07:10:49 --> Helper loaded: text_helper
INFO - 2026-01-21 07:10:49 --> Helper loaded: string_helper
INFO - 2026-01-21 07:10:49 --> Helper loaded: form_helper
INFO - 2026-01-21 07:10:49 --> Helper loaded: download_helper
INFO - 2026-01-21 07:10:49 --> Helper loaded: security_helper
INFO - 2026-01-21 07:10:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:10:49 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:10:49 --> Form Validation Class Initialized
INFO - 2026-01-21 07:10:49 --> Model "User_model" initialized
INFO - 2026-01-21 13:10:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:10:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:10:49 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:10:49 --> Controller Class Initialized
INFO - 2026-01-21 13:10:49 --> Model "Pages_model" initialized
INFO - 2026-01-21 13:10:49 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:10:49 --> Model "Download_model" initialized
INFO - 2026-01-21 13:10:49 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 13:10:49 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 13:10:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-21 13:10:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:10:49 --> Model "Log_model" initialized
INFO - 2026-01-21 13:10:49 --> Final output sent to browser
DEBUG - 2026-01-21 13:10:49 --> Total execution time: 0.4470
INFO - 2026-01-21 07:10:53 --> Config Class Initialized
INFO - 2026-01-21 07:10:53 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:10:53 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:10:53 --> Utf8 Class Initialized
INFO - 2026-01-21 07:10:53 --> URI Class Initialized
INFO - 2026-01-21 07:10:53 --> Router Class Initialized
INFO - 2026-01-21 07:10:53 --> Output Class Initialized
INFO - 2026-01-21 07:10:53 --> Security Class Initialized
DEBUG - 2026-01-21 07:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:10:53 --> CSRF cookie sent
INFO - 2026-01-21 07:10:53 --> Input Class Initialized
INFO - 2026-01-21 07:10:53 --> Language Class Initialized
INFO - 2026-01-21 07:10:53 --> Loader Class Initialized
INFO - 2026-01-21 07:10:53 --> Helper loaded: url_helper
INFO - 2026-01-21 07:10:53 --> Helper loaded: text_helper
INFO - 2026-01-21 07:10:53 --> Helper loaded: string_helper
INFO - 2026-01-21 07:10:53 --> Helper loaded: form_helper
INFO - 2026-01-21 07:10:53 --> Helper loaded: download_helper
INFO - 2026-01-21 07:10:53 --> Helper loaded: security_helper
INFO - 2026-01-21 07:10:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:10:53 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:10:53 --> Form Validation Class Initialized
INFO - 2026-01-21 07:10:53 --> Model "User_model" initialized
INFO - 2026-01-21 13:10:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:10:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:10:53 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:10:53 --> Controller Class Initialized
INFO - 2026-01-21 13:10:53 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:10:53 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:10:53 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:10:53 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 13:10:53 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2026-01-21 13:10:54 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 13:10:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 13:10:54 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-21 13:10:54 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-21 13:10:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-21 13:10:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:10:54 --> Model "Log_model" initialized
INFO - 2026-01-21 13:10:54 --> Final output sent to browser
DEBUG - 2026-01-21 13:10:54 --> Total execution time: 1.7431
INFO - 2026-01-21 07:15:45 --> Config Class Initialized
INFO - 2026-01-21 07:15:45 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:15:45 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:15:45 --> Utf8 Class Initialized
INFO - 2026-01-21 07:15:45 --> URI Class Initialized
INFO - 2026-01-21 07:15:45 --> Router Class Initialized
INFO - 2026-01-21 07:15:45 --> Output Class Initialized
INFO - 2026-01-21 07:15:45 --> Security Class Initialized
DEBUG - 2026-01-21 07:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:15:45 --> CSRF cookie sent
INFO - 2026-01-21 07:15:45 --> Input Class Initialized
INFO - 2026-01-21 07:15:45 --> Language Class Initialized
INFO - 2026-01-21 07:15:45 --> Loader Class Initialized
INFO - 2026-01-21 07:15:45 --> Helper loaded: url_helper
INFO - 2026-01-21 07:15:45 --> Helper loaded: text_helper
INFO - 2026-01-21 07:15:45 --> Helper loaded: string_helper
INFO - 2026-01-21 07:15:45 --> Helper loaded: form_helper
INFO - 2026-01-21 07:15:45 --> Helper loaded: download_helper
INFO - 2026-01-21 07:15:45 --> Helper loaded: security_helper
INFO - 2026-01-21 07:15:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:15:45 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:15:45 --> Form Validation Class Initialized
INFO - 2026-01-21 07:15:45 --> Model "User_model" initialized
INFO - 2026-01-21 13:15:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:15:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:15:45 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:15:45 --> Controller Class Initialized
INFO - 2026-01-21 13:15:45 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:15:45 --> Model "Staff_model" initialized
INFO - 2026-01-21 13:15:45 --> Model "Dasbor_model" initialized
INFO - 2026-01-21 13:15:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2026-01-21 13:15:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 13:15:46 --> Model "Log_model" initialized
INFO - 2026-01-21 13:15:46 --> Final output sent to browser
DEBUG - 2026-01-21 13:15:46 --> Total execution time: 1.3416
INFO - 2026-01-21 07:15:51 --> Config Class Initialized
INFO - 2026-01-21 07:15:51 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:15:51 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:15:51 --> Utf8 Class Initialized
INFO - 2026-01-21 07:15:51 --> URI Class Initialized
INFO - 2026-01-21 07:15:51 --> Router Class Initialized
INFO - 2026-01-21 07:15:51 --> Output Class Initialized
INFO - 2026-01-21 07:15:51 --> Security Class Initialized
DEBUG - 2026-01-21 07:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:15:51 --> CSRF cookie sent
INFO - 2026-01-21 07:15:51 --> Input Class Initialized
INFO - 2026-01-21 07:15:51 --> Language Class Initialized
INFO - 2026-01-21 07:15:51 --> Loader Class Initialized
INFO - 2026-01-21 07:15:51 --> Helper loaded: url_helper
INFO - 2026-01-21 07:15:51 --> Helper loaded: text_helper
INFO - 2026-01-21 07:15:51 --> Helper loaded: string_helper
INFO - 2026-01-21 07:15:51 --> Helper loaded: form_helper
INFO - 2026-01-21 07:15:51 --> Helper loaded: download_helper
INFO - 2026-01-21 07:15:51 --> Helper loaded: security_helper
INFO - 2026-01-21 07:15:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:15:51 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:15:51 --> Form Validation Class Initialized
INFO - 2026-01-21 07:15:51 --> Model "User_model" initialized
INFO - 2026-01-21 13:15:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:15:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:15:51 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:15:51 --> Controller Class Initialized
INFO - 2026-01-21 13:15:51 --> Model "Sitemap_model" initialized
INFO - 2026-01-21 13:15:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_alumni.php
INFO - 2026-01-21 13:15:51 --> Model "Log_model" initialized
INFO - 2026-01-21 13:15:51 --> Final output sent to browser
DEBUG - 2026-01-21 13:15:51 --> Total execution time: 0.1017
INFO - 2026-01-21 07:15:59 --> Config Class Initialized
INFO - 2026-01-21 07:15:59 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:15:59 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:15:59 --> Utf8 Class Initialized
INFO - 2026-01-21 07:15:59 --> URI Class Initialized
INFO - 2026-01-21 07:15:59 --> Router Class Initialized
INFO - 2026-01-21 07:15:59 --> Output Class Initialized
INFO - 2026-01-21 07:15:59 --> Security Class Initialized
DEBUG - 2026-01-21 07:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:15:59 --> CSRF cookie sent
INFO - 2026-01-21 07:15:59 --> Input Class Initialized
INFO - 2026-01-21 07:15:59 --> Language Class Initialized
INFO - 2026-01-21 07:15:59 --> Loader Class Initialized
INFO - 2026-01-21 07:15:59 --> Helper loaded: url_helper
INFO - 2026-01-21 07:15:59 --> Helper loaded: text_helper
INFO - 2026-01-21 07:15:59 --> Helper loaded: string_helper
INFO - 2026-01-21 07:15:59 --> Helper loaded: form_helper
INFO - 2026-01-21 07:15:59 --> Helper loaded: download_helper
INFO - 2026-01-21 07:15:59 --> Helper loaded: security_helper
INFO - 2026-01-21 07:15:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:15:59 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:15:59 --> Form Validation Class Initialized
INFO - 2026-01-21 07:15:59 --> Model "User_model" initialized
INFO - 2026-01-21 13:15:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:15:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:15:59 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:15:59 --> Controller Class Initialized
INFO - 2026-01-21 13:15:59 --> Model "Sitemap_model" initialized
INFO - 2026-01-21 13:15:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_berita.php
INFO - 2026-01-21 13:16:00 --> Model "Log_model" initialized
INFO - 2026-01-21 13:16:00 --> Final output sent to browser
DEBUG - 2026-01-21 13:16:00 --> Total execution time: 0.1083
INFO - 2026-01-21 07:16:08 --> Config Class Initialized
INFO - 2026-01-21 07:16:08 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:16:08 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:16:08 --> Utf8 Class Initialized
INFO - 2026-01-21 07:16:08 --> URI Class Initialized
INFO - 2026-01-21 07:16:08 --> Router Class Initialized
INFO - 2026-01-21 07:16:08 --> Output Class Initialized
INFO - 2026-01-21 07:16:08 --> Security Class Initialized
DEBUG - 2026-01-21 07:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:16:08 --> CSRF cookie sent
INFO - 2026-01-21 07:16:08 --> Input Class Initialized
INFO - 2026-01-21 07:16:08 --> Language Class Initialized
INFO - 2026-01-21 07:16:08 --> Loader Class Initialized
INFO - 2026-01-21 07:16:08 --> Helper loaded: url_helper
INFO - 2026-01-21 07:16:08 --> Helper loaded: text_helper
INFO - 2026-01-21 07:16:08 --> Helper loaded: string_helper
INFO - 2026-01-21 07:16:08 --> Helper loaded: form_helper
INFO - 2026-01-21 07:16:08 --> Helper loaded: download_helper
INFO - 2026-01-21 07:16:08 --> Helper loaded: security_helper
INFO - 2026-01-21 07:16:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:16:08 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:16:08 --> Form Validation Class Initialized
INFO - 2026-01-21 07:16:08 --> Model "User_model" initialized
INFO - 2026-01-21 13:16:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:16:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:16:08 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:16:08 --> Controller Class Initialized
INFO - 2026-01-21 13:16:08 --> Model "Sitemap_model" initialized
INFO - 2026-01-21 13:16:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_pendidikan.php
INFO - 2026-01-21 13:16:08 --> Model "Log_model" initialized
INFO - 2026-01-21 13:16:08 --> Final output sent to browser
DEBUG - 2026-01-21 13:16:08 --> Total execution time: 0.1089
INFO - 2026-01-21 07:16:14 --> Config Class Initialized
INFO - 2026-01-21 07:16:14 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:16:14 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:16:14 --> Utf8 Class Initialized
INFO - 2026-01-21 07:16:14 --> URI Class Initialized
INFO - 2026-01-21 07:16:14 --> Router Class Initialized
INFO - 2026-01-21 07:16:14 --> Output Class Initialized
INFO - 2026-01-21 07:16:14 --> Security Class Initialized
DEBUG - 2026-01-21 07:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:16:14 --> CSRF cookie sent
INFO - 2026-01-21 07:16:14 --> Input Class Initialized
INFO - 2026-01-21 07:16:14 --> Language Class Initialized
INFO - 2026-01-21 07:16:14 --> Loader Class Initialized
INFO - 2026-01-21 07:16:14 --> Helper loaded: url_helper
INFO - 2026-01-21 07:16:14 --> Helper loaded: text_helper
INFO - 2026-01-21 07:16:14 --> Helper loaded: string_helper
INFO - 2026-01-21 07:16:14 --> Helper loaded: form_helper
INFO - 2026-01-21 07:16:14 --> Helper loaded: download_helper
INFO - 2026-01-21 07:16:14 --> Helper loaded: security_helper
INFO - 2026-01-21 07:16:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:16:14 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:16:14 --> Form Validation Class Initialized
INFO - 2026-01-21 07:16:14 --> Model "User_model" initialized
INFO - 2026-01-21 13:16:14 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:16:14 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:16:14 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:16:14 --> Controller Class Initialized
INFO - 2026-01-21 13:16:14 --> Model "Sitemap_model" initialized
ERROR - 2026-01-21 13:16:14 --> Query error: Unknown column 'slug_prodi' in 'field list' - Invalid query: SELECT `slug_prodi`, `tanggal`
FROM `prodi`
WHERE `status_prodi` = 'Publish'
ORDER BY `tanggal` DESC
ERROR - 2026-01-21 13:16:14 --> Severity: error --> Exception: Call to a member function result_array() on bool D:\xampp\htdocs\dev_jkt3\application\models\Sitemap_model.php 49
INFO - 2026-01-21 07:19:21 --> Config Class Initialized
INFO - 2026-01-21 07:19:21 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:19:21 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:19:21 --> Utf8 Class Initialized
INFO - 2026-01-21 07:19:21 --> URI Class Initialized
INFO - 2026-01-21 07:19:21 --> Router Class Initialized
INFO - 2026-01-21 07:19:21 --> Output Class Initialized
INFO - 2026-01-21 07:19:21 --> Security Class Initialized
DEBUG - 2026-01-21 07:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:19:21 --> CSRF cookie sent
INFO - 2026-01-21 07:19:21 --> Input Class Initialized
INFO - 2026-01-21 07:19:21 --> Language Class Initialized
INFO - 2026-01-21 07:19:21 --> Loader Class Initialized
INFO - 2026-01-21 07:19:21 --> Helper loaded: url_helper
INFO - 2026-01-21 07:19:21 --> Helper loaded: text_helper
INFO - 2026-01-21 07:19:21 --> Helper loaded: string_helper
INFO - 2026-01-21 07:19:21 --> Helper loaded: form_helper
INFO - 2026-01-21 07:19:21 --> Helper loaded: download_helper
INFO - 2026-01-21 07:19:21 --> Helper loaded: security_helper
INFO - 2026-01-21 07:19:21 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:19:21 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:19:21 --> Form Validation Class Initialized
INFO - 2026-01-21 07:19:21 --> Model "User_model" initialized
INFO - 2026-01-21 13:19:21 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:19:21 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:19:21 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:19:21 --> Controller Class Initialized
INFO - 2026-01-21 13:19:21 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:19:21 --> Model "Staff_model" initialized
INFO - 2026-01-21 13:19:21 --> Model "Dasbor_model" initialized
INFO - 2026-01-21 13:19:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2026-01-21 13:19:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-21 13:19:22 --> Model "Log_model" initialized
INFO - 2026-01-21 13:19:22 --> Final output sent to browser
DEBUG - 2026-01-21 13:19:22 --> Total execution time: 0.5175
INFO - 2026-01-21 07:19:30 --> Config Class Initialized
INFO - 2026-01-21 07:19:30 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:19:30 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:19:30 --> Utf8 Class Initialized
INFO - 2026-01-21 07:19:30 --> URI Class Initialized
INFO - 2026-01-21 07:19:30 --> Router Class Initialized
INFO - 2026-01-21 07:19:30 --> Output Class Initialized
INFO - 2026-01-21 07:19:30 --> Security Class Initialized
DEBUG - 2026-01-21 07:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:19:30 --> CSRF cookie sent
INFO - 2026-01-21 07:19:30 --> Input Class Initialized
INFO - 2026-01-21 07:19:30 --> Language Class Initialized
INFO - 2026-01-21 07:19:30 --> Loader Class Initialized
INFO - 2026-01-21 07:19:30 --> Helper loaded: url_helper
INFO - 2026-01-21 07:19:30 --> Helper loaded: text_helper
INFO - 2026-01-21 07:19:30 --> Helper loaded: string_helper
INFO - 2026-01-21 07:19:30 --> Helper loaded: form_helper
INFO - 2026-01-21 07:19:30 --> Helper loaded: download_helper
INFO - 2026-01-21 07:19:30 --> Helper loaded: security_helper
INFO - 2026-01-21 07:19:30 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:19:30 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:19:30 --> Form Validation Class Initialized
INFO - 2026-01-21 07:19:30 --> Model "User_model" initialized
INFO - 2026-01-21 13:19:30 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:19:30 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:19:30 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:19:30 --> Controller Class Initialized
INFO - 2026-01-21 13:19:31 --> Model "Sitemap_model" initialized
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:19:31 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
INFO - 2026-01-21 13:19:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_prodi.php
INFO - 2026-01-21 13:19:31 --> Model "Log_model" initialized
INFO - 2026-01-21 13:19:31 --> Final output sent to browser
DEBUG - 2026-01-21 13:19:31 --> Total execution time: 0.1942
INFO - 2026-01-21 07:20:18 --> Config Class Initialized
INFO - 2026-01-21 07:20:18 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:20:18 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:20:18 --> Utf8 Class Initialized
INFO - 2026-01-21 07:20:18 --> URI Class Initialized
INFO - 2026-01-21 07:20:18 --> Router Class Initialized
INFO - 2026-01-21 07:20:18 --> Output Class Initialized
INFO - 2026-01-21 07:20:18 --> Security Class Initialized
DEBUG - 2026-01-21 07:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:20:18 --> CSRF cookie sent
INFO - 2026-01-21 07:20:18 --> Input Class Initialized
INFO - 2026-01-21 07:20:18 --> Language Class Initialized
INFO - 2026-01-21 07:20:18 --> Loader Class Initialized
INFO - 2026-01-21 07:20:18 --> Helper loaded: url_helper
INFO - 2026-01-21 07:20:18 --> Helper loaded: text_helper
INFO - 2026-01-21 07:20:18 --> Helper loaded: string_helper
INFO - 2026-01-21 07:20:18 --> Helper loaded: form_helper
INFO - 2026-01-21 07:20:18 --> Helper loaded: download_helper
INFO - 2026-01-21 07:20:18 --> Helper loaded: security_helper
INFO - 2026-01-21 07:20:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:20:18 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:20:18 --> Form Validation Class Initialized
INFO - 2026-01-21 07:20:18 --> Model "User_model" initialized
INFO - 2026-01-21 13:20:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:20:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:20:18 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:20:18 --> Controller Class Initialized
INFO - 2026-01-21 13:20:18 --> Model "Sitemap_model" initialized
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:18 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
INFO - 2026-01-21 13:20:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_prodi.php
INFO - 2026-01-21 13:20:18 --> Model "Log_model" initialized
INFO - 2026-01-21 13:20:18 --> Final output sent to browser
DEBUG - 2026-01-21 13:20:18 --> Total execution time: 0.2413
INFO - 2026-01-21 07:20:19 --> Config Class Initialized
INFO - 2026-01-21 07:20:19 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:20:19 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:20:19 --> Utf8 Class Initialized
INFO - 2026-01-21 07:20:19 --> URI Class Initialized
INFO - 2026-01-21 07:20:19 --> Router Class Initialized
INFO - 2026-01-21 07:20:19 --> Output Class Initialized
INFO - 2026-01-21 07:20:19 --> Security Class Initialized
DEBUG - 2026-01-21 07:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:20:19 --> CSRF cookie sent
INFO - 2026-01-21 07:20:19 --> Input Class Initialized
INFO - 2026-01-21 07:20:19 --> Language Class Initialized
INFO - 2026-01-21 07:20:19 --> Loader Class Initialized
INFO - 2026-01-21 07:20:19 --> Helper loaded: url_helper
INFO - 2026-01-21 07:20:19 --> Helper loaded: text_helper
INFO - 2026-01-21 07:20:19 --> Helper loaded: string_helper
INFO - 2026-01-21 07:20:19 --> Helper loaded: form_helper
INFO - 2026-01-21 07:20:19 --> Helper loaded: download_helper
INFO - 2026-01-21 07:20:19 --> Helper loaded: security_helper
INFO - 2026-01-21 07:20:19 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:20:19 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:20:19 --> Form Validation Class Initialized
INFO - 2026-01-21 07:20:19 --> Model "User_model" initialized
INFO - 2026-01-21 13:20:19 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:20:19 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:20:19 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:20:19 --> Controller Class Initialized
INFO - 2026-01-21 13:20:19 --> Model "Sitemap_model" initialized
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:19 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
ERROR - 2026-01-21 13:20:20 --> Severity: Notice --> Undefined index: slug_prodi D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 13
ERROR - 2026-01-21 13:20:20 --> Severity: Notice --> Undefined index: tanggal D:\xampp\htdocs\dev_jkt3\application\views\sitemap\sitemap_prodi.php 14
INFO - 2026-01-21 13:20:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_prodi.php
INFO - 2026-01-21 13:20:20 --> Model "Log_model" initialized
INFO - 2026-01-21 13:20:20 --> Final output sent to browser
DEBUG - 2026-01-21 13:20:20 --> Total execution time: 0.1146
INFO - 2026-01-21 07:22:12 --> Config Class Initialized
INFO - 2026-01-21 07:22:12 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:12 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:12 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:12 --> URI Class Initialized
INFO - 2026-01-21 07:22:12 --> Router Class Initialized
INFO - 2026-01-21 07:22:12 --> Output Class Initialized
INFO - 2026-01-21 07:22:12 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:12 --> CSRF cookie sent
INFO - 2026-01-21 07:22:12 --> Input Class Initialized
INFO - 2026-01-21 07:22:12 --> Language Class Initialized
INFO - 2026-01-21 07:22:12 --> Loader Class Initialized
INFO - 2026-01-21 07:22:12 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:12 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:12 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:12 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:12 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:12 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:12 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:12 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:12 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:12 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:12 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:12 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:12 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:12 --> Controller Class Initialized
INFO - 2026-01-21 13:22:12 --> Model "Sitemap_model" initialized
INFO - 2026-01-21 13:22:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_prodi.php
INFO - 2026-01-21 13:22:12 --> Model "Log_model" initialized
INFO - 2026-01-21 13:22:12 --> Final output sent to browser
DEBUG - 2026-01-21 13:22:12 --> Total execution time: 0.2128
INFO - 2026-01-21 07:22:32 --> Config Class Initialized
INFO - 2026-01-21 07:22:32 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:32 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:32 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:32 --> URI Class Initialized
INFO - 2026-01-21 07:22:32 --> Router Class Initialized
INFO - 2026-01-21 07:22:32 --> Output Class Initialized
INFO - 2026-01-21 07:22:32 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:32 --> CSRF cookie sent
INFO - 2026-01-21 07:22:32 --> Input Class Initialized
INFO - 2026-01-21 07:22:32 --> Language Class Initialized
INFO - 2026-01-21 07:22:32 --> Loader Class Initialized
INFO - 2026-01-21 07:22:32 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:32 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:32 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:32 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:32 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:32 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:32 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:32 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:33 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:33 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:33 --> Controller Class Initialized
INFO - 2026-01-21 13:22:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:33 --> Config Class Initialized
INFO - 2026-01-21 07:22:33 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:33 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:33 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:33 --> URI Class Initialized
INFO - 2026-01-21 07:22:33 --> Router Class Initialized
INFO - 2026-01-21 07:22:33 --> Output Class Initialized
INFO - 2026-01-21 07:22:33 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:33 --> CSRF cookie sent
INFO - 2026-01-21 07:22:33 --> Input Class Initialized
INFO - 2026-01-21 07:22:33 --> Language Class Initialized
INFO - 2026-01-21 07:22:33 --> Loader Class Initialized
INFO - 2026-01-21 07:22:33 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:33 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:33 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:33 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:33 --> Controller Class Initialized
INFO - 2026-01-21 13:22:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:33 --> Config Class Initialized
INFO - 2026-01-21 07:22:33 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:33 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:33 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:33 --> URI Class Initialized
INFO - 2026-01-21 07:22:33 --> Router Class Initialized
INFO - 2026-01-21 07:22:33 --> Output Class Initialized
INFO - 2026-01-21 07:22:33 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:33 --> CSRF cookie sent
INFO - 2026-01-21 07:22:33 --> Input Class Initialized
INFO - 2026-01-21 07:22:33 --> Language Class Initialized
INFO - 2026-01-21 07:22:33 --> Loader Class Initialized
INFO - 2026-01-21 07:22:33 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:33 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:33 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:33 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:33 --> Controller Class Initialized
INFO - 2026-01-21 13:22:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:33 --> Config Class Initialized
INFO - 2026-01-21 07:22:33 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:33 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:33 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:33 --> URI Class Initialized
INFO - 2026-01-21 07:22:33 --> Router Class Initialized
INFO - 2026-01-21 07:22:33 --> Output Class Initialized
INFO - 2026-01-21 07:22:33 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:33 --> CSRF cookie sent
INFO - 2026-01-21 07:22:33 --> Input Class Initialized
INFO - 2026-01-21 07:22:33 --> Language Class Initialized
INFO - 2026-01-21 07:22:33 --> Loader Class Initialized
INFO - 2026-01-21 07:22:33 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:33 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:33 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:33 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:33 --> Controller Class Initialized
INFO - 2026-01-21 13:22:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:33 --> Config Class Initialized
INFO - 2026-01-21 07:22:33 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:33 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:33 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:33 --> URI Class Initialized
INFO - 2026-01-21 07:22:33 --> Router Class Initialized
INFO - 2026-01-21 07:22:33 --> Output Class Initialized
INFO - 2026-01-21 07:22:33 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:33 --> CSRF cookie sent
INFO - 2026-01-21 07:22:33 --> Input Class Initialized
INFO - 2026-01-21 07:22:33 --> Language Class Initialized
INFO - 2026-01-21 07:22:33 --> Loader Class Initialized
INFO - 2026-01-21 07:22:33 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:33 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:33 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:33 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:33 --> Controller Class Initialized
INFO - 2026-01-21 13:22:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:33 --> Config Class Initialized
INFO - 2026-01-21 07:22:33 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:33 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:33 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:33 --> URI Class Initialized
INFO - 2026-01-21 07:22:33 --> Router Class Initialized
INFO - 2026-01-21 07:22:33 --> Output Class Initialized
INFO - 2026-01-21 07:22:33 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:33 --> CSRF cookie sent
INFO - 2026-01-21 07:22:33 --> Input Class Initialized
INFO - 2026-01-21 07:22:33 --> Language Class Initialized
INFO - 2026-01-21 07:22:33 --> Loader Class Initialized
INFO - 2026-01-21 07:22:33 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:33 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:33 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:33 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:33 --> Controller Class Initialized
INFO - 2026-01-21 13:22:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:33 --> Config Class Initialized
INFO - 2026-01-21 07:22:33 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:33 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:33 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:33 --> URI Class Initialized
INFO - 2026-01-21 07:22:33 --> Router Class Initialized
INFO - 2026-01-21 07:22:33 --> Output Class Initialized
INFO - 2026-01-21 07:22:33 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:33 --> CSRF cookie sent
INFO - 2026-01-21 07:22:33 --> Input Class Initialized
INFO - 2026-01-21 07:22:33 --> Language Class Initialized
INFO - 2026-01-21 07:22:33 --> Loader Class Initialized
INFO - 2026-01-21 07:22:33 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:33 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:33 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:33 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:33 --> Controller Class Initialized
INFO - 2026-01-21 13:22:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:33 --> Config Class Initialized
INFO - 2026-01-21 07:22:33 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:33 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:33 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:33 --> URI Class Initialized
INFO - 2026-01-21 07:22:33 --> Router Class Initialized
INFO - 2026-01-21 07:22:33 --> Output Class Initialized
INFO - 2026-01-21 07:22:33 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:33 --> CSRF cookie sent
INFO - 2026-01-21 07:22:33 --> Input Class Initialized
INFO - 2026-01-21 07:22:33 --> Language Class Initialized
INFO - 2026-01-21 07:22:33 --> Loader Class Initialized
INFO - 2026-01-21 07:22:33 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:34 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:34 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:34 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:34 --> Controller Class Initialized
INFO - 2026-01-21 13:22:34 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:34 --> Config Class Initialized
INFO - 2026-01-21 07:22:34 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:34 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:34 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:34 --> URI Class Initialized
INFO - 2026-01-21 07:22:34 --> Router Class Initialized
INFO - 2026-01-21 07:22:34 --> Output Class Initialized
INFO - 2026-01-21 07:22:34 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:34 --> CSRF cookie sent
INFO - 2026-01-21 07:22:34 --> Input Class Initialized
INFO - 2026-01-21 07:22:34 --> Language Class Initialized
INFO - 2026-01-21 07:22:34 --> Loader Class Initialized
INFO - 2026-01-21 07:22:34 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:34 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:34 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:34 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:34 --> Controller Class Initialized
INFO - 2026-01-21 13:22:34 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:34 --> Config Class Initialized
INFO - 2026-01-21 07:22:34 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:34 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:34 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:34 --> URI Class Initialized
INFO - 2026-01-21 07:22:34 --> Router Class Initialized
INFO - 2026-01-21 07:22:34 --> Output Class Initialized
INFO - 2026-01-21 07:22:34 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:34 --> CSRF cookie sent
INFO - 2026-01-21 07:22:34 --> Input Class Initialized
INFO - 2026-01-21 07:22:34 --> Language Class Initialized
INFO - 2026-01-21 07:22:34 --> Loader Class Initialized
INFO - 2026-01-21 07:22:34 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:34 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:34 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:34 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:34 --> Controller Class Initialized
INFO - 2026-01-21 13:22:34 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:34 --> Config Class Initialized
INFO - 2026-01-21 07:22:34 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:34 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:34 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:34 --> URI Class Initialized
INFO - 2026-01-21 07:22:34 --> Router Class Initialized
INFO - 2026-01-21 07:22:34 --> Output Class Initialized
INFO - 2026-01-21 07:22:34 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:34 --> CSRF cookie sent
INFO - 2026-01-21 07:22:34 --> Input Class Initialized
INFO - 2026-01-21 07:22:34 --> Language Class Initialized
INFO - 2026-01-21 07:22:34 --> Loader Class Initialized
INFO - 2026-01-21 07:22:34 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:34 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:34 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:34 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:34 --> Controller Class Initialized
INFO - 2026-01-21 13:22:34 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:34 --> Config Class Initialized
INFO - 2026-01-21 07:22:34 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:34 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:34 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:34 --> URI Class Initialized
INFO - 2026-01-21 07:22:34 --> Router Class Initialized
INFO - 2026-01-21 07:22:34 --> Output Class Initialized
INFO - 2026-01-21 07:22:34 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:34 --> CSRF cookie sent
INFO - 2026-01-21 07:22:34 --> Input Class Initialized
INFO - 2026-01-21 07:22:34 --> Language Class Initialized
INFO - 2026-01-21 07:22:34 --> Loader Class Initialized
INFO - 2026-01-21 07:22:34 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:34 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:34 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:34 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:34 --> Controller Class Initialized
INFO - 2026-01-21 13:22:34 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:34 --> Config Class Initialized
INFO - 2026-01-21 07:22:34 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:34 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:34 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:34 --> URI Class Initialized
INFO - 2026-01-21 07:22:34 --> Router Class Initialized
INFO - 2026-01-21 07:22:34 --> Output Class Initialized
INFO - 2026-01-21 07:22:34 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:34 --> CSRF cookie sent
INFO - 2026-01-21 07:22:34 --> Input Class Initialized
INFO - 2026-01-21 07:22:34 --> Language Class Initialized
INFO - 2026-01-21 07:22:34 --> Loader Class Initialized
INFO - 2026-01-21 07:22:34 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:34 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:34 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:34 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:34 --> Controller Class Initialized
INFO - 2026-01-21 13:22:34 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:34 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:35 --> Config Class Initialized
INFO - 2026-01-21 07:22:35 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:35 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:35 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:35 --> URI Class Initialized
INFO - 2026-01-21 07:22:35 --> Router Class Initialized
INFO - 2026-01-21 07:22:35 --> Output Class Initialized
INFO - 2026-01-21 07:22:35 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:35 --> CSRF cookie sent
INFO - 2026-01-21 07:22:35 --> Input Class Initialized
INFO - 2026-01-21 07:22:35 --> Language Class Initialized
INFO - 2026-01-21 07:22:35 --> Loader Class Initialized
INFO - 2026-01-21 07:22:35 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:35 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:35 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:35 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:35 --> Controller Class Initialized
INFO - 2026-01-21 13:22:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:35 --> Config Class Initialized
INFO - 2026-01-21 07:22:35 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:35 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:35 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:35 --> URI Class Initialized
INFO - 2026-01-21 07:22:35 --> Router Class Initialized
INFO - 2026-01-21 07:22:35 --> Output Class Initialized
INFO - 2026-01-21 07:22:35 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:35 --> CSRF cookie sent
INFO - 2026-01-21 07:22:35 --> Input Class Initialized
INFO - 2026-01-21 07:22:35 --> Language Class Initialized
INFO - 2026-01-21 07:22:35 --> Loader Class Initialized
INFO - 2026-01-21 07:22:35 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:35 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:35 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:35 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:35 --> Controller Class Initialized
INFO - 2026-01-21 13:22:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:35 --> Config Class Initialized
INFO - 2026-01-21 07:22:35 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:35 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:35 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:35 --> URI Class Initialized
INFO - 2026-01-21 07:22:35 --> Router Class Initialized
INFO - 2026-01-21 07:22:35 --> Output Class Initialized
INFO - 2026-01-21 07:22:35 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:35 --> CSRF cookie sent
INFO - 2026-01-21 07:22:35 --> Input Class Initialized
INFO - 2026-01-21 07:22:35 --> Language Class Initialized
INFO - 2026-01-21 07:22:35 --> Loader Class Initialized
INFO - 2026-01-21 07:22:35 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:35 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:35 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:35 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:35 --> Controller Class Initialized
INFO - 2026-01-21 13:22:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:35 --> Config Class Initialized
INFO - 2026-01-21 07:22:35 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:35 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:35 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:35 --> URI Class Initialized
INFO - 2026-01-21 07:22:35 --> Router Class Initialized
INFO - 2026-01-21 07:22:35 --> Output Class Initialized
INFO - 2026-01-21 07:22:35 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:35 --> CSRF cookie sent
INFO - 2026-01-21 07:22:35 --> Input Class Initialized
INFO - 2026-01-21 07:22:35 --> Language Class Initialized
INFO - 2026-01-21 07:22:35 --> Loader Class Initialized
INFO - 2026-01-21 07:22:35 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:35 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:35 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:35 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:35 --> Controller Class Initialized
INFO - 2026-01-21 13:22:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:35 --> Config Class Initialized
INFO - 2026-01-21 07:22:35 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:35 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:35 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:35 --> URI Class Initialized
INFO - 2026-01-21 07:22:35 --> Router Class Initialized
INFO - 2026-01-21 07:22:35 --> Output Class Initialized
INFO - 2026-01-21 07:22:35 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:35 --> CSRF cookie sent
INFO - 2026-01-21 07:22:35 --> Input Class Initialized
INFO - 2026-01-21 07:22:35 --> Language Class Initialized
INFO - 2026-01-21 07:22:35 --> Loader Class Initialized
INFO - 2026-01-21 07:22:35 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:35 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:35 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:35 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:35 --> Controller Class Initialized
INFO - 2026-01-21 13:22:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:35 --> Config Class Initialized
INFO - 2026-01-21 07:22:35 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:35 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:35 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:35 --> URI Class Initialized
INFO - 2026-01-21 07:22:35 --> Router Class Initialized
INFO - 2026-01-21 07:22:35 --> Output Class Initialized
INFO - 2026-01-21 07:22:35 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:35 --> CSRF cookie sent
INFO - 2026-01-21 07:22:35 --> Input Class Initialized
INFO - 2026-01-21 07:22:35 --> Language Class Initialized
INFO - 2026-01-21 07:22:35 --> Loader Class Initialized
INFO - 2026-01-21 07:22:35 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:35 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:35 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:35 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:35 --> Controller Class Initialized
INFO - 2026-01-21 13:22:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:35 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:35 --> Config Class Initialized
INFO - 2026-01-21 07:22:35 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:35 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:35 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:35 --> URI Class Initialized
INFO - 2026-01-21 07:22:35 --> Router Class Initialized
INFO - 2026-01-21 07:22:35 --> Output Class Initialized
INFO - 2026-01-21 07:22:35 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:35 --> CSRF cookie sent
INFO - 2026-01-21 07:22:35 --> Input Class Initialized
INFO - 2026-01-21 07:22:35 --> Language Class Initialized
INFO - 2026-01-21 07:22:35 --> Loader Class Initialized
INFO - 2026-01-21 07:22:35 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:35 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:36 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:36 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:36 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:36 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:36 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:36 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:36 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:36 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:36 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:36 --> Controller Class Initialized
INFO - 2026-01-21 13:22:36 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:36 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:36 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:36 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:37 --> Config Class Initialized
INFO - 2026-01-21 07:22:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:37 --> URI Class Initialized
INFO - 2026-01-21 07:22:37 --> Router Class Initialized
INFO - 2026-01-21 07:22:37 --> Output Class Initialized
INFO - 2026-01-21 07:22:37 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:37 --> CSRF cookie sent
INFO - 2026-01-21 07:22:37 --> Input Class Initialized
INFO - 2026-01-21 07:22:37 --> Language Class Initialized
INFO - 2026-01-21 07:22:37 --> Loader Class Initialized
INFO - 2026-01-21 07:22:37 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:37 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:37 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:37 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:37 --> Controller Class Initialized
INFO - 2026-01-21 13:22:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:37 --> Config Class Initialized
INFO - 2026-01-21 07:22:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:37 --> URI Class Initialized
INFO - 2026-01-21 07:22:37 --> Router Class Initialized
INFO - 2026-01-21 07:22:37 --> Output Class Initialized
INFO - 2026-01-21 07:22:37 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:37 --> CSRF cookie sent
INFO - 2026-01-21 07:22:37 --> Input Class Initialized
INFO - 2026-01-21 07:22:37 --> Language Class Initialized
INFO - 2026-01-21 07:22:37 --> Loader Class Initialized
INFO - 2026-01-21 07:22:37 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:37 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:37 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:37 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:37 --> Controller Class Initialized
INFO - 2026-01-21 13:22:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:37 --> Config Class Initialized
INFO - 2026-01-21 07:22:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:37 --> URI Class Initialized
INFO - 2026-01-21 07:22:37 --> Router Class Initialized
INFO - 2026-01-21 07:22:37 --> Output Class Initialized
INFO - 2026-01-21 07:22:37 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:37 --> CSRF cookie sent
INFO - 2026-01-21 07:22:37 --> Input Class Initialized
INFO - 2026-01-21 07:22:37 --> Language Class Initialized
INFO - 2026-01-21 07:22:37 --> Loader Class Initialized
INFO - 2026-01-21 07:22:37 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:37 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:37 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:37 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:37 --> Controller Class Initialized
INFO - 2026-01-21 13:22:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:37 --> Config Class Initialized
INFO - 2026-01-21 07:22:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:37 --> URI Class Initialized
INFO - 2026-01-21 07:22:37 --> Router Class Initialized
INFO - 2026-01-21 07:22:37 --> Output Class Initialized
INFO - 2026-01-21 07:22:37 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:37 --> CSRF cookie sent
INFO - 2026-01-21 07:22:37 --> Input Class Initialized
INFO - 2026-01-21 07:22:37 --> Language Class Initialized
INFO - 2026-01-21 07:22:37 --> Loader Class Initialized
INFO - 2026-01-21 07:22:37 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:37 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:37 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:37 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:37 --> Controller Class Initialized
INFO - 2026-01-21 13:22:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:37 --> Config Class Initialized
INFO - 2026-01-21 07:22:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:37 --> URI Class Initialized
INFO - 2026-01-21 07:22:37 --> Router Class Initialized
INFO - 2026-01-21 07:22:37 --> Output Class Initialized
INFO - 2026-01-21 07:22:37 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:37 --> CSRF cookie sent
INFO - 2026-01-21 07:22:37 --> Input Class Initialized
INFO - 2026-01-21 07:22:37 --> Language Class Initialized
INFO - 2026-01-21 07:22:37 --> Loader Class Initialized
INFO - 2026-01-21 07:22:37 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:37 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:37 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:37 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:37 --> Controller Class Initialized
INFO - 2026-01-21 13:22:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:37 --> Config Class Initialized
INFO - 2026-01-21 07:22:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:37 --> URI Class Initialized
INFO - 2026-01-21 07:22:37 --> Router Class Initialized
INFO - 2026-01-21 07:22:37 --> Output Class Initialized
INFO - 2026-01-21 07:22:37 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:37 --> CSRF cookie sent
INFO - 2026-01-21 07:22:37 --> Input Class Initialized
INFO - 2026-01-21 07:22:37 --> Language Class Initialized
INFO - 2026-01-21 07:22:37 --> Loader Class Initialized
INFO - 2026-01-21 07:22:37 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:37 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:37 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:37 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:37 --> Controller Class Initialized
INFO - 2026-01-21 13:22:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:37 --> Config Class Initialized
INFO - 2026-01-21 07:22:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:37 --> URI Class Initialized
INFO - 2026-01-21 07:22:37 --> Router Class Initialized
INFO - 2026-01-21 07:22:37 --> Output Class Initialized
INFO - 2026-01-21 07:22:37 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:37 --> CSRF cookie sent
INFO - 2026-01-21 07:22:37 --> Input Class Initialized
INFO - 2026-01-21 07:22:37 --> Language Class Initialized
INFO - 2026-01-21 07:22:37 --> Loader Class Initialized
INFO - 2026-01-21 07:22:37 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:37 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:37 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:37 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:37 --> Controller Class Initialized
INFO - 2026-01-21 13:22:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:37 --> Config Class Initialized
INFO - 2026-01-21 07:22:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:37 --> URI Class Initialized
INFO - 2026-01-21 07:22:37 --> Router Class Initialized
INFO - 2026-01-21 07:22:37 --> Output Class Initialized
INFO - 2026-01-21 07:22:37 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:37 --> CSRF cookie sent
INFO - 2026-01-21 07:22:37 --> Input Class Initialized
INFO - 2026-01-21 07:22:37 --> Language Class Initialized
INFO - 2026-01-21 07:22:37 --> Loader Class Initialized
INFO - 2026-01-21 07:22:37 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:37 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:37 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:37 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:37 --> Controller Class Initialized
INFO - 2026-01-21 13:22:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:37 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:37 --> Config Class Initialized
INFO - 2026-01-21 07:22:37 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:37 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:37 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:37 --> URI Class Initialized
INFO - 2026-01-21 07:22:38 --> Router Class Initialized
INFO - 2026-01-21 07:22:38 --> Output Class Initialized
INFO - 2026-01-21 07:22:38 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:38 --> CSRF cookie sent
INFO - 2026-01-21 07:22:38 --> Input Class Initialized
INFO - 2026-01-21 07:22:38 --> Language Class Initialized
INFO - 2026-01-21 07:22:38 --> Loader Class Initialized
INFO - 2026-01-21 07:22:38 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:38 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:38 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:38 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:38 --> Controller Class Initialized
INFO - 2026-01-21 13:22:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:38 --> Config Class Initialized
INFO - 2026-01-21 07:22:38 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:38 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:38 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:38 --> URI Class Initialized
INFO - 2026-01-21 07:22:38 --> Router Class Initialized
INFO - 2026-01-21 07:22:38 --> Output Class Initialized
INFO - 2026-01-21 07:22:38 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:38 --> CSRF cookie sent
INFO - 2026-01-21 07:22:38 --> Input Class Initialized
INFO - 2026-01-21 07:22:38 --> Language Class Initialized
INFO - 2026-01-21 07:22:38 --> Loader Class Initialized
INFO - 2026-01-21 07:22:38 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:38 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:38 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:38 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:38 --> Controller Class Initialized
INFO - 2026-01-21 13:22:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:38 --> Config Class Initialized
INFO - 2026-01-21 07:22:38 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:38 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:38 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:38 --> URI Class Initialized
INFO - 2026-01-21 07:22:38 --> Router Class Initialized
INFO - 2026-01-21 07:22:38 --> Output Class Initialized
INFO - 2026-01-21 07:22:38 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:38 --> CSRF cookie sent
INFO - 2026-01-21 07:22:38 --> Input Class Initialized
INFO - 2026-01-21 07:22:38 --> Language Class Initialized
INFO - 2026-01-21 07:22:38 --> Loader Class Initialized
INFO - 2026-01-21 07:22:38 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:38 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:38 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:38 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:38 --> Controller Class Initialized
INFO - 2026-01-21 13:22:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:38 --> Config Class Initialized
INFO - 2026-01-21 07:22:38 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:38 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:38 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:38 --> URI Class Initialized
INFO - 2026-01-21 07:22:38 --> Router Class Initialized
INFO - 2026-01-21 07:22:38 --> Output Class Initialized
INFO - 2026-01-21 07:22:38 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:38 --> CSRF cookie sent
INFO - 2026-01-21 07:22:38 --> Input Class Initialized
INFO - 2026-01-21 07:22:38 --> Language Class Initialized
INFO - 2026-01-21 07:22:38 --> Loader Class Initialized
INFO - 2026-01-21 07:22:38 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:38 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:38 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:38 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:38 --> Controller Class Initialized
INFO - 2026-01-21 13:22:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:38 --> Config Class Initialized
INFO - 2026-01-21 07:22:38 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:38 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:38 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:38 --> URI Class Initialized
INFO - 2026-01-21 07:22:38 --> Router Class Initialized
INFO - 2026-01-21 07:22:38 --> Output Class Initialized
INFO - 2026-01-21 07:22:38 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:38 --> CSRF cookie sent
INFO - 2026-01-21 07:22:38 --> Input Class Initialized
INFO - 2026-01-21 07:22:38 --> Language Class Initialized
INFO - 2026-01-21 07:22:38 --> Loader Class Initialized
INFO - 2026-01-21 07:22:38 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:38 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:38 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:38 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:38 --> Controller Class Initialized
INFO - 2026-01-21 13:22:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:38 --> Config Class Initialized
INFO - 2026-01-21 07:22:38 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:38 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:38 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:38 --> URI Class Initialized
INFO - 2026-01-21 07:22:38 --> Router Class Initialized
INFO - 2026-01-21 07:22:38 --> Output Class Initialized
INFO - 2026-01-21 07:22:38 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:38 --> CSRF cookie sent
INFO - 2026-01-21 07:22:38 --> Input Class Initialized
INFO - 2026-01-21 07:22:38 --> Language Class Initialized
INFO - 2026-01-21 07:22:38 --> Loader Class Initialized
INFO - 2026-01-21 07:22:38 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:38 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:38 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:38 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:38 --> Controller Class Initialized
INFO - 2026-01-21 13:22:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:38 --> Config Class Initialized
INFO - 2026-01-21 07:22:38 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:38 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:38 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:38 --> URI Class Initialized
INFO - 2026-01-21 07:22:38 --> Router Class Initialized
INFO - 2026-01-21 07:22:38 --> Output Class Initialized
INFO - 2026-01-21 07:22:38 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:38 --> CSRF cookie sent
INFO - 2026-01-21 07:22:38 --> Input Class Initialized
INFO - 2026-01-21 07:22:38 --> Language Class Initialized
INFO - 2026-01-21 07:22:38 --> Loader Class Initialized
INFO - 2026-01-21 07:22:38 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:38 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:38 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:38 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:38 --> Controller Class Initialized
INFO - 2026-01-21 13:22:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:38 --> Config Class Initialized
INFO - 2026-01-21 07:22:38 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:38 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:38 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:38 --> URI Class Initialized
INFO - 2026-01-21 07:22:38 --> Router Class Initialized
INFO - 2026-01-21 07:22:38 --> Output Class Initialized
INFO - 2026-01-21 07:22:38 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:38 --> CSRF cookie sent
INFO - 2026-01-21 07:22:38 --> Input Class Initialized
INFO - 2026-01-21 07:22:38 --> Language Class Initialized
INFO - 2026-01-21 07:22:38 --> Loader Class Initialized
INFO - 2026-01-21 07:22:38 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:38 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:38 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:38 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:38 --> Controller Class Initialized
INFO - 2026-01-21 13:22:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:38 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:39 --> Config Class Initialized
INFO - 2026-01-21 07:22:39 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:39 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:39 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:39 --> URI Class Initialized
INFO - 2026-01-21 07:22:39 --> Router Class Initialized
INFO - 2026-01-21 07:22:39 --> Output Class Initialized
INFO - 2026-01-21 07:22:39 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:39 --> CSRF cookie sent
INFO - 2026-01-21 07:22:39 --> Input Class Initialized
INFO - 2026-01-21 07:22:39 --> Language Class Initialized
INFO - 2026-01-21 07:22:39 --> Loader Class Initialized
INFO - 2026-01-21 07:22:39 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:39 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:39 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:39 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:39 --> Controller Class Initialized
INFO - 2026-01-21 13:22:39 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:39 --> Config Class Initialized
INFO - 2026-01-21 07:22:39 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:39 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:39 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:39 --> URI Class Initialized
INFO - 2026-01-21 07:22:39 --> Router Class Initialized
INFO - 2026-01-21 07:22:39 --> Output Class Initialized
INFO - 2026-01-21 07:22:39 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:39 --> CSRF cookie sent
INFO - 2026-01-21 07:22:39 --> Input Class Initialized
INFO - 2026-01-21 07:22:39 --> Language Class Initialized
INFO - 2026-01-21 07:22:39 --> Loader Class Initialized
INFO - 2026-01-21 07:22:39 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:39 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:39 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:39 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:39 --> Controller Class Initialized
INFO - 2026-01-21 13:22:39 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:39 --> Config Class Initialized
INFO - 2026-01-21 07:22:39 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:39 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:39 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:39 --> URI Class Initialized
INFO - 2026-01-21 07:22:39 --> Router Class Initialized
INFO - 2026-01-21 07:22:39 --> Output Class Initialized
INFO - 2026-01-21 07:22:39 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:39 --> CSRF cookie sent
INFO - 2026-01-21 07:22:39 --> Input Class Initialized
INFO - 2026-01-21 07:22:39 --> Language Class Initialized
INFO - 2026-01-21 07:22:39 --> Loader Class Initialized
INFO - 2026-01-21 07:22:39 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:39 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:39 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:39 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:39 --> Controller Class Initialized
INFO - 2026-01-21 13:22:39 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:39 --> Config Class Initialized
INFO - 2026-01-21 07:22:39 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:39 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:39 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:39 --> URI Class Initialized
INFO - 2026-01-21 07:22:39 --> Router Class Initialized
INFO - 2026-01-21 07:22:39 --> Output Class Initialized
INFO - 2026-01-21 07:22:39 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:39 --> CSRF cookie sent
INFO - 2026-01-21 07:22:39 --> Input Class Initialized
INFO - 2026-01-21 07:22:39 --> Language Class Initialized
INFO - 2026-01-21 07:22:39 --> Loader Class Initialized
INFO - 2026-01-21 07:22:39 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:39 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:39 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:39 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:39 --> Controller Class Initialized
INFO - 2026-01-21 13:22:39 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:39 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 07:22:42 --> Config Class Initialized
INFO - 2026-01-21 07:22:42 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:42 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:42 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:42 --> URI Class Initialized
INFO - 2026-01-21 07:22:42 --> Router Class Initialized
INFO - 2026-01-21 07:22:42 --> Output Class Initialized
INFO - 2026-01-21 07:22:42 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:42 --> CSRF cookie sent
INFO - 2026-01-21 07:22:42 --> Input Class Initialized
INFO - 2026-01-21 07:22:42 --> Language Class Initialized
INFO - 2026-01-21 07:22:42 --> Loader Class Initialized
INFO - 2026-01-21 07:22:42 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:42 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:42 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:42 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:42 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:42 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:42 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:42 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:43 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:43 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:43 --> Controller Class Initialized
INFO - 2026-01-21 13:22:43 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Video_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:43 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:22:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-21 13:22:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:22:43 --> Model "Log_model" initialized
INFO - 2026-01-21 13:22:43 --> Final output sent to browser
DEBUG - 2026-01-21 13:22:43 --> Total execution time: 0.1470
INFO - 2026-01-21 07:22:47 --> Config Class Initialized
INFO - 2026-01-21 07:22:47 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:22:47 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:22:47 --> Utf8 Class Initialized
INFO - 2026-01-21 07:22:47 --> URI Class Initialized
INFO - 2026-01-21 07:22:47 --> Router Class Initialized
INFO - 2026-01-21 07:22:47 --> Output Class Initialized
INFO - 2026-01-21 07:22:47 --> Security Class Initialized
DEBUG - 2026-01-21 07:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:22:47 --> CSRF cookie sent
INFO - 2026-01-21 07:22:47 --> Input Class Initialized
INFO - 2026-01-21 07:22:47 --> Language Class Initialized
INFO - 2026-01-21 07:22:47 --> Loader Class Initialized
INFO - 2026-01-21 07:22:47 --> Helper loaded: url_helper
INFO - 2026-01-21 07:22:47 --> Helper loaded: text_helper
INFO - 2026-01-21 07:22:47 --> Helper loaded: string_helper
INFO - 2026-01-21 07:22:47 --> Helper loaded: form_helper
INFO - 2026-01-21 07:22:47 --> Helper loaded: download_helper
INFO - 2026-01-21 07:22:47 --> Helper loaded: security_helper
INFO - 2026-01-21 07:22:47 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:22:47 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:22:48 --> Form Validation Class Initialized
INFO - 2026-01-21 07:22:48 --> Model "User_model" initialized
INFO - 2026-01-21 13:22:48 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:22:48 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:22:48 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:22:48 --> Controller Class Initialized
INFO - 2026-01-21 13:22:48 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:22:48 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:22:48 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:22:48 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 13:22:48 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2026-01-21 13:22:48 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 13:22:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 13:22:48 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-21 13:22:48 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-21 13:22:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-21 13:22:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:22:48 --> Model "Log_model" initialized
INFO - 2026-01-21 13:22:48 --> Final output sent to browser
DEBUG - 2026-01-21 13:22:48 --> Total execution time: 0.2575
INFO - 2026-01-21 07:23:16 --> Config Class Initialized
INFO - 2026-01-21 07:23:16 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:23:16 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:23:16 --> Utf8 Class Initialized
INFO - 2026-01-21 07:23:16 --> URI Class Initialized
INFO - 2026-01-21 07:23:16 --> Router Class Initialized
INFO - 2026-01-21 07:23:16 --> Output Class Initialized
INFO - 2026-01-21 07:23:16 --> Security Class Initialized
DEBUG - 2026-01-21 07:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:23:16 --> CSRF cookie sent
INFO - 2026-01-21 07:23:16 --> Input Class Initialized
INFO - 2026-01-21 07:23:16 --> Language Class Initialized
INFO - 2026-01-21 07:23:16 --> Loader Class Initialized
INFO - 2026-01-21 07:23:16 --> Helper loaded: url_helper
INFO - 2026-01-21 07:23:16 --> Helper loaded: text_helper
INFO - 2026-01-21 07:23:16 --> Helper loaded: string_helper
INFO - 2026-01-21 07:23:16 --> Helper loaded: form_helper
INFO - 2026-01-21 07:23:16 --> Helper loaded: download_helper
INFO - 2026-01-21 07:23:16 --> Helper loaded: security_helper
INFO - 2026-01-21 07:23:16 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:23:16 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:23:16 --> Form Validation Class Initialized
INFO - 2026-01-21 07:23:16 --> Model "User_model" initialized
INFO - 2026-01-21 13:23:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:23:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:23:16 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:23:16 --> Controller Class Initialized
INFO - 2026-01-21 13:23:16 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:23:16 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:23:16 --> Model "Sdm_model" initialized
INFO - 2026-01-21 13:23:16 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-21 13:23:16 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2026-01-21 13:23:16 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 13:23:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-21 13:23:16 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-21 13:23:16 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-21 13:23:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-21 13:23:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:23:16 --> Model "Log_model" initialized
INFO - 2026-01-21 13:23:16 --> Final output sent to browser
DEBUG - 2026-01-21 13:23:16 --> Total execution time: 0.1714
INFO - 2026-01-21 07:24:06 --> Config Class Initialized
INFO - 2026-01-21 07:24:06 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:24:06 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:24:06 --> Utf8 Class Initialized
INFO - 2026-01-21 07:24:06 --> URI Class Initialized
DEBUG - 2026-01-21 07:24:06 --> No URI present. Default controller set.
INFO - 2026-01-21 07:24:06 --> Router Class Initialized
INFO - 2026-01-21 07:24:06 --> Output Class Initialized
INFO - 2026-01-21 07:24:06 --> Security Class Initialized
DEBUG - 2026-01-21 07:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:24:06 --> CSRF cookie sent
INFO - 2026-01-21 07:24:06 --> Input Class Initialized
INFO - 2026-01-21 07:24:06 --> Language Class Initialized
INFO - 2026-01-21 07:24:06 --> Loader Class Initialized
INFO - 2026-01-21 07:24:06 --> Helper loaded: url_helper
INFO - 2026-01-21 07:24:06 --> Helper loaded: text_helper
INFO - 2026-01-21 07:24:06 --> Helper loaded: string_helper
INFO - 2026-01-21 07:24:06 --> Helper loaded: form_helper
INFO - 2026-01-21 07:24:06 --> Helper loaded: download_helper
INFO - 2026-01-21 07:24:06 --> Helper loaded: security_helper
INFO - 2026-01-21 07:24:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:24:06 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:24:06 --> Form Validation Class Initialized
INFO - 2026-01-21 07:24:06 --> Model "User_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:24:06 --> Controller Class Initialized
INFO - 2026-01-21 13:24:06 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Video_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:24:06 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:24:06 --> Pagination Class Initialized
INFO - 2026-01-21 13:24:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:24:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:24:06 --> Model "Log_model" initialized
INFO - 2026-01-21 13:24:06 --> Final output sent to browser
DEBUG - 2026-01-21 13:24:06 --> Total execution time: 0.2100
INFO - 2026-01-21 07:24:19 --> Config Class Initialized
INFO - 2026-01-21 07:24:19 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:24:19 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:24:19 --> Utf8 Class Initialized
INFO - 2026-01-21 07:24:19 --> URI Class Initialized
DEBUG - 2026-01-21 07:24:19 --> No URI present. Default controller set.
INFO - 2026-01-21 07:24:19 --> Router Class Initialized
INFO - 2026-01-21 07:24:19 --> Output Class Initialized
INFO - 2026-01-21 07:24:19 --> Security Class Initialized
DEBUG - 2026-01-21 07:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:24:19 --> CSRF cookie sent
INFO - 2026-01-21 07:24:19 --> Input Class Initialized
INFO - 2026-01-21 07:24:19 --> Language Class Initialized
INFO - 2026-01-21 07:24:19 --> Loader Class Initialized
INFO - 2026-01-21 07:24:19 --> Helper loaded: url_helper
INFO - 2026-01-21 07:24:19 --> Helper loaded: text_helper
INFO - 2026-01-21 07:24:19 --> Helper loaded: string_helper
INFO - 2026-01-21 07:24:19 --> Helper loaded: form_helper
INFO - 2026-01-21 07:24:19 --> Helper loaded: download_helper
INFO - 2026-01-21 07:24:19 --> Helper loaded: security_helper
INFO - 2026-01-21 07:24:19 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:24:19 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:24:19 --> Form Validation Class Initialized
INFO - 2026-01-21 07:24:19 --> Model "User_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:24:19 --> Controller Class Initialized
INFO - 2026-01-21 13:24:19 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Video_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:24:19 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:24:19 --> Pagination Class Initialized
INFO - 2026-01-21 13:24:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:24:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:24:19 --> Model "Log_model" initialized
INFO - 2026-01-21 13:24:19 --> Final output sent to browser
DEBUG - 2026-01-21 13:24:19 --> Total execution time: 0.2642
INFO - 2026-01-21 07:24:53 --> Config Class Initialized
INFO - 2026-01-21 07:24:53 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:24:53 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:24:53 --> Utf8 Class Initialized
INFO - 2026-01-21 07:24:53 --> URI Class Initialized
INFO - 2026-01-21 07:24:53 --> Router Class Initialized
INFO - 2026-01-21 07:24:53 --> Output Class Initialized
INFO - 2026-01-21 07:24:53 --> Security Class Initialized
DEBUG - 2026-01-21 07:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:24:53 --> CSRF cookie sent
INFO - 2026-01-21 07:24:53 --> Input Class Initialized
INFO - 2026-01-21 07:24:53 --> Language Class Initialized
INFO - 2026-01-21 07:24:53 --> Loader Class Initialized
INFO - 2026-01-21 07:24:53 --> Helper loaded: url_helper
INFO - 2026-01-21 07:24:53 --> Helper loaded: text_helper
INFO - 2026-01-21 07:24:53 --> Helper loaded: string_helper
INFO - 2026-01-21 07:24:53 --> Helper loaded: form_helper
INFO - 2026-01-21 07:24:53 --> Helper loaded: download_helper
INFO - 2026-01-21 07:24:53 --> Helper loaded: security_helper
INFO - 2026-01-21 07:24:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:24:53 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:24:53 --> Form Validation Class Initialized
INFO - 2026-01-21 07:24:53 --> Model "User_model" initialized
INFO - 2026-01-21 13:24:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:24:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:24:53 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:24:53 --> Controller Class Initialized
INFO - 2026-01-21 13:24:53 --> Model "Download_model" initialized
INFO - 2026-01-21 13:24:53 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 13:24:53 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 13:24:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-21 13:24:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:24:53 --> Model "Log_model" initialized
INFO - 2026-01-21 13:24:53 --> Final output sent to browser
DEBUG - 2026-01-21 13:24:53 --> Total execution time: 0.3687
INFO - 2026-01-21 07:24:59 --> Config Class Initialized
INFO - 2026-01-21 07:24:59 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:24:59 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:24:59 --> Utf8 Class Initialized
INFO - 2026-01-21 07:24:59 --> URI Class Initialized
INFO - 2026-01-21 07:24:59 --> Router Class Initialized
INFO - 2026-01-21 07:24:59 --> Output Class Initialized
INFO - 2026-01-21 07:24:59 --> Security Class Initialized
DEBUG - 2026-01-21 07:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:24:59 --> CSRF cookie sent
INFO - 2026-01-21 07:24:59 --> Input Class Initialized
INFO - 2026-01-21 07:24:59 --> Language Class Initialized
INFO - 2026-01-21 07:24:59 --> Loader Class Initialized
INFO - 2026-01-21 07:24:59 --> Helper loaded: url_helper
INFO - 2026-01-21 07:24:59 --> Helper loaded: text_helper
INFO - 2026-01-21 07:24:59 --> Helper loaded: string_helper
INFO - 2026-01-21 07:24:59 --> Helper loaded: form_helper
INFO - 2026-01-21 07:24:59 --> Helper loaded: download_helper
INFO - 2026-01-21 07:24:59 --> Helper loaded: security_helper
INFO - 2026-01-21 07:24:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:24:59 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:24:59 --> Form Validation Class Initialized
INFO - 2026-01-21 07:24:59 --> Model "User_model" initialized
INFO - 2026-01-21 13:24:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:24:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:24:59 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:24:59 --> Controller Class Initialized
INFO - 2026-01-21 13:24:59 --> Model "Pages_model" initialized
INFO - 2026-01-21 13:24:59 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:24:59 --> Model "Download_model" initialized
INFO - 2026-01-21 13:24:59 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 13:24:59 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 13:24:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-21 13:24:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:24:59 --> Model "Log_model" initialized
INFO - 2026-01-21 13:24:59 --> Final output sent to browser
DEBUG - 2026-01-21 13:24:59 --> Total execution time: 0.1434
INFO - 2026-01-21 07:25:05 --> Config Class Initialized
INFO - 2026-01-21 07:25:05 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:25:05 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:25:05 --> Utf8 Class Initialized
INFO - 2026-01-21 07:25:05 --> URI Class Initialized
DEBUG - 2026-01-21 07:25:05 --> No URI present. Default controller set.
INFO - 2026-01-21 07:25:05 --> Router Class Initialized
INFO - 2026-01-21 07:25:05 --> Output Class Initialized
INFO - 2026-01-21 07:25:05 --> Security Class Initialized
DEBUG - 2026-01-21 07:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:25:05 --> CSRF cookie sent
INFO - 2026-01-21 07:25:05 --> Input Class Initialized
INFO - 2026-01-21 07:25:05 --> Language Class Initialized
INFO - 2026-01-21 07:25:05 --> Loader Class Initialized
INFO - 2026-01-21 07:25:05 --> Helper loaded: url_helper
INFO - 2026-01-21 07:25:05 --> Helper loaded: text_helper
INFO - 2026-01-21 07:25:05 --> Helper loaded: string_helper
INFO - 2026-01-21 07:25:05 --> Helper loaded: form_helper
INFO - 2026-01-21 07:25:05 --> Helper loaded: download_helper
INFO - 2026-01-21 07:25:05 --> Helper loaded: security_helper
INFO - 2026-01-21 07:25:05 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:25:05 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:25:05 --> Form Validation Class Initialized
INFO - 2026-01-21 07:25:05 --> Model "User_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:25:05 --> Controller Class Initialized
INFO - 2026-01-21 13:25:05 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Video_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:25:05 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:25:05 --> Pagination Class Initialized
INFO - 2026-01-21 13:25:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:25:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:25:05 --> Model "Log_model" initialized
INFO - 2026-01-21 13:25:05 --> Final output sent to browser
DEBUG - 2026-01-21 13:25:05 --> Total execution time: 0.2460
INFO - 2026-01-21 07:26:26 --> Config Class Initialized
INFO - 2026-01-21 07:26:26 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:26:26 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:26:26 --> Utf8 Class Initialized
INFO - 2026-01-21 07:26:26 --> URI Class Initialized
INFO - 2026-01-21 07:26:26 --> Router Class Initialized
INFO - 2026-01-21 07:26:26 --> Output Class Initialized
INFO - 2026-01-21 07:26:26 --> Security Class Initialized
DEBUG - 2026-01-21 07:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:26:26 --> CSRF cookie sent
INFO - 2026-01-21 07:26:26 --> Input Class Initialized
INFO - 2026-01-21 07:26:26 --> Language Class Initialized
INFO - 2026-01-21 07:26:26 --> Loader Class Initialized
INFO - 2026-01-21 07:26:26 --> Helper loaded: url_helper
INFO - 2026-01-21 07:26:26 --> Helper loaded: text_helper
INFO - 2026-01-21 07:26:26 --> Helper loaded: string_helper
INFO - 2026-01-21 07:26:26 --> Helper loaded: form_helper
INFO - 2026-01-21 07:26:26 --> Helper loaded: download_helper
INFO - 2026-01-21 07:26:26 --> Helper loaded: security_helper
INFO - 2026-01-21 07:26:26 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:26:26 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:26:26 --> Form Validation Class Initialized
INFO - 2026-01-21 07:26:26 --> Model "User_model" initialized
INFO - 2026-01-21 13:26:26 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:26:26 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:26:26 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:26:26 --> Controller Class Initialized
INFO - 2026-01-21 13:26:26 --> Model "Helpdesk_model" initialized
INFO - 2026-01-21 13:26:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list.php
INFO - 2026-01-21 13:26:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:26:26 --> Model "Log_model" initialized
INFO - 2026-01-21 13:26:26 --> Final output sent to browser
DEBUG - 2026-01-21 13:26:26 --> Total execution time: 0.3233
INFO - 2026-01-21 07:26:29 --> Config Class Initialized
INFO - 2026-01-21 07:26:29 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:26:29 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:26:29 --> Utf8 Class Initialized
INFO - 2026-01-21 07:26:29 --> URI Class Initialized
INFO - 2026-01-21 07:26:29 --> Router Class Initialized
INFO - 2026-01-21 07:26:29 --> Output Class Initialized
INFO - 2026-01-21 07:26:29 --> Security Class Initialized
DEBUG - 2026-01-21 07:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:26:29 --> CSRF cookie sent
INFO - 2026-01-21 07:26:29 --> Input Class Initialized
INFO - 2026-01-21 07:26:29 --> Language Class Initialized
INFO - 2026-01-21 07:26:29 --> Loader Class Initialized
INFO - 2026-01-21 07:26:29 --> Helper loaded: url_helper
INFO - 2026-01-21 07:26:29 --> Helper loaded: text_helper
INFO - 2026-01-21 07:26:29 --> Helper loaded: string_helper
INFO - 2026-01-21 07:26:29 --> Helper loaded: form_helper
INFO - 2026-01-21 07:26:29 --> Helper loaded: download_helper
INFO - 2026-01-21 07:26:29 --> Helper loaded: security_helper
INFO - 2026-01-21 07:26:29 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:26:29 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:26:29 --> Form Validation Class Initialized
INFO - 2026-01-21 07:26:29 --> Model "User_model" initialized
INFO - 2026-01-21 13:26:29 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:26:29 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:26:29 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:26:29 --> Controller Class Initialized
INFO - 2026-01-21 13:26:29 --> Model "Helpdesk_model" initialized
INFO - 2026-01-21 13:26:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list_adak.php
INFO - 2026-01-21 13:26:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:26:29 --> Model "Log_model" initialized
INFO - 2026-01-21 13:26:30 --> Final output sent to browser
DEBUG - 2026-01-21 13:26:30 --> Total execution time: 0.1645
INFO - 2026-01-21 07:26:51 --> Config Class Initialized
INFO - 2026-01-21 07:26:51 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:26:51 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:26:51 --> Utf8 Class Initialized
INFO - 2026-01-21 07:26:51 --> URI Class Initialized
INFO - 2026-01-21 07:26:51 --> Router Class Initialized
INFO - 2026-01-21 07:26:51 --> Output Class Initialized
INFO - 2026-01-21 07:26:51 --> Security Class Initialized
DEBUG - 2026-01-21 07:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:26:51 --> CSRF cookie sent
INFO - 2026-01-21 07:26:51 --> Input Class Initialized
INFO - 2026-01-21 07:26:51 --> Language Class Initialized
INFO - 2026-01-21 07:26:51 --> Loader Class Initialized
INFO - 2026-01-21 07:26:51 --> Helper loaded: url_helper
INFO - 2026-01-21 07:26:51 --> Helper loaded: text_helper
INFO - 2026-01-21 07:26:51 --> Helper loaded: string_helper
INFO - 2026-01-21 07:26:51 --> Helper loaded: form_helper
INFO - 2026-01-21 07:26:51 --> Helper loaded: download_helper
INFO - 2026-01-21 07:26:51 --> Helper loaded: security_helper
INFO - 2026-01-21 07:26:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:26:51 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:26:51 --> Form Validation Class Initialized
INFO - 2026-01-21 07:26:51 --> Model "User_model" initialized
INFO - 2026-01-21 13:26:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:26:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:26:51 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:26:51 --> Controller Class Initialized
INFO - 2026-01-21 13:26:51 --> Model "Download_model" initialized
INFO - 2026-01-21 13:26:51 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 13:26:51 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 13:26:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_prestasi.php
INFO - 2026-01-21 13:26:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:26:51 --> Model "Log_model" initialized
INFO - 2026-01-21 13:26:51 --> Final output sent to browser
DEBUG - 2026-01-21 13:26:51 --> Total execution time: 0.1352
INFO - 2026-01-21 07:26:55 --> Config Class Initialized
INFO - 2026-01-21 07:26:55 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:26:55 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:26:55 --> Utf8 Class Initialized
INFO - 2026-01-21 07:26:55 --> URI Class Initialized
INFO - 2026-01-21 07:26:55 --> Router Class Initialized
INFO - 2026-01-21 07:26:55 --> Output Class Initialized
INFO - 2026-01-21 07:26:55 --> Security Class Initialized
DEBUG - 2026-01-21 07:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:26:55 --> CSRF cookie sent
INFO - 2026-01-21 07:26:55 --> Input Class Initialized
INFO - 2026-01-21 07:26:55 --> Language Class Initialized
INFO - 2026-01-21 07:26:55 --> Loader Class Initialized
INFO - 2026-01-21 07:26:55 --> Helper loaded: url_helper
INFO - 2026-01-21 07:26:55 --> Helper loaded: text_helper
INFO - 2026-01-21 07:26:55 --> Helper loaded: string_helper
INFO - 2026-01-21 07:26:55 --> Helper loaded: form_helper
INFO - 2026-01-21 07:26:55 --> Helper loaded: download_helper
INFO - 2026-01-21 07:26:55 --> Helper loaded: security_helper
INFO - 2026-01-21 07:26:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:26:55 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:26:55 --> Form Validation Class Initialized
INFO - 2026-01-21 07:26:55 --> Model "User_model" initialized
INFO - 2026-01-21 13:26:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:26:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:26:55 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:26:55 --> Controller Class Initialized
INFO - 2026-01-21 13:26:55 --> Model "Download_model" initialized
INFO - 2026-01-21 13:26:55 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 13:26:55 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 13:26:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_standardpelayanan.php
INFO - 2026-01-21 13:26:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:26:55 --> Model "Log_model" initialized
INFO - 2026-01-21 13:26:55 --> Final output sent to browser
DEBUG - 2026-01-21 13:26:55 --> Total execution time: 0.3241
INFO - 2026-01-21 07:27:58 --> Config Class Initialized
INFO - 2026-01-21 07:27:58 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:27:58 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:27:58 --> Utf8 Class Initialized
INFO - 2026-01-21 07:27:58 --> URI Class Initialized
INFO - 2026-01-21 07:27:58 --> Router Class Initialized
INFO - 2026-01-21 07:27:58 --> Output Class Initialized
INFO - 2026-01-21 07:27:58 --> Security Class Initialized
DEBUG - 2026-01-21 07:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:27:58 --> CSRF cookie sent
INFO - 2026-01-21 07:27:58 --> Input Class Initialized
INFO - 2026-01-21 07:27:58 --> Language Class Initialized
INFO - 2026-01-21 07:27:58 --> Loader Class Initialized
INFO - 2026-01-21 07:27:58 --> Helper loaded: url_helper
INFO - 2026-01-21 07:27:58 --> Helper loaded: text_helper
INFO - 2026-01-21 07:27:58 --> Helper loaded: string_helper
INFO - 2026-01-21 07:27:58 --> Helper loaded: form_helper
INFO - 2026-01-21 07:27:58 --> Helper loaded: download_helper
INFO - 2026-01-21 07:27:58 --> Helper loaded: security_helper
INFO - 2026-01-21 07:27:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:27:58 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:27:58 --> Form Validation Class Initialized
INFO - 2026-01-21 07:27:58 --> Model "User_model" initialized
INFO - 2026-01-21 13:27:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:27:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:27:58 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:27:58 --> Controller Class Initialized
INFO - 2026-01-21 13:27:58 --> Model "Download_model" initialized
INFO - 2026-01-21 13:27:58 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 13:27:58 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 13:27:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_standardpelayanan.php
INFO - 2026-01-21 13:27:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:27:58 --> Model "Log_model" initialized
INFO - 2026-01-21 13:27:58 --> Final output sent to browser
DEBUG - 2026-01-21 13:27:58 --> Total execution time: 0.2967
INFO - 2026-01-21 07:28:02 --> Config Class Initialized
INFO - 2026-01-21 07:28:02 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:28:02 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:28:02 --> Utf8 Class Initialized
INFO - 2026-01-21 07:28:02 --> URI Class Initialized
INFO - 2026-01-21 07:28:02 --> Router Class Initialized
INFO - 2026-01-21 07:28:02 --> Output Class Initialized
INFO - 2026-01-21 07:28:02 --> Security Class Initialized
DEBUG - 2026-01-21 07:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:28:02 --> CSRF cookie sent
INFO - 2026-01-21 07:28:02 --> Input Class Initialized
INFO - 2026-01-21 07:28:02 --> Language Class Initialized
INFO - 2026-01-21 07:28:02 --> Loader Class Initialized
INFO - 2026-01-21 07:28:02 --> Helper loaded: url_helper
INFO - 2026-01-21 07:28:02 --> Helper loaded: text_helper
INFO - 2026-01-21 07:28:02 --> Helper loaded: string_helper
INFO - 2026-01-21 07:28:02 --> Helper loaded: form_helper
INFO - 2026-01-21 07:28:02 --> Helper loaded: download_helper
INFO - 2026-01-21 07:28:02 --> Helper loaded: security_helper
INFO - 2026-01-21 07:28:02 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:28:02 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:28:02 --> Form Validation Class Initialized
INFO - 2026-01-21 07:28:02 --> Model "User_model" initialized
INFO - 2026-01-21 13:28:02 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:28:02 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:28:02 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:28:02 --> Controller Class Initialized
INFO - 2026-01-21 13:28:02 --> Model "Download_model" initialized
INFO - 2026-01-21 13:28:02 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 13:28:02 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 13:28:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_standardpelayanan.php
INFO - 2026-01-21 13:28:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:28:02 --> Model "Log_model" initialized
INFO - 2026-01-21 13:28:02 --> Final output sent to browser
DEBUG - 2026-01-21 13:28:02 --> Total execution time: 0.1936
INFO - 2026-01-21 07:28:27 --> Config Class Initialized
INFO - 2026-01-21 07:28:27 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:28:27 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:28:27 --> Utf8 Class Initialized
INFO - 2026-01-21 07:28:27 --> URI Class Initialized
INFO - 2026-01-21 07:28:27 --> Router Class Initialized
INFO - 2026-01-21 07:28:27 --> Output Class Initialized
INFO - 2026-01-21 07:28:27 --> Security Class Initialized
DEBUG - 2026-01-21 07:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:28:27 --> CSRF cookie sent
INFO - 2026-01-21 07:28:27 --> Input Class Initialized
INFO - 2026-01-21 07:28:27 --> Language Class Initialized
INFO - 2026-01-21 07:28:27 --> Loader Class Initialized
INFO - 2026-01-21 07:28:27 --> Helper loaded: url_helper
INFO - 2026-01-21 07:28:27 --> Helper loaded: text_helper
INFO - 2026-01-21 07:28:27 --> Helper loaded: string_helper
INFO - 2026-01-21 07:28:27 --> Helper loaded: form_helper
INFO - 2026-01-21 07:28:27 --> Helper loaded: download_helper
INFO - 2026-01-21 07:28:27 --> Helper loaded: security_helper
INFO - 2026-01-21 07:28:27 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:28:27 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:28:27 --> Form Validation Class Initialized
INFO - 2026-01-21 07:28:27 --> Model "User_model" initialized
INFO - 2026-01-21 13:28:27 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:28:27 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:28:27 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:28:27 --> Controller Class Initialized
INFO - 2026-01-21 13:28:27 --> Model "Download_model" initialized
INFO - 2026-01-21 13:28:27 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 13:28:27 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 13:28:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_standardpelayanan.php
INFO - 2026-01-21 13:28:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:28:28 --> Model "Log_model" initialized
INFO - 2026-01-21 13:28:28 --> Final output sent to browser
DEBUG - 2026-01-21 13:28:28 --> Total execution time: 0.6623
INFO - 2026-01-21 07:28:34 --> Config Class Initialized
INFO - 2026-01-21 07:28:34 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:28:34 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:28:34 --> Utf8 Class Initialized
INFO - 2026-01-21 07:28:34 --> URI Class Initialized
INFO - 2026-01-21 07:28:34 --> Router Class Initialized
INFO - 2026-01-21 07:28:34 --> Output Class Initialized
INFO - 2026-01-21 07:28:34 --> Security Class Initialized
DEBUG - 2026-01-21 07:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:28:34 --> CSRF cookie sent
INFO - 2026-01-21 07:28:34 --> Input Class Initialized
INFO - 2026-01-21 07:28:34 --> Language Class Initialized
INFO - 2026-01-21 07:28:34 --> Loader Class Initialized
INFO - 2026-01-21 07:28:34 --> Helper loaded: url_helper
INFO - 2026-01-21 07:28:34 --> Helper loaded: text_helper
INFO - 2026-01-21 07:28:34 --> Helper loaded: string_helper
INFO - 2026-01-21 07:28:34 --> Helper loaded: form_helper
INFO - 2026-01-21 07:28:34 --> Helper loaded: download_helper
INFO - 2026-01-21 07:28:34 --> Helper loaded: security_helper
INFO - 2026-01-21 07:28:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:28:34 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:28:34 --> Form Validation Class Initialized
INFO - 2026-01-21 07:28:35 --> Model "User_model" initialized
INFO - 2026-01-21 13:28:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:28:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:28:35 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:28:35 --> Controller Class Initialized
INFO - 2026-01-21 13:28:35 --> Model "Download_model" initialized
INFO - 2026-01-21 13:28:35 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 13:28:35 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 13:28:35 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko\/20100101 Firefox\/147.0","download_id":"51","filename":"Instruksi_Kerja_Legalisir_Dokumen_Akademik.pdf","timestamp":"2026-01-21 13:28:35"}
INFO - 2026-01-21 07:30:24 --> Config Class Initialized
INFO - 2026-01-21 07:30:24 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:30:24 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:30:24 --> Utf8 Class Initialized
INFO - 2026-01-21 07:30:24 --> URI Class Initialized
DEBUG - 2026-01-21 07:30:24 --> No URI present. Default controller set.
INFO - 2026-01-21 07:30:24 --> Router Class Initialized
INFO - 2026-01-21 07:30:24 --> Output Class Initialized
INFO - 2026-01-21 07:30:24 --> Security Class Initialized
DEBUG - 2026-01-21 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:30:24 --> CSRF cookie sent
INFO - 2026-01-21 07:30:24 --> Input Class Initialized
INFO - 2026-01-21 07:30:24 --> Language Class Initialized
INFO - 2026-01-21 07:30:24 --> Loader Class Initialized
INFO - 2026-01-21 07:30:24 --> Helper loaded: url_helper
INFO - 2026-01-21 07:30:24 --> Helper loaded: text_helper
INFO - 2026-01-21 07:30:24 --> Helper loaded: string_helper
INFO - 2026-01-21 07:30:24 --> Helper loaded: form_helper
INFO - 2026-01-21 07:30:24 --> Helper loaded: download_helper
INFO - 2026-01-21 07:30:24 --> Helper loaded: security_helper
INFO - 2026-01-21 07:30:24 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:30:24 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:30:24 --> Form Validation Class Initialized
INFO - 2026-01-21 07:30:24 --> Model "User_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:30:24 --> Controller Class Initialized
INFO - 2026-01-21 13:30:24 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Video_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:30:24 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:30:25 --> Pagination Class Initialized
INFO - 2026-01-21 13:30:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:30:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:30:25 --> Model "Log_model" initialized
INFO - 2026-01-21 13:30:25 --> Final output sent to browser
DEBUG - 2026-01-21 13:30:25 --> Total execution time: 0.2371
INFO - 2026-01-21 07:30:56 --> Config Class Initialized
INFO - 2026-01-21 07:30:56 --> Hooks Class Initialized
DEBUG - 2026-01-21 07:30:56 --> UTF-8 Support Enabled
INFO - 2026-01-21 07:30:56 --> Utf8 Class Initialized
INFO - 2026-01-21 07:30:56 --> URI Class Initialized
DEBUG - 2026-01-21 07:30:56 --> No URI present. Default controller set.
INFO - 2026-01-21 07:30:56 --> Router Class Initialized
INFO - 2026-01-21 07:30:56 --> Output Class Initialized
INFO - 2026-01-21 07:30:56 --> Security Class Initialized
DEBUG - 2026-01-21 07:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 07:30:56 --> CSRF cookie sent
INFO - 2026-01-21 07:30:56 --> Input Class Initialized
INFO - 2026-01-21 07:30:56 --> Language Class Initialized
INFO - 2026-01-21 07:30:56 --> Loader Class Initialized
INFO - 2026-01-21 07:30:56 --> Helper loaded: url_helper
INFO - 2026-01-21 07:30:56 --> Helper loaded: text_helper
INFO - 2026-01-21 07:30:56 --> Helper loaded: string_helper
INFO - 2026-01-21 07:30:56 --> Helper loaded: form_helper
INFO - 2026-01-21 07:30:56 --> Helper loaded: download_helper
INFO - 2026-01-21 07:30:56 --> Helper loaded: security_helper
INFO - 2026-01-21 07:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 07:30:57 --> Database Driver Class Initialized
DEBUG - 2026-01-21 07:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 07:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 07:30:57 --> Form Validation Class Initialized
INFO - 2026-01-21 07:30:57 --> Model "User_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Nav_model" initialized
INFO - 2026-01-21 13:30:57 --> Controller Class Initialized
INFO - 2026-01-21 13:30:57 --> Model "Berita_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Galeri_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Video_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Agenda_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Tautan_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Mitra_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Prodi_model" initialized
INFO - 2026-01-21 13:30:57 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 13:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 13:30:57 --> Pagination Class Initialized
INFO - 2026-01-21 13:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 13:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 13:30:57 --> Model "Log_model" initialized
INFO - 2026-01-21 13:30:57 --> Final output sent to browser
DEBUG - 2026-01-21 13:30:57 --> Total execution time: 0.2414
INFO - 2026-01-21 08:38:06 --> Config Class Initialized
INFO - 2026-01-21 08:38:06 --> Hooks Class Initialized
DEBUG - 2026-01-21 08:38:06 --> UTF-8 Support Enabled
INFO - 2026-01-21 08:38:06 --> Utf8 Class Initialized
INFO - 2026-01-21 08:38:06 --> URI Class Initialized
INFO - 2026-01-21 08:38:06 --> Router Class Initialized
INFO - 2026-01-21 08:38:06 --> Output Class Initialized
INFO - 2026-01-21 08:38:06 --> Security Class Initialized
DEBUG - 2026-01-21 08:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 08:38:06 --> CSRF cookie sent
INFO - 2026-01-21 08:38:06 --> Input Class Initialized
INFO - 2026-01-21 08:38:06 --> Language Class Initialized
INFO - 2026-01-21 08:38:06 --> Loader Class Initialized
INFO - 2026-01-21 08:38:06 --> Helper loaded: url_helper
INFO - 2026-01-21 08:38:06 --> Helper loaded: text_helper
INFO - 2026-01-21 08:38:06 --> Helper loaded: string_helper
INFO - 2026-01-21 08:38:06 --> Helper loaded: form_helper
INFO - 2026-01-21 08:38:06 --> Helper loaded: download_helper
INFO - 2026-01-21 08:38:06 --> Helper loaded: security_helper
INFO - 2026-01-21 08:38:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 08:38:06 --> Database Driver Class Initialized
DEBUG - 2026-01-21 08:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 08:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 08:38:06 --> Form Validation Class Initialized
INFO - 2026-01-21 08:38:06 --> Model "User_model" initialized
INFO - 2026-01-21 14:38:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 14:38:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 14:38:06 --> Model "Nav_model" initialized
INFO - 2026-01-21 14:38:06 --> Controller Class Initialized
INFO - 2026-01-21 14:38:06 --> Model "Download_model" initialized
INFO - 2026-01-21 14:38:06 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 14:38:06 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 14:38:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_standardpelayanan.php
INFO - 2026-01-21 14:38:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 14:38:06 --> Model "Log_model" initialized
INFO - 2026-01-21 14:38:06 --> Final output sent to browser
DEBUG - 2026-01-21 14:38:06 --> Total execution time: 0.1861
INFO - 2026-01-21 08:38:09 --> Config Class Initialized
INFO - 2026-01-21 08:38:09 --> Hooks Class Initialized
DEBUG - 2026-01-21 08:38:09 --> UTF-8 Support Enabled
INFO - 2026-01-21 08:38:09 --> Utf8 Class Initialized
INFO - 2026-01-21 08:38:09 --> URI Class Initialized
INFO - 2026-01-21 08:38:09 --> Router Class Initialized
INFO - 2026-01-21 08:38:09 --> Output Class Initialized
INFO - 2026-01-21 08:38:09 --> Security Class Initialized
DEBUG - 2026-01-21 08:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 08:38:09 --> CSRF cookie sent
INFO - 2026-01-21 08:38:09 --> Input Class Initialized
INFO - 2026-01-21 08:38:09 --> Language Class Initialized
INFO - 2026-01-21 08:38:09 --> Loader Class Initialized
INFO - 2026-01-21 08:38:09 --> Helper loaded: url_helper
INFO - 2026-01-21 08:38:09 --> Helper loaded: text_helper
INFO - 2026-01-21 08:38:09 --> Helper loaded: string_helper
INFO - 2026-01-21 08:38:09 --> Helper loaded: form_helper
INFO - 2026-01-21 08:38:09 --> Helper loaded: download_helper
INFO - 2026-01-21 08:38:09 --> Helper loaded: security_helper
INFO - 2026-01-21 08:38:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 08:38:09 --> Database Driver Class Initialized
DEBUG - 2026-01-21 08:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 08:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 08:38:09 --> Form Validation Class Initialized
INFO - 2026-01-21 08:38:09 --> Model "User_model" initialized
INFO - 2026-01-21 14:38:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 14:38:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 14:38:09 --> Model "Nav_model" initialized
INFO - 2026-01-21 14:38:09 --> Controller Class Initialized
INFO - 2026-01-21 14:38:09 --> Model "Download_model" initialized
INFO - 2026-01-21 14:38:09 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 14:38:09 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 14:38:09 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko\/20100101 Firefox\/147.0","download_id":"108","filename":"Standar_Suasana_Akademik.pdf","timestamp":"2026-01-21 14:38:09"}
INFO - 2026-01-21 08:38:16 --> Config Class Initialized
INFO - 2026-01-21 08:38:16 --> Hooks Class Initialized
DEBUG - 2026-01-21 08:38:16 --> UTF-8 Support Enabled
INFO - 2026-01-21 08:38:16 --> Utf8 Class Initialized
INFO - 2026-01-21 08:38:16 --> URI Class Initialized
INFO - 2026-01-21 08:38:16 --> Router Class Initialized
INFO - 2026-01-21 08:38:16 --> Output Class Initialized
INFO - 2026-01-21 08:38:16 --> Security Class Initialized
DEBUG - 2026-01-21 08:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 08:38:16 --> CSRF cookie sent
INFO - 2026-01-21 08:38:16 --> Input Class Initialized
INFO - 2026-01-21 08:38:16 --> Language Class Initialized
INFO - 2026-01-21 08:38:16 --> Loader Class Initialized
INFO - 2026-01-21 08:38:16 --> Helper loaded: url_helper
INFO - 2026-01-21 08:38:16 --> Helper loaded: text_helper
INFO - 2026-01-21 08:38:16 --> Helper loaded: string_helper
INFO - 2026-01-21 08:38:16 --> Helper loaded: form_helper
INFO - 2026-01-21 08:38:16 --> Helper loaded: download_helper
INFO - 2026-01-21 08:38:16 --> Helper loaded: security_helper
INFO - 2026-01-21 08:38:16 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 08:38:16 --> Database Driver Class Initialized
DEBUG - 2026-01-21 08:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 08:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 08:38:16 --> Form Validation Class Initialized
INFO - 2026-01-21 08:38:16 --> Model "User_model" initialized
INFO - 2026-01-21 14:38:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 14:38:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 14:38:16 --> Model "Nav_model" initialized
INFO - 2026-01-21 14:38:16 --> Controller Class Initialized
INFO - 2026-01-21 14:38:16 --> Model "Download_model" initialized
INFO - 2026-01-21 14:38:16 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 14:38:16 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 14:38:16 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko\/20100101 Firefox\/147.0","download_id":"115","filename":"Standar_Pelayanan_Penyelenggaraan_Wisuda.pdf","timestamp":"2026-01-21 14:38:16"}
INFO - 2026-01-21 08:38:26 --> Config Class Initialized
INFO - 2026-01-21 08:38:26 --> Hooks Class Initialized
DEBUG - 2026-01-21 08:38:26 --> UTF-8 Support Enabled
INFO - 2026-01-21 08:38:26 --> Utf8 Class Initialized
INFO - 2026-01-21 08:38:26 --> URI Class Initialized
DEBUG - 2026-01-21 08:38:26 --> No URI present. Default controller set.
INFO - 2026-01-21 08:38:26 --> Router Class Initialized
INFO - 2026-01-21 08:38:26 --> Output Class Initialized
INFO - 2026-01-21 08:38:26 --> Security Class Initialized
DEBUG - 2026-01-21 08:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 08:38:26 --> CSRF cookie sent
INFO - 2026-01-21 08:38:26 --> Input Class Initialized
INFO - 2026-01-21 08:38:26 --> Language Class Initialized
INFO - 2026-01-21 08:38:26 --> Loader Class Initialized
INFO - 2026-01-21 08:38:26 --> Helper loaded: url_helper
INFO - 2026-01-21 08:38:26 --> Helper loaded: text_helper
INFO - 2026-01-21 08:38:26 --> Helper loaded: string_helper
INFO - 2026-01-21 08:38:26 --> Helper loaded: form_helper
INFO - 2026-01-21 08:38:26 --> Helper loaded: download_helper
INFO - 2026-01-21 08:38:26 --> Helper loaded: security_helper
INFO - 2026-01-21 08:38:26 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 08:38:26 --> Database Driver Class Initialized
DEBUG - 2026-01-21 08:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 08:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 08:38:26 --> Form Validation Class Initialized
INFO - 2026-01-21 08:38:26 --> Model "User_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Nav_model" initialized
INFO - 2026-01-21 14:38:26 --> Controller Class Initialized
INFO - 2026-01-21 14:38:26 --> Model "Berita_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Galeri_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Video_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Agenda_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Tautan_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Mitra_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Prodi_model" initialized
INFO - 2026-01-21 14:38:26 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 14:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 14:38:26 --> Pagination Class Initialized
INFO - 2026-01-21 14:38:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 14:38:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 14:38:26 --> Model "Log_model" initialized
INFO - 2026-01-21 14:38:26 --> Final output sent to browser
DEBUG - 2026-01-21 14:38:26 --> Total execution time: 0.2344
INFO - 2026-01-21 09:33:50 --> Config Class Initialized
INFO - 2026-01-21 09:33:50 --> Hooks Class Initialized
DEBUG - 2026-01-21 09:33:50 --> UTF-8 Support Enabled
INFO - 2026-01-21 09:33:50 --> Utf8 Class Initialized
INFO - 2026-01-21 09:33:50 --> URI Class Initialized
DEBUG - 2026-01-21 09:33:50 --> No URI present. Default controller set.
INFO - 2026-01-21 09:33:50 --> Router Class Initialized
INFO - 2026-01-21 09:33:50 --> Output Class Initialized
INFO - 2026-01-21 09:33:50 --> Security Class Initialized
DEBUG - 2026-01-21 09:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 09:33:50 --> CSRF cookie sent
INFO - 2026-01-21 09:33:50 --> Input Class Initialized
INFO - 2026-01-21 09:33:50 --> Language Class Initialized
INFO - 2026-01-21 09:33:50 --> Loader Class Initialized
INFO - 2026-01-21 09:33:50 --> Helper loaded: url_helper
INFO - 2026-01-21 09:33:50 --> Helper loaded: text_helper
INFO - 2026-01-21 09:33:50 --> Helper loaded: string_helper
INFO - 2026-01-21 09:33:50 --> Helper loaded: form_helper
INFO - 2026-01-21 09:33:50 --> Helper loaded: download_helper
INFO - 2026-01-21 09:33:50 --> Helper loaded: security_helper
INFO - 2026-01-21 09:33:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 09:33:50 --> Database Driver Class Initialized
DEBUG - 2026-01-21 09:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 09:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 09:33:50 --> Form Validation Class Initialized
INFO - 2026-01-21 09:33:50 --> Model "User_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Nav_model" initialized
INFO - 2026-01-21 15:33:50 --> Controller Class Initialized
INFO - 2026-01-21 15:33:50 --> Model "Berita_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Galeri_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Video_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Agenda_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Tautan_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Mitra_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Jurusan_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Prodi_model" initialized
INFO - 2026-01-21 15:33:50 --> Model "Testimoni_model" initialized
INFO - 2026-01-21 15:33:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-21 15:33:50 --> Pagination Class Initialized
INFO - 2026-01-21 15:33:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-21 15:33:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 15:33:50 --> Model "Log_model" initialized
INFO - 2026-01-21 15:33:50 --> Final output sent to browser
DEBUG - 2026-01-21 15:33:50 --> Total execution time: 0.2145
INFO - 2026-01-21 09:33:59 --> Config Class Initialized
INFO - 2026-01-21 09:33:59 --> Hooks Class Initialized
DEBUG - 2026-01-21 09:33:59 --> UTF-8 Support Enabled
INFO - 2026-01-21 09:33:59 --> Utf8 Class Initialized
INFO - 2026-01-21 09:33:59 --> URI Class Initialized
INFO - 2026-01-21 09:33:59 --> Router Class Initialized
INFO - 2026-01-21 09:33:59 --> Output Class Initialized
INFO - 2026-01-21 09:33:59 --> Security Class Initialized
DEBUG - 2026-01-21 09:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 09:33:59 --> CSRF cookie sent
INFO - 2026-01-21 09:33:59 --> Input Class Initialized
INFO - 2026-01-21 09:33:59 --> Language Class Initialized
INFO - 2026-01-21 09:33:59 --> Loader Class Initialized
INFO - 2026-01-21 09:33:59 --> Helper loaded: url_helper
INFO - 2026-01-21 09:33:59 --> Helper loaded: text_helper
INFO - 2026-01-21 09:33:59 --> Helper loaded: string_helper
INFO - 2026-01-21 09:33:59 --> Helper loaded: form_helper
INFO - 2026-01-21 09:33:59 --> Helper loaded: download_helper
INFO - 2026-01-21 09:33:59 --> Helper loaded: security_helper
INFO - 2026-01-21 09:33:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 09:33:59 --> Database Driver Class Initialized
DEBUG - 2026-01-21 09:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 09:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 09:33:59 --> Form Validation Class Initialized
INFO - 2026-01-21 09:33:59 --> Model "User_model" initialized
INFO - 2026-01-21 15:33:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 15:33:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 15:33:59 --> Model "Nav_model" initialized
INFO - 2026-01-21 15:33:59 --> Controller Class Initialized
INFO - 2026-01-21 15:33:59 --> Model "Pages_model" initialized
INFO - 2026-01-21 15:33:59 --> Model "Berita_model" initialized
INFO - 2026-01-21 15:33:59 --> Model "Download_model" initialized
INFO - 2026-01-21 15:33:59 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 15:33:59 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 15:33:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-21 15:33:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 15:33:59 --> Model "Log_model" initialized
INFO - 2026-01-21 15:33:59 --> Final output sent to browser
DEBUG - 2026-01-21 15:33:59 --> Total execution time: 0.1493
INFO - 2026-01-21 09:34:23 --> Config Class Initialized
INFO - 2026-01-21 09:34:23 --> Hooks Class Initialized
DEBUG - 2026-01-21 09:34:23 --> UTF-8 Support Enabled
INFO - 2026-01-21 09:34:23 --> Utf8 Class Initialized
INFO - 2026-01-21 09:34:23 --> URI Class Initialized
INFO - 2026-01-21 09:34:23 --> Router Class Initialized
INFO - 2026-01-21 09:34:23 --> Output Class Initialized
INFO - 2026-01-21 09:34:23 --> Security Class Initialized
DEBUG - 2026-01-21 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 09:34:23 --> CSRF cookie sent
INFO - 2026-01-21 09:34:23 --> Input Class Initialized
INFO - 2026-01-21 09:34:23 --> Language Class Initialized
INFO - 2026-01-21 09:34:23 --> Loader Class Initialized
INFO - 2026-01-21 09:34:23 --> Helper loaded: url_helper
INFO - 2026-01-21 09:34:23 --> Helper loaded: text_helper
INFO - 2026-01-21 09:34:23 --> Helper loaded: string_helper
INFO - 2026-01-21 09:34:23 --> Helper loaded: form_helper
INFO - 2026-01-21 09:34:23 --> Helper loaded: download_helper
INFO - 2026-01-21 09:34:23 --> Helper loaded: security_helper
INFO - 2026-01-21 09:34:23 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 09:34:23 --> Database Driver Class Initialized
DEBUG - 2026-01-21 09:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 09:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 09:34:23 --> Form Validation Class Initialized
INFO - 2026-01-21 09:34:23 --> Model "User_model" initialized
INFO - 2026-01-21 15:34:23 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 15:34:23 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 15:34:23 --> Model "Nav_model" initialized
INFO - 2026-01-21 15:34:23 --> Controller Class Initialized
INFO - 2026-01-21 15:34:23 --> Model "Isbn_model" initialized
INFO - 2026-01-21 15:34:23 --> Model "Kategori_model" initialized
INFO - 2026-01-21 15:34:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\isbn/list.php
INFO - 2026-01-21 15:34:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 15:34:23 --> Model "Log_model" initialized
INFO - 2026-01-21 15:34:23 --> Final output sent to browser
DEBUG - 2026-01-21 15:34:23 --> Total execution time: 0.4072
INFO - 2026-01-21 09:34:26 --> Config Class Initialized
INFO - 2026-01-21 09:34:26 --> Hooks Class Initialized
DEBUG - 2026-01-21 09:34:26 --> UTF-8 Support Enabled
INFO - 2026-01-21 09:34:26 --> Utf8 Class Initialized
INFO - 2026-01-21 09:34:26 --> URI Class Initialized
INFO - 2026-01-21 09:34:26 --> Router Class Initialized
INFO - 2026-01-21 09:34:26 --> Output Class Initialized
INFO - 2026-01-21 09:34:26 --> Security Class Initialized
DEBUG - 2026-01-21 09:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 09:34:26 --> CSRF cookie sent
INFO - 2026-01-21 09:34:26 --> Input Class Initialized
INFO - 2026-01-21 09:34:26 --> Language Class Initialized
INFO - 2026-01-21 09:34:26 --> Loader Class Initialized
INFO - 2026-01-21 09:34:26 --> Helper loaded: url_helper
INFO - 2026-01-21 09:34:26 --> Helper loaded: text_helper
INFO - 2026-01-21 09:34:26 --> Helper loaded: string_helper
INFO - 2026-01-21 09:34:26 --> Helper loaded: form_helper
INFO - 2026-01-21 09:34:26 --> Helper loaded: download_helper
INFO - 2026-01-21 09:34:26 --> Helper loaded: security_helper
INFO - 2026-01-21 09:34:26 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 09:34:26 --> Database Driver Class Initialized
DEBUG - 2026-01-21 09:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 09:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 09:34:26 --> Form Validation Class Initialized
INFO - 2026-01-21 09:34:26 --> Model "User_model" initialized
INFO - 2026-01-21 15:34:26 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 15:34:26 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 15:34:26 --> Model "Nav_model" initialized
INFO - 2026-01-21 15:34:26 --> Controller Class Initialized
INFO - 2026-01-21 15:34:26 --> Model "Isbn_model" initialized
INFO - 2026-01-21 15:34:26 --> Model "Kategori_model" initialized
INFO - 2026-01-21 15:34:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\isbn/view.php
INFO - 2026-01-21 15:34:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 15:34:26 --> Model "Log_model" initialized
INFO - 2026-01-21 15:34:26 --> Final output sent to browser
DEBUG - 2026-01-21 15:34:26 --> Total execution time: 0.1436
INFO - 2026-01-21 09:35:14 --> Config Class Initialized
INFO - 2026-01-21 09:35:14 --> Hooks Class Initialized
DEBUG - 2026-01-21 09:35:14 --> UTF-8 Support Enabled
INFO - 2026-01-21 09:35:14 --> Utf8 Class Initialized
INFO - 2026-01-21 09:35:14 --> URI Class Initialized
INFO - 2026-01-21 09:35:14 --> Router Class Initialized
INFO - 2026-01-21 09:35:14 --> Output Class Initialized
INFO - 2026-01-21 09:35:14 --> Security Class Initialized
DEBUG - 2026-01-21 09:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 09:35:14 --> CSRF cookie sent
INFO - 2026-01-21 09:35:14 --> Input Class Initialized
INFO - 2026-01-21 09:35:14 --> Language Class Initialized
INFO - 2026-01-21 09:35:14 --> Loader Class Initialized
INFO - 2026-01-21 09:35:14 --> Helper loaded: url_helper
INFO - 2026-01-21 09:35:14 --> Helper loaded: text_helper
INFO - 2026-01-21 09:35:14 --> Helper loaded: string_helper
INFO - 2026-01-21 09:35:14 --> Helper loaded: form_helper
INFO - 2026-01-21 09:35:14 --> Helper loaded: download_helper
INFO - 2026-01-21 09:35:14 --> Helper loaded: security_helper
INFO - 2026-01-21 09:35:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 09:35:14 --> Database Driver Class Initialized
DEBUG - 2026-01-21 09:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 09:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 09:35:14 --> Form Validation Class Initialized
INFO - 2026-01-21 09:35:14 --> Model "User_model" initialized
INFO - 2026-01-21 15:35:14 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 15:35:14 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 15:35:14 --> Model "Nav_model" initialized
INFO - 2026-01-21 15:35:14 --> Controller Class Initialized
INFO - 2026-01-21 15:35:14 --> Model "Download_model" initialized
INFO - 2026-01-21 15:35:14 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 15:35:14 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 15:35:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-21 15:35:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-21 15:35:14 --> Model "Log_model" initialized
INFO - 2026-01-21 15:35:14 --> Final output sent to browser
DEBUG - 2026-01-21 15:35:14 --> Total execution time: 0.1030
INFO - 2026-01-21 09:35:18 --> Config Class Initialized
INFO - 2026-01-21 09:35:18 --> Hooks Class Initialized
DEBUG - 2026-01-21 09:35:18 --> UTF-8 Support Enabled
INFO - 2026-01-21 09:35:18 --> Utf8 Class Initialized
INFO - 2026-01-21 09:35:18 --> URI Class Initialized
INFO - 2026-01-21 09:35:18 --> Router Class Initialized
INFO - 2026-01-21 09:35:18 --> Output Class Initialized
INFO - 2026-01-21 09:35:18 --> Security Class Initialized
DEBUG - 2026-01-21 09:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 09:35:18 --> CSRF cookie sent
INFO - 2026-01-21 09:35:18 --> Input Class Initialized
INFO - 2026-01-21 09:35:18 --> Language Class Initialized
INFO - 2026-01-21 09:35:18 --> Loader Class Initialized
INFO - 2026-01-21 09:35:18 --> Helper loaded: url_helper
INFO - 2026-01-21 09:35:18 --> Helper loaded: text_helper
INFO - 2026-01-21 09:35:18 --> Helper loaded: string_helper
INFO - 2026-01-21 09:35:18 --> Helper loaded: form_helper
INFO - 2026-01-21 09:35:18 --> Helper loaded: download_helper
INFO - 2026-01-21 09:35:18 --> Helper loaded: security_helper
INFO - 2026-01-21 09:35:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 09:35:18 --> Database Driver Class Initialized
DEBUG - 2026-01-21 09:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 09:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 09:35:19 --> Form Validation Class Initialized
INFO - 2026-01-21 09:35:19 --> Model "User_model" initialized
INFO - 2026-01-21 15:35:19 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 15:35:19 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 15:35:19 --> Model "Nav_model" initialized
INFO - 2026-01-21 15:35:19 --> Controller Class Initialized
INFO - 2026-01-21 15:35:19 --> Model "Download_model" initialized
INFO - 2026-01-21 15:35:19 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 15:35:19 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 15:35:19 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"10","filename":"Sertifikat_Akreditasi_Keperawatan_Persahabatan_2004-2008.pdf","timestamp":"2026-01-21 15:35:19"}
INFO - 2026-01-21 09:35:26 --> Config Class Initialized
INFO - 2026-01-21 09:35:26 --> Hooks Class Initialized
DEBUG - 2026-01-21 09:35:26 --> UTF-8 Support Enabled
INFO - 2026-01-21 09:35:26 --> Utf8 Class Initialized
INFO - 2026-01-21 09:35:26 --> URI Class Initialized
INFO - 2026-01-21 09:35:26 --> Router Class Initialized
INFO - 2026-01-21 09:35:26 --> Output Class Initialized
INFO - 2026-01-21 09:35:26 --> Security Class Initialized
DEBUG - 2026-01-21 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-21 09:35:26 --> CSRF cookie sent
INFO - 2026-01-21 09:35:26 --> Input Class Initialized
INFO - 2026-01-21 09:35:26 --> Language Class Initialized
INFO - 2026-01-21 09:35:26 --> Loader Class Initialized
INFO - 2026-01-21 09:35:26 --> Helper loaded: url_helper
INFO - 2026-01-21 09:35:26 --> Helper loaded: text_helper
INFO - 2026-01-21 09:35:26 --> Helper loaded: string_helper
INFO - 2026-01-21 09:35:26 --> Helper loaded: form_helper
INFO - 2026-01-21 09:35:26 --> Helper loaded: download_helper
INFO - 2026-01-21 09:35:26 --> Helper loaded: security_helper
INFO - 2026-01-21 09:35:26 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-21 09:35:26 --> Database Driver Class Initialized
DEBUG - 2026-01-21 09:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-21 09:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-21 09:35:26 --> Form Validation Class Initialized
INFO - 2026-01-21 09:35:26 --> Model "User_model" initialized
INFO - 2026-01-21 15:35:26 --> Model "Kunjungan_model" initialized
INFO - 2026-01-21 15:35:26 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-21 15:35:26 --> Model "Nav_model" initialized
INFO - 2026-01-21 15:35:26 --> Controller Class Initialized
INFO - 2026-01-21 15:35:26 --> Model "Download_model" initialized
INFO - 2026-01-21 15:35:26 --> Model "Kategori_download_model" initialized
INFO - 2026-01-21 15:35:26 --> Model "Jenis_download_model" initialized
INFO - 2026-01-21 15:35:26 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"209","filename":"Sertifikat_Akreditasi_Sarjana_Terapan_Fisioterapi_2023-2028.pdf","timestamp":"2026-01-21 15:35:26"}
