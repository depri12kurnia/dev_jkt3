<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-07 03:26:09 --> Config Class Initialized
INFO - 2025-10-07 03:26:09 --> Hooks Class Initialized
DEBUG - 2025-10-07 03:26:09 --> UTF-8 Support Enabled
INFO - 2025-10-07 03:26:09 --> Utf8 Class Initialized
INFO - 2025-10-07 03:26:09 --> URI Class Initialized
DEBUG - 2025-10-07 03:26:09 --> No URI present. Default controller set.
INFO - 2025-10-07 03:26:09 --> Router Class Initialized
INFO - 2025-10-07 03:26:09 --> Output Class Initialized
INFO - 2025-10-07 03:26:10 --> Security Class Initialized
DEBUG - 2025-10-07 03:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 03:26:10 --> CSRF cookie sent
INFO - 2025-10-07 03:26:10 --> Input Class Initialized
INFO - 2025-10-07 03:26:10 --> Language Class Initialized
INFO - 2025-10-07 03:26:10 --> Loader Class Initialized
INFO - 2025-10-07 03:26:10 --> Helper loaded: url_helper
INFO - 2025-10-07 03:26:10 --> Helper loaded: text_helper
INFO - 2025-10-07 03:26:10 --> Helper loaded: string_helper
INFO - 2025-10-07 03:26:10 --> Helper loaded: form_helper
INFO - 2025-10-07 03:26:10 --> Helper loaded: download_helper
INFO - 2025-10-07 03:26:10 --> Helper loaded: security_helper
INFO - 2025-10-07 03:26:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 03:26:11 --> Database Driver Class Initialized
DEBUG - 2025-10-07 03:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 03:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 03:26:11 --> Form Validation Class Initialized
INFO - 2025-10-07 03:26:11 --> Model "User_model" initialized
INFO - 2025-10-07 08:26:11 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 08:26:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 08:26:11 --> Model "Nav_model" initialized
INFO - 2025-10-07 08:26:11 --> Controller Class Initialized
INFO - 2025-10-07 08:26:11 --> Model "Berita_model" initialized
INFO - 2025-10-07 08:26:11 --> Model "Galeri_model" initialized
INFO - 2025-10-07 08:26:11 --> Model "Video_model" initialized
INFO - 2025-10-07 08:26:11 --> Model "Agenda_model" initialized
INFO - 2025-10-07 08:26:11 --> Model "Tautan_model" initialized
INFO - 2025-10-07 08:26:11 --> Model "Mitra_model" initialized
INFO - 2025-10-07 08:26:11 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 08:26:11 --> Model "Prodi_model" initialized
INFO - 2025-10-07 08:26:12 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 08:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 08:26:12 --> Pagination Class Initialized
INFO - 2025-10-07 08:26:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 08:26:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 08:26:14 --> Model "Log_model" initialized
INFO - 2025-10-07 08:26:14 --> Final output sent to browser
DEBUG - 2025-10-07 08:26:14 --> Total execution time: 5.5923
INFO - 2025-10-07 04:02:02 --> Config Class Initialized
INFO - 2025-10-07 04:02:02 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:02:02 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:02:02 --> Utf8 Class Initialized
INFO - 2025-10-07 04:02:02 --> URI Class Initialized
INFO - 2025-10-07 04:02:02 --> Router Class Initialized
INFO - 2025-10-07 04:02:02 --> Output Class Initialized
INFO - 2025-10-07 04:02:02 --> Security Class Initialized
DEBUG - 2025-10-07 04:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:02:02 --> CSRF cookie sent
INFO - 2025-10-07 04:02:02 --> Input Class Initialized
INFO - 2025-10-07 04:02:02 --> Language Class Initialized
INFO - 2025-10-07 04:02:02 --> Loader Class Initialized
INFO - 2025-10-07 04:02:02 --> Helper loaded: url_helper
INFO - 2025-10-07 04:02:02 --> Helper loaded: text_helper
INFO - 2025-10-07 04:02:02 --> Helper loaded: string_helper
INFO - 2025-10-07 04:02:02 --> Helper loaded: form_helper
INFO - 2025-10-07 04:02:02 --> Helper loaded: download_helper
INFO - 2025-10-07 04:02:02 --> Helper loaded: security_helper
INFO - 2025-10-07 04:02:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:02:02 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:02:02 --> Form Validation Class Initialized
INFO - 2025-10-07 04:02:02 --> Model "User_model" initialized
INFO - 2025-10-07 09:02:02 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:02:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:02:02 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:02:02 --> Controller Class Initialized
DEBUG - 2025-10-07 09:02:02 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-10-07 09:02:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-10-07 09:02:02 --> Model "Log_model" initialized
INFO - 2025-10-07 09:02:02 --> Final output sent to browser
DEBUG - 2025-10-07 09:02:02 --> Total execution time: 0.4330
INFO - 2025-10-07 04:02:10 --> Config Class Initialized
INFO - 2025-10-07 04:02:10 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:02:10 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:02:10 --> Utf8 Class Initialized
INFO - 2025-10-07 04:02:10 --> URI Class Initialized
INFO - 2025-10-07 04:02:10 --> Router Class Initialized
INFO - 2025-10-07 04:02:10 --> Output Class Initialized
INFO - 2025-10-07 04:02:10 --> Security Class Initialized
DEBUG - 2025-10-07 04:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:02:10 --> CSRF cookie sent
INFO - 2025-10-07 04:02:10 --> CSRF token verified
INFO - 2025-10-07 04:02:10 --> Input Class Initialized
INFO - 2025-10-07 04:02:10 --> Language Class Initialized
INFO - 2025-10-07 04:02:10 --> Loader Class Initialized
INFO - 2025-10-07 04:02:10 --> Helper loaded: url_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: text_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: string_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: form_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: download_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: security_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:02:10 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:02:10 --> Form Validation Class Initialized
INFO - 2025-10-07 04:02:10 --> Model "User_model" initialized
INFO - 2025-10-07 09:02:10 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:02:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:02:10 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:02:10 --> Controller Class Initialized
DEBUG - 2025-10-07 09:02:10 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-10-07 09:02:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-07 04:02:10 --> Config Class Initialized
INFO - 2025-10-07 04:02:10 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:02:10 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:02:10 --> Utf8 Class Initialized
INFO - 2025-10-07 04:02:10 --> URI Class Initialized
INFO - 2025-10-07 04:02:10 --> Router Class Initialized
INFO - 2025-10-07 04:02:10 --> Output Class Initialized
INFO - 2025-10-07 04:02:10 --> Security Class Initialized
DEBUG - 2025-10-07 04:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:02:10 --> CSRF cookie sent
INFO - 2025-10-07 04:02:10 --> Input Class Initialized
INFO - 2025-10-07 04:02:10 --> Language Class Initialized
INFO - 2025-10-07 04:02:10 --> Loader Class Initialized
INFO - 2025-10-07 04:02:10 --> Helper loaded: url_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: text_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: string_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: form_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: download_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: security_helper
INFO - 2025-10-07 04:02:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:02:10 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:02:10 --> Form Validation Class Initialized
INFO - 2025-10-07 04:02:10 --> Model "User_model" initialized
INFO - 2025-10-07 09:02:10 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:02:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:02:10 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:02:10 --> Controller Class Initialized
INFO - 2025-10-07 09:02:10 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:02:10 --> Model "Staff_model" initialized
INFO - 2025-10-07 09:02:10 --> Model "Dasbor_model" initialized
INFO - 2025-10-07 09:02:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-10-07 09:02:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-07 09:02:13 --> Model "Log_model" initialized
INFO - 2025-10-07 09:02:13 --> Final output sent to browser
DEBUG - 2025-10-07 09:02:13 --> Total execution time: 3.5636
INFO - 2025-10-07 04:02:45 --> Config Class Initialized
INFO - 2025-10-07 04:02:45 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:02:45 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:02:45 --> Utf8 Class Initialized
INFO - 2025-10-07 04:02:45 --> URI Class Initialized
DEBUG - 2025-10-07 04:02:45 --> No URI present. Default controller set.
INFO - 2025-10-07 04:02:45 --> Router Class Initialized
INFO - 2025-10-07 04:02:45 --> Output Class Initialized
INFO - 2025-10-07 04:02:45 --> Security Class Initialized
DEBUG - 2025-10-07 04:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:02:45 --> CSRF cookie sent
INFO - 2025-10-07 04:02:45 --> Input Class Initialized
INFO - 2025-10-07 04:02:45 --> Language Class Initialized
INFO - 2025-10-07 04:02:45 --> Loader Class Initialized
INFO - 2025-10-07 04:02:45 --> Helper loaded: url_helper
INFO - 2025-10-07 04:02:45 --> Helper loaded: text_helper
INFO - 2025-10-07 04:02:45 --> Helper loaded: string_helper
INFO - 2025-10-07 04:02:45 --> Helper loaded: form_helper
INFO - 2025-10-07 04:02:45 --> Helper loaded: download_helper
INFO - 2025-10-07 04:02:45 --> Helper loaded: security_helper
INFO - 2025-10-07 04:02:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:02:45 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:02:45 --> Form Validation Class Initialized
INFO - 2025-10-07 04:02:45 --> Model "User_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:02:45 --> Controller Class Initialized
INFO - 2025-10-07 09:02:45 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Video_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:02:45 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:02:45 --> Pagination Class Initialized
INFO - 2025-10-07 09:02:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:02:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:02:45 --> Model "Log_model" initialized
INFO - 2025-10-07 09:02:45 --> Final output sent to browser
DEBUG - 2025-10-07 09:02:45 --> Total execution time: 0.3124
INFO - 2025-10-07 04:02:55 --> Config Class Initialized
INFO - 2025-10-07 04:02:55 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:02:55 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:02:55 --> Utf8 Class Initialized
INFO - 2025-10-07 04:02:55 --> URI Class Initialized
INFO - 2025-10-07 04:02:55 --> Router Class Initialized
INFO - 2025-10-07 04:02:55 --> Output Class Initialized
INFO - 2025-10-07 04:02:55 --> Security Class Initialized
DEBUG - 2025-10-07 04:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:02:55 --> CSRF cookie sent
INFO - 2025-10-07 04:02:55 --> Input Class Initialized
INFO - 2025-10-07 04:02:55 --> Language Class Initialized
INFO - 2025-10-07 04:02:55 --> Loader Class Initialized
INFO - 2025-10-07 04:02:55 --> Helper loaded: url_helper
INFO - 2025-10-07 04:02:55 --> Helper loaded: text_helper
INFO - 2025-10-07 04:02:55 --> Helper loaded: string_helper
INFO - 2025-10-07 04:02:55 --> Helper loaded: form_helper
INFO - 2025-10-07 04:02:55 --> Helper loaded: download_helper
INFO - 2025-10-07 04:02:55 --> Helper loaded: security_helper
INFO - 2025-10-07 04:02:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:02:55 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:02:55 --> Form Validation Class Initialized
INFO - 2025-10-07 04:02:55 --> Model "User_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:02:55 --> Controller Class Initialized
INFO - 2025-10-07 09:02:55 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Video_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:02:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:02:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-07 09:02:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:02:55 --> Model "Log_model" initialized
INFO - 2025-10-07 09:02:55 --> Final output sent to browser
DEBUG - 2025-10-07 09:02:55 --> Total execution time: 0.1534
INFO - 2025-10-07 04:03:04 --> Config Class Initialized
INFO - 2025-10-07 04:03:04 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:03:04 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:03:04 --> Utf8 Class Initialized
INFO - 2025-10-07 04:03:04 --> URI Class Initialized
DEBUG - 2025-10-07 04:03:04 --> No URI present. Default controller set.
INFO - 2025-10-07 04:03:04 --> Router Class Initialized
INFO - 2025-10-07 04:03:04 --> Output Class Initialized
INFO - 2025-10-07 04:03:04 --> Security Class Initialized
DEBUG - 2025-10-07 04:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:03:04 --> CSRF cookie sent
INFO - 2025-10-07 04:03:04 --> Input Class Initialized
INFO - 2025-10-07 04:03:04 --> Language Class Initialized
INFO - 2025-10-07 04:03:04 --> Loader Class Initialized
INFO - 2025-10-07 04:03:04 --> Helper loaded: url_helper
INFO - 2025-10-07 04:03:04 --> Helper loaded: text_helper
INFO - 2025-10-07 04:03:04 --> Helper loaded: string_helper
INFO - 2025-10-07 04:03:04 --> Helper loaded: form_helper
INFO - 2025-10-07 04:03:04 --> Helper loaded: download_helper
INFO - 2025-10-07 04:03:05 --> Helper loaded: security_helper
INFO - 2025-10-07 04:03:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:03:05 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:03:05 --> Form Validation Class Initialized
INFO - 2025-10-07 04:03:05 --> Model "User_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:03:05 --> Controller Class Initialized
INFO - 2025-10-07 09:03:05 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Video_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:03:05 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:03:05 --> Pagination Class Initialized
INFO - 2025-10-07 09:03:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:03:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:03:05 --> Model "Log_model" initialized
INFO - 2025-10-07 09:03:05 --> Final output sent to browser
DEBUG - 2025-10-07 09:03:05 --> Total execution time: 0.2487
INFO - 2025-10-07 04:05:37 --> Config Class Initialized
INFO - 2025-10-07 04:05:37 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:05:37 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:05:37 --> Utf8 Class Initialized
INFO - 2025-10-07 04:05:37 --> URI Class Initialized
DEBUG - 2025-10-07 04:05:37 --> No URI present. Default controller set.
INFO - 2025-10-07 04:05:37 --> Router Class Initialized
INFO - 2025-10-07 04:05:37 --> Output Class Initialized
INFO - 2025-10-07 04:05:37 --> Security Class Initialized
DEBUG - 2025-10-07 04:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:05:37 --> CSRF cookie sent
INFO - 2025-10-07 04:05:37 --> Input Class Initialized
INFO - 2025-10-07 04:05:37 --> Language Class Initialized
INFO - 2025-10-07 04:05:37 --> Loader Class Initialized
INFO - 2025-10-07 04:05:37 --> Helper loaded: url_helper
INFO - 2025-10-07 04:05:37 --> Helper loaded: text_helper
INFO - 2025-10-07 04:05:37 --> Helper loaded: string_helper
INFO - 2025-10-07 04:05:37 --> Helper loaded: form_helper
INFO - 2025-10-07 04:05:37 --> Helper loaded: download_helper
INFO - 2025-10-07 04:05:37 --> Helper loaded: security_helper
INFO - 2025-10-07 04:05:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:05:37 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:05:37 --> Form Validation Class Initialized
INFO - 2025-10-07 04:05:37 --> Model "User_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:05:37 --> Controller Class Initialized
INFO - 2025-10-07 09:05:37 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Video_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:05:37 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:05:38 --> Pagination Class Initialized
INFO - 2025-10-07 09:05:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:05:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:05:38 --> Model "Log_model" initialized
INFO - 2025-10-07 09:05:38 --> Final output sent to browser
DEBUG - 2025-10-07 09:05:38 --> Total execution time: 0.4138
INFO - 2025-10-07 04:05:49 --> Config Class Initialized
INFO - 2025-10-07 04:05:49 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:05:49 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:05:49 --> Utf8 Class Initialized
INFO - 2025-10-07 04:05:49 --> URI Class Initialized
DEBUG - 2025-10-07 04:05:49 --> No URI present. Default controller set.
INFO - 2025-10-07 04:05:49 --> Router Class Initialized
INFO - 2025-10-07 04:05:49 --> Output Class Initialized
INFO - 2025-10-07 04:05:49 --> Security Class Initialized
DEBUG - 2025-10-07 04:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:05:49 --> CSRF cookie sent
INFO - 2025-10-07 04:05:49 --> Input Class Initialized
INFO - 2025-10-07 04:05:49 --> Language Class Initialized
INFO - 2025-10-07 04:05:49 --> Loader Class Initialized
INFO - 2025-10-07 04:05:49 --> Helper loaded: url_helper
INFO - 2025-10-07 04:05:49 --> Helper loaded: text_helper
INFO - 2025-10-07 04:05:49 --> Helper loaded: string_helper
INFO - 2025-10-07 04:05:49 --> Helper loaded: form_helper
INFO - 2025-10-07 04:05:49 --> Helper loaded: download_helper
INFO - 2025-10-07 04:05:49 --> Helper loaded: security_helper
INFO - 2025-10-07 04:05:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:05:49 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:05:49 --> Form Validation Class Initialized
INFO - 2025-10-07 04:05:49 --> Model "User_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:05:49 --> Controller Class Initialized
INFO - 2025-10-07 09:05:49 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Video_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:05:49 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:05:49 --> Pagination Class Initialized
INFO - 2025-10-07 09:05:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:05:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:05:49 --> Model "Log_model" initialized
INFO - 2025-10-07 09:05:49 --> Final output sent to browser
DEBUG - 2025-10-07 09:05:49 --> Total execution time: 0.3313
INFO - 2025-10-07 04:06:01 --> Config Class Initialized
INFO - 2025-10-07 04:06:01 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:06:01 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:06:01 --> Utf8 Class Initialized
INFO - 2025-10-07 04:06:01 --> URI Class Initialized
DEBUG - 2025-10-07 04:06:01 --> No URI present. Default controller set.
INFO - 2025-10-07 04:06:01 --> Router Class Initialized
INFO - 2025-10-07 04:06:01 --> Output Class Initialized
INFO - 2025-10-07 04:06:01 --> Security Class Initialized
DEBUG - 2025-10-07 04:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:06:01 --> CSRF cookie sent
INFO - 2025-10-07 04:06:01 --> Input Class Initialized
INFO - 2025-10-07 04:06:01 --> Language Class Initialized
INFO - 2025-10-07 04:06:01 --> Loader Class Initialized
INFO - 2025-10-07 04:06:01 --> Helper loaded: url_helper
INFO - 2025-10-07 04:06:01 --> Helper loaded: text_helper
INFO - 2025-10-07 04:06:01 --> Helper loaded: string_helper
INFO - 2025-10-07 04:06:01 --> Helper loaded: form_helper
INFO - 2025-10-07 04:06:01 --> Helper loaded: download_helper
INFO - 2025-10-07 04:06:01 --> Helper loaded: security_helper
INFO - 2025-10-07 04:06:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:06:01 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:06:01 --> Form Validation Class Initialized
INFO - 2025-10-07 04:06:01 --> Model "User_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:06:01 --> Controller Class Initialized
INFO - 2025-10-07 09:06:01 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Video_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:06:01 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:06:01 --> Pagination Class Initialized
INFO - 2025-10-07 09:06:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:06:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:06:01 --> Model "Log_model" initialized
INFO - 2025-10-07 09:06:01 --> Final output sent to browser
DEBUG - 2025-10-07 09:06:01 --> Total execution time: 0.2320
INFO - 2025-10-07 04:06:03 --> Config Class Initialized
INFO - 2025-10-07 04:06:03 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:06:03 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:06:03 --> Utf8 Class Initialized
INFO - 2025-10-07 04:06:03 --> URI Class Initialized
DEBUG - 2025-10-07 04:06:03 --> No URI present. Default controller set.
INFO - 2025-10-07 04:06:03 --> Router Class Initialized
INFO - 2025-10-07 04:06:03 --> Output Class Initialized
INFO - 2025-10-07 04:06:03 --> Security Class Initialized
DEBUG - 2025-10-07 04:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:06:03 --> CSRF cookie sent
INFO - 2025-10-07 04:06:03 --> Input Class Initialized
INFO - 2025-10-07 04:06:03 --> Language Class Initialized
INFO - 2025-10-07 04:06:03 --> Loader Class Initialized
INFO - 2025-10-07 04:06:03 --> Helper loaded: url_helper
INFO - 2025-10-07 04:06:03 --> Helper loaded: text_helper
INFO - 2025-10-07 04:06:03 --> Helper loaded: string_helper
INFO - 2025-10-07 04:06:03 --> Helper loaded: form_helper
INFO - 2025-10-07 04:06:03 --> Helper loaded: download_helper
INFO - 2025-10-07 04:06:03 --> Helper loaded: security_helper
INFO - 2025-10-07 04:06:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:06:03 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:06:03 --> Form Validation Class Initialized
INFO - 2025-10-07 04:06:03 --> Model "User_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:06:03 --> Controller Class Initialized
INFO - 2025-10-07 09:06:03 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Video_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:06:03 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:06:03 --> Pagination Class Initialized
INFO - 2025-10-07 09:06:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:06:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:06:03 --> Model "Log_model" initialized
INFO - 2025-10-07 09:06:03 --> Final output sent to browser
DEBUG - 2025-10-07 09:06:03 --> Total execution time: 0.2206
INFO - 2025-10-07 04:06:50 --> Config Class Initialized
INFO - 2025-10-07 04:06:50 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:06:50 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:06:50 --> Utf8 Class Initialized
INFO - 2025-10-07 04:06:50 --> URI Class Initialized
DEBUG - 2025-10-07 04:06:50 --> No URI present. Default controller set.
INFO - 2025-10-07 04:06:50 --> Router Class Initialized
INFO - 2025-10-07 04:06:50 --> Output Class Initialized
INFO - 2025-10-07 04:06:50 --> Security Class Initialized
DEBUG - 2025-10-07 04:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:06:50 --> CSRF cookie sent
INFO - 2025-10-07 04:06:50 --> Input Class Initialized
INFO - 2025-10-07 04:06:50 --> Language Class Initialized
INFO - 2025-10-07 04:06:50 --> Loader Class Initialized
INFO - 2025-10-07 04:06:50 --> Helper loaded: url_helper
INFO - 2025-10-07 04:06:50 --> Helper loaded: text_helper
INFO - 2025-10-07 04:06:50 --> Helper loaded: string_helper
INFO - 2025-10-07 04:06:50 --> Helper loaded: form_helper
INFO - 2025-10-07 04:06:50 --> Helper loaded: download_helper
INFO - 2025-10-07 04:06:50 --> Helper loaded: security_helper
INFO - 2025-10-07 04:06:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:06:50 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:06:50 --> Form Validation Class Initialized
INFO - 2025-10-07 04:06:50 --> Model "User_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:06:50 --> Controller Class Initialized
INFO - 2025-10-07 09:06:50 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Video_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:06:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:06:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:06:50 --> Pagination Class Initialized
INFO - 2025-10-07 09:06:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:06:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:06:50 --> Model "Log_model" initialized
INFO - 2025-10-07 09:06:50 --> Final output sent to browser
DEBUG - 2025-10-07 09:06:50 --> Total execution time: 0.2411
INFO - 2025-10-07 04:07:32 --> Config Class Initialized
INFO - 2025-10-07 04:07:32 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:07:32 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:07:32 --> Utf8 Class Initialized
INFO - 2025-10-07 04:07:32 --> URI Class Initialized
DEBUG - 2025-10-07 04:07:32 --> No URI present. Default controller set.
INFO - 2025-10-07 04:07:32 --> Router Class Initialized
INFO - 2025-10-07 04:07:32 --> Output Class Initialized
INFO - 2025-10-07 04:07:32 --> Security Class Initialized
DEBUG - 2025-10-07 04:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:07:32 --> CSRF cookie sent
INFO - 2025-10-07 04:07:32 --> Input Class Initialized
INFO - 2025-10-07 04:07:32 --> Language Class Initialized
INFO - 2025-10-07 04:07:32 --> Loader Class Initialized
INFO - 2025-10-07 04:07:32 --> Helper loaded: url_helper
INFO - 2025-10-07 04:07:32 --> Helper loaded: text_helper
INFO - 2025-10-07 04:07:32 --> Helper loaded: string_helper
INFO - 2025-10-07 04:07:32 --> Helper loaded: form_helper
INFO - 2025-10-07 04:07:32 --> Helper loaded: download_helper
INFO - 2025-10-07 04:07:32 --> Helper loaded: security_helper
INFO - 2025-10-07 04:07:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:07:32 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:07:32 --> Form Validation Class Initialized
INFO - 2025-10-07 04:07:32 --> Model "User_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:07:32 --> Controller Class Initialized
INFO - 2025-10-07 09:07:32 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Video_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:07:32 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:07:32 --> Pagination Class Initialized
INFO - 2025-10-07 09:07:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:07:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:07:32 --> Model "Log_model" initialized
INFO - 2025-10-07 09:07:32 --> Final output sent to browser
DEBUG - 2025-10-07 09:07:32 --> Total execution time: 0.4213
INFO - 2025-10-07 04:07:59 --> Config Class Initialized
INFO - 2025-10-07 04:07:59 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:07:59 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:07:59 --> Utf8 Class Initialized
INFO - 2025-10-07 04:07:59 --> URI Class Initialized
INFO - 2025-10-07 04:07:59 --> Router Class Initialized
INFO - 2025-10-07 04:07:59 --> Output Class Initialized
INFO - 2025-10-07 04:07:59 --> Security Class Initialized
DEBUG - 2025-10-07 04:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:07:59 --> CSRF cookie sent
INFO - 2025-10-07 04:07:59 --> Input Class Initialized
INFO - 2025-10-07 04:07:59 --> Language Class Initialized
INFO - 2025-10-07 04:07:59 --> Loader Class Initialized
INFO - 2025-10-07 04:07:59 --> Helper loaded: url_helper
INFO - 2025-10-07 04:07:59 --> Helper loaded: text_helper
INFO - 2025-10-07 04:07:59 --> Helper loaded: string_helper
INFO - 2025-10-07 04:07:59 --> Helper loaded: form_helper
INFO - 2025-10-07 04:07:59 --> Helper loaded: download_helper
INFO - 2025-10-07 04:07:59 --> Helper loaded: security_helper
INFO - 2025-10-07 04:07:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:07:59 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:07:59 --> Form Validation Class Initialized
INFO - 2025-10-07 04:07:59 --> Model "User_model" initialized
INFO - 2025-10-07 09:07:59 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:07:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:07:59 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:07:59 --> Controller Class Initialized
INFO - 2025-10-07 09:07:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\kebijakan-cookies.php
INFO - 2025-10-07 09:07:59 --> Model "Log_model" initialized
INFO - 2025-10-07 09:07:59 --> Final output sent to browser
DEBUG - 2025-10-07 09:07:59 --> Total execution time: 0.2379
INFO - 2025-10-07 04:08:12 --> Config Class Initialized
INFO - 2025-10-07 04:08:12 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:08:12 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:08:12 --> Utf8 Class Initialized
INFO - 2025-10-07 04:08:12 --> URI Class Initialized
DEBUG - 2025-10-07 04:08:12 --> No URI present. Default controller set.
INFO - 2025-10-07 04:08:12 --> Router Class Initialized
INFO - 2025-10-07 04:08:12 --> Output Class Initialized
INFO - 2025-10-07 04:08:12 --> Security Class Initialized
DEBUG - 2025-10-07 04:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:08:12 --> CSRF cookie sent
INFO - 2025-10-07 04:08:12 --> Input Class Initialized
INFO - 2025-10-07 04:08:12 --> Language Class Initialized
INFO - 2025-10-07 04:08:12 --> Loader Class Initialized
INFO - 2025-10-07 04:08:12 --> Helper loaded: url_helper
INFO - 2025-10-07 04:08:12 --> Helper loaded: text_helper
INFO - 2025-10-07 04:08:12 --> Helper loaded: string_helper
INFO - 2025-10-07 04:08:12 --> Helper loaded: form_helper
INFO - 2025-10-07 04:08:12 --> Helper loaded: download_helper
INFO - 2025-10-07 04:08:12 --> Helper loaded: security_helper
INFO - 2025-10-07 04:08:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:08:12 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:08:12 --> Form Validation Class Initialized
INFO - 2025-10-07 04:08:12 --> Model "User_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:08:12 --> Controller Class Initialized
INFO - 2025-10-07 09:08:12 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Video_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:08:12 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:08:12 --> Pagination Class Initialized
INFO - 2025-10-07 09:08:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:08:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:08:12 --> Model "Log_model" initialized
INFO - 2025-10-07 09:08:13 --> Final output sent to browser
DEBUG - 2025-10-07 09:08:13 --> Total execution time: 0.2301
INFO - 2025-10-07 04:08:59 --> Config Class Initialized
INFO - 2025-10-07 04:08:59 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:08:59 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:08:59 --> Utf8 Class Initialized
INFO - 2025-10-07 04:08:59 --> URI Class Initialized
DEBUG - 2025-10-07 04:08:59 --> No URI present. Default controller set.
INFO - 2025-10-07 04:08:59 --> Router Class Initialized
INFO - 2025-10-07 04:08:59 --> Output Class Initialized
INFO - 2025-10-07 04:08:59 --> Security Class Initialized
DEBUG - 2025-10-07 04:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:08:59 --> CSRF cookie sent
INFO - 2025-10-07 04:08:59 --> Input Class Initialized
INFO - 2025-10-07 04:08:59 --> Language Class Initialized
INFO - 2025-10-07 04:08:59 --> Loader Class Initialized
INFO - 2025-10-07 04:08:59 --> Helper loaded: url_helper
INFO - 2025-10-07 04:08:59 --> Helper loaded: text_helper
INFO - 2025-10-07 04:08:59 --> Helper loaded: string_helper
INFO - 2025-10-07 04:08:59 --> Helper loaded: form_helper
INFO - 2025-10-07 04:08:59 --> Helper loaded: download_helper
INFO - 2025-10-07 04:08:59 --> Helper loaded: security_helper
INFO - 2025-10-07 04:08:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:08:59 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:08:59 --> Form Validation Class Initialized
INFO - 2025-10-07 04:08:59 --> Model "User_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:08:59 --> Controller Class Initialized
INFO - 2025-10-07 09:08:59 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Video_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:08:59 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:09:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:09:00 --> Pagination Class Initialized
INFO - 2025-10-07 09:09:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:09:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:09:00 --> Model "Log_model" initialized
INFO - 2025-10-07 09:09:00 --> Final output sent to browser
DEBUG - 2025-10-07 09:09:00 --> Total execution time: 0.2689
INFO - 2025-10-07 04:10:59 --> Config Class Initialized
INFO - 2025-10-07 04:10:59 --> Hooks Class Initialized
DEBUG - 2025-10-07 04:10:59 --> UTF-8 Support Enabled
INFO - 2025-10-07 04:10:59 --> Utf8 Class Initialized
INFO - 2025-10-07 04:10:59 --> URI Class Initialized
DEBUG - 2025-10-07 04:10:59 --> No URI present. Default controller set.
INFO - 2025-10-07 04:10:59 --> Router Class Initialized
INFO - 2025-10-07 04:10:59 --> Output Class Initialized
INFO - 2025-10-07 04:10:59 --> Security Class Initialized
DEBUG - 2025-10-07 04:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-07 04:10:59 --> CSRF cookie sent
INFO - 2025-10-07 04:10:59 --> Input Class Initialized
INFO - 2025-10-07 04:10:59 --> Language Class Initialized
INFO - 2025-10-07 04:10:59 --> Loader Class Initialized
INFO - 2025-10-07 04:10:59 --> Helper loaded: url_helper
INFO - 2025-10-07 04:10:59 --> Helper loaded: text_helper
INFO - 2025-10-07 04:10:59 --> Helper loaded: string_helper
INFO - 2025-10-07 04:10:59 --> Helper loaded: form_helper
INFO - 2025-10-07 04:10:59 --> Helper loaded: download_helper
INFO - 2025-10-07 04:10:59 --> Helper loaded: security_helper
INFO - 2025-10-07 04:10:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-07 04:10:59 --> Database Driver Class Initialized
DEBUG - 2025-10-07 04:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-07 04:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-07 04:10:59 --> Form Validation Class Initialized
INFO - 2025-10-07 04:10:59 --> Model "User_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Kunjungan_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Nav_model" initialized
INFO - 2025-10-07 09:10:59 --> Controller Class Initialized
INFO - 2025-10-07 09:10:59 --> Model "Berita_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Galeri_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Video_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Agenda_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Tautan_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Mitra_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Jurusan_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Prodi_model" initialized
INFO - 2025-10-07 09:10:59 --> Model "Testimoni_model" initialized
INFO - 2025-10-07 09:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-07 09:10:59 --> Pagination Class Initialized
INFO - 2025-10-07 09:10:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-07 09:10:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-07 09:10:59 --> Model "Log_model" initialized
INFO - 2025-10-07 09:10:59 --> Final output sent to browser
DEBUG - 2025-10-07 09:10:59 --> Total execution time: 0.2662
