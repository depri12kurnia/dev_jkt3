<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-12-22 03:36:50 --> Config Class Initialized
INFO - 2025-12-22 03:36:50 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:36:50 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:36:50 --> Utf8 Class Initialized
INFO - 2025-12-22 03:36:50 --> URI Class Initialized
DEBUG - 2025-12-22 03:36:50 --> No URI present. Default controller set.
INFO - 2025-12-22 03:36:50 --> Router Class Initialized
INFO - 2025-12-22 03:36:50 --> Output Class Initialized
INFO - 2025-12-22 03:36:50 --> Security Class Initialized
DEBUG - 2025-12-22 03:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:36:50 --> CSRF cookie sent
INFO - 2025-12-22 03:36:50 --> Input Class Initialized
INFO - 2025-12-22 03:36:50 --> Language Class Initialized
INFO - 2025-12-22 03:36:50 --> Loader Class Initialized
INFO - 2025-12-22 03:36:51 --> Helper loaded: url_helper
INFO - 2025-12-22 03:36:51 --> Helper loaded: text_helper
INFO - 2025-12-22 03:36:51 --> Helper loaded: string_helper
INFO - 2025-12-22 03:36:51 --> Helper loaded: form_helper
INFO - 2025-12-22 03:36:51 --> Helper loaded: download_helper
INFO - 2025-12-22 03:36:51 --> Helper loaded: security_helper
INFO - 2025-12-22 03:36:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:36:51 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:36:51 --> Form Validation Class Initialized
INFO - 2025-12-22 03:36:51 --> Model "User_model" initialized
INFO - 2025-12-22 09:36:51 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:36:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:36:52 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:36:52 --> Controller Class Initialized
INFO - 2025-12-22 09:36:52 --> Model "Berita_model" initialized
INFO - 2025-12-22 09:36:52 --> Model "Galeri_model" initialized
INFO - 2025-12-22 09:36:52 --> Model "Video_model" initialized
INFO - 2025-12-22 09:36:52 --> Model "Agenda_model" initialized
INFO - 2025-12-22 09:36:52 --> Model "Tautan_model" initialized
INFO - 2025-12-22 09:36:52 --> Model "Mitra_model" initialized
INFO - 2025-12-22 09:36:52 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 09:36:52 --> Model "Prodi_model" initialized
INFO - 2025-12-22 09:36:52 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 09:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-22 09:36:53 --> Pagination Class Initialized
INFO - 2025-12-22 09:36:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-22 09:36:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 09:36:56 --> Model "Log_model" initialized
INFO - 2025-12-22 09:36:56 --> Final output sent to browser
DEBUG - 2025-12-22 09:36:56 --> Total execution time: 6.3865
INFO - 2025-12-22 03:37:20 --> Config Class Initialized
INFO - 2025-12-22 03:37:20 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:37:20 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:37:20 --> Utf8 Class Initialized
INFO - 2025-12-22 03:37:20 --> URI Class Initialized
DEBUG - 2025-12-22 03:37:20 --> No URI present. Default controller set.
INFO - 2025-12-22 03:37:20 --> Router Class Initialized
INFO - 2025-12-22 03:37:20 --> Output Class Initialized
INFO - 2025-12-22 03:37:20 --> Security Class Initialized
DEBUG - 2025-12-22 03:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:37:21 --> CSRF cookie sent
INFO - 2025-12-22 03:37:21 --> Input Class Initialized
INFO - 2025-12-22 03:37:21 --> Language Class Initialized
INFO - 2025-12-22 03:37:21 --> Loader Class Initialized
INFO - 2025-12-22 03:37:21 --> Helper loaded: url_helper
INFO - 2025-12-22 03:37:21 --> Helper loaded: text_helper
INFO - 2025-12-22 03:37:21 --> Helper loaded: string_helper
INFO - 2025-12-22 03:37:21 --> Helper loaded: form_helper
INFO - 2025-12-22 03:37:21 --> Helper loaded: download_helper
INFO - 2025-12-22 03:37:21 --> Helper loaded: security_helper
INFO - 2025-12-22 03:37:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:37:21 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:37:21 --> Form Validation Class Initialized
INFO - 2025-12-22 03:37:21 --> Model "User_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:37:21 --> Controller Class Initialized
INFO - 2025-12-22 09:37:21 --> Model "Berita_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Galeri_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Video_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Agenda_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Tautan_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Mitra_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Prodi_model" initialized
INFO - 2025-12-22 09:37:21 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 09:37:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-22 09:37:21 --> Pagination Class Initialized
INFO - 2025-12-22 09:37:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-22 09:37:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 09:37:21 --> Model "Log_model" initialized
INFO - 2025-12-22 09:37:21 --> Final output sent to browser
DEBUG - 2025-12-22 09:37:21 --> Total execution time: 0.1830
INFO - 2025-12-22 03:37:49 --> Config Class Initialized
INFO - 2025-12-22 03:37:49 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:37:49 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:37:49 --> Utf8 Class Initialized
INFO - 2025-12-22 03:37:49 --> URI Class Initialized
DEBUG - 2025-12-22 03:37:49 --> No URI present. Default controller set.
INFO - 2025-12-22 03:37:49 --> Router Class Initialized
INFO - 2025-12-22 03:37:49 --> Output Class Initialized
INFO - 2025-12-22 03:37:49 --> Security Class Initialized
DEBUG - 2025-12-22 03:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:37:49 --> CSRF cookie sent
INFO - 2025-12-22 03:37:49 --> Input Class Initialized
INFO - 2025-12-22 03:37:49 --> Language Class Initialized
INFO - 2025-12-22 03:37:49 --> Loader Class Initialized
INFO - 2025-12-22 03:37:49 --> Helper loaded: url_helper
INFO - 2025-12-22 03:37:49 --> Helper loaded: text_helper
INFO - 2025-12-22 03:37:49 --> Helper loaded: string_helper
INFO - 2025-12-22 03:37:49 --> Helper loaded: form_helper
INFO - 2025-12-22 03:37:49 --> Helper loaded: download_helper
INFO - 2025-12-22 03:37:49 --> Helper loaded: security_helper
INFO - 2025-12-22 03:37:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:37:49 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:37:50 --> Form Validation Class Initialized
INFO - 2025-12-22 03:37:50 --> Model "User_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:37:50 --> Controller Class Initialized
INFO - 2025-12-22 09:37:50 --> Model "Berita_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Galeri_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Video_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Agenda_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Tautan_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Mitra_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Prodi_model" initialized
INFO - 2025-12-22 09:37:50 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 09:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-22 09:37:50 --> Pagination Class Initialized
INFO - 2025-12-22 09:37:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-22 09:37:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 09:37:50 --> Model "Log_model" initialized
INFO - 2025-12-22 09:37:50 --> Final output sent to browser
DEBUG - 2025-12-22 09:37:50 --> Total execution time: 0.1559
INFO - 2025-12-22 03:37:54 --> Config Class Initialized
INFO - 2025-12-22 03:37:54 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:37:54 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:37:54 --> Utf8 Class Initialized
INFO - 2025-12-22 03:37:54 --> URI Class Initialized
INFO - 2025-12-22 03:37:54 --> Router Class Initialized
INFO - 2025-12-22 03:37:54 --> Output Class Initialized
INFO - 2025-12-22 03:37:54 --> Security Class Initialized
DEBUG - 2025-12-22 03:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:37:54 --> CSRF cookie sent
INFO - 2025-12-22 03:37:54 --> Input Class Initialized
INFO - 2025-12-22 03:37:54 --> Language Class Initialized
INFO - 2025-12-22 03:37:54 --> Loader Class Initialized
INFO - 2025-12-22 03:37:54 --> Helper loaded: url_helper
INFO - 2025-12-22 03:37:54 --> Helper loaded: text_helper
INFO - 2025-12-22 03:37:54 --> Helper loaded: string_helper
INFO - 2025-12-22 03:37:54 --> Helper loaded: form_helper
INFO - 2025-12-22 03:37:54 --> Helper loaded: download_helper
INFO - 2025-12-22 03:37:54 --> Helper loaded: security_helper
INFO - 2025-12-22 03:37:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:37:54 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:37:54 --> Form Validation Class Initialized
INFO - 2025-12-22 03:37:54 --> Model "User_model" initialized
INFO - 2025-12-22 09:37:54 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:37:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:37:54 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:37:54 --> Controller Class Initialized
INFO - 2025-12-22 09:37:54 --> Model "Pages_model" initialized
INFO - 2025-12-22 09:37:54 --> Model "Berita_model" initialized
INFO - 2025-12-22 09:37:54 --> Model "Download_model" initialized
INFO - 2025-12-22 09:37:54 --> Model "Kategori_download_model" initialized
INFO - 2025-12-22 09:37:54 --> Model "Jenis_download_model" initialized
INFO - 2025-12-22 09:37:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-12-22 09:37:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 09:37:54 --> Model "Log_model" initialized
INFO - 2025-12-22 09:37:54 --> Final output sent to browser
DEBUG - 2025-12-22 09:37:54 --> Total execution time: 0.4854
INFO - 2025-12-22 03:38:06 --> Config Class Initialized
INFO - 2025-12-22 03:38:06 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:38:06 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:38:06 --> Utf8 Class Initialized
INFO - 2025-12-22 03:38:06 --> URI Class Initialized
INFO - 2025-12-22 03:38:06 --> Router Class Initialized
INFO - 2025-12-22 03:38:06 --> Output Class Initialized
INFO - 2025-12-22 03:38:06 --> Security Class Initialized
DEBUG - 2025-12-22 03:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:38:06 --> CSRF cookie sent
INFO - 2025-12-22 03:38:06 --> Input Class Initialized
INFO - 2025-12-22 03:38:06 --> Language Class Initialized
INFO - 2025-12-22 03:38:06 --> Loader Class Initialized
INFO - 2025-12-22 03:38:06 --> Helper loaded: url_helper
INFO - 2025-12-22 03:38:06 --> Helper loaded: text_helper
INFO - 2025-12-22 03:38:06 --> Helper loaded: string_helper
INFO - 2025-12-22 03:38:06 --> Helper loaded: form_helper
INFO - 2025-12-22 03:38:06 --> Helper loaded: download_helper
INFO - 2025-12-22 03:38:06 --> Helper loaded: security_helper
INFO - 2025-12-22 03:38:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:38:06 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:38:06 --> Form Validation Class Initialized
INFO - 2025-12-22 03:38:06 --> Model "User_model" initialized
INFO - 2025-12-22 09:38:06 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:38:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:38:06 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:38:06 --> Controller Class Initialized
INFO - 2025-12-22 09:38:06 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 09:38:06 --> Model "Prodi_model" initialized
INFO - 2025-12-22 09:38:06 --> Model "Sdm_model" initialized
INFO - 2025-12-22 09:38:06 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-12-22 09:38:06 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2025-12-22 09:38:07 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-22 09:38:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-22 09:38:07 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2025-12-22 09:38:07 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2025-12-22 09:38:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-12-22 09:38:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 09:38:07 --> Model "Log_model" initialized
INFO - 2025-12-22 09:38:07 --> Final output sent to browser
DEBUG - 2025-12-22 09:38:07 --> Total execution time: 1.1775
INFO - 2025-12-22 03:38:33 --> Config Class Initialized
INFO - 2025-12-22 03:38:33 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:38:33 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:38:33 --> Utf8 Class Initialized
INFO - 2025-12-22 03:38:33 --> URI Class Initialized
INFO - 2025-12-22 03:38:33 --> Router Class Initialized
INFO - 2025-12-22 03:38:33 --> Output Class Initialized
INFO - 2025-12-22 03:38:33 --> Security Class Initialized
DEBUG - 2025-12-22 03:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:38:33 --> CSRF cookie sent
INFO - 2025-12-22 03:38:33 --> Input Class Initialized
INFO - 2025-12-22 03:38:33 --> Language Class Initialized
INFO - 2025-12-22 03:38:33 --> Loader Class Initialized
INFO - 2025-12-22 03:38:33 --> Helper loaded: url_helper
INFO - 2025-12-22 03:38:33 --> Helper loaded: text_helper
INFO - 2025-12-22 03:38:33 --> Helper loaded: string_helper
INFO - 2025-12-22 03:38:33 --> Helper loaded: form_helper
INFO - 2025-12-22 03:38:33 --> Helper loaded: download_helper
INFO - 2025-12-22 03:38:33 --> Helper loaded: security_helper
INFO - 2025-12-22 03:38:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:38:33 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:38:33 --> Form Validation Class Initialized
INFO - 2025-12-22 03:38:33 --> Model "User_model" initialized
INFO - 2025-12-22 09:38:33 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:38:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:38:33 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:38:33 --> Controller Class Initialized
DEBUG - 2025-12-22 09:38:33 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-22 09:38:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-12-22 09:38:33 --> Model "Log_model" initialized
INFO - 2025-12-22 09:38:33 --> Final output sent to browser
DEBUG - 2025-12-22 09:38:33 --> Total execution time: 0.4129
INFO - 2025-12-22 03:38:40 --> Config Class Initialized
INFO - 2025-12-22 03:38:40 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:38:40 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:38:40 --> Utf8 Class Initialized
INFO - 2025-12-22 03:38:40 --> URI Class Initialized
INFO - 2025-12-22 03:38:40 --> Router Class Initialized
INFO - 2025-12-22 03:38:40 --> Output Class Initialized
INFO - 2025-12-22 03:38:40 --> Security Class Initialized
DEBUG - 2025-12-22 03:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:38:40 --> CSRF cookie sent
INFO - 2025-12-22 03:38:40 --> CSRF token verified
INFO - 2025-12-22 03:38:40 --> Input Class Initialized
INFO - 2025-12-22 03:38:40 --> Language Class Initialized
INFO - 2025-12-22 03:38:40 --> Loader Class Initialized
INFO - 2025-12-22 03:38:40 --> Helper loaded: url_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: text_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: string_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: form_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: download_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: security_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:38:40 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:38:40 --> Form Validation Class Initialized
INFO - 2025-12-22 03:38:40 --> Model "User_model" initialized
INFO - 2025-12-22 09:38:40 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:38:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:38:40 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:38:40 --> Controller Class Initialized
DEBUG - 2025-12-22 09:38:40 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-22 09:38:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-22 03:38:40 --> Config Class Initialized
INFO - 2025-12-22 03:38:40 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:38:40 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:38:40 --> Utf8 Class Initialized
INFO - 2025-12-22 03:38:40 --> URI Class Initialized
INFO - 2025-12-22 03:38:40 --> Router Class Initialized
INFO - 2025-12-22 03:38:40 --> Output Class Initialized
INFO - 2025-12-22 03:38:40 --> Security Class Initialized
DEBUG - 2025-12-22 03:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:38:40 --> CSRF cookie sent
INFO - 2025-12-22 03:38:40 --> Input Class Initialized
INFO - 2025-12-22 03:38:40 --> Language Class Initialized
INFO - 2025-12-22 03:38:40 --> Loader Class Initialized
INFO - 2025-12-22 03:38:40 --> Helper loaded: url_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: text_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: string_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: form_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: download_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: security_helper
INFO - 2025-12-22 03:38:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:38:40 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:38:40 --> Form Validation Class Initialized
INFO - 2025-12-22 03:38:40 --> Model "User_model" initialized
INFO - 2025-12-22 09:38:40 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:38:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:38:40 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:38:40 --> Controller Class Initialized
INFO - 2025-12-22 09:38:40 --> Model "Tautan_model" initialized
INFO - 2025-12-22 09:38:40 --> Model "Staff_model" initialized
INFO - 2025-12-22 09:38:41 --> Model "Dasbor_model" initialized
INFO - 2025-12-22 09:38:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-12-22 09:38:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 09:38:44 --> Model "Log_model" initialized
INFO - 2025-12-22 09:38:44 --> Final output sent to browser
DEBUG - 2025-12-22 09:38:44 --> Total execution time: 3.6373
INFO - 2025-12-22 03:38:58 --> Config Class Initialized
INFO - 2025-12-22 03:38:58 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:38:59 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:38:59 --> Utf8 Class Initialized
INFO - 2025-12-22 03:38:59 --> URI Class Initialized
INFO - 2025-12-22 03:38:59 --> Router Class Initialized
INFO - 2025-12-22 03:38:59 --> Output Class Initialized
INFO - 2025-12-22 03:38:59 --> Security Class Initialized
DEBUG - 2025-12-22 03:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:38:59 --> CSRF cookie sent
INFO - 2025-12-22 03:38:59 --> Input Class Initialized
INFO - 2025-12-22 03:38:59 --> Language Class Initialized
INFO - 2025-12-22 03:38:59 --> Loader Class Initialized
INFO - 2025-12-22 03:38:59 --> Helper loaded: url_helper
INFO - 2025-12-22 03:38:59 --> Helper loaded: text_helper
INFO - 2025-12-22 03:38:59 --> Helper loaded: string_helper
INFO - 2025-12-22 03:38:59 --> Helper loaded: form_helper
INFO - 2025-12-22 03:38:59 --> Helper loaded: download_helper
INFO - 2025-12-22 03:38:59 --> Helper loaded: security_helper
INFO - 2025-12-22 03:38:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:38:59 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:38:59 --> Form Validation Class Initialized
INFO - 2025-12-22 03:38:59 --> Model "User_model" initialized
INFO - 2025-12-22 09:38:59 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:38:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:38:59 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:38:59 --> Controller Class Initialized
INFO - 2025-12-22 09:38:59 --> Model "Agenda_model" initialized
INFO - 2025-12-22 09:38:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/agenda/list.php
INFO - 2025-12-22 09:38:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 09:38:59 --> Model "Log_model" initialized
INFO - 2025-12-22 09:38:59 --> Final output sent to browser
DEBUG - 2025-12-22 09:38:59 --> Total execution time: 0.3612
INFO - 2025-12-22 03:39:03 --> Config Class Initialized
INFO - 2025-12-22 03:39:03 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:39:03 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:39:03 --> Utf8 Class Initialized
INFO - 2025-12-22 03:39:03 --> URI Class Initialized
INFO - 2025-12-22 03:39:03 --> Router Class Initialized
INFO - 2025-12-22 03:39:03 --> Output Class Initialized
INFO - 2025-12-22 03:39:03 --> Security Class Initialized
DEBUG - 2025-12-22 03:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:39:03 --> CSRF cookie sent
INFO - 2025-12-22 03:39:03 --> Input Class Initialized
INFO - 2025-12-22 03:39:03 --> Language Class Initialized
INFO - 2025-12-22 03:39:03 --> Loader Class Initialized
INFO - 2025-12-22 03:39:03 --> Helper loaded: url_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: text_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: string_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: form_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: download_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: security_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:39:03 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:39:03 --> Form Validation Class Initialized
INFO - 2025-12-22 03:39:03 --> Model "User_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:39:03 --> Controller Class Initialized
INFO - 2025-12-22 09:39:03 --> Model "Pages_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Download_model" initialized
INFO - 2025-12-22 09:39:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pages/list.php
INFO - 2025-12-22 09:39:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 09:39:03 --> Model "Log_model" initialized
INFO - 2025-12-22 09:39:03 --> Final output sent to browser
DEBUG - 2025-12-22 09:39:03 --> Total execution time: 0.3996
INFO - 2025-12-22 03:39:03 --> Config Class Initialized
INFO - 2025-12-22 03:39:03 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:39:03 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:39:03 --> Utf8 Class Initialized
INFO - 2025-12-22 03:39:03 --> URI Class Initialized
INFO - 2025-12-22 03:39:03 --> Router Class Initialized
INFO - 2025-12-22 03:39:03 --> Output Class Initialized
INFO - 2025-12-22 03:39:03 --> Security Class Initialized
DEBUG - 2025-12-22 03:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:39:03 --> CSRF cookie sent
INFO - 2025-12-22 03:39:03 --> Input Class Initialized
INFO - 2025-12-22 03:39:03 --> Language Class Initialized
INFO - 2025-12-22 03:39:03 --> Loader Class Initialized
INFO - 2025-12-22 03:39:03 --> Helper loaded: url_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: text_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: string_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: form_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: download_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: security_helper
INFO - 2025-12-22 03:39:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:39:03 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:39:03 --> Form Validation Class Initialized
INFO - 2025-12-22 03:39:03 --> Model "User_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:39:03 --> Controller Class Initialized
INFO - 2025-12-22 09:39:03 --> Model "Berita_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Galeri_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Video_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Agenda_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Tautan_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Mitra_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Prodi_model" initialized
INFO - 2025-12-22 09:39:03 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 09:39:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-12-22 09:39:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 09:39:03 --> Model "Log_model" initialized
INFO - 2025-12-22 09:39:03 --> Final output sent to browser
DEBUG - 2025-12-22 09:39:03 --> Total execution time: 0.1239
INFO - 2025-12-22 03:39:09 --> Config Class Initialized
INFO - 2025-12-22 03:39:09 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:39:09 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:39:09 --> Utf8 Class Initialized
INFO - 2025-12-22 03:39:09 --> URI Class Initialized
INFO - 2025-12-22 03:39:09 --> Router Class Initialized
INFO - 2025-12-22 03:39:09 --> Output Class Initialized
INFO - 2025-12-22 03:39:09 --> Security Class Initialized
DEBUG - 2025-12-22 03:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:39:09 --> CSRF cookie sent
INFO - 2025-12-22 03:39:09 --> Input Class Initialized
INFO - 2025-12-22 03:39:09 --> Language Class Initialized
INFO - 2025-12-22 03:39:09 --> Loader Class Initialized
INFO - 2025-12-22 03:39:09 --> Helper loaded: url_helper
INFO - 2025-12-22 03:39:09 --> Helper loaded: text_helper
INFO - 2025-12-22 03:39:09 --> Helper loaded: string_helper
INFO - 2025-12-22 03:39:09 --> Helper loaded: form_helper
INFO - 2025-12-22 03:39:09 --> Helper loaded: download_helper
INFO - 2025-12-22 03:39:09 --> Helper loaded: security_helper
INFO - 2025-12-22 03:39:09 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:39:09 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:39:09 --> Form Validation Class Initialized
INFO - 2025-12-22 03:39:09 --> Model "User_model" initialized
INFO - 2025-12-22 09:39:09 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:39:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:39:09 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:39:09 --> Controller Class Initialized
INFO - 2025-12-22 03:39:17 --> Config Class Initialized
INFO - 2025-12-22 03:39:17 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:39:17 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:39:17 --> Utf8 Class Initialized
INFO - 2025-12-22 03:39:17 --> URI Class Initialized
INFO - 2025-12-22 03:39:17 --> Router Class Initialized
INFO - 2025-12-22 03:39:17 --> Output Class Initialized
INFO - 2025-12-22 03:39:17 --> Security Class Initialized
DEBUG - 2025-12-22 03:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:39:17 --> CSRF cookie sent
INFO - 2025-12-22 03:39:17 --> Input Class Initialized
INFO - 2025-12-22 03:39:17 --> Language Class Initialized
INFO - 2025-12-22 03:39:17 --> Loader Class Initialized
INFO - 2025-12-22 03:39:17 --> Helper loaded: url_helper
INFO - 2025-12-22 03:39:17 --> Helper loaded: text_helper
INFO - 2025-12-22 03:39:17 --> Helper loaded: string_helper
INFO - 2025-12-22 03:39:17 --> Helper loaded: form_helper
INFO - 2025-12-22 03:39:17 --> Helper loaded: download_helper
INFO - 2025-12-22 03:39:17 --> Helper loaded: security_helper
INFO - 2025-12-22 03:39:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:39:17 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:39:19 --> Config Class Initialized
INFO - 2025-12-22 03:39:19 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:39:19 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:39:19 --> Utf8 Class Initialized
INFO - 2025-12-22 03:39:19 --> URI Class Initialized
INFO - 2025-12-22 03:39:19 --> Router Class Initialized
INFO - 2025-12-22 03:39:19 --> Output Class Initialized
INFO - 2025-12-22 03:39:19 --> Security Class Initialized
DEBUG - 2025-12-22 03:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:39:19 --> CSRF cookie sent
INFO - 2025-12-22 03:39:19 --> Input Class Initialized
INFO - 2025-12-22 03:39:19 --> Language Class Initialized
INFO - 2025-12-22 03:39:19 --> Loader Class Initialized
INFO - 2025-12-22 03:39:19 --> Helper loaded: url_helper
INFO - 2025-12-22 03:39:19 --> Helper loaded: text_helper
INFO - 2025-12-22 03:39:19 --> Helper loaded: string_helper
INFO - 2025-12-22 03:39:19 --> Helper loaded: form_helper
INFO - 2025-12-22 03:39:19 --> Helper loaded: download_helper
INFO - 2025-12-22 03:39:19 --> Helper loaded: security_helper
INFO - 2025-12-22 03:39:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:39:19 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2025-12-22 09:39:31 --> SEAFILE API [GET http://192.168.11.105/api2//repos/] => HTTP 0
ERROR - 2025-12-22 09:39:31 --> RESPONSE: 
ERROR - 2025-12-22 09:39:31 --> SEAFILE LIST LIBRARIES RESPONSE: Array
(
    [error] => Failed to connect to 192.168.11.105 port 80: Timed out
)

INFO - 2025-12-22 09:39:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/seafile/list.php
INFO - 2025-12-22 09:39:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 09:39:31 --> Model "Log_model" initialized
INFO - 2025-12-22 09:39:31 --> Final output sent to browser
DEBUG - 2025-12-22 09:39:31 --> Total execution time: 21.5919
INFO - 2025-12-22 03:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:39:31 --> Form Validation Class Initialized
INFO - 2025-12-22 03:39:31 --> Model "User_model" initialized
INFO - 2025-12-22 09:39:31 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:39:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:39:31 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:39:31 --> Controller Class Initialized
INFO - 2025-12-22 09:39:31 --> Model "Log_model" initialized
INFO - 2025-12-22 09:39:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 09:39:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 09:39:31 --> Model "Log_model" initialized
INFO - 2025-12-22 09:39:31 --> Final output sent to browser
DEBUG - 2025-12-22 09:39:31 --> Total execution time: 13.5794
INFO - 2025-12-22 03:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:39:31 --> Form Validation Class Initialized
INFO - 2025-12-22 03:39:31 --> Model "User_model" initialized
INFO - 2025-12-22 09:39:31 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:39:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:39:31 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:39:31 --> Controller Class Initialized
INFO - 2025-12-22 09:39:31 --> Model "Log_model" initialized
INFO - 2025-12-22 09:39:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/activity.php
INFO - 2025-12-22 09:39:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 09:39:31 --> Model "Log_model" initialized
INFO - 2025-12-22 09:39:31 --> Final output sent to browser
DEBUG - 2025-12-22 09:39:31 --> Total execution time: 11.8754
INFO - 2025-12-22 03:39:31 --> Config Class Initialized
INFO - 2025-12-22 03:39:31 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:39:31 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:39:31 --> Utf8 Class Initialized
INFO - 2025-12-22 03:39:31 --> URI Class Initialized
INFO - 2025-12-22 03:39:31 --> Router Class Initialized
INFO - 2025-12-22 03:39:31 --> Output Class Initialized
INFO - 2025-12-22 03:39:31 --> Security Class Initialized
DEBUG - 2025-12-22 03:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:39:31 --> CSRF cookie sent
INFO - 2025-12-22 03:39:31 --> CSRF token verified
INFO - 2025-12-22 03:39:31 --> Input Class Initialized
INFO - 2025-12-22 03:39:31 --> Language Class Initialized
INFO - 2025-12-22 03:39:31 --> Loader Class Initialized
INFO - 2025-12-22 03:39:31 --> Helper loaded: url_helper
INFO - 2025-12-22 03:39:31 --> Helper loaded: text_helper
INFO - 2025-12-22 03:39:31 --> Helper loaded: string_helper
INFO - 2025-12-22 03:39:31 --> Helper loaded: form_helper
INFO - 2025-12-22 03:39:31 --> Helper loaded: download_helper
INFO - 2025-12-22 03:39:31 --> Helper loaded: security_helper
INFO - 2025-12-22 03:39:31 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:39:31 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:39:31 --> Form Validation Class Initialized
INFO - 2025-12-22 03:39:31 --> Model "User_model" initialized
INFO - 2025-12-22 09:39:31 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:39:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:39:31 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:39:31 --> Controller Class Initialized
INFO - 2025-12-22 09:39:31 --> Model "Log_model" initialized
DEBUG - 2025-12-22 09:39:31 --> CSRF Token dari request POST: TIDAK ADA
DEBUG - 2025-12-22 09:39:31 --> CSRF Token yang valid: 56966e48d20b930ac739f09032d30a9c
DEBUG - 2025-12-22 09:39:31 --> Session CSRF Token: 
ERROR - 2025-12-22 09:39:31 --> CSRF Token kosong, periksa apakah dikirim dari frontend.
INFO - 2025-12-22 03:58:18 --> Config Class Initialized
INFO - 2025-12-22 03:58:18 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:58:18 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:58:18 --> Utf8 Class Initialized
INFO - 2025-12-22 03:58:18 --> URI Class Initialized
INFO - 2025-12-22 03:58:18 --> Router Class Initialized
INFO - 2025-12-22 03:58:18 --> Output Class Initialized
INFO - 2025-12-22 03:58:18 --> Security Class Initialized
DEBUG - 2025-12-22 03:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:58:18 --> CSRF cookie sent
INFO - 2025-12-22 03:58:18 --> Input Class Initialized
INFO - 2025-12-22 03:58:18 --> Language Class Initialized
INFO - 2025-12-22 03:58:18 --> Loader Class Initialized
INFO - 2025-12-22 03:58:18 --> Helper loaded: url_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: text_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: string_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: form_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: download_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: security_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:58:18 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:58:18 --> Form Validation Class Initialized
INFO - 2025-12-22 03:58:18 --> Model "User_model" initialized
INFO - 2025-12-22 09:58:18 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:58:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:58:18 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:58:18 --> Controller Class Initialized
INFO - 2025-12-22 09:58:18 --> Model "Log_model" initialized
INFO - 2025-12-22 09:58:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 09:58:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 09:58:18 --> Model "Log_model" initialized
INFO - 2025-12-22 09:58:18 --> Final output sent to browser
DEBUG - 2025-12-22 09:58:18 --> Total execution time: 0.1614
INFO - 2025-12-22 03:58:18 --> Config Class Initialized
INFO - 2025-12-22 03:58:18 --> Hooks Class Initialized
DEBUG - 2025-12-22 03:58:18 --> UTF-8 Support Enabled
INFO - 2025-12-22 03:58:18 --> Utf8 Class Initialized
INFO - 2025-12-22 03:58:18 --> URI Class Initialized
INFO - 2025-12-22 03:58:18 --> Router Class Initialized
INFO - 2025-12-22 03:58:18 --> Output Class Initialized
INFO - 2025-12-22 03:58:18 --> Security Class Initialized
DEBUG - 2025-12-22 03:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 03:58:18 --> CSRF cookie sent
INFO - 2025-12-22 03:58:18 --> CSRF token verified
INFO - 2025-12-22 03:58:18 --> Input Class Initialized
INFO - 2025-12-22 03:58:18 --> Language Class Initialized
INFO - 2025-12-22 03:58:18 --> Loader Class Initialized
INFO - 2025-12-22 03:58:18 --> Helper loaded: url_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: text_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: string_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: form_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: download_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: security_helper
INFO - 2025-12-22 03:58:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 03:58:18 --> Database Driver Class Initialized
DEBUG - 2025-12-22 03:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 03:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 03:58:18 --> Form Validation Class Initialized
INFO - 2025-12-22 03:58:18 --> Model "User_model" initialized
INFO - 2025-12-22 09:58:18 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 09:58:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 09:58:18 --> Model "Nav_model" initialized
INFO - 2025-12-22 09:58:18 --> Controller Class Initialized
INFO - 2025-12-22 09:58:18 --> Model "Log_model" initialized
INFO - 2025-12-22 09:58:19 --> Model "Log_model" initialized
INFO - 2025-12-22 09:58:19 --> Final output sent to browser
DEBUG - 2025-12-22 09:58:19 --> Total execution time: 1.2493
INFO - 2025-12-22 04:01:14 --> Config Class Initialized
INFO - 2025-12-22 04:01:14 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:01:14 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:01:14 --> Utf8 Class Initialized
INFO - 2025-12-22 04:01:14 --> URI Class Initialized
INFO - 2025-12-22 04:01:14 --> Router Class Initialized
INFO - 2025-12-22 04:01:14 --> Output Class Initialized
INFO - 2025-12-22 04:01:14 --> Security Class Initialized
DEBUG - 2025-12-22 04:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:01:14 --> CSRF cookie sent
INFO - 2025-12-22 04:01:14 --> Input Class Initialized
INFO - 2025-12-22 04:01:14 --> Language Class Initialized
INFO - 2025-12-22 04:01:14 --> Loader Class Initialized
INFO - 2025-12-22 04:01:14 --> Helper loaded: url_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: text_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: string_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: form_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: download_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: security_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:01:14 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:01:14 --> Form Validation Class Initialized
INFO - 2025-12-22 04:01:14 --> Model "User_model" initialized
INFO - 2025-12-22 10:01:14 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:01:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:01:14 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:01:14 --> Controller Class Initialized
INFO - 2025-12-22 10:01:14 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:01:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:01:14 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:14 --> Final output sent to browser
DEBUG - 2025-12-22 10:01:14 --> Total execution time: 0.1712
INFO - 2025-12-22 04:01:14 --> Config Class Initialized
INFO - 2025-12-22 04:01:14 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:01:14 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:01:14 --> Utf8 Class Initialized
INFO - 2025-12-22 04:01:14 --> URI Class Initialized
INFO - 2025-12-22 04:01:14 --> Router Class Initialized
INFO - 2025-12-22 04:01:14 --> Output Class Initialized
INFO - 2025-12-22 04:01:14 --> Security Class Initialized
DEBUG - 2025-12-22 04:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:01:14 --> CSRF cookie sent
INFO - 2025-12-22 04:01:14 --> CSRF token verified
INFO - 2025-12-22 04:01:14 --> Input Class Initialized
INFO - 2025-12-22 04:01:14 --> Language Class Initialized
INFO - 2025-12-22 04:01:14 --> Loader Class Initialized
INFO - 2025-12-22 04:01:14 --> Helper loaded: url_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: text_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: string_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: form_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: download_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: security_helper
INFO - 2025-12-22 04:01:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:01:14 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:01:14 --> Form Validation Class Initialized
INFO - 2025-12-22 04:01:14 --> Model "User_model" initialized
INFO - 2025-12-22 10:01:14 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:01:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:01:14 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:01:14 --> Controller Class Initialized
INFO - 2025-12-22 10:01:14 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:15 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:15 --> Final output sent to browser
DEBUG - 2025-12-22 10:01:15 --> Total execution time: 0.7317
INFO - 2025-12-22 04:01:21 --> Config Class Initialized
INFO - 2025-12-22 04:01:21 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:01:21 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:01:21 --> Utf8 Class Initialized
INFO - 2025-12-22 04:01:21 --> URI Class Initialized
INFO - 2025-12-22 04:01:21 --> Router Class Initialized
INFO - 2025-12-22 04:01:21 --> Output Class Initialized
INFO - 2025-12-22 04:01:21 --> Security Class Initialized
DEBUG - 2025-12-22 04:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:01:21 --> CSRF cookie sent
INFO - 2025-12-22 04:01:21 --> Input Class Initialized
INFO - 2025-12-22 04:01:21 --> Language Class Initialized
INFO - 2025-12-22 04:01:21 --> Loader Class Initialized
INFO - 2025-12-22 04:01:21 --> Helper loaded: url_helper
INFO - 2025-12-22 04:01:21 --> Helper loaded: text_helper
INFO - 2025-12-22 04:01:21 --> Helper loaded: string_helper
INFO - 2025-12-22 04:01:21 --> Helper loaded: form_helper
INFO - 2025-12-22 04:01:21 --> Helper loaded: download_helper
INFO - 2025-12-22 04:01:21 --> Helper loaded: security_helper
INFO - 2025-12-22 04:01:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:01:21 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:01:21 --> Form Validation Class Initialized
INFO - 2025-12-22 04:01:21 --> Model "User_model" initialized
INFO - 2025-12-22 10:01:21 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:01:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:01:21 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:01:21 --> Controller Class Initialized
INFO - 2025-12-22 10:01:21 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/activity.php
INFO - 2025-12-22 10:01:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:01:21 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:21 --> Final output sent to browser
DEBUG - 2025-12-22 10:01:21 --> Total execution time: 0.1325
INFO - 2025-12-22 04:01:22 --> Config Class Initialized
INFO - 2025-12-22 04:01:22 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:01:22 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:01:22 --> Utf8 Class Initialized
INFO - 2025-12-22 04:01:22 --> URI Class Initialized
INFO - 2025-12-22 04:01:22 --> Router Class Initialized
INFO - 2025-12-22 04:01:22 --> Output Class Initialized
INFO - 2025-12-22 04:01:22 --> Security Class Initialized
DEBUG - 2025-12-22 04:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:01:22 --> CSRF cookie sent
INFO - 2025-12-22 04:01:22 --> CSRF token verified
INFO - 2025-12-22 04:01:22 --> Input Class Initialized
INFO - 2025-12-22 04:01:22 --> Language Class Initialized
INFO - 2025-12-22 04:01:22 --> Loader Class Initialized
INFO - 2025-12-22 04:01:22 --> Helper loaded: url_helper
INFO - 2025-12-22 04:01:22 --> Helper loaded: text_helper
INFO - 2025-12-22 04:01:22 --> Helper loaded: string_helper
INFO - 2025-12-22 04:01:22 --> Helper loaded: form_helper
INFO - 2025-12-22 04:01:22 --> Helper loaded: download_helper
INFO - 2025-12-22 04:01:22 --> Helper loaded: security_helper
INFO - 2025-12-22 04:01:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:01:22 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:01:22 --> Form Validation Class Initialized
INFO - 2025-12-22 04:01:22 --> Model "User_model" initialized
INFO - 2025-12-22 10:01:22 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:01:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:01:22 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:01:22 --> Controller Class Initialized
INFO - 2025-12-22 10:01:22 --> Model "Log_model" initialized
DEBUG - 2025-12-22 10:01:22 --> CSRF Token dari request POST: TIDAK ADA
DEBUG - 2025-12-22 10:01:22 --> CSRF Token yang valid: 56966e48d20b930ac739f09032d30a9c
DEBUG - 2025-12-22 10:01:22 --> Session CSRF Token: 
ERROR - 2025-12-22 10:01:22 --> CSRF Token kosong, periksa apakah dikirim dari frontend.
INFO - 2025-12-22 04:01:26 --> Config Class Initialized
INFO - 2025-12-22 04:01:26 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:01:26 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:01:26 --> Utf8 Class Initialized
INFO - 2025-12-22 04:01:26 --> URI Class Initialized
INFO - 2025-12-22 04:01:26 --> Router Class Initialized
INFO - 2025-12-22 04:01:26 --> Output Class Initialized
INFO - 2025-12-22 04:01:26 --> Security Class Initialized
DEBUG - 2025-12-22 04:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:01:26 --> CSRF cookie sent
INFO - 2025-12-22 04:01:26 --> Input Class Initialized
INFO - 2025-12-22 04:01:26 --> Language Class Initialized
INFO - 2025-12-22 04:01:26 --> Loader Class Initialized
INFO - 2025-12-22 04:01:26 --> Helper loaded: url_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: text_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: string_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: form_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: download_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: security_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:01:26 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:01:26 --> Form Validation Class Initialized
INFO - 2025-12-22 04:01:26 --> Model "User_model" initialized
INFO - 2025-12-22 10:01:26 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:01:26 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:01:26 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:01:26 --> Controller Class Initialized
INFO - 2025-12-22 10:01:26 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:01:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:01:26 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:26 --> Final output sent to browser
DEBUG - 2025-12-22 10:01:26 --> Total execution time: 0.1063
INFO - 2025-12-22 04:01:26 --> Config Class Initialized
INFO - 2025-12-22 04:01:26 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:01:26 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:01:26 --> Utf8 Class Initialized
INFO - 2025-12-22 04:01:26 --> URI Class Initialized
INFO - 2025-12-22 04:01:26 --> Router Class Initialized
INFO - 2025-12-22 04:01:26 --> Output Class Initialized
INFO - 2025-12-22 04:01:26 --> Security Class Initialized
DEBUG - 2025-12-22 04:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:01:26 --> CSRF cookie sent
INFO - 2025-12-22 04:01:26 --> CSRF token verified
INFO - 2025-12-22 04:01:26 --> Input Class Initialized
INFO - 2025-12-22 04:01:26 --> Language Class Initialized
INFO - 2025-12-22 04:01:26 --> Loader Class Initialized
INFO - 2025-12-22 04:01:26 --> Helper loaded: url_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: text_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: string_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: form_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: download_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: security_helper
INFO - 2025-12-22 04:01:26 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:01:26 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:01:26 --> Form Validation Class Initialized
INFO - 2025-12-22 04:01:26 --> Model "User_model" initialized
INFO - 2025-12-22 10:01:26 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:01:26 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:01:26 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:01:26 --> Controller Class Initialized
INFO - 2025-12-22 10:01:26 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:26 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:26 --> Final output sent to browser
DEBUG - 2025-12-22 10:01:26 --> Total execution time: 0.4144
INFO - 2025-12-22 04:01:38 --> Config Class Initialized
INFO - 2025-12-22 04:01:38 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:01:38 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:01:38 --> Utf8 Class Initialized
INFO - 2025-12-22 04:01:38 --> URI Class Initialized
INFO - 2025-12-22 04:01:38 --> Router Class Initialized
INFO - 2025-12-22 04:01:38 --> Output Class Initialized
INFO - 2025-12-22 04:01:38 --> Security Class Initialized
DEBUG - 2025-12-22 04:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:01:38 --> CSRF cookie sent
INFO - 2025-12-22 04:01:38 --> Input Class Initialized
INFO - 2025-12-22 04:01:38 --> Language Class Initialized
INFO - 2025-12-22 04:01:38 --> Loader Class Initialized
INFO - 2025-12-22 04:01:38 --> Helper loaded: url_helper
INFO - 2025-12-22 04:01:38 --> Helper loaded: text_helper
INFO - 2025-12-22 04:01:38 --> Helper loaded: string_helper
INFO - 2025-12-22 04:01:38 --> Helper loaded: form_helper
INFO - 2025-12-22 04:01:38 --> Helper loaded: download_helper
INFO - 2025-12-22 04:01:38 --> Helper loaded: security_helper
INFO - 2025-12-22 04:01:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:01:38 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:01:38 --> Form Validation Class Initialized
INFO - 2025-12-22 04:01:38 --> Model "User_model" initialized
INFO - 2025-12-22 10:01:38 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:01:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:01:38 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:01:38 --> Controller Class Initialized
INFO - 2025-12-22 10:01:38 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:01:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:01:39 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:39 --> Final output sent to browser
DEBUG - 2025-12-22 10:01:39 --> Total execution time: 0.1733
INFO - 2025-12-22 04:01:39 --> Config Class Initialized
INFO - 2025-12-22 04:01:39 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:01:39 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:01:39 --> Utf8 Class Initialized
INFO - 2025-12-22 04:01:39 --> URI Class Initialized
INFO - 2025-12-22 04:01:39 --> Router Class Initialized
INFO - 2025-12-22 04:01:39 --> Output Class Initialized
INFO - 2025-12-22 04:01:39 --> Security Class Initialized
DEBUG - 2025-12-22 04:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:01:39 --> CSRF cookie sent
INFO - 2025-12-22 04:01:39 --> CSRF token verified
INFO - 2025-12-22 04:01:39 --> Input Class Initialized
INFO - 2025-12-22 04:01:39 --> Language Class Initialized
INFO - 2025-12-22 04:01:39 --> Loader Class Initialized
INFO - 2025-12-22 04:01:39 --> Helper loaded: url_helper
INFO - 2025-12-22 04:01:39 --> Helper loaded: text_helper
INFO - 2025-12-22 04:01:39 --> Helper loaded: string_helper
INFO - 2025-12-22 04:01:39 --> Helper loaded: form_helper
INFO - 2025-12-22 04:01:39 --> Helper loaded: download_helper
INFO - 2025-12-22 04:01:39 --> Helper loaded: security_helper
INFO - 2025-12-22 04:01:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:01:39 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:01:39 --> Form Validation Class Initialized
INFO - 2025-12-22 04:01:39 --> Model "User_model" initialized
INFO - 2025-12-22 10:01:39 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:01:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:01:39 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:01:39 --> Controller Class Initialized
INFO - 2025-12-22 10:01:39 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:39 --> Model "Log_model" initialized
INFO - 2025-12-22 10:01:39 --> Final output sent to browser
DEBUG - 2025-12-22 10:01:39 --> Total execution time: 0.3735
INFO - 2025-12-22 04:02:08 --> Config Class Initialized
INFO - 2025-12-22 04:02:08 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:02:08 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:02:08 --> Utf8 Class Initialized
INFO - 2025-12-22 04:02:08 --> URI Class Initialized
INFO - 2025-12-22 04:02:08 --> Router Class Initialized
INFO - 2025-12-22 04:02:08 --> Output Class Initialized
INFO - 2025-12-22 04:02:08 --> Security Class Initialized
DEBUG - 2025-12-22 04:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:02:08 --> CSRF cookie sent
INFO - 2025-12-22 04:02:08 --> Input Class Initialized
INFO - 2025-12-22 04:02:08 --> Language Class Initialized
INFO - 2025-12-22 04:02:08 --> Loader Class Initialized
INFO - 2025-12-22 04:02:08 --> Helper loaded: url_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: text_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: string_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: form_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: download_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: security_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:02:08 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:02:08 --> Form Validation Class Initialized
INFO - 2025-12-22 04:02:08 --> Model "User_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:02:08 --> Controller Class Initialized
INFO - 2025-12-22 10:02:08 --> Model "Log_model" initialized
INFO - 2025-12-22 10:02:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:02:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:02:08 --> Model "Log_model" initialized
INFO - 2025-12-22 10:02:08 --> Final output sent to browser
DEBUG - 2025-12-22 10:02:08 --> Total execution time: 0.0991
INFO - 2025-12-22 04:02:08 --> Config Class Initialized
INFO - 2025-12-22 04:02:08 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:02:08 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:02:08 --> Utf8 Class Initialized
INFO - 2025-12-22 04:02:08 --> URI Class Initialized
INFO - 2025-12-22 04:02:08 --> Router Class Initialized
INFO - 2025-12-22 04:02:08 --> Output Class Initialized
INFO - 2025-12-22 04:02:08 --> Security Class Initialized
DEBUG - 2025-12-22 04:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:02:08 --> CSRF cookie sent
INFO - 2025-12-22 04:02:08 --> CSRF token verified
INFO - 2025-12-22 04:02:08 --> Input Class Initialized
INFO - 2025-12-22 04:02:08 --> Language Class Initialized
INFO - 2025-12-22 04:02:08 --> Loader Class Initialized
INFO - 2025-12-22 04:02:08 --> Helper loaded: url_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: text_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: string_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: form_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: download_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: security_helper
INFO - 2025-12-22 04:02:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:02:08 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:02:08 --> Form Validation Class Initialized
INFO - 2025-12-22 04:02:08 --> Model "User_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:02:08 --> Controller Class Initialized
INFO - 2025-12-22 10:02:08 --> Model "Berita_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Galeri_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Video_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Agenda_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Tautan_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Mitra_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Prodi_model" initialized
INFO - 2025-12-22 10:02:08 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 10:02:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-12-22 10:02:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 10:02:08 --> Model "Log_model" initialized
INFO - 2025-12-22 10:02:08 --> Final output sent to browser
DEBUG - 2025-12-22 10:02:08 --> Total execution time: 0.2432
INFO - 2025-12-22 04:02:20 --> Config Class Initialized
INFO - 2025-12-22 04:02:20 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:02:20 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:02:20 --> Utf8 Class Initialized
INFO - 2025-12-22 04:02:20 --> URI Class Initialized
INFO - 2025-12-22 04:02:20 --> Router Class Initialized
INFO - 2025-12-22 04:02:20 --> Output Class Initialized
INFO - 2025-12-22 04:02:20 --> Security Class Initialized
DEBUG - 2025-12-22 04:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:02:20 --> CSRF cookie sent
INFO - 2025-12-22 04:02:20 --> Input Class Initialized
INFO - 2025-12-22 04:02:20 --> Language Class Initialized
INFO - 2025-12-22 04:02:20 --> Loader Class Initialized
INFO - 2025-12-22 04:02:20 --> Helper loaded: url_helper
INFO - 2025-12-22 04:02:20 --> Helper loaded: text_helper
INFO - 2025-12-22 04:02:20 --> Helper loaded: string_helper
INFO - 2025-12-22 04:02:20 --> Helper loaded: form_helper
INFO - 2025-12-22 04:02:20 --> Helper loaded: download_helper
INFO - 2025-12-22 04:02:20 --> Helper loaded: security_helper
INFO - 2025-12-22 04:02:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:02:20 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:02:20 --> Form Validation Class Initialized
INFO - 2025-12-22 04:02:20 --> Model "User_model" initialized
INFO - 2025-12-22 10:02:20 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:02:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:02:20 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:02:20 --> Controller Class Initialized
INFO - 2025-12-22 10:02:20 --> Model "Log_model" initialized
INFO - 2025-12-22 10:02:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:02:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:02:20 --> Model "Log_model" initialized
INFO - 2025-12-22 10:02:20 --> Final output sent to browser
DEBUG - 2025-12-22 10:02:20 --> Total execution time: 0.0848
INFO - 2025-12-22 04:02:21 --> Config Class Initialized
INFO - 2025-12-22 04:02:21 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:02:21 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:02:21 --> Utf8 Class Initialized
INFO - 2025-12-22 04:02:21 --> URI Class Initialized
INFO - 2025-12-22 04:02:21 --> Router Class Initialized
INFO - 2025-12-22 04:02:21 --> Output Class Initialized
INFO - 2025-12-22 04:02:21 --> Security Class Initialized
DEBUG - 2025-12-22 04:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:02:21 --> CSRF cookie sent
INFO - 2025-12-22 04:02:21 --> CSRF token verified
INFO - 2025-12-22 04:02:21 --> Input Class Initialized
INFO - 2025-12-22 04:02:21 --> Language Class Initialized
INFO - 2025-12-22 04:02:21 --> Loader Class Initialized
INFO - 2025-12-22 04:02:21 --> Helper loaded: url_helper
INFO - 2025-12-22 04:02:21 --> Helper loaded: text_helper
INFO - 2025-12-22 04:02:21 --> Helper loaded: string_helper
INFO - 2025-12-22 04:02:21 --> Helper loaded: form_helper
INFO - 2025-12-22 04:02:21 --> Helper loaded: download_helper
INFO - 2025-12-22 04:02:21 --> Helper loaded: security_helper
INFO - 2025-12-22 04:02:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:02:21 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:02:21 --> Form Validation Class Initialized
INFO - 2025-12-22 04:02:21 --> Model "User_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:02:21 --> Controller Class Initialized
INFO - 2025-12-22 10:02:21 --> Model "Berita_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Galeri_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Video_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Agenda_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Tautan_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Mitra_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Prodi_model" initialized
INFO - 2025-12-22 10:02:21 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 10:02:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-12-22 10:02:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 10:02:21 --> Model "Log_model" initialized
INFO - 2025-12-22 10:02:21 --> Final output sent to browser
DEBUG - 2025-12-22 10:02:21 --> Total execution time: 0.1122
INFO - 2025-12-22 04:03:18 --> Config Class Initialized
INFO - 2025-12-22 04:03:18 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:03:18 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:03:18 --> Utf8 Class Initialized
INFO - 2025-12-22 04:03:18 --> URI Class Initialized
INFO - 2025-12-22 04:03:18 --> Router Class Initialized
INFO - 2025-12-22 04:03:18 --> Output Class Initialized
INFO - 2025-12-22 04:03:18 --> Security Class Initialized
DEBUG - 2025-12-22 04:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:03:18 --> CSRF cookie sent
INFO - 2025-12-22 04:03:18 --> Input Class Initialized
INFO - 2025-12-22 04:03:18 --> Language Class Initialized
INFO - 2025-12-22 04:03:18 --> Loader Class Initialized
INFO - 2025-12-22 04:03:18 --> Helper loaded: url_helper
INFO - 2025-12-22 04:03:18 --> Helper loaded: text_helper
INFO - 2025-12-22 04:03:18 --> Helper loaded: string_helper
INFO - 2025-12-22 04:03:18 --> Helper loaded: form_helper
INFO - 2025-12-22 04:03:18 --> Helper loaded: download_helper
INFO - 2025-12-22 04:03:18 --> Helper loaded: security_helper
INFO - 2025-12-22 04:03:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:03:18 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:03:18 --> Form Validation Class Initialized
INFO - 2025-12-22 04:03:18 --> Model "User_model" initialized
INFO - 2025-12-22 10:03:18 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:03:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:03:18 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:03:18 --> Controller Class Initialized
INFO - 2025-12-22 10:03:18 --> Model "Log_model" initialized
INFO - 2025-12-22 10:03:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:03:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:03:18 --> Model "Log_model" initialized
INFO - 2025-12-22 10:03:18 --> Final output sent to browser
DEBUG - 2025-12-22 10:03:18 --> Total execution time: 0.2835
INFO - 2025-12-22 04:03:19 --> Config Class Initialized
INFO - 2025-12-22 04:03:19 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:03:19 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:03:19 --> Utf8 Class Initialized
INFO - 2025-12-22 04:03:19 --> URI Class Initialized
INFO - 2025-12-22 04:03:19 --> Router Class Initialized
INFO - 2025-12-22 04:03:19 --> Output Class Initialized
INFO - 2025-12-22 04:03:19 --> Security Class Initialized
DEBUG - 2025-12-22 04:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:03:19 --> CSRF cookie sent
INFO - 2025-12-22 04:03:19 --> CSRF token verified
INFO - 2025-12-22 04:03:19 --> Input Class Initialized
INFO - 2025-12-22 04:03:19 --> Language Class Initialized
INFO - 2025-12-22 04:03:19 --> Loader Class Initialized
INFO - 2025-12-22 04:03:19 --> Helper loaded: url_helper
INFO - 2025-12-22 04:03:19 --> Helper loaded: text_helper
INFO - 2025-12-22 04:03:19 --> Helper loaded: string_helper
INFO - 2025-12-22 04:03:19 --> Helper loaded: form_helper
INFO - 2025-12-22 04:03:19 --> Helper loaded: download_helper
INFO - 2025-12-22 04:03:19 --> Helper loaded: security_helper
INFO - 2025-12-22 04:03:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:03:19 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:03:19 --> Form Validation Class Initialized
INFO - 2025-12-22 04:03:19 --> Model "User_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:03:19 --> Controller Class Initialized
INFO - 2025-12-22 10:03:19 --> Model "Berita_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Galeri_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Video_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Agenda_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Tautan_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Mitra_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Prodi_model" initialized
INFO - 2025-12-22 10:03:19 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 10:03:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-12-22 10:03:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 10:03:19 --> Model "Log_model" initialized
INFO - 2025-12-22 10:03:19 --> Final output sent to browser
DEBUG - 2025-12-22 10:03:19 --> Total execution time: 0.1283
INFO - 2025-12-22 04:03:27 --> Config Class Initialized
INFO - 2025-12-22 04:03:27 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:03:27 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:03:27 --> Utf8 Class Initialized
INFO - 2025-12-22 04:03:27 --> URI Class Initialized
INFO - 2025-12-22 04:03:27 --> Router Class Initialized
INFO - 2025-12-22 04:03:27 --> Output Class Initialized
INFO - 2025-12-22 04:03:27 --> Security Class Initialized
DEBUG - 2025-12-22 04:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:03:27 --> CSRF cookie sent
INFO - 2025-12-22 04:03:27 --> Input Class Initialized
INFO - 2025-12-22 04:03:27 --> Language Class Initialized
INFO - 2025-12-22 04:03:27 --> Loader Class Initialized
INFO - 2025-12-22 04:03:27 --> Helper loaded: url_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: text_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: string_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: form_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: download_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: security_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:03:27 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:03:27 --> Form Validation Class Initialized
INFO - 2025-12-22 04:03:27 --> Model "User_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:03:27 --> Controller Class Initialized
INFO - 2025-12-22 10:03:27 --> Model "Log_model" initialized
INFO - 2025-12-22 10:03:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:03:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:03:27 --> Model "Log_model" initialized
INFO - 2025-12-22 10:03:27 --> Final output sent to browser
DEBUG - 2025-12-22 10:03:27 --> Total execution time: 0.1103
INFO - 2025-12-22 04:03:27 --> Config Class Initialized
INFO - 2025-12-22 04:03:27 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:03:27 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:03:27 --> Utf8 Class Initialized
INFO - 2025-12-22 04:03:27 --> URI Class Initialized
INFO - 2025-12-22 04:03:27 --> Router Class Initialized
INFO - 2025-12-22 04:03:27 --> Output Class Initialized
INFO - 2025-12-22 04:03:27 --> Security Class Initialized
DEBUG - 2025-12-22 04:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:03:27 --> CSRF cookie sent
INFO - 2025-12-22 04:03:27 --> CSRF token verified
INFO - 2025-12-22 04:03:27 --> Input Class Initialized
INFO - 2025-12-22 04:03:27 --> Language Class Initialized
INFO - 2025-12-22 04:03:27 --> Loader Class Initialized
INFO - 2025-12-22 04:03:27 --> Helper loaded: url_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: text_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: string_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: form_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: download_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: security_helper
INFO - 2025-12-22 04:03:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:03:27 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:03:27 --> Form Validation Class Initialized
INFO - 2025-12-22 04:03:27 --> Model "User_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:03:27 --> Controller Class Initialized
INFO - 2025-12-22 10:03:27 --> Model "Berita_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Galeri_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Video_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Agenda_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Tautan_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Mitra_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Prodi_model" initialized
INFO - 2025-12-22 10:03:27 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 10:03:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-12-22 10:03:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 10:03:27 --> Model "Log_model" initialized
INFO - 2025-12-22 10:03:27 --> Final output sent to browser
DEBUG - 2025-12-22 10:03:27 --> Total execution time: 0.1186
INFO - 2025-12-22 04:03:45 --> Config Class Initialized
INFO - 2025-12-22 04:03:45 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:03:45 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:03:45 --> Utf8 Class Initialized
INFO - 2025-12-22 04:03:45 --> URI Class Initialized
INFO - 2025-12-22 04:03:45 --> Router Class Initialized
INFO - 2025-12-22 04:03:45 --> Output Class Initialized
INFO - 2025-12-22 04:03:45 --> Security Class Initialized
DEBUG - 2025-12-22 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:03:45 --> CSRF cookie sent
INFO - 2025-12-22 04:03:45 --> Input Class Initialized
INFO - 2025-12-22 04:03:45 --> Language Class Initialized
INFO - 2025-12-22 04:03:45 --> Loader Class Initialized
INFO - 2025-12-22 04:03:45 --> Helper loaded: url_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: text_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: string_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: form_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: download_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: security_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:03:45 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:03:45 --> Form Validation Class Initialized
INFO - 2025-12-22 04:03:45 --> Model "User_model" initialized
INFO - 2025-12-22 10:03:45 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:03:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:03:45 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:03:45 --> Controller Class Initialized
INFO - 2025-12-22 10:03:45 --> Model "Log_model" initialized
INFO - 2025-12-22 10:03:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:03:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:03:45 --> Model "Log_model" initialized
INFO - 2025-12-22 10:03:45 --> Final output sent to browser
DEBUG - 2025-12-22 10:03:45 --> Total execution time: 0.2307
INFO - 2025-12-22 04:03:45 --> Config Class Initialized
INFO - 2025-12-22 04:03:45 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:03:45 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:03:45 --> Utf8 Class Initialized
INFO - 2025-12-22 04:03:45 --> URI Class Initialized
INFO - 2025-12-22 04:03:45 --> Router Class Initialized
INFO - 2025-12-22 04:03:45 --> Output Class Initialized
INFO - 2025-12-22 04:03:45 --> Security Class Initialized
DEBUG - 2025-12-22 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:03:45 --> CSRF cookie sent
INFO - 2025-12-22 04:03:45 --> CSRF token verified
INFO - 2025-12-22 04:03:45 --> Input Class Initialized
INFO - 2025-12-22 04:03:45 --> Language Class Initialized
INFO - 2025-12-22 04:03:45 --> Loader Class Initialized
INFO - 2025-12-22 04:03:45 --> Helper loaded: url_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: text_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: string_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: form_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: download_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: security_helper
INFO - 2025-12-22 04:03:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:03:45 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:03:45 --> Form Validation Class Initialized
INFO - 2025-12-22 04:03:45 --> Model "User_model" initialized
INFO - 2025-12-22 10:03:45 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:03:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:03:45 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:03:45 --> Controller Class Initialized
INFO - 2025-12-22 10:03:46 --> Model "M_log" initialized
ERROR - 2025-12-22 10:03:46 --> Severity: Notice --> Undefined property: Logs::$ion_auth D:\xampp\htdocs\dev_jkt3\application\controllers\admin\Logs.php 10
ERROR - 2025-12-22 10:03:46 --> Severity: error --> Exception: Call to a member function logged_in() on null D:\xampp\htdocs\dev_jkt3\application\controllers\admin\Logs.php 10
INFO - 2025-12-22 04:04:52 --> Config Class Initialized
INFO - 2025-12-22 04:04:52 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:04:52 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:04:52 --> Utf8 Class Initialized
INFO - 2025-12-22 04:04:52 --> URI Class Initialized
INFO - 2025-12-22 04:04:52 --> Router Class Initialized
INFO - 2025-12-22 04:04:52 --> Output Class Initialized
INFO - 2025-12-22 04:04:52 --> Security Class Initialized
DEBUG - 2025-12-22 04:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:04:52 --> CSRF cookie sent
INFO - 2025-12-22 04:04:52 --> Input Class Initialized
INFO - 2025-12-22 04:04:52 --> Language Class Initialized
INFO - 2025-12-22 04:04:52 --> Loader Class Initialized
INFO - 2025-12-22 04:04:52 --> Helper loaded: url_helper
INFO - 2025-12-22 04:04:52 --> Helper loaded: text_helper
INFO - 2025-12-22 04:04:52 --> Helper loaded: string_helper
INFO - 2025-12-22 04:04:52 --> Helper loaded: form_helper
INFO - 2025-12-22 04:04:52 --> Helper loaded: download_helper
INFO - 2025-12-22 04:04:52 --> Helper loaded: security_helper
INFO - 2025-12-22 04:04:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:04:52 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:04:52 --> Form Validation Class Initialized
INFO - 2025-12-22 04:04:52 --> Model "User_model" initialized
INFO - 2025-12-22 10:04:52 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:04:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:04:52 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:04:52 --> Controller Class Initialized
INFO - 2025-12-22 10:04:52 --> Model "Log_model" initialized
INFO - 2025-12-22 10:04:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:04:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:04:52 --> Model "Log_model" initialized
INFO - 2025-12-22 10:04:52 --> Final output sent to browser
DEBUG - 2025-12-22 10:04:52 --> Total execution time: 0.1924
INFO - 2025-12-22 04:04:53 --> Config Class Initialized
INFO - 2025-12-22 04:04:53 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:04:53 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:04:53 --> Utf8 Class Initialized
INFO - 2025-12-22 04:04:53 --> URI Class Initialized
INFO - 2025-12-22 04:04:53 --> Router Class Initialized
INFO - 2025-12-22 04:04:53 --> Output Class Initialized
INFO - 2025-12-22 04:04:53 --> Security Class Initialized
DEBUG - 2025-12-22 04:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:04:53 --> CSRF cookie sent
INFO - 2025-12-22 04:04:53 --> CSRF token verified
INFO - 2025-12-22 04:04:53 --> Input Class Initialized
INFO - 2025-12-22 04:04:53 --> Language Class Initialized
INFO - 2025-12-22 04:04:53 --> Loader Class Initialized
INFO - 2025-12-22 04:04:53 --> Helper loaded: url_helper
INFO - 2025-12-22 04:04:53 --> Helper loaded: text_helper
INFO - 2025-12-22 04:04:53 --> Helper loaded: string_helper
INFO - 2025-12-22 04:04:53 --> Helper loaded: form_helper
INFO - 2025-12-22 04:04:53 --> Helper loaded: download_helper
INFO - 2025-12-22 04:04:53 --> Helper loaded: security_helper
INFO - 2025-12-22 04:04:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:04:53 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:04:53 --> Form Validation Class Initialized
INFO - 2025-12-22 04:04:53 --> Model "User_model" initialized
INFO - 2025-12-22 10:04:53 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:04:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:04:53 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:04:53 --> Controller Class Initialized
INFO - 2025-12-22 10:04:53 --> Model "M_log" initialized
INFO - 2025-12-22 10:04:54 --> Model "Log_model" initialized
INFO - 2025-12-22 10:04:54 --> Final output sent to browser
DEBUG - 2025-12-22 10:04:54 --> Total execution time: 0.8277
INFO - 2025-12-22 04:04:58 --> Config Class Initialized
INFO - 2025-12-22 04:04:58 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:04:58 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:04:58 --> Utf8 Class Initialized
INFO - 2025-12-22 04:04:58 --> URI Class Initialized
INFO - 2025-12-22 04:04:58 --> Router Class Initialized
INFO - 2025-12-22 04:04:58 --> Output Class Initialized
INFO - 2025-12-22 04:04:58 --> Security Class Initialized
DEBUG - 2025-12-22 04:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:04:58 --> CSRF cookie sent
INFO - 2025-12-22 04:04:58 --> Input Class Initialized
INFO - 2025-12-22 04:04:58 --> Language Class Initialized
INFO - 2025-12-22 04:04:58 --> Loader Class Initialized
INFO - 2025-12-22 04:04:58 --> Helper loaded: url_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: text_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: string_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: form_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: download_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: security_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:04:58 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:04:58 --> Form Validation Class Initialized
INFO - 2025-12-22 04:04:58 --> Model "User_model" initialized
INFO - 2025-12-22 10:04:58 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:04:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:04:58 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:04:58 --> Controller Class Initialized
INFO - 2025-12-22 10:04:58 --> Model "Log_model" initialized
INFO - 2025-12-22 10:04:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:04:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:04:58 --> Model "Log_model" initialized
INFO - 2025-12-22 10:04:58 --> Final output sent to browser
DEBUG - 2025-12-22 10:04:58 --> Total execution time: 0.1181
INFO - 2025-12-22 04:04:58 --> Config Class Initialized
INFO - 2025-12-22 04:04:58 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:04:58 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:04:58 --> Utf8 Class Initialized
INFO - 2025-12-22 04:04:58 --> URI Class Initialized
INFO - 2025-12-22 04:04:58 --> Router Class Initialized
INFO - 2025-12-22 04:04:58 --> Output Class Initialized
INFO - 2025-12-22 04:04:58 --> Security Class Initialized
DEBUG - 2025-12-22 04:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:04:58 --> CSRF cookie sent
INFO - 2025-12-22 04:04:58 --> CSRF token verified
INFO - 2025-12-22 04:04:58 --> Input Class Initialized
INFO - 2025-12-22 04:04:58 --> Language Class Initialized
INFO - 2025-12-22 04:04:58 --> Loader Class Initialized
INFO - 2025-12-22 04:04:58 --> Helper loaded: url_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: text_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: string_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: form_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: download_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: security_helper
INFO - 2025-12-22 04:04:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:04:58 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:04:58 --> Form Validation Class Initialized
INFO - 2025-12-22 04:04:58 --> Model "User_model" initialized
INFO - 2025-12-22 10:04:58 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:04:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:04:58 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:04:58 --> Controller Class Initialized
INFO - 2025-12-22 10:04:58 --> Model "M_log" initialized
INFO - 2025-12-22 10:04:58 --> Model "Log_model" initialized
INFO - 2025-12-22 10:04:58 --> Final output sent to browser
DEBUG - 2025-12-22 10:04:58 --> Total execution time: 0.4495
INFO - 2025-12-22 04:05:02 --> Config Class Initialized
INFO - 2025-12-22 04:05:02 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:05:02 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:05:02 --> Utf8 Class Initialized
INFO - 2025-12-22 04:05:02 --> URI Class Initialized
INFO - 2025-12-22 04:05:02 --> Router Class Initialized
INFO - 2025-12-22 04:05:02 --> Output Class Initialized
INFO - 2025-12-22 04:05:02 --> Security Class Initialized
DEBUG - 2025-12-22 04:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:05:02 --> CSRF cookie sent
INFO - 2025-12-22 04:05:02 --> CSRF token verified
INFO - 2025-12-22 04:05:02 --> Input Class Initialized
INFO - 2025-12-22 04:05:02 --> Language Class Initialized
INFO - 2025-12-22 04:05:02 --> Loader Class Initialized
INFO - 2025-12-22 04:05:02 --> Helper loaded: url_helper
INFO - 2025-12-22 04:05:02 --> Helper loaded: text_helper
INFO - 2025-12-22 04:05:02 --> Helper loaded: string_helper
INFO - 2025-12-22 04:05:02 --> Helper loaded: form_helper
INFO - 2025-12-22 04:05:02 --> Helper loaded: download_helper
INFO - 2025-12-22 04:05:02 --> Helper loaded: security_helper
INFO - 2025-12-22 04:05:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:05:02 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:05:02 --> Form Validation Class Initialized
INFO - 2025-12-22 04:05:02 --> Model "User_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:05:02 --> Controller Class Initialized
INFO - 2025-12-22 10:05:02 --> Model "Berita_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Galeri_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Video_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Agenda_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Tautan_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Mitra_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Prodi_model" initialized
INFO - 2025-12-22 10:05:02 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 10:05:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-12-22 10:05:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 10:05:02 --> Model "Log_model" initialized
INFO - 2025-12-22 10:05:02 --> Final output sent to browser
DEBUG - 2025-12-22 10:05:02 --> Total execution time: 0.1763
INFO - 2025-12-22 04:05:07 --> Config Class Initialized
INFO - 2025-12-22 04:05:07 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:05:07 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:05:07 --> Utf8 Class Initialized
INFO - 2025-12-22 04:05:07 --> URI Class Initialized
INFO - 2025-12-22 04:05:07 --> Router Class Initialized
INFO - 2025-12-22 04:05:07 --> Output Class Initialized
INFO - 2025-12-22 04:05:07 --> Security Class Initialized
DEBUG - 2025-12-22 04:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:05:07 --> CSRF cookie sent
INFO - 2025-12-22 04:05:07 --> Input Class Initialized
INFO - 2025-12-22 04:05:07 --> Language Class Initialized
INFO - 2025-12-22 04:05:07 --> Loader Class Initialized
INFO - 2025-12-22 04:05:07 --> Helper loaded: url_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: text_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: string_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: form_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: download_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: security_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:05:07 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:05:07 --> Form Validation Class Initialized
INFO - 2025-12-22 04:05:07 --> Model "User_model" initialized
INFO - 2025-12-22 10:05:07 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:05:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:05:07 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:05:07 --> Controller Class Initialized
INFO - 2025-12-22 10:05:07 --> Model "Log_model" initialized
INFO - 2025-12-22 10:05:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:05:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:05:07 --> Model "Log_model" initialized
INFO - 2025-12-22 10:05:07 --> Final output sent to browser
DEBUG - 2025-12-22 10:05:07 --> Total execution time: 0.1312
INFO - 2025-12-22 04:05:07 --> Config Class Initialized
INFO - 2025-12-22 04:05:07 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:05:07 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:05:07 --> Utf8 Class Initialized
INFO - 2025-12-22 04:05:07 --> URI Class Initialized
INFO - 2025-12-22 04:05:07 --> Router Class Initialized
INFO - 2025-12-22 04:05:07 --> Output Class Initialized
INFO - 2025-12-22 04:05:07 --> Security Class Initialized
DEBUG - 2025-12-22 04:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:05:07 --> CSRF cookie sent
INFO - 2025-12-22 04:05:07 --> CSRF token verified
INFO - 2025-12-22 04:05:07 --> Input Class Initialized
INFO - 2025-12-22 04:05:07 --> Language Class Initialized
INFO - 2025-12-22 04:05:07 --> Loader Class Initialized
INFO - 2025-12-22 04:05:07 --> Helper loaded: url_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: text_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: string_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: form_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: download_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: security_helper
INFO - 2025-12-22 04:05:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:05:07 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:05:07 --> Form Validation Class Initialized
INFO - 2025-12-22 04:05:07 --> Model "User_model" initialized
INFO - 2025-12-22 10:05:07 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:05:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:05:07 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:05:07 --> Controller Class Initialized
INFO - 2025-12-22 10:05:07 --> Model "M_log" initialized
INFO - 2025-12-22 10:05:07 --> Model "Log_model" initialized
INFO - 2025-12-22 10:05:07 --> Final output sent to browser
DEBUG - 2025-12-22 10:05:07 --> Total execution time: 0.3504
INFO - 2025-12-22 04:21:57 --> Config Class Initialized
INFO - 2025-12-22 04:21:57 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:21:57 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:21:57 --> Utf8 Class Initialized
INFO - 2025-12-22 04:21:57 --> URI Class Initialized
INFO - 2025-12-22 04:21:57 --> Router Class Initialized
INFO - 2025-12-22 04:21:57 --> Output Class Initialized
INFO - 2025-12-22 04:21:57 --> Security Class Initialized
DEBUG - 2025-12-22 04:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:21:57 --> CSRF cookie sent
INFO - 2025-12-22 04:21:57 --> Input Class Initialized
INFO - 2025-12-22 04:21:57 --> Language Class Initialized
INFO - 2025-12-22 04:21:57 --> Loader Class Initialized
INFO - 2025-12-22 04:21:57 --> Helper loaded: url_helper
INFO - 2025-12-22 04:21:57 --> Helper loaded: text_helper
INFO - 2025-12-22 04:21:57 --> Helper loaded: string_helper
INFO - 2025-12-22 04:21:57 --> Helper loaded: form_helper
INFO - 2025-12-22 04:21:57 --> Helper loaded: download_helper
INFO - 2025-12-22 04:21:57 --> Helper loaded: security_helper
INFO - 2025-12-22 04:21:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:21:57 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:21:57 --> Form Validation Class Initialized
INFO - 2025-12-22 04:21:57 --> Model "User_model" initialized
INFO - 2025-12-22 10:21:57 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:21:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:21:57 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:21:57 --> Controller Class Initialized
INFO - 2025-12-22 10:21:57 --> Model "Log_model" initialized
INFO - 2025-12-22 10:21:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:21:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:21:57 --> Model "Log_model" initialized
INFO - 2025-12-22 10:21:57 --> Final output sent to browser
DEBUG - 2025-12-22 10:21:57 --> Total execution time: 0.1259
INFO - 2025-12-22 04:21:57 --> Config Class Initialized
INFO - 2025-12-22 04:21:57 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:21:57 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:21:57 --> Utf8 Class Initialized
INFO - 2025-12-22 04:21:57 --> URI Class Initialized
INFO - 2025-12-22 04:21:57 --> Router Class Initialized
INFO - 2025-12-22 04:21:57 --> Output Class Initialized
INFO - 2025-12-22 04:21:57 --> Security Class Initialized
DEBUG - 2025-12-22 04:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:21:57 --> CSRF cookie sent
INFO - 2025-12-22 04:21:57 --> CSRF token verified
INFO - 2025-12-22 04:21:57 --> Input Class Initialized
INFO - 2025-12-22 04:21:57 --> Language Class Initialized
INFO - 2025-12-22 04:21:57 --> Loader Class Initialized
INFO - 2025-12-22 04:21:57 --> Helper loaded: url_helper
INFO - 2025-12-22 04:21:57 --> Helper loaded: text_helper
INFO - 2025-12-22 04:21:57 --> Helper loaded: string_helper
INFO - 2025-12-22 04:21:58 --> Helper loaded: form_helper
INFO - 2025-12-22 04:21:58 --> Helper loaded: download_helper
INFO - 2025-12-22 04:21:58 --> Helper loaded: security_helper
INFO - 2025-12-22 04:21:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:21:58 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:21:58 --> Form Validation Class Initialized
INFO - 2025-12-22 04:21:58 --> Model "User_model" initialized
INFO - 2025-12-22 10:21:58 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:21:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:21:58 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:21:58 --> Controller Class Initialized
INFO - 2025-12-22 10:21:58 --> Model "M_log" initialized
INFO - 2025-12-22 10:21:59 --> Model "Log_model" initialized
INFO - 2025-12-22 10:21:59 --> Final output sent to browser
DEBUG - 2025-12-22 10:21:59 --> Total execution time: 1.3744
INFO - 2025-12-22 04:22:00 --> Config Class Initialized
INFO - 2025-12-22 04:22:00 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:22:00 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:22:00 --> Utf8 Class Initialized
INFO - 2025-12-22 04:22:00 --> URI Class Initialized
INFO - 2025-12-22 04:22:00 --> Router Class Initialized
INFO - 2025-12-22 04:22:00 --> Output Class Initialized
INFO - 2025-12-22 04:22:00 --> Security Class Initialized
DEBUG - 2025-12-22 04:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:22:00 --> CSRF cookie sent
INFO - 2025-12-22 04:22:00 --> CSRF token verified
INFO - 2025-12-22 04:22:00 --> Input Class Initialized
INFO - 2025-12-22 04:22:00 --> Language Class Initialized
INFO - 2025-12-22 04:22:00 --> Loader Class Initialized
INFO - 2025-12-22 04:22:00 --> Helper loaded: url_helper
INFO - 2025-12-22 04:22:00 --> Helper loaded: text_helper
INFO - 2025-12-22 04:22:00 --> Helper loaded: string_helper
INFO - 2025-12-22 04:22:00 --> Helper loaded: form_helper
INFO - 2025-12-22 04:22:00 --> Helper loaded: download_helper
INFO - 2025-12-22 04:22:00 --> Helper loaded: security_helper
INFO - 2025-12-22 04:22:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:22:00 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:22:00 --> Form Validation Class Initialized
INFO - 2025-12-22 04:22:00 --> Model "User_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:22:00 --> Controller Class Initialized
INFO - 2025-12-22 10:22:00 --> Model "Berita_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Galeri_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Video_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Agenda_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Tautan_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Mitra_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Prodi_model" initialized
INFO - 2025-12-22 10:22:00 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 10:22:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-12-22 10:22:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 10:22:00 --> Model "Log_model" initialized
INFO - 2025-12-22 10:22:00 --> Final output sent to browser
DEBUG - 2025-12-22 10:22:00 --> Total execution time: 0.1645
INFO - 2025-12-22 04:22:10 --> Config Class Initialized
INFO - 2025-12-22 04:22:10 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:22:10 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:22:10 --> Utf8 Class Initialized
INFO - 2025-12-22 04:22:10 --> URI Class Initialized
INFO - 2025-12-22 04:22:10 --> Router Class Initialized
INFO - 2025-12-22 04:22:10 --> Output Class Initialized
INFO - 2025-12-22 04:22:10 --> Security Class Initialized
DEBUG - 2025-12-22 04:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:22:10 --> CSRF cookie sent
INFO - 2025-12-22 04:22:10 --> CSRF token verified
INFO - 2025-12-22 04:22:10 --> Input Class Initialized
INFO - 2025-12-22 04:22:10 --> Language Class Initialized
INFO - 2025-12-22 04:22:10 --> Loader Class Initialized
INFO - 2025-12-22 04:22:10 --> Helper loaded: url_helper
INFO - 2025-12-22 04:22:10 --> Helper loaded: text_helper
INFO - 2025-12-22 04:22:10 --> Helper loaded: string_helper
INFO - 2025-12-22 04:22:10 --> Helper loaded: form_helper
INFO - 2025-12-22 04:22:10 --> Helper loaded: download_helper
INFO - 2025-12-22 04:22:10 --> Helper loaded: security_helper
INFO - 2025-12-22 04:22:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:22:10 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:22:10 --> Form Validation Class Initialized
INFO - 2025-12-22 04:22:10 --> Model "User_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:22:10 --> Controller Class Initialized
INFO - 2025-12-22 10:22:10 --> Model "Berita_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Galeri_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Video_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Agenda_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Tautan_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Mitra_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Prodi_model" initialized
INFO - 2025-12-22 10:22:10 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 10:22:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-12-22 10:22:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 10:22:10 --> Model "Log_model" initialized
INFO - 2025-12-22 10:22:10 --> Final output sent to browser
DEBUG - 2025-12-22 10:22:10 --> Total execution time: 0.1251
INFO - 2025-12-22 04:22:15 --> Config Class Initialized
INFO - 2025-12-22 04:22:15 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:22:15 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:22:15 --> Utf8 Class Initialized
INFO - 2025-12-22 04:22:15 --> URI Class Initialized
INFO - 2025-12-22 04:22:15 --> Router Class Initialized
INFO - 2025-12-22 04:22:15 --> Output Class Initialized
INFO - 2025-12-22 04:22:15 --> Security Class Initialized
DEBUG - 2025-12-22 04:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:22:15 --> CSRF cookie sent
INFO - 2025-12-22 04:22:15 --> Input Class Initialized
INFO - 2025-12-22 04:22:15 --> Language Class Initialized
INFO - 2025-12-22 04:22:15 --> Loader Class Initialized
INFO - 2025-12-22 04:22:15 --> Helper loaded: url_helper
INFO - 2025-12-22 04:22:15 --> Helper loaded: text_helper
INFO - 2025-12-22 04:22:15 --> Helper loaded: string_helper
INFO - 2025-12-22 04:22:15 --> Helper loaded: form_helper
INFO - 2025-12-22 04:22:15 --> Helper loaded: download_helper
INFO - 2025-12-22 04:22:15 --> Helper loaded: security_helper
INFO - 2025-12-22 04:22:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:22:15 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:22:15 --> Form Validation Class Initialized
INFO - 2025-12-22 04:22:15 --> Model "User_model" initialized
INFO - 2025-12-22 10:22:15 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:22:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:22:15 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:22:15 --> Controller Class Initialized
INFO - 2025-12-22 10:22:15 --> Model "Log_model" initialized
INFO - 2025-12-22 10:22:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:22:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:22:15 --> Model "Log_model" initialized
INFO - 2025-12-22 10:22:15 --> Final output sent to browser
DEBUG - 2025-12-22 10:22:15 --> Total execution time: 0.1463
INFO - 2025-12-22 04:22:16 --> Config Class Initialized
INFO - 2025-12-22 04:22:16 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:22:16 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:22:16 --> Utf8 Class Initialized
INFO - 2025-12-22 04:22:16 --> URI Class Initialized
INFO - 2025-12-22 04:22:16 --> Router Class Initialized
INFO - 2025-12-22 04:22:16 --> Output Class Initialized
INFO - 2025-12-22 04:22:16 --> Security Class Initialized
DEBUG - 2025-12-22 04:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:22:16 --> CSRF cookie sent
INFO - 2025-12-22 04:22:16 --> CSRF token verified
INFO - 2025-12-22 04:22:16 --> Input Class Initialized
INFO - 2025-12-22 04:22:16 --> Language Class Initialized
INFO - 2025-12-22 04:22:16 --> Loader Class Initialized
INFO - 2025-12-22 04:22:16 --> Helper loaded: url_helper
INFO - 2025-12-22 04:22:16 --> Helper loaded: text_helper
INFO - 2025-12-22 04:22:16 --> Helper loaded: string_helper
INFO - 2025-12-22 04:22:16 --> Helper loaded: form_helper
INFO - 2025-12-22 04:22:16 --> Helper loaded: download_helper
INFO - 2025-12-22 04:22:16 --> Helper loaded: security_helper
INFO - 2025-12-22 04:22:16 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:22:16 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:22:16 --> Form Validation Class Initialized
INFO - 2025-12-22 04:22:16 --> Model "User_model" initialized
INFO - 2025-12-22 10:22:16 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:22:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:22:16 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:22:16 --> Controller Class Initialized
INFO - 2025-12-22 10:22:16 --> Model "M_log" initialized
INFO - 2025-12-22 10:22:16 --> Model "Log_model" initialized
INFO - 2025-12-22 10:22:16 --> Final output sent to browser
DEBUG - 2025-12-22 10:22:16 --> Total execution time: 0.4245
INFO - 2025-12-22 04:22:18 --> Config Class Initialized
INFO - 2025-12-22 04:22:18 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:22:18 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:22:18 --> Utf8 Class Initialized
INFO - 2025-12-22 04:22:18 --> URI Class Initialized
INFO - 2025-12-22 04:22:18 --> Router Class Initialized
INFO - 2025-12-22 04:22:18 --> Output Class Initialized
INFO - 2025-12-22 04:22:18 --> Security Class Initialized
DEBUG - 2025-12-22 04:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:22:18 --> CSRF cookie sent
INFO - 2025-12-22 04:22:18 --> CSRF token verified
INFO - 2025-12-22 04:22:18 --> Input Class Initialized
INFO - 2025-12-22 04:22:18 --> Language Class Initialized
INFO - 2025-12-22 04:22:18 --> Loader Class Initialized
INFO - 2025-12-22 04:22:18 --> Helper loaded: url_helper
INFO - 2025-12-22 04:22:18 --> Helper loaded: text_helper
INFO - 2025-12-22 04:22:18 --> Helper loaded: string_helper
INFO - 2025-12-22 04:22:18 --> Helper loaded: form_helper
INFO - 2025-12-22 04:22:18 --> Helper loaded: download_helper
INFO - 2025-12-22 04:22:18 --> Helper loaded: security_helper
INFO - 2025-12-22 04:22:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:22:18 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:22:18 --> Form Validation Class Initialized
INFO - 2025-12-22 04:22:18 --> Model "User_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:22:18 --> Controller Class Initialized
INFO - 2025-12-22 10:22:18 --> Model "Berita_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Galeri_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Video_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Agenda_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Tautan_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Mitra_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Prodi_model" initialized
INFO - 2025-12-22 10:22:18 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 10:22:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-12-22 10:22:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 10:22:18 --> Model "Log_model" initialized
INFO - 2025-12-22 10:22:18 --> Final output sent to browser
DEBUG - 2025-12-22 10:22:18 --> Total execution time: 0.1772
INFO - 2025-12-22 04:22:22 --> Config Class Initialized
INFO - 2025-12-22 04:22:22 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:22:22 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:22:22 --> Utf8 Class Initialized
INFO - 2025-12-22 04:22:22 --> URI Class Initialized
INFO - 2025-12-22 04:22:22 --> Router Class Initialized
INFO - 2025-12-22 04:22:22 --> Output Class Initialized
INFO - 2025-12-22 04:22:22 --> Security Class Initialized
DEBUG - 2025-12-22 04:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:22:22 --> CSRF cookie sent
INFO - 2025-12-22 04:22:22 --> Input Class Initialized
INFO - 2025-12-22 04:22:22 --> Language Class Initialized
INFO - 2025-12-22 04:22:22 --> Loader Class Initialized
INFO - 2025-12-22 04:22:22 --> Helper loaded: url_helper
INFO - 2025-12-22 04:22:22 --> Helper loaded: text_helper
INFO - 2025-12-22 04:22:22 --> Helper loaded: string_helper
INFO - 2025-12-22 04:22:22 --> Helper loaded: form_helper
INFO - 2025-12-22 04:22:22 --> Helper loaded: download_helper
INFO - 2025-12-22 04:22:22 --> Helper loaded: security_helper
INFO - 2025-12-22 04:22:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:22:22 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:22:22 --> Form Validation Class Initialized
INFO - 2025-12-22 04:22:22 --> Model "User_model" initialized
INFO - 2025-12-22 10:22:22 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:22:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:22:22 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:22:22 --> Controller Class Initialized
INFO - 2025-12-22 10:22:22 --> Model "Log_model" initialized
INFO - 2025-12-22 10:22:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2025-12-22 10:22:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-22 10:22:22 --> Model "Log_model" initialized
INFO - 2025-12-22 10:22:22 --> Final output sent to browser
DEBUG - 2025-12-22 10:22:22 --> Total execution time: 0.1708
INFO - 2025-12-22 04:22:23 --> Config Class Initialized
INFO - 2025-12-22 04:22:23 --> Hooks Class Initialized
DEBUG - 2025-12-22 04:22:23 --> UTF-8 Support Enabled
INFO - 2025-12-22 04:22:23 --> Utf8 Class Initialized
INFO - 2025-12-22 04:22:23 --> URI Class Initialized
INFO - 2025-12-22 04:22:23 --> Router Class Initialized
INFO - 2025-12-22 04:22:23 --> Output Class Initialized
INFO - 2025-12-22 04:22:23 --> Security Class Initialized
DEBUG - 2025-12-22 04:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 04:22:23 --> CSRF cookie sent
INFO - 2025-12-22 04:22:23 --> CSRF token verified
INFO - 2025-12-22 04:22:23 --> Input Class Initialized
INFO - 2025-12-22 04:22:23 --> Language Class Initialized
INFO - 2025-12-22 04:22:23 --> Loader Class Initialized
INFO - 2025-12-22 04:22:23 --> Helper loaded: url_helper
INFO - 2025-12-22 04:22:23 --> Helper loaded: text_helper
INFO - 2025-12-22 04:22:23 --> Helper loaded: string_helper
INFO - 2025-12-22 04:22:23 --> Helper loaded: form_helper
INFO - 2025-12-22 04:22:23 --> Helper loaded: download_helper
INFO - 2025-12-22 04:22:23 --> Helper loaded: security_helper
INFO - 2025-12-22 04:22:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 04:22:23 --> Database Driver Class Initialized
DEBUG - 2025-12-22 04:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 04:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 04:22:23 --> Form Validation Class Initialized
INFO - 2025-12-22 04:22:23 --> Model "User_model" initialized
INFO - 2025-12-22 10:22:23 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 10:22:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 10:22:23 --> Model "Nav_model" initialized
INFO - 2025-12-22 10:22:23 --> Controller Class Initialized
INFO - 2025-12-22 10:22:23 --> Model "M_log" initialized
INFO - 2025-12-22 10:22:23 --> Model "Log_model" initialized
INFO - 2025-12-22 10:22:23 --> Final output sent to browser
DEBUG - 2025-12-22 10:22:23 --> Total execution time: 0.2957
INFO - 2025-12-22 08:34:20 --> Config Class Initialized
INFO - 2025-12-22 08:34:20 --> Hooks Class Initialized
DEBUG - 2025-12-22 08:34:20 --> UTF-8 Support Enabled
INFO - 2025-12-22 08:34:20 --> Utf8 Class Initialized
INFO - 2025-12-22 08:34:20 --> URI Class Initialized
DEBUG - 2025-12-22 08:34:20 --> No URI present. Default controller set.
INFO - 2025-12-22 08:34:20 --> Router Class Initialized
INFO - 2025-12-22 08:34:20 --> Output Class Initialized
INFO - 2025-12-22 08:34:20 --> Security Class Initialized
DEBUG - 2025-12-22 08:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 08:34:20 --> CSRF cookie sent
INFO - 2025-12-22 08:34:20 --> Input Class Initialized
INFO - 2025-12-22 08:34:20 --> Language Class Initialized
INFO - 2025-12-22 08:34:21 --> Loader Class Initialized
INFO - 2025-12-22 08:34:21 --> Helper loaded: url_helper
INFO - 2025-12-22 08:34:21 --> Helper loaded: text_helper
INFO - 2025-12-22 08:34:21 --> Helper loaded: string_helper
INFO - 2025-12-22 08:34:21 --> Helper loaded: form_helper
INFO - 2025-12-22 08:34:21 --> Helper loaded: download_helper
INFO - 2025-12-22 08:34:21 --> Helper loaded: security_helper
INFO - 2025-12-22 08:34:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 08:34:21 --> Database Driver Class Initialized
DEBUG - 2025-12-22 08:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 08:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 08:34:22 --> Form Validation Class Initialized
INFO - 2025-12-22 08:34:22 --> Model "User_model" initialized
INFO - 2025-12-22 14:34:22 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 14:34:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 14:34:22 --> Model "Nav_model" initialized
INFO - 2025-12-22 14:34:22 --> Controller Class Initialized
INFO - 2025-12-22 14:34:22 --> Model "Berita_model" initialized
INFO - 2025-12-22 14:34:22 --> Model "Galeri_model" initialized
INFO - 2025-12-22 14:34:23 --> Model "Video_model" initialized
INFO - 2025-12-22 14:34:23 --> Model "Agenda_model" initialized
INFO - 2025-12-22 14:34:23 --> Model "Tautan_model" initialized
INFO - 2025-12-22 14:34:23 --> Model "Mitra_model" initialized
INFO - 2025-12-22 14:34:23 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 14:34:23 --> Model "Prodi_model" initialized
INFO - 2025-12-22 14:34:23 --> Model "Testimoni_model" initialized
INFO - 2025-12-22 14:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-22 14:34:24 --> Pagination Class Initialized
INFO - 2025-12-22 14:34:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-22 14:34:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 14:34:26 --> Model "Log_model" initialized
INFO - 2025-12-22 14:34:26 --> Final output sent to browser
DEBUG - 2025-12-22 14:34:26 --> Total execution time: 6.7004
INFO - 2025-12-22 08:34:33 --> Config Class Initialized
INFO - 2025-12-22 08:34:33 --> Hooks Class Initialized
DEBUG - 2025-12-22 08:34:33 --> UTF-8 Support Enabled
INFO - 2025-12-22 08:34:33 --> Utf8 Class Initialized
INFO - 2025-12-22 08:34:33 --> URI Class Initialized
INFO - 2025-12-22 08:34:33 --> Router Class Initialized
INFO - 2025-12-22 08:34:33 --> Output Class Initialized
INFO - 2025-12-22 08:34:33 --> Security Class Initialized
DEBUG - 2025-12-22 08:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 08:34:33 --> CSRF cookie sent
INFO - 2025-12-22 08:34:33 --> Input Class Initialized
INFO - 2025-12-22 08:34:33 --> Language Class Initialized
INFO - 2025-12-22 08:34:33 --> Loader Class Initialized
INFO - 2025-12-22 08:34:33 --> Helper loaded: url_helper
INFO - 2025-12-22 08:34:33 --> Helper loaded: text_helper
INFO - 2025-12-22 08:34:33 --> Helper loaded: string_helper
INFO - 2025-12-22 08:34:33 --> Helper loaded: form_helper
INFO - 2025-12-22 08:34:33 --> Helper loaded: download_helper
INFO - 2025-12-22 08:34:33 --> Helper loaded: security_helper
INFO - 2025-12-22 08:34:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 08:34:33 --> Database Driver Class Initialized
DEBUG - 2025-12-22 08:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 08:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 08:34:33 --> Form Validation Class Initialized
INFO - 2025-12-22 08:34:33 --> Model "User_model" initialized
INFO - 2025-12-22 14:34:33 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 14:34:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 14:34:33 --> Model "Nav_model" initialized
INFO - 2025-12-22 14:34:33 --> Controller Class Initialized
INFO - 2025-12-22 14:34:33 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 14:34:33 --> Model "Prodi_model" initialized
INFO - 2025-12-22 14:34:33 --> Model "Sdm_model" initialized
INFO - 2025-12-22 14:34:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-12-22 14:34:33 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2025-12-22 14:34:34 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-22 14:34:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-22 14:34:34 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2025-12-22 14:34:34 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2025-12-22 14:34:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-12-22 14:34:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 14:34:34 --> Model "Log_model" initialized
INFO - 2025-12-22 14:34:34 --> Final output sent to browser
DEBUG - 2025-12-22 14:34:34 --> Total execution time: 1.6224
INFO - 2025-12-22 08:37:53 --> Config Class Initialized
INFO - 2025-12-22 08:37:53 --> Hooks Class Initialized
DEBUG - 2025-12-22 08:37:53 --> UTF-8 Support Enabled
INFO - 2025-12-22 08:37:53 --> Utf8 Class Initialized
INFO - 2025-12-22 08:37:53 --> URI Class Initialized
INFO - 2025-12-22 08:37:53 --> Router Class Initialized
INFO - 2025-12-22 08:37:53 --> Output Class Initialized
INFO - 2025-12-22 08:37:53 --> Security Class Initialized
DEBUG - 2025-12-22 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-22 08:37:53 --> CSRF cookie sent
INFO - 2025-12-22 08:37:53 --> Input Class Initialized
INFO - 2025-12-22 08:37:53 --> Language Class Initialized
INFO - 2025-12-22 08:37:53 --> Loader Class Initialized
INFO - 2025-12-22 08:37:53 --> Helper loaded: url_helper
INFO - 2025-12-22 08:37:53 --> Helper loaded: text_helper
INFO - 2025-12-22 08:37:53 --> Helper loaded: string_helper
INFO - 2025-12-22 08:37:53 --> Helper loaded: form_helper
INFO - 2025-12-22 08:37:53 --> Helper loaded: download_helper
INFO - 2025-12-22 08:37:53 --> Helper loaded: security_helper
INFO - 2025-12-22 08:37:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-22 08:37:53 --> Database Driver Class Initialized
DEBUG - 2025-12-22 08:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-22 08:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-22 08:37:53 --> Form Validation Class Initialized
INFO - 2025-12-22 08:37:53 --> Model "User_model" initialized
INFO - 2025-12-22 14:37:53 --> Model "Kunjungan_model" initialized
INFO - 2025-12-22 14:37:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-22 14:37:53 --> Model "Nav_model" initialized
INFO - 2025-12-22 14:37:53 --> Controller Class Initialized
INFO - 2025-12-22 14:37:53 --> Model "Jurusan_model" initialized
INFO - 2025-12-22 14:37:53 --> Model "Prodi_model" initialized
INFO - 2025-12-22 14:37:53 --> Model "Sdm_model" initialized
INFO - 2025-12-22 14:37:53 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-12-22 14:37:53 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-12-22 14:37:53 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-22 14:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-22 14:37:53 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2025-12-22 14:37:53 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2025-12-22 14:37:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-12-22 14:37:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-22 14:37:53 --> Model "Log_model" initialized
INFO - 2025-12-22 14:37:53 --> Final output sent to browser
DEBUG - 2025-12-22 14:37:53 --> Total execution time: 0.2003
