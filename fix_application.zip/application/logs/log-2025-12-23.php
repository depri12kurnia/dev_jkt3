<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-12-23 02:37:01 --> Config Class Initialized
INFO - 2025-12-23 02:37:01 --> Hooks Class Initialized
DEBUG - 2025-12-23 02:37:01 --> UTF-8 Support Enabled
INFO - 2025-12-23 02:37:01 --> Utf8 Class Initialized
INFO - 2025-12-23 02:37:01 --> URI Class Initialized
DEBUG - 2025-12-23 02:37:01 --> No URI present. Default controller set.
INFO - 2025-12-23 02:37:01 --> Router Class Initialized
INFO - 2025-12-23 02:37:01 --> Output Class Initialized
INFO - 2025-12-23 02:37:01 --> Security Class Initialized
DEBUG - 2025-12-23 02:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-23 02:37:01 --> CSRF cookie sent
INFO - 2025-12-23 02:37:01 --> Input Class Initialized
INFO - 2025-12-23 02:37:01 --> Language Class Initialized
INFO - 2025-12-23 02:37:01 --> Loader Class Initialized
INFO - 2025-12-23 02:37:01 --> Helper loaded: url_helper
INFO - 2025-12-23 02:37:02 --> Helper loaded: text_helper
INFO - 2025-12-23 02:37:02 --> Helper loaded: string_helper
INFO - 2025-12-23 02:37:02 --> Helper loaded: form_helper
INFO - 2025-12-23 02:37:02 --> Helper loaded: download_helper
INFO - 2025-12-23 02:37:02 --> Helper loaded: security_helper
INFO - 2025-12-23 02:37:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-23 02:37:02 --> Database Driver Class Initialized
DEBUG - 2025-12-23 02:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-23 02:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-23 02:37:02 --> Form Validation Class Initialized
INFO - 2025-12-23 02:37:02 --> Model "User_model" initialized
INFO - 2025-12-23 08:37:02 --> Model "Kunjungan_model" initialized
INFO - 2025-12-23 08:37:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-23 08:37:03 --> Model "Nav_model" initialized
INFO - 2025-12-23 08:37:03 --> Controller Class Initialized
INFO - 2025-12-23 08:37:03 --> Model "Berita_model" initialized
INFO - 2025-12-23 08:37:03 --> Model "Galeri_model" initialized
INFO - 2025-12-23 08:37:03 --> Model "Video_model" initialized
INFO - 2025-12-23 08:37:03 --> Model "Agenda_model" initialized
INFO - 2025-12-23 08:37:03 --> Model "Tautan_model" initialized
INFO - 2025-12-23 08:37:03 --> Model "Mitra_model" initialized
INFO - 2025-12-23 08:37:03 --> Model "Jurusan_model" initialized
INFO - 2025-12-23 08:37:03 --> Model "Prodi_model" initialized
INFO - 2025-12-23 08:37:03 --> Model "Testimoni_model" initialized
INFO - 2025-12-23 08:37:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-23 08:37:03 --> Pagination Class Initialized
INFO - 2025-12-23 08:37:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-23 08:37:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-23 08:37:05 --> Model "Log_model" initialized
INFO - 2025-12-23 08:37:05 --> Final output sent to browser
DEBUG - 2025-12-23 08:37:05 --> Total execution time: 3.9127
INFO - 2025-12-23 02:38:44 --> Config Class Initialized
INFO - 2025-12-23 02:38:44 --> Hooks Class Initialized
DEBUG - 2025-12-23 02:38:44 --> UTF-8 Support Enabled
INFO - 2025-12-23 02:38:44 --> Utf8 Class Initialized
INFO - 2025-12-23 02:38:44 --> URI Class Initialized
INFO - 2025-12-23 02:38:44 --> Router Class Initialized
INFO - 2025-12-23 02:38:44 --> Output Class Initialized
INFO - 2025-12-23 02:38:44 --> Security Class Initialized
DEBUG - 2025-12-23 02:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-23 02:38:44 --> CSRF cookie sent
INFO - 2025-12-23 02:38:44 --> Input Class Initialized
INFO - 2025-12-23 02:38:44 --> Language Class Initialized
INFO - 2025-12-23 02:38:44 --> Loader Class Initialized
INFO - 2025-12-23 02:38:44 --> Helper loaded: url_helper
INFO - 2025-12-23 02:38:44 --> Helper loaded: text_helper
INFO - 2025-12-23 02:38:44 --> Helper loaded: string_helper
INFO - 2025-12-23 02:38:44 --> Helper loaded: form_helper
INFO - 2025-12-23 02:38:44 --> Helper loaded: download_helper
INFO - 2025-12-23 02:38:44 --> Helper loaded: security_helper
INFO - 2025-12-23 02:38:44 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-23 02:38:44 --> Database Driver Class Initialized
DEBUG - 2025-12-23 02:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-23 02:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-23 02:38:44 --> Form Validation Class Initialized
INFO - 2025-12-23 02:38:44 --> Model "User_model" initialized
INFO - 2025-12-23 08:38:44 --> Model "Kunjungan_model" initialized
INFO - 2025-12-23 08:38:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-23 08:38:44 --> Model "Nav_model" initialized
INFO - 2025-12-23 08:38:44 --> Controller Class Initialized
INFO - 2025-12-23 08:38:44 --> Model "Jurusan_model" initialized
INFO - 2025-12-23 08:38:44 --> Model "Prodi_model" initialized
INFO - 2025-12-23 08:38:44 --> Model "Sdm_model" initialized
INFO - 2025-12-23 08:38:44 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-12-23 08:38:44 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2025-12-23 08:38:45 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-23 08:38:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-23 08:38:46 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2025-12-23 08:38:46 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2025-12-23 08:38:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-12-23 08:38:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-23 08:38:46 --> Model "Log_model" initialized
INFO - 2025-12-23 08:38:46 --> Final output sent to browser
DEBUG - 2025-12-23 08:38:46 --> Total execution time: 1.8716
INFO - 2025-12-23 02:39:03 --> Config Class Initialized
INFO - 2025-12-23 02:39:03 --> Hooks Class Initialized
DEBUG - 2025-12-23 02:39:03 --> UTF-8 Support Enabled
INFO - 2025-12-23 02:39:03 --> Utf8 Class Initialized
INFO - 2025-12-23 02:39:03 --> URI Class Initialized
DEBUG - 2025-12-23 02:39:03 --> No URI present. Default controller set.
INFO - 2025-12-23 02:39:03 --> Router Class Initialized
INFO - 2025-12-23 02:39:03 --> Output Class Initialized
INFO - 2025-12-23 02:39:03 --> Security Class Initialized
DEBUG - 2025-12-23 02:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-23 02:39:03 --> CSRF cookie sent
INFO - 2025-12-23 02:39:03 --> Input Class Initialized
INFO - 2025-12-23 02:39:03 --> Language Class Initialized
INFO - 2025-12-23 02:39:03 --> Loader Class Initialized
INFO - 2025-12-23 02:39:03 --> Helper loaded: url_helper
INFO - 2025-12-23 02:39:03 --> Helper loaded: text_helper
INFO - 2025-12-23 02:39:03 --> Helper loaded: string_helper
INFO - 2025-12-23 02:39:03 --> Helper loaded: form_helper
INFO - 2025-12-23 02:39:03 --> Helper loaded: download_helper
INFO - 2025-12-23 02:39:03 --> Helper loaded: security_helper
INFO - 2025-12-23 02:39:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-23 02:39:03 --> Database Driver Class Initialized
DEBUG - 2025-12-23 02:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-23 02:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-23 02:39:03 --> Form Validation Class Initialized
INFO - 2025-12-23 02:39:03 --> Model "User_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Kunjungan_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Nav_model" initialized
INFO - 2025-12-23 08:39:03 --> Controller Class Initialized
INFO - 2025-12-23 08:39:03 --> Model "Berita_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Galeri_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Video_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Agenda_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Tautan_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Mitra_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Jurusan_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Prodi_model" initialized
INFO - 2025-12-23 08:39:03 --> Model "Testimoni_model" initialized
INFO - 2025-12-23 08:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-23 08:39:03 --> Pagination Class Initialized
INFO - 2025-12-23 08:39:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-23 08:39:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-23 08:39:03 --> Model "Log_model" initialized
INFO - 2025-12-23 08:39:03 --> Final output sent to browser
DEBUG - 2025-12-23 08:39:03 --> Total execution time: 0.2124
INFO - 2025-12-23 08:52:20 --> Config Class Initialized
INFO - 2025-12-23 08:52:20 --> Hooks Class Initialized
DEBUG - 2025-12-23 08:52:21 --> UTF-8 Support Enabled
INFO - 2025-12-23 08:52:21 --> Utf8 Class Initialized
INFO - 2025-12-23 08:52:21 --> URI Class Initialized
DEBUG - 2025-12-23 08:52:21 --> No URI present. Default controller set.
INFO - 2025-12-23 08:52:21 --> Router Class Initialized
INFO - 2025-12-23 08:52:21 --> Output Class Initialized
INFO - 2025-12-23 08:52:21 --> Security Class Initialized
DEBUG - 2025-12-23 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-23 08:52:21 --> CSRF cookie sent
INFO - 2025-12-23 08:52:21 --> Input Class Initialized
INFO - 2025-12-23 08:52:21 --> Language Class Initialized
INFO - 2025-12-23 08:52:21 --> Loader Class Initialized
INFO - 2025-12-23 08:52:22 --> Helper loaded: url_helper
INFO - 2025-12-23 08:52:22 --> Helper loaded: text_helper
INFO - 2025-12-23 08:52:22 --> Helper loaded: string_helper
INFO - 2025-12-23 08:52:22 --> Helper loaded: form_helper
INFO - 2025-12-23 08:52:22 --> Helper loaded: download_helper
INFO - 2025-12-23 08:52:22 --> Helper loaded: security_helper
INFO - 2025-12-23 08:52:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-23 08:52:22 --> Database Driver Class Initialized
DEBUG - 2025-12-23 08:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-23 08:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-23 08:52:23 --> Form Validation Class Initialized
INFO - 2025-12-23 08:52:23 --> Model "User_model" initialized
INFO - 2025-12-23 14:52:24 --> Model "Kunjungan_model" initialized
INFO - 2025-12-23 14:52:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-23 14:52:24 --> Model "Nav_model" initialized
INFO - 2025-12-23 14:52:24 --> Controller Class Initialized
INFO - 2025-12-23 14:52:24 --> Model "Berita_model" initialized
INFO - 2025-12-23 14:52:24 --> Model "Galeri_model" initialized
INFO - 2025-12-23 14:52:24 --> Model "Video_model" initialized
INFO - 2025-12-23 14:52:24 --> Model "Agenda_model" initialized
INFO - 2025-12-23 14:52:25 --> Model "Tautan_model" initialized
INFO - 2025-12-23 14:52:25 --> Model "Mitra_model" initialized
INFO - 2025-12-23 14:52:25 --> Model "Jurusan_model" initialized
INFO - 2025-12-23 14:52:25 --> Model "Prodi_model" initialized
INFO - 2025-12-23 14:52:25 --> Model "Testimoni_model" initialized
INFO - 2025-12-23 14:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-23 14:52:26 --> Pagination Class Initialized
INFO - 2025-12-23 14:52:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-23 14:52:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-23 14:52:31 --> Model "Log_model" initialized
INFO - 2025-12-23 14:52:31 --> Final output sent to browser
DEBUG - 2025-12-23 14:52:31 --> Total execution time: 10.2286
