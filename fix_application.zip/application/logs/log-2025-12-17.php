<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-12-17 08:17:14 --> Config Class Initialized
INFO - 2025-12-17 08:17:14 --> Hooks Class Initialized
DEBUG - 2025-12-17 08:17:14 --> UTF-8 Support Enabled
INFO - 2025-12-17 08:17:14 --> Utf8 Class Initialized
INFO - 2025-12-17 08:17:14 --> URI Class Initialized
DEBUG - 2025-12-17 08:17:15 --> No URI present. Default controller set.
INFO - 2025-12-17 08:17:15 --> Router Class Initialized
INFO - 2025-12-17 08:17:15 --> Output Class Initialized
INFO - 2025-12-17 08:17:15 --> Security Class Initialized
DEBUG - 2025-12-17 08:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-17 08:17:15 --> CSRF cookie sent
INFO - 2025-12-17 08:17:15 --> Input Class Initialized
INFO - 2025-12-17 08:17:15 --> Language Class Initialized
INFO - 2025-12-17 08:17:15 --> Loader Class Initialized
INFO - 2025-12-17 08:17:15 --> Helper loaded: url_helper
INFO - 2025-12-17 08:17:15 --> Helper loaded: text_helper
INFO - 2025-12-17 08:17:15 --> Helper loaded: string_helper
INFO - 2025-12-17 08:17:15 --> Helper loaded: form_helper
INFO - 2025-12-17 08:17:15 --> Helper loaded: download_helper
INFO - 2025-12-17 08:17:15 --> Helper loaded: security_helper
INFO - 2025-12-17 08:17:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-17 08:17:16 --> Database Driver Class Initialized
DEBUG - 2025-12-17 08:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-17 08:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-17 08:17:16 --> Form Validation Class Initialized
INFO - 2025-12-17 08:17:16 --> Model "User_model" initialized
INFO - 2025-12-17 14:17:16 --> Model "Kunjungan_model" initialized
INFO - 2025-12-17 14:17:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-17 14:17:17 --> Model "Nav_model" initialized
INFO - 2025-12-17 14:17:17 --> Controller Class Initialized
INFO - 2025-12-17 14:17:17 --> Model "Berita_model" initialized
INFO - 2025-12-17 14:17:17 --> Model "Galeri_model" initialized
INFO - 2025-12-17 14:17:17 --> Model "Video_model" initialized
INFO - 2025-12-17 14:17:17 --> Model "Agenda_model" initialized
INFO - 2025-12-17 14:17:17 --> Model "Tautan_model" initialized
INFO - 2025-12-17 14:17:17 --> Model "Mitra_model" initialized
INFO - 2025-12-17 14:17:17 --> Model "Jurusan_model" initialized
INFO - 2025-12-17 14:17:17 --> Model "Prodi_model" initialized
INFO - 2025-12-17 14:17:17 --> Model "Testimoni_model" initialized
INFO - 2025-12-17 14:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-17 14:17:18 --> Pagination Class Initialized
INFO - 2025-12-17 14:17:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-17 14:17:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-17 14:17:21 --> Model "Log_model" initialized
INFO - 2025-12-17 14:17:21 --> Final output sent to browser
DEBUG - 2025-12-17 14:17:21 --> Total execution time: 6.9352
INFO - 2025-12-17 08:17:42 --> Config Class Initialized
INFO - 2025-12-17 08:17:42 --> Hooks Class Initialized
DEBUG - 2025-12-17 08:17:42 --> UTF-8 Support Enabled
INFO - 2025-12-17 08:17:42 --> Utf8 Class Initialized
INFO - 2025-12-17 08:17:42 --> URI Class Initialized
INFO - 2025-12-17 08:17:42 --> Router Class Initialized
INFO - 2025-12-17 08:17:42 --> Output Class Initialized
INFO - 2025-12-17 08:17:42 --> Security Class Initialized
DEBUG - 2025-12-17 08:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-17 08:17:42 --> CSRF cookie sent
INFO - 2025-12-17 08:17:42 --> Input Class Initialized
INFO - 2025-12-17 08:17:42 --> Language Class Initialized
INFO - 2025-12-17 08:17:42 --> Loader Class Initialized
INFO - 2025-12-17 08:17:42 --> Helper loaded: url_helper
INFO - 2025-12-17 08:17:42 --> Helper loaded: text_helper
INFO - 2025-12-17 08:17:42 --> Helper loaded: string_helper
INFO - 2025-12-17 08:17:42 --> Helper loaded: form_helper
INFO - 2025-12-17 08:17:42 --> Helper loaded: download_helper
INFO - 2025-12-17 08:17:42 --> Helper loaded: security_helper
INFO - 2025-12-17 08:17:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-17 08:17:42 --> Database Driver Class Initialized
DEBUG - 2025-12-17 08:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-17 08:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-17 08:17:42 --> Form Validation Class Initialized
INFO - 2025-12-17 08:17:42 --> Model "User_model" initialized
INFO - 2025-12-17 14:17:42 --> Model "Kunjungan_model" initialized
INFO - 2025-12-17 14:17:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-17 14:17:42 --> Model "Nav_model" initialized
INFO - 2025-12-17 14:17:42 --> Controller Class Initialized
INFO - 2025-12-17 14:17:42 --> Model "Jurusan_model" initialized
INFO - 2025-12-17 14:17:42 --> Model "Prodi_model" initialized
INFO - 2025-12-17 14:17:42 --> Model "Sdm_model" initialized
INFO - 2025-12-17 14:17:42 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-12-17 14:17:42 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2025-12-17 14:17:42 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-17 14:17:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-17 14:17:43 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2025-12-17 14:17:43 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2025-12-17 14:17:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-12-17 14:17:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-17 14:17:43 --> Model "Log_model" initialized
INFO - 2025-12-17 14:17:43 --> Final output sent to browser
DEBUG - 2025-12-17 14:17:43 --> Total execution time: 1.8277
