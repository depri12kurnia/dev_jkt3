<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-27 02:47:20 --> Config Class Initialized
INFO - 2026-01-27 02:47:20 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:47:20 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:47:20 --> Utf8 Class Initialized
INFO - 2026-01-27 02:47:20 --> URI Class Initialized
DEBUG - 2026-01-27 02:47:20 --> No URI present. Default controller set.
INFO - 2026-01-27 02:47:20 --> Router Class Initialized
INFO - 2026-01-27 02:47:21 --> Output Class Initialized
INFO - 2026-01-27 02:47:21 --> Security Class Initialized
DEBUG - 2026-01-27 02:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:47:21 --> CSRF cookie sent
INFO - 2026-01-27 02:47:21 --> Input Class Initialized
INFO - 2026-01-27 02:47:21 --> Language Class Initialized
INFO - 2026-01-27 02:47:21 --> Loader Class Initialized
INFO - 2026-01-27 02:47:21 --> Helper loaded: url_helper
INFO - 2026-01-27 02:47:21 --> Helper loaded: text_helper
INFO - 2026-01-27 02:47:21 --> Helper loaded: string_helper
INFO - 2026-01-27 02:47:21 --> Helper loaded: form_helper
INFO - 2026-01-27 02:47:21 --> Helper loaded: download_helper
INFO - 2026-01-27 02:47:21 --> Helper loaded: security_helper
INFO - 2026-01-27 02:47:21 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:47:22 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:47:22 --> Form Validation Class Initialized
INFO - 2026-01-27 02:47:22 --> Model "User_model" initialized
INFO - 2026-01-27 08:47:22 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:47:23 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:47:23 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:47:23 --> Controller Class Initialized
INFO - 2026-01-27 08:47:23 --> Model "Berita_model" initialized
INFO - 2026-01-27 08:47:23 --> Model "Galeri_model" initialized
INFO - 2026-01-27 08:47:23 --> Model "Video_model" initialized
INFO - 2026-01-27 08:47:23 --> Model "Agenda_model" initialized
INFO - 2026-01-27 08:47:23 --> Model "Tautan_model" initialized
INFO - 2026-01-27 08:47:23 --> Model "Mitra_model" initialized
INFO - 2026-01-27 08:47:23 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:47:23 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:47:23 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 08:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 08:47:24 --> Pagination Class Initialized
INFO - 2026-01-27 08:47:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 08:47:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:47:27 --> Model "Log_model" initialized
INFO - 2026-01-27 08:47:27 --> Final output sent to browser
DEBUG - 2026-01-27 08:47:27 --> Total execution time: 7.1214
INFO - 2026-01-27 02:47:45 --> Config Class Initialized
INFO - 2026-01-27 02:47:45 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:47:45 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:47:45 --> Utf8 Class Initialized
INFO - 2026-01-27 02:47:45 --> URI Class Initialized
INFO - 2026-01-27 02:47:45 --> Router Class Initialized
INFO - 2026-01-27 02:47:45 --> Output Class Initialized
INFO - 2026-01-27 02:47:45 --> Security Class Initialized
DEBUG - 2026-01-27 02:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:47:45 --> CSRF cookie sent
INFO - 2026-01-27 02:47:45 --> Input Class Initialized
INFO - 2026-01-27 02:47:45 --> Language Class Initialized
INFO - 2026-01-27 02:47:45 --> Loader Class Initialized
INFO - 2026-01-27 02:47:45 --> Helper loaded: url_helper
INFO - 2026-01-27 02:47:45 --> Helper loaded: text_helper
INFO - 2026-01-27 02:47:45 --> Helper loaded: string_helper
INFO - 2026-01-27 02:47:45 --> Helper loaded: form_helper
INFO - 2026-01-27 02:47:45 --> Helper loaded: download_helper
INFO - 2026-01-27 02:47:45 --> Helper loaded: security_helper
INFO - 2026-01-27 02:47:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:47:45 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:47:45 --> Form Validation Class Initialized
INFO - 2026-01-27 02:47:45 --> Model "User_model" initialized
INFO - 2026-01-27 08:47:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:47:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:47:45 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:47:45 --> Controller Class Initialized
INFO - 2026-01-27 08:47:45 --> Model "Pages_model" initialized
INFO - 2026-01-27 08:47:45 --> Model "Berita_model" initialized
INFO - 2026-01-27 08:47:46 --> Model "Download_model" initialized
INFO - 2026-01-27 08:47:46 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 08:47:46 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 08:47:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-27 08:47:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:47:46 --> Model "Log_model" initialized
INFO - 2026-01-27 08:47:46 --> Final output sent to browser
DEBUG - 2026-01-27 08:47:46 --> Total execution time: 0.6193
INFO - 2026-01-27 02:48:50 --> Config Class Initialized
INFO - 2026-01-27 02:48:50 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:48:50 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:48:50 --> Utf8 Class Initialized
INFO - 2026-01-27 02:48:50 --> URI Class Initialized
INFO - 2026-01-27 02:48:50 --> Router Class Initialized
INFO - 2026-01-27 02:48:50 --> Output Class Initialized
INFO - 2026-01-27 02:48:50 --> Security Class Initialized
DEBUG - 2026-01-27 02:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:48:50 --> CSRF cookie sent
INFO - 2026-01-27 02:48:50 --> Input Class Initialized
INFO - 2026-01-27 02:48:50 --> Language Class Initialized
INFO - 2026-01-27 02:48:50 --> Loader Class Initialized
INFO - 2026-01-27 02:48:50 --> Helper loaded: url_helper
INFO - 2026-01-27 02:48:50 --> Helper loaded: text_helper
INFO - 2026-01-27 02:48:50 --> Helper loaded: string_helper
INFO - 2026-01-27 02:48:50 --> Helper loaded: form_helper
INFO - 2026-01-27 02:48:50 --> Helper loaded: download_helper
INFO - 2026-01-27 02:48:50 --> Helper loaded: security_helper
INFO - 2026-01-27 02:48:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:48:50 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:48:50 --> Form Validation Class Initialized
INFO - 2026-01-27 02:48:50 --> Model "User_model" initialized
INFO - 2026-01-27 08:48:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:48:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:48:50 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:48:50 --> Controller Class Initialized
INFO - 2026-01-27 08:48:50 --> Model "Pages_model" initialized
INFO - 2026-01-27 08:48:50 --> Model "Berita_model" initialized
INFO - 2026-01-27 08:48:50 --> Model "Download_model" initialized
INFO - 2026-01-27 08:48:50 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 08:48:51 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 08:48:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-27 08:48:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:48:51 --> Model "Log_model" initialized
INFO - 2026-01-27 08:48:51 --> Final output sent to browser
DEBUG - 2026-01-27 08:48:51 --> Total execution time: 0.2354
INFO - 2026-01-27 02:49:05 --> Config Class Initialized
INFO - 2026-01-27 02:49:05 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:49:05 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:49:05 --> Utf8 Class Initialized
INFO - 2026-01-27 02:49:05 --> URI Class Initialized
INFO - 2026-01-27 02:49:05 --> Router Class Initialized
INFO - 2026-01-27 02:49:05 --> Output Class Initialized
INFO - 2026-01-27 02:49:05 --> Security Class Initialized
DEBUG - 2026-01-27 02:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:49:05 --> CSRF cookie sent
INFO - 2026-01-27 02:49:05 --> Input Class Initialized
INFO - 2026-01-27 02:49:05 --> Language Class Initialized
INFO - 2026-01-27 02:49:05 --> Loader Class Initialized
INFO - 2026-01-27 02:49:05 --> Helper loaded: url_helper
INFO - 2026-01-27 02:49:05 --> Helper loaded: text_helper
INFO - 2026-01-27 02:49:05 --> Helper loaded: string_helper
INFO - 2026-01-27 02:49:05 --> Helper loaded: form_helper
INFO - 2026-01-27 02:49:05 --> Helper loaded: download_helper
INFO - 2026-01-27 02:49:05 --> Helper loaded: security_helper
INFO - 2026-01-27 02:49:05 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:49:05 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:49:05 --> Form Validation Class Initialized
INFO - 2026-01-27 02:49:05 --> Model "User_model" initialized
INFO - 2026-01-27 08:49:05 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:49:05 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:49:05 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:49:05 --> Controller Class Initialized
INFO - 2026-01-27 08:49:05 --> Model "Pages_model" initialized
INFO - 2026-01-27 08:49:05 --> Model "Berita_model" initialized
INFO - 2026-01-27 08:49:05 --> Model "Download_model" initialized
INFO - 2026-01-27 08:49:05 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 08:49:05 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 08:49:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-27 08:49:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:49:05 --> Model "Log_model" initialized
INFO - 2026-01-27 08:49:05 --> Final output sent to browser
DEBUG - 2026-01-27 08:49:05 --> Total execution time: 0.2209
INFO - 2026-01-27 02:49:33 --> Config Class Initialized
INFO - 2026-01-27 02:49:33 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:49:33 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:49:33 --> Utf8 Class Initialized
INFO - 2026-01-27 02:49:33 --> URI Class Initialized
INFO - 2026-01-27 02:49:33 --> Router Class Initialized
INFO - 2026-01-27 02:49:33 --> Output Class Initialized
INFO - 2026-01-27 02:49:33 --> Security Class Initialized
DEBUG - 2026-01-27 02:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:49:33 --> CSRF cookie sent
INFO - 2026-01-27 02:49:33 --> Input Class Initialized
INFO - 2026-01-27 02:49:33 --> Language Class Initialized
INFO - 2026-01-27 02:49:33 --> Loader Class Initialized
INFO - 2026-01-27 02:49:33 --> Helper loaded: url_helper
INFO - 2026-01-27 02:49:33 --> Helper loaded: text_helper
INFO - 2026-01-27 02:49:33 --> Helper loaded: string_helper
INFO - 2026-01-27 02:49:33 --> Helper loaded: form_helper
INFO - 2026-01-27 02:49:33 --> Helper loaded: download_helper
INFO - 2026-01-27 02:49:33 --> Helper loaded: security_helper
INFO - 2026-01-27 02:49:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:49:33 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:49:33 --> Form Validation Class Initialized
INFO - 2026-01-27 02:49:33 --> Model "User_model" initialized
INFO - 2026-01-27 08:49:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:49:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:49:33 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:49:33 --> Controller Class Initialized
INFO - 2026-01-27 08:49:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:49:33 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:49:33 --> Model "Sdm_model" initialized
INFO - 2026-01-27 08:49:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 08:49:33 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 08:49:34 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 08:49:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 08:49:36 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 08:49:36 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 08:49:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 08:49:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:49:36 --> Model "Log_model" initialized
INFO - 2026-01-27 08:49:36 --> Final output sent to browser
DEBUG - 2026-01-27 08:49:36 --> Total execution time: 2.4297
INFO - 2026-01-27 02:49:50 --> Config Class Initialized
INFO - 2026-01-27 02:49:50 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:49:50 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:49:50 --> Utf8 Class Initialized
INFO - 2026-01-27 02:49:50 --> URI Class Initialized
INFO - 2026-01-27 02:49:50 --> Router Class Initialized
INFO - 2026-01-27 02:49:50 --> Output Class Initialized
INFO - 2026-01-27 02:49:50 --> Security Class Initialized
DEBUG - 2026-01-27 02:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:49:50 --> CSRF cookie sent
INFO - 2026-01-27 02:49:50 --> Input Class Initialized
INFO - 2026-01-27 02:49:50 --> Language Class Initialized
INFO - 2026-01-27 02:49:50 --> Loader Class Initialized
INFO - 2026-01-27 02:49:50 --> Helper loaded: url_helper
INFO - 2026-01-27 02:49:50 --> Helper loaded: text_helper
INFO - 2026-01-27 02:49:50 --> Helper loaded: string_helper
INFO - 2026-01-27 02:49:50 --> Helper loaded: form_helper
INFO - 2026-01-27 02:49:50 --> Helper loaded: download_helper
INFO - 2026-01-27 02:49:50 --> Helper loaded: security_helper
INFO - 2026-01-27 02:49:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:49:50 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:49:50 --> Form Validation Class Initialized
INFO - 2026-01-27 02:49:50 --> Model "User_model" initialized
INFO - 2026-01-27 08:49:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:49:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:49:50 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:49:50 --> Controller Class Initialized
DEBUG - 2026-01-27 08:49:50 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 08:49:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-27 08:49:50 --> Model "Log_model" initialized
INFO - 2026-01-27 08:49:50 --> Final output sent to browser
DEBUG - 2026-01-27 08:49:50 --> Total execution time: 0.3763
INFO - 2026-01-27 02:51:29 --> Config Class Initialized
INFO - 2026-01-27 02:51:29 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:51:29 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:51:29 --> Utf8 Class Initialized
INFO - 2026-01-27 02:51:29 --> URI Class Initialized
INFO - 2026-01-27 02:51:29 --> Router Class Initialized
INFO - 2026-01-27 02:51:29 --> Output Class Initialized
INFO - 2026-01-27 02:51:29 --> Security Class Initialized
DEBUG - 2026-01-27 02:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:51:29 --> CSRF cookie sent
INFO - 2026-01-27 02:51:29 --> CSRF token verified
INFO - 2026-01-27 02:51:29 --> Input Class Initialized
INFO - 2026-01-27 02:51:29 --> Language Class Initialized
INFO - 2026-01-27 02:51:29 --> Loader Class Initialized
INFO - 2026-01-27 02:51:29 --> Helper loaded: url_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: text_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: string_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: form_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: download_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: security_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:51:29 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:51:29 --> Form Validation Class Initialized
INFO - 2026-01-27 02:51:29 --> Model "User_model" initialized
INFO - 2026-01-27 08:51:29 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:51:29 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:51:29 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:51:29 --> Controller Class Initialized
DEBUG - 2026-01-27 08:51:29 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 08:51:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 02:51:29 --> Config Class Initialized
INFO - 2026-01-27 02:51:29 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:51:29 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:51:29 --> Utf8 Class Initialized
INFO - 2026-01-27 02:51:29 --> URI Class Initialized
INFO - 2026-01-27 02:51:29 --> Router Class Initialized
INFO - 2026-01-27 02:51:29 --> Output Class Initialized
INFO - 2026-01-27 02:51:29 --> Security Class Initialized
DEBUG - 2026-01-27 02:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:51:29 --> CSRF cookie sent
INFO - 2026-01-27 02:51:29 --> Input Class Initialized
INFO - 2026-01-27 02:51:29 --> Language Class Initialized
INFO - 2026-01-27 02:51:29 --> Loader Class Initialized
INFO - 2026-01-27 02:51:29 --> Helper loaded: url_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: text_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: string_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: form_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: download_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: security_helper
INFO - 2026-01-27 02:51:29 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:51:29 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:51:29 --> Form Validation Class Initialized
INFO - 2026-01-27 02:51:29 --> Model "User_model" initialized
INFO - 2026-01-27 08:51:29 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:51:29 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:51:29 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:51:29 --> Controller Class Initialized
DEBUG - 2026-01-27 08:51:29 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 08:51:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-27 08:51:29 --> Model "Log_model" initialized
INFO - 2026-01-27 08:51:29 --> Final output sent to browser
DEBUG - 2026-01-27 08:51:29 --> Total execution time: 0.1521
INFO - 2026-01-27 02:51:38 --> Config Class Initialized
INFO - 2026-01-27 02:51:38 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:51:38 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:51:38 --> Utf8 Class Initialized
INFO - 2026-01-27 02:51:38 --> URI Class Initialized
INFO - 2026-01-27 02:51:38 --> Router Class Initialized
INFO - 2026-01-27 02:51:38 --> Output Class Initialized
INFO - 2026-01-27 02:51:38 --> Security Class Initialized
DEBUG - 2026-01-27 02:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:51:38 --> CSRF cookie sent
INFO - 2026-01-27 02:51:38 --> CSRF token verified
INFO - 2026-01-27 02:51:38 --> Input Class Initialized
INFO - 2026-01-27 02:51:38 --> Language Class Initialized
INFO - 2026-01-27 02:51:38 --> Loader Class Initialized
INFO - 2026-01-27 02:51:38 --> Helper loaded: url_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: text_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: string_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: form_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: download_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: security_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:51:38 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:51:38 --> Form Validation Class Initialized
INFO - 2026-01-27 02:51:38 --> Model "User_model" initialized
INFO - 2026-01-27 08:51:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:51:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:51:38 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:51:38 --> Controller Class Initialized
DEBUG - 2026-01-27 08:51:38 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 08:51:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 02:51:38 --> Config Class Initialized
INFO - 2026-01-27 02:51:38 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:51:38 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:51:38 --> Utf8 Class Initialized
INFO - 2026-01-27 02:51:38 --> URI Class Initialized
INFO - 2026-01-27 02:51:38 --> Router Class Initialized
INFO - 2026-01-27 02:51:38 --> Output Class Initialized
INFO - 2026-01-27 02:51:38 --> Security Class Initialized
DEBUG - 2026-01-27 02:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:51:38 --> CSRF cookie sent
INFO - 2026-01-27 02:51:38 --> Input Class Initialized
INFO - 2026-01-27 02:51:38 --> Language Class Initialized
INFO - 2026-01-27 02:51:38 --> Loader Class Initialized
INFO - 2026-01-27 02:51:38 --> Helper loaded: url_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: text_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: string_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: form_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: download_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: security_helper
INFO - 2026-01-27 02:51:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:51:38 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:51:38 --> Form Validation Class Initialized
INFO - 2026-01-27 02:51:38 --> Model "User_model" initialized
INFO - 2026-01-27 08:51:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:51:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:51:38 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:51:38 --> Controller Class Initialized
DEBUG - 2026-01-27 08:51:38 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 08:51:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-27 08:51:38 --> Model "Log_model" initialized
INFO - 2026-01-27 08:51:38 --> Final output sent to browser
DEBUG - 2026-01-27 08:51:38 --> Total execution time: 0.1692
INFO - 2026-01-27 02:51:47 --> Config Class Initialized
INFO - 2026-01-27 02:51:47 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:51:47 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:51:47 --> Utf8 Class Initialized
INFO - 2026-01-27 02:51:47 --> URI Class Initialized
INFO - 2026-01-27 02:51:47 --> Router Class Initialized
INFO - 2026-01-27 02:51:47 --> Output Class Initialized
INFO - 2026-01-27 02:51:47 --> Security Class Initialized
DEBUG - 2026-01-27 02:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:51:47 --> CSRF cookie sent
INFO - 2026-01-27 02:51:47 --> CSRF token verified
INFO - 2026-01-27 02:51:47 --> Input Class Initialized
INFO - 2026-01-27 02:51:47 --> Language Class Initialized
INFO - 2026-01-27 02:51:47 --> Loader Class Initialized
INFO - 2026-01-27 02:51:47 --> Helper loaded: url_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: text_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: string_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: form_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: download_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: security_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:51:47 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:51:47 --> Form Validation Class Initialized
INFO - 2026-01-27 02:51:47 --> Model "User_model" initialized
INFO - 2026-01-27 08:51:47 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:51:47 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:51:47 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:51:47 --> Controller Class Initialized
DEBUG - 2026-01-27 08:51:47 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 08:51:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 02:51:47 --> Config Class Initialized
INFO - 2026-01-27 02:51:47 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:51:47 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:51:47 --> Utf8 Class Initialized
INFO - 2026-01-27 02:51:47 --> URI Class Initialized
INFO - 2026-01-27 02:51:47 --> Router Class Initialized
INFO - 2026-01-27 02:51:47 --> Output Class Initialized
INFO - 2026-01-27 02:51:47 --> Security Class Initialized
DEBUG - 2026-01-27 02:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:51:47 --> CSRF cookie sent
INFO - 2026-01-27 02:51:47 --> Input Class Initialized
INFO - 2026-01-27 02:51:47 --> Language Class Initialized
INFO - 2026-01-27 02:51:47 --> Loader Class Initialized
INFO - 2026-01-27 02:51:47 --> Helper loaded: url_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: text_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: string_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: form_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: download_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: security_helper
INFO - 2026-01-27 02:51:47 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:51:47 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:51:47 --> Form Validation Class Initialized
INFO - 2026-01-27 02:51:47 --> Model "User_model" initialized
INFO - 2026-01-27 08:51:47 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:51:47 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:51:47 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:51:47 --> Controller Class Initialized
INFO - 2026-01-27 08:51:47 --> Model "Tautan_model" initialized
INFO - 2026-01-27 08:51:47 --> Model "Staff_model" initialized
INFO - 2026-01-27 08:51:47 --> Model "Dasbor_model" initialized
INFO - 2026-01-27 08:51:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2026-01-27 08:51:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 08:51:48 --> Model "Log_model" initialized
INFO - 2026-01-27 08:51:48 --> Final output sent to browser
DEBUG - 2026-01-27 08:51:48 --> Total execution time: 1.0153
INFO - 2026-01-27 02:51:58 --> Config Class Initialized
INFO - 2026-01-27 02:51:58 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:51:58 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:51:58 --> Utf8 Class Initialized
INFO - 2026-01-27 02:51:58 --> URI Class Initialized
INFO - 2026-01-27 02:51:58 --> Router Class Initialized
INFO - 2026-01-27 02:51:58 --> Output Class Initialized
INFO - 2026-01-27 02:51:58 --> Security Class Initialized
DEBUG - 2026-01-27 02:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:51:58 --> CSRF cookie sent
INFO - 2026-01-27 02:51:58 --> Input Class Initialized
INFO - 2026-01-27 02:51:58 --> Language Class Initialized
INFO - 2026-01-27 02:51:58 --> Loader Class Initialized
INFO - 2026-01-27 02:51:58 --> Helper loaded: url_helper
INFO - 2026-01-27 02:51:58 --> Helper loaded: text_helper
INFO - 2026-01-27 02:51:58 --> Helper loaded: string_helper
INFO - 2026-01-27 02:51:58 --> Helper loaded: form_helper
INFO - 2026-01-27 02:51:58 --> Helper loaded: download_helper
INFO - 2026-01-27 02:51:58 --> Helper loaded: security_helper
INFO - 2026-01-27 02:51:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:51:58 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:51:58 --> Form Validation Class Initialized
INFO - 2026-01-27 02:51:58 --> Model "User_model" initialized
INFO - 2026-01-27 08:51:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:51:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:51:58 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:51:58 --> Controller Class Initialized
INFO - 2026-01-27 08:51:58 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:51:58 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:51:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 08:51:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 08:51:58 --> Model "Log_model" initialized
INFO - 2026-01-27 08:51:58 --> Final output sent to browser
DEBUG - 2026-01-27 08:51:58 --> Total execution time: 0.2336
INFO - 2026-01-27 02:52:04 --> Config Class Initialized
INFO - 2026-01-27 02:52:04 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:52:04 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:52:04 --> Utf8 Class Initialized
INFO - 2026-01-27 02:52:04 --> URI Class Initialized
DEBUG - 2026-01-27 02:52:04 --> No URI present. Default controller set.
INFO - 2026-01-27 02:52:04 --> Router Class Initialized
INFO - 2026-01-27 02:52:04 --> Output Class Initialized
INFO - 2026-01-27 02:52:04 --> Security Class Initialized
DEBUG - 2026-01-27 02:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:52:04 --> CSRF cookie sent
INFO - 2026-01-27 02:52:04 --> Input Class Initialized
INFO - 2026-01-27 02:52:04 --> Language Class Initialized
INFO - 2026-01-27 02:52:04 --> Loader Class Initialized
INFO - 2026-01-27 02:52:04 --> Helper loaded: url_helper
INFO - 2026-01-27 02:52:04 --> Helper loaded: text_helper
INFO - 2026-01-27 02:52:04 --> Helper loaded: string_helper
INFO - 2026-01-27 02:52:04 --> Helper loaded: form_helper
INFO - 2026-01-27 02:52:04 --> Helper loaded: download_helper
INFO - 2026-01-27 02:52:04 --> Helper loaded: security_helper
INFO - 2026-01-27 02:52:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:52:04 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:52:04 --> Form Validation Class Initialized
INFO - 2026-01-27 02:52:04 --> Model "User_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:52:04 --> Controller Class Initialized
INFO - 2026-01-27 08:52:04 --> Model "Berita_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Galeri_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Video_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Agenda_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Tautan_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Mitra_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:52:04 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 08:52:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 08:52:04 --> Pagination Class Initialized
INFO - 2026-01-27 08:52:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 08:52:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:52:05 --> Model "Log_model" initialized
INFO - 2026-01-27 08:52:05 --> Final output sent to browser
DEBUG - 2026-01-27 08:52:05 --> Total execution time: 0.3351
INFO - 2026-01-27 02:52:12 --> Config Class Initialized
INFO - 2026-01-27 02:52:12 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:52:12 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:52:12 --> Utf8 Class Initialized
INFO - 2026-01-27 02:52:12 --> URI Class Initialized
INFO - 2026-01-27 02:52:12 --> Router Class Initialized
INFO - 2026-01-27 02:52:12 --> Output Class Initialized
INFO - 2026-01-27 02:52:12 --> Security Class Initialized
DEBUG - 2026-01-27 02:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:52:12 --> CSRF cookie sent
INFO - 2026-01-27 02:52:12 --> Input Class Initialized
INFO - 2026-01-27 02:52:12 --> Language Class Initialized
INFO - 2026-01-27 02:52:12 --> Loader Class Initialized
INFO - 2026-01-27 02:52:12 --> Helper loaded: url_helper
INFO - 2026-01-27 02:52:12 --> Helper loaded: text_helper
INFO - 2026-01-27 02:52:12 --> Helper loaded: string_helper
INFO - 2026-01-27 02:52:12 --> Helper loaded: form_helper
INFO - 2026-01-27 02:52:12 --> Helper loaded: download_helper
INFO - 2026-01-27 02:52:12 --> Helper loaded: security_helper
INFO - 2026-01-27 02:52:12 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:52:12 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:52:12 --> Form Validation Class Initialized
INFO - 2026-01-27 02:52:12 --> Model "User_model" initialized
INFO - 2026-01-27 08:52:12 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:52:12 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:52:12 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:52:12 --> Controller Class Initialized
INFO - 2026-01-27 08:52:12 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:52:12 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:52:12 --> Model "Sdm_model" initialized
INFO - 2026-01-27 08:52:12 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 08:52:12 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 08:52:12 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 08:52:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 08:52:12 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 08:52:12 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 08:52:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 08:52:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:52:12 --> Model "Log_model" initialized
INFO - 2026-01-27 08:52:12 --> Final output sent to browser
DEBUG - 2026-01-27 08:52:12 --> Total execution time: 0.2709
INFO - 2026-01-27 02:53:34 --> Config Class Initialized
INFO - 2026-01-27 02:53:34 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:53:34 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:53:34 --> Utf8 Class Initialized
INFO - 2026-01-27 02:53:34 --> URI Class Initialized
INFO - 2026-01-27 02:53:34 --> Router Class Initialized
INFO - 2026-01-27 02:53:34 --> Output Class Initialized
INFO - 2026-01-27 02:53:34 --> Security Class Initialized
DEBUG - 2026-01-27 02:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:53:34 --> CSRF cookie sent
INFO - 2026-01-27 02:53:34 --> Input Class Initialized
INFO - 2026-01-27 02:53:34 --> Language Class Initialized
INFO - 2026-01-27 02:53:34 --> Loader Class Initialized
INFO - 2026-01-27 02:53:34 --> Helper loaded: url_helper
INFO - 2026-01-27 02:53:34 --> Helper loaded: text_helper
INFO - 2026-01-27 02:53:34 --> Helper loaded: string_helper
INFO - 2026-01-27 02:53:34 --> Helper loaded: form_helper
INFO - 2026-01-27 02:53:34 --> Helper loaded: download_helper
INFO - 2026-01-27 02:53:34 --> Helper loaded: security_helper
INFO - 2026-01-27 02:53:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:53:34 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:53:34 --> Form Validation Class Initialized
INFO - 2026-01-27 02:53:34 --> Model "User_model" initialized
INFO - 2026-01-27 08:53:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:53:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:53:34 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:53:34 --> Controller Class Initialized
INFO - 2026-01-27 08:53:34 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:53:34 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:53:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 08:53:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 08:53:34 --> Model "Log_model" initialized
INFO - 2026-01-27 08:53:34 --> Final output sent to browser
DEBUG - 2026-01-27 08:53:34 --> Total execution time: 0.1549
INFO - 2026-01-27 02:56:03 --> Config Class Initialized
INFO - 2026-01-27 02:56:03 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:56:03 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:56:03 --> Utf8 Class Initialized
INFO - 2026-01-27 02:56:03 --> URI Class Initialized
INFO - 2026-01-27 02:56:03 --> Router Class Initialized
INFO - 2026-01-27 02:56:03 --> Output Class Initialized
INFO - 2026-01-27 02:56:03 --> Security Class Initialized
DEBUG - 2026-01-27 02:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:56:03 --> CSRF cookie sent
INFO - 2026-01-27 02:56:03 --> CSRF token verified
INFO - 2026-01-27 02:56:03 --> Input Class Initialized
INFO - 2026-01-27 02:56:03 --> Language Class Initialized
INFO - 2026-01-27 02:56:03 --> Loader Class Initialized
INFO - 2026-01-27 02:56:03 --> Helper loaded: url_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: text_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: string_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: form_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: download_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: security_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:56:03 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:56:03 --> Form Validation Class Initialized
INFO - 2026-01-27 02:56:03 --> Model "User_model" initialized
INFO - 2026-01-27 08:56:03 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:56:03 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:56:03 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:56:03 --> Controller Class Initialized
INFO - 2026-01-27 08:56:03 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:56:03 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:56:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 02:56:03 --> Config Class Initialized
INFO - 2026-01-27 02:56:03 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:56:03 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:56:03 --> Utf8 Class Initialized
INFO - 2026-01-27 02:56:03 --> URI Class Initialized
INFO - 2026-01-27 02:56:03 --> Router Class Initialized
INFO - 2026-01-27 02:56:03 --> Output Class Initialized
INFO - 2026-01-27 02:56:03 --> Security Class Initialized
DEBUG - 2026-01-27 02:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:56:03 --> CSRF cookie sent
INFO - 2026-01-27 02:56:03 --> Input Class Initialized
INFO - 2026-01-27 02:56:03 --> Language Class Initialized
INFO - 2026-01-27 02:56:03 --> Loader Class Initialized
INFO - 2026-01-27 02:56:03 --> Helper loaded: url_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: text_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: string_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: form_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: download_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: security_helper
INFO - 2026-01-27 02:56:03 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:56:03 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:56:03 --> Form Validation Class Initialized
INFO - 2026-01-27 02:56:03 --> Model "User_model" initialized
INFO - 2026-01-27 08:56:03 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:56:03 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:56:03 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:56:03 --> Controller Class Initialized
INFO - 2026-01-27 08:56:03 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:56:03 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:56:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 08:56:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 08:56:03 --> Model "Log_model" initialized
INFO - 2026-01-27 08:56:03 --> Final output sent to browser
DEBUG - 2026-01-27 08:56:03 --> Total execution time: 0.1347
INFO - 2026-01-27 02:56:06 --> Config Class Initialized
INFO - 2026-01-27 02:56:06 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:56:06 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:56:06 --> Utf8 Class Initialized
INFO - 2026-01-27 02:56:06 --> URI Class Initialized
INFO - 2026-01-27 02:56:06 --> Router Class Initialized
INFO - 2026-01-27 02:56:06 --> Output Class Initialized
INFO - 2026-01-27 02:56:06 --> Security Class Initialized
DEBUG - 2026-01-27 02:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:56:06 --> CSRF cookie sent
INFO - 2026-01-27 02:56:06 --> Input Class Initialized
INFO - 2026-01-27 02:56:06 --> Language Class Initialized
INFO - 2026-01-27 02:56:06 --> Loader Class Initialized
INFO - 2026-01-27 02:56:06 --> Helper loaded: url_helper
INFO - 2026-01-27 02:56:06 --> Helper loaded: text_helper
INFO - 2026-01-27 02:56:06 --> Helper loaded: string_helper
INFO - 2026-01-27 02:56:06 --> Helper loaded: form_helper
INFO - 2026-01-27 02:56:06 --> Helper loaded: download_helper
INFO - 2026-01-27 02:56:06 --> Helper loaded: security_helper
INFO - 2026-01-27 02:56:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:56:06 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:56:06 --> Form Validation Class Initialized
INFO - 2026-01-27 02:56:06 --> Model "User_model" initialized
INFO - 2026-01-27 08:56:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:56:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:56:06 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:56:06 --> Controller Class Initialized
INFO - 2026-01-27 08:56:06 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:56:06 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:56:06 --> Model "Sdm_model" initialized
INFO - 2026-01-27 08:56:06 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 08:56:06 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 08:56:06 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 08:56:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 08:56:06 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 08:56:06 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 08:56:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 08:56:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:56:06 --> Model "Log_model" initialized
INFO - 2026-01-27 08:56:06 --> Final output sent to browser
DEBUG - 2026-01-27 08:56:06 --> Total execution time: 0.1940
INFO - 2026-01-27 02:56:33 --> Config Class Initialized
INFO - 2026-01-27 02:56:33 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:56:33 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:56:33 --> Utf8 Class Initialized
INFO - 2026-01-27 02:56:33 --> URI Class Initialized
INFO - 2026-01-27 02:56:33 --> Router Class Initialized
INFO - 2026-01-27 02:56:33 --> Output Class Initialized
INFO - 2026-01-27 02:56:33 --> Security Class Initialized
DEBUG - 2026-01-27 02:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:56:33 --> CSRF cookie sent
INFO - 2026-01-27 02:56:33 --> Input Class Initialized
INFO - 2026-01-27 02:56:33 --> Language Class Initialized
INFO - 2026-01-27 02:56:33 --> Loader Class Initialized
INFO - 2026-01-27 02:56:33 --> Helper loaded: url_helper
INFO - 2026-01-27 02:56:33 --> Helper loaded: text_helper
INFO - 2026-01-27 02:56:33 --> Helper loaded: string_helper
INFO - 2026-01-27 02:56:33 --> Helper loaded: form_helper
INFO - 2026-01-27 02:56:33 --> Helper loaded: download_helper
INFO - 2026-01-27 02:56:33 --> Helper loaded: security_helper
INFO - 2026-01-27 02:56:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:56:33 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:56:33 --> Form Validation Class Initialized
INFO - 2026-01-27 02:56:33 --> Model "User_model" initialized
INFO - 2026-01-27 08:56:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:56:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:56:33 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:56:33 --> Controller Class Initialized
INFO - 2026-01-27 08:56:33 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:56:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:56:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 08:56:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 08:56:33 --> Model "Log_model" initialized
INFO - 2026-01-27 08:56:33 --> Final output sent to browser
DEBUG - 2026-01-27 08:56:33 --> Total execution time: 0.1504
INFO - 2026-01-27 02:56:44 --> Config Class Initialized
INFO - 2026-01-27 02:56:44 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:56:44 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:56:44 --> Utf8 Class Initialized
INFO - 2026-01-27 02:56:44 --> URI Class Initialized
INFO - 2026-01-27 02:56:44 --> Router Class Initialized
INFO - 2026-01-27 02:56:44 --> Output Class Initialized
INFO - 2026-01-27 02:56:44 --> Security Class Initialized
DEBUG - 2026-01-27 02:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:56:44 --> CSRF cookie sent
INFO - 2026-01-27 02:56:44 --> Input Class Initialized
INFO - 2026-01-27 02:56:44 --> Language Class Initialized
INFO - 2026-01-27 02:56:44 --> Loader Class Initialized
INFO - 2026-01-27 02:56:44 --> Helper loaded: url_helper
INFO - 2026-01-27 02:56:44 --> Helper loaded: text_helper
INFO - 2026-01-27 02:56:44 --> Helper loaded: string_helper
INFO - 2026-01-27 02:56:44 --> Helper loaded: form_helper
INFO - 2026-01-27 02:56:44 --> Helper loaded: download_helper
INFO - 2026-01-27 02:56:44 --> Helper loaded: security_helper
INFO - 2026-01-27 02:56:44 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:56:44 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:56:44 --> Form Validation Class Initialized
INFO - 2026-01-27 02:56:44 --> Model "User_model" initialized
INFO - 2026-01-27 08:56:44 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:56:44 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:56:44 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:56:44 --> Controller Class Initialized
INFO - 2026-01-27 08:56:44 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:56:44 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:56:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 08:56:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 08:56:44 --> Model "Log_model" initialized
INFO - 2026-01-27 08:56:44 --> Final output sent to browser
DEBUG - 2026-01-27 08:56:44 --> Total execution time: 0.1269
INFO - 2026-01-27 02:56:48 --> Config Class Initialized
INFO - 2026-01-27 02:56:48 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:56:48 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:56:48 --> Utf8 Class Initialized
INFO - 2026-01-27 02:56:48 --> URI Class Initialized
INFO - 2026-01-27 02:56:48 --> Router Class Initialized
INFO - 2026-01-27 02:56:48 --> Output Class Initialized
INFO - 2026-01-27 02:56:48 --> Security Class Initialized
DEBUG - 2026-01-27 02:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:56:48 --> CSRF cookie sent
INFO - 2026-01-27 02:56:48 --> Input Class Initialized
INFO - 2026-01-27 02:56:48 --> Language Class Initialized
INFO - 2026-01-27 02:56:48 --> Loader Class Initialized
INFO - 2026-01-27 02:56:48 --> Helper loaded: url_helper
INFO - 2026-01-27 02:56:48 --> Helper loaded: text_helper
INFO - 2026-01-27 02:56:48 --> Helper loaded: string_helper
INFO - 2026-01-27 02:56:48 --> Helper loaded: form_helper
INFO - 2026-01-27 02:56:48 --> Helper loaded: download_helper
INFO - 2026-01-27 02:56:48 --> Helper loaded: security_helper
INFO - 2026-01-27 02:56:48 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:56:48 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:56:48 --> Form Validation Class Initialized
INFO - 2026-01-27 02:56:48 --> Model "User_model" initialized
INFO - 2026-01-27 08:56:48 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:56:48 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:56:48 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:56:48 --> Controller Class Initialized
INFO - 2026-01-27 08:56:48 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:56:48 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:56:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 08:56:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 08:56:48 --> Model "Log_model" initialized
INFO - 2026-01-27 08:56:48 --> Final output sent to browser
DEBUG - 2026-01-27 08:56:48 --> Total execution time: 0.1246
INFO - 2026-01-27 02:57:53 --> Config Class Initialized
INFO - 2026-01-27 02:57:53 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:57:53 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:57:53 --> Utf8 Class Initialized
INFO - 2026-01-27 02:57:53 --> URI Class Initialized
INFO - 2026-01-27 02:57:53 --> Router Class Initialized
INFO - 2026-01-27 02:57:53 --> Output Class Initialized
INFO - 2026-01-27 02:57:53 --> Security Class Initialized
DEBUG - 2026-01-27 02:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:57:53 --> CSRF cookie sent
INFO - 2026-01-27 02:57:53 --> CSRF token verified
INFO - 2026-01-27 02:57:53 --> Input Class Initialized
INFO - 2026-01-27 02:57:53 --> Language Class Initialized
INFO - 2026-01-27 02:57:53 --> Loader Class Initialized
INFO - 2026-01-27 02:57:53 --> Helper loaded: url_helper
INFO - 2026-01-27 02:57:53 --> Helper loaded: text_helper
INFO - 2026-01-27 02:57:53 --> Helper loaded: string_helper
INFO - 2026-01-27 02:57:53 --> Helper loaded: form_helper
INFO - 2026-01-27 02:57:53 --> Helper loaded: download_helper
INFO - 2026-01-27 02:57:53 --> Helper loaded: security_helper
INFO - 2026-01-27 02:57:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:57:53 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:57:53 --> Form Validation Class Initialized
INFO - 2026-01-27 02:57:53 --> Model "User_model" initialized
INFO - 2026-01-27 08:57:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:57:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:57:53 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:57:53 --> Controller Class Initialized
INFO - 2026-01-27 08:57:53 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:57:53 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:57:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 02:57:54 --> Config Class Initialized
INFO - 2026-01-27 02:57:54 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:57:54 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:57:54 --> Utf8 Class Initialized
INFO - 2026-01-27 02:57:54 --> URI Class Initialized
INFO - 2026-01-27 02:57:54 --> Router Class Initialized
INFO - 2026-01-27 02:57:54 --> Output Class Initialized
INFO - 2026-01-27 02:57:54 --> Security Class Initialized
DEBUG - 2026-01-27 02:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:57:54 --> CSRF cookie sent
INFO - 2026-01-27 02:57:54 --> Input Class Initialized
INFO - 2026-01-27 02:57:54 --> Language Class Initialized
INFO - 2026-01-27 02:57:54 --> Loader Class Initialized
INFO - 2026-01-27 02:57:54 --> Helper loaded: url_helper
INFO - 2026-01-27 02:57:54 --> Helper loaded: text_helper
INFO - 2026-01-27 02:57:54 --> Helper loaded: string_helper
INFO - 2026-01-27 02:57:54 --> Helper loaded: form_helper
INFO - 2026-01-27 02:57:54 --> Helper loaded: download_helper
INFO - 2026-01-27 02:57:54 --> Helper loaded: security_helper
INFO - 2026-01-27 02:57:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:57:54 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:57:54 --> Form Validation Class Initialized
INFO - 2026-01-27 02:57:54 --> Model "User_model" initialized
INFO - 2026-01-27 08:57:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:57:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:57:54 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:57:54 --> Controller Class Initialized
INFO - 2026-01-27 08:57:54 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:57:54 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:57:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 08:57:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 08:57:54 --> Model "Log_model" initialized
INFO - 2026-01-27 08:57:54 --> Final output sent to browser
DEBUG - 2026-01-27 08:57:54 --> Total execution time: 0.0965
INFO - 2026-01-27 02:57:56 --> Config Class Initialized
INFO - 2026-01-27 02:57:56 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:57:56 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:57:56 --> Utf8 Class Initialized
INFO - 2026-01-27 02:57:56 --> URI Class Initialized
INFO - 2026-01-27 02:57:56 --> Router Class Initialized
INFO - 2026-01-27 02:57:56 --> Output Class Initialized
INFO - 2026-01-27 02:57:56 --> Security Class Initialized
DEBUG - 2026-01-27 02:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:57:56 --> CSRF cookie sent
INFO - 2026-01-27 02:57:56 --> Input Class Initialized
INFO - 2026-01-27 02:57:56 --> Language Class Initialized
INFO - 2026-01-27 02:57:56 --> Loader Class Initialized
INFO - 2026-01-27 02:57:56 --> Helper loaded: url_helper
INFO - 2026-01-27 02:57:56 --> Helper loaded: text_helper
INFO - 2026-01-27 02:57:56 --> Helper loaded: string_helper
INFO - 2026-01-27 02:57:56 --> Helper loaded: form_helper
INFO - 2026-01-27 02:57:56 --> Helper loaded: download_helper
INFO - 2026-01-27 02:57:56 --> Helper loaded: security_helper
INFO - 2026-01-27 02:57:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:57:56 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:57:56 --> Form Validation Class Initialized
INFO - 2026-01-27 02:57:57 --> Model "User_model" initialized
INFO - 2026-01-27 08:57:57 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:57:57 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:57:57 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:57:57 --> Controller Class Initialized
INFO - 2026-01-27 08:57:57 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:57:57 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:57:57 --> Model "Sdm_model" initialized
INFO - 2026-01-27 08:57:57 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 08:57:57 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 08:57:57 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 08:57:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 08:57:57 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 08:57:57 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 08:57:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 08:57:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:57:57 --> Model "Log_model" initialized
INFO - 2026-01-27 08:57:57 --> Final output sent to browser
DEBUG - 2026-01-27 08:57:57 --> Total execution time: 0.3010
INFO - 2026-01-27 02:59:14 --> Config Class Initialized
INFO - 2026-01-27 02:59:14 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:59:14 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:59:14 --> Utf8 Class Initialized
INFO - 2026-01-27 02:59:14 --> URI Class Initialized
INFO - 2026-01-27 02:59:14 --> Router Class Initialized
INFO - 2026-01-27 02:59:14 --> Output Class Initialized
INFO - 2026-01-27 02:59:14 --> Security Class Initialized
DEBUG - 2026-01-27 02:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:59:14 --> CSRF cookie sent
INFO - 2026-01-27 02:59:14 --> Input Class Initialized
INFO - 2026-01-27 02:59:14 --> Language Class Initialized
INFO - 2026-01-27 02:59:14 --> Loader Class Initialized
INFO - 2026-01-27 02:59:14 --> Helper loaded: url_helper
INFO - 2026-01-27 02:59:14 --> Helper loaded: text_helper
INFO - 2026-01-27 02:59:14 --> Helper loaded: string_helper
INFO - 2026-01-27 02:59:14 --> Helper loaded: form_helper
INFO - 2026-01-27 02:59:14 --> Helper loaded: download_helper
INFO - 2026-01-27 02:59:14 --> Helper loaded: security_helper
INFO - 2026-01-27 02:59:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:59:14 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:59:14 --> Form Validation Class Initialized
INFO - 2026-01-27 02:59:14 --> Model "User_model" initialized
INFO - 2026-01-27 08:59:14 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:59:14 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:59:14 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:59:14 --> Controller Class Initialized
INFO - 2026-01-27 08:59:14 --> Model "Sdm_model" initialized
INFO - 2026-01-27 08:59:14 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 08:59:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2026-01-27 08:59:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:59:14 --> Model "Log_model" initialized
INFO - 2026-01-27 08:59:14 --> Final output sent to browser
DEBUG - 2026-01-27 08:59:14 --> Total execution time: 0.1652
INFO - 2026-01-27 02:59:17 --> Config Class Initialized
INFO - 2026-01-27 02:59:17 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:59:17 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:59:17 --> Utf8 Class Initialized
INFO - 2026-01-27 02:59:17 --> URI Class Initialized
INFO - 2026-01-27 02:59:17 --> Router Class Initialized
INFO - 2026-01-27 02:59:17 --> Output Class Initialized
INFO - 2026-01-27 02:59:17 --> Security Class Initialized
DEBUG - 2026-01-27 02:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:59:17 --> CSRF cookie sent
INFO - 2026-01-27 02:59:17 --> Input Class Initialized
INFO - 2026-01-27 02:59:17 --> Language Class Initialized
INFO - 2026-01-27 02:59:17 --> Loader Class Initialized
INFO - 2026-01-27 02:59:17 --> Helper loaded: url_helper
INFO - 2026-01-27 02:59:17 --> Helper loaded: text_helper
INFO - 2026-01-27 02:59:17 --> Helper loaded: string_helper
INFO - 2026-01-27 02:59:17 --> Helper loaded: form_helper
INFO - 2026-01-27 02:59:17 --> Helper loaded: download_helper
INFO - 2026-01-27 02:59:17 --> Helper loaded: security_helper
INFO - 2026-01-27 02:59:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:59:17 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:59:17 --> Form Validation Class Initialized
INFO - 2026-01-27 02:59:17 --> Model "User_model" initialized
INFO - 2026-01-27 08:59:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:59:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:59:17 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:59:17 --> Controller Class Initialized
INFO - 2026-01-27 08:59:17 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:59:17 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:59:17 --> Model "Sdm_model" initialized
INFO - 2026-01-27 08:59:17 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 08:59:17 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 08:59:17 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 08:59:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 08:59:17 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 08:59:17 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 08:59:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 08:59:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 08:59:17 --> Model "Log_model" initialized
INFO - 2026-01-27 08:59:17 --> Final output sent to browser
DEBUG - 2026-01-27 08:59:17 --> Total execution time: 0.1800
INFO - 2026-01-27 02:59:44 --> Config Class Initialized
INFO - 2026-01-27 02:59:44 --> Hooks Class Initialized
DEBUG - 2026-01-27 02:59:44 --> UTF-8 Support Enabled
INFO - 2026-01-27 02:59:44 --> Utf8 Class Initialized
INFO - 2026-01-27 02:59:44 --> URI Class Initialized
INFO - 2026-01-27 02:59:44 --> Router Class Initialized
INFO - 2026-01-27 02:59:44 --> Output Class Initialized
INFO - 2026-01-27 02:59:44 --> Security Class Initialized
DEBUG - 2026-01-27 02:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 02:59:44 --> CSRF cookie sent
INFO - 2026-01-27 02:59:44 --> Input Class Initialized
INFO - 2026-01-27 02:59:44 --> Language Class Initialized
INFO - 2026-01-27 02:59:44 --> Loader Class Initialized
INFO - 2026-01-27 02:59:44 --> Helper loaded: url_helper
INFO - 2026-01-27 02:59:44 --> Helper loaded: text_helper
INFO - 2026-01-27 02:59:44 --> Helper loaded: string_helper
INFO - 2026-01-27 02:59:44 --> Helper loaded: form_helper
INFO - 2026-01-27 02:59:44 --> Helper loaded: download_helper
INFO - 2026-01-27 02:59:44 --> Helper loaded: security_helper
INFO - 2026-01-27 02:59:44 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 02:59:44 --> Database Driver Class Initialized
DEBUG - 2026-01-27 02:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 02:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 02:59:44 --> Form Validation Class Initialized
INFO - 2026-01-27 02:59:44 --> Model "User_model" initialized
INFO - 2026-01-27 08:59:44 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 08:59:44 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 08:59:44 --> Model "Nav_model" initialized
INFO - 2026-01-27 08:59:44 --> Controller Class Initialized
INFO - 2026-01-27 08:59:44 --> Model "Prodi_model" initialized
INFO - 2026-01-27 08:59:44 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 08:59:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 08:59:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 08:59:44 --> Model "Log_model" initialized
INFO - 2026-01-27 08:59:44 --> Final output sent to browser
DEBUG - 2026-01-27 08:59:44 --> Total execution time: 0.1500
INFO - 2026-01-27 03:04:11 --> Config Class Initialized
INFO - 2026-01-27 03:04:11 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:04:11 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:04:11 --> Utf8 Class Initialized
INFO - 2026-01-27 03:04:11 --> URI Class Initialized
INFO - 2026-01-27 03:04:11 --> Router Class Initialized
INFO - 2026-01-27 03:04:11 --> Output Class Initialized
INFO - 2026-01-27 03:04:11 --> Security Class Initialized
DEBUG - 2026-01-27 03:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:04:11 --> CSRF cookie sent
INFO - 2026-01-27 03:04:11 --> CSRF token verified
INFO - 2026-01-27 03:04:11 --> Input Class Initialized
INFO - 2026-01-27 03:04:11 --> Language Class Initialized
INFO - 2026-01-27 03:04:11 --> Loader Class Initialized
INFO - 2026-01-27 03:04:11 --> Helper loaded: url_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: text_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: string_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: form_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: download_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: security_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:04:11 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:04:11 --> Form Validation Class Initialized
INFO - 2026-01-27 03:04:11 --> Model "User_model" initialized
INFO - 2026-01-27 09:04:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:04:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:04:11 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:04:11 --> Controller Class Initialized
INFO - 2026-01-27 09:04:11 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:04:11 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:04:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 03:04:11 --> Config Class Initialized
INFO - 2026-01-27 03:04:11 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:04:11 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:04:11 --> Utf8 Class Initialized
INFO - 2026-01-27 03:04:11 --> URI Class Initialized
INFO - 2026-01-27 03:04:11 --> Router Class Initialized
INFO - 2026-01-27 03:04:11 --> Output Class Initialized
INFO - 2026-01-27 03:04:11 --> Security Class Initialized
DEBUG - 2026-01-27 03:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:04:11 --> CSRF cookie sent
INFO - 2026-01-27 03:04:11 --> Input Class Initialized
INFO - 2026-01-27 03:04:11 --> Language Class Initialized
INFO - 2026-01-27 03:04:11 --> Loader Class Initialized
INFO - 2026-01-27 03:04:11 --> Helper loaded: url_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: text_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: string_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: form_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: download_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: security_helper
INFO - 2026-01-27 03:04:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:04:11 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:04:11 --> Form Validation Class Initialized
INFO - 2026-01-27 03:04:11 --> Model "User_model" initialized
INFO - 2026-01-27 09:04:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:04:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:04:11 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:04:11 --> Controller Class Initialized
INFO - 2026-01-27 09:04:11 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:04:11 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:04:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 09:04:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:04:11 --> Model "Log_model" initialized
INFO - 2026-01-27 09:04:11 --> Final output sent to browser
DEBUG - 2026-01-27 09:04:11 --> Total execution time: 0.1018
INFO - 2026-01-27 03:04:14 --> Config Class Initialized
INFO - 2026-01-27 03:04:14 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:04:14 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:04:14 --> Utf8 Class Initialized
INFO - 2026-01-27 03:04:14 --> URI Class Initialized
INFO - 2026-01-27 03:04:14 --> Router Class Initialized
INFO - 2026-01-27 03:04:14 --> Output Class Initialized
INFO - 2026-01-27 03:04:14 --> Security Class Initialized
DEBUG - 2026-01-27 03:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:04:14 --> CSRF cookie sent
INFO - 2026-01-27 03:04:14 --> Input Class Initialized
INFO - 2026-01-27 03:04:14 --> Language Class Initialized
INFO - 2026-01-27 03:04:14 --> Loader Class Initialized
INFO - 2026-01-27 03:04:14 --> Helper loaded: url_helper
INFO - 2026-01-27 03:04:14 --> Helper loaded: text_helper
INFO - 2026-01-27 03:04:14 --> Helper loaded: string_helper
INFO - 2026-01-27 03:04:14 --> Helper loaded: form_helper
INFO - 2026-01-27 03:04:14 --> Helper loaded: download_helper
INFO - 2026-01-27 03:04:14 --> Helper loaded: security_helper
INFO - 2026-01-27 03:04:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:04:14 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:04:14 --> Form Validation Class Initialized
INFO - 2026-01-27 03:04:14 --> Model "User_model" initialized
INFO - 2026-01-27 09:04:14 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:04:14 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:04:14 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:04:14 --> Controller Class Initialized
INFO - 2026-01-27 09:04:14 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:04:14 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:04:14 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:04:14 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:04:14 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 09:04:14 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:04:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:04:14 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:04:14 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:04:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:04:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:04:14 --> Model "Log_model" initialized
INFO - 2026-01-27 09:04:14 --> Final output sent to browser
DEBUG - 2026-01-27 09:04:14 --> Total execution time: 0.1757
INFO - 2026-01-27 03:04:30 --> Config Class Initialized
INFO - 2026-01-27 03:04:30 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:04:30 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:04:30 --> Utf8 Class Initialized
INFO - 2026-01-27 03:04:30 --> URI Class Initialized
INFO - 2026-01-27 03:04:30 --> Router Class Initialized
INFO - 2026-01-27 03:04:30 --> Output Class Initialized
INFO - 2026-01-27 03:04:30 --> Security Class Initialized
DEBUG - 2026-01-27 03:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:04:30 --> CSRF cookie sent
INFO - 2026-01-27 03:04:30 --> Input Class Initialized
INFO - 2026-01-27 03:04:30 --> Language Class Initialized
INFO - 2026-01-27 03:04:30 --> Loader Class Initialized
INFO - 2026-01-27 03:04:30 --> Helper loaded: url_helper
INFO - 2026-01-27 03:04:30 --> Helper loaded: text_helper
INFO - 2026-01-27 03:04:30 --> Helper loaded: string_helper
INFO - 2026-01-27 03:04:30 --> Helper loaded: form_helper
INFO - 2026-01-27 03:04:30 --> Helper loaded: download_helper
INFO - 2026-01-27 03:04:30 --> Helper loaded: security_helper
INFO - 2026-01-27 03:04:30 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:04:30 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:04:30 --> Form Validation Class Initialized
INFO - 2026-01-27 03:04:30 --> Model "User_model" initialized
INFO - 2026-01-27 09:04:30 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:04:30 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:04:30 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:04:30 --> Controller Class Initialized
INFO - 2026-01-27 09:04:30 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:04:30 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:04:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 09:04:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:04:30 --> Model "Log_model" initialized
INFO - 2026-01-27 09:04:30 --> Final output sent to browser
DEBUG - 2026-01-27 09:04:30 --> Total execution time: 0.1630
INFO - 2026-01-27 03:04:53 --> Config Class Initialized
INFO - 2026-01-27 03:04:53 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:04:53 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:04:53 --> Utf8 Class Initialized
INFO - 2026-01-27 03:04:53 --> URI Class Initialized
INFO - 2026-01-27 03:04:53 --> Router Class Initialized
INFO - 2026-01-27 03:04:53 --> Output Class Initialized
INFO - 2026-01-27 03:04:53 --> Security Class Initialized
DEBUG - 2026-01-27 03:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:04:53 --> CSRF cookie sent
INFO - 2026-01-27 03:04:53 --> CSRF token verified
INFO - 2026-01-27 03:04:53 --> Input Class Initialized
INFO - 2026-01-27 03:04:53 --> Language Class Initialized
INFO - 2026-01-27 03:04:53 --> Loader Class Initialized
INFO - 2026-01-27 03:04:53 --> Helper loaded: url_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: text_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: string_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: form_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: download_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: security_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:04:53 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:04:53 --> Form Validation Class Initialized
INFO - 2026-01-27 03:04:53 --> Model "User_model" initialized
INFO - 2026-01-27 09:04:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:04:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:04:53 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:04:53 --> Controller Class Initialized
INFO - 2026-01-27 09:04:53 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:04:53 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:04:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 03:04:53 --> Config Class Initialized
INFO - 2026-01-27 03:04:53 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:04:53 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:04:53 --> Utf8 Class Initialized
INFO - 2026-01-27 03:04:53 --> URI Class Initialized
INFO - 2026-01-27 03:04:53 --> Router Class Initialized
INFO - 2026-01-27 03:04:53 --> Output Class Initialized
INFO - 2026-01-27 03:04:53 --> Security Class Initialized
DEBUG - 2026-01-27 03:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:04:53 --> CSRF cookie sent
INFO - 2026-01-27 03:04:53 --> Input Class Initialized
INFO - 2026-01-27 03:04:53 --> Language Class Initialized
INFO - 2026-01-27 03:04:53 --> Loader Class Initialized
INFO - 2026-01-27 03:04:53 --> Helper loaded: url_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: text_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: string_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: form_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: download_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: security_helper
INFO - 2026-01-27 03:04:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:04:53 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:04:53 --> Form Validation Class Initialized
INFO - 2026-01-27 03:04:53 --> Model "User_model" initialized
INFO - 2026-01-27 09:04:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:04:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:04:53 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:04:53 --> Controller Class Initialized
INFO - 2026-01-27 09:04:53 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:04:53 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:04:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 09:04:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:04:53 --> Model "Log_model" initialized
INFO - 2026-01-27 09:04:54 --> Final output sent to browser
DEBUG - 2026-01-27 09:04:54 --> Total execution time: 0.1131
INFO - 2026-01-27 03:04:56 --> Config Class Initialized
INFO - 2026-01-27 03:04:56 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:04:56 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:04:56 --> Utf8 Class Initialized
INFO - 2026-01-27 03:04:56 --> URI Class Initialized
INFO - 2026-01-27 03:04:56 --> Router Class Initialized
INFO - 2026-01-27 03:04:56 --> Output Class Initialized
INFO - 2026-01-27 03:04:56 --> Security Class Initialized
DEBUG - 2026-01-27 03:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:04:56 --> CSRF cookie sent
INFO - 2026-01-27 03:04:56 --> Input Class Initialized
INFO - 2026-01-27 03:04:56 --> Language Class Initialized
INFO - 2026-01-27 03:04:56 --> Loader Class Initialized
INFO - 2026-01-27 03:04:56 --> Helper loaded: url_helper
INFO - 2026-01-27 03:04:56 --> Helper loaded: text_helper
INFO - 2026-01-27 03:04:56 --> Helper loaded: string_helper
INFO - 2026-01-27 03:04:56 --> Helper loaded: form_helper
INFO - 2026-01-27 03:04:56 --> Helper loaded: download_helper
INFO - 2026-01-27 03:04:56 --> Helper loaded: security_helper
INFO - 2026-01-27 03:04:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:04:56 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:04:56 --> Form Validation Class Initialized
INFO - 2026-01-27 03:04:56 --> Model "User_model" initialized
INFO - 2026-01-27 09:04:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:04:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:04:56 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:04:56 --> Controller Class Initialized
INFO - 2026-01-27 09:04:56 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:04:56 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:04:56 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:04:56 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:04:56 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 09:04:56 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:04:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:04:56 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:04:56 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:04:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:04:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:04:56 --> Model "Log_model" initialized
INFO - 2026-01-27 09:04:56 --> Final output sent to browser
DEBUG - 2026-01-27 09:04:56 --> Total execution time: 0.1740
INFO - 2026-01-27 03:05:12 --> Config Class Initialized
INFO - 2026-01-27 03:05:12 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:05:12 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:05:12 --> Utf8 Class Initialized
INFO - 2026-01-27 03:05:12 --> URI Class Initialized
INFO - 2026-01-27 03:05:12 --> Router Class Initialized
INFO - 2026-01-27 03:05:12 --> Output Class Initialized
INFO - 2026-01-27 03:05:12 --> Security Class Initialized
DEBUG - 2026-01-27 03:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:05:12 --> CSRF cookie sent
INFO - 2026-01-27 03:05:12 --> Input Class Initialized
INFO - 2026-01-27 03:05:12 --> Language Class Initialized
INFO - 2026-01-27 03:05:12 --> Loader Class Initialized
INFO - 2026-01-27 03:05:12 --> Helper loaded: url_helper
INFO - 2026-01-27 03:05:12 --> Helper loaded: text_helper
INFO - 2026-01-27 03:05:12 --> Helper loaded: string_helper
INFO - 2026-01-27 03:05:12 --> Helper loaded: form_helper
INFO - 2026-01-27 03:05:12 --> Helper loaded: download_helper
INFO - 2026-01-27 03:05:12 --> Helper loaded: security_helper
INFO - 2026-01-27 03:05:12 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:05:12 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:05:12 --> Form Validation Class Initialized
INFO - 2026-01-27 03:05:12 --> Model "User_model" initialized
INFO - 2026-01-27 09:05:12 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:05:12 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:05:12 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:05:12 --> Controller Class Initialized
INFO - 2026-01-27 09:05:12 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:05:12 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:05:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 09:05:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:05:12 --> Model "Log_model" initialized
INFO - 2026-01-27 09:05:12 --> Final output sent to browser
DEBUG - 2026-01-27 09:05:12 --> Total execution time: 0.1392
INFO - 2026-01-27 03:08:13 --> Config Class Initialized
INFO - 2026-01-27 03:08:13 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:08:13 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:08:13 --> Utf8 Class Initialized
INFO - 2026-01-27 03:08:13 --> URI Class Initialized
INFO - 2026-01-27 03:08:13 --> Router Class Initialized
INFO - 2026-01-27 03:08:13 --> Output Class Initialized
INFO - 2026-01-27 03:08:13 --> Security Class Initialized
DEBUG - 2026-01-27 03:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:08:13 --> CSRF cookie sent
INFO - 2026-01-27 03:08:13 --> CSRF token verified
INFO - 2026-01-27 03:08:13 --> Input Class Initialized
INFO - 2026-01-27 03:08:13 --> Language Class Initialized
INFO - 2026-01-27 03:08:13 --> Loader Class Initialized
INFO - 2026-01-27 03:08:13 --> Helper loaded: url_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: text_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: string_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: form_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: download_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: security_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:08:14 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:08:14 --> Form Validation Class Initialized
INFO - 2026-01-27 03:08:14 --> Model "User_model" initialized
INFO - 2026-01-27 09:08:14 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:08:14 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:08:14 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:08:14 --> Controller Class Initialized
INFO - 2026-01-27 09:08:14 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:08:14 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:08:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 03:08:14 --> Config Class Initialized
INFO - 2026-01-27 03:08:14 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:08:14 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:08:14 --> Utf8 Class Initialized
INFO - 2026-01-27 03:08:14 --> URI Class Initialized
INFO - 2026-01-27 03:08:14 --> Router Class Initialized
INFO - 2026-01-27 03:08:14 --> Output Class Initialized
INFO - 2026-01-27 03:08:14 --> Security Class Initialized
DEBUG - 2026-01-27 03:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:08:14 --> CSRF cookie sent
INFO - 2026-01-27 03:08:14 --> Input Class Initialized
INFO - 2026-01-27 03:08:14 --> Language Class Initialized
INFO - 2026-01-27 03:08:14 --> Loader Class Initialized
INFO - 2026-01-27 03:08:14 --> Helper loaded: url_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: text_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: string_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: form_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: download_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: security_helper
INFO - 2026-01-27 03:08:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:08:14 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:08:14 --> Form Validation Class Initialized
INFO - 2026-01-27 03:08:14 --> Model "User_model" initialized
INFO - 2026-01-27 09:08:14 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:08:14 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:08:14 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:08:14 --> Controller Class Initialized
INFO - 2026-01-27 09:08:14 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:08:14 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:08:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 09:08:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:08:14 --> Model "Log_model" initialized
INFO - 2026-01-27 09:08:14 --> Final output sent to browser
DEBUG - 2026-01-27 09:08:14 --> Total execution time: 0.1073
INFO - 2026-01-27 03:08:16 --> Config Class Initialized
INFO - 2026-01-27 03:08:16 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:08:16 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:08:16 --> Utf8 Class Initialized
INFO - 2026-01-27 03:08:16 --> URI Class Initialized
INFO - 2026-01-27 03:08:16 --> Router Class Initialized
INFO - 2026-01-27 03:08:16 --> Output Class Initialized
INFO - 2026-01-27 03:08:16 --> Security Class Initialized
DEBUG - 2026-01-27 03:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:08:16 --> CSRF cookie sent
INFO - 2026-01-27 03:08:16 --> Input Class Initialized
INFO - 2026-01-27 03:08:16 --> Language Class Initialized
INFO - 2026-01-27 03:08:16 --> Loader Class Initialized
INFO - 2026-01-27 03:08:16 --> Helper loaded: url_helper
INFO - 2026-01-27 03:08:16 --> Helper loaded: text_helper
INFO - 2026-01-27 03:08:16 --> Helper loaded: string_helper
INFO - 2026-01-27 03:08:16 --> Helper loaded: form_helper
INFO - 2026-01-27 03:08:16 --> Helper loaded: download_helper
INFO - 2026-01-27 03:08:16 --> Helper loaded: security_helper
INFO - 2026-01-27 03:08:16 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:08:16 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:08:16 --> Form Validation Class Initialized
INFO - 2026-01-27 03:08:16 --> Model "User_model" initialized
INFO - 2026-01-27 09:08:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:08:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:08:16 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:08:16 --> Controller Class Initialized
INFO - 2026-01-27 09:08:16 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:08:16 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:08:16 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:08:16 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:08:16 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 09:08:16 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:08:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:08:16 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:08:16 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:08:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:08:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:08:16 --> Model "Log_model" initialized
INFO - 2026-01-27 09:08:16 --> Final output sent to browser
DEBUG - 2026-01-27 09:08:16 --> Total execution time: 0.1796
INFO - 2026-01-27 03:08:59 --> Config Class Initialized
INFO - 2026-01-27 03:08:59 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:08:59 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:08:59 --> Utf8 Class Initialized
INFO - 2026-01-27 03:08:59 --> URI Class Initialized
INFO - 2026-01-27 03:08:59 --> Router Class Initialized
INFO - 2026-01-27 03:08:59 --> Output Class Initialized
INFO - 2026-01-27 03:08:59 --> Security Class Initialized
DEBUG - 2026-01-27 03:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:08:59 --> CSRF cookie sent
INFO - 2026-01-27 03:08:59 --> Input Class Initialized
INFO - 2026-01-27 03:08:59 --> Language Class Initialized
INFO - 2026-01-27 03:08:59 --> Loader Class Initialized
INFO - 2026-01-27 03:08:59 --> Helper loaded: url_helper
INFO - 2026-01-27 03:08:59 --> Helper loaded: text_helper
INFO - 2026-01-27 03:08:59 --> Helper loaded: string_helper
INFO - 2026-01-27 03:08:59 --> Helper loaded: form_helper
INFO - 2026-01-27 03:08:59 --> Helper loaded: download_helper
INFO - 2026-01-27 03:08:59 --> Helper loaded: security_helper
INFO - 2026-01-27 03:08:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:08:59 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:08:59 --> Form Validation Class Initialized
INFO - 2026-01-27 03:08:59 --> Model "User_model" initialized
INFO - 2026-01-27 09:08:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:08:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:08:59 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:08:59 --> Controller Class Initialized
INFO - 2026-01-27 09:08:59 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:08:59 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:08:59 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:08:59 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:08:59 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-27 09:08:59 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:08:59 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:08:59 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:08:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:08:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:08:59 --> Model "Log_model" initialized
INFO - 2026-01-27 09:08:59 --> Final output sent to browser
DEBUG - 2026-01-27 09:08:59 --> Total execution time: 0.3207
INFO - 2026-01-27 03:09:22 --> Config Class Initialized
INFO - 2026-01-27 03:09:22 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:09:22 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:09:22 --> Utf8 Class Initialized
INFO - 2026-01-27 03:09:22 --> URI Class Initialized
INFO - 2026-01-27 03:09:22 --> Router Class Initialized
INFO - 2026-01-27 03:09:22 --> Output Class Initialized
INFO - 2026-01-27 03:09:22 --> Security Class Initialized
DEBUG - 2026-01-27 03:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:09:22 --> CSRF cookie sent
INFO - 2026-01-27 03:09:22 --> Input Class Initialized
INFO - 2026-01-27 03:09:22 --> Language Class Initialized
INFO - 2026-01-27 03:09:22 --> Loader Class Initialized
INFO - 2026-01-27 03:09:22 --> Helper loaded: url_helper
INFO - 2026-01-27 03:09:22 --> Helper loaded: text_helper
INFO - 2026-01-27 03:09:22 --> Helper loaded: string_helper
INFO - 2026-01-27 03:09:22 --> Helper loaded: form_helper
INFO - 2026-01-27 03:09:22 --> Helper loaded: download_helper
INFO - 2026-01-27 03:09:22 --> Helper loaded: security_helper
INFO - 2026-01-27 03:09:22 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:09:22 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:09:22 --> Form Validation Class Initialized
INFO - 2026-01-27 03:09:22 --> Model "User_model" initialized
INFO - 2026-01-27 09:09:22 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:09:22 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:09:22 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:09:22 --> Controller Class Initialized
INFO - 2026-01-27 09:09:22 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:09:22 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:09:22 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:09:22 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:09:22 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2026-01-27 09:09:23 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:09:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:09:23 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:09:23 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:09:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:09:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:09:23 --> Model "Log_model" initialized
INFO - 2026-01-27 09:09:23 --> Final output sent to browser
DEBUG - 2026-01-27 09:09:23 --> Total execution time: 0.1990
INFO - 2026-01-27 03:14:59 --> Config Class Initialized
INFO - 2026-01-27 03:14:59 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:14:59 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:14:59 --> Utf8 Class Initialized
INFO - 2026-01-27 03:14:59 --> URI Class Initialized
INFO - 2026-01-27 03:14:59 --> Router Class Initialized
INFO - 2026-01-27 03:14:59 --> Output Class Initialized
INFO - 2026-01-27 03:14:59 --> Security Class Initialized
DEBUG - 2026-01-27 03:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:14:59 --> CSRF cookie sent
INFO - 2026-01-27 03:14:59 --> Input Class Initialized
INFO - 2026-01-27 03:14:59 --> Language Class Initialized
INFO - 2026-01-27 03:14:59 --> Loader Class Initialized
INFO - 2026-01-27 03:14:59 --> Helper loaded: url_helper
INFO - 2026-01-27 03:14:59 --> Helper loaded: text_helper
INFO - 2026-01-27 03:14:59 --> Helper loaded: string_helper
INFO - 2026-01-27 03:14:59 --> Helper loaded: form_helper
INFO - 2026-01-27 03:14:59 --> Helper loaded: download_helper
INFO - 2026-01-27 03:14:59 --> Helper loaded: security_helper
INFO - 2026-01-27 03:14:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:14:59 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:14:59 --> Form Validation Class Initialized
INFO - 2026-01-27 03:14:59 --> Model "User_model" initialized
INFO - 2026-01-27 09:14:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:14:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:14:59 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:14:59 --> Controller Class Initialized
INFO - 2026-01-27 09:14:59 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:14:59 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:14:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 09:14:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:14:59 --> Model "Log_model" initialized
INFO - 2026-01-27 09:14:59 --> Final output sent to browser
DEBUG - 2026-01-27 09:14:59 --> Total execution time: 0.1291
INFO - 2026-01-27 03:22:22 --> Config Class Initialized
INFO - 2026-01-27 03:22:22 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:22:22 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:22:22 --> Utf8 Class Initialized
INFO - 2026-01-27 03:22:22 --> URI Class Initialized
INFO - 2026-01-27 03:22:22 --> Router Class Initialized
INFO - 2026-01-27 03:22:22 --> Output Class Initialized
INFO - 2026-01-27 03:22:22 --> Security Class Initialized
DEBUG - 2026-01-27 03:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:22:22 --> CSRF cookie sent
INFO - 2026-01-27 03:22:22 --> CSRF token verified
INFO - 2026-01-27 03:22:22 --> Input Class Initialized
INFO - 2026-01-27 03:22:22 --> Language Class Initialized
INFO - 2026-01-27 03:22:22 --> Loader Class Initialized
INFO - 2026-01-27 03:22:22 --> Helper loaded: url_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: text_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: string_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: form_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: download_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: security_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:22:22 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:22:22 --> Form Validation Class Initialized
INFO - 2026-01-27 03:22:22 --> Model "User_model" initialized
INFO - 2026-01-27 09:22:22 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:22:22 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:22:22 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:22:22 --> Controller Class Initialized
INFO - 2026-01-27 09:22:22 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:22:22 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:22:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 03:22:22 --> Config Class Initialized
INFO - 2026-01-27 03:22:22 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:22:22 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:22:22 --> Utf8 Class Initialized
INFO - 2026-01-27 03:22:22 --> URI Class Initialized
INFO - 2026-01-27 03:22:22 --> Router Class Initialized
INFO - 2026-01-27 03:22:22 --> Output Class Initialized
INFO - 2026-01-27 03:22:22 --> Security Class Initialized
DEBUG - 2026-01-27 03:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:22:22 --> CSRF cookie sent
INFO - 2026-01-27 03:22:22 --> Input Class Initialized
INFO - 2026-01-27 03:22:22 --> Language Class Initialized
INFO - 2026-01-27 03:22:22 --> Loader Class Initialized
INFO - 2026-01-27 03:22:22 --> Helper loaded: url_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: text_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: string_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: form_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: download_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: security_helper
INFO - 2026-01-27 03:22:22 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:22:22 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:22:22 --> Form Validation Class Initialized
INFO - 2026-01-27 03:22:22 --> Model "User_model" initialized
INFO - 2026-01-27 09:22:22 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:22:22 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:22:22 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:22:22 --> Controller Class Initialized
INFO - 2026-01-27 09:22:22 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:22:22 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:22:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 09:22:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:22:22 --> Model "Log_model" initialized
INFO - 2026-01-27 09:22:22 --> Final output sent to browser
DEBUG - 2026-01-27 09:22:22 --> Total execution time: 0.1283
INFO - 2026-01-27 03:22:25 --> Config Class Initialized
INFO - 2026-01-27 03:22:25 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:22:25 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:22:25 --> Utf8 Class Initialized
INFO - 2026-01-27 03:22:25 --> URI Class Initialized
INFO - 2026-01-27 03:22:25 --> Router Class Initialized
INFO - 2026-01-27 03:22:25 --> Output Class Initialized
INFO - 2026-01-27 03:22:25 --> Security Class Initialized
DEBUG - 2026-01-27 03:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:22:25 --> CSRF cookie sent
INFO - 2026-01-27 03:22:25 --> Input Class Initialized
INFO - 2026-01-27 03:22:25 --> Language Class Initialized
INFO - 2026-01-27 03:22:25 --> Loader Class Initialized
INFO - 2026-01-27 03:22:25 --> Helper loaded: url_helper
INFO - 2026-01-27 03:22:25 --> Helper loaded: text_helper
INFO - 2026-01-27 03:22:25 --> Helper loaded: string_helper
INFO - 2026-01-27 03:22:25 --> Helper loaded: form_helper
INFO - 2026-01-27 03:22:25 --> Helper loaded: download_helper
INFO - 2026-01-27 03:22:25 --> Helper loaded: security_helper
INFO - 2026-01-27 03:22:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:22:25 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:22:25 --> Form Validation Class Initialized
INFO - 2026-01-27 03:22:25 --> Model "User_model" initialized
INFO - 2026-01-27 09:22:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:22:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:22:25 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:22:25 --> Controller Class Initialized
INFO - 2026-01-27 09:22:25 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:22:25 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:22:25 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:22:25 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:22:25 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2026-01-27 09:22:25 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:22:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:22:25 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:22:25 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:22:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:22:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:22:25 --> Model "Log_model" initialized
INFO - 2026-01-27 09:22:25 --> Final output sent to browser
DEBUG - 2026-01-27 09:22:25 --> Total execution time: 0.1867
INFO - 2026-01-27 03:23:36 --> Config Class Initialized
INFO - 2026-01-27 03:23:36 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:23:36 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:23:36 --> Utf8 Class Initialized
INFO - 2026-01-27 03:23:36 --> URI Class Initialized
INFO - 2026-01-27 03:23:36 --> Router Class Initialized
INFO - 2026-01-27 03:23:36 --> Output Class Initialized
INFO - 2026-01-27 03:23:36 --> Security Class Initialized
DEBUG - 2026-01-27 03:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:23:36 --> CSRF cookie sent
INFO - 2026-01-27 03:23:36 --> Input Class Initialized
INFO - 2026-01-27 03:23:36 --> Language Class Initialized
INFO - 2026-01-27 03:23:36 --> Loader Class Initialized
INFO - 2026-01-27 03:23:36 --> Helper loaded: url_helper
INFO - 2026-01-27 03:23:36 --> Helper loaded: text_helper
INFO - 2026-01-27 03:23:36 --> Helper loaded: string_helper
INFO - 2026-01-27 03:23:36 --> Helper loaded: form_helper
INFO - 2026-01-27 03:23:36 --> Helper loaded: download_helper
INFO - 2026-01-27 03:23:36 --> Helper loaded: security_helper
INFO - 2026-01-27 03:23:36 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:23:36 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:23:36 --> Form Validation Class Initialized
INFO - 2026-01-27 03:23:36 --> Model "User_model" initialized
INFO - 2026-01-27 09:23:36 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:23:36 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:23:36 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:23:36 --> Controller Class Initialized
INFO - 2026-01-27 09:23:36 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:23:36 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:23:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 09:23:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:23:36 --> Model "Log_model" initialized
INFO - 2026-01-27 09:23:36 --> Final output sent to browser
DEBUG - 2026-01-27 09:23:36 --> Total execution time: 0.1371
INFO - 2026-01-27 03:27:15 --> Config Class Initialized
INFO - 2026-01-27 03:27:15 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:27:15 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:27:15 --> Utf8 Class Initialized
INFO - 2026-01-27 03:27:15 --> URI Class Initialized
INFO - 2026-01-27 03:27:15 --> Router Class Initialized
INFO - 2026-01-27 03:27:15 --> Output Class Initialized
INFO - 2026-01-27 03:27:15 --> Security Class Initialized
DEBUG - 2026-01-27 03:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:27:15 --> CSRF cookie sent
INFO - 2026-01-27 03:27:15 --> CSRF token verified
INFO - 2026-01-27 03:27:15 --> Input Class Initialized
INFO - 2026-01-27 03:27:15 --> Language Class Initialized
INFO - 2026-01-27 03:27:15 --> Loader Class Initialized
INFO - 2026-01-27 03:27:15 --> Helper loaded: url_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: text_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: string_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: form_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: download_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: security_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:27:15 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:27:15 --> Form Validation Class Initialized
INFO - 2026-01-27 03:27:15 --> Model "User_model" initialized
INFO - 2026-01-27 09:27:15 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:27:15 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:27:15 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:27:15 --> Controller Class Initialized
INFO - 2026-01-27 09:27:15 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:27:15 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:27:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 03:27:15 --> Config Class Initialized
INFO - 2026-01-27 03:27:15 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:27:15 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:27:15 --> Utf8 Class Initialized
INFO - 2026-01-27 03:27:15 --> URI Class Initialized
INFO - 2026-01-27 03:27:15 --> Router Class Initialized
INFO - 2026-01-27 03:27:15 --> Output Class Initialized
INFO - 2026-01-27 03:27:15 --> Security Class Initialized
DEBUG - 2026-01-27 03:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:27:15 --> CSRF cookie sent
INFO - 2026-01-27 03:27:15 --> Input Class Initialized
INFO - 2026-01-27 03:27:15 --> Language Class Initialized
INFO - 2026-01-27 03:27:15 --> Loader Class Initialized
INFO - 2026-01-27 03:27:15 --> Helper loaded: url_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: text_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: string_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: form_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: download_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: security_helper
INFO - 2026-01-27 03:27:15 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:27:15 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:27:15 --> Form Validation Class Initialized
INFO - 2026-01-27 03:27:15 --> Model "User_model" initialized
INFO - 2026-01-27 09:27:15 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:27:15 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:27:15 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:27:15 --> Controller Class Initialized
INFO - 2026-01-27 09:27:15 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:27:15 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:27:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 09:27:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:27:15 --> Model "Log_model" initialized
INFO - 2026-01-27 09:27:15 --> Final output sent to browser
DEBUG - 2026-01-27 09:27:15 --> Total execution time: 0.1457
INFO - 2026-01-27 03:27:18 --> Config Class Initialized
INFO - 2026-01-27 03:27:18 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:27:18 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:27:18 --> Utf8 Class Initialized
INFO - 2026-01-27 03:27:18 --> URI Class Initialized
INFO - 2026-01-27 03:27:18 --> Router Class Initialized
INFO - 2026-01-27 03:27:18 --> Output Class Initialized
INFO - 2026-01-27 03:27:18 --> Security Class Initialized
DEBUG - 2026-01-27 03:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:27:18 --> CSRF cookie sent
INFO - 2026-01-27 03:27:18 --> Input Class Initialized
INFO - 2026-01-27 03:27:18 --> Language Class Initialized
INFO - 2026-01-27 03:27:18 --> Loader Class Initialized
INFO - 2026-01-27 03:27:18 --> Helper loaded: url_helper
INFO - 2026-01-27 03:27:18 --> Helper loaded: text_helper
INFO - 2026-01-27 03:27:18 --> Helper loaded: string_helper
INFO - 2026-01-27 03:27:18 --> Helper loaded: form_helper
INFO - 2026-01-27 03:27:18 --> Helper loaded: download_helper
INFO - 2026-01-27 03:27:18 --> Helper loaded: security_helper
INFO - 2026-01-27 03:27:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:27:18 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:27:18 --> Form Validation Class Initialized
INFO - 2026-01-27 03:27:18 --> Model "User_model" initialized
INFO - 2026-01-27 09:27:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:27:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:27:18 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:27:18 --> Controller Class Initialized
INFO - 2026-01-27 09:27:18 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:27:18 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:27:18 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:27:18 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:27:18 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2026-01-27 09:27:18 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:27:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:27:18 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:27:18 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:27:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:27:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:27:18 --> Model "Log_model" initialized
INFO - 2026-01-27 09:27:18 --> Final output sent to browser
DEBUG - 2026-01-27 09:27:18 --> Total execution time: 0.1655
INFO - 2026-01-27 03:27:29 --> Config Class Initialized
INFO - 2026-01-27 03:27:29 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:27:29 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:27:29 --> Utf8 Class Initialized
INFO - 2026-01-27 03:27:29 --> URI Class Initialized
INFO - 2026-01-27 03:27:29 --> Router Class Initialized
INFO - 2026-01-27 03:27:29 --> Output Class Initialized
INFO - 2026-01-27 03:27:29 --> Security Class Initialized
DEBUG - 2026-01-27 03:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:27:29 --> CSRF cookie sent
INFO - 2026-01-27 03:27:29 --> Input Class Initialized
INFO - 2026-01-27 03:27:29 --> Language Class Initialized
INFO - 2026-01-27 03:27:29 --> Loader Class Initialized
INFO - 2026-01-27 03:27:29 --> Helper loaded: url_helper
INFO - 2026-01-27 03:27:29 --> Helper loaded: text_helper
INFO - 2026-01-27 03:27:29 --> Helper loaded: string_helper
INFO - 2026-01-27 03:27:29 --> Helper loaded: form_helper
INFO - 2026-01-27 03:27:29 --> Helper loaded: download_helper
INFO - 2026-01-27 03:27:29 --> Helper loaded: security_helper
INFO - 2026-01-27 03:27:29 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:27:29 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:27:29 --> Form Validation Class Initialized
INFO - 2026-01-27 03:27:29 --> Model "User_model" initialized
INFO - 2026-01-27 09:27:29 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:27:29 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:27:29 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:27:29 --> Controller Class Initialized
INFO - 2026-01-27 09:27:29 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:27:29 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:27:29 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:27:29 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:27:29 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2026-01-27 09:27:29 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:27:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:27:29 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:27:29 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:27:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:27:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:27:29 --> Model "Log_model" initialized
INFO - 2026-01-27 09:27:29 --> Final output sent to browser
DEBUG - 2026-01-27 09:27:29 --> Total execution time: 0.1852
INFO - 2026-01-27 03:28:50 --> Config Class Initialized
INFO - 2026-01-27 03:28:50 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:28:50 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:28:50 --> Utf8 Class Initialized
INFO - 2026-01-27 03:28:50 --> URI Class Initialized
INFO - 2026-01-27 03:28:50 --> Router Class Initialized
INFO - 2026-01-27 03:28:50 --> Output Class Initialized
INFO - 2026-01-27 03:28:50 --> Security Class Initialized
DEBUG - 2026-01-27 03:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:28:50 --> CSRF cookie sent
INFO - 2026-01-27 03:28:50 --> Input Class Initialized
INFO - 2026-01-27 03:28:50 --> Language Class Initialized
INFO - 2026-01-27 03:28:50 --> Loader Class Initialized
INFO - 2026-01-27 03:28:50 --> Helper loaded: url_helper
INFO - 2026-01-27 03:28:50 --> Helper loaded: text_helper
INFO - 2026-01-27 03:28:50 --> Helper loaded: string_helper
INFO - 2026-01-27 03:28:50 --> Helper loaded: form_helper
INFO - 2026-01-27 03:28:50 --> Helper loaded: download_helper
INFO - 2026-01-27 03:28:50 --> Helper loaded: security_helper
INFO - 2026-01-27 03:28:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:28:50 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:28:50 --> Form Validation Class Initialized
INFO - 2026-01-27 03:28:50 --> Model "User_model" initialized
INFO - 2026-01-27 09:28:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:28:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:28:50 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:28:50 --> Controller Class Initialized
INFO - 2026-01-27 09:28:50 --> Model "Download_model" initialized
INFO - 2026-01-27 09:28:50 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:28:50 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:28:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-27 09:28:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:28:50 --> Model "Log_model" initialized
INFO - 2026-01-27 09:28:50 --> Final output sent to browser
DEBUG - 2026-01-27 09:28:50 --> Total execution time: 0.1665
INFO - 2026-01-27 03:28:52 --> Config Class Initialized
INFO - 2026-01-27 03:28:52 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:28:52 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:28:52 --> Utf8 Class Initialized
INFO - 2026-01-27 03:28:52 --> URI Class Initialized
INFO - 2026-01-27 03:28:52 --> Router Class Initialized
INFO - 2026-01-27 03:28:52 --> Output Class Initialized
INFO - 2026-01-27 03:28:52 --> Security Class Initialized
DEBUG - 2026-01-27 03:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:28:52 --> CSRF cookie sent
INFO - 2026-01-27 03:28:52 --> Input Class Initialized
INFO - 2026-01-27 03:28:52 --> Language Class Initialized
INFO - 2026-01-27 03:28:52 --> Loader Class Initialized
INFO - 2026-01-27 03:28:52 --> Helper loaded: url_helper
INFO - 2026-01-27 03:28:52 --> Helper loaded: text_helper
INFO - 2026-01-27 03:28:52 --> Helper loaded: string_helper
INFO - 2026-01-27 03:28:52 --> Helper loaded: form_helper
INFO - 2026-01-27 03:28:52 --> Helper loaded: download_helper
INFO - 2026-01-27 03:28:52 --> Helper loaded: security_helper
INFO - 2026-01-27 03:28:52 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:28:52 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:28:52 --> Form Validation Class Initialized
INFO - 2026-01-27 03:28:52 --> Model "User_model" initialized
INFO - 2026-01-27 09:28:52 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:28:52 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:28:52 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:28:52 --> Controller Class Initialized
INFO - 2026-01-27 09:28:52 --> Model "Download_model" initialized
INFO - 2026-01-27 09:28:52 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:28:52 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:28:52 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"208","filename":"SERTIFIKAT_AIPT_2023-2027.pdf","timestamp":"2026-01-27 09:28:52"}
INFO - 2026-01-27 03:29:03 --> Config Class Initialized
INFO - 2026-01-27 03:29:03 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:29:03 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:29:03 --> Utf8 Class Initialized
INFO - 2026-01-27 03:29:03 --> URI Class Initialized
INFO - 2026-01-27 03:29:03 --> Router Class Initialized
INFO - 2026-01-27 03:29:03 --> Output Class Initialized
INFO - 2026-01-27 03:29:03 --> Security Class Initialized
DEBUG - 2026-01-27 03:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:29:03 --> CSRF cookie sent
INFO - 2026-01-27 03:29:03 --> Input Class Initialized
INFO - 2026-01-27 03:29:03 --> Language Class Initialized
INFO - 2026-01-27 03:29:03 --> Loader Class Initialized
INFO - 2026-01-27 03:29:03 --> Helper loaded: url_helper
INFO - 2026-01-27 03:29:03 --> Helper loaded: text_helper
INFO - 2026-01-27 03:29:03 --> Helper loaded: string_helper
INFO - 2026-01-27 03:29:03 --> Helper loaded: form_helper
INFO - 2026-01-27 03:29:03 --> Helper loaded: download_helper
INFO - 2026-01-27 03:29:03 --> Helper loaded: security_helper
INFO - 2026-01-27 03:29:03 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:29:03 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:29:03 --> Form Validation Class Initialized
INFO - 2026-01-27 03:29:03 --> Model "User_model" initialized
INFO - 2026-01-27 09:29:03 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:29:03 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:29:03 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:29:03 --> Controller Class Initialized
INFO - 2026-01-27 09:29:03 --> Model "Download_model" initialized
INFO - 2026-01-27 09:29:03 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:29:03 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:29:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-27 09:29:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:29:03 --> Model "Log_model" initialized
INFO - 2026-01-27 09:29:03 --> Final output sent to browser
DEBUG - 2026-01-27 09:29:03 --> Total execution time: 0.2764
INFO - 2026-01-27 03:29:05 --> Config Class Initialized
INFO - 2026-01-27 03:29:05 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:29:05 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:29:05 --> Utf8 Class Initialized
INFO - 2026-01-27 03:29:05 --> URI Class Initialized
INFO - 2026-01-27 03:29:05 --> Router Class Initialized
INFO - 2026-01-27 03:29:05 --> Output Class Initialized
INFO - 2026-01-27 03:29:05 --> Security Class Initialized
DEBUG - 2026-01-27 03:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:29:05 --> CSRF cookie sent
INFO - 2026-01-27 03:29:05 --> Input Class Initialized
INFO - 2026-01-27 03:29:05 --> Language Class Initialized
INFO - 2026-01-27 03:29:05 --> Loader Class Initialized
INFO - 2026-01-27 03:29:05 --> Helper loaded: url_helper
INFO - 2026-01-27 03:29:05 --> Helper loaded: text_helper
INFO - 2026-01-27 03:29:05 --> Helper loaded: string_helper
INFO - 2026-01-27 03:29:05 --> Helper loaded: form_helper
INFO - 2026-01-27 03:29:05 --> Helper loaded: download_helper
INFO - 2026-01-27 03:29:05 --> Helper loaded: security_helper
INFO - 2026-01-27 03:29:05 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:29:05 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:29:05 --> Form Validation Class Initialized
INFO - 2026-01-27 03:29:05 --> Model "User_model" initialized
INFO - 2026-01-27 09:29:05 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:29:05 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:29:05 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:29:05 --> Controller Class Initialized
INFO - 2026-01-27 09:29:05 --> Model "Download_model" initialized
INFO - 2026-01-27 09:29:05 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:29:05 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:29:05 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"215","filename":"DIPA_2023.pdf","timestamp":"2026-01-27 09:29:05"}
INFO - 2026-01-27 03:29:11 --> Config Class Initialized
INFO - 2026-01-27 03:29:11 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:29:11 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:29:11 --> Utf8 Class Initialized
INFO - 2026-01-27 03:29:11 --> URI Class Initialized
DEBUG - 2026-01-27 03:29:11 --> No URI present. Default controller set.
INFO - 2026-01-27 03:29:11 --> Router Class Initialized
INFO - 2026-01-27 03:29:11 --> Output Class Initialized
INFO - 2026-01-27 03:29:11 --> Security Class Initialized
DEBUG - 2026-01-27 03:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:29:11 --> CSRF cookie sent
INFO - 2026-01-27 03:29:11 --> Input Class Initialized
INFO - 2026-01-27 03:29:11 --> Language Class Initialized
INFO - 2026-01-27 03:29:11 --> Loader Class Initialized
INFO - 2026-01-27 03:29:11 --> Helper loaded: url_helper
INFO - 2026-01-27 03:29:11 --> Helper loaded: text_helper
INFO - 2026-01-27 03:29:11 --> Helper loaded: string_helper
INFO - 2026-01-27 03:29:11 --> Helper loaded: form_helper
INFO - 2026-01-27 03:29:11 --> Helper loaded: download_helper
INFO - 2026-01-27 03:29:11 --> Helper loaded: security_helper
INFO - 2026-01-27 03:29:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:29:11 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:29:11 --> Form Validation Class Initialized
INFO - 2026-01-27 03:29:11 --> Model "User_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:29:11 --> Controller Class Initialized
INFO - 2026-01-27 09:29:11 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Galeri_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Video_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Agenda_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Tautan_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Mitra_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:29:11 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 09:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 09:29:11 --> Pagination Class Initialized
INFO - 2026-01-27 09:29:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 09:29:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:29:11 --> Model "Log_model" initialized
INFO - 2026-01-27 09:29:11 --> Final output sent to browser
DEBUG - 2026-01-27 09:29:11 --> Total execution time: 0.2949
INFO - 2026-01-27 03:31:06 --> Config Class Initialized
INFO - 2026-01-27 03:31:06 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:31:06 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:31:06 --> Utf8 Class Initialized
INFO - 2026-01-27 03:31:06 --> URI Class Initialized
INFO - 2026-01-27 03:31:06 --> Router Class Initialized
INFO - 2026-01-27 03:31:06 --> Output Class Initialized
INFO - 2026-01-27 03:31:06 --> Security Class Initialized
DEBUG - 2026-01-27 03:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:31:06 --> CSRF cookie sent
INFO - 2026-01-27 03:31:06 --> Input Class Initialized
INFO - 2026-01-27 03:31:06 --> Language Class Initialized
INFO - 2026-01-27 03:31:06 --> Loader Class Initialized
INFO - 2026-01-27 03:31:06 --> Helper loaded: url_helper
INFO - 2026-01-27 03:31:06 --> Helper loaded: text_helper
INFO - 2026-01-27 03:31:06 --> Helper loaded: string_helper
INFO - 2026-01-27 03:31:06 --> Helper loaded: form_helper
INFO - 2026-01-27 03:31:06 --> Helper loaded: download_helper
INFO - 2026-01-27 03:31:06 --> Helper loaded: security_helper
INFO - 2026-01-27 03:31:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:31:06 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:31:06 --> Form Validation Class Initialized
INFO - 2026-01-27 03:31:06 --> Model "User_model" initialized
INFO - 2026-01-27 09:31:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:31:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:31:06 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:31:06 --> Controller Class Initialized
INFO - 2026-01-27 09:31:06 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:31:06 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:31:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 09:31:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:31:06 --> Model "Log_model" initialized
INFO - 2026-01-27 09:31:06 --> Final output sent to browser
DEBUG - 2026-01-27 09:31:06 --> Total execution time: 0.1447
INFO - 2026-01-27 03:32:59 --> Config Class Initialized
INFO - 2026-01-27 03:32:59 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:32:59 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:32:59 --> Utf8 Class Initialized
INFO - 2026-01-27 03:32:59 --> URI Class Initialized
INFO - 2026-01-27 03:32:59 --> Router Class Initialized
INFO - 2026-01-27 03:32:59 --> Output Class Initialized
INFO - 2026-01-27 03:32:59 --> Security Class Initialized
DEBUG - 2026-01-27 03:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:32:59 --> CSRF cookie sent
INFO - 2026-01-27 03:32:59 --> CSRF token verified
INFO - 2026-01-27 03:32:59 --> Input Class Initialized
INFO - 2026-01-27 03:32:59 --> Language Class Initialized
INFO - 2026-01-27 03:32:59 --> Loader Class Initialized
INFO - 2026-01-27 03:32:59 --> Helper loaded: url_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: text_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: string_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: form_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: download_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: security_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:32:59 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:32:59 --> Form Validation Class Initialized
INFO - 2026-01-27 03:32:59 --> Model "User_model" initialized
INFO - 2026-01-27 09:32:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:32:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:32:59 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:32:59 --> Controller Class Initialized
INFO - 2026-01-27 09:32:59 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:32:59 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:32:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 03:32:59 --> Config Class Initialized
INFO - 2026-01-27 03:32:59 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:32:59 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:32:59 --> Utf8 Class Initialized
INFO - 2026-01-27 03:32:59 --> URI Class Initialized
INFO - 2026-01-27 03:32:59 --> Router Class Initialized
INFO - 2026-01-27 03:32:59 --> Output Class Initialized
INFO - 2026-01-27 03:32:59 --> Security Class Initialized
DEBUG - 2026-01-27 03:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:32:59 --> CSRF cookie sent
INFO - 2026-01-27 03:32:59 --> Input Class Initialized
INFO - 2026-01-27 03:32:59 --> Language Class Initialized
INFO - 2026-01-27 03:32:59 --> Loader Class Initialized
INFO - 2026-01-27 03:32:59 --> Helper loaded: url_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: text_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: string_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: form_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: download_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: security_helper
INFO - 2026-01-27 03:32:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:32:59 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:32:59 --> Form Validation Class Initialized
INFO - 2026-01-27 03:32:59 --> Model "User_model" initialized
INFO - 2026-01-27 09:32:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:32:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:32:59 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:32:59 --> Controller Class Initialized
INFO - 2026-01-27 09:32:59 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:32:59 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:32:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 09:32:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:32:59 --> Model "Log_model" initialized
INFO - 2026-01-27 09:32:59 --> Final output sent to browser
DEBUG - 2026-01-27 09:32:59 --> Total execution time: 0.1306
INFO - 2026-01-27 03:33:01 --> Config Class Initialized
INFO - 2026-01-27 03:33:01 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:33:01 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:33:01 --> Utf8 Class Initialized
INFO - 2026-01-27 03:33:01 --> URI Class Initialized
DEBUG - 2026-01-27 03:33:01 --> No URI present. Default controller set.
INFO - 2026-01-27 03:33:01 --> Router Class Initialized
INFO - 2026-01-27 03:33:01 --> Output Class Initialized
INFO - 2026-01-27 03:33:01 --> Security Class Initialized
DEBUG - 2026-01-27 03:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:33:01 --> CSRF cookie sent
INFO - 2026-01-27 03:33:01 --> Input Class Initialized
INFO - 2026-01-27 03:33:01 --> Language Class Initialized
INFO - 2026-01-27 03:33:01 --> Loader Class Initialized
INFO - 2026-01-27 03:33:02 --> Helper loaded: url_helper
INFO - 2026-01-27 03:33:02 --> Helper loaded: text_helper
INFO - 2026-01-27 03:33:02 --> Helper loaded: string_helper
INFO - 2026-01-27 03:33:02 --> Helper loaded: form_helper
INFO - 2026-01-27 03:33:02 --> Helper loaded: download_helper
INFO - 2026-01-27 03:33:02 --> Helper loaded: security_helper
INFO - 2026-01-27 03:33:02 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:33:02 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:33:02 --> Form Validation Class Initialized
INFO - 2026-01-27 03:33:02 --> Model "User_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:33:02 --> Controller Class Initialized
INFO - 2026-01-27 09:33:02 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Galeri_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Video_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Agenda_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Tautan_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Mitra_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:33:02 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 09:33:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 09:33:02 --> Pagination Class Initialized
INFO - 2026-01-27 09:33:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 09:33:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:33:02 --> Model "Log_model" initialized
INFO - 2026-01-27 09:33:02 --> Final output sent to browser
DEBUG - 2026-01-27 09:33:02 --> Total execution time: 0.6156
INFO - 2026-01-27 03:33:15 --> Config Class Initialized
INFO - 2026-01-27 03:33:15 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:33:15 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:33:15 --> Utf8 Class Initialized
INFO - 2026-01-27 03:33:15 --> URI Class Initialized
INFO - 2026-01-27 03:33:15 --> Router Class Initialized
INFO - 2026-01-27 03:33:15 --> Output Class Initialized
INFO - 2026-01-27 03:33:15 --> Security Class Initialized
DEBUG - 2026-01-27 03:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:33:15 --> CSRF cookie sent
INFO - 2026-01-27 03:33:15 --> Input Class Initialized
INFO - 2026-01-27 03:33:15 --> Language Class Initialized
INFO - 2026-01-27 03:33:15 --> Loader Class Initialized
INFO - 2026-01-27 03:33:15 --> Helper loaded: url_helper
INFO - 2026-01-27 03:33:15 --> Helper loaded: text_helper
INFO - 2026-01-27 03:33:15 --> Helper loaded: string_helper
INFO - 2026-01-27 03:33:15 --> Helper loaded: form_helper
INFO - 2026-01-27 03:33:15 --> Helper loaded: download_helper
INFO - 2026-01-27 03:33:15 --> Helper loaded: security_helper
INFO - 2026-01-27 03:33:15 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:33:15 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:33:15 --> Form Validation Class Initialized
INFO - 2026-01-27 03:33:15 --> Model "User_model" initialized
INFO - 2026-01-27 09:33:15 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:33:15 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:33:15 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:33:15 --> Controller Class Initialized
INFO - 2026-01-27 09:33:15 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:33:15 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:33:15 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:33:15 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:33:15 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2026-01-27 09:33:15 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:33:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:33:15 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:33:15 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:33:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:33:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:33:15 --> Model "Log_model" initialized
INFO - 2026-01-27 09:33:15 --> Final output sent to browser
DEBUG - 2026-01-27 09:33:15 --> Total execution time: 0.2861
INFO - 2026-01-27 03:34:07 --> Config Class Initialized
INFO - 2026-01-27 03:34:07 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:34:07 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:34:07 --> Utf8 Class Initialized
INFO - 2026-01-27 03:34:07 --> URI Class Initialized
INFO - 2026-01-27 03:34:07 --> Router Class Initialized
INFO - 2026-01-27 03:34:07 --> Output Class Initialized
INFO - 2026-01-27 03:34:07 --> Security Class Initialized
DEBUG - 2026-01-27 03:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:34:07 --> CSRF cookie sent
INFO - 2026-01-27 03:34:07 --> Input Class Initialized
INFO - 2026-01-27 03:34:07 --> Language Class Initialized
INFO - 2026-01-27 03:34:07 --> Loader Class Initialized
INFO - 2026-01-27 03:34:07 --> Helper loaded: url_helper
INFO - 2026-01-27 03:34:07 --> Helper loaded: text_helper
INFO - 2026-01-27 03:34:07 --> Helper loaded: string_helper
INFO - 2026-01-27 03:34:07 --> Helper loaded: form_helper
INFO - 2026-01-27 03:34:07 --> Helper loaded: download_helper
INFO - 2026-01-27 03:34:07 --> Helper loaded: security_helper
INFO - 2026-01-27 03:34:07 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:34:07 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:34:07 --> Form Validation Class Initialized
INFO - 2026-01-27 03:34:07 --> Model "User_model" initialized
INFO - 2026-01-27 09:34:07 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:34:07 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:34:07 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:34:07 --> Controller Class Initialized
INFO - 2026-01-27 09:34:07 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:34:07 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:34:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 09:34:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:34:07 --> Model "Log_model" initialized
INFO - 2026-01-27 09:34:07 --> Final output sent to browser
DEBUG - 2026-01-27 09:34:07 --> Total execution time: 0.1573
INFO - 2026-01-27 03:35:49 --> Config Class Initialized
INFO - 2026-01-27 03:35:49 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:35:49 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:35:49 --> Utf8 Class Initialized
INFO - 2026-01-27 03:35:49 --> URI Class Initialized
INFO - 2026-01-27 03:35:49 --> Router Class Initialized
INFO - 2026-01-27 03:35:49 --> Output Class Initialized
INFO - 2026-01-27 03:35:49 --> Security Class Initialized
DEBUG - 2026-01-27 03:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:35:49 --> CSRF cookie sent
INFO - 2026-01-27 03:35:49 --> CSRF token verified
INFO - 2026-01-27 03:35:49 --> Input Class Initialized
INFO - 2026-01-27 03:35:49 --> Language Class Initialized
INFO - 2026-01-27 03:35:49 --> Loader Class Initialized
INFO - 2026-01-27 03:35:49 --> Helper loaded: url_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: text_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: string_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: form_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: download_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: security_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:35:49 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:35:49 --> Form Validation Class Initialized
INFO - 2026-01-27 03:35:49 --> Model "User_model" initialized
INFO - 2026-01-27 09:35:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:35:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:35:49 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:35:49 --> Controller Class Initialized
INFO - 2026-01-27 09:35:49 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:35:49 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:35:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 03:35:49 --> Config Class Initialized
INFO - 2026-01-27 03:35:49 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:35:49 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:35:49 --> Utf8 Class Initialized
INFO - 2026-01-27 03:35:49 --> URI Class Initialized
INFO - 2026-01-27 03:35:49 --> Router Class Initialized
INFO - 2026-01-27 03:35:49 --> Output Class Initialized
INFO - 2026-01-27 03:35:49 --> Security Class Initialized
DEBUG - 2026-01-27 03:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:35:49 --> CSRF cookie sent
INFO - 2026-01-27 03:35:49 --> Input Class Initialized
INFO - 2026-01-27 03:35:49 --> Language Class Initialized
INFO - 2026-01-27 03:35:49 --> Loader Class Initialized
INFO - 2026-01-27 03:35:49 --> Helper loaded: url_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: text_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: string_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: form_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: download_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: security_helper
INFO - 2026-01-27 03:35:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:35:49 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:35:49 --> Form Validation Class Initialized
INFO - 2026-01-27 03:35:49 --> Model "User_model" initialized
INFO - 2026-01-27 09:35:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:35:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:35:49 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:35:49 --> Controller Class Initialized
INFO - 2026-01-27 09:35:49 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:35:49 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:35:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 09:35:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:35:49 --> Model "Log_model" initialized
INFO - 2026-01-27 09:35:49 --> Final output sent to browser
DEBUG - 2026-01-27 09:35:49 --> Total execution time: 0.1256
INFO - 2026-01-27 03:35:52 --> Config Class Initialized
INFO - 2026-01-27 03:35:52 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:35:52 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:35:52 --> Utf8 Class Initialized
INFO - 2026-01-27 03:35:52 --> URI Class Initialized
INFO - 2026-01-27 03:35:52 --> Router Class Initialized
INFO - 2026-01-27 03:35:52 --> Output Class Initialized
INFO - 2026-01-27 03:35:52 --> Security Class Initialized
DEBUG - 2026-01-27 03:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:35:52 --> CSRF cookie sent
INFO - 2026-01-27 03:35:52 --> Input Class Initialized
INFO - 2026-01-27 03:35:52 --> Language Class Initialized
INFO - 2026-01-27 03:35:52 --> Loader Class Initialized
INFO - 2026-01-27 03:35:52 --> Helper loaded: url_helper
INFO - 2026-01-27 03:35:52 --> Helper loaded: text_helper
INFO - 2026-01-27 03:35:52 --> Helper loaded: string_helper
INFO - 2026-01-27 03:35:52 --> Helper loaded: form_helper
INFO - 2026-01-27 03:35:52 --> Helper loaded: download_helper
INFO - 2026-01-27 03:35:52 --> Helper loaded: security_helper
INFO - 2026-01-27 03:35:52 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:35:52 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:35:52 --> Form Validation Class Initialized
INFO - 2026-01-27 03:35:52 --> Model "User_model" initialized
INFO - 2026-01-27 09:35:52 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:35:52 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:35:52 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:35:52 --> Controller Class Initialized
INFO - 2026-01-27 09:35:52 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:35:52 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:35:52 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:35:52 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:35:52 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2026-01-27 09:35:52 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:35:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:35:52 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:35:52 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:35:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:35:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:35:52 --> Model "Log_model" initialized
INFO - 2026-01-27 09:35:52 --> Final output sent to browser
DEBUG - 2026-01-27 09:35:52 --> Total execution time: 0.1804
INFO - 2026-01-27 03:36:13 --> Config Class Initialized
INFO - 2026-01-27 03:36:13 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:36:13 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:36:13 --> Utf8 Class Initialized
INFO - 2026-01-27 03:36:13 --> URI Class Initialized
INFO - 2026-01-27 03:36:13 --> Router Class Initialized
INFO - 2026-01-27 03:36:13 --> Output Class Initialized
INFO - 2026-01-27 03:36:13 --> Security Class Initialized
DEBUG - 2026-01-27 03:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:36:13 --> CSRF cookie sent
INFO - 2026-01-27 03:36:13 --> Input Class Initialized
INFO - 2026-01-27 03:36:13 --> Language Class Initialized
INFO - 2026-01-27 03:36:13 --> Loader Class Initialized
INFO - 2026-01-27 03:36:13 --> Helper loaded: url_helper
INFO - 2026-01-27 03:36:13 --> Helper loaded: text_helper
INFO - 2026-01-27 03:36:13 --> Helper loaded: string_helper
INFO - 2026-01-27 03:36:13 --> Helper loaded: form_helper
INFO - 2026-01-27 03:36:13 --> Helper loaded: download_helper
INFO - 2026-01-27 03:36:13 --> Helper loaded: security_helper
INFO - 2026-01-27 03:36:13 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:36:13 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:36:13 --> Form Validation Class Initialized
INFO - 2026-01-27 03:36:13 --> Model "User_model" initialized
INFO - 2026-01-27 09:36:13 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:36:13 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:36:13 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:36:13 --> Controller Class Initialized
INFO - 2026-01-27 09:36:13 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:36:13 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:36:13 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:36:13 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:36:13 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2026-01-27 09:36:13 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:36:13 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:36:13 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:36:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:36:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:36:13 --> Model "Log_model" initialized
INFO - 2026-01-27 09:36:13 --> Final output sent to browser
DEBUG - 2026-01-27 09:36:13 --> Total execution time: 0.2156
INFO - 2026-01-27 03:36:48 --> Config Class Initialized
INFO - 2026-01-27 03:36:48 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:36:48 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:36:48 --> Utf8 Class Initialized
INFO - 2026-01-27 03:36:48 --> URI Class Initialized
INFO - 2026-01-27 03:36:48 --> Router Class Initialized
INFO - 2026-01-27 03:36:48 --> Output Class Initialized
INFO - 2026-01-27 03:36:48 --> Security Class Initialized
DEBUG - 2026-01-27 03:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:36:48 --> CSRF cookie sent
INFO - 2026-01-27 03:36:48 --> Input Class Initialized
INFO - 2026-01-27 03:36:48 --> Language Class Initialized
INFO - 2026-01-27 03:36:48 --> Loader Class Initialized
INFO - 2026-01-27 03:36:48 --> Helper loaded: url_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: text_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: string_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: form_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: download_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: security_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:36:48 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:36:48 --> Form Validation Class Initialized
INFO - 2026-01-27 03:36:48 --> Model "User_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:36:48 --> Controller Class Initialized
INFO - 2026-01-27 09:36:48 --> Model "Pages_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Download_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:36:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-27 09:36:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:36:48 --> Model "Log_model" initialized
INFO - 2026-01-27 09:36:48 --> Final output sent to browser
DEBUG - 2026-01-27 09:36:48 --> Total execution time: 0.1388
INFO - 2026-01-27 03:36:48 --> Config Class Initialized
INFO - 2026-01-27 03:36:48 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:36:48 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:36:48 --> Utf8 Class Initialized
INFO - 2026-01-27 03:36:48 --> URI Class Initialized
INFO - 2026-01-27 03:36:48 --> Router Class Initialized
INFO - 2026-01-27 03:36:48 --> Output Class Initialized
INFO - 2026-01-27 03:36:48 --> Security Class Initialized
DEBUG - 2026-01-27 03:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:36:48 --> CSRF cookie sent
INFO - 2026-01-27 03:36:48 --> Input Class Initialized
INFO - 2026-01-27 03:36:48 --> Language Class Initialized
INFO - 2026-01-27 03:36:48 --> Loader Class Initialized
INFO - 2026-01-27 03:36:48 --> Helper loaded: url_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: text_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: string_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: form_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: download_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: security_helper
INFO - 2026-01-27 03:36:48 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:36:48 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:36:48 --> Form Validation Class Initialized
INFO - 2026-01-27 03:36:48 --> Model "User_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:36:48 --> Controller Class Initialized
INFO - 2026-01-27 09:36:48 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Galeri_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Video_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Agenda_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Tautan_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Mitra_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:36:48 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 09:36:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-27 09:36:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:36:48 --> Model "Log_model" initialized
INFO - 2026-01-27 09:36:48 --> Final output sent to browser
DEBUG - 2026-01-27 09:36:48 --> Total execution time: 0.1285
INFO - 2026-01-27 03:36:51 --> Config Class Initialized
INFO - 2026-01-27 03:36:51 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:36:51 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:36:51 --> Utf8 Class Initialized
INFO - 2026-01-27 03:36:51 --> URI Class Initialized
INFO - 2026-01-27 03:36:51 --> Router Class Initialized
INFO - 2026-01-27 03:36:51 --> Output Class Initialized
INFO - 2026-01-27 03:36:51 --> Security Class Initialized
DEBUG - 2026-01-27 03:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:36:51 --> CSRF cookie sent
INFO - 2026-01-27 03:36:51 --> Input Class Initialized
INFO - 2026-01-27 03:36:51 --> Language Class Initialized
INFO - 2026-01-27 03:36:51 --> Loader Class Initialized
INFO - 2026-01-27 03:36:51 --> Helper loaded: url_helper
INFO - 2026-01-27 03:36:51 --> Helper loaded: text_helper
INFO - 2026-01-27 03:36:51 --> Helper loaded: string_helper
INFO - 2026-01-27 03:36:51 --> Helper loaded: form_helper
INFO - 2026-01-27 03:36:51 --> Helper loaded: download_helper
INFO - 2026-01-27 03:36:51 --> Helper loaded: security_helper
INFO - 2026-01-27 03:36:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:36:51 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:36:51 --> Form Validation Class Initialized
INFO - 2026-01-27 03:36:51 --> Model "User_model" initialized
INFO - 2026-01-27 09:36:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:36:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:36:51 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:36:51 --> Controller Class Initialized
INFO - 2026-01-27 09:36:51 --> Model "Pages_model" initialized
INFO - 2026-01-27 09:36:51 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:36:51 --> Model "Download_model" initialized
INFO - 2026-01-27 09:36:51 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:36:51 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:36:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-27 09:36:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:36:52 --> Model "Log_model" initialized
INFO - 2026-01-27 09:36:52 --> Final output sent to browser
DEBUG - 2026-01-27 09:36:52 --> Total execution time: 0.1686
INFO - 2026-01-27 03:37:01 --> Config Class Initialized
INFO - 2026-01-27 03:37:01 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:37:01 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:37:01 --> Utf8 Class Initialized
INFO - 2026-01-27 03:37:01 --> URI Class Initialized
DEBUG - 2026-01-27 03:37:01 --> No URI present. Default controller set.
INFO - 2026-01-27 03:37:01 --> Router Class Initialized
INFO - 2026-01-27 03:37:01 --> Output Class Initialized
INFO - 2026-01-27 03:37:01 --> Security Class Initialized
DEBUG - 2026-01-27 03:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:37:01 --> CSRF cookie sent
INFO - 2026-01-27 03:37:01 --> Input Class Initialized
INFO - 2026-01-27 03:37:01 --> Language Class Initialized
INFO - 2026-01-27 03:37:01 --> Loader Class Initialized
INFO - 2026-01-27 03:37:01 --> Helper loaded: url_helper
INFO - 2026-01-27 03:37:01 --> Helper loaded: text_helper
INFO - 2026-01-27 03:37:01 --> Helper loaded: string_helper
INFO - 2026-01-27 03:37:01 --> Helper loaded: form_helper
INFO - 2026-01-27 03:37:01 --> Helper loaded: download_helper
INFO - 2026-01-27 03:37:01 --> Helper loaded: security_helper
INFO - 2026-01-27 03:37:01 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:37:01 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:37:01 --> Form Validation Class Initialized
INFO - 2026-01-27 03:37:01 --> Model "User_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:37:01 --> Controller Class Initialized
INFO - 2026-01-27 09:37:01 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Galeri_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Video_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Agenda_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Tautan_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Mitra_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:37:01 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 09:37:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 09:37:01 --> Pagination Class Initialized
INFO - 2026-01-27 09:37:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 09:37:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:37:01 --> Model "Log_model" initialized
INFO - 2026-01-27 09:37:01 --> Final output sent to browser
DEBUG - 2026-01-27 09:37:01 --> Total execution time: 0.2309
INFO - 2026-01-27 03:37:17 --> Config Class Initialized
INFO - 2026-01-27 03:37:17 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:37:17 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:37:17 --> Utf8 Class Initialized
INFO - 2026-01-27 03:37:17 --> URI Class Initialized
INFO - 2026-01-27 03:37:17 --> Router Class Initialized
INFO - 2026-01-27 03:37:17 --> Output Class Initialized
INFO - 2026-01-27 03:37:17 --> Security Class Initialized
DEBUG - 2026-01-27 03:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:37:17 --> CSRF cookie sent
INFO - 2026-01-27 03:37:17 --> Input Class Initialized
INFO - 2026-01-27 03:37:17 --> Language Class Initialized
INFO - 2026-01-27 03:37:17 --> Loader Class Initialized
INFO - 2026-01-27 03:37:17 --> Helper loaded: url_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: text_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: string_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: form_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: download_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: security_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:37:17 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:37:17 --> Form Validation Class Initialized
INFO - 2026-01-27 03:37:17 --> Model "User_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:37:17 --> Controller Class Initialized
INFO - 2026-01-27 09:37:17 --> Model "Pages_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Download_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:37:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-27 09:37:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:37:17 --> Model "Log_model" initialized
INFO - 2026-01-27 09:37:17 --> Final output sent to browser
DEBUG - 2026-01-27 09:37:17 --> Total execution time: 0.1502
INFO - 2026-01-27 03:37:17 --> Config Class Initialized
INFO - 2026-01-27 03:37:17 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:37:17 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:37:17 --> Utf8 Class Initialized
INFO - 2026-01-27 03:37:17 --> URI Class Initialized
INFO - 2026-01-27 03:37:17 --> Router Class Initialized
INFO - 2026-01-27 03:37:17 --> Output Class Initialized
INFO - 2026-01-27 03:37:17 --> Security Class Initialized
DEBUG - 2026-01-27 03:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:37:17 --> CSRF cookie sent
INFO - 2026-01-27 03:37:17 --> Input Class Initialized
INFO - 2026-01-27 03:37:17 --> Language Class Initialized
INFO - 2026-01-27 03:37:17 --> Loader Class Initialized
INFO - 2026-01-27 03:37:17 --> Helper loaded: url_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: text_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: string_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: form_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: download_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: security_helper
INFO - 2026-01-27 03:37:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:37:17 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:37:17 --> Form Validation Class Initialized
INFO - 2026-01-27 03:37:17 --> Model "User_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:37:17 --> Controller Class Initialized
INFO - 2026-01-27 09:37:17 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Galeri_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Video_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Agenda_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Tautan_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Mitra_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:37:17 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 09:37:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-27 09:37:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:37:17 --> Model "Log_model" initialized
INFO - 2026-01-27 09:37:17 --> Final output sent to browser
DEBUG - 2026-01-27 09:37:17 --> Total execution time: 0.1013
INFO - 2026-01-27 03:37:21 --> Config Class Initialized
INFO - 2026-01-27 03:37:21 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:37:21 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:37:21 --> Utf8 Class Initialized
INFO - 2026-01-27 03:37:21 --> URI Class Initialized
INFO - 2026-01-27 03:37:21 --> Router Class Initialized
INFO - 2026-01-27 03:37:21 --> Output Class Initialized
INFO - 2026-01-27 03:37:21 --> Security Class Initialized
DEBUG - 2026-01-27 03:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:37:21 --> CSRF cookie sent
INFO - 2026-01-27 03:37:21 --> Input Class Initialized
INFO - 2026-01-27 03:37:21 --> Language Class Initialized
INFO - 2026-01-27 03:37:21 --> Loader Class Initialized
INFO - 2026-01-27 03:37:21 --> Helper loaded: url_helper
INFO - 2026-01-27 03:37:21 --> Helper loaded: text_helper
INFO - 2026-01-27 03:37:21 --> Helper loaded: string_helper
INFO - 2026-01-27 03:37:21 --> Helper loaded: form_helper
INFO - 2026-01-27 03:37:21 --> Helper loaded: download_helper
INFO - 2026-01-27 03:37:21 --> Helper loaded: security_helper
INFO - 2026-01-27 03:37:21 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:37:21 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:37:21 --> Form Validation Class Initialized
INFO - 2026-01-27 03:37:21 --> Model "User_model" initialized
INFO - 2026-01-27 09:37:21 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:37:21 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:37:21 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:37:21 --> Controller Class Initialized
INFO - 2026-01-27 09:37:21 --> Model "Download_model" initialized
INFO - 2026-01-27 09:37:21 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:37:21 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:37:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-27 09:37:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:37:21 --> Model "Log_model" initialized
INFO - 2026-01-27 09:37:21 --> Final output sent to browser
DEBUG - 2026-01-27 09:37:21 --> Total execution time: 0.1559
INFO - 2026-01-27 03:37:26 --> Config Class Initialized
INFO - 2026-01-27 03:37:26 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:37:26 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:37:26 --> Utf8 Class Initialized
INFO - 2026-01-27 03:37:26 --> URI Class Initialized
INFO - 2026-01-27 03:37:26 --> Router Class Initialized
INFO - 2026-01-27 03:37:27 --> Output Class Initialized
INFO - 2026-01-27 03:37:27 --> Security Class Initialized
DEBUG - 2026-01-27 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:37:27 --> CSRF cookie sent
INFO - 2026-01-27 03:37:27 --> Input Class Initialized
INFO - 2026-01-27 03:37:27 --> Language Class Initialized
INFO - 2026-01-27 03:37:27 --> Loader Class Initialized
INFO - 2026-01-27 03:37:27 --> Helper loaded: url_helper
INFO - 2026-01-27 03:37:27 --> Helper loaded: text_helper
INFO - 2026-01-27 03:37:27 --> Helper loaded: string_helper
INFO - 2026-01-27 03:37:27 --> Helper loaded: form_helper
INFO - 2026-01-27 03:37:27 --> Helper loaded: download_helper
INFO - 2026-01-27 03:37:27 --> Helper loaded: security_helper
INFO - 2026-01-27 03:37:27 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:37:27 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:37:27 --> Form Validation Class Initialized
INFO - 2026-01-27 03:37:27 --> Model "User_model" initialized
INFO - 2026-01-27 09:37:27 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:37:27 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:37:27 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:37:27 --> Controller Class Initialized
INFO - 2026-01-27 09:37:27 --> Model "Download_model" initialized
INFO - 2026-01-27 09:37:27 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:37:27 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:37:27 --> File downloaded: {"ip_address":"127.0.0.1","user_agent":"Mozilla\/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit\/605.1.15 (KHTML, like Gecko) Version\/14.0.3 Mobile\/15E148 Safari\/604.1","download_id":"25","filename":"Sertifikat_Akreditasi_Diploma_Tiga_Kebidanan_2015-2020.pdf","timestamp":"2026-01-27 09:37:27"}
INFO - 2026-01-27 03:37:36 --> Config Class Initialized
INFO - 2026-01-27 03:37:36 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:37:36 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:37:36 --> Utf8 Class Initialized
INFO - 2026-01-27 03:37:36 --> URI Class Initialized
INFO - 2026-01-27 03:37:36 --> Router Class Initialized
INFO - 2026-01-27 03:37:36 --> Output Class Initialized
INFO - 2026-01-27 03:37:36 --> Security Class Initialized
DEBUG - 2026-01-27 03:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:37:36 --> CSRF cookie sent
INFO - 2026-01-27 03:37:36 --> Input Class Initialized
INFO - 2026-01-27 03:37:36 --> Language Class Initialized
INFO - 2026-01-27 03:37:37 --> Loader Class Initialized
INFO - 2026-01-27 03:37:37 --> Helper loaded: url_helper
INFO - 2026-01-27 03:37:37 --> Helper loaded: text_helper
INFO - 2026-01-27 03:37:37 --> Helper loaded: string_helper
INFO - 2026-01-27 03:37:37 --> Helper loaded: form_helper
INFO - 2026-01-27 03:37:37 --> Helper loaded: download_helper
INFO - 2026-01-27 03:37:37 --> Helper loaded: security_helper
INFO - 2026-01-27 03:37:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:37:37 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:37:37 --> Form Validation Class Initialized
INFO - 2026-01-27 03:37:37 --> Model "User_model" initialized
INFO - 2026-01-27 09:37:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:37:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:37:37 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:37:37 --> Controller Class Initialized
INFO - 2026-01-27 09:37:37 --> Model "Pages_model" initialized
INFO - 2026-01-27 09:37:37 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:37:37 --> Model "Download_model" initialized
INFO - 2026-01-27 09:37:37 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:37:37 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:37:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/alumni.php
INFO - 2026-01-27 09:37:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:37:37 --> Model "Log_model" initialized
INFO - 2026-01-27 09:37:37 --> Final output sent to browser
DEBUG - 2026-01-27 09:37:37 --> Total execution time: 0.1488
INFO - 2026-01-27 03:38:33 --> Config Class Initialized
INFO - 2026-01-27 03:38:33 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:38:33 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:38:33 --> Utf8 Class Initialized
INFO - 2026-01-27 03:38:33 --> URI Class Initialized
INFO - 2026-01-27 03:38:33 --> Router Class Initialized
INFO - 2026-01-27 03:38:33 --> Output Class Initialized
INFO - 2026-01-27 03:38:33 --> Security Class Initialized
DEBUG - 2026-01-27 03:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:38:33 --> CSRF cookie sent
INFO - 2026-01-27 03:38:33 --> Input Class Initialized
INFO - 2026-01-27 03:38:33 --> Language Class Initialized
INFO - 2026-01-27 03:38:33 --> Loader Class Initialized
INFO - 2026-01-27 03:38:33 --> Helper loaded: url_helper
INFO - 2026-01-27 03:38:33 --> Helper loaded: text_helper
INFO - 2026-01-27 03:38:33 --> Helper loaded: string_helper
INFO - 2026-01-27 03:38:33 --> Helper loaded: form_helper
INFO - 2026-01-27 03:38:33 --> Helper loaded: download_helper
INFO - 2026-01-27 03:38:33 --> Helper loaded: security_helper
INFO - 2026-01-27 03:38:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:38:33 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:38:33 --> Form Validation Class Initialized
INFO - 2026-01-27 03:38:33 --> Model "User_model" initialized
INFO - 2026-01-27 09:38:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:38:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:38:33 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:38:33 --> Controller Class Initialized
INFO - 2026-01-27 09:38:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:38:33 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:38:33 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:38:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:38:33 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 09:38:34 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:38:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:38:34 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:38:34 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:38:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:38:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:38:34 --> Model "Log_model" initialized
INFO - 2026-01-27 09:38:34 --> Final output sent to browser
DEBUG - 2026-01-27 09:38:34 --> Total execution time: 0.1968
INFO - 2026-01-27 03:40:25 --> Config Class Initialized
INFO - 2026-01-27 03:40:25 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:40:25 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:40:25 --> Utf8 Class Initialized
INFO - 2026-01-27 03:40:25 --> URI Class Initialized
DEBUG - 2026-01-27 03:40:25 --> No URI present. Default controller set.
INFO - 2026-01-27 03:40:25 --> Router Class Initialized
INFO - 2026-01-27 03:40:25 --> Output Class Initialized
INFO - 2026-01-27 03:40:25 --> Security Class Initialized
DEBUG - 2026-01-27 03:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:40:25 --> CSRF cookie sent
INFO - 2026-01-27 03:40:25 --> Input Class Initialized
INFO - 2026-01-27 03:40:25 --> Language Class Initialized
INFO - 2026-01-27 03:40:25 --> Loader Class Initialized
INFO - 2026-01-27 03:40:25 --> Helper loaded: url_helper
INFO - 2026-01-27 03:40:25 --> Helper loaded: text_helper
INFO - 2026-01-27 03:40:25 --> Helper loaded: string_helper
INFO - 2026-01-27 03:40:25 --> Helper loaded: form_helper
INFO - 2026-01-27 03:40:25 --> Helper loaded: download_helper
INFO - 2026-01-27 03:40:25 --> Helper loaded: security_helper
INFO - 2026-01-27 03:40:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:40:25 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:40:26 --> Form Validation Class Initialized
INFO - 2026-01-27 03:40:26 --> Model "User_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:40:26 --> Controller Class Initialized
INFO - 2026-01-27 09:40:26 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Galeri_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Video_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Agenda_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Tautan_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Mitra_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:40:26 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 09:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 09:40:26 --> Pagination Class Initialized
INFO - 2026-01-27 09:40:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 09:40:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:40:26 --> Model "Log_model" initialized
INFO - 2026-01-27 09:40:26 --> Final output sent to browser
DEBUG - 2026-01-27 09:40:26 --> Total execution time: 0.2867
INFO - 2026-01-27 03:41:38 --> Config Class Initialized
INFO - 2026-01-27 03:41:38 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:41:38 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:41:38 --> Utf8 Class Initialized
INFO - 2026-01-27 03:41:38 --> URI Class Initialized
INFO - 2026-01-27 03:41:38 --> Router Class Initialized
INFO - 2026-01-27 03:41:38 --> Output Class Initialized
INFO - 2026-01-27 03:41:38 --> Security Class Initialized
DEBUG - 2026-01-27 03:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:41:38 --> CSRF cookie sent
INFO - 2026-01-27 03:41:38 --> Input Class Initialized
INFO - 2026-01-27 03:41:38 --> Language Class Initialized
INFO - 2026-01-27 03:41:38 --> Loader Class Initialized
INFO - 2026-01-27 03:41:38 --> Helper loaded: url_helper
INFO - 2026-01-27 03:41:38 --> Helper loaded: text_helper
INFO - 2026-01-27 03:41:38 --> Helper loaded: string_helper
INFO - 2026-01-27 03:41:38 --> Helper loaded: form_helper
INFO - 2026-01-27 03:41:38 --> Helper loaded: download_helper
INFO - 2026-01-27 03:41:38 --> Helper loaded: security_helper
INFO - 2026-01-27 03:41:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:41:38 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:41:38 --> Form Validation Class Initialized
INFO - 2026-01-27 03:41:38 --> Model "User_model" initialized
INFO - 2026-01-27 09:41:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:41:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:41:38 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:41:38 --> Controller Class Initialized
INFO - 2026-01-27 09:41:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:41:38 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:41:38 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:41:38 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:41:38 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2026-01-27 09:41:38 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:41:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:41:38 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:41:38 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:41:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:41:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:41:38 --> Model "Log_model" initialized
INFO - 2026-01-27 09:41:38 --> Final output sent to browser
DEBUG - 2026-01-27 09:41:38 --> Total execution time: 0.1807
INFO - 2026-01-27 03:41:50 --> Config Class Initialized
INFO - 2026-01-27 03:41:50 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:41:50 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:41:50 --> Utf8 Class Initialized
INFO - 2026-01-27 03:41:50 --> URI Class Initialized
DEBUG - 2026-01-27 03:41:50 --> No URI present. Default controller set.
INFO - 2026-01-27 03:41:50 --> Router Class Initialized
INFO - 2026-01-27 03:41:50 --> Output Class Initialized
INFO - 2026-01-27 03:41:50 --> Security Class Initialized
DEBUG - 2026-01-27 03:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:41:50 --> CSRF cookie sent
INFO - 2026-01-27 03:41:50 --> Input Class Initialized
INFO - 2026-01-27 03:41:50 --> Language Class Initialized
INFO - 2026-01-27 03:41:50 --> Loader Class Initialized
INFO - 2026-01-27 03:41:50 --> Helper loaded: url_helper
INFO - 2026-01-27 03:41:50 --> Helper loaded: text_helper
INFO - 2026-01-27 03:41:50 --> Helper loaded: string_helper
INFO - 2026-01-27 03:41:50 --> Helper loaded: form_helper
INFO - 2026-01-27 03:41:50 --> Helper loaded: download_helper
INFO - 2026-01-27 03:41:50 --> Helper loaded: security_helper
INFO - 2026-01-27 03:41:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:41:50 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:41:50 --> Form Validation Class Initialized
INFO - 2026-01-27 03:41:50 --> Model "User_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:41:50 --> Controller Class Initialized
INFO - 2026-01-27 09:41:50 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Galeri_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Video_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Agenda_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Tautan_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Mitra_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:41:50 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 09:41:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 09:41:50 --> Pagination Class Initialized
INFO - 2026-01-27 09:41:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 09:41:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:41:50 --> Model "Log_model" initialized
INFO - 2026-01-27 09:41:50 --> Final output sent to browser
DEBUG - 2026-01-27 09:41:50 --> Total execution time: 0.3873
INFO - 2026-01-27 03:42:19 --> Config Class Initialized
INFO - 2026-01-27 03:42:19 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:42:19 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:42:19 --> Utf8 Class Initialized
INFO - 2026-01-27 03:42:19 --> URI Class Initialized
INFO - 2026-01-27 03:42:19 --> Router Class Initialized
INFO - 2026-01-27 03:42:19 --> Output Class Initialized
INFO - 2026-01-27 03:42:19 --> Security Class Initialized
DEBUG - 2026-01-27 03:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:42:19 --> CSRF cookie sent
INFO - 2026-01-27 03:42:19 --> Input Class Initialized
INFO - 2026-01-27 03:42:19 --> Language Class Initialized
INFO - 2026-01-27 03:42:19 --> Loader Class Initialized
INFO - 2026-01-27 03:42:19 --> Helper loaded: url_helper
INFO - 2026-01-27 03:42:19 --> Helper loaded: text_helper
INFO - 2026-01-27 03:42:19 --> Helper loaded: string_helper
INFO - 2026-01-27 03:42:19 --> Helper loaded: form_helper
INFO - 2026-01-27 03:42:19 --> Helper loaded: download_helper
INFO - 2026-01-27 03:42:19 --> Helper loaded: security_helper
INFO - 2026-01-27 03:42:19 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:42:19 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:42:19 --> Form Validation Class Initialized
INFO - 2026-01-27 03:42:19 --> Model "User_model" initialized
INFO - 2026-01-27 09:42:19 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:42:19 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:42:19 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:42:19 --> Controller Class Initialized
INFO - 2026-01-27 09:42:19 --> Model "Download_model" initialized
INFO - 2026-01-27 09:42:19 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:42:19 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:42:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_perpustakaan.php
INFO - 2026-01-27 09:42:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:42:20 --> Model "Log_model" initialized
INFO - 2026-01-27 09:42:20 --> Final output sent to browser
DEBUG - 2026-01-27 09:42:20 --> Total execution time: 0.2325
INFO - 2026-01-27 03:42:22 --> Config Class Initialized
INFO - 2026-01-27 03:42:22 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:42:22 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:42:22 --> Utf8 Class Initialized
INFO - 2026-01-27 03:42:22 --> URI Class Initialized
INFO - 2026-01-27 03:42:22 --> Router Class Initialized
INFO - 2026-01-27 03:42:22 --> Output Class Initialized
INFO - 2026-01-27 03:42:22 --> Security Class Initialized
DEBUG - 2026-01-27 03:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:42:22 --> CSRF cookie sent
INFO - 2026-01-27 03:42:22 --> Input Class Initialized
INFO - 2026-01-27 03:42:22 --> Language Class Initialized
INFO - 2026-01-27 03:42:22 --> Loader Class Initialized
INFO - 2026-01-27 03:42:22 --> Helper loaded: url_helper
INFO - 2026-01-27 03:42:22 --> Helper loaded: text_helper
INFO - 2026-01-27 03:42:22 --> Helper loaded: string_helper
INFO - 2026-01-27 03:42:22 --> Helper loaded: form_helper
INFO - 2026-01-27 03:42:22 --> Helper loaded: download_helper
INFO - 2026-01-27 03:42:22 --> Helper loaded: security_helper
INFO - 2026-01-27 03:42:22 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:42:22 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:42:22 --> Form Validation Class Initialized
INFO - 2026-01-27 03:42:22 --> Model "User_model" initialized
INFO - 2026-01-27 09:42:22 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:42:22 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:42:22 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:42:22 --> Controller Class Initialized
INFO - 2026-01-27 09:42:22 --> Model "Download_model" initialized
INFO - 2026-01-27 09:42:22 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 09:42:22 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 09:42:22 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"173","filename":"Prosedur_Pelayanan_Perpustakaan.pdf","timestamp":"2026-01-27 09:42:22"}
INFO - 2026-01-27 03:42:27 --> Config Class Initialized
INFO - 2026-01-27 03:42:27 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:42:27 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:42:27 --> Utf8 Class Initialized
INFO - 2026-01-27 03:42:27 --> URI Class Initialized
DEBUG - 2026-01-27 03:42:27 --> No URI present. Default controller set.
INFO - 2026-01-27 03:42:27 --> Router Class Initialized
INFO - 2026-01-27 03:42:27 --> Output Class Initialized
INFO - 2026-01-27 03:42:27 --> Security Class Initialized
DEBUG - 2026-01-27 03:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:42:27 --> CSRF cookie sent
INFO - 2026-01-27 03:42:27 --> Input Class Initialized
INFO - 2026-01-27 03:42:27 --> Language Class Initialized
INFO - 2026-01-27 03:42:27 --> Loader Class Initialized
INFO - 2026-01-27 03:42:27 --> Helper loaded: url_helper
INFO - 2026-01-27 03:42:27 --> Helper loaded: text_helper
INFO - 2026-01-27 03:42:27 --> Helper loaded: string_helper
INFO - 2026-01-27 03:42:27 --> Helper loaded: form_helper
INFO - 2026-01-27 03:42:27 --> Helper loaded: download_helper
INFO - 2026-01-27 03:42:27 --> Helper loaded: security_helper
INFO - 2026-01-27 03:42:27 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:42:27 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:42:27 --> Form Validation Class Initialized
INFO - 2026-01-27 03:42:27 --> Model "User_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:42:27 --> Controller Class Initialized
INFO - 2026-01-27 09:42:27 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Galeri_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Video_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Agenda_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Tautan_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Mitra_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:42:27 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 09:42:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 09:42:27 --> Pagination Class Initialized
INFO - 2026-01-27 09:42:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 09:42:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:42:27 --> Model "Log_model" initialized
INFO - 2026-01-27 09:42:27 --> Final output sent to browser
DEBUG - 2026-01-27 09:42:27 --> Total execution time: 0.3782
INFO - 2026-01-27 03:43:14 --> Config Class Initialized
INFO - 2026-01-27 03:43:14 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:43:14 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:43:14 --> Utf8 Class Initialized
INFO - 2026-01-27 03:43:14 --> URI Class Initialized
DEBUG - 2026-01-27 03:43:14 --> No URI present. Default controller set.
INFO - 2026-01-27 03:43:14 --> Router Class Initialized
INFO - 2026-01-27 03:43:14 --> Output Class Initialized
INFO - 2026-01-27 03:43:14 --> Security Class Initialized
DEBUG - 2026-01-27 03:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:43:14 --> CSRF cookie sent
INFO - 2026-01-27 03:43:14 --> Input Class Initialized
INFO - 2026-01-27 03:43:14 --> Language Class Initialized
INFO - 2026-01-27 03:43:14 --> Loader Class Initialized
INFO - 2026-01-27 03:43:14 --> Helper loaded: url_helper
INFO - 2026-01-27 03:43:14 --> Helper loaded: text_helper
INFO - 2026-01-27 03:43:14 --> Helper loaded: string_helper
INFO - 2026-01-27 03:43:14 --> Helper loaded: form_helper
INFO - 2026-01-27 03:43:14 --> Helper loaded: download_helper
INFO - 2026-01-27 03:43:14 --> Helper loaded: security_helper
INFO - 2026-01-27 03:43:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:43:14 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:43:14 --> Form Validation Class Initialized
INFO - 2026-01-27 03:43:14 --> Model "User_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:43:14 --> Controller Class Initialized
INFO - 2026-01-27 09:43:14 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Galeri_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Video_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Agenda_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Tautan_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Mitra_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:43:14 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 09:43:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 09:43:14 --> Pagination Class Initialized
INFO - 2026-01-27 09:43:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 09:43:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:43:14 --> Model "Log_model" initialized
INFO - 2026-01-27 09:43:14 --> Final output sent to browser
DEBUG - 2026-01-27 09:43:14 --> Total execution time: 0.3349
INFO - 2026-01-27 03:43:29 --> Config Class Initialized
INFO - 2026-01-27 03:43:29 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:43:29 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:43:29 --> Utf8 Class Initialized
INFO - 2026-01-27 03:43:29 --> URI Class Initialized
INFO - 2026-01-27 03:43:29 --> Router Class Initialized
INFO - 2026-01-27 03:43:29 --> Output Class Initialized
INFO - 2026-01-27 03:43:29 --> Security Class Initialized
DEBUG - 2026-01-27 03:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:43:29 --> CSRF cookie sent
INFO - 2026-01-27 03:43:29 --> Input Class Initialized
INFO - 2026-01-27 03:43:29 --> Language Class Initialized
INFO - 2026-01-27 03:43:29 --> Loader Class Initialized
INFO - 2026-01-27 03:43:29 --> Helper loaded: url_helper
INFO - 2026-01-27 03:43:29 --> Helper loaded: text_helper
INFO - 2026-01-27 03:43:29 --> Helper loaded: string_helper
INFO - 2026-01-27 03:43:29 --> Helper loaded: form_helper
INFO - 2026-01-27 03:43:29 --> Helper loaded: download_helper
INFO - 2026-01-27 03:43:29 --> Helper loaded: security_helper
INFO - 2026-01-27 03:43:29 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:43:29 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:43:29 --> Form Validation Class Initialized
INFO - 2026-01-27 03:43:29 --> Model "User_model" initialized
INFO - 2026-01-27 09:43:29 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:43:29 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:43:29 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:43:29 --> Controller Class Initialized
INFO - 2026-01-27 09:43:29 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:43:29 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:43:29 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:43:29 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:43:29 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-27 09:43:29 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:43:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:43:29 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:43:29 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:43:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:43:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:43:29 --> Model "Log_model" initialized
INFO - 2026-01-27 09:43:29 --> Final output sent to browser
DEBUG - 2026-01-27 09:43:29 --> Total execution time: 0.2444
INFO - 2026-01-27 03:49:46 --> Config Class Initialized
INFO - 2026-01-27 03:49:46 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:49:46 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:49:46 --> Utf8 Class Initialized
INFO - 2026-01-27 03:49:46 --> URI Class Initialized
INFO - 2026-01-27 03:49:46 --> Router Class Initialized
INFO - 2026-01-27 03:49:46 --> Output Class Initialized
INFO - 2026-01-27 03:49:46 --> Security Class Initialized
DEBUG - 2026-01-27 03:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:49:46 --> CSRF cookie sent
INFO - 2026-01-27 03:49:46 --> Input Class Initialized
INFO - 2026-01-27 03:49:46 --> Language Class Initialized
INFO - 2026-01-27 03:49:46 --> Loader Class Initialized
INFO - 2026-01-27 03:49:46 --> Helper loaded: url_helper
INFO - 2026-01-27 03:49:46 --> Helper loaded: text_helper
INFO - 2026-01-27 03:49:46 --> Helper loaded: string_helper
INFO - 2026-01-27 03:49:46 --> Helper loaded: form_helper
INFO - 2026-01-27 03:49:46 --> Helper loaded: download_helper
INFO - 2026-01-27 03:49:46 --> Helper loaded: security_helper
INFO - 2026-01-27 03:49:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:49:46 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:49:46 --> Form Validation Class Initialized
INFO - 2026-01-27 03:49:46 --> Model "User_model" initialized
INFO - 2026-01-27 09:49:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:49:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:49:46 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:49:46 --> Controller Class Initialized
INFO - 2026-01-27 09:49:46 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:49:46 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:49:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-27 09:49:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:49:46 --> Model "Log_model" initialized
INFO - 2026-01-27 09:49:46 --> Final output sent to browser
DEBUG - 2026-01-27 09:49:46 --> Total execution time: 0.1431
INFO - 2026-01-27 03:51:22 --> Config Class Initialized
INFO - 2026-01-27 03:51:22 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:51:22 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:51:22 --> Utf8 Class Initialized
INFO - 2026-01-27 03:51:22 --> URI Class Initialized
INFO - 2026-01-27 03:51:22 --> Router Class Initialized
INFO - 2026-01-27 03:51:22 --> Output Class Initialized
INFO - 2026-01-27 03:51:22 --> Security Class Initialized
DEBUG - 2026-01-27 03:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:51:22 --> CSRF cookie sent
INFO - 2026-01-27 03:51:22 --> CSRF token verified
INFO - 2026-01-27 03:51:22 --> Input Class Initialized
INFO - 2026-01-27 03:51:22 --> Language Class Initialized
INFO - 2026-01-27 03:51:22 --> Loader Class Initialized
INFO - 2026-01-27 03:51:22 --> Helper loaded: url_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: text_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: string_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: form_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: download_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: security_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:51:22 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:51:22 --> Form Validation Class Initialized
INFO - 2026-01-27 03:51:22 --> Model "User_model" initialized
INFO - 2026-01-27 09:51:22 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:51:22 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:51:22 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:51:22 --> Controller Class Initialized
INFO - 2026-01-27 09:51:22 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:51:22 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:51:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 03:51:22 --> Config Class Initialized
INFO - 2026-01-27 03:51:22 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:51:22 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:51:22 --> Utf8 Class Initialized
INFO - 2026-01-27 03:51:22 --> URI Class Initialized
INFO - 2026-01-27 03:51:22 --> Router Class Initialized
INFO - 2026-01-27 03:51:22 --> Output Class Initialized
INFO - 2026-01-27 03:51:22 --> Security Class Initialized
DEBUG - 2026-01-27 03:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:51:22 --> CSRF cookie sent
INFO - 2026-01-27 03:51:22 --> Input Class Initialized
INFO - 2026-01-27 03:51:22 --> Language Class Initialized
INFO - 2026-01-27 03:51:22 --> Loader Class Initialized
INFO - 2026-01-27 03:51:22 --> Helper loaded: url_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: text_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: string_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: form_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: download_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: security_helper
INFO - 2026-01-27 03:51:22 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:51:22 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:51:22 --> Form Validation Class Initialized
INFO - 2026-01-27 03:51:22 --> Model "User_model" initialized
INFO - 2026-01-27 09:51:22 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:51:22 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:51:22 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:51:22 --> Controller Class Initialized
INFO - 2026-01-27 09:51:22 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:51:22 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:51:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-27 09:51:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:51:22 --> Model "Log_model" initialized
INFO - 2026-01-27 09:51:22 --> Final output sent to browser
DEBUG - 2026-01-27 09:51:22 --> Total execution time: 0.1580
INFO - 2026-01-27 03:51:26 --> Config Class Initialized
INFO - 2026-01-27 03:51:26 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:51:26 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:51:26 --> Utf8 Class Initialized
INFO - 2026-01-27 03:51:26 --> URI Class Initialized
INFO - 2026-01-27 03:51:26 --> Router Class Initialized
INFO - 2026-01-27 03:51:26 --> Output Class Initialized
INFO - 2026-01-27 03:51:26 --> Security Class Initialized
DEBUG - 2026-01-27 03:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:51:26 --> CSRF cookie sent
INFO - 2026-01-27 03:51:26 --> Input Class Initialized
INFO - 2026-01-27 03:51:26 --> Language Class Initialized
INFO - 2026-01-27 03:51:26 --> Loader Class Initialized
INFO - 2026-01-27 03:51:26 --> Helper loaded: url_helper
INFO - 2026-01-27 03:51:26 --> Helper loaded: text_helper
INFO - 2026-01-27 03:51:26 --> Helper loaded: string_helper
INFO - 2026-01-27 03:51:26 --> Helper loaded: form_helper
INFO - 2026-01-27 03:51:26 --> Helper loaded: download_helper
INFO - 2026-01-27 03:51:26 --> Helper loaded: security_helper
INFO - 2026-01-27 03:51:26 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:51:26 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:51:26 --> Form Validation Class Initialized
INFO - 2026-01-27 03:51:26 --> Model "User_model" initialized
INFO - 2026-01-27 09:51:26 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:51:26 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:51:26 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:51:26 --> Controller Class Initialized
INFO - 2026-01-27 09:51:26 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:51:26 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:51:26 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:51:26 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:51:26 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-27 09:51:26 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:51:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:51:26 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:51:26 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:51:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:51:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:51:26 --> Model "Log_model" initialized
INFO - 2026-01-27 09:51:26 --> Final output sent to browser
DEBUG - 2026-01-27 09:51:26 --> Total execution time: 0.3437
INFO - 2026-01-27 03:52:08 --> Config Class Initialized
INFO - 2026-01-27 03:52:08 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:52:08 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:52:08 --> Utf8 Class Initialized
INFO - 2026-01-27 03:52:08 --> URI Class Initialized
INFO - 2026-01-27 03:52:08 --> Router Class Initialized
INFO - 2026-01-27 03:52:08 --> Output Class Initialized
INFO - 2026-01-27 03:52:08 --> Security Class Initialized
DEBUG - 2026-01-27 03:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:52:08 --> CSRF cookie sent
INFO - 2026-01-27 03:52:08 --> Input Class Initialized
INFO - 2026-01-27 03:52:08 --> Language Class Initialized
INFO - 2026-01-27 03:52:08 --> Loader Class Initialized
INFO - 2026-01-27 03:52:08 --> Helper loaded: url_helper
INFO - 2026-01-27 03:52:08 --> Helper loaded: text_helper
INFO - 2026-01-27 03:52:08 --> Helper loaded: string_helper
INFO - 2026-01-27 03:52:08 --> Helper loaded: form_helper
INFO - 2026-01-27 03:52:08 --> Helper loaded: download_helper
INFO - 2026-01-27 03:52:08 --> Helper loaded: security_helper
INFO - 2026-01-27 03:52:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:52:08 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:52:08 --> Form Validation Class Initialized
INFO - 2026-01-27 03:52:08 --> Model "User_model" initialized
INFO - 2026-01-27 09:52:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:52:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:52:08 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:52:08 --> Controller Class Initialized
INFO - 2026-01-27 09:52:08 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:52:08 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 09:52:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2026-01-27 09:52:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:52:08 --> Model "Log_model" initialized
INFO - 2026-01-27 09:52:08 --> Final output sent to browser
DEBUG - 2026-01-27 09:52:08 --> Total execution time: 0.2550
INFO - 2026-01-27 03:52:11 --> Config Class Initialized
INFO - 2026-01-27 03:52:11 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:52:11 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:52:11 --> Utf8 Class Initialized
INFO - 2026-01-27 03:52:11 --> URI Class Initialized
INFO - 2026-01-27 03:52:11 --> Router Class Initialized
INFO - 2026-01-27 03:52:11 --> Output Class Initialized
INFO - 2026-01-27 03:52:11 --> Security Class Initialized
DEBUG - 2026-01-27 03:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:52:11 --> CSRF cookie sent
INFO - 2026-01-27 03:52:11 --> Input Class Initialized
INFO - 2026-01-27 03:52:11 --> Language Class Initialized
INFO - 2026-01-27 03:52:11 --> Loader Class Initialized
INFO - 2026-01-27 03:52:11 --> Helper loaded: url_helper
INFO - 2026-01-27 03:52:11 --> Helper loaded: text_helper
INFO - 2026-01-27 03:52:11 --> Helper loaded: string_helper
INFO - 2026-01-27 03:52:11 --> Helper loaded: form_helper
INFO - 2026-01-27 03:52:11 --> Helper loaded: download_helper
INFO - 2026-01-27 03:52:11 --> Helper loaded: security_helper
INFO - 2026-01-27 03:52:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:52:11 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:52:11 --> Form Validation Class Initialized
INFO - 2026-01-27 03:52:11 --> Model "User_model" initialized
INFO - 2026-01-27 09:52:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:52:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:52:11 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:52:11 --> Controller Class Initialized
INFO - 2026-01-27 09:52:11 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:52:11 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:52:11 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:52:11 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 09:52:11 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-27 09:52:11 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:52:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 09:52:11 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 09:52:11 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 09:52:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 09:52:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:52:11 --> Model "Log_model" initialized
INFO - 2026-01-27 09:52:11 --> Final output sent to browser
DEBUG - 2026-01-27 09:52:11 --> Total execution time: 0.4391
INFO - 2026-01-27 03:52:14 --> Config Class Initialized
INFO - 2026-01-27 03:52:14 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:52:14 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:52:14 --> Utf8 Class Initialized
INFO - 2026-01-27 03:52:14 --> URI Class Initialized
INFO - 2026-01-27 03:52:14 --> Router Class Initialized
INFO - 2026-01-27 03:52:14 --> Output Class Initialized
INFO - 2026-01-27 03:52:14 --> Security Class Initialized
DEBUG - 2026-01-27 03:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:52:14 --> CSRF cookie sent
INFO - 2026-01-27 03:52:14 --> Input Class Initialized
INFO - 2026-01-27 03:52:14 --> Language Class Initialized
INFO - 2026-01-27 03:52:14 --> Loader Class Initialized
INFO - 2026-01-27 03:52:14 --> Helper loaded: url_helper
INFO - 2026-01-27 03:52:14 --> Helper loaded: text_helper
INFO - 2026-01-27 03:52:14 --> Helper loaded: string_helper
INFO - 2026-01-27 03:52:14 --> Helper loaded: form_helper
INFO - 2026-01-27 03:52:14 --> Helper loaded: download_helper
INFO - 2026-01-27 03:52:14 --> Helper loaded: security_helper
INFO - 2026-01-27 03:52:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:52:14 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:52:14 --> Form Validation Class Initialized
INFO - 2026-01-27 03:52:15 --> Model "User_model" initialized
INFO - 2026-01-27 09:52:15 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:52:15 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:52:15 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:52:15 --> Controller Class Initialized
INFO - 2026-01-27 09:52:15 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:52:15 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 09:52:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2026-01-27 09:52:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:52:15 --> Model "Log_model" initialized
INFO - 2026-01-27 09:52:15 --> Final output sent to browser
DEBUG - 2026-01-27 09:52:15 --> Total execution time: 0.6271
INFO - 2026-01-27 03:52:17 --> Config Class Initialized
INFO - 2026-01-27 03:52:17 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:52:17 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:52:17 --> Utf8 Class Initialized
INFO - 2026-01-27 03:52:17 --> URI Class Initialized
INFO - 2026-01-27 03:52:17 --> Router Class Initialized
INFO - 2026-01-27 03:52:17 --> Output Class Initialized
INFO - 2026-01-27 03:52:17 --> Security Class Initialized
DEBUG - 2026-01-27 03:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:52:17 --> CSRF cookie sent
INFO - 2026-01-27 03:52:17 --> Input Class Initialized
INFO - 2026-01-27 03:52:17 --> Language Class Initialized
INFO - 2026-01-27 03:52:17 --> Loader Class Initialized
INFO - 2026-01-27 03:52:17 --> Helper loaded: url_helper
INFO - 2026-01-27 03:52:17 --> Helper loaded: text_helper
INFO - 2026-01-27 03:52:17 --> Helper loaded: string_helper
INFO - 2026-01-27 03:52:17 --> Helper loaded: form_helper
INFO - 2026-01-27 03:52:17 --> Helper loaded: download_helper
INFO - 2026-01-27 03:52:17 --> Helper loaded: security_helper
INFO - 2026-01-27 03:52:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:52:17 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:52:17 --> Form Validation Class Initialized
INFO - 2026-01-27 03:52:17 --> Model "User_model" initialized
INFO - 2026-01-27 09:52:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:52:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:52:17 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:52:17 --> Controller Class Initialized
INFO - 2026-01-27 09:52:17 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:52:17 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 09:52:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-27 09:52:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:52:17 --> Model "Log_model" initialized
INFO - 2026-01-27 09:52:17 --> Final output sent to browser
DEBUG - 2026-01-27 09:52:17 --> Total execution time: 0.3343
INFO - 2026-01-27 03:52:58 --> Config Class Initialized
INFO - 2026-01-27 03:52:58 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:52:58 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:52:58 --> Utf8 Class Initialized
INFO - 2026-01-27 03:52:58 --> URI Class Initialized
INFO - 2026-01-27 03:52:58 --> Router Class Initialized
INFO - 2026-01-27 03:52:58 --> Output Class Initialized
INFO - 2026-01-27 03:52:58 --> Security Class Initialized
DEBUG - 2026-01-27 03:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:52:58 --> CSRF cookie sent
INFO - 2026-01-27 03:52:58 --> Input Class Initialized
INFO - 2026-01-27 03:52:58 --> Language Class Initialized
INFO - 2026-01-27 03:52:58 --> Loader Class Initialized
INFO - 2026-01-27 03:52:58 --> Helper loaded: url_helper
INFO - 2026-01-27 03:52:58 --> Helper loaded: text_helper
INFO - 2026-01-27 03:52:58 --> Helper loaded: string_helper
INFO - 2026-01-27 03:52:58 --> Helper loaded: form_helper
INFO - 2026-01-27 03:52:58 --> Helper loaded: download_helper
INFO - 2026-01-27 03:52:58 --> Helper loaded: security_helper
INFO - 2026-01-27 03:52:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:52:58 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:52:58 --> Form Validation Class Initialized
INFO - 2026-01-27 03:52:58 --> Model "User_model" initialized
INFO - 2026-01-27 09:52:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:52:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:52:58 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:52:58 --> Controller Class Initialized
INFO - 2026-01-27 09:52:58 --> Model "Staff_model" initialized
INFO - 2026-01-27 09:52:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/staff/list.php
INFO - 2026-01-27 09:52:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:52:58 --> Model "Log_model" initialized
INFO - 2026-01-27 09:52:58 --> Final output sent to browser
DEBUG - 2026-01-27 09:52:58 --> Total execution time: 0.1635
INFO - 2026-01-27 03:53:01 --> Config Class Initialized
INFO - 2026-01-27 03:53:01 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:53:01 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:53:01 --> Utf8 Class Initialized
INFO - 2026-01-27 03:53:01 --> URI Class Initialized
INFO - 2026-01-27 03:53:01 --> Router Class Initialized
INFO - 2026-01-27 03:53:01 --> Output Class Initialized
INFO - 2026-01-27 03:53:01 --> Security Class Initialized
DEBUG - 2026-01-27 03:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:53:01 --> CSRF cookie sent
INFO - 2026-01-27 03:53:01 --> Input Class Initialized
INFO - 2026-01-27 03:53:01 --> Language Class Initialized
INFO - 2026-01-27 03:53:01 --> Loader Class Initialized
INFO - 2026-01-27 03:53:01 --> Helper loaded: url_helper
INFO - 2026-01-27 03:53:01 --> Helper loaded: text_helper
INFO - 2026-01-27 03:53:01 --> Helper loaded: string_helper
INFO - 2026-01-27 03:53:01 --> Helper loaded: form_helper
INFO - 2026-01-27 03:53:01 --> Helper loaded: download_helper
INFO - 2026-01-27 03:53:01 --> Helper loaded: security_helper
INFO - 2026-01-27 03:53:01 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:53:01 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:53:01 --> Form Validation Class Initialized
INFO - 2026-01-27 03:53:01 --> Model "User_model" initialized
INFO - 2026-01-27 09:53:01 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:53:01 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:53:01 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:53:01 --> Controller Class Initialized
INFO - 2026-01-27 09:53:01 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 09:53:01 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:53:01 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:53:01 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:53:01 --> Model "Unit_model" initialized
INFO - 2026-01-27 09:53:01 --> Model "Pusat_model" initialized
INFO - 2026-01-27 09:53:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/list.php
INFO - 2026-01-27 09:53:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:53:01 --> Model "Log_model" initialized
INFO - 2026-01-27 09:53:01 --> Final output sent to browser
DEBUG - 2026-01-27 09:53:01 --> Total execution time: 0.1457
INFO - 2026-01-27 03:53:04 --> Config Class Initialized
INFO - 2026-01-27 03:53:04 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:53:04 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:53:04 --> Utf8 Class Initialized
INFO - 2026-01-27 03:53:04 --> URI Class Initialized
INFO - 2026-01-27 03:53:04 --> Router Class Initialized
INFO - 2026-01-27 03:53:04 --> Output Class Initialized
INFO - 2026-01-27 03:53:04 --> Security Class Initialized
DEBUG - 2026-01-27 03:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:53:04 --> CSRF cookie sent
INFO - 2026-01-27 03:53:04 --> Input Class Initialized
INFO - 2026-01-27 03:53:04 --> Language Class Initialized
INFO - 2026-01-27 03:53:04 --> Loader Class Initialized
INFO - 2026-01-27 03:53:04 --> Helper loaded: url_helper
INFO - 2026-01-27 03:53:04 --> Helper loaded: text_helper
INFO - 2026-01-27 03:53:04 --> Helper loaded: string_helper
INFO - 2026-01-27 03:53:04 --> Helper loaded: form_helper
INFO - 2026-01-27 03:53:04 --> Helper loaded: download_helper
INFO - 2026-01-27 03:53:04 --> Helper loaded: security_helper
INFO - 2026-01-27 03:53:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:53:04 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:53:05 --> Form Validation Class Initialized
INFO - 2026-01-27 03:53:05 --> Model "User_model" initialized
INFO - 2026-01-27 09:53:05 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:53:05 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:53:05 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:53:05 --> Controller Class Initialized
INFO - 2026-01-27 09:53:05 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:53:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2026-01-27 09:53:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:53:05 --> Model "Log_model" initialized
INFO - 2026-01-27 09:53:05 --> Final output sent to browser
DEBUG - 2026-01-27 09:53:05 --> Total execution time: 0.1631
INFO - 2026-01-27 03:53:09 --> Config Class Initialized
INFO - 2026-01-27 03:53:09 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:53:09 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:53:09 --> Utf8 Class Initialized
INFO - 2026-01-27 03:53:09 --> URI Class Initialized
INFO - 2026-01-27 03:53:09 --> Router Class Initialized
INFO - 2026-01-27 03:53:09 --> Output Class Initialized
INFO - 2026-01-27 03:53:09 --> Security Class Initialized
DEBUG - 2026-01-27 03:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:53:09 --> CSRF cookie sent
INFO - 2026-01-27 03:53:09 --> Input Class Initialized
INFO - 2026-01-27 03:53:09 --> Language Class Initialized
INFO - 2026-01-27 03:53:09 --> Loader Class Initialized
INFO - 2026-01-27 03:53:09 --> Helper loaded: url_helper
INFO - 2026-01-27 03:53:09 --> Helper loaded: text_helper
INFO - 2026-01-27 03:53:09 --> Helper loaded: string_helper
INFO - 2026-01-27 03:53:09 --> Helper loaded: form_helper
INFO - 2026-01-27 03:53:09 --> Helper loaded: download_helper
INFO - 2026-01-27 03:53:09 --> Helper loaded: security_helper
INFO - 2026-01-27 03:53:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:53:09 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:53:09 --> Form Validation Class Initialized
INFO - 2026-01-27 03:53:09 --> Model "User_model" initialized
INFO - 2026-01-27 09:53:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:53:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:53:09 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:53:09 --> Controller Class Initialized
INFO - 2026-01-27 09:53:09 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 09:53:09 --> Model "Sdm_model" initialized
INFO - 2026-01-27 09:53:09 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:53:09 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:53:09 --> Model "Unit_model" initialized
INFO - 2026-01-27 09:53:09 --> Model "Pusat_model" initialized
INFO - 2026-01-27 09:53:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/list.php
INFO - 2026-01-27 09:53:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 09:53:09 --> Model "Log_model" initialized
INFO - 2026-01-27 09:53:09 --> Final output sent to browser
DEBUG - 2026-01-27 09:53:09 --> Total execution time: 0.1690
INFO - 2026-01-27 03:57:37 --> Config Class Initialized
INFO - 2026-01-27 03:57:37 --> Hooks Class Initialized
DEBUG - 2026-01-27 03:57:37 --> UTF-8 Support Enabled
INFO - 2026-01-27 03:57:37 --> Utf8 Class Initialized
INFO - 2026-01-27 03:57:37 --> URI Class Initialized
DEBUG - 2026-01-27 03:57:37 --> No URI present. Default controller set.
INFO - 2026-01-27 03:57:37 --> Router Class Initialized
INFO - 2026-01-27 03:57:37 --> Output Class Initialized
INFO - 2026-01-27 03:57:37 --> Security Class Initialized
DEBUG - 2026-01-27 03:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 03:57:37 --> CSRF cookie sent
INFO - 2026-01-27 03:57:37 --> Input Class Initialized
INFO - 2026-01-27 03:57:37 --> Language Class Initialized
INFO - 2026-01-27 03:57:37 --> Loader Class Initialized
INFO - 2026-01-27 03:57:37 --> Helper loaded: url_helper
INFO - 2026-01-27 03:57:37 --> Helper loaded: text_helper
INFO - 2026-01-27 03:57:37 --> Helper loaded: string_helper
INFO - 2026-01-27 03:57:37 --> Helper loaded: form_helper
INFO - 2026-01-27 03:57:37 --> Helper loaded: download_helper
INFO - 2026-01-27 03:57:37 --> Helper loaded: security_helper
INFO - 2026-01-27 03:57:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 03:57:37 --> Database Driver Class Initialized
DEBUG - 2026-01-27 03:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 03:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 03:57:38 --> Form Validation Class Initialized
INFO - 2026-01-27 03:57:38 --> Model "User_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Nav_model" initialized
INFO - 2026-01-27 09:57:38 --> Controller Class Initialized
INFO - 2026-01-27 09:57:38 --> Model "Berita_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Galeri_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Video_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Agenda_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Tautan_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Mitra_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Prodi_model" initialized
INFO - 2026-01-27 09:57:38 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 09:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 09:57:38 --> Pagination Class Initialized
INFO - 2026-01-27 09:57:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 09:57:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 09:57:38 --> Model "Log_model" initialized
INFO - 2026-01-27 09:57:38 --> Final output sent to browser
DEBUG - 2026-01-27 09:57:38 --> Total execution time: 0.2059
INFO - 2026-01-27 04:03:45 --> Config Class Initialized
INFO - 2026-01-27 04:03:45 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:03:45 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:03:45 --> Utf8 Class Initialized
INFO - 2026-01-27 04:03:45 --> URI Class Initialized
INFO - 2026-01-27 04:03:45 --> Router Class Initialized
INFO - 2026-01-27 04:03:45 --> Output Class Initialized
INFO - 2026-01-27 04:03:45 --> Security Class Initialized
DEBUG - 2026-01-27 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:03:45 --> CSRF cookie sent
INFO - 2026-01-27 04:03:45 --> Input Class Initialized
INFO - 2026-01-27 04:03:45 --> Language Class Initialized
INFO - 2026-01-27 04:03:45 --> Loader Class Initialized
INFO - 2026-01-27 04:03:45 --> Helper loaded: url_helper
INFO - 2026-01-27 04:03:45 --> Helper loaded: text_helper
INFO - 2026-01-27 04:03:45 --> Helper loaded: string_helper
INFO - 2026-01-27 04:03:45 --> Helper loaded: form_helper
INFO - 2026-01-27 04:03:45 --> Helper loaded: download_helper
INFO - 2026-01-27 04:03:45 --> Helper loaded: security_helper
INFO - 2026-01-27 04:03:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:03:45 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:03:45 --> Form Validation Class Initialized
INFO - 2026-01-27 04:03:45 --> Model "User_model" initialized
INFO - 2026-01-27 10:03:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:03:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:03:45 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:03:45 --> Controller Class Initialized
INFO - 2026-01-27 10:03:45 --> Model "Pages_model" initialized
INFO - 2026-01-27 10:03:45 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:03:45 --> Model "Download_model" initialized
INFO - 2026-01-27 10:03:45 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 10:03:45 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 10:03:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2026-01-27 10:03:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:03:45 --> Model "Log_model" initialized
INFO - 2026-01-27 10:03:45 --> Final output sent to browser
DEBUG - 2026-01-27 10:03:45 --> Total execution time: 0.2019
INFO - 2026-01-27 04:03:58 --> Config Class Initialized
INFO - 2026-01-27 04:03:58 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:03:58 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:03:58 --> Utf8 Class Initialized
INFO - 2026-01-27 04:03:58 --> URI Class Initialized
INFO - 2026-01-27 04:03:58 --> Router Class Initialized
INFO - 2026-01-27 04:03:58 --> Output Class Initialized
INFO - 2026-01-27 04:03:58 --> Security Class Initialized
DEBUG - 2026-01-27 04:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:03:58 --> CSRF cookie sent
INFO - 2026-01-27 04:03:58 --> Input Class Initialized
INFO - 2026-01-27 04:03:58 --> Language Class Initialized
INFO - 2026-01-27 04:03:58 --> Loader Class Initialized
INFO - 2026-01-27 04:03:58 --> Helper loaded: url_helper
INFO - 2026-01-27 04:03:58 --> Helper loaded: text_helper
INFO - 2026-01-27 04:03:58 --> Helper loaded: string_helper
INFO - 2026-01-27 04:03:58 --> Helper loaded: form_helper
INFO - 2026-01-27 04:03:58 --> Helper loaded: download_helper
INFO - 2026-01-27 04:03:58 --> Helper loaded: security_helper
INFO - 2026-01-27 04:03:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:03:58 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:03:58 --> Form Validation Class Initialized
INFO - 2026-01-27 04:03:58 --> Model "User_model" initialized
INFO - 2026-01-27 10:03:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:03:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:03:58 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:03:58 --> Controller Class Initialized
INFO - 2026-01-27 10:03:58 --> Model "Download_model" initialized
INFO - 2026-01-27 10:03:58 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 10:03:58 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 10:03:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_layananpelanggan.php
INFO - 2026-01-27 10:03:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:03:58 --> Model "Log_model" initialized
INFO - 2026-01-27 10:03:58 --> Final output sent to browser
DEBUG - 2026-01-27 10:03:58 --> Total execution time: 0.1029
INFO - 2026-01-27 04:04:00 --> Config Class Initialized
INFO - 2026-01-27 04:04:00 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:04:00 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:04:00 --> Utf8 Class Initialized
INFO - 2026-01-27 04:04:00 --> URI Class Initialized
INFO - 2026-01-27 04:04:00 --> Router Class Initialized
INFO - 2026-01-27 04:04:00 --> Output Class Initialized
INFO - 2026-01-27 04:04:00 --> Security Class Initialized
DEBUG - 2026-01-27 04:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:04:00 --> CSRF cookie sent
INFO - 2026-01-27 04:04:00 --> Input Class Initialized
INFO - 2026-01-27 04:04:00 --> Language Class Initialized
INFO - 2026-01-27 04:04:00 --> Loader Class Initialized
INFO - 2026-01-27 04:04:00 --> Helper loaded: url_helper
INFO - 2026-01-27 04:04:00 --> Helper loaded: text_helper
INFO - 2026-01-27 04:04:00 --> Helper loaded: string_helper
INFO - 2026-01-27 04:04:00 --> Helper loaded: form_helper
INFO - 2026-01-27 04:04:00 --> Helper loaded: download_helper
INFO - 2026-01-27 04:04:00 --> Helper loaded: security_helper
INFO - 2026-01-27 04:04:00 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:04:00 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:04:00 --> Form Validation Class Initialized
INFO - 2026-01-27 04:04:00 --> Model "User_model" initialized
INFO - 2026-01-27 10:04:00 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:04:00 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:04:00 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:04:00 --> Controller Class Initialized
INFO - 2026-01-27 10:04:00 --> Model "Download_model" initialized
INFO - 2026-01-27 10:04:00 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 10:04:00 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 10:04:00 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"166","filename":"Prosedur_Layanan_Hotline_Services.pdf","timestamp":"2026-01-27 10:04:00"}
INFO - 2026-01-27 04:04:19 --> Config Class Initialized
INFO - 2026-01-27 04:04:19 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:04:19 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:04:19 --> Utf8 Class Initialized
INFO - 2026-01-27 04:04:19 --> URI Class Initialized
INFO - 2026-01-27 04:04:19 --> Router Class Initialized
INFO - 2026-01-27 04:04:19 --> Output Class Initialized
INFO - 2026-01-27 04:04:19 --> Security Class Initialized
DEBUG - 2026-01-27 04:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:04:19 --> CSRF cookie sent
INFO - 2026-01-27 04:04:19 --> Input Class Initialized
INFO - 2026-01-27 04:04:19 --> Language Class Initialized
INFO - 2026-01-27 04:04:19 --> Loader Class Initialized
INFO - 2026-01-27 04:04:19 --> Helper loaded: url_helper
INFO - 2026-01-27 04:04:19 --> Helper loaded: text_helper
INFO - 2026-01-27 04:04:19 --> Helper loaded: string_helper
INFO - 2026-01-27 04:04:19 --> Helper loaded: form_helper
INFO - 2026-01-27 04:04:19 --> Helper loaded: download_helper
INFO - 2026-01-27 04:04:19 --> Helper loaded: security_helper
INFO - 2026-01-27 04:04:19 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:04:19 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:04:19 --> Form Validation Class Initialized
INFO - 2026-01-27 04:04:19 --> Model "User_model" initialized
INFO - 2026-01-27 10:04:19 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:04:19 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:04:19 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:04:19 --> Controller Class Initialized
INFO - 2026-01-27 10:04:19 --> Model "Download_model" initialized
INFO - 2026-01-27 10:04:19 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 10:04:19 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 10:04:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_standardpelayanan.php
INFO - 2026-01-27 10:04:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:04:19 --> Model "Log_model" initialized
INFO - 2026-01-27 10:04:19 --> Final output sent to browser
DEBUG - 2026-01-27 10:04:19 --> Total execution time: 0.2121
INFO - 2026-01-27 04:04:21 --> Config Class Initialized
INFO - 2026-01-27 04:04:21 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:04:21 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:04:21 --> Utf8 Class Initialized
INFO - 2026-01-27 04:04:21 --> URI Class Initialized
INFO - 2026-01-27 04:04:21 --> Router Class Initialized
INFO - 2026-01-27 04:04:21 --> Output Class Initialized
INFO - 2026-01-27 04:04:21 --> Security Class Initialized
DEBUG - 2026-01-27 04:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:04:21 --> CSRF cookie sent
INFO - 2026-01-27 04:04:21 --> Input Class Initialized
INFO - 2026-01-27 04:04:21 --> Language Class Initialized
INFO - 2026-01-27 04:04:21 --> Loader Class Initialized
INFO - 2026-01-27 04:04:21 --> Helper loaded: url_helper
INFO - 2026-01-27 04:04:21 --> Helper loaded: text_helper
INFO - 2026-01-27 04:04:21 --> Helper loaded: string_helper
INFO - 2026-01-27 04:04:21 --> Helper loaded: form_helper
INFO - 2026-01-27 04:04:21 --> Helper loaded: download_helper
INFO - 2026-01-27 04:04:21 --> Helper loaded: security_helper
INFO - 2026-01-27 04:04:21 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:04:21 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:04:21 --> Form Validation Class Initialized
INFO - 2026-01-27 04:04:21 --> Model "User_model" initialized
INFO - 2026-01-27 10:04:21 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:04:21 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:04:21 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:04:21 --> Controller Class Initialized
INFO - 2026-01-27 10:04:21 --> Model "Download_model" initialized
INFO - 2026-01-27 10:04:21 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 10:04:21 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 10:04:21 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"54","filename":"Prosedur_Pemberian_Beasiswa_Bagi_Mahasiswa.pdf","timestamp":"2026-01-27 10:04:21"}
INFO - 2026-01-27 04:04:25 --> Config Class Initialized
INFO - 2026-01-27 04:04:25 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:04:25 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:04:25 --> Utf8 Class Initialized
INFO - 2026-01-27 04:04:25 --> URI Class Initialized
INFO - 2026-01-27 04:04:25 --> Router Class Initialized
INFO - 2026-01-27 04:04:25 --> Output Class Initialized
INFO - 2026-01-27 04:04:25 --> Security Class Initialized
DEBUG - 2026-01-27 04:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:04:25 --> CSRF cookie sent
INFO - 2026-01-27 04:04:25 --> Input Class Initialized
INFO - 2026-01-27 04:04:25 --> Language Class Initialized
INFO - 2026-01-27 04:04:25 --> Loader Class Initialized
INFO - 2026-01-27 04:04:25 --> Helper loaded: url_helper
INFO - 2026-01-27 04:04:25 --> Helper loaded: text_helper
INFO - 2026-01-27 04:04:25 --> Helper loaded: string_helper
INFO - 2026-01-27 04:04:25 --> Helper loaded: form_helper
INFO - 2026-01-27 04:04:25 --> Helper loaded: download_helper
INFO - 2026-01-27 04:04:25 --> Helper loaded: security_helper
INFO - 2026-01-27 04:04:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:04:25 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:04:25 --> Form Validation Class Initialized
INFO - 2026-01-27 04:04:25 --> Model "User_model" initialized
INFO - 2026-01-27 10:04:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:04:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:04:25 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:04:25 --> Controller Class Initialized
INFO - 2026-01-27 10:04:25 --> Model "Download_model" initialized
INFO - 2026-01-27 10:04:25 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 10:04:25 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 10:04:25 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"122","filename":"Standar_Pelayanan_Yudisium.pdf","timestamp":"2026-01-27 10:04:25"}
INFO - 2026-01-27 04:04:30 --> Config Class Initialized
INFO - 2026-01-27 04:04:30 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:04:30 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:04:30 --> Utf8 Class Initialized
INFO - 2026-01-27 04:04:30 --> URI Class Initialized
INFO - 2026-01-27 04:04:30 --> Router Class Initialized
INFO - 2026-01-27 04:04:30 --> Output Class Initialized
INFO - 2026-01-27 04:04:30 --> Security Class Initialized
DEBUG - 2026-01-27 04:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:04:30 --> CSRF cookie sent
INFO - 2026-01-27 04:04:30 --> Input Class Initialized
INFO - 2026-01-27 04:04:30 --> Language Class Initialized
INFO - 2026-01-27 04:04:30 --> Loader Class Initialized
INFO - 2026-01-27 04:04:30 --> Helper loaded: url_helper
INFO - 2026-01-27 04:04:30 --> Helper loaded: text_helper
INFO - 2026-01-27 04:04:30 --> Helper loaded: string_helper
INFO - 2026-01-27 04:04:30 --> Helper loaded: form_helper
INFO - 2026-01-27 04:04:30 --> Helper loaded: download_helper
INFO - 2026-01-27 04:04:30 --> Helper loaded: security_helper
INFO - 2026-01-27 04:04:30 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:04:30 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:04:30 --> Form Validation Class Initialized
INFO - 2026-01-27 04:04:30 --> Model "User_model" initialized
INFO - 2026-01-27 10:04:30 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:04:30 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:04:30 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:04:30 --> Controller Class Initialized
INFO - 2026-01-27 10:04:30 --> Model "Download_model" initialized
INFO - 2026-01-27 10:04:30 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 10:04:30 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 10:04:30 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"116","filename":"Standar_Pelayanan_Prodedur_Pengajuan_UKT.pdf","timestamp":"2026-01-27 10:04:30"}
INFO - 2026-01-27 04:05:03 --> Config Class Initialized
INFO - 2026-01-27 04:05:03 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:05:03 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:05:03 --> Utf8 Class Initialized
INFO - 2026-01-27 04:05:03 --> URI Class Initialized
DEBUG - 2026-01-27 04:05:03 --> No URI present. Default controller set.
INFO - 2026-01-27 04:05:03 --> Router Class Initialized
INFO - 2026-01-27 04:05:03 --> Output Class Initialized
INFO - 2026-01-27 04:05:03 --> Security Class Initialized
DEBUG - 2026-01-27 04:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:05:03 --> CSRF cookie sent
INFO - 2026-01-27 04:05:03 --> Input Class Initialized
INFO - 2026-01-27 04:05:03 --> Language Class Initialized
INFO - 2026-01-27 04:05:03 --> Loader Class Initialized
INFO - 2026-01-27 04:05:03 --> Helper loaded: url_helper
INFO - 2026-01-27 04:05:03 --> Helper loaded: text_helper
INFO - 2026-01-27 04:05:03 --> Helper loaded: string_helper
INFO - 2026-01-27 04:05:03 --> Helper loaded: form_helper
INFO - 2026-01-27 04:05:03 --> Helper loaded: download_helper
INFO - 2026-01-27 04:05:03 --> Helper loaded: security_helper
INFO - 2026-01-27 04:05:03 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:05:03 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:05:03 --> Form Validation Class Initialized
INFO - 2026-01-27 04:05:03 --> Model "User_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:05:03 --> Controller Class Initialized
INFO - 2026-01-27 10:05:03 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Video_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:05:03 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:05:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:05:03 --> Pagination Class Initialized
INFO - 2026-01-27 10:05:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:05:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:05:03 --> Model "Log_model" initialized
INFO - 2026-01-27 10:05:03 --> Final output sent to browser
DEBUG - 2026-01-27 10:05:03 --> Total execution time: 0.2495
INFO - 2026-01-27 04:05:34 --> Config Class Initialized
INFO - 2026-01-27 04:05:34 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:05:34 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:05:34 --> Utf8 Class Initialized
INFO - 2026-01-27 04:05:34 --> URI Class Initialized
DEBUG - 2026-01-27 04:05:34 --> No URI present. Default controller set.
INFO - 2026-01-27 04:05:34 --> Router Class Initialized
INFO - 2026-01-27 04:05:34 --> Output Class Initialized
INFO - 2026-01-27 04:05:34 --> Security Class Initialized
DEBUG - 2026-01-27 04:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:05:34 --> CSRF cookie sent
INFO - 2026-01-27 04:05:34 --> Input Class Initialized
INFO - 2026-01-27 04:05:34 --> Language Class Initialized
INFO - 2026-01-27 04:05:34 --> Loader Class Initialized
INFO - 2026-01-27 04:05:34 --> Helper loaded: url_helper
INFO - 2026-01-27 04:05:34 --> Helper loaded: text_helper
INFO - 2026-01-27 04:05:34 --> Helper loaded: string_helper
INFO - 2026-01-27 04:05:34 --> Helper loaded: form_helper
INFO - 2026-01-27 04:05:34 --> Helper loaded: download_helper
INFO - 2026-01-27 04:05:34 --> Helper loaded: security_helper
INFO - 2026-01-27 04:05:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:05:34 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:05:34 --> Form Validation Class Initialized
INFO - 2026-01-27 04:05:34 --> Model "User_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:05:34 --> Controller Class Initialized
INFO - 2026-01-27 10:05:34 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Video_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:05:34 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:05:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:05:34 --> Pagination Class Initialized
INFO - 2026-01-27 10:05:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:05:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:05:34 --> Model "Log_model" initialized
INFO - 2026-01-27 10:05:34 --> Final output sent to browser
DEBUG - 2026-01-27 10:05:34 --> Total execution time: 0.1609
INFO - 2026-01-27 04:08:11 --> Config Class Initialized
INFO - 2026-01-27 04:08:11 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:08:11 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:08:11 --> Utf8 Class Initialized
INFO - 2026-01-27 04:08:11 --> URI Class Initialized
DEBUG - 2026-01-27 04:08:11 --> No URI present. Default controller set.
INFO - 2026-01-27 04:08:11 --> Router Class Initialized
INFO - 2026-01-27 04:08:11 --> Output Class Initialized
INFO - 2026-01-27 04:08:11 --> Security Class Initialized
DEBUG - 2026-01-27 04:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:08:11 --> CSRF cookie sent
INFO - 2026-01-27 04:08:11 --> Input Class Initialized
INFO - 2026-01-27 04:08:11 --> Language Class Initialized
INFO - 2026-01-27 04:08:11 --> Loader Class Initialized
INFO - 2026-01-27 04:08:11 --> Helper loaded: url_helper
INFO - 2026-01-27 04:08:11 --> Helper loaded: text_helper
INFO - 2026-01-27 04:08:11 --> Helper loaded: string_helper
INFO - 2026-01-27 04:08:11 --> Helper loaded: form_helper
INFO - 2026-01-27 04:08:11 --> Helper loaded: download_helper
INFO - 2026-01-27 04:08:11 --> Helper loaded: security_helper
INFO - 2026-01-27 04:08:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:08:12 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:08:12 --> Form Validation Class Initialized
INFO - 2026-01-27 04:08:12 --> Model "User_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:08:12 --> Controller Class Initialized
INFO - 2026-01-27 10:08:12 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Video_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:08:12 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:08:12 --> Pagination Class Initialized
INFO - 2026-01-27 10:08:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:08:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:08:12 --> Model "Log_model" initialized
INFO - 2026-01-27 10:08:12 --> Final output sent to browser
DEBUG - 2026-01-27 10:08:12 --> Total execution time: 0.3191
INFO - 2026-01-27 04:08:58 --> Config Class Initialized
INFO - 2026-01-27 04:08:58 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:08:58 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:08:58 --> Utf8 Class Initialized
INFO - 2026-01-27 04:08:58 --> URI Class Initialized
INFO - 2026-01-27 04:08:58 --> Router Class Initialized
INFO - 2026-01-27 04:08:58 --> Output Class Initialized
INFO - 2026-01-27 04:08:58 --> Security Class Initialized
DEBUG - 2026-01-27 04:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:08:58 --> CSRF cookie sent
INFO - 2026-01-27 04:08:58 --> Input Class Initialized
INFO - 2026-01-27 04:08:58 --> Language Class Initialized
INFO - 2026-01-27 04:08:58 --> Loader Class Initialized
INFO - 2026-01-27 04:08:58 --> Helper loaded: url_helper
INFO - 2026-01-27 04:08:58 --> Helper loaded: text_helper
INFO - 2026-01-27 04:08:58 --> Helper loaded: string_helper
INFO - 2026-01-27 04:08:58 --> Helper loaded: form_helper
INFO - 2026-01-27 04:08:58 --> Helper loaded: download_helper
INFO - 2026-01-27 04:08:58 --> Helper loaded: security_helper
INFO - 2026-01-27 04:08:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:08:58 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:08:58 --> Form Validation Class Initialized
INFO - 2026-01-27 04:08:58 --> Model "User_model" initialized
INFO - 2026-01-27 10:08:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:08:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:08:58 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:08:58 --> Controller Class Initialized
INFO - 2026-01-27 10:08:58 --> Model "Pages_model" initialized
INFO - 2026-01-27 10:08:58 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:08:58 --> Model "Download_model" initialized
INFO - 2026-01-27 10:08:58 --> Model "Kategori_download_model" initialized
INFO - 2026-01-27 10:08:58 --> Model "Jenis_download_model" initialized
INFO - 2026-01-27 10:08:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-27 10:08:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:08:58 --> Model "Log_model" initialized
INFO - 2026-01-27 10:08:58 --> Final output sent to browser
DEBUG - 2026-01-27 10:08:58 --> Total execution time: 0.2050
INFO - 2026-01-27 04:09:06 --> Config Class Initialized
INFO - 2026-01-27 04:09:06 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:09:06 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:09:06 --> Utf8 Class Initialized
INFO - 2026-01-27 04:09:06 --> URI Class Initialized
DEBUG - 2026-01-27 04:09:06 --> No URI present. Default controller set.
INFO - 2026-01-27 04:09:06 --> Router Class Initialized
INFO - 2026-01-27 04:09:06 --> Output Class Initialized
INFO - 2026-01-27 04:09:06 --> Security Class Initialized
DEBUG - 2026-01-27 04:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:09:06 --> CSRF cookie sent
INFO - 2026-01-27 04:09:06 --> Input Class Initialized
INFO - 2026-01-27 04:09:06 --> Language Class Initialized
INFO - 2026-01-27 04:09:06 --> Loader Class Initialized
INFO - 2026-01-27 04:09:06 --> Helper loaded: url_helper
INFO - 2026-01-27 04:09:06 --> Helper loaded: text_helper
INFO - 2026-01-27 04:09:06 --> Helper loaded: string_helper
INFO - 2026-01-27 04:09:06 --> Helper loaded: form_helper
INFO - 2026-01-27 04:09:06 --> Helper loaded: download_helper
INFO - 2026-01-27 04:09:06 --> Helper loaded: security_helper
INFO - 2026-01-27 04:09:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:09:06 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:09:06 --> Form Validation Class Initialized
INFO - 2026-01-27 04:09:06 --> Model "User_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:09:06 --> Controller Class Initialized
INFO - 2026-01-27 10:09:06 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Video_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:09:06 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:09:06 --> Pagination Class Initialized
INFO - 2026-01-27 10:09:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:09:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:09:06 --> Model "Log_model" initialized
INFO - 2026-01-27 10:09:06 --> Final output sent to browser
DEBUG - 2026-01-27 10:09:06 --> Total execution time: 0.2311
INFO - 2026-01-27 04:13:07 --> Config Class Initialized
INFO - 2026-01-27 04:13:07 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:13:07 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:13:07 --> Utf8 Class Initialized
INFO - 2026-01-27 04:13:07 --> URI Class Initialized
DEBUG - 2026-01-27 04:13:07 --> No URI present. Default controller set.
INFO - 2026-01-27 04:13:07 --> Router Class Initialized
INFO - 2026-01-27 04:13:07 --> Output Class Initialized
INFO - 2026-01-27 04:13:07 --> Security Class Initialized
DEBUG - 2026-01-27 04:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:13:07 --> CSRF cookie sent
INFO - 2026-01-27 04:13:07 --> Input Class Initialized
INFO - 2026-01-27 04:13:07 --> Language Class Initialized
INFO - 2026-01-27 04:13:07 --> Loader Class Initialized
INFO - 2026-01-27 04:13:07 --> Helper loaded: url_helper
INFO - 2026-01-27 04:13:07 --> Helper loaded: text_helper
INFO - 2026-01-27 04:13:07 --> Helper loaded: string_helper
INFO - 2026-01-27 04:13:07 --> Helper loaded: form_helper
INFO - 2026-01-27 04:13:07 --> Helper loaded: download_helper
INFO - 2026-01-27 04:13:07 --> Helper loaded: security_helper
INFO - 2026-01-27 04:13:07 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:13:08 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:13:08 --> Form Validation Class Initialized
INFO - 2026-01-27 04:13:08 --> Model "User_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:13:08 --> Controller Class Initialized
INFO - 2026-01-27 10:13:08 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Video_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:13:08 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:13:08 --> Pagination Class Initialized
INFO - 2026-01-27 10:13:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:13:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:13:08 --> Model "Log_model" initialized
INFO - 2026-01-27 10:13:08 --> Final output sent to browser
DEBUG - 2026-01-27 10:13:08 --> Total execution time: 0.2581
INFO - 2026-01-27 04:15:18 --> Config Class Initialized
INFO - 2026-01-27 04:15:18 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:15:18 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:15:18 --> Utf8 Class Initialized
INFO - 2026-01-27 04:15:18 --> URI Class Initialized
INFO - 2026-01-27 04:15:18 --> Router Class Initialized
INFO - 2026-01-27 04:15:18 --> Output Class Initialized
INFO - 2026-01-27 04:15:18 --> Security Class Initialized
DEBUG - 2026-01-27 04:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:15:18 --> CSRF cookie sent
INFO - 2026-01-27 04:15:18 --> Input Class Initialized
INFO - 2026-01-27 04:15:18 --> Language Class Initialized
INFO - 2026-01-27 04:15:18 --> Loader Class Initialized
INFO - 2026-01-27 04:15:18 --> Helper loaded: url_helper
INFO - 2026-01-27 04:15:18 --> Helper loaded: text_helper
INFO - 2026-01-27 04:15:18 --> Helper loaded: string_helper
INFO - 2026-01-27 04:15:18 --> Helper loaded: form_helper
INFO - 2026-01-27 04:15:18 --> Helper loaded: download_helper
INFO - 2026-01-27 04:15:18 --> Helper loaded: security_helper
INFO - 2026-01-27 04:15:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:15:18 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:15:18 --> Form Validation Class Initialized
INFO - 2026-01-27 04:15:18 --> Model "User_model" initialized
INFO - 2026-01-27 10:15:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:15:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:15:18 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:15:18 --> Controller Class Initialized
INFO - 2026-01-27 10:15:18 --> Model "Helpdesk_model" initialized
INFO - 2026-01-27 10:15:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list.php
INFO - 2026-01-27 10:15:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:15:18 --> Model "Log_model" initialized
INFO - 2026-01-27 10:15:18 --> Final output sent to browser
DEBUG - 2026-01-27 10:15:18 --> Total execution time: 0.1456
INFO - 2026-01-27 04:15:21 --> Config Class Initialized
INFO - 2026-01-27 04:15:21 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:15:21 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:15:21 --> Utf8 Class Initialized
INFO - 2026-01-27 04:15:21 --> URI Class Initialized
INFO - 2026-01-27 04:15:21 --> Router Class Initialized
INFO - 2026-01-27 04:15:21 --> Output Class Initialized
INFO - 2026-01-27 04:15:21 --> Security Class Initialized
DEBUG - 2026-01-27 04:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:15:21 --> CSRF cookie sent
INFO - 2026-01-27 04:15:21 --> Input Class Initialized
INFO - 2026-01-27 04:15:21 --> Language Class Initialized
INFO - 2026-01-27 04:15:21 --> Loader Class Initialized
INFO - 2026-01-27 04:15:21 --> Helper loaded: url_helper
INFO - 2026-01-27 04:15:21 --> Helper loaded: text_helper
INFO - 2026-01-27 04:15:21 --> Helper loaded: string_helper
INFO - 2026-01-27 04:15:21 --> Helper loaded: form_helper
INFO - 2026-01-27 04:15:21 --> Helper loaded: download_helper
INFO - 2026-01-27 04:15:21 --> Helper loaded: security_helper
INFO - 2026-01-27 04:15:21 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:15:21 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:15:21 --> Form Validation Class Initialized
INFO - 2026-01-27 04:15:21 --> Model "User_model" initialized
INFO - 2026-01-27 10:15:21 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:15:21 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:15:21 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:15:21 --> Controller Class Initialized
INFO - 2026-01-27 10:15:21 --> Model "Helpdesk_model" initialized
INFO - 2026-01-27 10:15:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list_sdm.php
INFO - 2026-01-27 10:15:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:15:21 --> Model "Log_model" initialized
INFO - 2026-01-27 10:15:21 --> Final output sent to browser
DEBUG - 2026-01-27 10:15:21 --> Total execution time: 0.2432
INFO - 2026-01-27 04:15:36 --> Config Class Initialized
INFO - 2026-01-27 04:15:36 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:15:36 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:15:36 --> Utf8 Class Initialized
INFO - 2026-01-27 04:15:36 --> URI Class Initialized
DEBUG - 2026-01-27 04:15:36 --> No URI present. Default controller set.
INFO - 2026-01-27 04:15:36 --> Router Class Initialized
INFO - 2026-01-27 04:15:36 --> Output Class Initialized
INFO - 2026-01-27 04:15:36 --> Security Class Initialized
DEBUG - 2026-01-27 04:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:15:36 --> CSRF cookie sent
INFO - 2026-01-27 04:15:36 --> Input Class Initialized
INFO - 2026-01-27 04:15:36 --> Language Class Initialized
INFO - 2026-01-27 04:15:36 --> Loader Class Initialized
INFO - 2026-01-27 04:15:36 --> Helper loaded: url_helper
INFO - 2026-01-27 04:15:36 --> Helper loaded: text_helper
INFO - 2026-01-27 04:15:36 --> Helper loaded: string_helper
INFO - 2026-01-27 04:15:36 --> Helper loaded: form_helper
INFO - 2026-01-27 04:15:36 --> Helper loaded: download_helper
INFO - 2026-01-27 04:15:36 --> Helper loaded: security_helper
INFO - 2026-01-27 04:15:36 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:15:36 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:15:36 --> Form Validation Class Initialized
INFO - 2026-01-27 04:15:36 --> Model "User_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:15:36 --> Controller Class Initialized
INFO - 2026-01-27 10:15:36 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Video_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:15:36 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:15:36 --> Pagination Class Initialized
INFO - 2026-01-27 10:15:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:15:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:15:36 --> Model "Log_model" initialized
INFO - 2026-01-27 10:15:36 --> Final output sent to browser
DEBUG - 2026-01-27 10:15:36 --> Total execution time: 0.2601
INFO - 2026-01-27 04:15:43 --> Config Class Initialized
INFO - 2026-01-27 04:15:43 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:15:43 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:15:43 --> Utf8 Class Initialized
INFO - 2026-01-27 04:15:43 --> URI Class Initialized
DEBUG - 2026-01-27 04:15:43 --> No URI present. Default controller set.
INFO - 2026-01-27 04:15:43 --> Router Class Initialized
INFO - 2026-01-27 04:15:43 --> Output Class Initialized
INFO - 2026-01-27 04:15:43 --> Security Class Initialized
DEBUG - 2026-01-27 04:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:15:43 --> CSRF cookie sent
INFO - 2026-01-27 04:15:43 --> Input Class Initialized
INFO - 2026-01-27 04:15:43 --> Language Class Initialized
INFO - 2026-01-27 04:15:43 --> Loader Class Initialized
INFO - 2026-01-27 04:15:43 --> Helper loaded: url_helper
INFO - 2026-01-27 04:15:43 --> Helper loaded: text_helper
INFO - 2026-01-27 04:15:43 --> Helper loaded: string_helper
INFO - 2026-01-27 04:15:43 --> Helper loaded: form_helper
INFO - 2026-01-27 04:15:43 --> Helper loaded: download_helper
INFO - 2026-01-27 04:15:43 --> Helper loaded: security_helper
INFO - 2026-01-27 04:15:43 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:15:43 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:15:43 --> Form Validation Class Initialized
INFO - 2026-01-27 04:15:43 --> Model "User_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:15:43 --> Controller Class Initialized
INFO - 2026-01-27 10:15:43 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Video_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:15:43 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:15:43 --> Pagination Class Initialized
INFO - 2026-01-27 10:15:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:15:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:15:43 --> Model "Log_model" initialized
INFO - 2026-01-27 10:15:43 --> Final output sent to browser
DEBUG - 2026-01-27 10:15:43 --> Total execution time: 0.2287
INFO - 2026-01-27 04:15:47 --> Config Class Initialized
INFO - 2026-01-27 04:15:47 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:15:47 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:15:47 --> Utf8 Class Initialized
INFO - 2026-01-27 04:15:47 --> URI Class Initialized
DEBUG - 2026-01-27 04:15:47 --> No URI present. Default controller set.
INFO - 2026-01-27 04:15:47 --> Router Class Initialized
INFO - 2026-01-27 04:15:47 --> Output Class Initialized
INFO - 2026-01-27 04:15:47 --> Security Class Initialized
DEBUG - 2026-01-27 04:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:15:47 --> CSRF cookie sent
INFO - 2026-01-27 04:15:47 --> Input Class Initialized
INFO - 2026-01-27 04:15:47 --> Language Class Initialized
INFO - 2026-01-27 04:15:47 --> Loader Class Initialized
INFO - 2026-01-27 04:15:47 --> Helper loaded: url_helper
INFO - 2026-01-27 04:15:47 --> Helper loaded: text_helper
INFO - 2026-01-27 04:15:47 --> Helper loaded: string_helper
INFO - 2026-01-27 04:15:47 --> Helper loaded: form_helper
INFO - 2026-01-27 04:15:47 --> Helper loaded: download_helper
INFO - 2026-01-27 04:15:47 --> Helper loaded: security_helper
INFO - 2026-01-27 04:15:47 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:15:47 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:15:47 --> Form Validation Class Initialized
INFO - 2026-01-27 04:15:47 --> Model "User_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:15:47 --> Controller Class Initialized
INFO - 2026-01-27 10:15:47 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Video_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:15:47 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:15:47 --> Pagination Class Initialized
INFO - 2026-01-27 10:15:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:15:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:15:47 --> Model "Log_model" initialized
INFO - 2026-01-27 10:15:47 --> Final output sent to browser
DEBUG - 2026-01-27 10:15:47 --> Total execution time: 0.2111
INFO - 2026-01-27 04:16:13 --> Config Class Initialized
INFO - 2026-01-27 04:16:13 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:16:13 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:16:13 --> Utf8 Class Initialized
INFO - 2026-01-27 04:16:13 --> URI Class Initialized
DEBUG - 2026-01-27 04:16:13 --> No URI present. Default controller set.
INFO - 2026-01-27 04:16:13 --> Router Class Initialized
INFO - 2026-01-27 04:16:13 --> Output Class Initialized
INFO - 2026-01-27 04:16:13 --> Security Class Initialized
DEBUG - 2026-01-27 04:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:16:13 --> CSRF cookie sent
INFO - 2026-01-27 04:16:13 --> Input Class Initialized
INFO - 2026-01-27 04:16:13 --> Language Class Initialized
INFO - 2026-01-27 04:16:13 --> Loader Class Initialized
INFO - 2026-01-27 04:16:13 --> Helper loaded: url_helper
INFO - 2026-01-27 04:16:13 --> Helper loaded: text_helper
INFO - 2026-01-27 04:16:13 --> Helper loaded: string_helper
INFO - 2026-01-27 04:16:13 --> Helper loaded: form_helper
INFO - 2026-01-27 04:16:13 --> Helper loaded: download_helper
INFO - 2026-01-27 04:16:13 --> Helper loaded: security_helper
INFO - 2026-01-27 04:16:13 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:16:13 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:16:13 --> Form Validation Class Initialized
INFO - 2026-01-27 04:16:13 --> Model "User_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:16:13 --> Controller Class Initialized
INFO - 2026-01-27 10:16:13 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Video_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:16:13 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:16:13 --> Pagination Class Initialized
INFO - 2026-01-27 10:16:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:16:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:16:13 --> Model "Log_model" initialized
INFO - 2026-01-27 10:16:13 --> Final output sent to browser
DEBUG - 2026-01-27 10:16:13 --> Total execution time: 0.2397
INFO - 2026-01-27 04:16:30 --> Config Class Initialized
INFO - 2026-01-27 04:16:30 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:16:30 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:16:30 --> Utf8 Class Initialized
INFO - 2026-01-27 04:16:30 --> URI Class Initialized
INFO - 2026-01-27 04:16:30 --> Router Class Initialized
INFO - 2026-01-27 04:16:30 --> Output Class Initialized
INFO - 2026-01-27 04:16:30 --> Security Class Initialized
DEBUG - 2026-01-27 04:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:16:30 --> CSRF cookie sent
INFO - 2026-01-27 04:16:30 --> Input Class Initialized
INFO - 2026-01-27 04:16:30 --> Language Class Initialized
INFO - 2026-01-27 04:16:30 --> Loader Class Initialized
INFO - 2026-01-27 04:16:30 --> Helper loaded: url_helper
INFO - 2026-01-27 04:16:30 --> Helper loaded: text_helper
INFO - 2026-01-27 04:16:30 --> Helper loaded: string_helper
INFO - 2026-01-27 04:16:30 --> Helper loaded: form_helper
INFO - 2026-01-27 04:16:30 --> Helper loaded: download_helper
INFO - 2026-01-27 04:16:30 --> Helper loaded: security_helper
INFO - 2026-01-27 04:16:30 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:16:30 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:16:30 --> Form Validation Class Initialized
INFO - 2026-01-27 04:16:30 --> Model "User_model" initialized
INFO - 2026-01-27 10:16:30 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:16:30 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:16:30 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:16:30 --> Controller Class Initialized
INFO - 2026-01-27 10:16:30 --> Model "Helpdesk_model" initialized
INFO - 2026-01-27 10:16:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list_sdm.php
INFO - 2026-01-27 10:16:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:16:30 --> Model "Log_model" initialized
INFO - 2026-01-27 10:16:30 --> Final output sent to browser
DEBUG - 2026-01-27 10:16:30 --> Total execution time: 0.2158
INFO - 2026-01-27 04:16:34 --> Config Class Initialized
INFO - 2026-01-27 04:16:34 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:16:34 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:16:34 --> Utf8 Class Initialized
INFO - 2026-01-27 04:16:34 --> URI Class Initialized
INFO - 2026-01-27 04:16:34 --> Router Class Initialized
INFO - 2026-01-27 04:16:34 --> Output Class Initialized
INFO - 2026-01-27 04:16:34 --> Security Class Initialized
DEBUG - 2026-01-27 04:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:16:34 --> CSRF cookie sent
INFO - 2026-01-27 04:16:34 --> Input Class Initialized
INFO - 2026-01-27 04:16:34 --> Language Class Initialized
INFO - 2026-01-27 04:16:34 --> Loader Class Initialized
INFO - 2026-01-27 04:16:34 --> Helper loaded: url_helper
INFO - 2026-01-27 04:16:34 --> Helper loaded: text_helper
INFO - 2026-01-27 04:16:34 --> Helper loaded: string_helper
INFO - 2026-01-27 04:16:34 --> Helper loaded: form_helper
INFO - 2026-01-27 04:16:34 --> Helper loaded: download_helper
INFO - 2026-01-27 04:16:34 --> Helper loaded: security_helper
INFO - 2026-01-27 04:16:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:16:34 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:16:34 --> Form Validation Class Initialized
INFO - 2026-01-27 04:16:34 --> Model "User_model" initialized
INFO - 2026-01-27 10:16:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:16:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:16:34 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:16:34 --> Controller Class Initialized
INFO - 2026-01-27 10:16:34 --> Model "Helpdesk_model" initialized
INFO - 2026-01-27 10:16:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list_sdm.php
INFO - 2026-01-27 10:16:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:16:34 --> Model "Log_model" initialized
INFO - 2026-01-27 10:16:34 --> Final output sent to browser
DEBUG - 2026-01-27 10:16:34 --> Total execution time: 0.1417
INFO - 2026-01-27 04:16:59 --> Config Class Initialized
INFO - 2026-01-27 04:16:59 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:16:59 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:16:59 --> Utf8 Class Initialized
INFO - 2026-01-27 04:16:59 --> URI Class Initialized
INFO - 2026-01-27 04:16:59 --> Router Class Initialized
INFO - 2026-01-27 04:16:59 --> Output Class Initialized
INFO - 2026-01-27 04:16:59 --> Security Class Initialized
DEBUG - 2026-01-27 04:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:17:00 --> CSRF cookie sent
INFO - 2026-01-27 04:17:00 --> Input Class Initialized
INFO - 2026-01-27 04:17:00 --> Language Class Initialized
INFO - 2026-01-27 04:17:00 --> Loader Class Initialized
INFO - 2026-01-27 04:17:00 --> Helper loaded: url_helper
INFO - 2026-01-27 04:17:00 --> Helper loaded: text_helper
INFO - 2026-01-27 04:17:00 --> Helper loaded: string_helper
INFO - 2026-01-27 04:17:00 --> Helper loaded: form_helper
INFO - 2026-01-27 04:17:00 --> Helper loaded: download_helper
INFO - 2026-01-27 04:17:00 --> Helper loaded: security_helper
INFO - 2026-01-27 04:17:00 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:17:00 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:17:00 --> Form Validation Class Initialized
INFO - 2026-01-27 04:17:00 --> Model "User_model" initialized
INFO - 2026-01-27 10:17:00 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:17:00 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:17:00 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:17:00 --> Controller Class Initialized
INFO - 2026-01-27 10:17:00 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:17:00 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:17:00 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:17:00 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 10:17:00 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2026-01-27 10:17:00 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:17:00 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 10:17:00 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 10:17:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 10:17:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:17:00 --> Model "Log_model" initialized
INFO - 2026-01-27 10:17:00 --> Final output sent to browser
DEBUG - 2026-01-27 10:17:00 --> Total execution time: 0.1777
INFO - 2026-01-27 04:17:24 --> Config Class Initialized
INFO - 2026-01-27 04:17:24 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:17:24 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:17:24 --> Utf8 Class Initialized
INFO - 2026-01-27 04:17:24 --> URI Class Initialized
DEBUG - 2026-01-27 04:17:24 --> No URI present. Default controller set.
INFO - 2026-01-27 04:17:24 --> Router Class Initialized
INFO - 2026-01-27 04:17:24 --> Output Class Initialized
INFO - 2026-01-27 04:17:24 --> Security Class Initialized
DEBUG - 2026-01-27 04:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:17:24 --> CSRF cookie sent
INFO - 2026-01-27 04:17:24 --> Input Class Initialized
INFO - 2026-01-27 04:17:24 --> Language Class Initialized
INFO - 2026-01-27 04:17:24 --> Loader Class Initialized
INFO - 2026-01-27 04:17:24 --> Helper loaded: url_helper
INFO - 2026-01-27 04:17:24 --> Helper loaded: text_helper
INFO - 2026-01-27 04:17:24 --> Helper loaded: string_helper
INFO - 2026-01-27 04:17:24 --> Helper loaded: form_helper
INFO - 2026-01-27 04:17:24 --> Helper loaded: download_helper
INFO - 2026-01-27 04:17:24 --> Helper loaded: security_helper
INFO - 2026-01-27 04:17:24 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:17:24 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:17:24 --> Form Validation Class Initialized
INFO - 2026-01-27 04:17:24 --> Model "User_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:17:24 --> Controller Class Initialized
INFO - 2026-01-27 10:17:24 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Video_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:17:24 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:17:24 --> Pagination Class Initialized
INFO - 2026-01-27 10:17:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:17:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:17:24 --> Model "Log_model" initialized
INFO - 2026-01-27 10:17:24 --> Final output sent to browser
DEBUG - 2026-01-27 10:17:24 --> Total execution time: 0.2574
INFO - 2026-01-27 04:17:35 --> Config Class Initialized
INFO - 2026-01-27 04:17:35 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:17:35 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:17:35 --> Utf8 Class Initialized
INFO - 2026-01-27 04:17:35 --> URI Class Initialized
DEBUG - 2026-01-27 04:17:35 --> No URI present. Default controller set.
INFO - 2026-01-27 04:17:35 --> Router Class Initialized
INFO - 2026-01-27 04:17:35 --> Output Class Initialized
INFO - 2026-01-27 04:17:35 --> Security Class Initialized
DEBUG - 2026-01-27 04:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:17:35 --> CSRF cookie sent
INFO - 2026-01-27 04:17:35 --> Input Class Initialized
INFO - 2026-01-27 04:17:35 --> Language Class Initialized
INFO - 2026-01-27 04:17:35 --> Loader Class Initialized
INFO - 2026-01-27 04:17:35 --> Helper loaded: url_helper
INFO - 2026-01-27 04:17:35 --> Helper loaded: text_helper
INFO - 2026-01-27 04:17:35 --> Helper loaded: string_helper
INFO - 2026-01-27 04:17:35 --> Helper loaded: form_helper
INFO - 2026-01-27 04:17:35 --> Helper loaded: download_helper
INFO - 2026-01-27 04:17:35 --> Helper loaded: security_helper
INFO - 2026-01-27 04:17:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:17:35 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:17:35 --> Form Validation Class Initialized
INFO - 2026-01-27 04:17:35 --> Model "User_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:17:35 --> Controller Class Initialized
INFO - 2026-01-27 10:17:35 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Video_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:17:35 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:17:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:17:35 --> Pagination Class Initialized
INFO - 2026-01-27 10:17:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:17:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:17:35 --> Model "Log_model" initialized
INFO - 2026-01-27 10:17:35 --> Final output sent to browser
DEBUG - 2026-01-27 10:17:35 --> Total execution time: 0.2125
INFO - 2026-01-27 04:17:40 --> Config Class Initialized
INFO - 2026-01-27 04:17:40 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:17:40 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:17:40 --> Utf8 Class Initialized
INFO - 2026-01-27 04:17:40 --> URI Class Initialized
INFO - 2026-01-27 04:17:40 --> Router Class Initialized
INFO - 2026-01-27 04:17:40 --> Output Class Initialized
INFO - 2026-01-27 04:17:40 --> Security Class Initialized
DEBUG - 2026-01-27 04:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:17:40 --> CSRF cookie sent
INFO - 2026-01-27 04:17:40 --> Input Class Initialized
INFO - 2026-01-27 04:17:40 --> Language Class Initialized
INFO - 2026-01-27 04:17:40 --> Loader Class Initialized
INFO - 2026-01-27 04:17:40 --> Helper loaded: url_helper
INFO - 2026-01-27 04:17:40 --> Helper loaded: text_helper
INFO - 2026-01-27 04:17:40 --> Helper loaded: string_helper
INFO - 2026-01-27 04:17:40 --> Helper loaded: form_helper
INFO - 2026-01-27 04:17:40 --> Helper loaded: download_helper
INFO - 2026-01-27 04:17:40 --> Helper loaded: security_helper
INFO - 2026-01-27 04:17:40 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:17:40 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:17:40 --> Form Validation Class Initialized
INFO - 2026-01-27 04:17:40 --> Model "User_model" initialized
INFO - 2026-01-27 10:17:40 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:17:40 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:17:40 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:17:40 --> Controller Class Initialized
INFO - 2026-01-27 10:17:40 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:17:40 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:17:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2026-01-27 10:17:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:17:40 --> Model "Log_model" initialized
INFO - 2026-01-27 10:17:40 --> Final output sent to browser
DEBUG - 2026-01-27 10:17:40 --> Total execution time: 0.1457
INFO - 2026-01-27 04:17:44 --> Config Class Initialized
INFO - 2026-01-27 04:17:44 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:17:44 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:17:44 --> Utf8 Class Initialized
INFO - 2026-01-27 04:17:44 --> URI Class Initialized
INFO - 2026-01-27 04:17:44 --> Router Class Initialized
INFO - 2026-01-27 04:17:44 --> Output Class Initialized
INFO - 2026-01-27 04:17:44 --> Security Class Initialized
DEBUG - 2026-01-27 04:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:17:44 --> CSRF cookie sent
INFO - 2026-01-27 04:17:44 --> Input Class Initialized
INFO - 2026-01-27 04:17:44 --> Language Class Initialized
INFO - 2026-01-27 04:17:44 --> Loader Class Initialized
INFO - 2026-01-27 04:17:44 --> Helper loaded: url_helper
INFO - 2026-01-27 04:17:44 --> Helper loaded: text_helper
INFO - 2026-01-27 04:17:44 --> Helper loaded: string_helper
INFO - 2026-01-27 04:17:44 --> Helper loaded: form_helper
INFO - 2026-01-27 04:17:44 --> Helper loaded: download_helper
INFO - 2026-01-27 04:17:44 --> Helper loaded: security_helper
INFO - 2026-01-27 04:17:44 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:17:44 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:17:44 --> Form Validation Class Initialized
INFO - 2026-01-27 04:17:44 --> Model "User_model" initialized
INFO - 2026-01-27 10:17:44 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:17:44 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:17:44 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:17:44 --> Controller Class Initialized
INFO - 2026-01-27 10:17:44 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:17:44 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:17:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2026-01-27 10:17:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:17:44 --> Model "Log_model" initialized
INFO - 2026-01-27 10:17:44 --> Final output sent to browser
DEBUG - 2026-01-27 10:17:44 --> Total execution time: 0.1272
INFO - 2026-01-27 04:18:08 --> Config Class Initialized
INFO - 2026-01-27 04:18:08 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:08 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:08 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:08 --> URI Class Initialized
INFO - 2026-01-27 04:18:08 --> Router Class Initialized
INFO - 2026-01-27 04:18:08 --> Output Class Initialized
INFO - 2026-01-27 04:18:08 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:08 --> CSRF cookie sent
INFO - 2026-01-27 04:18:08 --> CSRF token verified
INFO - 2026-01-27 04:18:08 --> Input Class Initialized
INFO - 2026-01-27 04:18:08 --> Language Class Initialized
INFO - 2026-01-27 04:18:08 --> Loader Class Initialized
INFO - 2026-01-27 04:18:08 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:08 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:08 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:08 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:08 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:08 --> Controller Class Initialized
INFO - 2026-01-27 10:18:08 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:08 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 04:18:08 --> Config Class Initialized
INFO - 2026-01-27 04:18:08 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:08 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:08 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:08 --> URI Class Initialized
INFO - 2026-01-27 04:18:08 --> Router Class Initialized
INFO - 2026-01-27 04:18:08 --> Output Class Initialized
INFO - 2026-01-27 04:18:08 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:08 --> CSRF cookie sent
INFO - 2026-01-27 04:18:08 --> Input Class Initialized
INFO - 2026-01-27 04:18:08 --> Language Class Initialized
INFO - 2026-01-27 04:18:08 --> Loader Class Initialized
INFO - 2026-01-27 04:18:08 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:08 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:08 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:08 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:08 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:08 --> Controller Class Initialized
INFO - 2026-01-27 10:18:08 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:08 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2026-01-27 10:18:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:18:08 --> Model "Log_model" initialized
INFO - 2026-01-27 10:18:08 --> Final output sent to browser
DEBUG - 2026-01-27 10:18:08 --> Total execution time: 0.0859
INFO - 2026-01-27 04:18:11 --> Config Class Initialized
INFO - 2026-01-27 04:18:11 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:11 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:11 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:11 --> URI Class Initialized
INFO - 2026-01-27 04:18:11 --> Router Class Initialized
INFO - 2026-01-27 04:18:11 --> Output Class Initialized
INFO - 2026-01-27 04:18:11 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:11 --> CSRF cookie sent
INFO - 2026-01-27 04:18:11 --> Input Class Initialized
INFO - 2026-01-27 04:18:11 --> Language Class Initialized
INFO - 2026-01-27 04:18:11 --> Loader Class Initialized
INFO - 2026-01-27 04:18:11 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:11 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:11 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:11 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:11 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:11 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:12 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:12 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:12 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:12 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:12 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:12 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:12 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:12 --> Controller Class Initialized
INFO - 2026-01-27 10:18:12 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:12 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2026-01-27 10:18:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:18:12 --> Model "Log_model" initialized
INFO - 2026-01-27 10:18:12 --> Final output sent to browser
DEBUG - 2026-01-27 10:18:12 --> Total execution time: 0.1380
INFO - 2026-01-27 04:18:17 --> Config Class Initialized
INFO - 2026-01-27 04:18:17 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:17 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:17 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:17 --> URI Class Initialized
INFO - 2026-01-27 04:18:17 --> Router Class Initialized
INFO - 2026-01-27 04:18:17 --> Output Class Initialized
INFO - 2026-01-27 04:18:17 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:17 --> CSRF cookie sent
INFO - 2026-01-27 04:18:17 --> CSRF token verified
INFO - 2026-01-27 04:18:17 --> Input Class Initialized
INFO - 2026-01-27 04:18:17 --> Language Class Initialized
INFO - 2026-01-27 04:18:17 --> Loader Class Initialized
INFO - 2026-01-27 04:18:17 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:17 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:17 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:17 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:17 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:17 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:17 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:17 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:17 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:17 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:17 --> Controller Class Initialized
INFO - 2026-01-27 10:18:17 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:17 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 04:18:18 --> Config Class Initialized
INFO - 2026-01-27 04:18:18 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:18 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:18 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:18 --> URI Class Initialized
INFO - 2026-01-27 04:18:18 --> Router Class Initialized
INFO - 2026-01-27 04:18:18 --> Output Class Initialized
INFO - 2026-01-27 04:18:18 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:18 --> CSRF cookie sent
INFO - 2026-01-27 04:18:18 --> Input Class Initialized
INFO - 2026-01-27 04:18:18 --> Language Class Initialized
INFO - 2026-01-27 04:18:18 --> Loader Class Initialized
INFO - 2026-01-27 04:18:18 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:18 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:18 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:18 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:18 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:18 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:18 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:18 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:18 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:18 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:18 --> Controller Class Initialized
INFO - 2026-01-27 10:18:18 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:18 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2026-01-27 10:18:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:18:18 --> Model "Log_model" initialized
INFO - 2026-01-27 10:18:18 --> Final output sent to browser
DEBUG - 2026-01-27 10:18:18 --> Total execution time: 0.0919
INFO - 2026-01-27 04:18:23 --> Config Class Initialized
INFO - 2026-01-27 04:18:23 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:23 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:23 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:23 --> URI Class Initialized
INFO - 2026-01-27 04:18:23 --> Router Class Initialized
INFO - 2026-01-27 04:18:23 --> Output Class Initialized
INFO - 2026-01-27 04:18:23 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:23 --> CSRF cookie sent
INFO - 2026-01-27 04:18:23 --> Input Class Initialized
INFO - 2026-01-27 04:18:23 --> Language Class Initialized
INFO - 2026-01-27 04:18:23 --> Loader Class Initialized
INFO - 2026-01-27 04:18:23 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:23 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:23 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:23 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:23 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:23 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:23 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:23 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:23 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:23 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:23 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:23 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:23 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:23 --> Controller Class Initialized
INFO - 2026-01-27 10:18:23 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:23 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2026-01-27 10:18:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:18:24 --> Model "Log_model" initialized
INFO - 2026-01-27 10:18:24 --> Final output sent to browser
DEBUG - 2026-01-27 10:18:24 --> Total execution time: 0.1226
INFO - 2026-01-27 04:18:28 --> Config Class Initialized
INFO - 2026-01-27 04:18:28 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:28 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:28 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:28 --> URI Class Initialized
INFO - 2026-01-27 04:18:28 --> Router Class Initialized
INFO - 2026-01-27 04:18:28 --> Output Class Initialized
INFO - 2026-01-27 04:18:28 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:28 --> CSRF cookie sent
INFO - 2026-01-27 04:18:28 --> CSRF token verified
INFO - 2026-01-27 04:18:28 --> Input Class Initialized
INFO - 2026-01-27 04:18:28 --> Language Class Initialized
INFO - 2026-01-27 04:18:28 --> Loader Class Initialized
INFO - 2026-01-27 04:18:28 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:28 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:28 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:28 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:28 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:28 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:28 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:28 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:28 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:28 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:28 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:28 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:28 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:28 --> Controller Class Initialized
INFO - 2026-01-27 10:18:28 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:28 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 04:18:29 --> Config Class Initialized
INFO - 2026-01-27 04:18:29 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:29 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:29 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:29 --> URI Class Initialized
INFO - 2026-01-27 04:18:29 --> Router Class Initialized
INFO - 2026-01-27 04:18:29 --> Output Class Initialized
INFO - 2026-01-27 04:18:29 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:29 --> CSRF cookie sent
INFO - 2026-01-27 04:18:29 --> Input Class Initialized
INFO - 2026-01-27 04:18:29 --> Language Class Initialized
INFO - 2026-01-27 04:18:29 --> Loader Class Initialized
INFO - 2026-01-27 04:18:29 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:29 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:29 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:29 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:29 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:29 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:29 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:29 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:29 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:29 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:29 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:29 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:29 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:29 --> Controller Class Initialized
INFO - 2026-01-27 10:18:29 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:29 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2026-01-27 10:18:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:18:29 --> Model "Log_model" initialized
INFO - 2026-01-27 10:18:29 --> Final output sent to browser
DEBUG - 2026-01-27 10:18:29 --> Total execution time: 0.1142
INFO - 2026-01-27 04:18:32 --> Config Class Initialized
INFO - 2026-01-27 04:18:32 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:32 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:32 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:32 --> URI Class Initialized
INFO - 2026-01-27 04:18:32 --> Router Class Initialized
INFO - 2026-01-27 04:18:32 --> Output Class Initialized
INFO - 2026-01-27 04:18:32 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:32 --> CSRF cookie sent
INFO - 2026-01-27 04:18:32 --> Input Class Initialized
INFO - 2026-01-27 04:18:32 --> Language Class Initialized
INFO - 2026-01-27 04:18:32 --> Loader Class Initialized
INFO - 2026-01-27 04:18:32 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:32 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:32 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:32 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:32 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:32 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:32 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:32 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:32 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:32 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:32 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:32 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:32 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:32 --> Controller Class Initialized
INFO - 2026-01-27 10:18:32 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:32 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2026-01-27 10:18:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:18:32 --> Model "Log_model" initialized
INFO - 2026-01-27 10:18:32 --> Final output sent to browser
DEBUG - 2026-01-27 10:18:32 --> Total execution time: 0.1189
INFO - 2026-01-27 04:18:36 --> Config Class Initialized
INFO - 2026-01-27 04:18:36 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:36 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:36 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:36 --> URI Class Initialized
INFO - 2026-01-27 04:18:36 --> Router Class Initialized
INFO - 2026-01-27 04:18:36 --> Output Class Initialized
INFO - 2026-01-27 04:18:36 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:36 --> CSRF cookie sent
INFO - 2026-01-27 04:18:36 --> CSRF token verified
INFO - 2026-01-27 04:18:36 --> Input Class Initialized
INFO - 2026-01-27 04:18:36 --> Language Class Initialized
INFO - 2026-01-27 04:18:36 --> Loader Class Initialized
INFO - 2026-01-27 04:18:36 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:36 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:36 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:36 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:36 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:36 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:36 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:36 --> Controller Class Initialized
INFO - 2026-01-27 10:18:36 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:36 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 04:18:36 --> Config Class Initialized
INFO - 2026-01-27 04:18:36 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:36 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:36 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:36 --> URI Class Initialized
INFO - 2026-01-27 04:18:36 --> Router Class Initialized
INFO - 2026-01-27 04:18:36 --> Output Class Initialized
INFO - 2026-01-27 04:18:36 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:36 --> CSRF cookie sent
INFO - 2026-01-27 04:18:36 --> Input Class Initialized
INFO - 2026-01-27 04:18:36 --> Language Class Initialized
INFO - 2026-01-27 04:18:36 --> Loader Class Initialized
INFO - 2026-01-27 04:18:36 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:36 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:36 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:36 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:36 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:36 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:36 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:36 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:36 --> Controller Class Initialized
INFO - 2026-01-27 10:18:36 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:36 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2026-01-27 10:18:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:18:36 --> Model "Log_model" initialized
INFO - 2026-01-27 10:18:36 --> Final output sent to browser
DEBUG - 2026-01-27 10:18:36 --> Total execution time: 0.0811
INFO - 2026-01-27 04:18:39 --> Config Class Initialized
INFO - 2026-01-27 04:18:39 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:39 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:39 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:39 --> URI Class Initialized
DEBUG - 2026-01-27 04:18:39 --> No URI present. Default controller set.
INFO - 2026-01-27 04:18:39 --> Router Class Initialized
INFO - 2026-01-27 04:18:39 --> Output Class Initialized
INFO - 2026-01-27 04:18:39 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:39 --> CSRF cookie sent
INFO - 2026-01-27 04:18:39 --> Input Class Initialized
INFO - 2026-01-27 04:18:39 --> Language Class Initialized
INFO - 2026-01-27 04:18:39 --> Loader Class Initialized
INFO - 2026-01-27 04:18:39 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:39 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:39 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:39 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:39 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:39 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:39 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:39 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:39 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:39 --> Controller Class Initialized
INFO - 2026-01-27 10:18:39 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Video_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:39 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:18:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:18:39 --> Pagination Class Initialized
INFO - 2026-01-27 10:18:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:18:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:18:39 --> Model "Log_model" initialized
INFO - 2026-01-27 10:18:39 --> Final output sent to browser
DEBUG - 2026-01-27 10:18:39 --> Total execution time: 0.2901
INFO - 2026-01-27 04:18:44 --> Config Class Initialized
INFO - 2026-01-27 04:18:44 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:44 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:44 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:44 --> URI Class Initialized
INFO - 2026-01-27 04:18:44 --> Router Class Initialized
INFO - 2026-01-27 04:18:44 --> Output Class Initialized
INFO - 2026-01-27 04:18:44 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:44 --> CSRF cookie sent
INFO - 2026-01-27 04:18:44 --> Input Class Initialized
INFO - 2026-01-27 04:18:44 --> Language Class Initialized
INFO - 2026-01-27 04:18:44 --> Loader Class Initialized
INFO - 2026-01-27 04:18:44 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:44 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:44 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:44 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:44 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:44 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:44 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:44 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:44 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:44 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:44 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:44 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:44 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:44 --> Controller Class Initialized
INFO - 2026-01-27 10:18:44 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:44 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:44 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:18:44 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 10:18:44 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-27 10:18:44 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:18:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:18:44 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 10:18:44 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 10:18:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 10:18:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:18:44 --> Model "Log_model" initialized
INFO - 2026-01-27 10:18:44 --> Final output sent to browser
DEBUG - 2026-01-27 10:18:44 --> Total execution time: 0.1951
INFO - 2026-01-27 04:18:50 --> Config Class Initialized
INFO - 2026-01-27 04:18:50 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:18:50 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:18:50 --> Utf8 Class Initialized
INFO - 2026-01-27 04:18:50 --> URI Class Initialized
INFO - 2026-01-27 04:18:50 --> Router Class Initialized
INFO - 2026-01-27 04:18:50 --> Output Class Initialized
INFO - 2026-01-27 04:18:50 --> Security Class Initialized
DEBUG - 2026-01-27 04:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:18:50 --> CSRF cookie sent
INFO - 2026-01-27 04:18:50 --> Input Class Initialized
INFO - 2026-01-27 04:18:50 --> Language Class Initialized
INFO - 2026-01-27 04:18:50 --> Loader Class Initialized
INFO - 2026-01-27 04:18:50 --> Helper loaded: url_helper
INFO - 2026-01-27 04:18:50 --> Helper loaded: text_helper
INFO - 2026-01-27 04:18:50 --> Helper loaded: string_helper
INFO - 2026-01-27 04:18:50 --> Helper loaded: form_helper
INFO - 2026-01-27 04:18:50 --> Helper loaded: download_helper
INFO - 2026-01-27 04:18:50 --> Helper loaded: security_helper
INFO - 2026-01-27 04:18:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:18:50 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:18:50 --> Form Validation Class Initialized
INFO - 2026-01-27 04:18:50 --> Model "User_model" initialized
INFO - 2026-01-27 10:18:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:18:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:18:50 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:18:50 --> Controller Class Initialized
INFO - 2026-01-27 10:18:50 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:18:50 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:18:50 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:18:50 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 10:18:50 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-27 10:18:50 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:18:50 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 10:18:50 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 10:18:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 10:18:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:18:50 --> Model "Log_model" initialized
INFO - 2026-01-27 10:18:50 --> Final output sent to browser
DEBUG - 2026-01-27 10:18:50 --> Total execution time: 0.1707
INFO - 2026-01-27 04:35:46 --> Config Class Initialized
INFO - 2026-01-27 04:35:46 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:35:46 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:35:46 --> Utf8 Class Initialized
INFO - 2026-01-27 04:35:46 --> URI Class Initialized
DEBUG - 2026-01-27 04:35:46 --> No URI present. Default controller set.
INFO - 2026-01-27 04:35:46 --> Router Class Initialized
INFO - 2026-01-27 04:35:46 --> Output Class Initialized
INFO - 2026-01-27 04:35:46 --> Security Class Initialized
DEBUG - 2026-01-27 04:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:35:46 --> CSRF cookie sent
INFO - 2026-01-27 04:35:46 --> Input Class Initialized
INFO - 2026-01-27 04:35:46 --> Language Class Initialized
INFO - 2026-01-27 04:35:46 --> Loader Class Initialized
INFO - 2026-01-27 04:35:46 --> Helper loaded: url_helper
INFO - 2026-01-27 04:35:46 --> Helper loaded: text_helper
INFO - 2026-01-27 04:35:46 --> Helper loaded: string_helper
INFO - 2026-01-27 04:35:46 --> Helper loaded: form_helper
INFO - 2026-01-27 04:35:46 --> Helper loaded: download_helper
INFO - 2026-01-27 04:35:46 --> Helper loaded: security_helper
INFO - 2026-01-27 04:35:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:35:46 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:35:46 --> Form Validation Class Initialized
INFO - 2026-01-27 04:35:46 --> Model "User_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:35:46 --> Controller Class Initialized
INFO - 2026-01-27 10:35:46 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Video_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:35:46 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:35:46 --> Pagination Class Initialized
INFO - 2026-01-27 10:35:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:35:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:35:46 --> Model "Log_model" initialized
INFO - 2026-01-27 10:35:46 --> Final output sent to browser
DEBUG - 2026-01-27 10:35:46 --> Total execution time: 0.4049
INFO - 2026-01-27 04:35:52 --> Config Class Initialized
INFO - 2026-01-27 04:35:53 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:35:53 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:35:53 --> Utf8 Class Initialized
INFO - 2026-01-27 04:35:53 --> URI Class Initialized
DEBUG - 2026-01-27 04:35:53 --> No URI present. Default controller set.
INFO - 2026-01-27 04:35:53 --> Router Class Initialized
INFO - 2026-01-27 04:35:53 --> Output Class Initialized
INFO - 2026-01-27 04:35:53 --> Security Class Initialized
DEBUG - 2026-01-27 04:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:35:53 --> CSRF cookie sent
INFO - 2026-01-27 04:35:53 --> Input Class Initialized
INFO - 2026-01-27 04:35:53 --> Language Class Initialized
INFO - 2026-01-27 04:35:53 --> Loader Class Initialized
INFO - 2026-01-27 04:35:53 --> Helper loaded: url_helper
INFO - 2026-01-27 04:35:53 --> Helper loaded: text_helper
INFO - 2026-01-27 04:35:53 --> Helper loaded: string_helper
INFO - 2026-01-27 04:35:53 --> Helper loaded: form_helper
INFO - 2026-01-27 04:35:53 --> Helper loaded: download_helper
INFO - 2026-01-27 04:35:53 --> Helper loaded: security_helper
INFO - 2026-01-27 04:35:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:35:53 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:35:53 --> Form Validation Class Initialized
INFO - 2026-01-27 04:35:53 --> Model "User_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:35:53 --> Controller Class Initialized
INFO - 2026-01-27 10:35:53 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Video_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:35:53 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:35:53 --> Pagination Class Initialized
INFO - 2026-01-27 10:35:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:35:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:35:53 --> Model "Log_model" initialized
INFO - 2026-01-27 10:35:53 --> Final output sent to browser
DEBUG - 2026-01-27 10:35:53 --> Total execution time: 0.3141
INFO - 2026-01-27 04:36:25 --> Config Class Initialized
INFO - 2026-01-27 04:36:25 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:36:25 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:36:25 --> Utf8 Class Initialized
INFO - 2026-01-27 04:36:25 --> URI Class Initialized
DEBUG - 2026-01-27 04:36:25 --> No URI present. Default controller set.
INFO - 2026-01-27 04:36:25 --> Router Class Initialized
INFO - 2026-01-27 04:36:25 --> Output Class Initialized
INFO - 2026-01-27 04:36:25 --> Security Class Initialized
DEBUG - 2026-01-27 04:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:36:25 --> CSRF cookie sent
INFO - 2026-01-27 04:36:25 --> Input Class Initialized
INFO - 2026-01-27 04:36:25 --> Language Class Initialized
INFO - 2026-01-27 04:36:25 --> Loader Class Initialized
INFO - 2026-01-27 04:36:25 --> Helper loaded: url_helper
INFO - 2026-01-27 04:36:25 --> Helper loaded: text_helper
INFO - 2026-01-27 04:36:25 --> Helper loaded: string_helper
INFO - 2026-01-27 04:36:25 --> Helper loaded: form_helper
INFO - 2026-01-27 04:36:25 --> Helper loaded: download_helper
INFO - 2026-01-27 04:36:25 --> Helper loaded: security_helper
INFO - 2026-01-27 04:36:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:36:25 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:36:25 --> Form Validation Class Initialized
INFO - 2026-01-27 04:36:25 --> Model "User_model" initialized
INFO - 2026-01-27 10:36:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:36:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:36:25 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:36:25 --> Controller Class Initialized
INFO - 2026-01-27 10:36:25 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:36:25 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:36:25 --> Model "Video_model" initialized
INFO - 2026-01-27 10:36:25 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:36:26 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:36:26 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:36:26 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:36:26 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:36:26 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:36:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:36:26 --> Pagination Class Initialized
INFO - 2026-01-27 10:36:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:36:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:36:26 --> Model "Log_model" initialized
INFO - 2026-01-27 10:36:26 --> Final output sent to browser
DEBUG - 2026-01-27 10:36:26 --> Total execution time: 0.2065
INFO - 2026-01-27 04:40:09 --> Config Class Initialized
INFO - 2026-01-27 04:40:09 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:40:09 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:40:09 --> Utf8 Class Initialized
INFO - 2026-01-27 04:40:09 --> URI Class Initialized
INFO - 2026-01-27 04:40:09 --> Router Class Initialized
INFO - 2026-01-27 04:40:09 --> Output Class Initialized
INFO - 2026-01-27 04:40:09 --> Security Class Initialized
DEBUG - 2026-01-27 04:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:40:09 --> CSRF cookie sent
INFO - 2026-01-27 04:40:09 --> Input Class Initialized
INFO - 2026-01-27 04:40:09 --> Language Class Initialized
INFO - 2026-01-27 04:40:09 --> Loader Class Initialized
INFO - 2026-01-27 04:40:09 --> Helper loaded: url_helper
INFO - 2026-01-27 04:40:09 --> Helper loaded: text_helper
INFO - 2026-01-27 04:40:09 --> Helper loaded: string_helper
INFO - 2026-01-27 04:40:09 --> Helper loaded: form_helper
INFO - 2026-01-27 04:40:09 --> Helper loaded: download_helper
INFO - 2026-01-27 04:40:09 --> Helper loaded: security_helper
INFO - 2026-01-27 04:40:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:40:09 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:40:09 --> Form Validation Class Initialized
INFO - 2026-01-27 04:40:09 --> Model "User_model" initialized
INFO - 2026-01-27 10:40:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:40:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:40:09 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:40:09 --> Controller Class Initialized
INFO - 2026-01-27 10:40:09 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:40:09 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:40:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-27 10:40:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:40:09 --> Model "Log_model" initialized
INFO - 2026-01-27 10:40:09 --> Final output sent to browser
DEBUG - 2026-01-27 10:40:09 --> Total execution time: 0.2025
INFO - 2026-01-27 04:40:46 --> Config Class Initialized
INFO - 2026-01-27 04:40:46 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:40:46 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:40:46 --> Utf8 Class Initialized
INFO - 2026-01-27 04:40:46 --> URI Class Initialized
INFO - 2026-01-27 04:40:46 --> Router Class Initialized
INFO - 2026-01-27 04:40:46 --> Output Class Initialized
INFO - 2026-01-27 04:40:46 --> Security Class Initialized
DEBUG - 2026-01-27 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:40:46 --> CSRF cookie sent
INFO - 2026-01-27 04:40:46 --> Input Class Initialized
INFO - 2026-01-27 04:40:46 --> Language Class Initialized
INFO - 2026-01-27 04:40:46 --> Loader Class Initialized
INFO - 2026-01-27 04:40:46 --> Helper loaded: url_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: text_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: string_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: form_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: download_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: security_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:40:46 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:40:46 --> Form Validation Class Initialized
INFO - 2026-01-27 04:40:46 --> Model "User_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:40:46 --> Controller Class Initialized
INFO - 2026-01-27 10:40:46 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Pusat_model" initialized
INFO - 2026-01-27 04:40:46 --> Config Class Initialized
INFO - 2026-01-27 04:40:46 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:40:46 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:40:46 --> Utf8 Class Initialized
INFO - 2026-01-27 04:40:46 --> URI Class Initialized
INFO - 2026-01-27 04:40:46 --> Router Class Initialized
INFO - 2026-01-27 04:40:46 --> Output Class Initialized
INFO - 2026-01-27 04:40:46 --> Security Class Initialized
DEBUG - 2026-01-27 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:40:46 --> CSRF cookie sent
INFO - 2026-01-27 04:40:46 --> Input Class Initialized
INFO - 2026-01-27 04:40:46 --> Language Class Initialized
INFO - 2026-01-27 04:40:46 --> Loader Class Initialized
INFO - 2026-01-27 04:40:46 --> Helper loaded: url_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: text_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: string_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: form_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: download_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: security_helper
INFO - 2026-01-27 04:40:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:40:46 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:40:46 --> Form Validation Class Initialized
INFO - 2026-01-27 04:40:46 --> Model "User_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:40:46 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:40:46 --> Controller Class Initialized
DEBUG - 2026-01-27 10:40:46 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 10:40:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-27 10:40:46 --> Model "Log_model" initialized
INFO - 2026-01-27 10:40:46 --> Final output sent to browser
DEBUG - 2026-01-27 10:40:46 --> Total execution time: 0.0860
INFO - 2026-01-27 04:42:13 --> Config Class Initialized
INFO - 2026-01-27 04:42:13 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:42:13 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:42:13 --> Utf8 Class Initialized
INFO - 2026-01-27 04:42:13 --> URI Class Initialized
INFO - 2026-01-27 04:42:13 --> Router Class Initialized
INFO - 2026-01-27 04:42:13 --> Output Class Initialized
INFO - 2026-01-27 04:42:13 --> Security Class Initialized
DEBUG - 2026-01-27 04:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:42:13 --> CSRF cookie sent
INFO - 2026-01-27 04:42:13 --> CSRF token verified
INFO - 2026-01-27 04:42:13 --> Input Class Initialized
INFO - 2026-01-27 04:42:13 --> Language Class Initialized
INFO - 2026-01-27 04:42:13 --> Loader Class Initialized
INFO - 2026-01-27 04:42:13 --> Helper loaded: url_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: text_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: string_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: form_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: download_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: security_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:42:13 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:42:13 --> Form Validation Class Initialized
INFO - 2026-01-27 04:42:13 --> Model "User_model" initialized
INFO - 2026-01-27 10:42:13 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:42:13 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:42:13 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:42:13 --> Controller Class Initialized
DEBUG - 2026-01-27 10:42:13 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 10:42:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 04:42:13 --> Config Class Initialized
INFO - 2026-01-27 04:42:13 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:42:13 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:42:13 --> Utf8 Class Initialized
INFO - 2026-01-27 04:42:13 --> URI Class Initialized
INFO - 2026-01-27 04:42:13 --> Router Class Initialized
INFO - 2026-01-27 04:42:13 --> Output Class Initialized
INFO - 2026-01-27 04:42:13 --> Security Class Initialized
DEBUG - 2026-01-27 04:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:42:13 --> CSRF cookie sent
INFO - 2026-01-27 04:42:13 --> Input Class Initialized
INFO - 2026-01-27 04:42:13 --> Language Class Initialized
INFO - 2026-01-27 04:42:13 --> Loader Class Initialized
INFO - 2026-01-27 04:42:13 --> Helper loaded: url_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: text_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: string_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: form_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: download_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: security_helper
INFO - 2026-01-27 04:42:13 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:42:13 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:42:13 --> Form Validation Class Initialized
INFO - 2026-01-27 04:42:13 --> Model "User_model" initialized
INFO - 2026-01-27 10:42:13 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:42:13 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:42:13 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:42:13 --> Controller Class Initialized
DEBUG - 2026-01-27 10:42:13 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 10:42:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-27 10:42:13 --> Model "Log_model" initialized
INFO - 2026-01-27 10:42:13 --> Final output sent to browser
DEBUG - 2026-01-27 10:42:13 --> Total execution time: 0.0837
INFO - 2026-01-27 04:42:20 --> Config Class Initialized
INFO - 2026-01-27 04:42:20 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:42:20 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:42:20 --> Utf8 Class Initialized
INFO - 2026-01-27 04:42:20 --> URI Class Initialized
INFO - 2026-01-27 04:42:20 --> Router Class Initialized
INFO - 2026-01-27 04:42:20 --> Output Class Initialized
INFO - 2026-01-27 04:42:20 --> Security Class Initialized
DEBUG - 2026-01-27 04:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:42:20 --> CSRF cookie sent
INFO - 2026-01-27 04:42:20 --> CSRF token verified
INFO - 2026-01-27 04:42:20 --> Input Class Initialized
INFO - 2026-01-27 04:42:20 --> Language Class Initialized
INFO - 2026-01-27 04:42:20 --> Loader Class Initialized
INFO - 2026-01-27 04:42:20 --> Helper loaded: url_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: text_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: string_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: form_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: download_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: security_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:42:20 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:42:20 --> Form Validation Class Initialized
INFO - 2026-01-27 04:42:20 --> Model "User_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:42:20 --> Controller Class Initialized
DEBUG - 2026-01-27 10:42:20 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 10:42:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 04:42:20 --> Config Class Initialized
INFO - 2026-01-27 04:42:20 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:42:20 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:42:20 --> Utf8 Class Initialized
INFO - 2026-01-27 04:42:20 --> URI Class Initialized
INFO - 2026-01-27 04:42:20 --> Router Class Initialized
INFO - 2026-01-27 04:42:20 --> Output Class Initialized
INFO - 2026-01-27 04:42:20 --> Security Class Initialized
DEBUG - 2026-01-27 04:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:42:20 --> CSRF cookie sent
INFO - 2026-01-27 04:42:20 --> Input Class Initialized
INFO - 2026-01-27 04:42:20 --> Language Class Initialized
INFO - 2026-01-27 04:42:20 --> Loader Class Initialized
INFO - 2026-01-27 04:42:20 --> Helper loaded: url_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: text_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: string_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: form_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: download_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: security_helper
INFO - 2026-01-27 04:42:20 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:42:20 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:42:20 --> Form Validation Class Initialized
INFO - 2026-01-27 04:42:20 --> Model "User_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:42:20 --> Controller Class Initialized
INFO - 2026-01-27 10:42:20 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:42:20 --> Model "Pusat_model" initialized
INFO - 2026-01-27 10:42:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/list.php
INFO - 2026-01-27 10:42:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:42:20 --> Model "Log_model" initialized
INFO - 2026-01-27 10:42:20 --> Final output sent to browser
DEBUG - 2026-01-27 10:42:20 --> Total execution time: 0.1159
INFO - 2026-01-27 04:42:25 --> Config Class Initialized
INFO - 2026-01-27 04:42:25 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:42:25 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:42:25 --> Utf8 Class Initialized
INFO - 2026-01-27 04:42:25 --> URI Class Initialized
INFO - 2026-01-27 04:42:25 --> Router Class Initialized
INFO - 2026-01-27 04:42:25 --> Output Class Initialized
INFO - 2026-01-27 04:42:25 --> Security Class Initialized
DEBUG - 2026-01-27 04:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:42:25 --> CSRF cookie sent
INFO - 2026-01-27 04:42:25 --> Input Class Initialized
INFO - 2026-01-27 04:42:25 --> Language Class Initialized
INFO - 2026-01-27 04:42:25 --> Loader Class Initialized
INFO - 2026-01-27 04:42:25 --> Helper loaded: url_helper
INFO - 2026-01-27 04:42:25 --> Helper loaded: text_helper
INFO - 2026-01-27 04:42:25 --> Helper loaded: string_helper
INFO - 2026-01-27 04:42:25 --> Helper loaded: form_helper
INFO - 2026-01-27 04:42:25 --> Helper loaded: download_helper
INFO - 2026-01-27 04:42:25 --> Helper loaded: security_helper
INFO - 2026-01-27 04:42:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:42:25 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:42:25 --> Form Validation Class Initialized
INFO - 2026-01-27 04:42:25 --> Model "User_model" initialized
INFO - 2026-01-27 10:42:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:42:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:42:25 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:42:25 --> Controller Class Initialized
INFO - 2026-01-27 10:42:25 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:42:25 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:42:25 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:42:25 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:42:25 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:42:25 --> Model "Pusat_model" initialized
DEBUG - 2026-01-27 10:42:25 --> POST: []
INFO - 2026-01-27 10:42:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/tambah.php
INFO - 2026-01-27 10:42:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:42:25 --> Model "Log_model" initialized
INFO - 2026-01-27 10:42:25 --> Final output sent to browser
DEBUG - 2026-01-27 10:42:25 --> Total execution time: 0.1315
INFO - 2026-01-27 04:42:36 --> Config Class Initialized
INFO - 2026-01-27 04:42:36 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:42:36 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:42:36 --> Utf8 Class Initialized
INFO - 2026-01-27 04:42:36 --> URI Class Initialized
INFO - 2026-01-27 04:42:36 --> Router Class Initialized
INFO - 2026-01-27 04:42:36 --> Output Class Initialized
INFO - 2026-01-27 04:42:36 --> Security Class Initialized
DEBUG - 2026-01-27 04:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:42:36 --> CSRF cookie sent
INFO - 2026-01-27 04:42:36 --> Input Class Initialized
INFO - 2026-01-27 04:42:36 --> Language Class Initialized
INFO - 2026-01-27 04:42:36 --> Loader Class Initialized
INFO - 2026-01-27 04:42:36 --> Helper loaded: url_helper
INFO - 2026-01-27 04:42:36 --> Helper loaded: text_helper
INFO - 2026-01-27 04:42:36 --> Helper loaded: string_helper
INFO - 2026-01-27 04:42:36 --> Helper loaded: form_helper
INFO - 2026-01-27 04:42:36 --> Helper loaded: download_helper
INFO - 2026-01-27 04:42:36 --> Helper loaded: security_helper
INFO - 2026-01-27 04:42:36 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:42:36 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:42:36 --> Form Validation Class Initialized
INFO - 2026-01-27 04:42:36 --> Model "User_model" initialized
INFO - 2026-01-27 10:42:36 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:42:36 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:42:36 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:42:36 --> Controller Class Initialized
INFO - 2026-01-27 10:42:36 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:42:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2026-01-27 10:42:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:42:36 --> Model "Log_model" initialized
INFO - 2026-01-27 10:42:36 --> Final output sent to browser
DEBUG - 2026-01-27 10:42:36 --> Total execution time: 0.1731
INFO - 2026-01-27 04:42:42 --> Config Class Initialized
INFO - 2026-01-27 04:42:42 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:42:42 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:42:42 --> Utf8 Class Initialized
INFO - 2026-01-27 04:42:42 --> URI Class Initialized
INFO - 2026-01-27 04:42:42 --> Router Class Initialized
INFO - 2026-01-27 04:42:42 --> Output Class Initialized
INFO - 2026-01-27 04:42:42 --> Security Class Initialized
DEBUG - 2026-01-27 04:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:42:42 --> CSRF cookie sent
INFO - 2026-01-27 04:42:42 --> Input Class Initialized
INFO - 2026-01-27 04:42:42 --> Language Class Initialized
INFO - 2026-01-27 04:42:42 --> Loader Class Initialized
INFO - 2026-01-27 04:42:42 --> Helper loaded: url_helper
INFO - 2026-01-27 04:42:42 --> Helper loaded: text_helper
INFO - 2026-01-27 04:42:42 --> Helper loaded: string_helper
INFO - 2026-01-27 04:42:42 --> Helper loaded: form_helper
INFO - 2026-01-27 04:42:42 --> Helper loaded: download_helper
INFO - 2026-01-27 04:42:42 --> Helper loaded: security_helper
INFO - 2026-01-27 04:42:42 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:42:42 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:42:42 --> Form Validation Class Initialized
INFO - 2026-01-27 04:42:42 --> Model "User_model" initialized
INFO - 2026-01-27 10:42:42 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:42:42 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:42:42 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:42:42 --> Controller Class Initialized
INFO - 2026-01-27 10:42:42 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:42:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/edit.php
INFO - 2026-01-27 10:42:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:42:42 --> Model "Log_model" initialized
INFO - 2026-01-27 10:42:42 --> Final output sent to browser
DEBUG - 2026-01-27 10:42:42 --> Total execution time: 0.1101
INFO - 2026-01-27 04:42:49 --> Config Class Initialized
INFO - 2026-01-27 04:42:49 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:42:49 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:42:49 --> Utf8 Class Initialized
INFO - 2026-01-27 04:42:49 --> URI Class Initialized
INFO - 2026-01-27 04:42:49 --> Router Class Initialized
INFO - 2026-01-27 04:42:49 --> Output Class Initialized
INFO - 2026-01-27 04:42:49 --> Security Class Initialized
DEBUG - 2026-01-27 04:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:42:49 --> CSRF cookie sent
INFO - 2026-01-27 04:42:49 --> CSRF token verified
INFO - 2026-01-27 04:42:49 --> Input Class Initialized
INFO - 2026-01-27 04:42:49 --> Language Class Initialized
INFO - 2026-01-27 04:42:49 --> Loader Class Initialized
INFO - 2026-01-27 04:42:49 --> Helper loaded: url_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: text_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: string_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: form_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: download_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: security_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:42:49 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:42:49 --> Form Validation Class Initialized
INFO - 2026-01-27 04:42:49 --> Model "User_model" initialized
INFO - 2026-01-27 10:42:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:42:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:42:49 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:42:49 --> Controller Class Initialized
INFO - 2026-01-27 10:42:49 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:42:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 04:42:49 --> Config Class Initialized
INFO - 2026-01-27 04:42:49 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:42:49 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:42:49 --> Utf8 Class Initialized
INFO - 2026-01-27 04:42:49 --> URI Class Initialized
INFO - 2026-01-27 04:42:49 --> Router Class Initialized
INFO - 2026-01-27 04:42:49 --> Output Class Initialized
INFO - 2026-01-27 04:42:49 --> Security Class Initialized
DEBUG - 2026-01-27 04:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:42:49 --> CSRF cookie sent
INFO - 2026-01-27 04:42:49 --> Input Class Initialized
INFO - 2026-01-27 04:42:49 --> Language Class Initialized
INFO - 2026-01-27 04:42:49 --> Loader Class Initialized
INFO - 2026-01-27 04:42:49 --> Helper loaded: url_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: text_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: string_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: form_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: download_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: security_helper
INFO - 2026-01-27 04:42:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:42:49 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:42:49 --> Form Validation Class Initialized
INFO - 2026-01-27 04:42:49 --> Model "User_model" initialized
INFO - 2026-01-27 10:42:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:42:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:42:49 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:42:49 --> Controller Class Initialized
INFO - 2026-01-27 10:42:49 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:42:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2026-01-27 10:42:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:42:49 --> Model "Log_model" initialized
INFO - 2026-01-27 10:42:49 --> Final output sent to browser
DEBUG - 2026-01-27 10:42:49 --> Total execution time: 0.1271
INFO - 2026-01-27 04:43:01 --> Config Class Initialized
INFO - 2026-01-27 04:43:01 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:43:01 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:43:01 --> Utf8 Class Initialized
INFO - 2026-01-27 04:43:01 --> URI Class Initialized
INFO - 2026-01-27 04:43:01 --> Router Class Initialized
INFO - 2026-01-27 04:43:01 --> Output Class Initialized
INFO - 2026-01-27 04:43:01 --> Security Class Initialized
DEBUG - 2026-01-27 04:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:43:01 --> CSRF cookie sent
INFO - 2026-01-27 04:43:01 --> Input Class Initialized
INFO - 2026-01-27 04:43:01 --> Language Class Initialized
INFO - 2026-01-27 04:43:01 --> Loader Class Initialized
INFO - 2026-01-27 04:43:01 --> Helper loaded: url_helper
INFO - 2026-01-27 04:43:01 --> Helper loaded: text_helper
INFO - 2026-01-27 04:43:01 --> Helper loaded: string_helper
INFO - 2026-01-27 04:43:01 --> Helper loaded: form_helper
INFO - 2026-01-27 04:43:01 --> Helper loaded: download_helper
INFO - 2026-01-27 04:43:01 --> Helper loaded: security_helper
INFO - 2026-01-27 04:43:01 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:43:01 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:43:01 --> Form Validation Class Initialized
INFO - 2026-01-27 04:43:01 --> Model "User_model" initialized
INFO - 2026-01-27 10:43:01 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:43:01 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:43:01 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:43:01 --> Controller Class Initialized
INFO - 2026-01-27 10:43:01 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:43:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/tambah.php
INFO - 2026-01-27 10:43:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:43:01 --> Model "Log_model" initialized
INFO - 2026-01-27 10:43:01 --> Final output sent to browser
DEBUG - 2026-01-27 10:43:01 --> Total execution time: 0.0964
INFO - 2026-01-27 04:43:10 --> Config Class Initialized
INFO - 2026-01-27 04:43:10 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:43:10 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:43:10 --> Utf8 Class Initialized
INFO - 2026-01-27 04:43:10 --> URI Class Initialized
INFO - 2026-01-27 04:43:10 --> Router Class Initialized
INFO - 2026-01-27 04:43:10 --> Output Class Initialized
INFO - 2026-01-27 04:43:10 --> Security Class Initialized
DEBUG - 2026-01-27 04:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:43:10 --> CSRF cookie sent
INFO - 2026-01-27 04:43:10 --> Input Class Initialized
INFO - 2026-01-27 04:43:10 --> Language Class Initialized
INFO - 2026-01-27 04:43:10 --> Loader Class Initialized
INFO - 2026-01-27 04:43:10 --> Helper loaded: url_helper
INFO - 2026-01-27 04:43:10 --> Helper loaded: text_helper
INFO - 2026-01-27 04:43:10 --> Helper loaded: string_helper
INFO - 2026-01-27 04:43:10 --> Helper loaded: form_helper
INFO - 2026-01-27 04:43:10 --> Helper loaded: download_helper
INFO - 2026-01-27 04:43:10 --> Helper loaded: security_helper
INFO - 2026-01-27 04:43:10 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:43:10 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:43:10 --> Form Validation Class Initialized
INFO - 2026-01-27 04:43:10 --> Model "User_model" initialized
INFO - 2026-01-27 10:43:10 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:43:10 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:43:10 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:43:10 --> Controller Class Initialized
INFO - 2026-01-27 10:43:10 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:43:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2026-01-27 10:43:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:43:10 --> Model "Log_model" initialized
INFO - 2026-01-27 10:43:10 --> Final output sent to browser
DEBUG - 2026-01-27 10:43:10 --> Total execution time: 0.1673
INFO - 2026-01-27 04:43:24 --> Config Class Initialized
INFO - 2026-01-27 04:43:24 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:43:24 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:43:24 --> Utf8 Class Initialized
INFO - 2026-01-27 04:43:24 --> URI Class Initialized
INFO - 2026-01-27 04:43:24 --> Router Class Initialized
INFO - 2026-01-27 04:43:24 --> Output Class Initialized
INFO - 2026-01-27 04:43:24 --> Security Class Initialized
DEBUG - 2026-01-27 04:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:43:24 --> CSRF cookie sent
INFO - 2026-01-27 04:43:24 --> Input Class Initialized
INFO - 2026-01-27 04:43:24 --> Language Class Initialized
INFO - 2026-01-27 04:43:24 --> Loader Class Initialized
INFO - 2026-01-27 04:43:24 --> Helper loaded: url_helper
INFO - 2026-01-27 04:43:24 --> Helper loaded: text_helper
INFO - 2026-01-27 04:43:24 --> Helper loaded: string_helper
INFO - 2026-01-27 04:43:24 --> Helper loaded: form_helper
INFO - 2026-01-27 04:43:24 --> Helper loaded: download_helper
INFO - 2026-01-27 04:43:24 --> Helper loaded: security_helper
INFO - 2026-01-27 04:43:24 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:43:24 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:43:24 --> Form Validation Class Initialized
INFO - 2026-01-27 04:43:24 --> Model "User_model" initialized
INFO - 2026-01-27 10:43:24 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:43:24 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:43:24 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:43:24 --> Controller Class Initialized
INFO - 2026-01-27 10:43:24 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:43:24 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:43:24 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:43:24 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 10:43:25 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-27 10:43:25 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:43:25 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 10:43:25 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 10:43:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 10:43:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:43:25 --> Model "Log_model" initialized
INFO - 2026-01-27 10:43:25 --> Final output sent to browser
DEBUG - 2026-01-27 10:43:25 --> Total execution time: 0.1757
INFO - 2026-01-27 04:43:35 --> Config Class Initialized
INFO - 2026-01-27 04:43:35 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:43:35 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:43:35 --> Utf8 Class Initialized
INFO - 2026-01-27 04:43:35 --> URI Class Initialized
INFO - 2026-01-27 04:43:35 --> Router Class Initialized
INFO - 2026-01-27 04:43:35 --> Output Class Initialized
INFO - 2026-01-27 04:43:35 --> Security Class Initialized
DEBUG - 2026-01-27 04:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:43:35 --> CSRF cookie sent
INFO - 2026-01-27 04:43:35 --> Input Class Initialized
INFO - 2026-01-27 04:43:35 --> Language Class Initialized
INFO - 2026-01-27 04:43:35 --> Loader Class Initialized
INFO - 2026-01-27 04:43:35 --> Helper loaded: url_helper
INFO - 2026-01-27 04:43:35 --> Helper loaded: text_helper
INFO - 2026-01-27 04:43:35 --> Helper loaded: string_helper
INFO - 2026-01-27 04:43:35 --> Helper loaded: form_helper
INFO - 2026-01-27 04:43:35 --> Helper loaded: download_helper
INFO - 2026-01-27 04:43:35 --> Helper loaded: security_helper
INFO - 2026-01-27 04:43:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:43:35 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:43:35 --> Form Validation Class Initialized
INFO - 2026-01-27 04:43:35 --> Model "User_model" initialized
INFO - 2026-01-27 10:43:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:43:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:43:35 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:43:35 --> Controller Class Initialized
INFO - 2026-01-27 10:43:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:43:35 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:43:35 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:43:35 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 10:43:35 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2026-01-27 10:43:35 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:43:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:43:35 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 10:43:35 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 10:43:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 10:43:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:43:35 --> Model "Log_model" initialized
INFO - 2026-01-27 10:43:35 --> Final output sent to browser
DEBUG - 2026-01-27 10:43:35 --> Total execution time: 0.1508
INFO - 2026-01-27 04:43:41 --> Config Class Initialized
INFO - 2026-01-27 04:43:41 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:43:41 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:43:41 --> Utf8 Class Initialized
INFO - 2026-01-27 04:43:41 --> URI Class Initialized
INFO - 2026-01-27 04:43:41 --> Router Class Initialized
INFO - 2026-01-27 04:43:41 --> Output Class Initialized
INFO - 2026-01-27 04:43:41 --> Security Class Initialized
DEBUG - 2026-01-27 04:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:43:41 --> CSRF cookie sent
INFO - 2026-01-27 04:43:41 --> Input Class Initialized
INFO - 2026-01-27 04:43:41 --> Language Class Initialized
INFO - 2026-01-27 04:43:41 --> Loader Class Initialized
INFO - 2026-01-27 04:43:41 --> Helper loaded: url_helper
INFO - 2026-01-27 04:43:41 --> Helper loaded: text_helper
INFO - 2026-01-27 04:43:41 --> Helper loaded: string_helper
INFO - 2026-01-27 04:43:41 --> Helper loaded: form_helper
INFO - 2026-01-27 04:43:41 --> Helper loaded: download_helper
INFO - 2026-01-27 04:43:41 --> Helper loaded: security_helper
INFO - 2026-01-27 04:43:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:43:41 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:43:41 --> Form Validation Class Initialized
INFO - 2026-01-27 04:43:41 --> Model "User_model" initialized
INFO - 2026-01-27 10:43:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:43:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:43:41 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:43:41 --> Controller Class Initialized
INFO - 2026-01-27 10:43:41 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:43:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/tambah.php
INFO - 2026-01-27 10:43:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:43:41 --> Model "Log_model" initialized
INFO - 2026-01-27 10:43:41 --> Final output sent to browser
DEBUG - 2026-01-27 10:43:41 --> Total execution time: 0.1026
INFO - 2026-01-27 04:44:51 --> Config Class Initialized
INFO - 2026-01-27 04:44:51 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:44:51 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:44:51 --> Utf8 Class Initialized
INFO - 2026-01-27 04:44:51 --> URI Class Initialized
INFO - 2026-01-27 04:44:51 --> Router Class Initialized
INFO - 2026-01-27 04:44:51 --> Output Class Initialized
INFO - 2026-01-27 04:44:51 --> Security Class Initialized
DEBUG - 2026-01-27 04:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:44:51 --> CSRF cookie sent
INFO - 2026-01-27 04:44:51 --> CSRF token verified
INFO - 2026-01-27 04:44:51 --> Input Class Initialized
INFO - 2026-01-27 04:44:51 --> Language Class Initialized
INFO - 2026-01-27 04:44:51 --> Loader Class Initialized
INFO - 2026-01-27 04:44:51 --> Helper loaded: url_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: text_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: string_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: form_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: download_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: security_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:44:51 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:44:51 --> Form Validation Class Initialized
INFO - 2026-01-27 04:44:51 --> Model "User_model" initialized
INFO - 2026-01-27 10:44:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:44:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:44:51 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:44:51 --> Controller Class Initialized
INFO - 2026-01-27 10:44:51 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:44:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 10:44:51 --> Upload Class Initialized
INFO - 2026-01-27 04:44:51 --> Config Class Initialized
INFO - 2026-01-27 04:44:51 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:44:51 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:44:51 --> Utf8 Class Initialized
INFO - 2026-01-27 04:44:51 --> URI Class Initialized
INFO - 2026-01-27 04:44:51 --> Router Class Initialized
INFO - 2026-01-27 04:44:51 --> Output Class Initialized
INFO - 2026-01-27 04:44:51 --> Security Class Initialized
DEBUG - 2026-01-27 04:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:44:51 --> CSRF cookie sent
INFO - 2026-01-27 04:44:51 --> Input Class Initialized
INFO - 2026-01-27 04:44:51 --> Language Class Initialized
INFO - 2026-01-27 04:44:51 --> Loader Class Initialized
INFO - 2026-01-27 04:44:51 --> Helper loaded: url_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: text_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: string_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: form_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: download_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: security_helper
INFO - 2026-01-27 04:44:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:44:51 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:44:51 --> Form Validation Class Initialized
INFO - 2026-01-27 04:44:51 --> Model "User_model" initialized
INFO - 2026-01-27 10:44:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:44:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:44:51 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:44:51 --> Controller Class Initialized
INFO - 2026-01-27 10:44:51 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:44:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2026-01-27 10:44:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:44:51 --> Model "Log_model" initialized
INFO - 2026-01-27 10:44:51 --> Final output sent to browser
DEBUG - 2026-01-27 10:44:51 --> Total execution time: 0.0931
INFO - 2026-01-27 04:44:55 --> Config Class Initialized
INFO - 2026-01-27 04:44:55 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:44:55 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:44:55 --> Utf8 Class Initialized
INFO - 2026-01-27 04:44:55 --> URI Class Initialized
INFO - 2026-01-27 04:44:55 --> Router Class Initialized
INFO - 2026-01-27 04:44:55 --> Output Class Initialized
INFO - 2026-01-27 04:44:55 --> Security Class Initialized
DEBUG - 2026-01-27 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:44:55 --> CSRF cookie sent
INFO - 2026-01-27 04:44:55 --> Input Class Initialized
INFO - 2026-01-27 04:44:55 --> Language Class Initialized
INFO - 2026-01-27 04:44:55 --> Loader Class Initialized
INFO - 2026-01-27 04:44:55 --> Helper loaded: url_helper
INFO - 2026-01-27 04:44:55 --> Helper loaded: text_helper
INFO - 2026-01-27 04:44:55 --> Helper loaded: string_helper
INFO - 2026-01-27 04:44:55 --> Helper loaded: form_helper
INFO - 2026-01-27 04:44:55 --> Helper loaded: download_helper
INFO - 2026-01-27 04:44:55 --> Helper loaded: security_helper
INFO - 2026-01-27 04:44:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:44:55 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:44:55 --> Form Validation Class Initialized
INFO - 2026-01-27 04:44:55 --> Model "User_model" initialized
INFO - 2026-01-27 10:44:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:44:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:44:55 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:44:55 --> Controller Class Initialized
INFO - 2026-01-27 10:44:55 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:44:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/tambah.php
INFO - 2026-01-27 10:44:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:44:55 --> Model "Log_model" initialized
INFO - 2026-01-27 10:44:55 --> Final output sent to browser
DEBUG - 2026-01-27 10:44:55 --> Total execution time: 0.1714
INFO - 2026-01-27 04:45:40 --> Config Class Initialized
INFO - 2026-01-27 04:45:40 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:45:40 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:45:40 --> Utf8 Class Initialized
INFO - 2026-01-27 04:45:40 --> URI Class Initialized
INFO - 2026-01-27 04:45:40 --> Router Class Initialized
INFO - 2026-01-27 04:45:40 --> Output Class Initialized
INFO - 2026-01-27 04:45:40 --> Security Class Initialized
DEBUG - 2026-01-27 04:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:45:40 --> CSRF cookie sent
INFO - 2026-01-27 04:45:40 --> CSRF token verified
INFO - 2026-01-27 04:45:40 --> Input Class Initialized
INFO - 2026-01-27 04:45:40 --> Language Class Initialized
INFO - 2026-01-27 04:45:40 --> Loader Class Initialized
INFO - 2026-01-27 04:45:40 --> Helper loaded: url_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: text_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: string_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: form_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: download_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: security_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:45:40 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:45:40 --> Form Validation Class Initialized
INFO - 2026-01-27 04:45:40 --> Model "User_model" initialized
INFO - 2026-01-27 10:45:40 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:45:40 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:45:40 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:45:40 --> Controller Class Initialized
INFO - 2026-01-27 10:45:40 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:45:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 10:45:40 --> Upload Class Initialized
INFO - 2026-01-27 04:45:40 --> Config Class Initialized
INFO - 2026-01-27 04:45:40 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:45:40 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:45:40 --> Utf8 Class Initialized
INFO - 2026-01-27 04:45:40 --> URI Class Initialized
INFO - 2026-01-27 04:45:40 --> Router Class Initialized
INFO - 2026-01-27 04:45:40 --> Output Class Initialized
INFO - 2026-01-27 04:45:40 --> Security Class Initialized
DEBUG - 2026-01-27 04:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:45:40 --> CSRF cookie sent
INFO - 2026-01-27 04:45:40 --> Input Class Initialized
INFO - 2026-01-27 04:45:40 --> Language Class Initialized
INFO - 2026-01-27 04:45:40 --> Loader Class Initialized
INFO - 2026-01-27 04:45:40 --> Helper loaded: url_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: text_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: string_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: form_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: download_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: security_helper
INFO - 2026-01-27 04:45:40 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:45:40 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:45:40 --> Form Validation Class Initialized
INFO - 2026-01-27 04:45:40 --> Model "User_model" initialized
INFO - 2026-01-27 10:45:40 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:45:40 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:45:40 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:45:40 --> Controller Class Initialized
INFO - 2026-01-27 10:45:40 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:45:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2026-01-27 10:45:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:45:40 --> Model "Log_model" initialized
INFO - 2026-01-27 10:45:40 --> Final output sent to browser
DEBUG - 2026-01-27 10:45:40 --> Total execution time: 0.1076
INFO - 2026-01-27 04:45:43 --> Config Class Initialized
INFO - 2026-01-27 04:45:43 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:45:43 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:45:43 --> Utf8 Class Initialized
INFO - 2026-01-27 04:45:43 --> URI Class Initialized
INFO - 2026-01-27 04:45:43 --> Router Class Initialized
INFO - 2026-01-27 04:45:43 --> Output Class Initialized
INFO - 2026-01-27 04:45:43 --> Security Class Initialized
DEBUG - 2026-01-27 04:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:45:43 --> CSRF cookie sent
INFO - 2026-01-27 04:45:43 --> Input Class Initialized
INFO - 2026-01-27 04:45:43 --> Language Class Initialized
INFO - 2026-01-27 04:45:43 --> Loader Class Initialized
INFO - 2026-01-27 04:45:43 --> Helper loaded: url_helper
INFO - 2026-01-27 04:45:43 --> Helper loaded: text_helper
INFO - 2026-01-27 04:45:43 --> Helper loaded: string_helper
INFO - 2026-01-27 04:45:43 --> Helper loaded: form_helper
INFO - 2026-01-27 04:45:43 --> Helper loaded: download_helper
INFO - 2026-01-27 04:45:43 --> Helper loaded: security_helper
INFO - 2026-01-27 04:45:43 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:45:43 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:45:43 --> Form Validation Class Initialized
INFO - 2026-01-27 04:45:43 --> Model "User_model" initialized
INFO - 2026-01-27 10:45:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:45:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:45:43 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:45:43 --> Controller Class Initialized
INFO - 2026-01-27 10:45:43 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:45:43 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:45:43 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:45:43 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:45:43 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:45:43 --> Model "Pusat_model" initialized
INFO - 2026-01-27 10:45:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/list.php
INFO - 2026-01-27 10:45:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:45:43 --> Model "Log_model" initialized
INFO - 2026-01-27 10:45:43 --> Final output sent to browser
DEBUG - 2026-01-27 10:45:43 --> Total execution time: 0.1253
INFO - 2026-01-27 04:45:45 --> Config Class Initialized
INFO - 2026-01-27 04:45:45 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:45:45 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:45:45 --> Utf8 Class Initialized
INFO - 2026-01-27 04:45:45 --> URI Class Initialized
INFO - 2026-01-27 04:45:45 --> Router Class Initialized
INFO - 2026-01-27 04:45:45 --> Output Class Initialized
INFO - 2026-01-27 04:45:45 --> Security Class Initialized
DEBUG - 2026-01-27 04:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:45:45 --> CSRF cookie sent
INFO - 2026-01-27 04:45:45 --> Input Class Initialized
INFO - 2026-01-27 04:45:45 --> Language Class Initialized
INFO - 2026-01-27 04:45:45 --> Loader Class Initialized
INFO - 2026-01-27 04:45:45 --> Helper loaded: url_helper
INFO - 2026-01-27 04:45:45 --> Helper loaded: text_helper
INFO - 2026-01-27 04:45:45 --> Helper loaded: string_helper
INFO - 2026-01-27 04:45:45 --> Helper loaded: form_helper
INFO - 2026-01-27 04:45:45 --> Helper loaded: download_helper
INFO - 2026-01-27 04:45:45 --> Helper loaded: security_helper
INFO - 2026-01-27 04:45:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:45:45 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:45:45 --> Form Validation Class Initialized
INFO - 2026-01-27 04:45:45 --> Model "User_model" initialized
INFO - 2026-01-27 10:45:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:45:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:45:45 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:45:45 --> Controller Class Initialized
INFO - 2026-01-27 10:45:45 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:45:45 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:45:45 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:45:45 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:45:45 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:45:45 --> Model "Pusat_model" initialized
DEBUG - 2026-01-27 10:45:45 --> POST: []
INFO - 2026-01-27 10:45:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/tambah.php
INFO - 2026-01-27 10:45:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:45:45 --> Model "Log_model" initialized
INFO - 2026-01-27 10:45:45 --> Final output sent to browser
DEBUG - 2026-01-27 10:45:45 --> Total execution time: 0.1286
INFO - 2026-01-27 04:45:50 --> Config Class Initialized
INFO - 2026-01-27 04:45:50 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:45:50 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:45:50 --> Utf8 Class Initialized
INFO - 2026-01-27 04:45:50 --> URI Class Initialized
INFO - 2026-01-27 04:45:50 --> Router Class Initialized
INFO - 2026-01-27 04:45:50 --> Output Class Initialized
INFO - 2026-01-27 04:45:50 --> Security Class Initialized
DEBUG - 2026-01-27 04:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:45:50 --> CSRF cookie sent
INFO - 2026-01-27 04:45:50 --> Input Class Initialized
INFO - 2026-01-27 04:45:50 --> Language Class Initialized
INFO - 2026-01-27 04:45:50 --> Loader Class Initialized
INFO - 2026-01-27 04:45:50 --> Helper loaded: url_helper
INFO - 2026-01-27 04:45:50 --> Helper loaded: text_helper
INFO - 2026-01-27 04:45:50 --> Helper loaded: string_helper
INFO - 2026-01-27 04:45:50 --> Helper loaded: form_helper
INFO - 2026-01-27 04:45:50 --> Helper loaded: download_helper
INFO - 2026-01-27 04:45:50 --> Helper loaded: security_helper
INFO - 2026-01-27 04:45:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:45:50 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:45:50 --> Form Validation Class Initialized
INFO - 2026-01-27 04:45:50 --> Model "User_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:45:50 --> Controller Class Initialized
INFO - 2026-01-27 10:45:50 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Video_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:45:50 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:45:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-27 10:45:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:45:50 --> Model "Log_model" initialized
INFO - 2026-01-27 10:45:50 --> Final output sent to browser
DEBUG - 2026-01-27 10:45:50 --> Total execution time: 0.1271
INFO - 2026-01-27 04:46:12 --> Config Class Initialized
INFO - 2026-01-27 04:46:12 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:46:12 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:46:12 --> Utf8 Class Initialized
INFO - 2026-01-27 04:46:12 --> URI Class Initialized
INFO - 2026-01-27 04:46:12 --> Router Class Initialized
INFO - 2026-01-27 04:46:12 --> Output Class Initialized
INFO - 2026-01-27 04:46:12 --> Security Class Initialized
DEBUG - 2026-01-27 04:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:46:12 --> CSRF cookie sent
INFO - 2026-01-27 04:46:12 --> Input Class Initialized
INFO - 2026-01-27 04:46:12 --> Language Class Initialized
INFO - 2026-01-27 04:46:12 --> Loader Class Initialized
INFO - 2026-01-27 04:46:12 --> Helper loaded: url_helper
INFO - 2026-01-27 04:46:12 --> Helper loaded: text_helper
INFO - 2026-01-27 04:46:12 --> Helper loaded: string_helper
INFO - 2026-01-27 04:46:12 --> Helper loaded: form_helper
INFO - 2026-01-27 04:46:12 --> Helper loaded: download_helper
INFO - 2026-01-27 04:46:12 --> Helper loaded: security_helper
INFO - 2026-01-27 04:46:12 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:46:12 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:46:12 --> Form Validation Class Initialized
INFO - 2026-01-27 04:46:12 --> Model "User_model" initialized
INFO - 2026-01-27 10:46:12 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:46:12 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:46:12 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:46:12 --> Controller Class Initialized
INFO - 2026-01-27 10:46:12 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:46:12 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:46:12 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:46:12 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:46:12 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:46:12 --> Model "Pusat_model" initialized
INFO - 2026-01-27 10:46:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/list.php
INFO - 2026-01-27 10:46:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:46:12 --> Model "Log_model" initialized
INFO - 2026-01-27 10:46:12 --> Final output sent to browser
DEBUG - 2026-01-27 10:46:12 --> Total execution time: 0.1277
INFO - 2026-01-27 04:46:15 --> Config Class Initialized
INFO - 2026-01-27 04:46:15 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:46:15 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:46:15 --> Utf8 Class Initialized
INFO - 2026-01-27 04:46:15 --> URI Class Initialized
INFO - 2026-01-27 04:46:15 --> Router Class Initialized
INFO - 2026-01-27 04:46:15 --> Output Class Initialized
INFO - 2026-01-27 04:46:15 --> Security Class Initialized
DEBUG - 2026-01-27 04:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:46:15 --> CSRF cookie sent
INFO - 2026-01-27 04:46:15 --> Input Class Initialized
INFO - 2026-01-27 04:46:15 --> Language Class Initialized
INFO - 2026-01-27 04:46:15 --> Loader Class Initialized
INFO - 2026-01-27 04:46:15 --> Helper loaded: url_helper
INFO - 2026-01-27 04:46:15 --> Helper loaded: text_helper
INFO - 2026-01-27 04:46:15 --> Helper loaded: string_helper
INFO - 2026-01-27 04:46:15 --> Helper loaded: form_helper
INFO - 2026-01-27 04:46:15 --> Helper loaded: download_helper
INFO - 2026-01-27 04:46:15 --> Helper loaded: security_helper
INFO - 2026-01-27 04:46:15 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:46:15 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:46:16 --> Form Validation Class Initialized
INFO - 2026-01-27 04:46:16 --> Model "User_model" initialized
INFO - 2026-01-27 10:46:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:46:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:46:16 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:46:16 --> Controller Class Initialized
INFO - 2026-01-27 10:46:16 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:46:16 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:46:16 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:46:16 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:46:16 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:46:16 --> Model "Pusat_model" initialized
INFO - 2026-01-27 10:46:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/detail.php
INFO - 2026-01-27 10:46:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:46:16 --> Model "Log_model" initialized
INFO - 2026-01-27 10:46:16 --> Final output sent to browser
DEBUG - 2026-01-27 10:46:16 --> Total execution time: 0.1509
INFO - 2026-01-27 04:46:37 --> Config Class Initialized
INFO - 2026-01-27 04:46:37 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:46:37 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:46:37 --> Utf8 Class Initialized
INFO - 2026-01-27 04:46:37 --> URI Class Initialized
INFO - 2026-01-27 04:46:37 --> Router Class Initialized
INFO - 2026-01-27 04:46:37 --> Output Class Initialized
INFO - 2026-01-27 04:46:37 --> Security Class Initialized
DEBUG - 2026-01-27 04:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:46:37 --> CSRF cookie sent
INFO - 2026-01-27 04:46:37 --> Input Class Initialized
INFO - 2026-01-27 04:46:37 --> Language Class Initialized
INFO - 2026-01-27 04:46:37 --> Loader Class Initialized
INFO - 2026-01-27 04:46:37 --> Helper loaded: url_helper
INFO - 2026-01-27 04:46:37 --> Helper loaded: text_helper
INFO - 2026-01-27 04:46:37 --> Helper loaded: string_helper
INFO - 2026-01-27 04:46:37 --> Helper loaded: form_helper
INFO - 2026-01-27 04:46:37 --> Helper loaded: download_helper
INFO - 2026-01-27 04:46:37 --> Helper loaded: security_helper
INFO - 2026-01-27 04:46:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:46:37 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:46:37 --> Form Validation Class Initialized
INFO - 2026-01-27 04:46:37 --> Model "User_model" initialized
INFO - 2026-01-27 10:46:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:46:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:46:37 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:46:37 --> Controller Class Initialized
INFO - 2026-01-27 10:46:37 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:46:37 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:46:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:46:37 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:46:37 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:46:37 --> Model "Pusat_model" initialized
ERROR - 2026-01-27 10:46:37 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\dev_jkt3\application\views\admin\jabatan_sdm\edit.php 328
ERROR - 2026-01-27 10:46:37 --> Severity: Notice --> Undefined property: stdClass::$catatan D:\xampp\htdocs\dev_jkt3\application\views\admin\jabatan_sdm\edit.php 329
INFO - 2026-01-27 10:46:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/edit.php
INFO - 2026-01-27 10:46:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:46:37 --> Model "Log_model" initialized
INFO - 2026-01-27 10:46:37 --> Final output sent to browser
DEBUG - 2026-01-27 10:46:37 --> Total execution time: 0.2270
INFO - 2026-01-27 04:47:38 --> Config Class Initialized
INFO - 2026-01-27 04:47:38 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:47:38 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:47:38 --> Utf8 Class Initialized
INFO - 2026-01-27 04:47:38 --> URI Class Initialized
INFO - 2026-01-27 04:47:38 --> Router Class Initialized
INFO - 2026-01-27 04:47:38 --> Output Class Initialized
INFO - 2026-01-27 04:47:38 --> Security Class Initialized
DEBUG - 2026-01-27 04:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:47:38 --> CSRF cookie sent
INFO - 2026-01-27 04:47:38 --> CSRF token verified
INFO - 2026-01-27 04:47:38 --> Input Class Initialized
INFO - 2026-01-27 04:47:38 --> Language Class Initialized
INFO - 2026-01-27 04:47:38 --> Loader Class Initialized
INFO - 2026-01-27 04:47:38 --> Helper loaded: url_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: text_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: string_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: form_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: download_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: security_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:47:38 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:47:38 --> Form Validation Class Initialized
INFO - 2026-01-27 04:47:38 --> Model "User_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:47:38 --> Controller Class Initialized
INFO - 2026-01-27 10:47:38 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Pusat_model" initialized
DEBUG - 2026-01-27 10:47:38 --> POST: {"sdm_id":"31","level":"jurusan","jurusan_id":"4","prodi_id":"11","unit_id":"","pusat_id":"","jabatan":"Ketua Prodi Sarjana Terapan Teknologi Laboratorium Medis","periode_mulai":"2025","periode_akhir":"2029"}
INFO - 2026-01-27 10:47:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 04:47:38 --> Config Class Initialized
INFO - 2026-01-27 04:47:38 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:47:38 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:47:38 --> Utf8 Class Initialized
INFO - 2026-01-27 04:47:38 --> URI Class Initialized
INFO - 2026-01-27 04:47:38 --> Router Class Initialized
INFO - 2026-01-27 04:47:38 --> Output Class Initialized
INFO - 2026-01-27 04:47:38 --> Security Class Initialized
DEBUG - 2026-01-27 04:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:47:38 --> CSRF cookie sent
INFO - 2026-01-27 04:47:38 --> Input Class Initialized
INFO - 2026-01-27 04:47:38 --> Language Class Initialized
INFO - 2026-01-27 04:47:38 --> Loader Class Initialized
INFO - 2026-01-27 04:47:38 --> Helper loaded: url_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: text_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: string_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: form_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: download_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: security_helper
INFO - 2026-01-27 04:47:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:47:38 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:47:38 --> Form Validation Class Initialized
INFO - 2026-01-27 04:47:38 --> Model "User_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:47:38 --> Controller Class Initialized
INFO - 2026-01-27 10:47:38 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:47:38 --> Model "Pusat_model" initialized
INFO - 2026-01-27 10:47:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/list.php
INFO - 2026-01-27 10:47:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:47:38 --> Model "Log_model" initialized
INFO - 2026-01-27 10:47:38 --> Final output sent to browser
DEBUG - 2026-01-27 10:47:38 --> Total execution time: 0.1289
INFO - 2026-01-27 04:47:41 --> Config Class Initialized
INFO - 2026-01-27 04:47:41 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:47:41 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:47:41 --> Utf8 Class Initialized
INFO - 2026-01-27 04:47:41 --> URI Class Initialized
INFO - 2026-01-27 04:47:41 --> Router Class Initialized
INFO - 2026-01-27 04:47:41 --> Output Class Initialized
INFO - 2026-01-27 04:47:41 --> Security Class Initialized
DEBUG - 2026-01-27 04:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:47:41 --> CSRF cookie sent
INFO - 2026-01-27 04:47:41 --> Input Class Initialized
INFO - 2026-01-27 04:47:41 --> Language Class Initialized
INFO - 2026-01-27 04:47:41 --> Loader Class Initialized
INFO - 2026-01-27 04:47:41 --> Helper loaded: url_helper
INFO - 2026-01-27 04:47:41 --> Helper loaded: text_helper
INFO - 2026-01-27 04:47:41 --> Helper loaded: string_helper
INFO - 2026-01-27 04:47:41 --> Helper loaded: form_helper
INFO - 2026-01-27 04:47:41 --> Helper loaded: download_helper
INFO - 2026-01-27 04:47:41 --> Helper loaded: security_helper
INFO - 2026-01-27 04:47:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:47:41 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:47:41 --> Form Validation Class Initialized
INFO - 2026-01-27 04:47:41 --> Model "User_model" initialized
INFO - 2026-01-27 10:47:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:47:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:47:41 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:47:41 --> Controller Class Initialized
INFO - 2026-01-27 10:47:41 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:47:41 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:47:41 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:47:41 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 10:47:41 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2026-01-27 10:47:41 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:47:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:47:41 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 10:47:41 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 10:47:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 10:47:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:47:41 --> Model "Log_model" initialized
INFO - 2026-01-27 10:47:42 --> Final output sent to browser
DEBUG - 2026-01-27 10:47:42 --> Total execution time: 0.1324
INFO - 2026-01-27 04:47:43 --> Config Class Initialized
INFO - 2026-01-27 04:47:43 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:47:43 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:47:43 --> Utf8 Class Initialized
INFO - 2026-01-27 04:47:43 --> URI Class Initialized
INFO - 2026-01-27 04:47:43 --> Router Class Initialized
INFO - 2026-01-27 04:47:43 --> Output Class Initialized
INFO - 2026-01-27 04:47:43 --> Security Class Initialized
DEBUG - 2026-01-27 04:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:47:43 --> CSRF cookie sent
INFO - 2026-01-27 04:47:43 --> Input Class Initialized
INFO - 2026-01-27 04:47:43 --> Language Class Initialized
INFO - 2026-01-27 04:47:43 --> Loader Class Initialized
INFO - 2026-01-27 04:47:43 --> Helper loaded: url_helper
INFO - 2026-01-27 04:47:43 --> Helper loaded: text_helper
INFO - 2026-01-27 04:47:43 --> Helper loaded: string_helper
INFO - 2026-01-27 04:47:43 --> Helper loaded: form_helper
INFO - 2026-01-27 04:47:43 --> Helper loaded: download_helper
INFO - 2026-01-27 04:47:43 --> Helper loaded: security_helper
INFO - 2026-01-27 04:47:43 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:47:43 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:47:43 --> Form Validation Class Initialized
INFO - 2026-01-27 04:47:43 --> Model "User_model" initialized
INFO - 2026-01-27 10:47:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:47:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:47:43 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:47:43 --> Controller Class Initialized
INFO - 2026-01-27 10:47:43 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:47:43 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:47:43 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:47:43 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 10:47:44 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 2
ERROR - 2026-01-27 10:47:44 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:47:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:47:44 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 10:47:44 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 10:47:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 10:47:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:47:44 --> Model "Log_model" initialized
INFO - 2026-01-27 10:47:44 --> Final output sent to browser
DEBUG - 2026-01-27 10:47:44 --> Total execution time: 0.1847
INFO - 2026-01-27 04:47:52 --> Config Class Initialized
INFO - 2026-01-27 04:47:52 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:47:52 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:47:52 --> Utf8 Class Initialized
INFO - 2026-01-27 04:47:52 --> URI Class Initialized
INFO - 2026-01-27 04:47:52 --> Router Class Initialized
INFO - 2026-01-27 04:47:52 --> Output Class Initialized
INFO - 2026-01-27 04:47:52 --> Security Class Initialized
DEBUG - 2026-01-27 04:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:47:52 --> CSRF cookie sent
INFO - 2026-01-27 04:47:52 --> Input Class Initialized
INFO - 2026-01-27 04:47:52 --> Language Class Initialized
INFO - 2026-01-27 04:47:52 --> Loader Class Initialized
INFO - 2026-01-27 04:47:52 --> Helper loaded: url_helper
INFO - 2026-01-27 04:47:52 --> Helper loaded: text_helper
INFO - 2026-01-27 04:47:52 --> Helper loaded: string_helper
INFO - 2026-01-27 04:47:52 --> Helper loaded: form_helper
INFO - 2026-01-27 04:47:52 --> Helper loaded: download_helper
INFO - 2026-01-27 04:47:52 --> Helper loaded: security_helper
INFO - 2026-01-27 04:47:52 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:47:52 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:47:52 --> Form Validation Class Initialized
INFO - 2026-01-27 04:47:52 --> Model "User_model" initialized
INFO - 2026-01-27 10:47:52 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:47:52 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:47:52 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:47:52 --> Controller Class Initialized
INFO - 2026-01-27 10:47:52 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:47:52 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:47:52 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:47:52 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:47:52 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:47:52 --> Model "Pusat_model" initialized
DEBUG - 2026-01-27 10:47:52 --> POST: []
INFO - 2026-01-27 10:47:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/tambah.php
INFO - 2026-01-27 10:47:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:47:52 --> Model "Log_model" initialized
INFO - 2026-01-27 10:47:52 --> Final output sent to browser
DEBUG - 2026-01-27 10:47:52 --> Total execution time: 0.1622
INFO - 2026-01-27 04:47:56 --> Config Class Initialized
INFO - 2026-01-27 04:47:56 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:47:56 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:47:56 --> Utf8 Class Initialized
INFO - 2026-01-27 04:47:56 --> URI Class Initialized
INFO - 2026-01-27 04:47:56 --> Router Class Initialized
INFO - 2026-01-27 04:47:56 --> Output Class Initialized
INFO - 2026-01-27 04:47:56 --> Security Class Initialized
DEBUG - 2026-01-27 04:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:47:56 --> CSRF cookie sent
INFO - 2026-01-27 04:47:56 --> Input Class Initialized
INFO - 2026-01-27 04:47:56 --> Language Class Initialized
INFO - 2026-01-27 04:47:56 --> Loader Class Initialized
INFO - 2026-01-27 04:47:56 --> Helper loaded: url_helper
INFO - 2026-01-27 04:47:56 --> Helper loaded: text_helper
INFO - 2026-01-27 04:47:56 --> Helper loaded: string_helper
INFO - 2026-01-27 04:47:56 --> Helper loaded: form_helper
INFO - 2026-01-27 04:47:56 --> Helper loaded: download_helper
INFO - 2026-01-27 04:47:56 --> Helper loaded: security_helper
INFO - 2026-01-27 04:47:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:47:56 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:47:56 --> Form Validation Class Initialized
INFO - 2026-01-27 04:47:56 --> Model "User_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:47:56 --> Controller Class Initialized
INFO - 2026-01-27 10:47:56 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Video_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:47:56 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:47:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-27 10:47:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:47:56 --> Model "Log_model" initialized
INFO - 2026-01-27 10:47:56 --> Final output sent to browser
DEBUG - 2026-01-27 10:47:56 --> Total execution time: 0.1030
INFO - 2026-01-27 04:48:26 --> Config Class Initialized
INFO - 2026-01-27 04:48:26 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:48:26 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:48:26 --> Utf8 Class Initialized
INFO - 2026-01-27 04:48:26 --> URI Class Initialized
INFO - 2026-01-27 04:48:26 --> Router Class Initialized
INFO - 2026-01-27 04:48:26 --> Output Class Initialized
INFO - 2026-01-27 04:48:26 --> Security Class Initialized
DEBUG - 2026-01-27 04:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:48:26 --> CSRF cookie sent
INFO - 2026-01-27 04:48:26 --> CSRF token verified
INFO - 2026-01-27 04:48:26 --> Input Class Initialized
INFO - 2026-01-27 04:48:26 --> Language Class Initialized
INFO - 2026-01-27 04:48:26 --> Loader Class Initialized
INFO - 2026-01-27 04:48:26 --> Helper loaded: url_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: text_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: string_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: form_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: download_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: security_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:48:26 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:48:26 --> Form Validation Class Initialized
INFO - 2026-01-27 04:48:26 --> Model "User_model" initialized
INFO - 2026-01-27 10:48:26 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:48:26 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:48:26 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:48:26 --> Controller Class Initialized
INFO - 2026-01-27 10:48:26 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:48:26 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:48:26 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:48:26 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:48:26 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:48:26 --> Model "Pusat_model" initialized
DEBUG - 2026-01-27 10:48:26 --> POST: {"sdm_id":"32","level":"jurusan","jurusan_id":"4","prodi_id":"10","unit_id":"","pusat_id":"","jabatan":"Ketua Program Studi DIII Teknologi Laboratorium Medis","periode_mulai":"2025","periode_akhir":"2029"}
INFO - 2026-01-27 10:48:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 04:48:26 --> Config Class Initialized
INFO - 2026-01-27 04:48:26 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:48:26 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:48:26 --> Utf8 Class Initialized
INFO - 2026-01-27 04:48:26 --> URI Class Initialized
INFO - 2026-01-27 04:48:26 --> Router Class Initialized
INFO - 2026-01-27 04:48:26 --> Output Class Initialized
INFO - 2026-01-27 04:48:26 --> Security Class Initialized
DEBUG - 2026-01-27 04:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:48:26 --> CSRF cookie sent
INFO - 2026-01-27 04:48:26 --> Input Class Initialized
INFO - 2026-01-27 04:48:26 --> Language Class Initialized
INFO - 2026-01-27 04:48:26 --> Loader Class Initialized
INFO - 2026-01-27 04:48:26 --> Helper loaded: url_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: text_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: string_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: form_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: download_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: security_helper
INFO - 2026-01-27 04:48:26 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:48:27 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:48:27 --> Form Validation Class Initialized
INFO - 2026-01-27 04:48:27 --> Model "User_model" initialized
INFO - 2026-01-27 10:48:27 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:48:27 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:48:27 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:48:27 --> Controller Class Initialized
INFO - 2026-01-27 10:48:27 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:48:27 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:48:27 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:48:27 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:48:27 --> Model "Unit_model" initialized
INFO - 2026-01-27 10:48:27 --> Model "Pusat_model" initialized
INFO - 2026-01-27 10:48:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jabatan_sdm/list.php
INFO - 2026-01-27 10:48:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:48:27 --> Model "Log_model" initialized
INFO - 2026-01-27 10:48:27 --> Final output sent to browser
DEBUG - 2026-01-27 10:48:27 --> Total execution time: 0.0860
INFO - 2026-01-27 04:48:30 --> Config Class Initialized
INFO - 2026-01-27 04:48:30 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:48:30 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:48:30 --> Utf8 Class Initialized
INFO - 2026-01-27 04:48:30 --> URI Class Initialized
DEBUG - 2026-01-27 04:48:30 --> No URI present. Default controller set.
INFO - 2026-01-27 04:48:30 --> Router Class Initialized
INFO - 2026-01-27 04:48:31 --> Output Class Initialized
INFO - 2026-01-27 04:48:31 --> Security Class Initialized
DEBUG - 2026-01-27 04:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:48:31 --> CSRF cookie sent
INFO - 2026-01-27 04:48:31 --> Input Class Initialized
INFO - 2026-01-27 04:48:31 --> Language Class Initialized
INFO - 2026-01-27 04:48:31 --> Loader Class Initialized
INFO - 2026-01-27 04:48:31 --> Helper loaded: url_helper
INFO - 2026-01-27 04:48:31 --> Helper loaded: text_helper
INFO - 2026-01-27 04:48:31 --> Helper loaded: string_helper
INFO - 2026-01-27 04:48:31 --> Helper loaded: form_helper
INFO - 2026-01-27 04:48:31 --> Helper loaded: download_helper
INFO - 2026-01-27 04:48:31 --> Helper loaded: security_helper
INFO - 2026-01-27 04:48:31 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:48:31 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:48:31 --> Form Validation Class Initialized
INFO - 2026-01-27 04:48:31 --> Model "User_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:48:31 --> Controller Class Initialized
INFO - 2026-01-27 10:48:31 --> Model "Berita_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Galeri_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Video_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Agenda_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Tautan_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Mitra_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:48:31 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 10:48:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 10:48:31 --> Pagination Class Initialized
INFO - 2026-01-27 10:48:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 10:48:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:48:31 --> Model "Log_model" initialized
INFO - 2026-01-27 10:48:31 --> Final output sent to browser
DEBUG - 2026-01-27 10:48:31 --> Total execution time: 0.3364
INFO - 2026-01-27 04:48:35 --> Config Class Initialized
INFO - 2026-01-27 04:48:35 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:48:35 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:48:35 --> Utf8 Class Initialized
INFO - 2026-01-27 04:48:35 --> URI Class Initialized
INFO - 2026-01-27 04:48:35 --> Router Class Initialized
INFO - 2026-01-27 04:48:35 --> Output Class Initialized
INFO - 2026-01-27 04:48:35 --> Security Class Initialized
DEBUG - 2026-01-27 04:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:48:35 --> CSRF cookie sent
INFO - 2026-01-27 04:48:35 --> Input Class Initialized
INFO - 2026-01-27 04:48:35 --> Language Class Initialized
INFO - 2026-01-27 04:48:35 --> Loader Class Initialized
INFO - 2026-01-27 04:48:35 --> Helper loaded: url_helper
INFO - 2026-01-27 04:48:35 --> Helper loaded: text_helper
INFO - 2026-01-27 04:48:35 --> Helper loaded: string_helper
INFO - 2026-01-27 04:48:35 --> Helper loaded: form_helper
INFO - 2026-01-27 04:48:35 --> Helper loaded: download_helper
INFO - 2026-01-27 04:48:35 --> Helper loaded: security_helper
INFO - 2026-01-27 04:48:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:48:35 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:48:35 --> Form Validation Class Initialized
INFO - 2026-01-27 04:48:35 --> Model "User_model" initialized
INFO - 2026-01-27 10:48:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:48:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:48:35 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:48:35 --> Controller Class Initialized
INFO - 2026-01-27 10:48:35 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:48:35 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 10:48:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-27 10:48:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:48:35 --> Model "Log_model" initialized
INFO - 2026-01-27 10:48:35 --> Final output sent to browser
DEBUG - 2026-01-27 10:48:35 --> Total execution time: 0.1551
INFO - 2026-01-27 04:48:59 --> Config Class Initialized
INFO - 2026-01-27 04:48:59 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:48:59 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:48:59 --> Utf8 Class Initialized
INFO - 2026-01-27 04:48:59 --> URI Class Initialized
INFO - 2026-01-27 04:48:59 --> Router Class Initialized
INFO - 2026-01-27 04:48:59 --> Output Class Initialized
INFO - 2026-01-27 04:48:59 --> Security Class Initialized
DEBUG - 2026-01-27 04:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:48:59 --> CSRF cookie sent
INFO - 2026-01-27 04:48:59 --> Input Class Initialized
INFO - 2026-01-27 04:48:59 --> Language Class Initialized
INFO - 2026-01-27 04:48:59 --> Loader Class Initialized
INFO - 2026-01-27 04:48:59 --> Helper loaded: url_helper
INFO - 2026-01-27 04:48:59 --> Helper loaded: text_helper
INFO - 2026-01-27 04:48:59 --> Helper loaded: string_helper
INFO - 2026-01-27 04:48:59 --> Helper loaded: form_helper
INFO - 2026-01-27 04:48:59 --> Helper loaded: download_helper
INFO - 2026-01-27 04:49:00 --> Helper loaded: security_helper
INFO - 2026-01-27 04:49:00 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:49:00 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:49:00 --> Form Validation Class Initialized
INFO - 2026-01-27 04:49:00 --> Model "User_model" initialized
INFO - 2026-01-27 10:49:00 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:49:00 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:49:00 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:49:00 --> Controller Class Initialized
INFO - 2026-01-27 10:49:00 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:49:00 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:49:00 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:49:00 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 10:49:00 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 3
ERROR - 2026-01-27 10:49:00 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:49:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:49:00 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 10:49:00 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 10:49:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 10:49:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:49:00 --> Model "Log_model" initialized
INFO - 2026-01-27 10:49:00 --> Final output sent to browser
DEBUG - 2026-01-27 10:49:00 --> Total execution time: 0.1588
INFO - 2026-01-27 04:49:14 --> Config Class Initialized
INFO - 2026-01-27 04:49:14 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:49:14 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:49:14 --> Utf8 Class Initialized
INFO - 2026-01-27 04:49:14 --> URI Class Initialized
INFO - 2026-01-27 04:49:14 --> Router Class Initialized
INFO - 2026-01-27 04:49:14 --> Output Class Initialized
INFO - 2026-01-27 04:49:14 --> Security Class Initialized
DEBUG - 2026-01-27 04:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:49:14 --> CSRF cookie sent
INFO - 2026-01-27 04:49:14 --> Input Class Initialized
INFO - 2026-01-27 04:49:14 --> Language Class Initialized
INFO - 2026-01-27 04:49:14 --> Loader Class Initialized
INFO - 2026-01-27 04:49:14 --> Helper loaded: url_helper
INFO - 2026-01-27 04:49:14 --> Helper loaded: text_helper
INFO - 2026-01-27 04:49:14 --> Helper loaded: string_helper
INFO - 2026-01-27 04:49:14 --> Helper loaded: form_helper
INFO - 2026-01-27 04:49:14 --> Helper loaded: download_helper
INFO - 2026-01-27 04:49:14 --> Helper loaded: security_helper
INFO - 2026-01-27 04:49:14 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:49:14 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:49:14 --> Form Validation Class Initialized
INFO - 2026-01-27 04:49:14 --> Model "User_model" initialized
INFO - 2026-01-27 10:49:14 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:49:14 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:49:14 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:49:14 --> Controller Class Initialized
INFO - 2026-01-27 10:49:14 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 10:49:14 --> Model "Prodi_model" initialized
INFO - 2026-01-27 10:49:14 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:49:14 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 10:49:14 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2026-01-27 10:49:14 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:49:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 10:49:14 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 10:49:14 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 10:49:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 10:49:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 10:49:14 --> Model "Log_model" initialized
INFO - 2026-01-27 10:49:14 --> Final output sent to browser
DEBUG - 2026-01-27 10:49:14 --> Total execution time: 0.1797
INFO - 2026-01-27 04:49:25 --> Config Class Initialized
INFO - 2026-01-27 04:49:25 --> Hooks Class Initialized
DEBUG - 2026-01-27 04:49:25 --> UTF-8 Support Enabled
INFO - 2026-01-27 04:49:25 --> Utf8 Class Initialized
INFO - 2026-01-27 04:49:25 --> URI Class Initialized
INFO - 2026-01-27 04:49:25 --> Router Class Initialized
INFO - 2026-01-27 04:49:25 --> Output Class Initialized
INFO - 2026-01-27 04:49:25 --> Security Class Initialized
DEBUG - 2026-01-27 04:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 04:49:25 --> CSRF cookie sent
INFO - 2026-01-27 04:49:25 --> Input Class Initialized
INFO - 2026-01-27 04:49:25 --> Language Class Initialized
INFO - 2026-01-27 04:49:25 --> Loader Class Initialized
INFO - 2026-01-27 04:49:25 --> Helper loaded: url_helper
INFO - 2026-01-27 04:49:25 --> Helper loaded: text_helper
INFO - 2026-01-27 04:49:25 --> Helper loaded: string_helper
INFO - 2026-01-27 04:49:25 --> Helper loaded: form_helper
INFO - 2026-01-27 04:49:25 --> Helper loaded: download_helper
INFO - 2026-01-27 04:49:25 --> Helper loaded: security_helper
INFO - 2026-01-27 04:49:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 04:49:25 --> Database Driver Class Initialized
DEBUG - 2026-01-27 04:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 04:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 04:49:25 --> Form Validation Class Initialized
INFO - 2026-01-27 04:49:25 --> Model "User_model" initialized
INFO - 2026-01-27 10:49:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 10:49:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 10:49:25 --> Model "Nav_model" initialized
INFO - 2026-01-27 10:49:25 --> Controller Class Initialized
INFO - 2026-01-27 10:49:25 --> Model "Sdm_model" initialized
INFO - 2026-01-27 10:49:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2026-01-27 10:49:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 10:49:25 --> Model "Log_model" initialized
INFO - 2026-01-27 10:49:25 --> Final output sent to browser
DEBUG - 2026-01-27 10:49:25 --> Total execution time: 0.1325
INFO - 2026-01-27 05:06:36 --> Config Class Initialized
INFO - 2026-01-27 05:06:36 --> Hooks Class Initialized
DEBUG - 2026-01-27 05:06:36 --> UTF-8 Support Enabled
INFO - 2026-01-27 05:06:36 --> Utf8 Class Initialized
INFO - 2026-01-27 05:06:36 --> URI Class Initialized
INFO - 2026-01-27 05:06:37 --> Router Class Initialized
INFO - 2026-01-27 05:06:37 --> Output Class Initialized
INFO - 2026-01-27 05:06:37 --> Security Class Initialized
DEBUG - 2026-01-27 05:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 05:06:37 --> CSRF cookie sent
INFO - 2026-01-27 05:06:37 --> Input Class Initialized
INFO - 2026-01-27 05:06:37 --> Language Class Initialized
INFO - 2026-01-27 05:06:37 --> Loader Class Initialized
INFO - 2026-01-27 05:06:37 --> Helper loaded: url_helper
INFO - 2026-01-27 05:06:37 --> Helper loaded: text_helper
INFO - 2026-01-27 05:06:38 --> Helper loaded: string_helper
INFO - 2026-01-27 05:06:38 --> Helper loaded: form_helper
INFO - 2026-01-27 05:06:38 --> Helper loaded: download_helper
INFO - 2026-01-27 05:06:38 --> Helper loaded: security_helper
INFO - 2026-01-27 05:06:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 05:06:38 --> Database Driver Class Initialized
DEBUG - 2026-01-27 05:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 05:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 05:06:38 --> Form Validation Class Initialized
INFO - 2026-01-27 05:06:38 --> Model "User_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Nav_model" initialized
INFO - 2026-01-27 11:06:39 --> Controller Class Initialized
INFO - 2026-01-27 11:06:39 --> Model "Berita_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Galeri_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Video_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Agenda_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Tautan_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Mitra_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Prodi_model" initialized
INFO - 2026-01-27 11:06:39 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 11:06:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-27 11:06:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 11:06:40 --> Model "Log_model" initialized
INFO - 2026-01-27 11:06:40 --> Final output sent to browser
DEBUG - 2026-01-27 11:06:40 --> Total execution time: 3.7881
INFO - 2026-01-27 05:06:41 --> Config Class Initialized
INFO - 2026-01-27 05:06:41 --> Hooks Class Initialized
DEBUG - 2026-01-27 05:06:41 --> UTF-8 Support Enabled
INFO - 2026-01-27 05:06:41 --> Utf8 Class Initialized
INFO - 2026-01-27 05:06:41 --> URI Class Initialized
INFO - 2026-01-27 05:06:41 --> Router Class Initialized
INFO - 2026-01-27 05:06:41 --> Output Class Initialized
INFO - 2026-01-27 05:06:41 --> Security Class Initialized
DEBUG - 2026-01-27 05:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 05:06:41 --> CSRF cookie sent
INFO - 2026-01-27 05:06:41 --> Input Class Initialized
INFO - 2026-01-27 05:06:41 --> Language Class Initialized
INFO - 2026-01-27 05:06:41 --> Loader Class Initialized
INFO - 2026-01-27 05:06:41 --> Helper loaded: url_helper
INFO - 2026-01-27 05:06:41 --> Helper loaded: text_helper
INFO - 2026-01-27 05:06:41 --> Helper loaded: string_helper
INFO - 2026-01-27 05:06:41 --> Helper loaded: form_helper
INFO - 2026-01-27 05:06:41 --> Helper loaded: download_helper
INFO - 2026-01-27 05:06:41 --> Helper loaded: security_helper
INFO - 2026-01-27 05:06:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 05:06:41 --> Database Driver Class Initialized
DEBUG - 2026-01-27 05:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 05:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 05:06:41 --> Form Validation Class Initialized
INFO - 2026-01-27 05:06:41 --> Model "User_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Nav_model" initialized
INFO - 2026-01-27 11:06:41 --> Controller Class Initialized
INFO - 2026-01-27 11:06:41 --> Model "Berita_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Galeri_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Video_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Agenda_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Tautan_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Mitra_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Prodi_model" initialized
INFO - 2026-01-27 11:06:41 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 11:06:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-27 11:06:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 11:06:41 --> Model "Log_model" initialized
INFO - 2026-01-27 11:06:41 --> Final output sent to browser
DEBUG - 2026-01-27 11:06:41 --> Total execution time: 0.1034
INFO - 2026-01-27 05:17:03 --> Config Class Initialized
INFO - 2026-01-27 05:17:03 --> Hooks Class Initialized
DEBUG - 2026-01-27 05:17:03 --> UTF-8 Support Enabled
INFO - 2026-01-27 05:17:03 --> Utf8 Class Initialized
INFO - 2026-01-27 05:17:03 --> URI Class Initialized
DEBUG - 2026-01-27 05:17:03 --> No URI present. Default controller set.
INFO - 2026-01-27 05:17:03 --> Router Class Initialized
INFO - 2026-01-27 05:17:03 --> Output Class Initialized
INFO - 2026-01-27 05:17:03 --> Security Class Initialized
DEBUG - 2026-01-27 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 05:17:03 --> CSRF cookie sent
INFO - 2026-01-27 05:17:03 --> Input Class Initialized
INFO - 2026-01-27 05:17:03 --> Language Class Initialized
INFO - 2026-01-27 05:17:03 --> Loader Class Initialized
INFO - 2026-01-27 05:17:03 --> Helper loaded: url_helper
INFO - 2026-01-27 05:17:03 --> Helper loaded: text_helper
INFO - 2026-01-27 05:17:03 --> Helper loaded: string_helper
INFO - 2026-01-27 05:17:03 --> Helper loaded: form_helper
INFO - 2026-01-27 05:17:03 --> Helper loaded: download_helper
INFO - 2026-01-27 05:17:03 --> Helper loaded: security_helper
INFO - 2026-01-27 05:17:03 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 05:17:03 --> Database Driver Class Initialized
DEBUG - 2026-01-27 05:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 05:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 05:17:03 --> Form Validation Class Initialized
INFO - 2026-01-27 05:17:03 --> Model "User_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Nav_model" initialized
INFO - 2026-01-27 11:17:03 --> Controller Class Initialized
INFO - 2026-01-27 11:17:03 --> Model "Berita_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Galeri_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Video_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Agenda_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Tautan_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Mitra_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Prodi_model" initialized
INFO - 2026-01-27 11:17:03 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 11:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 11:17:03 --> Pagination Class Initialized
INFO - 2026-01-27 11:17:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 11:17:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 11:17:03 --> Model "Log_model" initialized
INFO - 2026-01-27 11:17:03 --> Final output sent to browser
DEBUG - 2026-01-27 11:17:03 --> Total execution time: 0.2864
INFO - 2026-01-27 05:18:26 --> Config Class Initialized
INFO - 2026-01-27 05:18:26 --> Hooks Class Initialized
DEBUG - 2026-01-27 05:18:26 --> UTF-8 Support Enabled
INFO - 2026-01-27 05:18:26 --> Utf8 Class Initialized
INFO - 2026-01-27 05:18:26 --> URI Class Initialized
INFO - 2026-01-27 05:18:26 --> Router Class Initialized
INFO - 2026-01-27 05:18:26 --> Output Class Initialized
INFO - 2026-01-27 05:18:26 --> Security Class Initialized
DEBUG - 2026-01-27 05:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 05:18:26 --> CSRF cookie sent
INFO - 2026-01-27 05:18:26 --> Input Class Initialized
INFO - 2026-01-27 05:18:26 --> Language Class Initialized
INFO - 2026-01-27 05:18:26 --> Loader Class Initialized
INFO - 2026-01-27 05:18:26 --> Helper loaded: url_helper
INFO - 2026-01-27 05:18:26 --> Helper loaded: text_helper
INFO - 2026-01-27 05:18:26 --> Helper loaded: string_helper
INFO - 2026-01-27 05:18:26 --> Helper loaded: form_helper
INFO - 2026-01-27 05:18:26 --> Helper loaded: download_helper
INFO - 2026-01-27 05:18:26 --> Helper loaded: security_helper
INFO - 2026-01-27 05:18:26 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 05:18:26 --> Database Driver Class Initialized
DEBUG - 2026-01-27 05:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 05:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 05:18:26 --> Form Validation Class Initialized
INFO - 2026-01-27 05:18:26 --> Model "User_model" initialized
INFO - 2026-01-27 11:18:26 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 11:18:26 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 11:18:26 --> Model "Nav_model" initialized
INFO - 2026-01-27 11:18:26 --> Controller Class Initialized
INFO - 2026-01-27 11:18:26 --> Model "Sitemap_model" initialized
INFO - 2026-01-27 11:18:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_index.php
INFO - 2026-01-27 11:18:26 --> Model "Log_model" initialized
INFO - 2026-01-27 11:18:26 --> Final output sent to browser
DEBUG - 2026-01-27 11:18:26 --> Total execution time: 0.2186
INFO - 2026-01-27 05:18:33 --> Config Class Initialized
INFO - 2026-01-27 05:18:33 --> Hooks Class Initialized
DEBUG - 2026-01-27 05:18:33 --> UTF-8 Support Enabled
INFO - 2026-01-27 05:18:33 --> Utf8 Class Initialized
INFO - 2026-01-27 05:18:33 --> URI Class Initialized
INFO - 2026-01-27 05:18:33 --> Router Class Initialized
INFO - 2026-01-27 05:18:33 --> Output Class Initialized
INFO - 2026-01-27 05:18:33 --> Security Class Initialized
DEBUG - 2026-01-27 05:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 05:18:33 --> CSRF cookie sent
INFO - 2026-01-27 05:18:33 --> Input Class Initialized
INFO - 2026-01-27 05:18:33 --> Language Class Initialized
INFO - 2026-01-27 05:18:33 --> Loader Class Initialized
INFO - 2026-01-27 05:18:33 --> Helper loaded: url_helper
INFO - 2026-01-27 05:18:33 --> Helper loaded: text_helper
INFO - 2026-01-27 05:18:33 --> Helper loaded: string_helper
INFO - 2026-01-27 05:18:33 --> Helper loaded: form_helper
INFO - 2026-01-27 05:18:33 --> Helper loaded: download_helper
INFO - 2026-01-27 05:18:33 --> Helper loaded: security_helper
INFO - 2026-01-27 05:18:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 05:18:33 --> Database Driver Class Initialized
DEBUG - 2026-01-27 05:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 05:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 05:18:33 --> Form Validation Class Initialized
INFO - 2026-01-27 05:18:34 --> Model "User_model" initialized
INFO - 2026-01-27 11:18:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 11:18:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 11:18:34 --> Model "Nav_model" initialized
INFO - 2026-01-27 11:18:34 --> Controller Class Initialized
INFO - 2026-01-27 11:18:34 --> Model "Sitemap_model" initialized
INFO - 2026-01-27 11:18:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_alumni.php
INFO - 2026-01-27 11:18:34 --> Model "Log_model" initialized
INFO - 2026-01-27 11:18:34 --> Final output sent to browser
DEBUG - 2026-01-27 11:18:34 --> Total execution time: 0.1605
INFO - 2026-01-27 05:19:19 --> Config Class Initialized
INFO - 2026-01-27 05:19:19 --> Hooks Class Initialized
DEBUG - 2026-01-27 05:19:19 --> UTF-8 Support Enabled
INFO - 2026-01-27 05:19:19 --> Utf8 Class Initialized
INFO - 2026-01-27 05:19:19 --> URI Class Initialized
INFO - 2026-01-27 05:19:19 --> Router Class Initialized
INFO - 2026-01-27 05:19:19 --> Output Class Initialized
INFO - 2026-01-27 05:19:19 --> Security Class Initialized
DEBUG - 2026-01-27 05:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 05:19:19 --> CSRF cookie sent
INFO - 2026-01-27 05:19:19 --> Input Class Initialized
INFO - 2026-01-27 05:19:19 --> Language Class Initialized
INFO - 2026-01-27 05:19:19 --> Loader Class Initialized
INFO - 2026-01-27 05:19:19 --> Helper loaded: url_helper
INFO - 2026-01-27 05:19:19 --> Helper loaded: text_helper
INFO - 2026-01-27 05:19:19 --> Helper loaded: string_helper
INFO - 2026-01-27 05:19:19 --> Helper loaded: form_helper
INFO - 2026-01-27 05:19:19 --> Helper loaded: download_helper
INFO - 2026-01-27 05:19:19 --> Helper loaded: security_helper
INFO - 2026-01-27 05:19:19 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 05:19:19 --> Database Driver Class Initialized
DEBUG - 2026-01-27 05:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 05:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 05:19:19 --> Form Validation Class Initialized
INFO - 2026-01-27 05:19:19 --> Model "User_model" initialized
INFO - 2026-01-27 11:19:19 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 11:19:19 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 11:19:19 --> Model "Nav_model" initialized
INFO - 2026-01-27 11:19:19 --> Controller Class Initialized
INFO - 2026-01-27 11:19:19 --> Model "Sitemap_model" initialized
INFO - 2026-01-27 11:19:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_berita.php
INFO - 2026-01-27 11:19:19 --> Model "Log_model" initialized
INFO - 2026-01-27 11:19:19 --> Final output sent to browser
DEBUG - 2026-01-27 11:19:19 --> Total execution time: 0.1468
INFO - 2026-01-27 05:19:28 --> Config Class Initialized
INFO - 2026-01-27 05:19:28 --> Hooks Class Initialized
DEBUG - 2026-01-27 05:19:28 --> UTF-8 Support Enabled
INFO - 2026-01-27 05:19:28 --> Utf8 Class Initialized
INFO - 2026-01-27 05:19:28 --> URI Class Initialized
INFO - 2026-01-27 05:19:28 --> Router Class Initialized
INFO - 2026-01-27 05:19:28 --> Output Class Initialized
INFO - 2026-01-27 05:19:28 --> Security Class Initialized
DEBUG - 2026-01-27 05:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 05:19:28 --> CSRF cookie sent
INFO - 2026-01-27 05:19:28 --> Input Class Initialized
INFO - 2026-01-27 05:19:28 --> Language Class Initialized
INFO - 2026-01-27 05:19:28 --> Loader Class Initialized
INFO - 2026-01-27 05:19:28 --> Helper loaded: url_helper
INFO - 2026-01-27 05:19:28 --> Helper loaded: text_helper
INFO - 2026-01-27 05:19:28 --> Helper loaded: string_helper
INFO - 2026-01-27 05:19:28 --> Helper loaded: form_helper
INFO - 2026-01-27 05:19:28 --> Helper loaded: download_helper
INFO - 2026-01-27 05:19:28 --> Helper loaded: security_helper
INFO - 2026-01-27 05:19:28 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 05:19:28 --> Database Driver Class Initialized
DEBUG - 2026-01-27 05:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 05:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 05:19:28 --> Form Validation Class Initialized
INFO - 2026-01-27 05:19:28 --> Model "User_model" initialized
INFO - 2026-01-27 11:19:28 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 11:19:28 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 11:19:28 --> Model "Nav_model" initialized
INFO - 2026-01-27 11:19:28 --> Controller Class Initialized
INFO - 2026-01-27 11:19:28 --> Model "Sitemap_model" initialized
INFO - 2026-01-27 11:19:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_prodi.php
INFO - 2026-01-27 11:19:28 --> Model "Log_model" initialized
INFO - 2026-01-27 11:19:28 --> Final output sent to browser
DEBUG - 2026-01-27 11:19:28 --> Total execution time: 0.1526
INFO - 2026-01-27 07:46:51 --> Config Class Initialized
INFO - 2026-01-27 07:46:51 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:46:51 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:46:51 --> Utf8 Class Initialized
INFO - 2026-01-27 07:46:51 --> URI Class Initialized
DEBUG - 2026-01-27 07:46:51 --> No URI present. Default controller set.
INFO - 2026-01-27 07:46:51 --> Router Class Initialized
INFO - 2026-01-27 07:46:51 --> Output Class Initialized
INFO - 2026-01-27 07:46:51 --> Security Class Initialized
DEBUG - 2026-01-27 07:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:46:51 --> CSRF cookie sent
INFO - 2026-01-27 07:46:51 --> Input Class Initialized
INFO - 2026-01-27 07:46:51 --> Language Class Initialized
INFO - 2026-01-27 07:46:51 --> Loader Class Initialized
INFO - 2026-01-27 07:46:51 --> Helper loaded: url_helper
INFO - 2026-01-27 07:46:51 --> Helper loaded: text_helper
INFO - 2026-01-27 07:46:51 --> Helper loaded: string_helper
INFO - 2026-01-27 07:46:51 --> Helper loaded: form_helper
INFO - 2026-01-27 07:46:51 --> Helper loaded: download_helper
INFO - 2026-01-27 07:46:51 --> Helper loaded: security_helper
INFO - 2026-01-27 07:46:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:46:51 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:46:51 --> Form Validation Class Initialized
INFO - 2026-01-27 07:46:51 --> Model "User_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:46:51 --> Controller Class Initialized
INFO - 2026-01-27 13:46:51 --> Model "Berita_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Galeri_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Video_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Agenda_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Tautan_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Mitra_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Prodi_model" initialized
INFO - 2026-01-27 13:46:51 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 13:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 13:46:51 --> Pagination Class Initialized
INFO - 2026-01-27 13:46:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 13:46:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 13:46:52 --> Model "Log_model" initialized
INFO - 2026-01-27 13:46:52 --> Final output sent to browser
DEBUG - 2026-01-27 13:46:52 --> Total execution time: 0.5174
INFO - 2026-01-27 07:49:25 --> Config Class Initialized
INFO - 2026-01-27 07:49:25 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:49:25 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:49:25 --> Utf8 Class Initialized
INFO - 2026-01-27 07:49:25 --> URI Class Initialized
INFO - 2026-01-27 07:49:25 --> Router Class Initialized
INFO - 2026-01-27 07:49:25 --> Output Class Initialized
INFO - 2026-01-27 07:49:25 --> Security Class Initialized
DEBUG - 2026-01-27 07:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:49:25 --> CSRF cookie sent
INFO - 2026-01-27 07:49:25 --> Input Class Initialized
INFO - 2026-01-27 07:49:25 --> Language Class Initialized
INFO - 2026-01-27 07:49:25 --> Loader Class Initialized
INFO - 2026-01-27 07:49:25 --> Helper loaded: url_helper
INFO - 2026-01-27 07:49:25 --> Helper loaded: text_helper
INFO - 2026-01-27 07:49:25 --> Helper loaded: string_helper
INFO - 2026-01-27 07:49:25 --> Helper loaded: form_helper
INFO - 2026-01-27 07:49:25 --> Helper loaded: download_helper
INFO - 2026-01-27 07:49:25 --> Helper loaded: security_helper
INFO - 2026-01-27 07:49:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:49:25 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:49:25 --> Form Validation Class Initialized
INFO - 2026-01-27 07:49:25 --> Model "User_model" initialized
INFO - 2026-01-27 13:49:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:49:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:49:25 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:49:25 --> Controller Class Initialized
INFO - 2026-01-27 13:49:25 --> Model "Sdm_model" initialized
INFO - 2026-01-27 13:49:25 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-27 13:49:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-27 13:49:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 13:49:25 --> Model "Log_model" initialized
INFO - 2026-01-27 13:49:25 --> Final output sent to browser
DEBUG - 2026-01-27 13:49:25 --> Total execution time: 0.2437
INFO - 2026-01-27 07:49:30 --> Config Class Initialized
INFO - 2026-01-27 07:49:30 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:49:30 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:49:30 --> Utf8 Class Initialized
INFO - 2026-01-27 07:49:30 --> URI Class Initialized
INFO - 2026-01-27 07:49:30 --> Router Class Initialized
INFO - 2026-01-27 07:49:30 --> Output Class Initialized
INFO - 2026-01-27 07:49:30 --> Security Class Initialized
DEBUG - 2026-01-27 07:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:49:30 --> CSRF cookie sent
INFO - 2026-01-27 07:49:30 --> Input Class Initialized
INFO - 2026-01-27 07:49:30 --> Language Class Initialized
INFO - 2026-01-27 07:49:30 --> Loader Class Initialized
INFO - 2026-01-27 07:49:30 --> Helper loaded: url_helper
INFO - 2026-01-27 07:49:30 --> Helper loaded: text_helper
INFO - 2026-01-27 07:49:30 --> Helper loaded: string_helper
INFO - 2026-01-27 07:49:30 --> Helper loaded: form_helper
INFO - 2026-01-27 07:49:30 --> Helper loaded: download_helper
INFO - 2026-01-27 07:49:30 --> Helper loaded: security_helper
INFO - 2026-01-27 07:49:30 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:49:30 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:49:30 --> Form Validation Class Initialized
INFO - 2026-01-27 07:49:30 --> Model "User_model" initialized
INFO - 2026-01-27 13:49:30 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:49:30 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:49:30 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:49:30 --> Controller Class Initialized
INFO - 2026-01-27 13:49:30 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 13:49:30 --> Model "Prodi_model" initialized
INFO - 2026-01-27 13:49:30 --> Model "Sdm_model" initialized
INFO - 2026-01-27 13:49:30 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 13:49:30 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-27 13:49:30 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 13:49:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 13:49:30 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 13:49:30 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 13:49:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 13:49:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 13:49:30 --> Model "Log_model" initialized
INFO - 2026-01-27 13:49:30 --> Final output sent to browser
DEBUG - 2026-01-27 13:49:30 --> Total execution time: 0.5643
INFO - 2026-01-27 07:49:37 --> Config Class Initialized
INFO - 2026-01-27 07:49:37 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:49:37 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:49:37 --> Utf8 Class Initialized
INFO - 2026-01-27 07:49:37 --> URI Class Initialized
INFO - 2026-01-27 07:49:37 --> Router Class Initialized
INFO - 2026-01-27 07:49:37 --> Output Class Initialized
INFO - 2026-01-27 07:49:37 --> Security Class Initialized
DEBUG - 2026-01-27 07:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:49:37 --> CSRF cookie sent
INFO - 2026-01-27 07:49:37 --> Input Class Initialized
INFO - 2026-01-27 07:49:37 --> Language Class Initialized
INFO - 2026-01-27 07:49:37 --> Loader Class Initialized
INFO - 2026-01-27 07:49:37 --> Helper loaded: url_helper
INFO - 2026-01-27 07:49:37 --> Helper loaded: text_helper
INFO - 2026-01-27 07:49:37 --> Helper loaded: string_helper
INFO - 2026-01-27 07:49:37 --> Helper loaded: form_helper
INFO - 2026-01-27 07:49:37 --> Helper loaded: download_helper
INFO - 2026-01-27 07:49:37 --> Helper loaded: security_helper
INFO - 2026-01-27 07:49:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:49:37 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:49:38 --> Form Validation Class Initialized
INFO - 2026-01-27 07:49:38 --> Model "User_model" initialized
INFO - 2026-01-27 13:49:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:49:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:49:38 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:49:38 --> Controller Class Initialized
INFO - 2026-01-27 13:49:38 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 13:49:38 --> Model "Prodi_model" initialized
INFO - 2026-01-27 13:49:38 --> Model "Sdm_model" initialized
INFO - 2026-01-27 13:49:38 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 13:49:38 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 13:49:38 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 13:49:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 13:49:38 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 13:49:38 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 13:49:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 13:49:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 13:49:38 --> Model "Log_model" initialized
INFO - 2026-01-27 13:49:38 --> Final output sent to browser
DEBUG - 2026-01-27 13:49:38 --> Total execution time: 0.3798
INFO - 2026-01-27 07:49:45 --> Config Class Initialized
INFO - 2026-01-27 07:49:45 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:49:45 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:49:45 --> Utf8 Class Initialized
INFO - 2026-01-27 07:49:45 --> URI Class Initialized
INFO - 2026-01-27 07:49:45 --> Router Class Initialized
INFO - 2026-01-27 07:49:45 --> Output Class Initialized
INFO - 2026-01-27 07:49:45 --> Security Class Initialized
DEBUG - 2026-01-27 07:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:49:45 --> CSRF cookie sent
INFO - 2026-01-27 07:49:45 --> Input Class Initialized
INFO - 2026-01-27 07:49:45 --> Language Class Initialized
INFO - 2026-01-27 07:49:45 --> Loader Class Initialized
INFO - 2026-01-27 07:49:45 --> Helper loaded: url_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: text_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: string_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: form_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: download_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: security_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:49:45 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:49:45 --> Form Validation Class Initialized
INFO - 2026-01-27 07:49:45 --> Model "User_model" initialized
INFO - 2026-01-27 13:49:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:49:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:49:45 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:49:45 --> Controller Class Initialized
INFO - 2026-01-27 13:49:45 --> Model "Sdm_model" initialized
INFO - 2026-01-27 07:49:45 --> Config Class Initialized
INFO - 2026-01-27 07:49:45 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:49:45 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:49:45 --> Utf8 Class Initialized
INFO - 2026-01-27 07:49:45 --> URI Class Initialized
INFO - 2026-01-27 07:49:45 --> Router Class Initialized
INFO - 2026-01-27 07:49:45 --> Output Class Initialized
INFO - 2026-01-27 07:49:45 --> Security Class Initialized
DEBUG - 2026-01-27 07:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:49:45 --> CSRF cookie sent
INFO - 2026-01-27 07:49:45 --> Input Class Initialized
INFO - 2026-01-27 07:49:45 --> Language Class Initialized
INFO - 2026-01-27 07:49:45 --> Loader Class Initialized
INFO - 2026-01-27 07:49:45 --> Helper loaded: url_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: text_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: string_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: form_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: download_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: security_helper
INFO - 2026-01-27 07:49:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:49:45 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:49:45 --> Form Validation Class Initialized
INFO - 2026-01-27 07:49:45 --> Model "User_model" initialized
INFO - 2026-01-27 13:49:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:49:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:49:45 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:49:45 --> Controller Class Initialized
DEBUG - 2026-01-27 13:49:45 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 13:49:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-27 13:49:45 --> Model "Log_model" initialized
INFO - 2026-01-27 13:49:45 --> Final output sent to browser
DEBUG - 2026-01-27 13:49:45 --> Total execution time: 0.1061
INFO - 2026-01-27 07:49:53 --> Config Class Initialized
INFO - 2026-01-27 07:49:53 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:49:53 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:49:53 --> Utf8 Class Initialized
INFO - 2026-01-27 07:49:53 --> URI Class Initialized
INFO - 2026-01-27 07:49:53 --> Router Class Initialized
INFO - 2026-01-27 07:49:53 --> Output Class Initialized
INFO - 2026-01-27 07:49:53 --> Security Class Initialized
DEBUG - 2026-01-27 07:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:49:53 --> CSRF cookie sent
INFO - 2026-01-27 07:49:53 --> CSRF token verified
INFO - 2026-01-27 07:49:53 --> Input Class Initialized
INFO - 2026-01-27 07:49:53 --> Language Class Initialized
INFO - 2026-01-27 07:49:53 --> Loader Class Initialized
INFO - 2026-01-27 07:49:53 --> Helper loaded: url_helper
INFO - 2026-01-27 07:49:53 --> Helper loaded: text_helper
INFO - 2026-01-27 07:49:53 --> Helper loaded: string_helper
INFO - 2026-01-27 07:49:53 --> Helper loaded: form_helper
INFO - 2026-01-27 07:49:53 --> Helper loaded: download_helper
INFO - 2026-01-27 07:49:53 --> Helper loaded: security_helper
INFO - 2026-01-27 07:49:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:49:53 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:49:53 --> Form Validation Class Initialized
INFO - 2026-01-27 07:49:53 --> Model "User_model" initialized
INFO - 2026-01-27 13:49:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:49:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:49:53 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:49:53 --> Controller Class Initialized
DEBUG - 2026-01-27 13:49:53 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 13:49:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 13:49:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-27 13:49:54 --> Model "Log_model" initialized
INFO - 2026-01-27 13:49:54 --> Final output sent to browser
DEBUG - 2026-01-27 13:49:54 --> Total execution time: 0.2622
INFO - 2026-01-27 07:49:59 --> Config Class Initialized
INFO - 2026-01-27 07:49:59 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:49:59 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:49:59 --> Utf8 Class Initialized
INFO - 2026-01-27 07:49:59 --> URI Class Initialized
INFO - 2026-01-27 07:49:59 --> Router Class Initialized
INFO - 2026-01-27 07:49:59 --> Output Class Initialized
INFO - 2026-01-27 07:49:59 --> Security Class Initialized
DEBUG - 2026-01-27 07:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:49:59 --> CSRF cookie sent
INFO - 2026-01-27 07:49:59 --> CSRF token verified
INFO - 2026-01-27 07:49:59 --> Input Class Initialized
INFO - 2026-01-27 07:49:59 --> Language Class Initialized
INFO - 2026-01-27 07:49:59 --> Loader Class Initialized
INFO - 2026-01-27 07:49:59 --> Helper loaded: url_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: text_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: string_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: form_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: download_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: security_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:49:59 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:49:59 --> Form Validation Class Initialized
INFO - 2026-01-27 07:49:59 --> Model "User_model" initialized
INFO - 2026-01-27 13:49:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:49:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:49:59 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:49:59 --> Controller Class Initialized
DEBUG - 2026-01-27 13:49:59 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-27 13:49:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-27 07:49:59 --> Config Class Initialized
INFO - 2026-01-27 07:49:59 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:49:59 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:49:59 --> Utf8 Class Initialized
INFO - 2026-01-27 07:49:59 --> URI Class Initialized
INFO - 2026-01-27 07:49:59 --> Router Class Initialized
INFO - 2026-01-27 07:49:59 --> Output Class Initialized
INFO - 2026-01-27 07:49:59 --> Security Class Initialized
DEBUG - 2026-01-27 07:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:49:59 --> CSRF cookie sent
INFO - 2026-01-27 07:49:59 --> Input Class Initialized
INFO - 2026-01-27 07:49:59 --> Language Class Initialized
INFO - 2026-01-27 07:49:59 --> Loader Class Initialized
INFO - 2026-01-27 07:49:59 --> Helper loaded: url_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: text_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: string_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: form_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: download_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: security_helper
INFO - 2026-01-27 07:49:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:49:59 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:49:59 --> Form Validation Class Initialized
INFO - 2026-01-27 07:49:59 --> Model "User_model" initialized
INFO - 2026-01-27 13:49:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:49:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:49:59 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:49:59 --> Controller Class Initialized
INFO - 2026-01-27 13:49:59 --> Model "Sdm_model" initialized
INFO - 2026-01-27 13:49:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2026-01-27 13:49:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 13:49:59 --> Model "Log_model" initialized
INFO - 2026-01-27 13:49:59 --> Final output sent to browser
DEBUG - 2026-01-27 13:49:59 --> Total execution time: 0.1158
INFO - 2026-01-27 07:50:05 --> Config Class Initialized
INFO - 2026-01-27 07:50:05 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:50:05 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:50:05 --> Utf8 Class Initialized
INFO - 2026-01-27 07:50:05 --> URI Class Initialized
INFO - 2026-01-27 07:50:05 --> Router Class Initialized
INFO - 2026-01-27 07:50:05 --> Output Class Initialized
INFO - 2026-01-27 07:50:05 --> Security Class Initialized
DEBUG - 2026-01-27 07:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:50:05 --> CSRF cookie sent
INFO - 2026-01-27 07:50:05 --> Input Class Initialized
INFO - 2026-01-27 07:50:05 --> Language Class Initialized
INFO - 2026-01-27 07:50:05 --> Loader Class Initialized
INFO - 2026-01-27 07:50:05 --> Helper loaded: url_helper
INFO - 2026-01-27 07:50:05 --> Helper loaded: text_helper
INFO - 2026-01-27 07:50:05 --> Helper loaded: string_helper
INFO - 2026-01-27 07:50:05 --> Helper loaded: form_helper
INFO - 2026-01-27 07:50:05 --> Helper loaded: download_helper
INFO - 2026-01-27 07:50:05 --> Helper loaded: security_helper
INFO - 2026-01-27 07:50:05 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:50:05 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:50:05 --> Form Validation Class Initialized
INFO - 2026-01-27 07:50:05 --> Model "User_model" initialized
INFO - 2026-01-27 13:50:05 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:50:05 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:50:05 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:50:05 --> Controller Class Initialized
INFO - 2026-01-27 13:50:05 --> Model "Sdm_model" initialized
INFO - 2026-01-27 13:50:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/tambah.php
INFO - 2026-01-27 13:50:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-27 13:50:05 --> Model "Log_model" initialized
INFO - 2026-01-27 13:50:05 --> Final output sent to browser
DEBUG - 2026-01-27 13:50:05 --> Total execution time: 0.1325
INFO - 2026-01-27 07:54:29 --> Config Class Initialized
INFO - 2026-01-27 07:54:29 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:54:29 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:54:29 --> Utf8 Class Initialized
INFO - 2026-01-27 07:54:29 --> URI Class Initialized
INFO - 2026-01-27 07:54:29 --> Router Class Initialized
INFO - 2026-01-27 07:54:29 --> Output Class Initialized
INFO - 2026-01-27 07:54:29 --> Security Class Initialized
DEBUG - 2026-01-27 07:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:54:29 --> CSRF cookie sent
INFO - 2026-01-27 07:54:29 --> Input Class Initialized
INFO - 2026-01-27 07:54:29 --> Language Class Initialized
INFO - 2026-01-27 07:54:29 --> Loader Class Initialized
INFO - 2026-01-27 07:54:29 --> Helper loaded: url_helper
INFO - 2026-01-27 07:54:29 --> Helper loaded: text_helper
INFO - 2026-01-27 07:54:29 --> Helper loaded: string_helper
INFO - 2026-01-27 07:54:29 --> Helper loaded: form_helper
INFO - 2026-01-27 07:54:29 --> Helper loaded: download_helper
INFO - 2026-01-27 07:54:29 --> Helper loaded: security_helper
INFO - 2026-01-27 07:54:29 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:54:29 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:54:29 --> Form Validation Class Initialized
INFO - 2026-01-27 07:54:29 --> Model "User_model" initialized
INFO - 2026-01-27 13:54:29 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:54:29 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:54:29 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:54:29 --> Controller Class Initialized
INFO - 2026-01-27 13:54:29 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 13:54:29 --> Model "Prodi_model" initialized
INFO - 2026-01-27 13:54:29 --> Model "Sdm_model" initialized
INFO - 2026-01-27 13:54:29 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 13:54:29 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 13:54:29 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 13:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 13:54:29 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 13:54:29 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 13:54:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 13:54:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 13:54:29 --> Model "Log_model" initialized
INFO - 2026-01-27 13:54:29 --> Final output sent to browser
DEBUG - 2026-01-27 13:54:29 --> Total execution time: 0.2578
INFO - 2026-01-27 07:54:39 --> Config Class Initialized
INFO - 2026-01-27 07:54:39 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:54:39 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:54:39 --> Utf8 Class Initialized
INFO - 2026-01-27 07:54:39 --> URI Class Initialized
INFO - 2026-01-27 07:54:39 --> Router Class Initialized
INFO - 2026-01-27 07:54:39 --> Output Class Initialized
INFO - 2026-01-27 07:54:39 --> Security Class Initialized
DEBUG - 2026-01-27 07:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:54:39 --> CSRF cookie sent
INFO - 2026-01-27 07:54:39 --> Input Class Initialized
INFO - 2026-01-27 07:54:39 --> Language Class Initialized
INFO - 2026-01-27 07:54:39 --> Loader Class Initialized
INFO - 2026-01-27 07:54:39 --> Helper loaded: url_helper
INFO - 2026-01-27 07:54:39 --> Helper loaded: text_helper
INFO - 2026-01-27 07:54:39 --> Helper loaded: string_helper
INFO - 2026-01-27 07:54:39 --> Helper loaded: form_helper
INFO - 2026-01-27 07:54:39 --> Helper loaded: download_helper
INFO - 2026-01-27 07:54:39 --> Helper loaded: security_helper
INFO - 2026-01-27 07:54:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:54:39 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:54:39 --> Form Validation Class Initialized
INFO - 2026-01-27 07:54:39 --> Model "User_model" initialized
INFO - 2026-01-27 13:54:40 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:54:40 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:54:40 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:54:40 --> Controller Class Initialized
INFO - 2026-01-27 13:54:40 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 13:54:40 --> Model "Prodi_model" initialized
INFO - 2026-01-27 13:54:40 --> Model "Sdm_model" initialized
INFO - 2026-01-27 13:54:40 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 13:54:40 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 13:54:40 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 13:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 13:54:40 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 13:54:40 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 13:54:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 13:54:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 13:54:40 --> Model "Log_model" initialized
INFO - 2026-01-27 13:54:40 --> Final output sent to browser
DEBUG - 2026-01-27 13:54:40 --> Total execution time: 0.2328
INFO - 2026-01-27 07:54:41 --> Config Class Initialized
INFO - 2026-01-27 07:54:41 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:54:41 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:54:41 --> Utf8 Class Initialized
INFO - 2026-01-27 07:54:41 --> URI Class Initialized
INFO - 2026-01-27 07:54:41 --> Router Class Initialized
INFO - 2026-01-27 07:54:41 --> Output Class Initialized
INFO - 2026-01-27 07:54:41 --> Security Class Initialized
DEBUG - 2026-01-27 07:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:54:41 --> CSRF cookie sent
INFO - 2026-01-27 07:54:41 --> Input Class Initialized
INFO - 2026-01-27 07:54:41 --> Language Class Initialized
INFO - 2026-01-27 07:54:41 --> Loader Class Initialized
INFO - 2026-01-27 07:54:41 --> Helper loaded: url_helper
INFO - 2026-01-27 07:54:41 --> Helper loaded: text_helper
INFO - 2026-01-27 07:54:41 --> Helper loaded: string_helper
INFO - 2026-01-27 07:54:41 --> Helper loaded: form_helper
INFO - 2026-01-27 07:54:41 --> Helper loaded: download_helper
INFO - 2026-01-27 07:54:41 --> Helper loaded: security_helper
INFO - 2026-01-27 07:54:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:54:41 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:54:41 --> Form Validation Class Initialized
INFO - 2026-01-27 07:54:41 --> Model "User_model" initialized
INFO - 2026-01-27 13:54:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:54:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:54:41 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:54:41 --> Controller Class Initialized
INFO - 2026-01-27 13:54:41 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 13:54:41 --> Model "Prodi_model" initialized
INFO - 2026-01-27 13:54:41 --> Model "Sdm_model" initialized
INFO - 2026-01-27 13:54:41 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-27 13:54:42 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-27 13:54:42 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 13:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-27 13:54:42 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-27 13:54:42 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-27 13:54:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-27 13:54:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 13:54:42 --> Model "Log_model" initialized
INFO - 2026-01-27 13:54:42 --> Final output sent to browser
DEBUG - 2026-01-27 13:54:42 --> Total execution time: 0.3103
INFO - 2026-01-27 07:54:51 --> Config Class Initialized
INFO - 2026-01-27 07:54:51 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:54:51 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:54:51 --> Utf8 Class Initialized
INFO - 2026-01-27 07:54:51 --> URI Class Initialized
INFO - 2026-01-27 07:54:51 --> Router Class Initialized
INFO - 2026-01-27 07:54:51 --> Output Class Initialized
INFO - 2026-01-27 07:54:51 --> Security Class Initialized
DEBUG - 2026-01-27 07:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:54:51 --> CSRF cookie sent
INFO - 2026-01-27 07:54:51 --> Input Class Initialized
INFO - 2026-01-27 07:54:51 --> Language Class Initialized
INFO - 2026-01-27 07:54:51 --> Loader Class Initialized
INFO - 2026-01-27 07:54:51 --> Helper loaded: url_helper
INFO - 2026-01-27 07:54:51 --> Helper loaded: text_helper
INFO - 2026-01-27 07:54:51 --> Helper loaded: string_helper
INFO - 2026-01-27 07:54:51 --> Helper loaded: form_helper
INFO - 2026-01-27 07:54:51 --> Helper loaded: download_helper
INFO - 2026-01-27 07:54:51 --> Helper loaded: security_helper
INFO - 2026-01-27 07:54:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:54:51 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:54:51 --> Form Validation Class Initialized
INFO - 2026-01-27 07:54:51 --> Model "User_model" initialized
INFO - 2026-01-27 13:54:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:54:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:54:51 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:54:51 --> Controller Class Initialized
INFO - 2026-01-27 13:54:51 --> Model "Sitemap_model" initialized
INFO - 2026-01-27 13:54:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_index.php
INFO - 2026-01-27 13:54:51 --> Model "Log_model" initialized
INFO - 2026-01-27 13:54:51 --> Final output sent to browser
DEBUG - 2026-01-27 13:54:51 --> Total execution time: 0.1847
INFO - 2026-01-27 07:54:58 --> Config Class Initialized
INFO - 2026-01-27 07:54:58 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:54:58 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:54:58 --> Utf8 Class Initialized
INFO - 2026-01-27 07:54:58 --> URI Class Initialized
INFO - 2026-01-27 07:54:58 --> Router Class Initialized
INFO - 2026-01-27 07:54:58 --> Output Class Initialized
INFO - 2026-01-27 07:54:58 --> Security Class Initialized
DEBUG - 2026-01-27 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:54:58 --> CSRF cookie sent
INFO - 2026-01-27 07:54:58 --> Input Class Initialized
INFO - 2026-01-27 07:54:58 --> Language Class Initialized
INFO - 2026-01-27 07:54:58 --> Loader Class Initialized
INFO - 2026-01-27 07:54:58 --> Helper loaded: url_helper
INFO - 2026-01-27 07:54:58 --> Helper loaded: text_helper
INFO - 2026-01-27 07:54:58 --> Helper loaded: string_helper
INFO - 2026-01-27 07:54:58 --> Helper loaded: form_helper
INFO - 2026-01-27 07:54:58 --> Helper loaded: download_helper
INFO - 2026-01-27 07:54:58 --> Helper loaded: security_helper
INFO - 2026-01-27 07:54:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:54:58 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:54:58 --> Form Validation Class Initialized
INFO - 2026-01-27 07:54:58 --> Model "User_model" initialized
INFO - 2026-01-27 13:54:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:54:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:54:58 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:54:58 --> Controller Class Initialized
INFO - 2026-01-27 13:54:58 --> Model "Sitemap_model" initialized
INFO - 2026-01-27 13:54:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_custom.php
INFO - 2026-01-27 13:54:58 --> Model "Log_model" initialized
INFO - 2026-01-27 13:54:58 --> Final output sent to browser
DEBUG - 2026-01-27 13:54:58 --> Total execution time: 0.0759
INFO - 2026-01-27 07:55:06 --> Config Class Initialized
INFO - 2026-01-27 07:55:06 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:55:06 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:55:06 --> Utf8 Class Initialized
INFO - 2026-01-27 07:55:06 --> URI Class Initialized
INFO - 2026-01-27 07:55:06 --> Router Class Initialized
INFO - 2026-01-27 07:55:06 --> Output Class Initialized
INFO - 2026-01-27 07:55:06 --> Security Class Initialized
DEBUG - 2026-01-27 07:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:55:06 --> CSRF cookie sent
INFO - 2026-01-27 07:55:06 --> Input Class Initialized
INFO - 2026-01-27 07:55:06 --> Language Class Initialized
INFO - 2026-01-27 07:55:06 --> Loader Class Initialized
INFO - 2026-01-27 07:55:06 --> Helper loaded: url_helper
INFO - 2026-01-27 07:55:06 --> Helper loaded: text_helper
INFO - 2026-01-27 07:55:06 --> Helper loaded: string_helper
INFO - 2026-01-27 07:55:06 --> Helper loaded: form_helper
INFO - 2026-01-27 07:55:06 --> Helper loaded: download_helper
INFO - 2026-01-27 07:55:06 --> Helper loaded: security_helper
INFO - 2026-01-27 07:55:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:55:06 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:55:06 --> Form Validation Class Initialized
INFO - 2026-01-27 07:55:06 --> Model "User_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:55:06 --> Controller Class Initialized
INFO - 2026-01-27 13:55:06 --> Model "Berita_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Galeri_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Video_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Agenda_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Tautan_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Mitra_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Prodi_model" initialized
INFO - 2026-01-27 13:55:06 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 13:55:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-27 13:55:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 13:55:06 --> Model "Log_model" initialized
INFO - 2026-01-27 13:55:06 --> Final output sent to browser
DEBUG - 2026-01-27 13:55:06 --> Total execution time: 0.1928
INFO - 2026-01-27 07:55:11 --> Config Class Initialized
INFO - 2026-01-27 07:55:11 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:55:11 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:55:11 --> Utf8 Class Initialized
INFO - 2026-01-27 07:55:11 --> URI Class Initialized
INFO - 2026-01-27 07:55:11 --> Router Class Initialized
INFO - 2026-01-27 07:55:11 --> Output Class Initialized
INFO - 2026-01-27 07:55:11 --> Security Class Initialized
DEBUG - 2026-01-27 07:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:55:11 --> CSRF cookie sent
INFO - 2026-01-27 07:55:11 --> Input Class Initialized
INFO - 2026-01-27 07:55:11 --> Language Class Initialized
INFO - 2026-01-27 07:55:11 --> Loader Class Initialized
INFO - 2026-01-27 07:55:11 --> Helper loaded: url_helper
INFO - 2026-01-27 07:55:11 --> Helper loaded: text_helper
INFO - 2026-01-27 07:55:11 --> Helper loaded: string_helper
INFO - 2026-01-27 07:55:11 --> Helper loaded: form_helper
INFO - 2026-01-27 07:55:11 --> Helper loaded: download_helper
INFO - 2026-01-27 07:55:11 --> Helper loaded: security_helper
INFO - 2026-01-27 07:55:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:55:11 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:55:11 --> Form Validation Class Initialized
INFO - 2026-01-27 07:55:11 --> Model "User_model" initialized
INFO - 2026-01-27 13:55:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:55:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:55:11 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:55:11 --> Controller Class Initialized
INFO - 2026-01-27 13:55:11 --> Model "Sitemap_model" initialized
INFO - 2026-01-27 13:55:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_berita.php
INFO - 2026-01-27 13:55:11 --> Model "Log_model" initialized
INFO - 2026-01-27 13:55:11 --> Final output sent to browser
DEBUG - 2026-01-27 13:55:11 --> Total execution time: 0.2624
INFO - 2026-01-27 07:55:30 --> Config Class Initialized
INFO - 2026-01-27 07:55:30 --> Hooks Class Initialized
DEBUG - 2026-01-27 07:55:30 --> UTF-8 Support Enabled
INFO - 2026-01-27 07:55:30 --> Utf8 Class Initialized
INFO - 2026-01-27 07:55:30 --> URI Class Initialized
INFO - 2026-01-27 07:55:30 --> Router Class Initialized
INFO - 2026-01-27 07:55:30 --> Output Class Initialized
INFO - 2026-01-27 07:55:30 --> Security Class Initialized
DEBUG - 2026-01-27 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 07:55:30 --> CSRF cookie sent
INFO - 2026-01-27 07:55:30 --> Input Class Initialized
INFO - 2026-01-27 07:55:30 --> Language Class Initialized
INFO - 2026-01-27 07:55:30 --> Loader Class Initialized
INFO - 2026-01-27 07:55:30 --> Helper loaded: url_helper
INFO - 2026-01-27 07:55:30 --> Helper loaded: text_helper
INFO - 2026-01-27 07:55:30 --> Helper loaded: string_helper
INFO - 2026-01-27 07:55:30 --> Helper loaded: form_helper
INFO - 2026-01-27 07:55:30 --> Helper loaded: download_helper
INFO - 2026-01-27 07:55:30 --> Helper loaded: security_helper
INFO - 2026-01-27 07:55:30 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 07:55:30 --> Database Driver Class Initialized
DEBUG - 2026-01-27 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 07:55:30 --> Form Validation Class Initialized
INFO - 2026-01-27 07:55:30 --> Model "User_model" initialized
INFO - 2026-01-27 13:55:30 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 13:55:30 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 13:55:30 --> Model "Nav_model" initialized
INFO - 2026-01-27 13:55:30 --> Controller Class Initialized
INFO - 2026-01-27 13:55:30 --> Model "Sitemap_model" initialized
INFO - 2026-01-27 13:55:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_prodi.php
INFO - 2026-01-27 13:55:30 --> Model "Log_model" initialized
INFO - 2026-01-27 13:55:30 --> Final output sent to browser
DEBUG - 2026-01-27 13:55:30 --> Total execution time: 0.1605
INFO - 2026-01-27 08:08:51 --> Config Class Initialized
INFO - 2026-01-27 08:08:51 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:08:51 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:08:51 --> Utf8 Class Initialized
INFO - 2026-01-27 08:08:51 --> URI Class Initialized
INFO - 2026-01-27 08:08:51 --> Router Class Initialized
INFO - 2026-01-27 08:08:51 --> Output Class Initialized
INFO - 2026-01-27 08:08:51 --> Security Class Initialized
DEBUG - 2026-01-27 08:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:08:51 --> CSRF cookie sent
INFO - 2026-01-27 08:08:51 --> Input Class Initialized
INFO - 2026-01-27 08:08:51 --> Language Class Initialized
INFO - 2026-01-27 08:08:51 --> Loader Class Initialized
INFO - 2026-01-27 08:08:51 --> Helper loaded: url_helper
INFO - 2026-01-27 08:08:51 --> Helper loaded: text_helper
INFO - 2026-01-27 08:08:51 --> Helper loaded: string_helper
INFO - 2026-01-27 08:08:51 --> Helper loaded: form_helper
INFO - 2026-01-27 08:08:51 --> Helper loaded: download_helper
INFO - 2026-01-27 08:08:51 --> Helper loaded: security_helper
INFO - 2026-01-27 08:08:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:08:51 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:08:51 --> Form Validation Class Initialized
INFO - 2026-01-27 08:08:51 --> Model "User_model" initialized
INFO - 2026-01-27 14:08:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:08:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:08:51 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:08:51 --> Controller Class Initialized
INFO - 2026-01-27 14:08:51 --> Model "Sitemap_model" initialized
INFO - 2026-01-27 14:08:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sitemap/sitemap_berita.php
INFO - 2026-01-27 14:08:51 --> Model "Log_model" initialized
INFO - 2026-01-27 14:08:51 --> Final output sent to browser
DEBUG - 2026-01-27 14:08:51 --> Total execution time: 0.1139
INFO - 2026-01-27 08:08:52 --> Config Class Initialized
INFO - 2026-01-27 08:08:52 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:08:52 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:08:52 --> Utf8 Class Initialized
INFO - 2026-01-27 08:08:52 --> URI Class Initialized
INFO - 2026-01-27 08:08:52 --> Router Class Initialized
INFO - 2026-01-27 08:08:52 --> Output Class Initialized
INFO - 2026-01-27 08:08:52 --> Security Class Initialized
DEBUG - 2026-01-27 08:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:08:52 --> CSRF cookie sent
INFO - 2026-01-27 08:08:52 --> Input Class Initialized
INFO - 2026-01-27 08:08:52 --> Language Class Initialized
INFO - 2026-01-27 08:08:52 --> Loader Class Initialized
INFO - 2026-01-27 08:08:52 --> Helper loaded: url_helper
INFO - 2026-01-27 08:08:52 --> Helper loaded: text_helper
INFO - 2026-01-27 08:08:52 --> Helper loaded: string_helper
INFO - 2026-01-27 08:08:52 --> Helper loaded: form_helper
INFO - 2026-01-27 08:08:52 --> Helper loaded: download_helper
INFO - 2026-01-27 08:08:52 --> Helper loaded: security_helper
INFO - 2026-01-27 08:08:52 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:08:52 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:08:52 --> Form Validation Class Initialized
INFO - 2026-01-27 08:08:52 --> Model "User_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:08:52 --> Controller Class Initialized
INFO - 2026-01-27 14:08:52 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Video_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:08:52 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:08:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-27 14:08:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:08:52 --> Model "Log_model" initialized
INFO - 2026-01-27 14:08:52 --> Final output sent to browser
DEBUG - 2026-01-27 14:08:52 --> Total execution time: 0.1702
INFO - 2026-01-27 08:08:55 --> Config Class Initialized
INFO - 2026-01-27 08:08:55 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:08:55 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:08:55 --> Utf8 Class Initialized
INFO - 2026-01-27 08:08:55 --> URI Class Initialized
DEBUG - 2026-01-27 08:08:55 --> No URI present. Default controller set.
INFO - 2026-01-27 08:08:55 --> Router Class Initialized
INFO - 2026-01-27 08:08:55 --> Output Class Initialized
INFO - 2026-01-27 08:08:55 --> Security Class Initialized
DEBUG - 2026-01-27 08:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:08:55 --> CSRF cookie sent
INFO - 2026-01-27 08:08:55 --> Input Class Initialized
INFO - 2026-01-27 08:08:55 --> Language Class Initialized
INFO - 2026-01-27 08:08:55 --> Loader Class Initialized
INFO - 2026-01-27 08:08:55 --> Helper loaded: url_helper
INFO - 2026-01-27 08:08:55 --> Helper loaded: text_helper
INFO - 2026-01-27 08:08:55 --> Helper loaded: string_helper
INFO - 2026-01-27 08:08:55 --> Helper loaded: form_helper
INFO - 2026-01-27 08:08:55 --> Helper loaded: download_helper
INFO - 2026-01-27 08:08:55 --> Helper loaded: security_helper
INFO - 2026-01-27 08:08:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:08:55 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:08:55 --> Form Validation Class Initialized
INFO - 2026-01-27 08:08:55 --> Model "User_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:08:55 --> Controller Class Initialized
INFO - 2026-01-27 14:08:55 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Video_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:08:55 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:08:55 --> Pagination Class Initialized
INFO - 2026-01-27 14:08:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:08:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:08:55 --> Model "Log_model" initialized
INFO - 2026-01-27 14:08:55 --> Final output sent to browser
DEBUG - 2026-01-27 14:08:55 --> Total execution time: 0.3499
INFO - 2026-01-27 08:09:03 --> Config Class Initialized
INFO - 2026-01-27 08:09:03 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:09:03 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:09:03 --> Utf8 Class Initialized
INFO - 2026-01-27 08:09:03 --> URI Class Initialized
DEBUG - 2026-01-27 08:09:03 --> No URI present. Default controller set.
INFO - 2026-01-27 08:09:03 --> Router Class Initialized
INFO - 2026-01-27 08:09:03 --> Output Class Initialized
INFO - 2026-01-27 08:09:03 --> Security Class Initialized
DEBUG - 2026-01-27 08:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:09:03 --> CSRF cookie sent
INFO - 2026-01-27 08:09:03 --> Input Class Initialized
INFO - 2026-01-27 08:09:03 --> Language Class Initialized
INFO - 2026-01-27 08:09:03 --> Loader Class Initialized
INFO - 2026-01-27 08:09:03 --> Helper loaded: url_helper
INFO - 2026-01-27 08:09:03 --> Helper loaded: text_helper
INFO - 2026-01-27 08:09:03 --> Helper loaded: string_helper
INFO - 2026-01-27 08:09:03 --> Helper loaded: form_helper
INFO - 2026-01-27 08:09:03 --> Helper loaded: download_helper
INFO - 2026-01-27 08:09:03 --> Helper loaded: security_helper
INFO - 2026-01-27 08:09:03 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:09:03 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:09:03 --> Form Validation Class Initialized
INFO - 2026-01-27 08:09:03 --> Model "User_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:09:03 --> Controller Class Initialized
INFO - 2026-01-27 14:09:03 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Video_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:09:03 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:09:03 --> Pagination Class Initialized
INFO - 2026-01-27 14:09:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:09:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:09:04 --> Model "Log_model" initialized
INFO - 2026-01-27 14:09:04 --> Final output sent to browser
DEBUG - 2026-01-27 14:09:04 --> Total execution time: 0.5288
INFO - 2026-01-27 08:09:17 --> Config Class Initialized
INFO - 2026-01-27 08:09:17 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:09:17 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:09:17 --> Utf8 Class Initialized
INFO - 2026-01-27 08:09:17 --> URI Class Initialized
DEBUG - 2026-01-27 08:09:17 --> No URI present. Default controller set.
INFO - 2026-01-27 08:09:17 --> Router Class Initialized
INFO - 2026-01-27 08:09:17 --> Output Class Initialized
INFO - 2026-01-27 08:09:17 --> Security Class Initialized
DEBUG - 2026-01-27 08:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:09:17 --> CSRF cookie sent
INFO - 2026-01-27 08:09:17 --> Input Class Initialized
INFO - 2026-01-27 08:09:17 --> Language Class Initialized
INFO - 2026-01-27 08:09:17 --> Loader Class Initialized
INFO - 2026-01-27 08:09:17 --> Helper loaded: url_helper
INFO - 2026-01-27 08:09:17 --> Helper loaded: text_helper
INFO - 2026-01-27 08:09:17 --> Helper loaded: string_helper
INFO - 2026-01-27 08:09:17 --> Helper loaded: form_helper
INFO - 2026-01-27 08:09:17 --> Helper loaded: download_helper
INFO - 2026-01-27 08:09:17 --> Helper loaded: security_helper
INFO - 2026-01-27 08:09:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:09:17 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:09:17 --> Form Validation Class Initialized
INFO - 2026-01-27 08:09:17 --> Model "User_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:09:17 --> Controller Class Initialized
INFO - 2026-01-27 14:09:17 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Video_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:09:17 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:09:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:09:17 --> Pagination Class Initialized
INFO - 2026-01-27 14:09:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:09:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:09:17 --> Model "Log_model" initialized
INFO - 2026-01-27 14:09:17 --> Final output sent to browser
DEBUG - 2026-01-27 14:09:17 --> Total execution time: 0.3945
INFO - 2026-01-27 08:09:19 --> Config Class Initialized
INFO - 2026-01-27 08:09:19 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:09:19 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:09:19 --> Utf8 Class Initialized
INFO - 2026-01-27 08:09:19 --> URI Class Initialized
DEBUG - 2026-01-27 08:09:19 --> No URI present. Default controller set.
INFO - 2026-01-27 08:09:19 --> Router Class Initialized
INFO - 2026-01-27 08:09:19 --> Output Class Initialized
INFO - 2026-01-27 08:09:19 --> Security Class Initialized
DEBUG - 2026-01-27 08:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:09:19 --> CSRF cookie sent
INFO - 2026-01-27 08:09:19 --> Input Class Initialized
INFO - 2026-01-27 08:09:19 --> Language Class Initialized
INFO - 2026-01-27 08:09:19 --> Loader Class Initialized
INFO - 2026-01-27 08:09:19 --> Helper loaded: url_helper
INFO - 2026-01-27 08:09:19 --> Helper loaded: text_helper
INFO - 2026-01-27 08:09:19 --> Helper loaded: string_helper
INFO - 2026-01-27 08:09:19 --> Helper loaded: form_helper
INFO - 2026-01-27 08:09:19 --> Helper loaded: download_helper
INFO - 2026-01-27 08:09:19 --> Helper loaded: security_helper
INFO - 2026-01-27 08:09:19 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:09:19 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:09:20 --> Form Validation Class Initialized
INFO - 2026-01-27 08:09:20 --> Model "User_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:09:20 --> Controller Class Initialized
INFO - 2026-01-27 14:09:20 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Video_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:09:20 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:09:20 --> Pagination Class Initialized
INFO - 2026-01-27 14:09:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:09:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:09:20 --> Model "Log_model" initialized
INFO - 2026-01-27 14:09:20 --> Final output sent to browser
DEBUG - 2026-01-27 14:09:20 --> Total execution time: 0.4032
INFO - 2026-01-27 08:09:43 --> Config Class Initialized
INFO - 2026-01-27 08:09:43 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:09:43 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:09:43 --> Utf8 Class Initialized
INFO - 2026-01-27 08:09:43 --> URI Class Initialized
DEBUG - 2026-01-27 08:09:43 --> No URI present. Default controller set.
INFO - 2026-01-27 08:09:43 --> Router Class Initialized
INFO - 2026-01-27 08:09:43 --> Output Class Initialized
INFO - 2026-01-27 08:09:43 --> Security Class Initialized
DEBUG - 2026-01-27 08:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:09:43 --> CSRF cookie sent
INFO - 2026-01-27 08:09:43 --> Input Class Initialized
INFO - 2026-01-27 08:09:43 --> Language Class Initialized
INFO - 2026-01-27 08:09:43 --> Loader Class Initialized
INFO - 2026-01-27 08:09:43 --> Helper loaded: url_helper
INFO - 2026-01-27 08:09:43 --> Helper loaded: text_helper
INFO - 2026-01-27 08:09:43 --> Helper loaded: string_helper
INFO - 2026-01-27 08:09:43 --> Helper loaded: form_helper
INFO - 2026-01-27 08:09:43 --> Helper loaded: download_helper
INFO - 2026-01-27 08:09:43 --> Helper loaded: security_helper
INFO - 2026-01-27 08:09:43 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:09:43 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:09:43 --> Form Validation Class Initialized
INFO - 2026-01-27 08:09:43 --> Model "User_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:09:43 --> Controller Class Initialized
INFO - 2026-01-27 14:09:43 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Video_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:09:43 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:09:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:09:43 --> Pagination Class Initialized
INFO - 2026-01-27 14:09:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:09:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:09:43 --> Model "Log_model" initialized
INFO - 2026-01-27 14:09:43 --> Final output sent to browser
DEBUG - 2026-01-27 14:09:43 --> Total execution time: 0.3860
INFO - 2026-01-27 08:09:56 --> Config Class Initialized
INFO - 2026-01-27 08:09:56 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:09:56 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:09:56 --> Utf8 Class Initialized
INFO - 2026-01-27 08:09:56 --> URI Class Initialized
DEBUG - 2026-01-27 08:09:56 --> No URI present. Default controller set.
INFO - 2026-01-27 08:09:56 --> Router Class Initialized
INFO - 2026-01-27 08:09:56 --> Output Class Initialized
INFO - 2026-01-27 08:09:56 --> Security Class Initialized
DEBUG - 2026-01-27 08:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:09:56 --> CSRF cookie sent
INFO - 2026-01-27 08:09:56 --> Input Class Initialized
INFO - 2026-01-27 08:09:56 --> Language Class Initialized
INFO - 2026-01-27 08:09:56 --> Loader Class Initialized
INFO - 2026-01-27 08:09:56 --> Helper loaded: url_helper
INFO - 2026-01-27 08:09:56 --> Helper loaded: text_helper
INFO - 2026-01-27 08:09:56 --> Helper loaded: string_helper
INFO - 2026-01-27 08:09:56 --> Helper loaded: form_helper
INFO - 2026-01-27 08:09:56 --> Helper loaded: download_helper
INFO - 2026-01-27 08:09:56 --> Helper loaded: security_helper
INFO - 2026-01-27 08:09:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:09:56 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:09:56 --> Form Validation Class Initialized
INFO - 2026-01-27 08:09:56 --> Model "User_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:09:56 --> Controller Class Initialized
INFO - 2026-01-27 14:09:56 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Video_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:09:56 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:09:57 --> Pagination Class Initialized
INFO - 2026-01-27 14:09:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:09:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:09:57 --> Model "Log_model" initialized
INFO - 2026-01-27 14:09:57 --> Final output sent to browser
DEBUG - 2026-01-27 14:09:57 --> Total execution time: 0.3107
INFO - 2026-01-27 08:09:59 --> Config Class Initialized
INFO - 2026-01-27 08:09:59 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:09:59 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:09:59 --> Utf8 Class Initialized
INFO - 2026-01-27 08:09:59 --> URI Class Initialized
DEBUG - 2026-01-27 08:09:59 --> No URI present. Default controller set.
INFO - 2026-01-27 08:09:59 --> Router Class Initialized
INFO - 2026-01-27 08:09:59 --> Output Class Initialized
INFO - 2026-01-27 08:09:59 --> Security Class Initialized
DEBUG - 2026-01-27 08:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:09:59 --> CSRF cookie sent
INFO - 2026-01-27 08:09:59 --> Input Class Initialized
INFO - 2026-01-27 08:09:59 --> Language Class Initialized
INFO - 2026-01-27 08:09:59 --> Loader Class Initialized
INFO - 2026-01-27 08:09:59 --> Helper loaded: url_helper
INFO - 2026-01-27 08:09:59 --> Helper loaded: text_helper
INFO - 2026-01-27 08:09:59 --> Helper loaded: string_helper
INFO - 2026-01-27 08:09:59 --> Helper loaded: form_helper
INFO - 2026-01-27 08:09:59 --> Helper loaded: download_helper
INFO - 2026-01-27 08:09:59 --> Helper loaded: security_helper
INFO - 2026-01-27 08:09:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:09:59 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:09:59 --> Form Validation Class Initialized
INFO - 2026-01-27 08:09:59 --> Model "User_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:09:59 --> Controller Class Initialized
INFO - 2026-01-27 14:09:59 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Video_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:09:59 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:09:59 --> Pagination Class Initialized
INFO - 2026-01-27 14:09:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:09:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:09:59 --> Model "Log_model" initialized
INFO - 2026-01-27 14:09:59 --> Final output sent to browser
DEBUG - 2026-01-27 14:09:59 --> Total execution time: 0.4266
INFO - 2026-01-27 08:10:45 --> Config Class Initialized
INFO - 2026-01-27 08:10:45 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:10:45 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:10:45 --> Utf8 Class Initialized
INFO - 2026-01-27 08:10:45 --> URI Class Initialized
DEBUG - 2026-01-27 08:10:45 --> No URI present. Default controller set.
INFO - 2026-01-27 08:10:45 --> Router Class Initialized
INFO - 2026-01-27 08:10:45 --> Output Class Initialized
INFO - 2026-01-27 08:10:45 --> Security Class Initialized
DEBUG - 2026-01-27 08:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:10:45 --> CSRF cookie sent
INFO - 2026-01-27 08:10:45 --> Input Class Initialized
INFO - 2026-01-27 08:10:45 --> Language Class Initialized
INFO - 2026-01-27 08:10:45 --> Loader Class Initialized
INFO - 2026-01-27 08:10:45 --> Helper loaded: url_helper
INFO - 2026-01-27 08:10:45 --> Helper loaded: text_helper
INFO - 2026-01-27 08:10:45 --> Helper loaded: string_helper
INFO - 2026-01-27 08:10:45 --> Helper loaded: form_helper
INFO - 2026-01-27 08:10:45 --> Helper loaded: download_helper
INFO - 2026-01-27 08:10:45 --> Helper loaded: security_helper
INFO - 2026-01-27 08:10:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:10:45 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:10:45 --> Form Validation Class Initialized
INFO - 2026-01-27 08:10:45 --> Model "User_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:10:45 --> Controller Class Initialized
INFO - 2026-01-27 14:10:45 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Video_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:10:45 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:10:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:10:45 --> Pagination Class Initialized
INFO - 2026-01-27 14:10:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:10:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:10:45 --> Model "Log_model" initialized
INFO - 2026-01-27 14:10:45 --> Final output sent to browser
DEBUG - 2026-01-27 14:10:45 --> Total execution time: 0.3540
INFO - 2026-01-27 08:10:59 --> Config Class Initialized
INFO - 2026-01-27 08:10:59 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:10:59 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:10:59 --> Utf8 Class Initialized
INFO - 2026-01-27 08:10:59 --> URI Class Initialized
DEBUG - 2026-01-27 08:10:59 --> No URI present. Default controller set.
INFO - 2026-01-27 08:10:59 --> Router Class Initialized
INFO - 2026-01-27 08:10:59 --> Output Class Initialized
INFO - 2026-01-27 08:10:59 --> Security Class Initialized
DEBUG - 2026-01-27 08:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:10:59 --> CSRF cookie sent
INFO - 2026-01-27 08:10:59 --> Input Class Initialized
INFO - 2026-01-27 08:10:59 --> Language Class Initialized
INFO - 2026-01-27 08:10:59 --> Loader Class Initialized
INFO - 2026-01-27 08:10:59 --> Helper loaded: url_helper
INFO - 2026-01-27 08:10:59 --> Helper loaded: text_helper
INFO - 2026-01-27 08:10:59 --> Helper loaded: string_helper
INFO - 2026-01-27 08:10:59 --> Helper loaded: form_helper
INFO - 2026-01-27 08:10:59 --> Helper loaded: download_helper
INFO - 2026-01-27 08:10:59 --> Helper loaded: security_helper
INFO - 2026-01-27 08:10:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:10:59 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:10:59 --> Form Validation Class Initialized
INFO - 2026-01-27 08:10:59 --> Model "User_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:10:59 --> Controller Class Initialized
INFO - 2026-01-27 14:10:59 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Video_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:10:59 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:10:59 --> Pagination Class Initialized
INFO - 2026-01-27 14:10:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:10:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:10:59 --> Model "Log_model" initialized
INFO - 2026-01-27 14:10:59 --> Final output sent to browser
DEBUG - 2026-01-27 14:10:59 --> Total execution time: 0.3615
INFO - 2026-01-27 08:11:01 --> Config Class Initialized
INFO - 2026-01-27 08:11:01 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:11:01 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:11:01 --> Utf8 Class Initialized
INFO - 2026-01-27 08:11:01 --> URI Class Initialized
DEBUG - 2026-01-27 08:11:01 --> No URI present. Default controller set.
INFO - 2026-01-27 08:11:01 --> Router Class Initialized
INFO - 2026-01-27 08:11:01 --> Output Class Initialized
INFO - 2026-01-27 08:11:01 --> Security Class Initialized
DEBUG - 2026-01-27 08:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:11:01 --> CSRF cookie sent
INFO - 2026-01-27 08:11:02 --> Input Class Initialized
INFO - 2026-01-27 08:11:02 --> Language Class Initialized
INFO - 2026-01-27 08:11:02 --> Loader Class Initialized
INFO - 2026-01-27 08:11:02 --> Helper loaded: url_helper
INFO - 2026-01-27 08:11:02 --> Helper loaded: text_helper
INFO - 2026-01-27 08:11:02 --> Helper loaded: string_helper
INFO - 2026-01-27 08:11:02 --> Helper loaded: form_helper
INFO - 2026-01-27 08:11:02 --> Helper loaded: download_helper
INFO - 2026-01-27 08:11:02 --> Helper loaded: security_helper
INFO - 2026-01-27 08:11:02 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:11:02 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:11:02 --> Form Validation Class Initialized
INFO - 2026-01-27 08:11:02 --> Model "User_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:11:02 --> Controller Class Initialized
INFO - 2026-01-27 14:11:02 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Video_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:11:02 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:11:02 --> Pagination Class Initialized
INFO - 2026-01-27 14:11:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:11:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:11:02 --> Model "Log_model" initialized
INFO - 2026-01-27 14:11:02 --> Final output sent to browser
DEBUG - 2026-01-27 14:11:02 --> Total execution time: 0.3992
INFO - 2026-01-27 08:37:11 --> Config Class Initialized
INFO - 2026-01-27 08:37:11 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:37:11 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:37:11 --> Utf8 Class Initialized
INFO - 2026-01-27 08:37:11 --> URI Class Initialized
DEBUG - 2026-01-27 08:37:11 --> No URI present. Default controller set.
INFO - 2026-01-27 08:37:11 --> Router Class Initialized
INFO - 2026-01-27 08:37:11 --> Output Class Initialized
INFO - 2026-01-27 08:37:11 --> Security Class Initialized
DEBUG - 2026-01-27 08:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:37:11 --> CSRF cookie sent
INFO - 2026-01-27 08:37:11 --> Input Class Initialized
INFO - 2026-01-27 08:37:11 --> Language Class Initialized
INFO - 2026-01-27 08:37:11 --> Loader Class Initialized
INFO - 2026-01-27 08:37:11 --> Helper loaded: url_helper
INFO - 2026-01-27 08:37:11 --> Helper loaded: text_helper
INFO - 2026-01-27 08:37:11 --> Helper loaded: string_helper
INFO - 2026-01-27 08:37:11 --> Helper loaded: form_helper
INFO - 2026-01-27 08:37:11 --> Helper loaded: download_helper
INFO - 2026-01-27 08:37:11 --> Helper loaded: security_helper
INFO - 2026-01-27 08:37:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:37:11 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:37:11 --> Form Validation Class Initialized
INFO - 2026-01-27 08:37:11 --> Model "User_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:37:11 --> Controller Class Initialized
INFO - 2026-01-27 14:37:11 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Video_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:37:11 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:37:11 --> Pagination Class Initialized
INFO - 2026-01-27 14:37:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:37:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:37:11 --> Model "Log_model" initialized
INFO - 2026-01-27 14:37:11 --> Final output sent to browser
DEBUG - 2026-01-27 14:37:11 --> Total execution time: 0.3109
INFO - 2026-01-27 08:37:27 --> Config Class Initialized
INFO - 2026-01-27 08:37:27 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:37:27 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:37:27 --> Utf8 Class Initialized
INFO - 2026-01-27 08:37:27 --> URI Class Initialized
DEBUG - 2026-01-27 08:37:27 --> No URI present. Default controller set.
INFO - 2026-01-27 08:37:27 --> Router Class Initialized
INFO - 2026-01-27 08:37:27 --> Output Class Initialized
INFO - 2026-01-27 08:37:27 --> Security Class Initialized
DEBUG - 2026-01-27 08:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:37:27 --> CSRF cookie sent
INFO - 2026-01-27 08:37:27 --> Input Class Initialized
INFO - 2026-01-27 08:37:27 --> Language Class Initialized
INFO - 2026-01-27 08:37:27 --> Loader Class Initialized
INFO - 2026-01-27 08:37:27 --> Helper loaded: url_helper
INFO - 2026-01-27 08:37:27 --> Helper loaded: text_helper
INFO - 2026-01-27 08:37:27 --> Helper loaded: string_helper
INFO - 2026-01-27 08:37:27 --> Helper loaded: form_helper
INFO - 2026-01-27 08:37:27 --> Helper loaded: download_helper
INFO - 2026-01-27 08:37:27 --> Helper loaded: security_helper
INFO - 2026-01-27 08:37:27 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:37:27 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:37:27 --> Form Validation Class Initialized
INFO - 2026-01-27 08:37:27 --> Model "User_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:37:27 --> Controller Class Initialized
INFO - 2026-01-27 14:37:27 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Video_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:37:27 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:37:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:37:28 --> Pagination Class Initialized
INFO - 2026-01-27 14:37:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:37:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:37:28 --> Model "Log_model" initialized
INFO - 2026-01-27 14:37:28 --> Final output sent to browser
DEBUG - 2026-01-27 14:37:28 --> Total execution time: 0.2723
INFO - 2026-01-27 08:37:56 --> Config Class Initialized
INFO - 2026-01-27 08:37:56 --> Hooks Class Initialized
DEBUG - 2026-01-27 08:37:56 --> UTF-8 Support Enabled
INFO - 2026-01-27 08:37:56 --> Utf8 Class Initialized
INFO - 2026-01-27 08:37:56 --> URI Class Initialized
DEBUG - 2026-01-27 08:37:56 --> No URI present. Default controller set.
INFO - 2026-01-27 08:37:56 --> Router Class Initialized
INFO - 2026-01-27 08:37:56 --> Output Class Initialized
INFO - 2026-01-27 08:37:56 --> Security Class Initialized
DEBUG - 2026-01-27 08:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-27 08:37:56 --> CSRF cookie sent
INFO - 2026-01-27 08:37:56 --> Input Class Initialized
INFO - 2026-01-27 08:37:56 --> Language Class Initialized
INFO - 2026-01-27 08:37:56 --> Loader Class Initialized
INFO - 2026-01-27 08:37:56 --> Helper loaded: url_helper
INFO - 2026-01-27 08:37:56 --> Helper loaded: text_helper
INFO - 2026-01-27 08:37:56 --> Helper loaded: string_helper
INFO - 2026-01-27 08:37:56 --> Helper loaded: form_helper
INFO - 2026-01-27 08:37:56 --> Helper loaded: download_helper
INFO - 2026-01-27 08:37:56 --> Helper loaded: security_helper
INFO - 2026-01-27 08:37:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-27 08:37:56 --> Database Driver Class Initialized
DEBUG - 2026-01-27 08:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-27 08:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-27 08:37:56 --> Form Validation Class Initialized
INFO - 2026-01-27 08:37:56 --> Model "User_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Nav_model" initialized
INFO - 2026-01-27 14:37:56 --> Controller Class Initialized
INFO - 2026-01-27 14:37:56 --> Model "Berita_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Galeri_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Video_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Agenda_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Tautan_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Mitra_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Jurusan_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Prodi_model" initialized
INFO - 2026-01-27 14:37:56 --> Model "Testimoni_model" initialized
INFO - 2026-01-27 14:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-27 14:37:57 --> Pagination Class Initialized
INFO - 2026-01-27 14:37:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-27 14:37:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-27 14:37:57 --> Model "Log_model" initialized
INFO - 2026-01-27 14:37:57 --> Final output sent to browser
DEBUG - 2026-01-27 14:37:57 --> Total execution time: 0.2479
