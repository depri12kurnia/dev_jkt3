<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-03 09:59:47 --> Config Class Initialized
INFO - 2025-10-03 09:59:47 --> Hooks Class Initialized
DEBUG - 2025-10-03 09:59:48 --> UTF-8 Support Enabled
INFO - 2025-10-03 09:59:48 --> Utf8 Class Initialized
INFO - 2025-10-03 09:59:48 --> URI Class Initialized
DEBUG - 2025-10-03 09:59:48 --> No URI present. Default controller set.
INFO - 2025-10-03 09:59:48 --> Router Class Initialized
INFO - 2025-10-03 09:59:48 --> Output Class Initialized
INFO - 2025-10-03 09:59:48 --> Security Class Initialized
DEBUG - 2025-10-03 09:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-03 09:59:48 --> CSRF cookie sent
INFO - 2025-10-03 09:59:48 --> Input Class Initialized
INFO - 2025-10-03 09:59:48 --> Language Class Initialized
INFO - 2025-10-03 09:59:48 --> Loader Class Initialized
INFO - 2025-10-03 09:59:49 --> Helper loaded: url_helper
INFO - 2025-10-03 09:59:49 --> Helper loaded: text_helper
INFO - 2025-10-03 09:59:49 --> Helper loaded: string_helper
INFO - 2025-10-03 09:59:49 --> Helper loaded: form_helper
INFO - 2025-10-03 09:59:49 --> Helper loaded: download_helper
INFO - 2025-10-03 09:59:49 --> Helper loaded: security_helper
INFO - 2025-10-03 09:59:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-03 09:59:49 --> Database Driver Class Initialized
DEBUG - 2025-10-03 09:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-03 09:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-03 09:59:50 --> Form Validation Class Initialized
INFO - 2025-10-03 09:59:50 --> Model "User_model" initialized
INFO - 2025-10-03 14:59:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-03 14:59:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-03 14:59:50 --> Model "Nav_model" initialized
INFO - 2025-10-03 14:59:50 --> Controller Class Initialized
INFO - 2025-10-03 14:59:50 --> Model "Berita_model" initialized
INFO - 2025-10-03 14:59:50 --> Model "Galeri_model" initialized
INFO - 2025-10-03 14:59:50 --> Model "Video_model" initialized
INFO - 2025-10-03 14:59:50 --> Model "Agenda_model" initialized
INFO - 2025-10-03 14:59:51 --> Model "Tautan_model" initialized
INFO - 2025-10-03 14:59:51 --> Model "Mitra_model" initialized
INFO - 2025-10-03 14:59:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-03 14:59:51 --> Model "Prodi_model" initialized
INFO - 2025-10-03 14:59:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-03 14:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-03 14:59:51 --> Pagination Class Initialized
INFO - 2025-10-03 14:59:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-03 14:59:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-03 14:59:54 --> Model "Log_model" initialized
INFO - 2025-10-03 14:59:54 --> Final output sent to browser
DEBUG - 2025-10-03 14:59:54 --> Total execution time: 6.8242
INFO - 2025-10-03 10:01:21 --> Config Class Initialized
INFO - 2025-10-03 10:01:21 --> Hooks Class Initialized
DEBUG - 2025-10-03 10:01:21 --> UTF-8 Support Enabled
INFO - 2025-10-03 10:01:21 --> Utf8 Class Initialized
INFO - 2025-10-03 10:01:21 --> URI Class Initialized
DEBUG - 2025-10-03 10:01:21 --> No URI present. Default controller set.
INFO - 2025-10-03 10:01:21 --> Router Class Initialized
INFO - 2025-10-03 10:01:21 --> Output Class Initialized
INFO - 2025-10-03 10:01:21 --> Security Class Initialized
DEBUG - 2025-10-03 10:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-03 10:01:21 --> CSRF cookie sent
INFO - 2025-10-03 10:01:21 --> Input Class Initialized
INFO - 2025-10-03 10:01:21 --> Language Class Initialized
INFO - 2025-10-03 10:01:21 --> Loader Class Initialized
INFO - 2025-10-03 10:01:21 --> Helper loaded: url_helper
INFO - 2025-10-03 10:01:21 --> Helper loaded: text_helper
INFO - 2025-10-03 10:01:21 --> Helper loaded: string_helper
INFO - 2025-10-03 10:01:21 --> Helper loaded: form_helper
INFO - 2025-10-03 10:01:21 --> Helper loaded: download_helper
INFO - 2025-10-03 10:01:21 --> Helper loaded: security_helper
INFO - 2025-10-03 10:01:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-03 10:01:21 --> Database Driver Class Initialized
DEBUG - 2025-10-03 10:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-03 10:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-03 10:01:21 --> Form Validation Class Initialized
INFO - 2025-10-03 10:01:21 --> Model "User_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Kunjungan_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Nav_model" initialized
INFO - 2025-10-03 15:01:21 --> Controller Class Initialized
INFO - 2025-10-03 15:01:21 --> Model "Berita_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Galeri_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Video_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Agenda_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Tautan_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Mitra_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Jurusan_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Prodi_model" initialized
INFO - 2025-10-03 15:01:21 --> Model "Testimoni_model" initialized
INFO - 2025-10-03 15:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-03 15:01:21 --> Pagination Class Initialized
INFO - 2025-10-03 15:01:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-03 15:01:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-03 15:01:21 --> Model "Log_model" initialized
INFO - 2025-10-03 15:01:21 --> Final output sent to browser
DEBUG - 2025-10-03 15:01:21 --> Total execution time: 0.0845
INFO - 2025-10-03 10:04:10 --> Config Class Initialized
INFO - 2025-10-03 10:04:10 --> Hooks Class Initialized
DEBUG - 2025-10-03 10:04:10 --> UTF-8 Support Enabled
INFO - 2025-10-03 10:04:10 --> Utf8 Class Initialized
INFO - 2025-10-03 10:04:10 --> URI Class Initialized
INFO - 2025-10-03 10:04:10 --> Router Class Initialized
INFO - 2025-10-03 10:04:10 --> Output Class Initialized
INFO - 2025-10-03 10:04:10 --> Security Class Initialized
DEBUG - 2025-10-03 10:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-03 10:04:10 --> CSRF cookie sent
INFO - 2025-10-03 10:04:10 --> Input Class Initialized
INFO - 2025-10-03 10:04:10 --> Language Class Initialized
INFO - 2025-10-03 10:04:10 --> Loader Class Initialized
INFO - 2025-10-03 10:04:10 --> Helper loaded: url_helper
INFO - 2025-10-03 10:04:10 --> Helper loaded: text_helper
INFO - 2025-10-03 10:04:10 --> Helper loaded: string_helper
INFO - 2025-10-03 10:04:10 --> Helper loaded: form_helper
INFO - 2025-10-03 10:04:10 --> Helper loaded: download_helper
INFO - 2025-10-03 10:04:10 --> Helper loaded: security_helper
INFO - 2025-10-03 10:04:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-03 10:04:10 --> Database Driver Class Initialized
DEBUG - 2025-10-03 10:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-03 10:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-03 10:04:10 --> Form Validation Class Initialized
INFO - 2025-10-03 10:04:10 --> Model "User_model" initialized
INFO - 2025-10-03 15:04:10 --> Model "Kunjungan_model" initialized
INFO - 2025-10-03 15:04:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-03 15:04:10 --> Model "Nav_model" initialized
INFO - 2025-10-03 15:04:10 --> Controller Class Initialized
INFO - 2025-10-03 15:04:10 --> Model "Sdm_model" initialized
INFO - 2025-10-03 15:04:10 --> Model "Jabatansdm_model" initialized
INFO - 2025-10-03 15:04:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-10-03 15:04:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-03 15:04:11 --> Model "Log_model" initialized
INFO - 2025-10-03 15:04:11 --> Final output sent to browser
DEBUG - 2025-10-03 15:04:11 --> Total execution time: 0.2916
INFO - 2025-10-03 10:04:29 --> Config Class Initialized
INFO - 2025-10-03 10:04:29 --> Hooks Class Initialized
DEBUG - 2025-10-03 10:04:29 --> UTF-8 Support Enabled
INFO - 2025-10-03 10:04:29 --> Utf8 Class Initialized
INFO - 2025-10-03 10:04:29 --> URI Class Initialized
INFO - 2025-10-03 10:04:29 --> Router Class Initialized
INFO - 2025-10-03 10:04:29 --> Output Class Initialized
INFO - 2025-10-03 10:04:29 --> Security Class Initialized
DEBUG - 2025-10-03 10:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-03 10:04:29 --> CSRF cookie sent
INFO - 2025-10-03 10:04:29 --> Input Class Initialized
INFO - 2025-10-03 10:04:29 --> Language Class Initialized
INFO - 2025-10-03 10:04:29 --> Loader Class Initialized
INFO - 2025-10-03 10:04:29 --> Helper loaded: url_helper
INFO - 2025-10-03 10:04:29 --> Helper loaded: text_helper
INFO - 2025-10-03 10:04:29 --> Helper loaded: string_helper
INFO - 2025-10-03 10:04:29 --> Helper loaded: form_helper
INFO - 2025-10-03 10:04:29 --> Helper loaded: download_helper
INFO - 2025-10-03 10:04:29 --> Helper loaded: security_helper
INFO - 2025-10-03 10:04:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-03 10:04:29 --> Database Driver Class Initialized
DEBUG - 2025-10-03 10:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-03 10:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-03 10:04:29 --> Form Validation Class Initialized
INFO - 2025-10-03 10:04:29 --> Model "User_model" initialized
INFO - 2025-10-03 15:04:29 --> Model "Kunjungan_model" initialized
INFO - 2025-10-03 15:04:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-03 15:04:29 --> Model "Nav_model" initialized
INFO - 2025-10-03 15:04:29 --> Controller Class Initialized
INFO - 2025-10-03 15:04:29 --> Model "Sdm_model" initialized
INFO - 2025-10-03 15:04:29 --> Model "Jabatansdm_model" initialized
INFO - 2025-10-03 15:04:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-10-03 15:04:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-03 15:04:29 --> Model "Log_model" initialized
INFO - 2025-10-03 15:04:29 --> Final output sent to browser
DEBUG - 2025-10-03 15:04:29 --> Total execution time: 0.0679
