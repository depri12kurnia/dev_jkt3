<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-24 03:54:52 --> Config Class Initialized
INFO - 2025-11-24 03:54:52 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:54:52 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:54:52 --> Utf8 Class Initialized
INFO - 2025-11-24 03:54:52 --> URI Class Initialized
DEBUG - 2025-11-24 03:54:52 --> No URI present. Default controller set.
INFO - 2025-11-24 03:54:52 --> Router Class Initialized
INFO - 2025-11-24 03:54:52 --> Output Class Initialized
INFO - 2025-11-24 03:54:52 --> Security Class Initialized
DEBUG - 2025-11-24 03:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:54:52 --> CSRF cookie sent
INFO - 2025-11-24 03:54:52 --> Input Class Initialized
INFO - 2025-11-24 03:54:52 --> Language Class Initialized
INFO - 2025-11-24 03:54:53 --> Loader Class Initialized
INFO - 2025-11-24 03:54:53 --> Helper loaded: url_helper
INFO - 2025-11-24 03:54:53 --> Helper loaded: text_helper
INFO - 2025-11-24 03:54:53 --> Helper loaded: string_helper
INFO - 2025-11-24 03:54:53 --> Helper loaded: form_helper
INFO - 2025-11-24 03:54:53 --> Helper loaded: download_helper
INFO - 2025-11-24 03:54:53 --> Helper loaded: security_helper
INFO - 2025-11-24 03:54:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:54:53 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:54:53 --> Form Validation Class Initialized
INFO - 2025-11-24 03:54:53 --> Model "User_model" initialized
INFO - 2025-11-24 09:54:53 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:54:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:54:54 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:54:54 --> Controller Class Initialized
INFO - 2025-11-24 09:54:54 --> Model "Berita_model" initialized
INFO - 2025-11-24 09:54:54 --> Model "Galeri_model" initialized
INFO - 2025-11-24 09:54:54 --> Model "Video_model" initialized
INFO - 2025-11-24 09:54:54 --> Model "Agenda_model" initialized
INFO - 2025-11-24 09:54:54 --> Model "Tautan_model" initialized
INFO - 2025-11-24 09:54:54 --> Model "Mitra_model" initialized
INFO - 2025-11-24 09:54:54 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 09:54:54 --> Model "Prodi_model" initialized
INFO - 2025-11-24 09:54:54 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 09:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 09:54:55 --> Pagination Class Initialized
INFO - 2025-11-24 09:54:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 09:54:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:54:58 --> Model "Log_model" initialized
INFO - 2025-11-24 09:54:58 --> Final output sent to browser
DEBUG - 2025-11-24 09:54:58 --> Total execution time: 6.4116
INFO - 2025-11-24 03:55:39 --> Config Class Initialized
INFO - 2025-11-24 03:55:39 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:55:39 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:55:39 --> Utf8 Class Initialized
INFO - 2025-11-24 03:55:39 --> URI Class Initialized
DEBUG - 2025-11-24 03:55:39 --> No URI present. Default controller set.
INFO - 2025-11-24 03:55:39 --> Router Class Initialized
INFO - 2025-11-24 03:55:39 --> Output Class Initialized
INFO - 2025-11-24 03:55:39 --> Security Class Initialized
DEBUG - 2025-11-24 03:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:55:39 --> CSRF cookie sent
INFO - 2025-11-24 03:55:39 --> Input Class Initialized
INFO - 2025-11-24 03:55:39 --> Language Class Initialized
INFO - 2025-11-24 03:55:39 --> Loader Class Initialized
INFO - 2025-11-24 03:55:39 --> Helper loaded: url_helper
INFO - 2025-11-24 03:55:39 --> Helper loaded: text_helper
INFO - 2025-11-24 03:55:39 --> Helper loaded: string_helper
INFO - 2025-11-24 03:55:39 --> Helper loaded: form_helper
INFO - 2025-11-24 03:55:39 --> Helper loaded: download_helper
INFO - 2025-11-24 03:55:39 --> Helper loaded: security_helper
INFO - 2025-11-24 03:55:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:55:39 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:55:39 --> Form Validation Class Initialized
INFO - 2025-11-24 03:55:39 --> Model "User_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:55:39 --> Controller Class Initialized
INFO - 2025-11-24 09:55:39 --> Model "Berita_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Galeri_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Video_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Agenda_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Tautan_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Mitra_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Prodi_model" initialized
INFO - 2025-11-24 09:55:39 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 09:55:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 09:55:39 --> Pagination Class Initialized
INFO - 2025-11-24 09:55:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 09:55:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:55:39 --> Model "Log_model" initialized
INFO - 2025-11-24 09:55:39 --> Final output sent to browser
DEBUG - 2025-11-24 09:55:39 --> Total execution time: 0.1840
INFO - 2025-11-24 03:56:07 --> Config Class Initialized
INFO - 2025-11-24 03:56:07 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:56:07 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:56:07 --> Utf8 Class Initialized
INFO - 2025-11-24 03:56:07 --> URI Class Initialized
DEBUG - 2025-11-24 03:56:07 --> No URI present. Default controller set.
INFO - 2025-11-24 03:56:07 --> Router Class Initialized
INFO - 2025-11-24 03:56:07 --> Output Class Initialized
INFO - 2025-11-24 03:56:07 --> Security Class Initialized
DEBUG - 2025-11-24 03:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:56:07 --> CSRF cookie sent
INFO - 2025-11-24 03:56:07 --> Input Class Initialized
INFO - 2025-11-24 03:56:07 --> Language Class Initialized
INFO - 2025-11-24 03:56:07 --> Loader Class Initialized
INFO - 2025-11-24 03:56:07 --> Helper loaded: url_helper
INFO - 2025-11-24 03:56:07 --> Helper loaded: text_helper
INFO - 2025-11-24 03:56:07 --> Helper loaded: string_helper
INFO - 2025-11-24 03:56:07 --> Helper loaded: form_helper
INFO - 2025-11-24 03:56:07 --> Helper loaded: download_helper
INFO - 2025-11-24 03:56:07 --> Helper loaded: security_helper
INFO - 2025-11-24 03:56:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:56:07 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:56:07 --> Form Validation Class Initialized
INFO - 2025-11-24 03:56:07 --> Model "User_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:56:07 --> Controller Class Initialized
INFO - 2025-11-24 09:56:07 --> Model "Berita_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Galeri_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Video_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Agenda_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Tautan_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Mitra_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Prodi_model" initialized
INFO - 2025-11-24 09:56:07 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 09:56:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 09:56:07 --> Pagination Class Initialized
INFO - 2025-11-24 09:56:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 09:56:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:56:07 --> Model "Log_model" initialized
INFO - 2025-11-24 09:56:07 --> Final output sent to browser
DEBUG - 2025-11-24 09:56:07 --> Total execution time: 0.2604
INFO - 2025-11-24 03:56:20 --> Config Class Initialized
INFO - 2025-11-24 03:56:20 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:56:20 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:56:20 --> Utf8 Class Initialized
INFO - 2025-11-24 03:56:20 --> URI Class Initialized
DEBUG - 2025-11-24 03:56:20 --> No URI present. Default controller set.
INFO - 2025-11-24 03:56:20 --> Router Class Initialized
INFO - 2025-11-24 03:56:20 --> Output Class Initialized
INFO - 2025-11-24 03:56:20 --> Security Class Initialized
DEBUG - 2025-11-24 03:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:56:20 --> CSRF cookie sent
INFO - 2025-11-24 03:56:20 --> Input Class Initialized
INFO - 2025-11-24 03:56:20 --> Language Class Initialized
INFO - 2025-11-24 03:56:20 --> Loader Class Initialized
INFO - 2025-11-24 03:56:20 --> Helper loaded: url_helper
INFO - 2025-11-24 03:56:20 --> Helper loaded: text_helper
INFO - 2025-11-24 03:56:20 --> Helper loaded: string_helper
INFO - 2025-11-24 03:56:20 --> Helper loaded: form_helper
INFO - 2025-11-24 03:56:20 --> Helper loaded: download_helper
INFO - 2025-11-24 03:56:20 --> Helper loaded: security_helper
INFO - 2025-11-24 03:56:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:56:20 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:56:20 --> Form Validation Class Initialized
INFO - 2025-11-24 03:56:20 --> Model "User_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:56:20 --> Controller Class Initialized
INFO - 2025-11-24 09:56:20 --> Model "Berita_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Galeri_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Video_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Agenda_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Tautan_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Mitra_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Prodi_model" initialized
INFO - 2025-11-24 09:56:20 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 09:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 09:56:20 --> Pagination Class Initialized
INFO - 2025-11-24 09:56:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 09:56:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:56:20 --> Model "Log_model" initialized
INFO - 2025-11-24 09:56:20 --> Final output sent to browser
DEBUG - 2025-11-24 09:56:20 --> Total execution time: 0.2613
INFO - 2025-11-24 03:56:23 --> Config Class Initialized
INFO - 2025-11-24 03:56:23 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:56:23 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:56:23 --> Utf8 Class Initialized
INFO - 2025-11-24 03:56:23 --> URI Class Initialized
DEBUG - 2025-11-24 03:56:23 --> No URI present. Default controller set.
INFO - 2025-11-24 03:56:23 --> Router Class Initialized
INFO - 2025-11-24 03:56:23 --> Output Class Initialized
INFO - 2025-11-24 03:56:23 --> Security Class Initialized
DEBUG - 2025-11-24 03:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:56:23 --> CSRF cookie sent
INFO - 2025-11-24 03:56:23 --> Input Class Initialized
INFO - 2025-11-24 03:56:23 --> Language Class Initialized
INFO - 2025-11-24 03:56:23 --> Loader Class Initialized
INFO - 2025-11-24 03:56:23 --> Helper loaded: url_helper
INFO - 2025-11-24 03:56:23 --> Helper loaded: text_helper
INFO - 2025-11-24 03:56:23 --> Helper loaded: string_helper
INFO - 2025-11-24 03:56:23 --> Helper loaded: form_helper
INFO - 2025-11-24 03:56:23 --> Helper loaded: download_helper
INFO - 2025-11-24 03:56:23 --> Helper loaded: security_helper
INFO - 2025-11-24 03:56:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:56:23 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:56:23 --> Form Validation Class Initialized
INFO - 2025-11-24 03:56:23 --> Model "User_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:56:23 --> Controller Class Initialized
INFO - 2025-11-24 09:56:23 --> Model "Berita_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Galeri_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Video_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Agenda_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Tautan_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Mitra_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Prodi_model" initialized
INFO - 2025-11-24 09:56:23 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 09:56:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 09:56:23 --> Pagination Class Initialized
INFO - 2025-11-24 09:56:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 09:56:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:56:23 --> Model "Log_model" initialized
INFO - 2025-11-24 09:56:23 --> Final output sent to browser
DEBUG - 2025-11-24 09:56:23 --> Total execution time: 0.2341
INFO - 2025-11-24 03:58:55 --> Config Class Initialized
INFO - 2025-11-24 03:58:55 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:58:55 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:58:55 --> Utf8 Class Initialized
INFO - 2025-11-24 03:58:55 --> URI Class Initialized
DEBUG - 2025-11-24 03:58:55 --> No URI present. Default controller set.
INFO - 2025-11-24 03:58:55 --> Router Class Initialized
INFO - 2025-11-24 03:58:55 --> Output Class Initialized
INFO - 2025-11-24 03:58:55 --> Security Class Initialized
DEBUG - 2025-11-24 03:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:58:55 --> CSRF cookie sent
INFO - 2025-11-24 03:58:55 --> Input Class Initialized
INFO - 2025-11-24 03:58:55 --> Language Class Initialized
INFO - 2025-11-24 03:58:55 --> Loader Class Initialized
INFO - 2025-11-24 03:58:55 --> Helper loaded: url_helper
INFO - 2025-11-24 03:58:55 --> Helper loaded: text_helper
INFO - 2025-11-24 03:58:55 --> Helper loaded: string_helper
INFO - 2025-11-24 03:58:55 --> Helper loaded: form_helper
INFO - 2025-11-24 03:58:55 --> Helper loaded: download_helper
INFO - 2025-11-24 03:58:55 --> Helper loaded: security_helper
INFO - 2025-11-24 03:58:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:58:55 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:58:55 --> Form Validation Class Initialized
INFO - 2025-11-24 03:58:55 --> Model "User_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:58:55 --> Controller Class Initialized
INFO - 2025-11-24 09:58:55 --> Model "Berita_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Galeri_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Video_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Agenda_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Tautan_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Mitra_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Prodi_model" initialized
INFO - 2025-11-24 09:58:55 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 09:58:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 09:58:55 --> Pagination Class Initialized
INFO - 2025-11-24 09:58:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 09:58:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:58:55 --> Model "Log_model" initialized
INFO - 2025-11-24 09:58:55 --> Final output sent to browser
DEBUG - 2025-11-24 09:58:55 --> Total execution time: 0.1895
INFO - 2025-11-24 03:59:08 --> Config Class Initialized
INFO - 2025-11-24 03:59:08 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:59:08 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:59:08 --> Utf8 Class Initialized
INFO - 2025-11-24 03:59:08 --> URI Class Initialized
DEBUG - 2025-11-24 03:59:08 --> No URI present. Default controller set.
INFO - 2025-11-24 03:59:08 --> Router Class Initialized
INFO - 2025-11-24 03:59:08 --> Output Class Initialized
INFO - 2025-11-24 03:59:08 --> Security Class Initialized
DEBUG - 2025-11-24 03:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:59:08 --> CSRF cookie sent
INFO - 2025-11-24 03:59:08 --> Input Class Initialized
INFO - 2025-11-24 03:59:08 --> Language Class Initialized
INFO - 2025-11-24 03:59:08 --> Loader Class Initialized
INFO - 2025-11-24 03:59:08 --> Helper loaded: url_helper
INFO - 2025-11-24 03:59:08 --> Helper loaded: text_helper
INFO - 2025-11-24 03:59:08 --> Helper loaded: string_helper
INFO - 2025-11-24 03:59:08 --> Helper loaded: form_helper
INFO - 2025-11-24 03:59:08 --> Helper loaded: download_helper
INFO - 2025-11-24 03:59:08 --> Helper loaded: security_helper
INFO - 2025-11-24 03:59:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:59:08 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:59:08 --> Form Validation Class Initialized
INFO - 2025-11-24 03:59:08 --> Model "User_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:59:08 --> Controller Class Initialized
INFO - 2025-11-24 09:59:08 --> Model "Berita_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Galeri_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Video_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Agenda_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Tautan_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Mitra_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Prodi_model" initialized
INFO - 2025-11-24 09:59:08 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 09:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 09:59:08 --> Pagination Class Initialized
INFO - 2025-11-24 09:59:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 09:59:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:59:08 --> Model "Log_model" initialized
INFO - 2025-11-24 09:59:08 --> Final output sent to browser
DEBUG - 2025-11-24 09:59:08 --> Total execution time: 0.2127
INFO - 2025-11-24 03:59:10 --> Config Class Initialized
INFO - 2025-11-24 03:59:10 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:59:10 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:59:10 --> Utf8 Class Initialized
INFO - 2025-11-24 03:59:10 --> URI Class Initialized
DEBUG - 2025-11-24 03:59:10 --> No URI present. Default controller set.
INFO - 2025-11-24 03:59:10 --> Router Class Initialized
INFO - 2025-11-24 03:59:10 --> Output Class Initialized
INFO - 2025-11-24 03:59:10 --> Security Class Initialized
DEBUG - 2025-11-24 03:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:59:10 --> CSRF cookie sent
INFO - 2025-11-24 03:59:10 --> Input Class Initialized
INFO - 2025-11-24 03:59:10 --> Language Class Initialized
INFO - 2025-11-24 03:59:10 --> Loader Class Initialized
INFO - 2025-11-24 03:59:10 --> Helper loaded: url_helper
INFO - 2025-11-24 03:59:10 --> Helper loaded: text_helper
INFO - 2025-11-24 03:59:10 --> Helper loaded: string_helper
INFO - 2025-11-24 03:59:10 --> Helper loaded: form_helper
INFO - 2025-11-24 03:59:10 --> Helper loaded: download_helper
INFO - 2025-11-24 03:59:10 --> Helper loaded: security_helper
INFO - 2025-11-24 03:59:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:59:10 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:59:10 --> Form Validation Class Initialized
INFO - 2025-11-24 03:59:10 --> Model "User_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:59:10 --> Controller Class Initialized
INFO - 2025-11-24 09:59:10 --> Model "Berita_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Galeri_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Video_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Agenda_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Tautan_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Mitra_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Prodi_model" initialized
INFO - 2025-11-24 09:59:10 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 09:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 09:59:11 --> Pagination Class Initialized
INFO - 2025-11-24 09:59:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 09:59:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:59:11 --> Model "Log_model" initialized
INFO - 2025-11-24 09:59:11 --> Final output sent to browser
DEBUG - 2025-11-24 09:59:11 --> Total execution time: 0.2158
INFO - 2025-11-24 03:59:20 --> Config Class Initialized
INFO - 2025-11-24 03:59:20 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:59:20 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:59:20 --> Utf8 Class Initialized
INFO - 2025-11-24 03:59:20 --> URI Class Initialized
DEBUG - 2025-11-24 03:59:20 --> No URI present. Default controller set.
INFO - 2025-11-24 03:59:20 --> Router Class Initialized
INFO - 2025-11-24 03:59:20 --> Output Class Initialized
INFO - 2025-11-24 03:59:20 --> Security Class Initialized
DEBUG - 2025-11-24 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:59:20 --> CSRF cookie sent
INFO - 2025-11-24 03:59:20 --> Input Class Initialized
INFO - 2025-11-24 03:59:20 --> Language Class Initialized
INFO - 2025-11-24 03:59:20 --> Loader Class Initialized
INFO - 2025-11-24 03:59:20 --> Helper loaded: url_helper
INFO - 2025-11-24 03:59:20 --> Helper loaded: text_helper
INFO - 2025-11-24 03:59:20 --> Helper loaded: string_helper
INFO - 2025-11-24 03:59:20 --> Helper loaded: form_helper
INFO - 2025-11-24 03:59:20 --> Helper loaded: download_helper
INFO - 2025-11-24 03:59:20 --> Helper loaded: security_helper
INFO - 2025-11-24 03:59:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:59:20 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:59:20 --> Form Validation Class Initialized
INFO - 2025-11-24 03:59:20 --> Model "User_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:59:20 --> Controller Class Initialized
INFO - 2025-11-24 09:59:20 --> Model "Berita_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Galeri_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Video_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Agenda_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Tautan_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Mitra_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Prodi_model" initialized
INFO - 2025-11-24 09:59:20 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 09:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 09:59:20 --> Pagination Class Initialized
INFO - 2025-11-24 09:59:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 09:59:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:59:20 --> Model "Log_model" initialized
INFO - 2025-11-24 09:59:20 --> Final output sent to browser
DEBUG - 2025-11-24 09:59:21 --> Total execution time: 0.2698
INFO - 2025-11-24 03:59:38 --> Config Class Initialized
INFO - 2025-11-24 03:59:38 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:59:38 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:59:38 --> Utf8 Class Initialized
INFO - 2025-11-24 03:59:38 --> URI Class Initialized
INFO - 2025-11-24 03:59:38 --> Router Class Initialized
INFO - 2025-11-24 03:59:38 --> Output Class Initialized
INFO - 2025-11-24 03:59:38 --> Security Class Initialized
DEBUG - 2025-11-24 03:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:59:38 --> CSRF cookie sent
INFO - 2025-11-24 03:59:38 --> Input Class Initialized
INFO - 2025-11-24 03:59:38 --> Language Class Initialized
INFO - 2025-11-24 03:59:38 --> Loader Class Initialized
INFO - 2025-11-24 03:59:38 --> Helper loaded: url_helper
INFO - 2025-11-24 03:59:38 --> Helper loaded: text_helper
INFO - 2025-11-24 03:59:38 --> Helper loaded: string_helper
INFO - 2025-11-24 03:59:38 --> Helper loaded: form_helper
INFO - 2025-11-24 03:59:38 --> Helper loaded: download_helper
INFO - 2025-11-24 03:59:38 --> Helper loaded: security_helper
INFO - 2025-11-24 03:59:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:59:38 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:59:38 --> Form Validation Class Initialized
INFO - 2025-11-24 03:59:38 --> Model "User_model" initialized
INFO - 2025-11-24 09:59:38 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:59:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:59:38 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:59:38 --> Controller Class Initialized
INFO - 2025-11-24 09:59:38 --> Model "Pages_model" initialized
INFO - 2025-11-24 09:59:38 --> Model "Berita_model" initialized
INFO - 2025-11-24 09:59:38 --> Model "Download_model" initialized
INFO - 2025-11-24 09:59:38 --> Model "Kategori_download_model" initialized
INFO - 2025-11-24 09:59:38 --> Model "Jenis_download_model" initialized
INFO - 2025-11-24 09:59:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-11-24 09:59:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:59:38 --> Model "Log_model" initialized
INFO - 2025-11-24 09:59:38 --> Final output sent to browser
DEBUG - 2025-11-24 09:59:38 --> Total execution time: 0.6365
INFO - 2025-11-24 03:59:45 --> Config Class Initialized
INFO - 2025-11-24 03:59:45 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:59:45 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:59:45 --> Utf8 Class Initialized
INFO - 2025-11-24 03:59:45 --> URI Class Initialized
INFO - 2025-11-24 03:59:45 --> Router Class Initialized
INFO - 2025-11-24 03:59:45 --> Output Class Initialized
INFO - 2025-11-24 03:59:45 --> Security Class Initialized
DEBUG - 2025-11-24 03:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:59:45 --> CSRF cookie sent
INFO - 2025-11-24 03:59:45 --> Input Class Initialized
INFO - 2025-11-24 03:59:45 --> Language Class Initialized
INFO - 2025-11-24 03:59:46 --> Loader Class Initialized
INFO - 2025-11-24 03:59:46 --> Helper loaded: url_helper
INFO - 2025-11-24 03:59:46 --> Helper loaded: text_helper
INFO - 2025-11-24 03:59:46 --> Helper loaded: string_helper
INFO - 2025-11-24 03:59:46 --> Helper loaded: form_helper
INFO - 2025-11-24 03:59:46 --> Helper loaded: download_helper
INFO - 2025-11-24 03:59:46 --> Helper loaded: security_helper
INFO - 2025-11-24 03:59:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:59:46 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:59:46 --> Form Validation Class Initialized
INFO - 2025-11-24 03:59:46 --> Model "User_model" initialized
INFO - 2025-11-24 09:59:46 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:59:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:59:46 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:59:46 --> Controller Class Initialized
INFO - 2025-11-24 09:59:46 --> Model "Sdm_model" initialized
INFO - 2025-11-24 09:59:46 --> Model "Jabatansdm_model" initialized
INFO - 2025-11-24 09:59:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-11-24 09:59:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:59:46 --> Model "Log_model" initialized
INFO - 2025-11-24 09:59:46 --> Final output sent to browser
DEBUG - 2025-11-24 09:59:46 --> Total execution time: 0.5107
INFO - 2025-11-24 03:59:58 --> Config Class Initialized
INFO - 2025-11-24 03:59:58 --> Hooks Class Initialized
DEBUG - 2025-11-24 03:59:58 --> UTF-8 Support Enabled
INFO - 2025-11-24 03:59:58 --> Utf8 Class Initialized
INFO - 2025-11-24 03:59:58 --> URI Class Initialized
INFO - 2025-11-24 03:59:58 --> Router Class Initialized
INFO - 2025-11-24 03:59:58 --> Output Class Initialized
INFO - 2025-11-24 03:59:58 --> Security Class Initialized
DEBUG - 2025-11-24 03:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 03:59:58 --> CSRF cookie sent
INFO - 2025-11-24 03:59:58 --> Input Class Initialized
INFO - 2025-11-24 03:59:58 --> Language Class Initialized
INFO - 2025-11-24 03:59:58 --> Loader Class Initialized
INFO - 2025-11-24 03:59:58 --> Helper loaded: url_helper
INFO - 2025-11-24 03:59:58 --> Helper loaded: text_helper
INFO - 2025-11-24 03:59:58 --> Helper loaded: string_helper
INFO - 2025-11-24 03:59:58 --> Helper loaded: form_helper
INFO - 2025-11-24 03:59:58 --> Helper loaded: download_helper
INFO - 2025-11-24 03:59:58 --> Helper loaded: security_helper
INFO - 2025-11-24 03:59:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 03:59:58 --> Database Driver Class Initialized
DEBUG - 2025-11-24 03:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 03:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 03:59:59 --> Form Validation Class Initialized
INFO - 2025-11-24 03:59:59 --> Model "User_model" initialized
INFO - 2025-11-24 09:59:59 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 09:59:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 09:59:59 --> Model "Nav_model" initialized
INFO - 2025-11-24 09:59:59 --> Controller Class Initialized
INFO - 2025-11-24 09:59:59 --> Model "Sdm_model" initialized
INFO - 2025-11-24 09:59:59 --> Model "Jabatansdm_model" initialized
INFO - 2025-11-24 09:59:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2025-11-24 09:59:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 09:59:59 --> Model "Log_model" initialized
INFO - 2025-11-24 09:59:59 --> Final output sent to browser
DEBUG - 2025-11-24 09:59:59 --> Total execution time: 0.2989
INFO - 2025-11-24 04:00:05 --> Config Class Initialized
INFO - 2025-11-24 04:00:05 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:00:05 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:00:05 --> Utf8 Class Initialized
INFO - 2025-11-24 04:00:05 --> URI Class Initialized
INFO - 2025-11-24 04:00:05 --> Router Class Initialized
INFO - 2025-11-24 04:00:05 --> Output Class Initialized
INFO - 2025-11-24 04:00:05 --> Security Class Initialized
DEBUG - 2025-11-24 04:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:00:05 --> CSRF cookie sent
INFO - 2025-11-24 04:00:05 --> Input Class Initialized
INFO - 2025-11-24 04:00:05 --> Language Class Initialized
INFO - 2025-11-24 04:00:05 --> Loader Class Initialized
INFO - 2025-11-24 04:00:05 --> Helper loaded: url_helper
INFO - 2025-11-24 04:00:05 --> Helper loaded: text_helper
INFO - 2025-11-24 04:00:05 --> Helper loaded: string_helper
INFO - 2025-11-24 04:00:05 --> Helper loaded: form_helper
INFO - 2025-11-24 04:00:05 --> Helper loaded: download_helper
INFO - 2025-11-24 04:00:05 --> Helper loaded: security_helper
INFO - 2025-11-24 04:00:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:00:05 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:00:05 --> Form Validation Class Initialized
INFO - 2025-11-24 04:00:05 --> Model "User_model" initialized
INFO - 2025-11-24 10:00:05 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:00:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:00:05 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:00:05 --> Controller Class Initialized
INFO - 2025-11-24 10:00:05 --> Model "Sdm_model" initialized
INFO - 2025-11-24 10:00:05 --> Model "Jabatansdm_model" initialized
INFO - 2025-11-24 10:00:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-11-24 10:00:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:00:05 --> Model "Log_model" initialized
INFO - 2025-11-24 10:00:05 --> Final output sent to browser
DEBUG - 2025-11-24 10:00:05 --> Total execution time: 0.2193
INFO - 2025-11-24 04:00:07 --> Config Class Initialized
INFO - 2025-11-24 04:00:07 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:00:07 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:00:07 --> Utf8 Class Initialized
INFO - 2025-11-24 04:00:07 --> URI Class Initialized
INFO - 2025-11-24 04:00:07 --> Router Class Initialized
INFO - 2025-11-24 04:00:07 --> Output Class Initialized
INFO - 2025-11-24 04:00:07 --> Security Class Initialized
DEBUG - 2025-11-24 04:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:00:07 --> CSRF cookie sent
INFO - 2025-11-24 04:00:07 --> Input Class Initialized
INFO - 2025-11-24 04:00:07 --> Language Class Initialized
INFO - 2025-11-24 04:00:07 --> Loader Class Initialized
INFO - 2025-11-24 04:00:07 --> Helper loaded: url_helper
INFO - 2025-11-24 04:00:07 --> Helper loaded: text_helper
INFO - 2025-11-24 04:00:07 --> Helper loaded: string_helper
INFO - 2025-11-24 04:00:07 --> Helper loaded: form_helper
INFO - 2025-11-24 04:00:07 --> Helper loaded: download_helper
INFO - 2025-11-24 04:00:07 --> Helper loaded: security_helper
INFO - 2025-11-24 04:00:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:00:07 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:00:07 --> Form Validation Class Initialized
INFO - 2025-11-24 04:00:07 --> Model "User_model" initialized
INFO - 2025-11-24 10:00:07 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:00:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:00:07 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:00:07 --> Controller Class Initialized
INFO - 2025-11-24 10:00:07 --> Model "Sdm_model" initialized
INFO - 2025-11-24 10:00:07 --> Model "Jabatansdm_model" initialized
INFO - 2025-11-24 10:00:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2025-11-24 10:00:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:00:07 --> Model "Log_model" initialized
INFO - 2025-11-24 10:00:07 --> Final output sent to browser
DEBUG - 2025-11-24 10:00:07 --> Total execution time: 0.1820
INFO - 2025-11-24 04:00:22 --> Config Class Initialized
INFO - 2025-11-24 04:00:22 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:00:22 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:00:22 --> Utf8 Class Initialized
INFO - 2025-11-24 04:00:22 --> URI Class Initialized
INFO - 2025-11-24 04:00:22 --> Router Class Initialized
INFO - 2025-11-24 04:00:22 --> Output Class Initialized
INFO - 2025-11-24 04:00:22 --> Security Class Initialized
DEBUG - 2025-11-24 04:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:00:23 --> CSRF cookie sent
INFO - 2025-11-24 04:00:23 --> Input Class Initialized
INFO - 2025-11-24 04:00:23 --> Language Class Initialized
INFO - 2025-11-24 04:00:23 --> Loader Class Initialized
INFO - 2025-11-24 04:00:23 --> Helper loaded: url_helper
INFO - 2025-11-24 04:00:23 --> Helper loaded: text_helper
INFO - 2025-11-24 04:00:23 --> Helper loaded: string_helper
INFO - 2025-11-24 04:00:23 --> Helper loaded: form_helper
INFO - 2025-11-24 04:00:23 --> Helper loaded: download_helper
INFO - 2025-11-24 04:00:23 --> Helper loaded: security_helper
INFO - 2025-11-24 04:00:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:00:23 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:00:23 --> Form Validation Class Initialized
INFO - 2025-11-24 04:00:23 --> Model "User_model" initialized
INFO - 2025-11-24 10:00:23 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:00:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:00:23 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:00:23 --> Controller Class Initialized
INFO - 2025-11-24 10:00:23 --> Model "Pusat_model" initialized
INFO - 2025-11-24 10:00:23 --> Model "Prodi_model" initialized
INFO - 2025-11-24 10:00:23 --> Model "Sdm_model" initialized
INFO - 2025-11-24 10:00:23 --> Model "Sdm_pusat_model" initialized
INFO - 2025-11-24 10:00:23 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-11-24 10:00:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-11-24 10:00:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:00:24 --> Model "Log_model" initialized
INFO - 2025-11-24 10:00:24 --> Final output sent to browser
DEBUG - 2025-11-24 10:00:24 --> Total execution time: 1.1723
INFO - 2025-11-24 04:00:45 --> Config Class Initialized
INFO - 2025-11-24 04:00:45 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:00:45 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:00:45 --> Utf8 Class Initialized
INFO - 2025-11-24 04:00:45 --> URI Class Initialized
INFO - 2025-11-24 04:00:45 --> Router Class Initialized
INFO - 2025-11-24 04:00:45 --> Output Class Initialized
INFO - 2025-11-24 04:00:45 --> Security Class Initialized
DEBUG - 2025-11-24 04:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:00:45 --> CSRF cookie sent
INFO - 2025-11-24 04:00:45 --> Input Class Initialized
INFO - 2025-11-24 04:00:45 --> Language Class Initialized
INFO - 2025-11-24 04:00:45 --> Loader Class Initialized
INFO - 2025-11-24 04:00:45 --> Helper loaded: url_helper
INFO - 2025-11-24 04:00:45 --> Helper loaded: text_helper
INFO - 2025-11-24 04:00:45 --> Helper loaded: string_helper
INFO - 2025-11-24 04:00:45 --> Helper loaded: form_helper
INFO - 2025-11-24 04:00:45 --> Helper loaded: download_helper
INFO - 2025-11-24 04:00:45 --> Helper loaded: security_helper
INFO - 2025-11-24 04:00:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:00:45 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:00:45 --> Form Validation Class Initialized
INFO - 2025-11-24 04:00:45 --> Model "User_model" initialized
INFO - 2025-11-24 10:00:45 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:00:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:00:45 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:00:45 --> Controller Class Initialized
INFO - 2025-11-24 10:00:45 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 10:00:45 --> Model "Prodi_model" initialized
INFO - 2025-11-24 10:00:45 --> Model "Sdm_model" initialized
INFO - 2025-11-24 10:00:45 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-11-24 10:00:45 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 1
ERROR - 2025-11-24 10:00:46 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-11-24 10:00:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-11-24 10:00:47 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2025-11-24 10:00:47 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2025-11-24 10:00:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-11-24 10:00:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:00:47 --> Model "Log_model" initialized
INFO - 2025-11-24 10:00:47 --> Final output sent to browser
DEBUG - 2025-11-24 10:00:47 --> Total execution time: 1.7261
INFO - 2025-11-24 04:01:06 --> Config Class Initialized
INFO - 2025-11-24 04:01:06 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:01:06 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:01:06 --> Utf8 Class Initialized
INFO - 2025-11-24 04:01:06 --> URI Class Initialized
INFO - 2025-11-24 04:01:06 --> Router Class Initialized
INFO - 2025-11-24 04:01:06 --> Output Class Initialized
INFO - 2025-11-24 04:01:06 --> Security Class Initialized
DEBUG - 2025-11-24 04:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:01:06 --> CSRF cookie sent
INFO - 2025-11-24 04:01:06 --> Input Class Initialized
INFO - 2025-11-24 04:01:06 --> Language Class Initialized
INFO - 2025-11-24 04:01:06 --> Loader Class Initialized
INFO - 2025-11-24 04:01:06 --> Helper loaded: url_helper
INFO - 2025-11-24 04:01:06 --> Helper loaded: text_helper
INFO - 2025-11-24 04:01:06 --> Helper loaded: string_helper
INFO - 2025-11-24 04:01:06 --> Helper loaded: form_helper
INFO - 2025-11-24 04:01:06 --> Helper loaded: download_helper
INFO - 2025-11-24 04:01:06 --> Helper loaded: security_helper
INFO - 2025-11-24 04:01:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:01:06 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:01:06 --> Form Validation Class Initialized
INFO - 2025-11-24 04:01:06 --> Model "User_model" initialized
INFO - 2025-11-24 10:01:06 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:01:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:01:06 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:01:06 --> Controller Class Initialized
INFO - 2025-11-24 10:01:06 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 10:01:06 --> Model "Prodi_model" initialized
INFO - 2025-11-24 10:01:06 --> Model "Sdm_model" initialized
INFO - 2025-11-24 10:01:06 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-11-24 10:01:06 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-11-24 10:01:06 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-11-24 10:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-11-24 10:01:06 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2025-11-24 10:01:06 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2025-11-24 10:01:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-11-24 10:01:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:01:06 --> Model "Log_model" initialized
INFO - 2025-11-24 10:01:06 --> Final output sent to browser
DEBUG - 2025-11-24 10:01:06 --> Total execution time: 0.1403
INFO - 2025-11-24 04:01:33 --> Config Class Initialized
INFO - 2025-11-24 04:01:33 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:01:33 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:01:33 --> Utf8 Class Initialized
INFO - 2025-11-24 04:01:33 --> URI Class Initialized
INFO - 2025-11-24 04:01:33 --> Router Class Initialized
INFO - 2025-11-24 04:01:33 --> Output Class Initialized
INFO - 2025-11-24 04:01:33 --> Security Class Initialized
DEBUG - 2025-11-24 04:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:01:33 --> CSRF cookie sent
INFO - 2025-11-24 04:01:33 --> Input Class Initialized
INFO - 2025-11-24 04:01:33 --> Language Class Initialized
INFO - 2025-11-24 04:01:33 --> Loader Class Initialized
INFO - 2025-11-24 04:01:33 --> Helper loaded: url_helper
INFO - 2025-11-24 04:01:33 --> Helper loaded: text_helper
INFO - 2025-11-24 04:01:33 --> Helper loaded: string_helper
INFO - 2025-11-24 04:01:33 --> Helper loaded: form_helper
INFO - 2025-11-24 04:01:33 --> Helper loaded: download_helper
INFO - 2025-11-24 04:01:33 --> Helper loaded: security_helper
INFO - 2025-11-24 04:01:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:01:33 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:01:33 --> Form Validation Class Initialized
INFO - 2025-11-24 04:01:33 --> Model "User_model" initialized
INFO - 2025-11-24 10:01:33 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:01:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:01:33 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:01:33 --> Controller Class Initialized
INFO - 2025-11-24 10:01:33 --> Model "Pages_model" initialized
INFO - 2025-11-24 10:01:33 --> Model "Berita_model" initialized
INFO - 2025-11-24 10:01:33 --> Model "Download_model" initialized
INFO - 2025-11-24 10:01:33 --> Model "Kategori_download_model" initialized
INFO - 2025-11-24 10:01:33 --> Model "Jenis_download_model" initialized
INFO - 2025-11-24 10:01:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-11-24 10:01:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:01:33 --> Model "Log_model" initialized
INFO - 2025-11-24 10:01:33 --> Final output sent to browser
DEBUG - 2025-11-24 10:01:33 --> Total execution time: 0.2483
INFO - 2025-11-24 04:01:41 --> Config Class Initialized
INFO - 2025-11-24 04:01:41 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:01:41 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:01:41 --> Utf8 Class Initialized
INFO - 2025-11-24 04:01:41 --> URI Class Initialized
INFO - 2025-11-24 04:01:41 --> Router Class Initialized
INFO - 2025-11-24 04:01:41 --> Output Class Initialized
INFO - 2025-11-24 04:01:41 --> Security Class Initialized
DEBUG - 2025-11-24 04:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:01:41 --> CSRF cookie sent
INFO - 2025-11-24 04:01:41 --> Input Class Initialized
INFO - 2025-11-24 04:01:41 --> Language Class Initialized
INFO - 2025-11-24 04:01:41 --> Loader Class Initialized
INFO - 2025-11-24 04:01:41 --> Helper loaded: url_helper
INFO - 2025-11-24 04:01:41 --> Helper loaded: text_helper
INFO - 2025-11-24 04:01:41 --> Helper loaded: string_helper
INFO - 2025-11-24 04:01:41 --> Helper loaded: form_helper
INFO - 2025-11-24 04:01:41 --> Helper loaded: download_helper
INFO - 2025-11-24 04:01:41 --> Helper loaded: security_helper
INFO - 2025-11-24 04:01:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:01:41 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:01:41 --> Form Validation Class Initialized
INFO - 2025-11-24 04:01:41 --> Model "User_model" initialized
INFO - 2025-11-24 10:01:41 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:01:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:01:41 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:01:41 --> Controller Class Initialized
INFO - 2025-11-24 10:01:41 --> Model "Pages_model" initialized
INFO - 2025-11-24 10:01:41 --> Model "Berita_model" initialized
INFO - 2025-11-24 10:01:41 --> Model "Download_model" initialized
INFO - 2025-11-24 10:01:41 --> Model "Kategori_download_model" initialized
INFO - 2025-11-24 10:01:41 --> Model "Jenis_download_model" initialized
INFO - 2025-11-24 10:01:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/alumni.php
INFO - 2025-11-24 10:01:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:01:41 --> Model "Log_model" initialized
INFO - 2025-11-24 10:01:42 --> Final output sent to browser
DEBUG - 2025-11-24 10:01:42 --> Total execution time: 0.2730
INFO - 2025-11-24 04:01:50 --> Config Class Initialized
INFO - 2025-11-24 04:01:50 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:01:50 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:01:50 --> Utf8 Class Initialized
INFO - 2025-11-24 04:01:50 --> URI Class Initialized
INFO - 2025-11-24 04:01:50 --> Router Class Initialized
INFO - 2025-11-24 04:01:50 --> Output Class Initialized
INFO - 2025-11-24 04:01:50 --> Security Class Initialized
DEBUG - 2025-11-24 04:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:01:50 --> CSRF cookie sent
INFO - 2025-11-24 04:01:50 --> Input Class Initialized
INFO - 2025-11-24 04:01:50 --> Language Class Initialized
INFO - 2025-11-24 04:01:50 --> Loader Class Initialized
INFO - 2025-11-24 04:01:50 --> Helper loaded: url_helper
INFO - 2025-11-24 04:01:50 --> Helper loaded: text_helper
INFO - 2025-11-24 04:01:50 --> Helper loaded: string_helper
INFO - 2025-11-24 04:01:50 --> Helper loaded: form_helper
INFO - 2025-11-24 04:01:50 --> Helper loaded: download_helper
INFO - 2025-11-24 04:01:50 --> Helper loaded: security_helper
INFO - 2025-11-24 04:01:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:01:50 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:01:50 --> Form Validation Class Initialized
INFO - 2025-11-24 04:01:50 --> Model "User_model" initialized
INFO - 2025-11-24 10:01:50 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:01:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:01:50 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:01:50 --> Controller Class Initialized
INFO - 2025-11-24 10:01:50 --> Model "Pages_model" initialized
INFO - 2025-11-24 10:01:50 --> Model "Berita_model" initialized
INFO - 2025-11-24 10:01:50 --> Model "Download_model" initialized
INFO - 2025-11-24 10:01:50 --> Model "Kategori_download_model" initialized
INFO - 2025-11-24 10:01:50 --> Model "Jenis_download_model" initialized
INFO - 2025-11-24 10:01:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-11-24 10:01:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:01:50 --> Model "Log_model" initialized
INFO - 2025-11-24 10:01:50 --> Final output sent to browser
DEBUG - 2025-11-24 10:01:50 --> Total execution time: 0.2076
INFO - 2025-11-24 04:01:59 --> Config Class Initialized
INFO - 2025-11-24 04:01:59 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:01:59 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:01:59 --> Utf8 Class Initialized
INFO - 2025-11-24 04:01:59 --> URI Class Initialized
INFO - 2025-11-24 04:01:59 --> Router Class Initialized
INFO - 2025-11-24 04:01:59 --> Output Class Initialized
INFO - 2025-11-24 04:01:59 --> Security Class Initialized
DEBUG - 2025-11-24 04:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:01:59 --> CSRF cookie sent
INFO - 2025-11-24 04:01:59 --> Input Class Initialized
INFO - 2025-11-24 04:01:59 --> Language Class Initialized
INFO - 2025-11-24 04:01:59 --> Loader Class Initialized
INFO - 2025-11-24 04:01:59 --> Helper loaded: url_helper
INFO - 2025-11-24 04:01:59 --> Helper loaded: text_helper
INFO - 2025-11-24 04:01:59 --> Helper loaded: string_helper
INFO - 2025-11-24 04:01:59 --> Helper loaded: form_helper
INFO - 2025-11-24 04:01:59 --> Helper loaded: download_helper
INFO - 2025-11-24 04:01:59 --> Helper loaded: security_helper
INFO - 2025-11-24 04:01:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:01:59 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:01:59 --> Form Validation Class Initialized
INFO - 2025-11-24 04:01:59 --> Model "User_model" initialized
INFO - 2025-11-24 10:01:59 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:01:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:01:59 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:01:59 --> Controller Class Initialized
INFO - 2025-11-24 10:01:59 --> Model "Download_model" initialized
INFO - 2025-11-24 10:01:59 --> Model "Kategori_download_model" initialized
INFO - 2025-11-24 10:01:59 --> Model "Jenis_download_model" initialized
INFO - 2025-11-24 10:01:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\monev/list.php
INFO - 2025-11-24 10:01:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:01:59 --> Model "Log_model" initialized
INFO - 2025-11-24 10:01:59 --> Final output sent to browser
DEBUG - 2025-11-24 10:01:59 --> Total execution time: 0.2561
INFO - 2025-11-24 04:02:12 --> Config Class Initialized
INFO - 2025-11-24 04:02:12 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:02:12 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:02:12 --> Utf8 Class Initialized
INFO - 2025-11-24 04:02:12 --> URI Class Initialized
INFO - 2025-11-24 04:02:12 --> Router Class Initialized
INFO - 2025-11-24 04:02:12 --> Output Class Initialized
INFO - 2025-11-24 04:02:12 --> Security Class Initialized
DEBUG - 2025-11-24 04:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:02:12 --> CSRF cookie sent
INFO - 2025-11-24 04:02:12 --> Input Class Initialized
INFO - 2025-11-24 04:02:12 --> Language Class Initialized
INFO - 2025-11-24 04:02:12 --> Loader Class Initialized
INFO - 2025-11-24 04:02:12 --> Helper loaded: url_helper
INFO - 2025-11-24 04:02:12 --> Helper loaded: text_helper
INFO - 2025-11-24 04:02:12 --> Helper loaded: string_helper
INFO - 2025-11-24 04:02:12 --> Helper loaded: form_helper
INFO - 2025-11-24 04:02:12 --> Helper loaded: download_helper
INFO - 2025-11-24 04:02:12 --> Helper loaded: security_helper
INFO - 2025-11-24 04:02:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:02:12 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:02:13 --> Form Validation Class Initialized
INFO - 2025-11-24 04:02:13 --> Model "User_model" initialized
INFO - 2025-11-24 10:02:13 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:02:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:02:13 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:02:13 --> Controller Class Initialized
INFO - 2025-11-24 10:02:13 --> Model "Helpdesk_model" initialized
INFO - 2025-11-24 10:02:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\helpdesk/list.php
INFO - 2025-11-24 10:02:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:02:13 --> Model "Log_model" initialized
INFO - 2025-11-24 10:02:13 --> Final output sent to browser
DEBUG - 2025-11-24 10:02:13 --> Total execution time: 0.4213
INFO - 2025-11-24 04:03:56 --> Config Class Initialized
INFO - 2025-11-24 04:03:56 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:03:56 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:03:56 --> Utf8 Class Initialized
INFO - 2025-11-24 04:03:56 --> URI Class Initialized
INFO - 2025-11-24 04:03:56 --> Router Class Initialized
INFO - 2025-11-24 04:03:56 --> Output Class Initialized
INFO - 2025-11-24 04:03:56 --> Security Class Initialized
DEBUG - 2025-11-24 04:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:03:56 --> CSRF cookie sent
INFO - 2025-11-24 04:03:56 --> Input Class Initialized
INFO - 2025-11-24 04:03:56 --> Language Class Initialized
INFO - 2025-11-24 04:03:56 --> Loader Class Initialized
INFO - 2025-11-24 04:03:56 --> Helper loaded: url_helper
INFO - 2025-11-24 04:03:56 --> Helper loaded: text_helper
INFO - 2025-11-24 04:03:56 --> Helper loaded: string_helper
INFO - 2025-11-24 04:03:56 --> Helper loaded: form_helper
INFO - 2025-11-24 04:03:56 --> Helper loaded: download_helper
INFO - 2025-11-24 04:03:56 --> Helper loaded: security_helper
INFO - 2025-11-24 04:03:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:03:56 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:03:56 --> Form Validation Class Initialized
INFO - 2025-11-24 04:03:56 --> Model "User_model" initialized
INFO - 2025-11-24 10:03:56 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:03:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:03:56 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:03:56 --> Controller Class Initialized
INFO - 2025-11-24 10:03:56 --> Model "Pages_model" initialized
INFO - 2025-11-24 10:03:56 --> Model "Berita_model" initialized
INFO - 2025-11-24 10:03:56 --> Model "Download_model" initialized
INFO - 2025-11-24 10:03:56 --> Model "Kategori_download_model" initialized
INFO - 2025-11-24 10:03:56 --> Model "Jenis_download_model" initialized
INFO - 2025-11-24 10:03:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-11-24 10:03:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:03:56 --> Model "Log_model" initialized
INFO - 2025-11-24 10:03:56 --> Final output sent to browser
DEBUG - 2025-11-24 10:03:56 --> Total execution time: 0.2120
INFO - 2025-11-24 04:04:43 --> Config Class Initialized
INFO - 2025-11-24 04:04:43 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:04:43 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:04:43 --> Utf8 Class Initialized
INFO - 2025-11-24 04:04:43 --> URI Class Initialized
INFO - 2025-11-24 04:04:43 --> Router Class Initialized
INFO - 2025-11-24 04:04:43 --> Output Class Initialized
INFO - 2025-11-24 04:04:43 --> Security Class Initialized
DEBUG - 2025-11-24 04:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:04:43 --> CSRF cookie sent
INFO - 2025-11-24 04:04:43 --> Input Class Initialized
INFO - 2025-11-24 04:04:43 --> Language Class Initialized
INFO - 2025-11-24 04:04:43 --> Loader Class Initialized
INFO - 2025-11-24 04:04:43 --> Helper loaded: url_helper
INFO - 2025-11-24 04:04:43 --> Helper loaded: text_helper
INFO - 2025-11-24 04:04:43 --> Helper loaded: string_helper
INFO - 2025-11-24 04:04:43 --> Helper loaded: form_helper
INFO - 2025-11-24 04:04:43 --> Helper loaded: download_helper
INFO - 2025-11-24 04:04:43 --> Helper loaded: security_helper
INFO - 2025-11-24 04:04:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:04:43 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:04:43 --> Form Validation Class Initialized
INFO - 2025-11-24 04:04:43 --> Model "User_model" initialized
INFO - 2025-11-24 10:04:43 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:04:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:04:43 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:04:43 --> Controller Class Initialized
INFO - 2025-11-24 10:04:43 --> Model "Download_model" initialized
INFO - 2025-11-24 10:04:43 --> Model "Kategori_download_model" initialized
INFO - 2025-11-24 10:04:43 --> Model "Jenis_download_model" initialized
INFO - 2025-11-24 10:04:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2025-11-24 10:04:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:04:44 --> Model "Log_model" initialized
INFO - 2025-11-24 10:04:44 --> Final output sent to browser
DEBUG - 2025-11-24 10:04:44 --> Total execution time: 0.4451
INFO - 2025-11-24 04:05:02 --> Config Class Initialized
INFO - 2025-11-24 04:05:02 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:05:02 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:05:02 --> Utf8 Class Initialized
INFO - 2025-11-24 04:05:02 --> URI Class Initialized
INFO - 2025-11-24 04:05:02 --> Router Class Initialized
INFO - 2025-11-24 04:05:02 --> Output Class Initialized
INFO - 2025-11-24 04:05:02 --> Security Class Initialized
DEBUG - 2025-11-24 04:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:05:02 --> CSRF cookie sent
INFO - 2025-11-24 04:05:02 --> Input Class Initialized
INFO - 2025-11-24 04:05:02 --> Language Class Initialized
INFO - 2025-11-24 04:05:02 --> Loader Class Initialized
INFO - 2025-11-24 04:05:02 --> Helper loaded: url_helper
INFO - 2025-11-24 04:05:02 --> Helper loaded: text_helper
INFO - 2025-11-24 04:05:02 --> Helper loaded: string_helper
INFO - 2025-11-24 04:05:02 --> Helper loaded: form_helper
INFO - 2025-11-24 04:05:02 --> Helper loaded: download_helper
INFO - 2025-11-24 04:05:02 --> Helper loaded: security_helper
INFO - 2025-11-24 04:05:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:05:02 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:05:02 --> Form Validation Class Initialized
INFO - 2025-11-24 04:05:02 --> Model "User_model" initialized
INFO - 2025-11-24 10:05:02 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:05:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:05:02 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:05:02 --> Controller Class Initialized
INFO - 2025-11-24 10:05:02 --> Model "Download_model" initialized
INFO - 2025-11-24 10:05:02 --> Model "Kategori_download_model" initialized
INFO - 2025-11-24 10:05:02 --> Model "Jenis_download_model" initialized
INFO - 2025-11-24 10:05:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_perpustakaan.php
INFO - 2025-11-24 10:05:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:05:02 --> Model "Log_model" initialized
INFO - 2025-11-24 10:05:02 --> Final output sent to browser
DEBUG - 2025-11-24 10:05:02 --> Total execution time: 0.1862
INFO - 2025-11-24 04:05:08 --> Config Class Initialized
INFO - 2025-11-24 04:05:08 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:05:08 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:05:08 --> Utf8 Class Initialized
INFO - 2025-11-24 04:05:08 --> URI Class Initialized
INFO - 2025-11-24 04:05:08 --> Router Class Initialized
INFO - 2025-11-24 04:05:08 --> Output Class Initialized
INFO - 2025-11-24 04:05:08 --> Security Class Initialized
DEBUG - 2025-11-24 04:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:05:08 --> CSRF cookie sent
INFO - 2025-11-24 04:05:08 --> Input Class Initialized
INFO - 2025-11-24 04:05:08 --> Language Class Initialized
INFO - 2025-11-24 04:05:08 --> Loader Class Initialized
INFO - 2025-11-24 04:05:08 --> Helper loaded: url_helper
INFO - 2025-11-24 04:05:08 --> Helper loaded: text_helper
INFO - 2025-11-24 04:05:08 --> Helper loaded: string_helper
INFO - 2025-11-24 04:05:08 --> Helper loaded: form_helper
INFO - 2025-11-24 04:05:08 --> Helper loaded: download_helper
INFO - 2025-11-24 04:05:08 --> Helper loaded: security_helper
INFO - 2025-11-24 04:05:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:05:08 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:05:08 --> Form Validation Class Initialized
INFO - 2025-11-24 04:05:08 --> Model "User_model" initialized
INFO - 2025-11-24 10:05:08 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:05:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:05:08 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:05:08 --> Controller Class Initialized
INFO - 2025-11-24 10:05:08 --> Model "Pages_model" initialized
INFO - 2025-11-24 10:05:08 --> Model "Berita_model" initialized
INFO - 2025-11-24 10:05:08 --> Model "Download_model" initialized
INFO - 2025-11-24 10:05:08 --> Model "Kategori_download_model" initialized
INFO - 2025-11-24 10:05:08 --> Model "Jenis_download_model" initialized
INFO - 2025-11-24 10:05:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/layanan.php
INFO - 2025-11-24 10:05:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:05:08 --> Model "Log_model" initialized
INFO - 2025-11-24 10:05:08 --> Final output sent to browser
DEBUG - 2025-11-24 10:05:08 --> Total execution time: 0.3223
INFO - 2025-11-24 04:05:22 --> Config Class Initialized
INFO - 2025-11-24 04:05:22 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:05:22 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:05:22 --> Utf8 Class Initialized
INFO - 2025-11-24 04:05:22 --> URI Class Initialized
INFO - 2025-11-24 04:05:22 --> Router Class Initialized
INFO - 2025-11-24 04:05:22 --> Output Class Initialized
INFO - 2025-11-24 04:05:22 --> Security Class Initialized
DEBUG - 2025-11-24 04:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:05:22 --> CSRF cookie sent
INFO - 2025-11-24 04:05:22 --> Input Class Initialized
INFO - 2025-11-24 04:05:22 --> Language Class Initialized
INFO - 2025-11-24 04:05:22 --> Loader Class Initialized
INFO - 2025-11-24 04:05:22 --> Helper loaded: url_helper
INFO - 2025-11-24 04:05:22 --> Helper loaded: text_helper
INFO - 2025-11-24 04:05:22 --> Helper loaded: string_helper
INFO - 2025-11-24 04:05:22 --> Helper loaded: form_helper
INFO - 2025-11-24 04:05:22 --> Helper loaded: download_helper
INFO - 2025-11-24 04:05:22 --> Helper loaded: security_helper
INFO - 2025-11-24 04:05:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:05:22 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:05:22 --> Form Validation Class Initialized
INFO - 2025-11-24 04:05:22 --> Model "User_model" initialized
INFO - 2025-11-24 10:05:22 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:05:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:05:22 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:05:22 --> Controller Class Initialized
INFO - 2025-11-24 10:05:22 --> Model "Pages_model" initialized
INFO - 2025-11-24 10:05:22 --> Model "Berita_model" initialized
INFO - 2025-11-24 10:05:22 --> Model "Download_model" initialized
INFO - 2025-11-24 10:05:22 --> Model "Kategori_download_model" initialized
INFO - 2025-11-24 10:05:22 --> Model "Jenis_download_model" initialized
INFO - 2025-11-24 10:05:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-11-24 10:05:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:05:22 --> Model "Log_model" initialized
INFO - 2025-11-24 10:05:22 --> Final output sent to browser
DEBUG - 2025-11-24 10:05:22 --> Total execution time: 0.1086
INFO - 2025-11-24 04:11:57 --> Config Class Initialized
INFO - 2025-11-24 04:11:57 --> Hooks Class Initialized
DEBUG - 2025-11-24 04:11:57 --> UTF-8 Support Enabled
INFO - 2025-11-24 04:11:57 --> Utf8 Class Initialized
INFO - 2025-11-24 04:11:57 --> URI Class Initialized
DEBUG - 2025-11-24 04:11:57 --> No URI present. Default controller set.
INFO - 2025-11-24 04:11:57 --> Router Class Initialized
INFO - 2025-11-24 04:11:57 --> Output Class Initialized
INFO - 2025-11-24 04:11:57 --> Security Class Initialized
DEBUG - 2025-11-24 04:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 04:11:57 --> CSRF cookie sent
INFO - 2025-11-24 04:11:57 --> Input Class Initialized
INFO - 2025-11-24 04:11:57 --> Language Class Initialized
INFO - 2025-11-24 04:11:57 --> Loader Class Initialized
INFO - 2025-11-24 04:11:57 --> Helper loaded: url_helper
INFO - 2025-11-24 04:11:57 --> Helper loaded: text_helper
INFO - 2025-11-24 04:11:57 --> Helper loaded: string_helper
INFO - 2025-11-24 04:11:57 --> Helper loaded: form_helper
INFO - 2025-11-24 04:11:57 --> Helper loaded: download_helper
INFO - 2025-11-24 04:11:57 --> Helper loaded: security_helper
INFO - 2025-11-24 04:11:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 04:11:57 --> Database Driver Class Initialized
DEBUG - 2025-11-24 04:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 04:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 04:11:58 --> Form Validation Class Initialized
INFO - 2025-11-24 04:11:58 --> Model "User_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Nav_model" initialized
INFO - 2025-11-24 10:11:58 --> Controller Class Initialized
INFO - 2025-11-24 10:11:58 --> Model "Berita_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Galeri_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Video_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Agenda_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Tautan_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Mitra_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Prodi_model" initialized
INFO - 2025-11-24 10:11:58 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 10:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 10:11:58 --> Pagination Class Initialized
INFO - 2025-11-24 10:11:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 10:11:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 10:11:58 --> Model "Log_model" initialized
INFO - 2025-11-24 10:11:58 --> Final output sent to browser
DEBUG - 2025-11-24 10:11:58 --> Total execution time: 0.2490
INFO - 2025-11-24 08:58:56 --> Config Class Initialized
INFO - 2025-11-24 08:58:56 --> Hooks Class Initialized
DEBUG - 2025-11-24 08:58:56 --> UTF-8 Support Enabled
INFO - 2025-11-24 08:58:56 --> Utf8 Class Initialized
INFO - 2025-11-24 08:58:56 --> URI Class Initialized
DEBUG - 2025-11-24 08:58:56 --> No URI present. Default controller set.
INFO - 2025-11-24 08:58:56 --> Router Class Initialized
INFO - 2025-11-24 08:58:56 --> Output Class Initialized
INFO - 2025-11-24 08:58:56 --> Security Class Initialized
DEBUG - 2025-11-24 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-24 08:58:57 --> CSRF cookie sent
INFO - 2025-11-24 08:58:57 --> Input Class Initialized
INFO - 2025-11-24 08:58:57 --> Language Class Initialized
INFO - 2025-11-24 08:58:57 --> Loader Class Initialized
INFO - 2025-11-24 08:58:57 --> Helper loaded: url_helper
INFO - 2025-11-24 08:58:57 --> Helper loaded: text_helper
INFO - 2025-11-24 08:58:57 --> Helper loaded: string_helper
INFO - 2025-11-24 08:58:57 --> Helper loaded: form_helper
INFO - 2025-11-24 08:58:57 --> Helper loaded: download_helper
INFO - 2025-11-24 08:58:57 --> Helper loaded: security_helper
INFO - 2025-11-24 08:58:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-24 08:58:57 --> Database Driver Class Initialized
DEBUG - 2025-11-24 08:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-24 08:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-24 08:58:57 --> Form Validation Class Initialized
INFO - 2025-11-24 08:58:57 --> Model "User_model" initialized
INFO - 2025-11-24 14:58:57 --> Model "Kunjungan_model" initialized
INFO - 2025-11-24 14:58:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-24 14:58:57 --> Model "Nav_model" initialized
INFO - 2025-11-24 14:58:57 --> Controller Class Initialized
INFO - 2025-11-24 14:58:57 --> Model "Berita_model" initialized
INFO - 2025-11-24 14:58:57 --> Model "Galeri_model" initialized
INFO - 2025-11-24 14:58:57 --> Model "Video_model" initialized
INFO - 2025-11-24 14:58:58 --> Model "Agenda_model" initialized
INFO - 2025-11-24 14:58:58 --> Model "Tautan_model" initialized
INFO - 2025-11-24 14:58:58 --> Model "Mitra_model" initialized
INFO - 2025-11-24 14:58:58 --> Model "Jurusan_model" initialized
INFO - 2025-11-24 14:58:58 --> Model "Prodi_model" initialized
INFO - 2025-11-24 14:58:58 --> Model "Testimoni_model" initialized
INFO - 2025-11-24 14:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-24 14:58:58 --> Pagination Class Initialized
INFO - 2025-11-24 14:58:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-24 14:58:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-24 14:59:00 --> Model "Log_model" initialized
INFO - 2025-11-24 14:59:00 --> Final output sent to browser
DEBUG - 2025-11-24 14:59:00 --> Total execution time: 3.7465
