INFO - 2025-09-15 09:44:01 --> Config Class Initialized
INFO - 2025-09-15 09:44:01 --> Hooks Class Initialized
DEBUG - 2025-09-15 09:44:01 --> UTF-8 Support Enabled
INFO - 2025-09-15 09:44:01 --> Utf8 Class Initialized
INFO - 2025-09-15 09:44:01 --> URI Class Initialized
INFO - 2025-09-15 09:44:01 --> Router Class Initialized
INFO - 2025-09-15 09:44:01 --> Output Class Initialized
INFO - 2025-09-15 09:44:01 --> Security Class Initialized
DEBUG - 2025-09-15 09:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 09:44:01 --> CSRF cookie sent
INFO - 2025-09-15 09:44:01 --> Input Class Initialized
INFO - 2025-09-15 09:44:01 --> Language Class Initialized
INFO - 2025-09-15 09:44:01 --> Loader Class Initialized
INFO - 2025-09-15 09:44:01 --> Helper loaded: url_helper
INFO - 2025-09-15 09:44:01 --> Helper loaded: text_helper
INFO - 2025-09-15 09:44:01 --> Helper loaded: string_helper
INFO - 2025-09-15 09:44:01 --> Helper loaded: form_helper
INFO - 2025-09-15 09:44:01 --> Helper loaded: download_helper
INFO - 2025-09-15 09:44:01 --> Helper loaded: security_helper
INFO - 2025-09-15 09:44:01 --> Database Driver Class Initialized
DEBUG - 2025-09-15 09:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 09:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 09:44:01 --> Form Validation Class Initialized
INFO - 2025-09-15 09:44:01 --> Model "User_model" initialized
INFO - 2025-09-15 14:44:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 14:44:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 14:44:01 --> Model "Nav_model" initialized
INFO - 2025-09-15 14:44:01 --> Controller Class Initialized
INFO - 2025-09-15 14:44:01 --> Model "Prodi_model" initialized
INFO - 2025-09-15 14:44:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 14:44:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-15 14:44:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-15 14:44:02 --> Model "Log_model" initialized
ERROR - 2025-09-15 14:44:02 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 14:44:02', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 'admin/prodi', 'GET', 'Page accessed')
INFO - 2025-09-15 14:44:02 --> Final output sent to browser
DEBUG - 2025-09-15 14:44:02 --> Total execution time: 0.6045
INFO - 2025-09-15 09:44:07 --> Config Class Initialized
INFO - 2025-09-15 09:44:07 --> Hooks Class Initialized
DEBUG - 2025-09-15 09:44:07 --> UTF-8 Support Enabled
INFO - 2025-09-15 09:44:07 --> Utf8 Class Initialized
INFO - 2025-09-15 09:44:07 --> URI Class Initialized
INFO - 2025-09-15 09:44:07 --> Router Class Initialized
INFO - 2025-09-15 09:44:07 --> Output Class Initialized
INFO - 2025-09-15 09:44:07 --> Security Class Initialized
DEBUG - 2025-09-15 09:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 09:44:07 --> CSRF cookie sent
INFO - 2025-09-15 09:44:07 --> Input Class Initialized
INFO - 2025-09-15 09:44:07 --> Language Class Initialized
INFO - 2025-09-15 09:44:07 --> Loader Class Initialized
INFO - 2025-09-15 09:44:07 --> Helper loaded: url_helper
INFO - 2025-09-15 09:44:07 --> Helper loaded: text_helper
INFO - 2025-09-15 09:44:07 --> Helper loaded: string_helper
INFO - 2025-09-15 09:44:07 --> Helper loaded: form_helper
INFO - 2025-09-15 09:44:07 --> Helper loaded: download_helper
INFO - 2025-09-15 09:44:07 --> Helper loaded: security_helper
INFO - 2025-09-15 09:44:07 --> Database Driver Class Initialized
DEBUG - 2025-09-15 09:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 09:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 09:44:07 --> Form Validation Class Initialized
INFO - 2025-09-15 09:44:07 --> Model "User_model" initialized
INFO - 2025-09-15 14:44:07 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 14:44:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 14:44:07 --> Model "Nav_model" initialized
INFO - 2025-09-15 14:44:07 --> Controller Class Initialized
INFO - 2025-09-15 14:44:07 --> Model "Prodi_model" initialized
INFO - 2025-09-15 14:44:07 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 14:44:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-15 14:44:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-15 14:44:07 --> Model "Log_model" initialized
ERROR - 2025-09-15 14:44:07 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 14:44:07', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 'admin/prodi/edit/6', 'GET', 'Page accessed')
INFO - 2025-09-15 14:44:07 --> Final output sent to browser
DEBUG - 2025-09-15 14:44:07 --> Total execution time: 0.1992
INFO - 2025-09-15 09:44:12 --> Config Class Initialized
INFO - 2025-09-15 09:44:12 --> Hooks Class Initialized
DEBUG - 2025-09-15 09:44:12 --> UTF-8 Support Enabled
INFO - 2025-09-15 09:44:12 --> Utf8 Class Initialized
INFO - 2025-09-15 09:44:12 --> URI Class Initialized
INFO - 2025-09-15 09:44:12 --> Router Class Initialized
INFO - 2025-09-15 09:44:12 --> Output Class Initialized
INFO - 2025-09-15 09:44:12 --> Security Class Initialized
DEBUG - 2025-09-15 09:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 09:44:12 --> CSRF cookie sent
INFO - 2025-09-15 09:44:12 --> CSRF token verified
INFO - 2025-09-15 09:44:12 --> Input Class Initialized
INFO - 2025-09-15 09:44:12 --> Language Class Initialized
INFO - 2025-09-15 09:44:12 --> Loader Class Initialized
INFO - 2025-09-15 09:44:12 --> Helper loaded: url_helper
INFO - 2025-09-15 09:44:12 --> Helper loaded: text_helper
INFO - 2025-09-15 09:44:12 --> Helper loaded: string_helper
INFO - 2025-09-15 09:44:12 --> Helper loaded: form_helper
INFO - 2025-09-15 09:44:12 --> Helper loaded: download_helper
INFO - 2025-09-15 09:44:12 --> Helper loaded: security_helper
INFO - 2025-09-15 09:44:12 --> Database Driver Class Initialized
DEBUG - 2025-09-15 09:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 09:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 09:44:12 --> Form Validation Class Initialized
INFO - 2025-09-15 09:44:12 --> Model "User_model" initialized
INFO - 2025-09-15 14:44:12 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 14:44:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 14:44:12 --> Model "Nav_model" initialized
INFO - 2025-09-15 14:44:12 --> Controller Class Initialized
INFO - 2025-09-15 14:44:12 --> Model "Prodi_model" initialized
INFO - 2025-09-15 14:44:12 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 14:44:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-09-15 14:44:12 --> Query error: Table 'prodi' is read only - Invalid query: UPDATE `prodi` SET `jurusan_id` = '2', `nama` = 'DIII Kebidanan tes', `jenjang` = 'D3', `akreditasi` = 'A (Unggul)', `mode_kuliah` = 'Reguler', `biaya_kuliah` = 'Rp. 5.800.000/Semester', `icon` = 'bi bi-mortarboard-fill', `color` = 'success', `keunggulan` = '[\"Akreditasi Program Studi yang Terbaru (2025\\u20132030)\",\"Calon Center of Excellence (CoE)\",\"Kurikulum Responsif Gender dan Teknologi Tepat Guna\",\"Fasilitas Belajar Terpadu\",\"Jaringan Kerjasama yang Kuat\",\"Pendidikan Vokasi Berorientasi Praktik\"]', `prospek_karir` = '{\"0\":{\"icon\":\"bi bi-hospital\",\"color\":\"success\",\"text\":\"Bidan di Fasilitas Kesehatan\"},\"2\":{\"icon\":\"bi bi-heart-pulse\",\"color\":\"danger\",\"text\":\"Tenaga Kesehatan di Lembaga Pemerintah\"},\"3\":{\"icon\":\"bi bi-people\",\"color\":\"warning\",\"text\":\"Bidan Komunitas \\/ LSM\"},\"4\":{\"icon\":\"bi bi-laptop\",\"color\":\"info\",\"text\":\"Tenaga Edukator atau Penyuluh Kesehatan\"},\"5\":{\"icon\":\"bi bi-calculator\",\"color\":\"secondary\",\"text\":\"Karir di Luar Negeri\"}}', `prospek_title` = ' Peluang Kerja di Dalam Negeri, Peluang Kerja di Luar Negeri ', `link_brosur` = '', `link_detail` = '', `status` = 'active', `deskripsi` = '<p data-start=\"273\" data-end=\"369\">Program D3 Kebidanan Poltekkes Kemenkes Jakarta III awalnya berasal dari dua akademi kebidanan:</p>\r\n<p data-start=\"273\" data-end=\"369\"><strong data-start=\"373\" data-end=\"395\">Cipto Mangunkusumo</strong> (Jakarta Timur), yang berawal dari Akademi Kebidanan sejak tahun 1996 (konversi dari SPK tahun 1980).</p>\r\n<p data-start=\"273\" data-end=\"369\"><strong data-start=\"500\" data-end=\"516\">Harapan Kita</strong> (Jakarta Barat), yang berawal dari Akademi Kebidanan sejak 1998 (konversi dari SPK tahun 1983).</p>\r\n<p data-start=\"614\" data-end=\"795\">Kedua prodi tersebut dilebur sejak tahun 2014 sebagai bagian dari penguatan dan konsolidasi pendidikan kebidanan di bawah Poltekkes Jakarta III</p>', `durasi` = '3', `total_sks` = '114', `gelar` = 'A.Md.Bid', `visi` = '<p>Mengembangkan keilmuan kebidanan dalam asuhan kebidanan melalui pemanfaatan teknologi terkini berfokus pada peningkatan kesehatan otak dan pendekatan sensitif gender</p>', `misi` = '<ol>\r\n<li>Meningkatkan kualitas penyelenggaraan pendidikan dan pembelajaran dengan mengimplementasikan asuhan kebidanan yang berbasis filosofi kebidanan dengan pendekatan sensitif gender dan peningkatan kesehatan otak.</li>\r\n<li>Melaksanakan penelitian kebidanan yang mendukung model praktik kebidanan.</li>\r\n<li>Melaksanakan pengabdian kepada masyarakat yang dapat meningkatkan derajat kesehatan melalui pemberdayaan perempuan dan keluarga.</li>\r\n<li>Menjalin kerjasama lintas program maupun lintas sektoral dengan institusi terkait baik regional, nasional maupun internasional</li>\r\n</ol>', `alumni_count` = 1000, `job_placement` = 96, `rating` = 4.6, `updated_at` = '2025-09-15 14:44:12', `slug` = 'diii-kebidanan-tes'
WHERE `id` = '6'
INFO - 2025-09-15 09:44:12 --> Config Class Initialized
INFO - 2025-09-15 09:44:12 --> Hooks Class Initialized
DEBUG - 2025-09-15 09:44:12 --> UTF-8 Support Enabled
INFO - 2025-09-15 09:44:12 --> Utf8 Class Initialized
INFO - 2025-09-15 09:44:12 --> URI Class Initialized
INFO - 2025-09-15 09:44:12 --> Router Class Initialized
INFO - 2025-09-15 09:44:12 --> Output Class Initialized
INFO - 2025-09-15 09:44:12 --> Security Class Initialized
DEBUG - 2025-09-15 09:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 09:44:12 --> CSRF cookie sent
INFO - 2025-09-15 09:44:12 --> Input Class Initialized
INFO - 2025-09-15 09:44:12 --> Language Class Initialized
INFO - 2025-09-15 09:44:13 --> Loader Class Initialized
INFO - 2025-09-15 09:44:13 --> Helper loaded: url_helper
INFO - 2025-09-15 09:44:13 --> Helper loaded: text_helper
INFO - 2025-09-15 09:44:13 --> Helper loaded: string_helper
INFO - 2025-09-15 09:44:13 --> Helper loaded: form_helper
INFO - 2025-09-15 09:44:13 --> Helper loaded: download_helper
INFO - 2025-09-15 09:44:13 --> Helper loaded: security_helper
INFO - 2025-09-15 09:44:13 --> Database Driver Class Initialized
DEBUG - 2025-09-15 09:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 09:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 09:44:13 --> Form Validation Class Initialized
INFO - 2025-09-15 09:44:13 --> Model "User_model" initialized
INFO - 2025-09-15 14:44:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 14:44:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 14:44:13 --> Model "Nav_model" initialized
INFO - 2025-09-15 14:44:13 --> Controller Class Initialized
INFO - 2025-09-15 14:44:13 --> Model "Prodi_model" initialized
INFO - 2025-09-15 14:44:13 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 14:44:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-15 14:44:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-15 14:44:13 --> Model "Log_model" initialized
ERROR - 2025-09-15 14:44:13 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 14:44:13', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 'admin/prodi', 'GET', 'Page accessed')
INFO - 2025-09-15 14:44:13 --> Final output sent to browser
DEBUG - 2025-09-15 14:44:13 --> Total execution time: 0.1183
INFO - 2025-09-15 09:48:41 --> Config Class Initialized
INFO - 2025-09-15 09:48:41 --> Hooks Class Initialized
DEBUG - 2025-09-15 09:48:41 --> UTF-8 Support Enabled
INFO - 2025-09-15 09:48:41 --> Utf8 Class Initialized
INFO - 2025-09-15 09:48:41 --> URI Class Initialized
INFO - 2025-09-15 09:48:41 --> Router Class Initialized
INFO - 2025-09-15 09:48:41 --> Output Class Initialized
INFO - 2025-09-15 09:48:41 --> Security Class Initialized
DEBUG - 2025-09-15 09:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 09:48:41 --> CSRF cookie sent
INFO - 2025-09-15 09:48:41 --> Input Class Initialized
INFO - 2025-09-15 09:48:41 --> Language Class Initialized
INFO - 2025-09-15 09:48:41 --> Loader Class Initialized
INFO - 2025-09-15 09:48:41 --> Helper loaded: url_helper
INFO - 2025-09-15 09:48:41 --> Helper loaded: text_helper
INFO - 2025-09-15 09:48:41 --> Helper loaded: string_helper
INFO - 2025-09-15 09:48:41 --> Helper loaded: form_helper
INFO - 2025-09-15 09:48:41 --> Helper loaded: download_helper
INFO - 2025-09-15 09:48:41 --> Helper loaded: security_helper
INFO - 2025-09-15 09:48:41 --> Database Driver Class Initialized
ERROR - 2025-09-15 09:48:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-15 09:48:43 --> Unable to connect to the database
DEBUG - 2025-09-15 09:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 09:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 09:48:43 --> Form Validation Class Initialized
INFO - 2025-09-15 09:48:43 --> Database Driver Class Initialized
ERROR - 2025-09-15 09:48:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-15 09:48:45 --> Unable to connect to the database
INFO - 2025-09-15 09:48:45 --> Model "User_model" initialized
INFO - 2025-09-15 14:48:45 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 14:48:45 --> Database Driver Class Initialized
ERROR - 2025-09-15 14:48:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-15 14:48:47 --> Unable to connect to the database
INFO - 2025-09-15 14:48:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 14:48:47 --> Database Driver Class Initialized
ERROR - 2025-09-15 14:48:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-15 14:48:49 --> Unable to connect to the database
INFO - 2025-09-15 14:48:49 --> Model "Nav_model" initialized
INFO - 2025-09-15 14:48:49 --> Controller Class Initialized
INFO - 2025-09-15 14:48:49 --> Database Driver Class Initialized
ERROR - 2025-09-15 14:48:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-15 14:48:51 --> Unable to connect to the database
INFO - 2025-09-15 14:48:51 --> Model "Prodi_model" initialized
INFO - 2025-09-15 14:48:51 --> Database Driver Class Initialized
ERROR - 2025-09-15 14:48:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-15 14:48:53 --> Unable to connect to the database
INFO - 2025-09-15 14:48:53 --> Model "Jurusan_model" initialized
ERROR - 2025-09-15 14:48:53 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 401
ERROR - 2025-09-15 14:48:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\dev_jkt3\system\core\Exceptions.php:272) D:\xampp\htdocs\dev_jkt3\system\core\Common.php 571
INFO - 2025-09-15 09:49:03 --> Config Class Initialized
INFO - 2025-09-15 09:49:03 --> Hooks Class Initialized
DEBUG - 2025-09-15 09:49:03 --> UTF-8 Support Enabled
INFO - 2025-09-15 09:49:03 --> Utf8 Class Initialized
INFO - 2025-09-15 09:49:03 --> URI Class Initialized
INFO - 2025-09-15 09:49:03 --> Router Class Initialized
INFO - 2025-09-15 09:49:03 --> Output Class Initialized
INFO - 2025-09-15 09:49:03 --> Security Class Initialized
DEBUG - 2025-09-15 09:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 09:49:03 --> CSRF cookie sent
INFO - 2025-09-15 09:49:03 --> Input Class Initialized
INFO - 2025-09-15 09:49:03 --> Language Class Initialized
INFO - 2025-09-15 09:49:03 --> Loader Class Initialized
INFO - 2025-09-15 09:49:03 --> Helper loaded: url_helper
INFO - 2025-09-15 09:49:03 --> Helper loaded: text_helper
INFO - 2025-09-15 09:49:03 --> Helper loaded: string_helper
INFO - 2025-09-15 09:49:03 --> Helper loaded: form_helper
INFO - 2025-09-15 09:49:03 --> Helper loaded: download_helper
INFO - 2025-09-15 09:49:03 --> Helper loaded: security_helper
INFO - 2025-09-15 09:49:03 --> Database Driver Class Initialized
DEBUG - 2025-09-15 09:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 09:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 09:49:03 --> Form Validation Class Initialized
INFO - 2025-09-15 09:49:03 --> Model "User_model" initialized
INFO - 2025-09-15 14:49:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 14:49:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 14:49:03 --> Model "Nav_model" initialized
INFO - 2025-09-15 14:49:03 --> Controller Class Initialized
INFO - 2025-09-15 14:49:03 --> Model "Prodi_model" initialized
INFO - 2025-09-15 14:49:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 14:49:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-15 14:49:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-15 14:49:03 --> Model "Log_model" initialized
ERROR - 2025-09-15 14:49:03 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 14:49:03', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 'admin/prodi/edit/6', 'GET', 'Page accessed')
INFO - 2025-09-15 14:49:03 --> Final output sent to browser
DEBUG - 2025-09-15 14:49:03 --> Total execution time: 0.0705
INFO - 2025-09-15 11:28:33 --> Config Class Initialized
INFO - 2025-09-15 11:28:33 --> Hooks Class Initialized
DEBUG - 2025-09-15 11:28:33 --> UTF-8 Support Enabled
INFO - 2025-09-15 11:28:33 --> Utf8 Class Initialized
INFO - 2025-09-15 11:28:34 --> URI Class Initialized
DEBUG - 2025-09-15 11:28:34 --> No URI present. Default controller set.
INFO - 2025-09-15 11:28:34 --> Router Class Initialized
INFO - 2025-09-15 11:28:34 --> Output Class Initialized
INFO - 2025-09-15 11:28:34 --> Security Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 11:28:34 --> CSRF cookie sent
INFO - 2025-09-15 11:28:34 --> Input Class Initialized
INFO - 2025-09-15 11:28:34 --> Language Class Initialized
INFO - 2025-09-15 11:28:34 --> Loader Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: url_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: text_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: string_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: form_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: download_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: security_helper
INFO - 2025-09-15 11:28:34 --> Database Driver Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 11:28:34 --> Form Validation Class Initialized
INFO - 2025-09-15 11:28:34 --> Model "User_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Nav_model" initialized
INFO - 2025-09-15 16:28:34 --> Controller Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Berita_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Galeri_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Video_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Agenda_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Tautan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Mitra_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Prodi_model" initialized
INFO - 2025-09-15 16:28:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-15 16:28:34 --> Pagination Class Initialized
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-15 16:28:34 --> Model "Log_model" initialized
ERROR - 2025-09-15 16:28:34 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 16:28:34', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0', '', 'GET', 'Page accessed')
INFO - 2025-09-15 16:28:34 --> Final output sent to browser
DEBUG - 2025-09-15 16:28:34 --> Total execution time: 0.4312
INFO - 2025-09-15 11:28:34 --> Config Class Initialized
INFO - 2025-09-15 11:28:34 --> Hooks Class Initialized
DEBUG - 2025-09-15 11:28:34 --> UTF-8 Support Enabled
INFO - 2025-09-15 11:28:34 --> Utf8 Class Initialized
INFO - 2025-09-15 11:28:34 --> Config Class Initialized
INFO - 2025-09-15 11:28:34 --> Hooks Class Initialized
INFO - 2025-09-15 11:28:34 --> URI Class Initialized
INFO - 2025-09-15 11:28:34 --> Config Class Initialized
INFO - 2025-09-15 11:28:34 --> Config Class Initialized
INFO - 2025-09-15 11:28:34 --> Hooks Class Initialized
INFO - 2025-09-15 11:28:34 --> Hooks Class Initialized
INFO - 2025-09-15 11:28:34 --> Config Class Initialized
INFO - 2025-09-15 11:28:34 --> Hooks Class Initialized
INFO - 2025-09-15 11:28:34 --> Router Class Initialized
INFO - 2025-09-15 11:28:34 --> Config Class Initialized
INFO - 2025-09-15 11:28:34 --> Hooks Class Initialized
DEBUG - 2025-09-15 11:28:34 --> UTF-8 Support Enabled
INFO - 2025-09-15 11:28:34 --> Utf8 Class Initialized
DEBUG - 2025-09-15 11:28:34 --> UTF-8 Support Enabled
INFO - 2025-09-15 11:28:34 --> URI Class Initialized
INFO - 2025-09-15 11:28:34 --> Utf8 Class Initialized
INFO - 2025-09-15 11:28:34 --> Output Class Initialized
DEBUG - 2025-09-15 11:28:34 --> UTF-8 Support Enabled
INFO - 2025-09-15 11:28:34 --> Utf8 Class Initialized
DEBUG - 2025-09-15 11:28:34 --> UTF-8 Support Enabled
INFO - 2025-09-15 11:28:34 --> Router Class Initialized
INFO - 2025-09-15 11:28:34 --> Utf8 Class Initialized
INFO - 2025-09-15 11:28:34 --> URI Class Initialized
INFO - 2025-09-15 11:28:34 --> URI Class Initialized
INFO - 2025-09-15 11:28:34 --> URI Class Initialized
INFO - 2025-09-15 11:28:34 --> Security Class Initialized
INFO - 2025-09-15 11:28:34 --> Output Class Initialized
DEBUG - 2025-09-15 11:28:34 --> UTF-8 Support Enabled
INFO - 2025-09-15 11:28:34 --> Router Class Initialized
INFO - 2025-09-15 11:28:34 --> Utf8 Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 11:28:34 --> Router Class Initialized
INFO - 2025-09-15 11:28:34 --> CSRF cookie sent
INFO - 2025-09-15 11:28:34 --> Security Class Initialized
INFO - 2025-09-15 11:28:34 --> Input Class Initialized
INFO - 2025-09-15 11:28:34 --> Router Class Initialized
INFO - 2025-09-15 11:28:34 --> URI Class Initialized
INFO - 2025-09-15 11:28:34 --> Language Class Initialized
INFO - 2025-09-15 11:28:34 --> Output Class Initialized
INFO - 2025-09-15 11:28:34 --> Output Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 11:28:34 --> CSRF cookie sent
INFO - 2025-09-15 11:28:34 --> Input Class Initialized
INFO - 2025-09-15 11:28:34 --> Language Class Initialized
INFO - 2025-09-15 11:28:34 --> Router Class Initialized
INFO - 2025-09-15 11:28:34 --> Security Class Initialized
INFO - 2025-09-15 11:28:34 --> Security Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 11:28:34 --> Loader Class Initialized
INFO - 2025-09-15 11:28:34 --> Output Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 11:28:34 --> CSRF cookie sent
INFO - 2025-09-15 11:28:34 --> CSRF cookie sent
INFO - 2025-09-15 11:28:34 --> Input Class Initialized
INFO - 2025-09-15 11:28:34 --> Input Class Initialized
INFO - 2025-09-15 11:28:34 --> Output Class Initialized
INFO - 2025-09-15 11:28:34 --> Language Class Initialized
INFO - 2025-09-15 11:28:34 --> Language Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: url_helper
INFO - 2025-09-15 11:28:34 --> Security Class Initialized
INFO - 2025-09-15 11:28:34 --> Loader Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: text_helper
INFO - 2025-09-15 11:28:34 --> Security Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: string_helper
DEBUG - 2025-09-15 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 11:28:34 --> CSRF cookie sent
INFO - 2025-09-15 11:28:34 --> Helper loaded: url_helper
INFO - 2025-09-15 11:28:34 --> Input Class Initialized
INFO - 2025-09-15 11:28:34 --> Loader Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 11:28:34 --> Helper loaded: form_helper
INFO - 2025-09-15 11:28:34 --> CSRF cookie sent
INFO - 2025-09-15 11:28:34 --> Input Class Initialized
INFO - 2025-09-15 11:28:34 --> Loader Class Initialized
INFO - 2025-09-15 11:28:34 --> Language Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: download_helper
INFO - 2025-09-15 11:28:34 --> Language Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: url_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: url_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: security_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: text_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: text_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: string_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: string_helper
INFO - 2025-09-15 11:28:34 --> Loader Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: text_helper
INFO - 2025-09-15 11:28:34 --> Loader Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: string_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: form_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: form_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: url_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: url_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: download_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: download_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: text_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: text_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: form_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: security_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: security_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: string_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: download_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: string_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: security_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: form_helper
INFO - 2025-09-15 11:28:34 --> Database Driver Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: form_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: download_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: download_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: security_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: security_helper
INFO - 2025-09-15 11:28:34 --> Database Driver Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 11:28:34 --> Database Driver Class Initialized
INFO - 2025-09-15 11:28:34 --> Form Validation Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 11:28:34 --> Database Driver Class Initialized
INFO - 2025-09-15 11:28:34 --> Database Driver Class Initialized
INFO - 2025-09-15 11:28:34 --> Database Driver Class Initialized
INFO - 2025-09-15 11:28:34 --> Model "User_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Kunjungan_model" initialized
DEBUG - 2025-09-15 11:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 16:28:34 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-15 11:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 16:28:34 --> Model "Nav_model" initialized
INFO - 2025-09-15 16:28:34 --> Controller Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Berita_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Galeri_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Video_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Agenda_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Tautan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Mitra_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Prodi_model" initialized
DEBUG - 2025-09-15 11:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-15 11:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-15 16:28:34 --> Model "Log_model" initialized
ERROR - 2025-09-15 16:28:34 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 16:28:34', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0', 'assets/images/alumni/alumni2.jpg', 'GET', 'Page accessed')
INFO - 2025-09-15 16:28:34 --> Final output sent to browser
DEBUG - 2025-09-15 16:28:34 --> Total execution time: 0.1341
INFO - 2025-09-15 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 11:28:34 --> Form Validation Class Initialized
INFO - 2025-09-15 11:28:34 --> Model "User_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Nav_model" initialized
INFO - 2025-09-15 11:28:34 --> Config Class Initialized
INFO - 2025-09-15 16:28:34 --> Controller Class Initialized
INFO - 2025-09-15 11:28:34 --> Hooks Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Berita_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Galeri_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Video_model" initialized
DEBUG - 2025-09-15 11:28:34 --> UTF-8 Support Enabled
INFO - 2025-09-15 16:28:34 --> Model "Agenda_model" initialized
INFO - 2025-09-15 11:28:34 --> Utf8 Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Tautan_model" initialized
INFO - 2025-09-15 11:28:34 --> URI Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Mitra_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 11:28:34 --> Router Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Prodi_model" initialized
INFO - 2025-09-15 11:28:34 --> Output Class Initialized
INFO - 2025-09-15 11:28:34 --> Security Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 11:28:34 --> CSRF cookie sent
INFO - 2025-09-15 11:28:34 --> Input Class Initialized
INFO - 2025-09-15 11:28:34 --> Language Class Initialized
INFO - 2025-09-15 11:28:34 --> Loader Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: url_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: text_helper
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-15 11:28:34 --> Helper loaded: string_helper
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-15 11:28:34 --> Helper loaded: form_helper
INFO - 2025-09-15 16:28:34 --> Model "Log_model" initialized
ERROR - 2025-09-15 16:28:34 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 16:28:34', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0', 'assets/images/alumni/alumni1.jpg', 'GET', 'Page accessed')
INFO - 2025-09-15 11:28:34 --> Helper loaded: download_helper
INFO - 2025-09-15 16:28:34 --> Final output sent to browser
DEBUG - 2025-09-15 16:28:34 --> Total execution time: 0.1738
INFO - 2025-09-15 11:28:34 --> Helper loaded: security_helper
INFO - 2025-09-15 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 11:28:34 --> Form Validation Class Initialized
INFO - 2025-09-15 11:28:34 --> Model "User_model" initialized
INFO - 2025-09-15 11:28:34 --> Database Driver Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Nav_model" initialized
INFO - 2025-09-15 11:28:34 --> Config Class Initialized
INFO - 2025-09-15 16:28:34 --> Controller Class Initialized
INFO - 2025-09-15 11:28:34 --> Hooks Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Berita_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Galeri_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Video_model" initialized
DEBUG - 2025-09-15 11:28:34 --> UTF-8 Support Enabled
INFO - 2025-09-15 11:28:34 --> Utf8 Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Agenda_model" initialized
INFO - 2025-09-15 11:28:34 --> URI Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Tautan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Mitra_model" initialized
INFO - 2025-09-15 11:28:34 --> Router Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 16:28:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Prodi_model" initialized
INFO - 2025-09-15 11:28:34 --> Output Class Initialized
INFO - 2025-09-15 11:28:34 --> Security Class Initialized
DEBUG - 2025-09-15 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 11:28:34 --> CSRF cookie sent
INFO - 2025-09-15 11:28:34 --> Input Class Initialized
INFO - 2025-09-15 11:28:34 --> Language Class Initialized
INFO - 2025-09-15 11:28:34 --> Loader Class Initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: url_helper
INFO - 2025-09-15 11:28:34 --> Helper loaded: text_helper
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-15 11:28:34 --> Helper loaded: string_helper
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-15 16:28:34 --> Model "Log_model" initialized
INFO - 2025-09-15 11:28:34 --> Helper loaded: form_helper
ERROR - 2025-09-15 16:28:34 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 16:28:34', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0', 'assets/images/alumni/alumni5.jpg', 'GET', 'Page accessed')
INFO - 2025-09-15 16:28:34 --> Final output sent to browser
INFO - 2025-09-15 11:28:34 --> Helper loaded: download_helper
DEBUG - 2025-09-15 16:28:34 --> Total execution time: 0.2213
INFO - 2025-09-15 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 11:28:34 --> Helper loaded: security_helper
INFO - 2025-09-15 11:28:34 --> Form Validation Class Initialized
INFO - 2025-09-15 11:28:34 --> Model "User_model" initialized
INFO - 2025-09-15 11:28:34 --> Database Driver Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Nav_model" initialized
INFO - 2025-09-15 16:28:34 --> Controller Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Berita_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Galeri_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Video_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Agenda_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Tautan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Mitra_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Prodi_model" initialized
DEBUG - 2025-09-15 11:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-15 16:28:34 --> Model "Log_model" initialized
ERROR - 2025-09-15 16:28:34 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 16:28:34', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0', 'assets/images/alumni/alumni4.jpg', 'GET', 'Page accessed')
INFO - 2025-09-15 16:28:34 --> Final output sent to browser
DEBUG - 2025-09-15 16:28:34 --> Total execution time: 0.2806
INFO - 2025-09-15 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 11:28:34 --> Form Validation Class Initialized
INFO - 2025-09-15 11:28:34 --> Model "User_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Nav_model" initialized
INFO - 2025-09-15 16:28:34 --> Controller Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Berita_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Galeri_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Video_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Agenda_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Tautan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Mitra_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Prodi_model" initialized
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-15 16:28:34 --> Model "Log_model" initialized
ERROR - 2025-09-15 16:28:34 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 16:28:34', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0', 'assets/images/alumni/alumni6.jpg', 'GET', 'Page accessed')
INFO - 2025-09-15 16:28:34 --> Final output sent to browser
DEBUG - 2025-09-15 16:28:34 --> Total execution time: 0.3372
INFO - 2025-09-15 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 11:28:34 --> Form Validation Class Initialized
INFO - 2025-09-15 11:28:34 --> Model "User_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Nav_model" initialized
INFO - 2025-09-15 16:28:34 --> Controller Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Berita_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Galeri_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Video_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Agenda_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Tautan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Mitra_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Prodi_model" initialized
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-15 16:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-15 16:28:34 --> Model "Log_model" initialized
ERROR - 2025-09-15 16:28:34 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 16:28:34', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0', 'assets/images/alumni/alumni3.jpg', 'GET', 'Page accessed')
INFO - 2025-09-15 16:28:34 --> Final output sent to browser
DEBUG - 2025-09-15 16:28:34 --> Total execution time: 0.4041
INFO - 2025-09-15 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 11:28:34 --> Form Validation Class Initialized
INFO - 2025-09-15 11:28:34 --> Model "User_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Nav_model" initialized
INFO - 2025-09-15 16:28:34 --> Controller Class Initialized
INFO - 2025-09-15 16:28:34 --> Model "Berita_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Galeri_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Video_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Agenda_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Tautan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Mitra_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 16:28:34 --> Model "Prodi_model" initialized
INFO - 2025-09-15 16:28:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-15 16:28:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-15 16:28:35 --> Model "Log_model" initialized
ERROR - 2025-09-15 16:28:35 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 16:28:35', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0', 'assets/images/alumni/alumni7.jpg', 'GET', 'Page accessed')
INFO - 2025-09-15 16:28:35 --> Final output sent to browser
DEBUG - 2025-09-15 16:28:35 --> Total execution time: 0.3246
INFO - 2025-09-15 11:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 11:28:35 --> Form Validation Class Initialized
INFO - 2025-09-15 11:28:35 --> Model "User_model" initialized
INFO - 2025-09-15 16:28:35 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 16:28:35 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 16:28:35 --> Model "Nav_model" initialized
INFO - 2025-09-15 16:28:35 --> Controller Class Initialized
INFO - 2025-09-15 16:28:35 --> Model "Berita_model" initialized
INFO - 2025-09-15 16:28:35 --> Model "Galeri_model" initialized
INFO - 2025-09-15 16:28:35 --> Model "Video_model" initialized
INFO - 2025-09-15 16:28:35 --> Model "Agenda_model" initialized
INFO - 2025-09-15 16:28:35 --> Model "Tautan_model" initialized
INFO - 2025-09-15 16:28:35 --> Model "Mitra_model" initialized
INFO - 2025-09-15 16:28:35 --> Model "Jurusan_model" initialized
INFO - 2025-09-15 16:28:35 --> Model "Prodi_model" initialized
INFO - 2025-09-15 16:28:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-15 16:28:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-15 16:28:35 --> Model "Log_model" initialized
ERROR - 2025-09-15 16:28:35 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 16:28:35', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0', 'assets/images/alumni/alumni8.jpg', 'GET', 'Page accessed')
INFO - 2025-09-15 16:28:35 --> Final output sent to browser
DEBUG - 2025-09-15 16:28:35 --> Total execution time: 0.3462
INFO - 2025-09-15 11:29:09 --> Config Class Initialized
INFO - 2025-09-15 11:29:09 --> Hooks Class Initialized
DEBUG - 2025-09-15 11:29:09 --> UTF-8 Support Enabled
INFO - 2025-09-15 11:29:09 --> Utf8 Class Initialized
INFO - 2025-09-15 11:29:09 --> URI Class Initialized
INFO - 2025-09-15 11:29:09 --> Router Class Initialized
INFO - 2025-09-15 11:29:09 --> Output Class Initialized
INFO - 2025-09-15 11:29:09 --> Security Class Initialized
DEBUG - 2025-09-15 11:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-15 11:29:09 --> CSRF cookie sent
INFO - 2025-09-15 11:29:09 --> Input Class Initialized
INFO - 2025-09-15 11:29:09 --> Language Class Initialized
INFO - 2025-09-15 11:29:09 --> Loader Class Initialized
INFO - 2025-09-15 11:29:09 --> Helper loaded: url_helper
INFO - 2025-09-15 11:29:09 --> Helper loaded: text_helper
INFO - 2025-09-15 11:29:09 --> Helper loaded: string_helper
INFO - 2025-09-15 11:29:09 --> Helper loaded: form_helper
INFO - 2025-09-15 11:29:09 --> Helper loaded: download_helper
INFO - 2025-09-15 11:29:09 --> Helper loaded: security_helper
INFO - 2025-09-15 11:29:09 --> Database Driver Class Initialized
DEBUG - 2025-09-15 11:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-15 11:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-15 11:29:09 --> Form Validation Class Initialized
INFO - 2025-09-15 11:29:09 --> Model "User_model" initialized
INFO - 2025-09-15 16:29:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-15 16:29:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-15 16:29:09 --> Model "Nav_model" initialized
INFO - 2025-09-15 16:29:09 --> Controller Class Initialized
DEBUG - 2025-09-15 16:29:09 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-15 16:29:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-15 16:29:09 --> Model "Log_model" initialized
ERROR - 2025-09-15 16:29:09 --> Query error: Table 'access_logs' is read only - Invalid query: INSERT INTO `access_logs` (`timestamp`, `ip_address`, `user_agent`, `uri`, `method`, `message`) VALUES ('2025-09-15 16:29:09', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 'login', 'GET', 'Page accessed')
INFO - 2025-09-15 16:29:09 --> Final output sent to browser
DEBUG - 2025-09-15 16:29:09 --> Total execution time: 0.1355
