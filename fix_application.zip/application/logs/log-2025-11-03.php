<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-03 02:54:44 --> Config Class Initialized
INFO - 2025-11-03 02:54:44 --> Hooks Class Initialized
DEBUG - 2025-11-03 02:54:44 --> UTF-8 Support Enabled
INFO - 2025-11-03 02:54:44 --> Utf8 Class Initialized
INFO - 2025-11-03 02:54:44 --> URI Class Initialized
DEBUG - 2025-11-03 02:54:44 --> No URI present. Default controller set.
INFO - 2025-11-03 02:54:44 --> Router Class Initialized
INFO - 2025-11-03 02:54:44 --> Output Class Initialized
INFO - 2025-11-03 02:54:45 --> Security Class Initialized
DEBUG - 2025-11-03 02:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-03 02:54:45 --> CSRF cookie sent
INFO - 2025-11-03 02:54:45 --> Input Class Initialized
INFO - 2025-11-03 02:54:45 --> Language Class Initialized
INFO - 2025-11-03 02:54:45 --> Loader Class Initialized
INFO - 2025-11-03 02:54:45 --> Helper loaded: url_helper
INFO - 2025-11-03 02:54:45 --> Helper loaded: text_helper
INFO - 2025-11-03 02:54:45 --> Helper loaded: string_helper
INFO - 2025-11-03 02:54:45 --> Helper loaded: form_helper
INFO - 2025-11-03 02:54:45 --> Helper loaded: download_helper
INFO - 2025-11-03 02:54:45 --> Helper loaded: security_helper
INFO - 2025-11-03 02:54:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-03 02:54:46 --> Database Driver Class Initialized
DEBUG - 2025-11-03 02:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-03 02:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-03 02:54:46 --> Form Validation Class Initialized
INFO - 2025-11-03 02:54:46 --> Model "User_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Kunjungan_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Nav_model" initialized
INFO - 2025-11-03 08:54:47 --> Controller Class Initialized
INFO - 2025-11-03 08:54:47 --> Model "Berita_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Galeri_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Video_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Agenda_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Tautan_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Mitra_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Jurusan_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Prodi_model" initialized
INFO - 2025-11-03 08:54:47 --> Model "Testimoni_model" initialized
INFO - 2025-11-03 08:54:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-03 08:54:48 --> Pagination Class Initialized
INFO - 2025-11-03 08:54:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-03 08:54:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-03 08:54:51 --> Model "Log_model" initialized
INFO - 2025-11-03 08:54:51 --> Final output sent to browser
DEBUG - 2025-11-03 08:54:51 --> Total execution time: 7.5178
INFO - 2025-11-03 02:55:19 --> Config Class Initialized
INFO - 2025-11-03 02:55:19 --> Hooks Class Initialized
DEBUG - 2025-11-03 02:55:19 --> UTF-8 Support Enabled
INFO - 2025-11-03 02:55:19 --> Utf8 Class Initialized
INFO - 2025-11-03 02:55:19 --> URI Class Initialized
INFO - 2025-11-03 02:55:19 --> Router Class Initialized
INFO - 2025-11-03 02:55:19 --> Output Class Initialized
INFO - 2025-11-03 02:55:19 --> Security Class Initialized
DEBUG - 2025-11-03 02:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-03 02:55:19 --> CSRF cookie sent
INFO - 2025-11-03 02:55:19 --> Input Class Initialized
INFO - 2025-11-03 02:55:19 --> Language Class Initialized
INFO - 2025-11-03 02:55:19 --> Loader Class Initialized
INFO - 2025-11-03 02:55:19 --> Helper loaded: url_helper
INFO - 2025-11-03 02:55:19 --> Helper loaded: text_helper
INFO - 2025-11-03 02:55:19 --> Helper loaded: string_helper
INFO - 2025-11-03 02:55:19 --> Helper loaded: form_helper
INFO - 2025-11-03 02:55:19 --> Helper loaded: download_helper
INFO - 2025-11-03 02:55:19 --> Helper loaded: security_helper
INFO - 2025-11-03 02:55:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-03 02:55:19 --> Database Driver Class Initialized
DEBUG - 2025-11-03 02:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-03 02:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-03 02:55:19 --> Form Validation Class Initialized
INFO - 2025-11-03 02:55:19 --> Model "User_model" initialized
INFO - 2025-11-03 08:55:19 --> Model "Kunjungan_model" initialized
INFO - 2025-11-03 08:55:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-03 08:55:19 --> Model "Nav_model" initialized
INFO - 2025-11-03 08:55:19 --> Controller Class Initialized
INFO - 2025-11-03 08:55:19 --> Model "Pages_model" initialized
INFO - 2025-11-03 08:55:19 --> Model "Berita_model" initialized
INFO - 2025-11-03 08:55:19 --> Model "Download_model" initialized
INFO - 2025-11-03 08:55:19 --> Model "Kategori_download_model" initialized
INFO - 2025-11-03 08:55:19 --> Model "Jenis_download_model" initialized
INFO - 2025-11-03 08:55:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2025-11-03 08:55:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-03 08:55:19 --> Model "Log_model" initialized
INFO - 2025-11-03 08:55:19 --> Final output sent to browser
DEBUG - 2025-11-03 08:55:19 --> Total execution time: 0.3954
INFO - 2025-11-03 02:55:45 --> Config Class Initialized
INFO - 2025-11-03 02:55:45 --> Hooks Class Initialized
DEBUG - 2025-11-03 02:55:45 --> UTF-8 Support Enabled
INFO - 2025-11-03 02:55:45 --> Utf8 Class Initialized
INFO - 2025-11-03 02:55:45 --> URI Class Initialized
INFO - 2025-11-03 02:55:45 --> Router Class Initialized
INFO - 2025-11-03 02:55:45 --> Output Class Initialized
INFO - 2025-11-03 02:55:45 --> Security Class Initialized
DEBUG - 2025-11-03 02:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-03 02:55:45 --> CSRF cookie sent
INFO - 2025-11-03 02:55:45 --> Input Class Initialized
INFO - 2025-11-03 02:55:45 --> Language Class Initialized
INFO - 2025-11-03 02:55:45 --> Loader Class Initialized
INFO - 2025-11-03 02:55:45 --> Helper loaded: url_helper
INFO - 2025-11-03 02:55:45 --> Helper loaded: text_helper
INFO - 2025-11-03 02:55:45 --> Helper loaded: string_helper
INFO - 2025-11-03 02:55:45 --> Helper loaded: form_helper
INFO - 2025-11-03 02:55:45 --> Helper loaded: download_helper
INFO - 2025-11-03 02:55:45 --> Helper loaded: security_helper
INFO - 2025-11-03 02:55:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-03 02:55:45 --> Database Driver Class Initialized
DEBUG - 2025-11-03 02:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-03 02:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-03 02:55:45 --> Form Validation Class Initialized
INFO - 2025-11-03 02:55:45 --> Model "User_model" initialized
INFO - 2025-11-03 08:55:45 --> Model "Kunjungan_model" initialized
INFO - 2025-11-03 08:55:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-03 08:55:45 --> Model "Nav_model" initialized
INFO - 2025-11-03 08:55:45 --> Controller Class Initialized
INFO - 2025-11-03 08:55:45 --> Model "Pages_model" initialized
INFO - 2025-11-03 08:55:45 --> Model "Berita_model" initialized
INFO - 2025-11-03 08:55:45 --> Model "Download_model" initialized
INFO - 2025-11-03 08:55:45 --> Model "Kategori_download_model" initialized
INFO - 2025-11-03 08:55:45 --> Model "Jenis_download_model" initialized
INFO - 2025-11-03 08:55:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-11-03 08:55:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-03 08:55:45 --> Model "Log_model" initialized
INFO - 2025-11-03 08:55:45 --> Final output sent to browser
DEBUG - 2025-11-03 08:55:45 --> Total execution time: 0.0739
INFO - 2025-11-03 02:58:53 --> Config Class Initialized
INFO - 2025-11-03 02:58:53 --> Hooks Class Initialized
DEBUG - 2025-11-03 02:58:53 --> UTF-8 Support Enabled
INFO - 2025-11-03 02:58:53 --> Utf8 Class Initialized
INFO - 2025-11-03 02:58:53 --> URI Class Initialized
DEBUG - 2025-11-03 02:58:53 --> No URI present. Default controller set.
INFO - 2025-11-03 02:58:53 --> Router Class Initialized
INFO - 2025-11-03 02:58:53 --> Output Class Initialized
INFO - 2025-11-03 02:58:53 --> Security Class Initialized
DEBUG - 2025-11-03 02:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-03 02:58:53 --> CSRF cookie sent
INFO - 2025-11-03 02:58:53 --> Input Class Initialized
INFO - 2025-11-03 02:58:53 --> Language Class Initialized
INFO - 2025-11-03 02:58:53 --> Loader Class Initialized
INFO - 2025-11-03 02:58:53 --> Helper loaded: url_helper
INFO - 2025-11-03 02:58:53 --> Helper loaded: text_helper
INFO - 2025-11-03 02:58:53 --> Helper loaded: string_helper
INFO - 2025-11-03 02:58:53 --> Helper loaded: form_helper
INFO - 2025-11-03 02:58:53 --> Helper loaded: download_helper
INFO - 2025-11-03 02:58:53 --> Helper loaded: security_helper
INFO - 2025-11-03 02:58:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-03 02:58:53 --> Database Driver Class Initialized
DEBUG - 2025-11-03 02:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-03 02:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-03 02:58:53 --> Form Validation Class Initialized
INFO - 2025-11-03 02:58:53 --> Model "User_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Kunjungan_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Nav_model" initialized
INFO - 2025-11-03 08:58:53 --> Controller Class Initialized
INFO - 2025-11-03 08:58:53 --> Model "Berita_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Galeri_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Video_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Agenda_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Tautan_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Mitra_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Jurusan_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Prodi_model" initialized
INFO - 2025-11-03 08:58:53 --> Model "Testimoni_model" initialized
INFO - 2025-11-03 08:58:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-03 08:58:53 --> Pagination Class Initialized
INFO - 2025-11-03 08:58:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-03 08:58:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-03 08:58:53 --> Model "Log_model" initialized
INFO - 2025-11-03 08:58:53 --> Final output sent to browser
DEBUG - 2025-11-03 08:58:53 --> Total execution time: 0.1195
INFO - 2025-11-03 02:59:25 --> Config Class Initialized
INFO - 2025-11-03 02:59:25 --> Hooks Class Initialized
DEBUG - 2025-11-03 02:59:25 --> UTF-8 Support Enabled
INFO - 2025-11-03 02:59:25 --> Utf8 Class Initialized
INFO - 2025-11-03 02:59:25 --> URI Class Initialized
DEBUG - 2025-11-03 02:59:25 --> No URI present. Default controller set.
INFO - 2025-11-03 02:59:25 --> Router Class Initialized
INFO - 2025-11-03 02:59:25 --> Output Class Initialized
INFO - 2025-11-03 02:59:25 --> Security Class Initialized
DEBUG - 2025-11-03 02:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-03 02:59:25 --> CSRF cookie sent
INFO - 2025-11-03 02:59:25 --> Input Class Initialized
INFO - 2025-11-03 02:59:25 --> Language Class Initialized
INFO - 2025-11-03 02:59:25 --> Loader Class Initialized
INFO - 2025-11-03 02:59:25 --> Helper loaded: url_helper
INFO - 2025-11-03 02:59:25 --> Helper loaded: text_helper
INFO - 2025-11-03 02:59:25 --> Helper loaded: string_helper
INFO - 2025-11-03 02:59:25 --> Helper loaded: form_helper
INFO - 2025-11-03 02:59:25 --> Helper loaded: download_helper
INFO - 2025-11-03 02:59:25 --> Helper loaded: security_helper
INFO - 2025-11-03 02:59:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-03 02:59:25 --> Database Driver Class Initialized
DEBUG - 2025-11-03 02:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-03 02:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-03 02:59:25 --> Form Validation Class Initialized
INFO - 2025-11-03 02:59:25 --> Model "User_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Kunjungan_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Nav_model" initialized
INFO - 2025-11-03 08:59:25 --> Controller Class Initialized
INFO - 2025-11-03 08:59:25 --> Model "Berita_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Galeri_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Video_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Agenda_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Tautan_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Mitra_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Jurusan_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Prodi_model" initialized
INFO - 2025-11-03 08:59:25 --> Model "Testimoni_model" initialized
INFO - 2025-11-03 08:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-03 08:59:25 --> Pagination Class Initialized
INFO - 2025-11-03 08:59:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-03 08:59:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-03 08:59:25 --> Model "Log_model" initialized
INFO - 2025-11-03 08:59:25 --> Final output sent to browser
DEBUG - 2025-11-03 08:59:25 --> Total execution time: 0.0837
