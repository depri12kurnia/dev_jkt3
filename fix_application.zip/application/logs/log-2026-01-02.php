<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-02 08:37:26 --> Config Class Initialized
INFO - 2026-01-02 08:37:26 --> Hooks Class Initialized
DEBUG - 2026-01-02 08:37:26 --> UTF-8 Support Enabled
INFO - 2026-01-02 08:37:26 --> Utf8 Class Initialized
INFO - 2026-01-02 08:37:26 --> URI Class Initialized
DEBUG - 2026-01-02 08:37:26 --> No URI present. Default controller set.
INFO - 2026-01-02 08:37:26 --> Router Class Initialized
INFO - 2026-01-02 08:37:26 --> Output Class Initialized
INFO - 2026-01-02 08:37:26 --> Security Class Initialized
DEBUG - 2026-01-02 08:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-02 08:37:27 --> CSRF cookie sent
INFO - 2026-01-02 08:37:27 --> Input Class Initialized
INFO - 2026-01-02 08:37:27 --> Language Class Initialized
INFO - 2026-01-02 08:37:27 --> Loader Class Initialized
INFO - 2026-01-02 08:37:27 --> Helper loaded: url_helper
INFO - 2026-01-02 08:37:27 --> Helper loaded: text_helper
INFO - 2026-01-02 08:37:27 --> Helper loaded: string_helper
INFO - 2026-01-02 08:37:27 --> Helper loaded: form_helper
INFO - 2026-01-02 08:37:27 --> Helper loaded: download_helper
INFO - 2026-01-02 08:37:27 --> Helper loaded: security_helper
INFO - 2026-01-02 08:37:27 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-02 08:37:28 --> Database Driver Class Initialized
DEBUG - 2026-01-02 08:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-02 08:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-02 08:37:28 --> Form Validation Class Initialized
INFO - 2026-01-02 08:37:28 --> Model "User_model" initialized
INFO - 2026-01-02 14:37:28 --> Model "Kunjungan_model" initialized
INFO - 2026-01-02 14:37:28 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-02 14:37:29 --> Model "Nav_model" initialized
INFO - 2026-01-02 14:37:29 --> Controller Class Initialized
INFO - 2026-01-02 14:37:29 --> Model "Berita_model" initialized
INFO - 2026-01-02 14:37:29 --> Model "Galeri_model" initialized
INFO - 2026-01-02 14:37:29 --> Model "Video_model" initialized
INFO - 2026-01-02 14:37:29 --> Model "Agenda_model" initialized
INFO - 2026-01-02 14:37:29 --> Model "Tautan_model" initialized
INFO - 2026-01-02 14:37:29 --> Model "Mitra_model" initialized
INFO - 2026-01-02 14:37:29 --> Model "Jurusan_model" initialized
INFO - 2026-01-02 14:37:29 --> Model "Prodi_model" initialized
INFO - 2026-01-02 14:37:29 --> Model "Testimoni_model" initialized
INFO - 2026-01-02 14:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-02 14:37:30 --> Pagination Class Initialized
INFO - 2026-01-02 14:37:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-02 14:37:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-02 14:37:34 --> Model "Log_model" initialized
INFO - 2026-01-02 14:37:34 --> Final output sent to browser
DEBUG - 2026-01-02 14:37:34 --> Total execution time: 7.8548
