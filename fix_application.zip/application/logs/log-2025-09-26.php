<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-09-26 04:25:47 --> Config Class Initialized
INFO - 2025-09-26 04:25:47 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:25:48 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:25:48 --> Utf8 Class Initialized
INFO - 2025-09-26 04:25:48 --> URI Class Initialized
DEBUG - 2025-09-26 04:25:48 --> No URI present. Default controller set.
INFO - 2025-09-26 04:25:48 --> Router Class Initialized
INFO - 2025-09-26 04:25:48 --> Output Class Initialized
INFO - 2025-09-26 04:25:48 --> Security Class Initialized
DEBUG - 2025-09-26 04:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:25:48 --> CSRF cookie sent
INFO - 2025-09-26 04:25:48 --> Input Class Initialized
INFO - 2025-09-26 04:25:49 --> Language Class Initialized
INFO - 2025-09-26 04:25:49 --> Loader Class Initialized
INFO - 2025-09-26 04:25:49 --> Helper loaded: url_helper
INFO - 2025-09-26 04:25:49 --> Helper loaded: text_helper
INFO - 2025-09-26 04:25:49 --> Helper loaded: string_helper
INFO - 2025-09-26 04:25:49 --> Helper loaded: form_helper
INFO - 2025-09-26 04:25:49 --> Helper loaded: download_helper
INFO - 2025-09-26 04:25:49 --> Helper loaded: security_helper
INFO - 2025-09-26 04:25:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:25:50 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:25:50 --> Form Validation Class Initialized
INFO - 2025-09-26 04:25:51 --> Model "User_model" initialized
INFO - 2025-09-26 09:25:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:25:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:25:51 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:25:51 --> Controller Class Initialized
INFO - 2025-09-26 09:25:51 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:25:51 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:25:51 --> Model "Video_model" initialized
INFO - 2025-09-26 09:25:52 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:25:52 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:25:52 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:25:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:25:52 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:25:52 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:25:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:25:52 --> Pagination Class Initialized
INFO - 2025-09-26 09:25:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-26 09:25:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 09:25:55 --> Model "Log_model" initialized
INFO - 2025-09-26 09:25:55 --> Final output sent to browser
DEBUG - 2025-09-26 09:25:55 --> Total execution time: 7.7890
INFO - 2025-09-26 04:25:55 --> Config Class Initialized
INFO - 2025-09-26 04:25:55 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:25:55 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:25:55 --> Utf8 Class Initialized
INFO - 2025-09-26 04:25:55 --> URI Class Initialized
INFO - 2025-09-26 04:25:55 --> Router Class Initialized
INFO - 2025-09-26 04:25:55 --> Output Class Initialized
INFO - 2025-09-26 04:25:55 --> Security Class Initialized
DEBUG - 2025-09-26 04:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:25:55 --> CSRF cookie sent
INFO - 2025-09-26 04:25:55 --> Input Class Initialized
INFO - 2025-09-26 04:25:55 --> Language Class Initialized
INFO - 2025-09-26 04:25:55 --> Loader Class Initialized
INFO - 2025-09-26 04:25:55 --> Helper loaded: url_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: text_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: string_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: form_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: download_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: security_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:25:55 --> Database Driver Class Initialized
INFO - 2025-09-26 04:25:55 --> Config Class Initialized
INFO - 2025-09-26 04:25:55 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:25:55 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:25:55 --> Utf8 Class Initialized
INFO - 2025-09-26 04:25:55 --> URI Class Initialized
INFO - 2025-09-26 04:25:55 --> Router Class Initialized
INFO - 2025-09-26 04:25:55 --> Output Class Initialized
INFO - 2025-09-26 04:25:55 --> Security Class Initialized
DEBUG - 2025-09-26 04:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:25:55 --> CSRF cookie sent
INFO - 2025-09-26 04:25:55 --> Input Class Initialized
INFO - 2025-09-26 04:25:55 --> Language Class Initialized
INFO - 2025-09-26 04:25:55 --> Loader Class Initialized
DEBUG - 2025-09-26 04:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:25:55 --> Helper loaded: url_helper
INFO - 2025-09-26 04:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:25:55 --> Helper loaded: text_helper
INFO - 2025-09-26 04:25:55 --> Form Validation Class Initialized
INFO - 2025-09-26 04:25:55 --> Helper loaded: string_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: form_helper
INFO - 2025-09-26 04:25:55 --> Model "User_model" initialized
INFO - 2025-09-26 04:25:55 --> Helper loaded: download_helper
INFO - 2025-09-26 09:25:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 04:25:55 --> Helper loaded: security_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 09:25:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:25:55 --> Controller Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Video_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Mitra_model" initialized
INFO - 2025-09-26 04:25:55 --> Database Driver Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:25:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-26 09:25:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 09:25:55 --> Model "Log_model" initialized
INFO - 2025-09-26 09:25:55 --> Final output sent to browser
DEBUG - 2025-09-26 09:25:55 --> Total execution time: 0.0676
DEBUG - 2025-09-26 04:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:25:55 --> Form Validation Class Initialized
INFO - 2025-09-26 04:25:55 --> Model "User_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:25:55 --> Controller Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Video_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 04:25:55 --> Config Class Initialized
INFO - 2025-09-26 04:25:55 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:25:55 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:25:55 --> Utf8 Class Initialized
INFO - 2025-09-26 04:25:55 --> URI Class Initialized
INFO - 2025-09-26 04:25:55 --> Router Class Initialized
INFO - 2025-09-26 04:25:55 --> Output Class Initialized
INFO - 2025-09-26 04:25:55 --> Security Class Initialized
DEBUG - 2025-09-26 04:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:25:55 --> CSRF cookie sent
INFO - 2025-09-26 04:25:55 --> Input Class Initialized
INFO - 2025-09-26 04:25:55 --> Language Class Initialized
INFO - 2025-09-26 04:25:55 --> Loader Class Initialized
INFO - 2025-09-26 09:25:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-26 09:25:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 04:25:55 --> Helper loaded: url_helper
INFO - 2025-09-26 09:25:55 --> Model "Log_model" initialized
INFO - 2025-09-26 04:25:55 --> Helper loaded: text_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: string_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: form_helper
INFO - 2025-09-26 09:25:55 --> Final output sent to browser
DEBUG - 2025-09-26 09:25:55 --> Total execution time: 0.0707
INFO - 2025-09-26 04:25:55 --> Helper loaded: download_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: security_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:25:55 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:25:55 --> Config Class Initialized
INFO - 2025-09-26 04:25:55 --> Hooks Class Initialized
INFO - 2025-09-26 04:25:55 --> Form Validation Class Initialized
INFO - 2025-09-26 04:25:55 --> Model "User_model" initialized
DEBUG - 2025-09-26 04:25:55 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:25:55 --> Utf8 Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 04:25:55 --> URI Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 04:25:55 --> Router Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:25:55 --> Controller Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Berita_model" initialized
INFO - 2025-09-26 04:25:55 --> Output Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Video_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Agenda_model" initialized
INFO - 2025-09-26 04:25:55 --> Security Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Mitra_model" initialized
DEBUG - 2025-09-26 04:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:25:55 --> CSRF cookie sent
INFO - 2025-09-26 04:25:55 --> Input Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 04:25:55 --> Language Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:25:55 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 04:25:55 --> Loader Class Initialized
INFO - 2025-09-26 04:25:55 --> Helper loaded: url_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: text_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: string_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: form_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: download_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: security_helper
INFO - 2025-09-26 04:25:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 09:25:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-26 09:25:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 04:25:55 --> Database Driver Class Initialized
INFO - 2025-09-26 09:25:55 --> Model "Log_model" initialized
INFO - 2025-09-26 09:25:55 --> Final output sent to browser
DEBUG - 2025-09-26 09:25:55 --> Total execution time: 0.0456
INFO - 2025-09-26 04:25:56 --> Config Class Initialized
INFO - 2025-09-26 04:25:56 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:25:56 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:25:56 --> Utf8 Class Initialized
INFO - 2025-09-26 04:25:56 --> URI Class Initialized
INFO - 2025-09-26 04:25:56 --> Router Class Initialized
INFO - 2025-09-26 04:25:56 --> Output Class Initialized
INFO - 2025-09-26 04:25:56 --> Security Class Initialized
DEBUG - 2025-09-26 04:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:25:56 --> CSRF cookie sent
INFO - 2025-09-26 04:25:56 --> Input Class Initialized
INFO - 2025-09-26 04:25:56 --> Language Class Initialized
INFO - 2025-09-26 04:25:56 --> Loader Class Initialized
INFO - 2025-09-26 04:25:56 --> Helper loaded: url_helper
INFO - 2025-09-26 04:25:56 --> Helper loaded: text_helper
INFO - 2025-09-26 04:25:56 --> Helper loaded: string_helper
INFO - 2025-09-26 04:25:56 --> Helper loaded: form_helper
INFO - 2025-09-26 04:25:56 --> Helper loaded: download_helper
INFO - 2025-09-26 04:25:56 --> Helper loaded: security_helper
INFO - 2025-09-26 04:25:56 --> Helper loaded: image_optimizer_helper
DEBUG - 2025-09-26 04:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:25:56 --> Database Driver Class Initialized
INFO - 2025-09-26 04:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:25:56 --> Form Validation Class Initialized
INFO - 2025-09-26 04:25:56 --> Model "User_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:25:56 --> Controller Class Initialized
INFO - 2025-09-26 09:25:56 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Video_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:25:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-26 09:25:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 09:25:56 --> Model "Log_model" initialized
DEBUG - 2025-09-26 04:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 09:25:56 --> Final output sent to browser
DEBUG - 2025-09-26 09:25:56 --> Total execution time: 0.0653
INFO - 2025-09-26 04:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:25:56 --> Form Validation Class Initialized
INFO - 2025-09-26 04:25:56 --> Model "User_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:25:56 --> Controller Class Initialized
INFO - 2025-09-26 09:25:56 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Video_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Agenda_model" initialized
INFO - 2025-09-26 04:25:56 --> Config Class Initialized
INFO - 2025-09-26 04:25:56 --> Hooks Class Initialized
INFO - 2025-09-26 09:25:56 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Prodi_model" initialized
DEBUG - 2025-09-26 04:25:56 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:25:56 --> Utf8 Class Initialized
INFO - 2025-09-26 09:25:56 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 04:25:56 --> URI Class Initialized
INFO - 2025-09-26 04:25:56 --> Router Class Initialized
INFO - 2025-09-26 04:25:56 --> Output Class Initialized
INFO - 2025-09-26 04:25:56 --> Security Class Initialized
DEBUG - 2025-09-26 04:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:25:56 --> CSRF cookie sent
INFO - 2025-09-26 04:25:56 --> Input Class Initialized
INFO - 2025-09-26 04:25:56 --> Language Class Initialized
INFO - 2025-09-26 04:25:56 --> Loader Class Initialized
INFO - 2025-09-26 09:25:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-26 09:25:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 04:25:56 --> Helper loaded: url_helper
INFO - 2025-09-26 09:25:56 --> Model "Log_model" initialized
INFO - 2025-09-26 04:25:56 --> Helper loaded: text_helper
INFO - 2025-09-26 04:25:56 --> Helper loaded: string_helper
INFO - 2025-09-26 09:25:56 --> Final output sent to browser
INFO - 2025-09-26 04:25:56 --> Helper loaded: form_helper
DEBUG - 2025-09-26 09:25:56 --> Total execution time: 0.0552
INFO - 2025-09-26 04:25:56 --> Helper loaded: download_helper
INFO - 2025-09-26 04:25:56 --> Helper loaded: security_helper
INFO - 2025-09-26 04:25:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:25:56 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:25:56 --> Form Validation Class Initialized
INFO - 2025-09-26 04:25:56 --> Model "User_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:25:56 --> Controller Class Initialized
INFO - 2025-09-26 09:25:56 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Video_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:25:56 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:25:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-26 09:25:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 09:25:56 --> Model "Log_model" initialized
INFO - 2025-09-26 09:25:56 --> Final output sent to browser
DEBUG - 2025-09-26 09:25:56 --> Total execution time: 0.0418
INFO - 2025-09-26 04:26:05 --> Config Class Initialized
INFO - 2025-09-26 04:26:05 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:26:05 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:26:05 --> Utf8 Class Initialized
INFO - 2025-09-26 04:26:05 --> URI Class Initialized
INFO - 2025-09-26 04:26:05 --> Router Class Initialized
INFO - 2025-09-26 04:26:05 --> Output Class Initialized
INFO - 2025-09-26 04:26:05 --> Security Class Initialized
DEBUG - 2025-09-26 04:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:26:05 --> CSRF cookie sent
INFO - 2025-09-26 04:26:05 --> Input Class Initialized
INFO - 2025-09-26 04:26:05 --> Language Class Initialized
INFO - 2025-09-26 04:26:05 --> Loader Class Initialized
INFO - 2025-09-26 04:26:05 --> Helper loaded: url_helper
INFO - 2025-09-26 04:26:05 --> Helper loaded: text_helper
INFO - 2025-09-26 04:26:05 --> Helper loaded: string_helper
INFO - 2025-09-26 04:26:05 --> Helper loaded: form_helper
INFO - 2025-09-26 04:26:05 --> Helper loaded: download_helper
INFO - 2025-09-26 04:26:05 --> Helper loaded: security_helper
INFO - 2025-09-26 04:26:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:26:05 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:26:05 --> Form Validation Class Initialized
INFO - 2025-09-26 04:26:05 --> Model "User_model" initialized
INFO - 2025-09-26 09:26:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:26:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:26:05 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:26:05 --> Controller Class Initialized
DEBUG - 2025-09-26 09:26:05 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:26:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-26 09:26:05 --> Model "Log_model" initialized
INFO - 2025-09-26 09:26:05 --> Final output sent to browser
DEBUG - 2025-09-26 09:26:05 --> Total execution time: 0.1326
INFO - 2025-09-26 04:26:12 --> Config Class Initialized
INFO - 2025-09-26 04:26:12 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:26:12 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:26:12 --> Utf8 Class Initialized
INFO - 2025-09-26 04:26:12 --> URI Class Initialized
INFO - 2025-09-26 04:26:12 --> Router Class Initialized
INFO - 2025-09-26 04:26:12 --> Output Class Initialized
INFO - 2025-09-26 04:26:12 --> Security Class Initialized
DEBUG - 2025-09-26 04:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:26:12 --> CSRF cookie sent
INFO - 2025-09-26 04:26:12 --> CSRF token verified
INFO - 2025-09-26 04:26:12 --> Input Class Initialized
INFO - 2025-09-26 04:26:12 --> Language Class Initialized
INFO - 2025-09-26 04:26:12 --> Loader Class Initialized
INFO - 2025-09-26 04:26:12 --> Helper loaded: url_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: text_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: string_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: form_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: download_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: security_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:26:12 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:26:12 --> Form Validation Class Initialized
INFO - 2025-09-26 04:26:12 --> Model "User_model" initialized
INFO - 2025-09-26 09:26:12 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:26:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:26:12 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:26:12 --> Controller Class Initialized
DEBUG - 2025-09-26 09:26:12 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:26:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-26 04:26:12 --> Config Class Initialized
INFO - 2025-09-26 04:26:12 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:26:12 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:26:12 --> Utf8 Class Initialized
INFO - 2025-09-26 04:26:12 --> URI Class Initialized
INFO - 2025-09-26 04:26:12 --> Router Class Initialized
INFO - 2025-09-26 04:26:12 --> Output Class Initialized
INFO - 2025-09-26 04:26:12 --> Security Class Initialized
DEBUG - 2025-09-26 04:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:26:12 --> CSRF cookie sent
INFO - 2025-09-26 04:26:12 --> Input Class Initialized
INFO - 2025-09-26 04:26:12 --> Language Class Initialized
INFO - 2025-09-26 04:26:12 --> Loader Class Initialized
INFO - 2025-09-26 04:26:12 --> Helper loaded: url_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: text_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: string_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: form_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: download_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: security_helper
INFO - 2025-09-26 04:26:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:26:12 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:26:12 --> Form Validation Class Initialized
INFO - 2025-09-26 04:26:12 --> Model "User_model" initialized
INFO - 2025-09-26 09:26:12 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:26:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:26:12 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:26:12 --> Controller Class Initialized
INFO - 2025-09-26 09:26:12 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:26:12 --> Model "Staff_model" initialized
INFO - 2025-09-26 09:26:12 --> Model "Dasbor_model" initialized
INFO - 2025-09-26 09:26:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-09-26 09:26:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:26:13 --> Model "Log_model" initialized
INFO - 2025-09-26 09:26:13 --> Final output sent to browser
DEBUG - 2025-09-26 09:26:13 --> Total execution time: 1.4457
INFO - 2025-09-26 04:26:20 --> Config Class Initialized
INFO - 2025-09-26 04:26:20 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:26:20 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:26:20 --> Utf8 Class Initialized
INFO - 2025-09-26 04:26:20 --> URI Class Initialized
INFO - 2025-09-26 04:26:20 --> Router Class Initialized
INFO - 2025-09-26 04:26:20 --> Output Class Initialized
INFO - 2025-09-26 04:26:20 --> Security Class Initialized
DEBUG - 2025-09-26 04:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:26:20 --> CSRF cookie sent
INFO - 2025-09-26 04:26:20 --> Input Class Initialized
INFO - 2025-09-26 04:26:20 --> Language Class Initialized
INFO - 2025-09-26 04:26:20 --> Loader Class Initialized
INFO - 2025-09-26 04:26:20 --> Helper loaded: url_helper
INFO - 2025-09-26 04:26:20 --> Helper loaded: text_helper
INFO - 2025-09-26 04:26:20 --> Helper loaded: string_helper
INFO - 2025-09-26 04:26:20 --> Helper loaded: form_helper
INFO - 2025-09-26 04:26:20 --> Helper loaded: download_helper
INFO - 2025-09-26 04:26:20 --> Helper loaded: security_helper
INFO - 2025-09-26 04:26:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:26:20 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:26:20 --> Form Validation Class Initialized
INFO - 2025-09-26 04:26:20 --> Model "User_model" initialized
INFO - 2025-09-26 09:26:20 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:26:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:26:20 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:26:20 --> Controller Class Initialized
INFO - 2025-09-26 09:26:20 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:26:20 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:26:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:26:20 --> Pagination Class Initialized
INFO - 2025-09-26 09:26:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-26 09:26:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:26:20 --> Model "Log_model" initialized
INFO - 2025-09-26 09:26:20 --> Final output sent to browser
DEBUG - 2025-09-26 09:26:20 --> Total execution time: 0.2452
INFO - 2025-09-26 04:27:51 --> Config Class Initialized
INFO - 2025-09-26 04:27:51 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:27:51 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:27:51 --> Utf8 Class Initialized
INFO - 2025-09-26 04:27:51 --> URI Class Initialized
DEBUG - 2025-09-26 04:27:51 --> No URI present. Default controller set.
INFO - 2025-09-26 04:27:51 --> Router Class Initialized
INFO - 2025-09-26 04:27:51 --> Output Class Initialized
INFO - 2025-09-26 04:27:51 --> Security Class Initialized
DEBUG - 2025-09-26 04:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:27:51 --> CSRF cookie sent
INFO - 2025-09-26 04:27:51 --> Input Class Initialized
INFO - 2025-09-26 04:27:51 --> Language Class Initialized
INFO - 2025-09-26 04:27:51 --> Loader Class Initialized
INFO - 2025-09-26 04:27:51 --> Helper loaded: url_helper
INFO - 2025-09-26 04:27:51 --> Helper loaded: text_helper
INFO - 2025-09-26 04:27:51 --> Helper loaded: string_helper
INFO - 2025-09-26 04:27:51 --> Helper loaded: form_helper
INFO - 2025-09-26 04:27:51 --> Helper loaded: download_helper
INFO - 2025-09-26 04:27:51 --> Helper loaded: security_helper
INFO - 2025-09-26 04:27:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:27:51 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:27:51 --> Form Validation Class Initialized
INFO - 2025-09-26 04:27:51 --> Model "User_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:27:51 --> Controller Class Initialized
INFO - 2025-09-26 09:27:51 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Video_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:27:51 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:27:51 --> Pagination Class Initialized
INFO - 2025-09-26 09:27:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-26 09:27:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 09:27:51 --> Model "Log_model" initialized
INFO - 2025-09-26 09:27:51 --> Final output sent to browser
DEBUG - 2025-09-26 09:27:51 --> Total execution time: 0.1257
INFO - 2025-09-26 04:28:34 --> Config Class Initialized
INFO - 2025-09-26 04:28:34 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:28:34 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:28:34 --> Utf8 Class Initialized
INFO - 2025-09-26 04:28:34 --> URI Class Initialized
INFO - 2025-09-26 04:28:34 --> Router Class Initialized
INFO - 2025-09-26 04:28:34 --> Output Class Initialized
INFO - 2025-09-26 04:28:34 --> Security Class Initialized
DEBUG - 2025-09-26 04:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:28:34 --> CSRF cookie sent
INFO - 2025-09-26 04:28:34 --> Input Class Initialized
INFO - 2025-09-26 04:28:34 --> Language Class Initialized
INFO - 2025-09-26 04:28:34 --> Loader Class Initialized
INFO - 2025-09-26 04:28:34 --> Helper loaded: url_helper
INFO - 2025-09-26 04:28:34 --> Helper loaded: text_helper
INFO - 2025-09-26 04:28:34 --> Helper loaded: string_helper
INFO - 2025-09-26 04:28:34 --> Helper loaded: form_helper
INFO - 2025-09-26 04:28:34 --> Helper loaded: download_helper
INFO - 2025-09-26 04:28:34 --> Helper loaded: security_helper
INFO - 2025-09-26 04:28:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:28:34 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:28:34 --> Form Validation Class Initialized
INFO - 2025-09-26 04:28:34 --> Model "User_model" initialized
INFO - 2025-09-26 09:28:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:28:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:28:34 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:28:34 --> Controller Class Initialized
INFO - 2025-09-26 09:28:34 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:28:34 --> Model "Staff_model" initialized
INFO - 2025-09-26 09:28:34 --> Model "Dasbor_model" initialized
INFO - 2025-09-26 09:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-09-26 09:28:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:28:34 --> Model "Log_model" initialized
INFO - 2025-09-26 09:28:34 --> Final output sent to browser
DEBUG - 2025-09-26 09:28:34 --> Total execution time: 0.2751
INFO - 2025-09-26 04:31:03 --> Config Class Initialized
INFO - 2025-09-26 04:31:03 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:31:03 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:31:03 --> Utf8 Class Initialized
INFO - 2025-09-26 04:31:03 --> URI Class Initialized
INFO - 2025-09-26 04:31:03 --> Router Class Initialized
INFO - 2025-09-26 04:31:03 --> Output Class Initialized
INFO - 2025-09-26 04:31:03 --> Security Class Initialized
DEBUG - 2025-09-26 04:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:31:03 --> CSRF cookie sent
INFO - 2025-09-26 04:31:03 --> Input Class Initialized
INFO - 2025-09-26 04:31:03 --> Language Class Initialized
INFO - 2025-09-26 04:31:03 --> Loader Class Initialized
INFO - 2025-09-26 04:31:03 --> Helper loaded: url_helper
INFO - 2025-09-26 04:31:03 --> Helper loaded: text_helper
INFO - 2025-09-26 04:31:03 --> Helper loaded: string_helper
INFO - 2025-09-26 04:31:03 --> Helper loaded: form_helper
INFO - 2025-09-26 04:31:03 --> Helper loaded: download_helper
INFO - 2025-09-26 04:31:03 --> Helper loaded: security_helper
INFO - 2025-09-26 04:31:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:31:03 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:31:04 --> Form Validation Class Initialized
INFO - 2025-09-26 04:31:04 --> Model "User_model" initialized
INFO - 2025-09-26 09:31:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:31:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:31:04 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:31:04 --> Controller Class Initialized
INFO - 2025-09-26 09:31:04 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:31:04 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:31:04 --> Pagination Class Initialized
INFO - 2025-09-26 09:31:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-26 09:31:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:31:04 --> Model "Log_model" initialized
INFO - 2025-09-26 09:31:04 --> Final output sent to browser
DEBUG - 2025-09-26 09:31:04 --> Total execution time: 0.0516
INFO - 2025-09-26 04:32:37 --> Config Class Initialized
INFO - 2025-09-26 04:32:37 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:32:37 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:32:37 --> Utf8 Class Initialized
INFO - 2025-09-26 04:32:37 --> URI Class Initialized
INFO - 2025-09-26 04:32:37 --> Router Class Initialized
INFO - 2025-09-26 04:32:37 --> Output Class Initialized
INFO - 2025-09-26 04:32:37 --> Security Class Initialized
DEBUG - 2025-09-26 04:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:32:37 --> CSRF cookie sent
INFO - 2025-09-26 04:32:37 --> CSRF token verified
INFO - 2025-09-26 04:32:37 --> Input Class Initialized
INFO - 2025-09-26 04:32:37 --> Language Class Initialized
INFO - 2025-09-26 04:32:37 --> Loader Class Initialized
INFO - 2025-09-26 04:32:37 --> Helper loaded: url_helper
INFO - 2025-09-26 04:32:37 --> Helper loaded: text_helper
INFO - 2025-09-26 04:32:37 --> Helper loaded: string_helper
INFO - 2025-09-26 04:32:37 --> Helper loaded: form_helper
INFO - 2025-09-26 04:32:37 --> Helper loaded: download_helper
INFO - 2025-09-26 04:32:37 --> Helper loaded: security_helper
INFO - 2025-09-26 04:32:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:32:37 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:32:37 --> Form Validation Class Initialized
INFO - 2025-09-26 04:32:37 --> Model "User_model" initialized
INFO - 2025-09-26 09:32:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:32:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:32:37 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:32:37 --> Controller Class Initialized
INFO - 2025-09-26 09:32:37 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:32:37 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:32:37 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:32:37 --> Pagination Class Initialized
INFO - 2025-09-26 09:32:37 --> Upload Class Initialized
ERROR - 2025-09-26 09:32:37 --> Query error: Unknown column 'asal_prodi' in 'field list' - Invalid query: INSERT INTO `testimoni` (`nama`, `asal_prodi`, `jabatan`, `role`, `isi`, `status`, `foto`) VALUES ('Paul Malau', 'D-III Keperawatan', 'Alumni', 'umum', 'My name is Paul Malau. I graduated from Diploma III of Nursing at Poltekkes Kemenkes Jakarta III in 1992. In 1997 I pursuedmy Bachelor of Nursing at Faculty of Nursing, Avondale College and Master of Nursing (Cancer Nursing) in 1999 at Faculty of Nursing, Avondale College.Since 2010 I have been working as an Apheresis Clinical Nursing Consultantat New South Wales Health Pathology in West Royal Prince Alfred hospital. Proud to be part of Poltekkes Kemenkes Jakarta III', 'publish', '6f8194b2085326953d69cca51b2d730f.jpg')
INFO - 2025-09-26 09:32:37 --> Model "Log_model" initialized
INFO - 2025-09-26 09:32:37 --> Final output sent to browser
DEBUG - 2025-09-26 09:32:37 --> Total execution time: 0.5083
INFO - 2025-09-26 04:32:58 --> Config Class Initialized
INFO - 2025-09-26 04:32:58 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:32:58 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:32:58 --> Utf8 Class Initialized
INFO - 2025-09-26 04:32:58 --> URI Class Initialized
INFO - 2025-09-26 04:32:58 --> Router Class Initialized
INFO - 2025-09-26 04:32:58 --> Output Class Initialized
INFO - 2025-09-26 04:32:58 --> Security Class Initialized
DEBUG - 2025-09-26 04:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:32:58 --> CSRF cookie sent
INFO - 2025-09-26 04:32:58 --> Input Class Initialized
INFO - 2025-09-26 04:32:58 --> Language Class Initialized
INFO - 2025-09-26 04:32:58 --> Loader Class Initialized
INFO - 2025-09-26 04:32:58 --> Helper loaded: url_helper
INFO - 2025-09-26 04:32:58 --> Helper loaded: text_helper
INFO - 2025-09-26 04:32:58 --> Helper loaded: string_helper
INFO - 2025-09-26 04:32:58 --> Helper loaded: form_helper
INFO - 2025-09-26 04:32:58 --> Helper loaded: download_helper
INFO - 2025-09-26 04:32:58 --> Helper loaded: security_helper
INFO - 2025-09-26 04:32:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:32:58 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:32:58 --> Form Validation Class Initialized
INFO - 2025-09-26 04:32:58 --> Model "User_model" initialized
INFO - 2025-09-26 09:32:58 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:32:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:32:58 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:32:58 --> Controller Class Initialized
INFO - 2025-09-26 09:32:58 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:32:58 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:32:58 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:32:58 --> Pagination Class Initialized
INFO - 2025-09-26 09:32:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-26 09:32:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:32:58 --> Model "Log_model" initialized
INFO - 2025-09-26 09:32:58 --> Final output sent to browser
DEBUG - 2025-09-26 09:32:58 --> Total execution time: 0.0617
INFO - 2025-09-26 04:33:18 --> Config Class Initialized
INFO - 2025-09-26 04:33:18 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:33:18 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:33:18 --> Utf8 Class Initialized
INFO - 2025-09-26 04:33:18 --> URI Class Initialized
INFO - 2025-09-26 04:33:18 --> Router Class Initialized
INFO - 2025-09-26 04:33:18 --> Output Class Initialized
INFO - 2025-09-26 04:33:18 --> Security Class Initialized
DEBUG - 2025-09-26 04:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:33:18 --> CSRF cookie sent
INFO - 2025-09-26 04:33:18 --> CSRF token verified
INFO - 2025-09-26 04:33:18 --> Input Class Initialized
INFO - 2025-09-26 04:33:18 --> Language Class Initialized
INFO - 2025-09-26 04:33:18 --> Loader Class Initialized
INFO - 2025-09-26 04:33:18 --> Helper loaded: url_helper
INFO - 2025-09-26 04:33:18 --> Helper loaded: text_helper
INFO - 2025-09-26 04:33:18 --> Helper loaded: string_helper
INFO - 2025-09-26 04:33:18 --> Helper loaded: form_helper
INFO - 2025-09-26 04:33:18 --> Helper loaded: download_helper
INFO - 2025-09-26 04:33:18 --> Helper loaded: security_helper
INFO - 2025-09-26 04:33:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:33:18 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:33:18 --> Form Validation Class Initialized
INFO - 2025-09-26 04:33:18 --> Model "User_model" initialized
INFO - 2025-09-26 09:33:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:33:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:33:18 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:33:18 --> Controller Class Initialized
INFO - 2025-09-26 09:33:18 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:33:18 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:33:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:33:18 --> Pagination Class Initialized
INFO - 2025-09-26 09:33:18 --> Upload Class Initialized
ERROR - 2025-09-26 09:33:18 --> Query error: Unknown column 'asal_prodi' in 'field list' - Invalid query: INSERT INTO `testimoni` (`nama`, `asal_prodi`, `jabatan`, `role`, `isi`, `status`, `foto`) VALUES ('Paul Malau', 'D-III Keperawatan', 'Alumni', 'alumni', 'My name is Paul Malau. I graduated from Diploma III of Nursing at Poltekkes Kemenkes Jakarta III in 1992. In 1997 I pursuedmy Bachelor of Nursing at Faculty of Nursing, Avondale College and Master of Nursing (Cancer Nursing) in 1999 at Faculty of Nursing, Avondale College.Since 2010 I have been working as an Apheresis Clinical Nursing Consultantat New South Wales Health Pathology in West Royal Prince Alfred hospital. Proud to be part of Poltekkes Kemenkes Jakarta III', 'publish', '0a9a5e371d9ac20b399fd0ea571f6ad6.jpg')
INFO - 2025-09-26 09:33:18 --> Model "Log_model" initialized
INFO - 2025-09-26 09:33:18 --> Final output sent to browser
DEBUG - 2025-09-26 09:33:18 --> Total execution time: 0.0526
INFO - 2025-09-26 04:37:21 --> Config Class Initialized
INFO - 2025-09-26 04:37:21 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:37:21 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:37:21 --> Utf8 Class Initialized
INFO - 2025-09-26 04:37:21 --> URI Class Initialized
INFO - 2025-09-26 04:37:21 --> Router Class Initialized
INFO - 2025-09-26 04:37:21 --> Output Class Initialized
INFO - 2025-09-26 04:37:21 --> Security Class Initialized
DEBUG - 2025-09-26 04:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:37:21 --> CSRF cookie sent
INFO - 2025-09-26 04:37:21 --> Input Class Initialized
INFO - 2025-09-26 04:37:21 --> Language Class Initialized
INFO - 2025-09-26 04:37:21 --> Loader Class Initialized
INFO - 2025-09-26 04:37:21 --> Helper loaded: url_helper
INFO - 2025-09-26 04:37:21 --> Helper loaded: text_helper
INFO - 2025-09-26 04:37:21 --> Helper loaded: string_helper
INFO - 2025-09-26 04:37:21 --> Helper loaded: form_helper
INFO - 2025-09-26 04:37:21 --> Helper loaded: download_helper
INFO - 2025-09-26 04:37:21 --> Helper loaded: security_helper
INFO - 2025-09-26 04:37:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:37:21 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:37:21 --> Form Validation Class Initialized
INFO - 2025-09-26 04:37:21 --> Model "User_model" initialized
INFO - 2025-09-26 09:37:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:37:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:37:21 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:37:21 --> Controller Class Initialized
INFO - 2025-09-26 09:37:21 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:37:21 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:37:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:37:21 --> Pagination Class Initialized
INFO - 2025-09-26 09:37:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-26 09:37:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:37:21 --> Model "Log_model" initialized
INFO - 2025-09-26 09:37:21 --> Final output sent to browser
DEBUG - 2025-09-26 09:37:21 --> Total execution time: 0.0762
INFO - 2025-09-26 04:37:43 --> Config Class Initialized
INFO - 2025-09-26 04:37:43 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:37:43 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:37:43 --> Utf8 Class Initialized
INFO - 2025-09-26 04:37:43 --> URI Class Initialized
INFO - 2025-09-26 04:37:43 --> Router Class Initialized
INFO - 2025-09-26 04:37:43 --> Output Class Initialized
INFO - 2025-09-26 04:37:43 --> Security Class Initialized
DEBUG - 2025-09-26 04:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:37:43 --> CSRF cookie sent
INFO - 2025-09-26 04:37:43 --> CSRF token verified
INFO - 2025-09-26 04:37:43 --> Input Class Initialized
INFO - 2025-09-26 04:37:43 --> Language Class Initialized
INFO - 2025-09-26 04:37:43 --> Loader Class Initialized
INFO - 2025-09-26 04:37:43 --> Helper loaded: url_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: text_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: string_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: form_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: download_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: security_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:37:43 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:37:43 --> Form Validation Class Initialized
INFO - 2025-09-26 04:37:43 --> Model "User_model" initialized
INFO - 2025-09-26 09:37:43 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:37:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:37:43 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:37:43 --> Controller Class Initialized
INFO - 2025-09-26 09:37:43 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:37:43 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:37:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:37:43 --> Pagination Class Initialized
INFO - 2025-09-26 09:37:43 --> Upload Class Initialized
INFO - 2025-09-26 09:37:43 --> Model "Log_model" initialized
INFO - 2025-09-26 09:37:43 --> Final output sent to browser
DEBUG - 2025-09-26 09:37:43 --> Total execution time: 0.0718
INFO - 2025-09-26 04:37:43 --> Config Class Initialized
INFO - 2025-09-26 04:37:43 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:37:43 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:37:43 --> Utf8 Class Initialized
INFO - 2025-09-26 04:37:43 --> URI Class Initialized
INFO - 2025-09-26 04:37:43 --> Router Class Initialized
INFO - 2025-09-26 04:37:43 --> Output Class Initialized
INFO - 2025-09-26 04:37:43 --> Security Class Initialized
DEBUG - 2025-09-26 04:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:37:43 --> CSRF cookie sent
INFO - 2025-09-26 04:37:43 --> Input Class Initialized
INFO - 2025-09-26 04:37:43 --> Language Class Initialized
INFO - 2025-09-26 04:37:43 --> Loader Class Initialized
INFO - 2025-09-26 04:37:43 --> Helper loaded: url_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: text_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: string_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: form_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: download_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: security_helper
INFO - 2025-09-26 04:37:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:37:43 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:37:43 --> Form Validation Class Initialized
INFO - 2025-09-26 04:37:43 --> Model "User_model" initialized
INFO - 2025-09-26 09:37:43 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:37:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:37:43 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:37:43 --> Controller Class Initialized
INFO - 2025-09-26 09:37:43 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:37:43 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:37:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:37:43 --> Pagination Class Initialized
INFO - 2025-09-26 09:37:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-26 09:37:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:37:43 --> Model "Log_model" initialized
INFO - 2025-09-26 09:37:43 --> Final output sent to browser
DEBUG - 2025-09-26 09:37:43 --> Total execution time: 0.0583
INFO - 2025-09-26 04:37:47 --> Config Class Initialized
INFO - 2025-09-26 04:37:47 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:37:47 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:37:47 --> Utf8 Class Initialized
INFO - 2025-09-26 04:37:47 --> URI Class Initialized
DEBUG - 2025-09-26 04:37:47 --> No URI present. Default controller set.
INFO - 2025-09-26 04:37:47 --> Router Class Initialized
INFO - 2025-09-26 04:37:47 --> Output Class Initialized
INFO - 2025-09-26 04:37:47 --> Security Class Initialized
DEBUG - 2025-09-26 04:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:37:47 --> CSRF cookie sent
INFO - 2025-09-26 04:37:47 --> Input Class Initialized
INFO - 2025-09-26 04:37:47 --> Language Class Initialized
INFO - 2025-09-26 04:37:47 --> Loader Class Initialized
INFO - 2025-09-26 04:37:47 --> Helper loaded: url_helper
INFO - 2025-09-26 04:37:47 --> Helper loaded: text_helper
INFO - 2025-09-26 04:37:47 --> Helper loaded: string_helper
INFO - 2025-09-26 04:37:47 --> Helper loaded: form_helper
INFO - 2025-09-26 04:37:47 --> Helper loaded: download_helper
INFO - 2025-09-26 04:37:47 --> Helper loaded: security_helper
INFO - 2025-09-26 04:37:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:37:47 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:37:47 --> Form Validation Class Initialized
INFO - 2025-09-26 04:37:47 --> Model "User_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:37:47 --> Controller Class Initialized
INFO - 2025-09-26 09:37:47 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Video_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:37:47 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:37:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:37:47 --> Pagination Class Initialized
INFO - 2025-09-26 09:37:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-26 09:37:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 09:37:47 --> Model "Log_model" initialized
INFO - 2025-09-26 09:37:47 --> Final output sent to browser
DEBUG - 2025-09-26 09:37:47 --> Total execution time: 0.0991
INFO - 2025-09-26 04:38:49 --> Config Class Initialized
INFO - 2025-09-26 04:38:49 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:38:49 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:38:49 --> Utf8 Class Initialized
INFO - 2025-09-26 04:38:49 --> URI Class Initialized
INFO - 2025-09-26 04:38:49 --> Router Class Initialized
INFO - 2025-09-26 04:38:49 --> Output Class Initialized
INFO - 2025-09-26 04:38:49 --> Security Class Initialized
DEBUG - 2025-09-26 04:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:38:49 --> CSRF cookie sent
INFO - 2025-09-26 04:38:49 --> CSRF token verified
INFO - 2025-09-26 04:38:49 --> Input Class Initialized
INFO - 2025-09-26 04:38:49 --> Language Class Initialized
INFO - 2025-09-26 04:38:49 --> Loader Class Initialized
INFO - 2025-09-26 04:38:49 --> Helper loaded: url_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: text_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: string_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: form_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: download_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: security_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:38:49 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:38:49 --> Form Validation Class Initialized
INFO - 2025-09-26 04:38:49 --> Model "User_model" initialized
INFO - 2025-09-26 09:38:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:38:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:38:49 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:38:49 --> Controller Class Initialized
INFO - 2025-09-26 09:38:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:38:49 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:38:49 --> Pagination Class Initialized
INFO - 2025-09-26 09:38:49 --> Upload Class Initialized
INFO - 2025-09-26 09:38:49 --> Model "Log_model" initialized
INFO - 2025-09-26 09:38:49 --> Final output sent to browser
DEBUG - 2025-09-26 09:38:49 --> Total execution time: 0.0588
INFO - 2025-09-26 04:38:49 --> Config Class Initialized
INFO - 2025-09-26 04:38:49 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:38:49 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:38:49 --> Utf8 Class Initialized
INFO - 2025-09-26 04:38:49 --> URI Class Initialized
INFO - 2025-09-26 04:38:49 --> Router Class Initialized
INFO - 2025-09-26 04:38:49 --> Output Class Initialized
INFO - 2025-09-26 04:38:49 --> Security Class Initialized
DEBUG - 2025-09-26 04:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:38:49 --> CSRF cookie sent
INFO - 2025-09-26 04:38:49 --> Input Class Initialized
INFO - 2025-09-26 04:38:49 --> Language Class Initialized
INFO - 2025-09-26 04:38:49 --> Loader Class Initialized
INFO - 2025-09-26 04:38:49 --> Helper loaded: url_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: text_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: string_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: form_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: download_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: security_helper
INFO - 2025-09-26 04:38:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:38:49 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:38:49 --> Form Validation Class Initialized
INFO - 2025-09-26 04:38:49 --> Model "User_model" initialized
INFO - 2025-09-26 09:38:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:38:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:38:49 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:38:49 --> Controller Class Initialized
INFO - 2025-09-26 09:38:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:38:49 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:38:49 --> Pagination Class Initialized
INFO - 2025-09-26 09:38:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-26 09:38:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:38:49 --> Model "Log_model" initialized
INFO - 2025-09-26 09:38:49 --> Final output sent to browser
DEBUG - 2025-09-26 09:38:49 --> Total execution time: 0.0633
INFO - 2025-09-26 04:38:54 --> Config Class Initialized
INFO - 2025-09-26 04:38:54 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:38:54 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:38:54 --> Utf8 Class Initialized
INFO - 2025-09-26 04:38:54 --> URI Class Initialized
DEBUG - 2025-09-26 04:38:54 --> No URI present. Default controller set.
INFO - 2025-09-26 04:38:54 --> Router Class Initialized
INFO - 2025-09-26 04:38:54 --> Output Class Initialized
INFO - 2025-09-26 04:38:54 --> Security Class Initialized
DEBUG - 2025-09-26 04:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:38:54 --> CSRF cookie sent
INFO - 2025-09-26 04:38:54 --> Input Class Initialized
INFO - 2025-09-26 04:38:54 --> Language Class Initialized
INFO - 2025-09-26 04:38:54 --> Loader Class Initialized
INFO - 2025-09-26 04:38:54 --> Helper loaded: url_helper
INFO - 2025-09-26 04:38:54 --> Helper loaded: text_helper
INFO - 2025-09-26 04:38:54 --> Helper loaded: string_helper
INFO - 2025-09-26 04:38:54 --> Helper loaded: form_helper
INFO - 2025-09-26 04:38:54 --> Helper loaded: download_helper
INFO - 2025-09-26 04:38:54 --> Helper loaded: security_helper
INFO - 2025-09-26 04:38:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:38:54 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:38:54 --> Form Validation Class Initialized
INFO - 2025-09-26 04:38:54 --> Model "User_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:38:54 --> Controller Class Initialized
INFO - 2025-09-26 09:38:54 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Video_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:38:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:38:54 --> Pagination Class Initialized
INFO - 2025-09-26 09:38:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-26 09:38:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 09:38:54 --> Model "Log_model" initialized
INFO - 2025-09-26 09:38:54 --> Final output sent to browser
DEBUG - 2025-09-26 09:38:54 --> Total execution time: 0.1015
INFO - 2025-09-26 04:40:33 --> Config Class Initialized
INFO - 2025-09-26 04:40:33 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:40:33 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:40:33 --> Utf8 Class Initialized
INFO - 2025-09-26 04:40:33 --> URI Class Initialized
INFO - 2025-09-26 04:40:33 --> Router Class Initialized
INFO - 2025-09-26 04:40:33 --> Output Class Initialized
INFO - 2025-09-26 04:40:33 --> Security Class Initialized
DEBUG - 2025-09-26 04:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:40:33 --> CSRF cookie sent
INFO - 2025-09-26 04:40:33 --> CSRF token verified
INFO - 2025-09-26 04:40:33 --> Input Class Initialized
INFO - 2025-09-26 04:40:33 --> Language Class Initialized
INFO - 2025-09-26 04:40:33 --> Loader Class Initialized
INFO - 2025-09-26 04:40:33 --> Helper loaded: url_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: text_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: string_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: form_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: download_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: security_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:40:33 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:40:33 --> Form Validation Class Initialized
INFO - 2025-09-26 04:40:33 --> Model "User_model" initialized
INFO - 2025-09-26 09:40:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:40:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:40:33 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:40:33 --> Controller Class Initialized
INFO - 2025-09-26 09:40:33 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:40:33 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:40:33 --> Pagination Class Initialized
INFO - 2025-09-26 09:40:33 --> Model "Log_model" initialized
INFO - 2025-09-26 09:40:33 --> Final output sent to browser
DEBUG - 2025-09-26 09:40:33 --> Total execution time: 0.0498
INFO - 2025-09-26 04:40:33 --> Config Class Initialized
INFO - 2025-09-26 04:40:33 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:40:33 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:40:33 --> Utf8 Class Initialized
INFO - 2025-09-26 04:40:33 --> URI Class Initialized
INFO - 2025-09-26 04:40:33 --> Router Class Initialized
INFO - 2025-09-26 04:40:33 --> Output Class Initialized
INFO - 2025-09-26 04:40:33 --> Security Class Initialized
DEBUG - 2025-09-26 04:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:40:33 --> CSRF cookie sent
INFO - 2025-09-26 04:40:33 --> Input Class Initialized
INFO - 2025-09-26 04:40:33 --> Language Class Initialized
INFO - 2025-09-26 04:40:33 --> Loader Class Initialized
INFO - 2025-09-26 04:40:33 --> Helper loaded: url_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: text_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: string_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: form_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: download_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: security_helper
INFO - 2025-09-26 04:40:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:40:33 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:40:33 --> Form Validation Class Initialized
INFO - 2025-09-26 04:40:33 --> Model "User_model" initialized
INFO - 2025-09-26 09:40:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:40:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:40:33 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:40:33 --> Controller Class Initialized
INFO - 2025-09-26 09:40:33 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:40:33 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:40:33 --> Pagination Class Initialized
INFO - 2025-09-26 09:40:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-26 09:40:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:40:33 --> Model "Log_model" initialized
INFO - 2025-09-26 09:40:33 --> Final output sent to browser
DEBUG - 2025-09-26 09:40:33 --> Total execution time: 0.0442
INFO - 2025-09-26 04:41:09 --> Config Class Initialized
INFO - 2025-09-26 04:41:09 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:41:09 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:41:09 --> Utf8 Class Initialized
INFO - 2025-09-26 04:41:09 --> URI Class Initialized
INFO - 2025-09-26 04:41:09 --> Router Class Initialized
INFO - 2025-09-26 04:41:09 --> Output Class Initialized
INFO - 2025-09-26 04:41:09 --> Security Class Initialized
DEBUG - 2025-09-26 04:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:41:09 --> CSRF cookie sent
INFO - 2025-09-26 04:41:09 --> Input Class Initialized
INFO - 2025-09-26 04:41:09 --> Language Class Initialized
INFO - 2025-09-26 04:41:09 --> Loader Class Initialized
INFO - 2025-09-26 04:41:09 --> Helper loaded: url_helper
INFO - 2025-09-26 04:41:09 --> Helper loaded: text_helper
INFO - 2025-09-26 04:41:09 --> Helper loaded: string_helper
INFO - 2025-09-26 04:41:09 --> Helper loaded: form_helper
INFO - 2025-09-26 04:41:09 --> Helper loaded: download_helper
INFO - 2025-09-26 04:41:09 --> Helper loaded: security_helper
INFO - 2025-09-26 04:41:09 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:41:09 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:41:10 --> Form Validation Class Initialized
INFO - 2025-09-26 04:41:10 --> Model "User_model" initialized
INFO - 2025-09-26 09:41:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:41:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:41:10 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:41:10 --> Controller Class Initialized
INFO - 2025-09-26 09:41:10 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:41:10 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:41:10 --> Pagination Class Initialized
INFO - 2025-09-26 09:41:10 --> Model "Log_model" initialized
INFO - 2025-09-26 09:41:10 --> Final output sent to browser
DEBUG - 2025-09-26 09:41:10 --> Total execution time: 0.0503
INFO - 2025-09-26 04:41:13 --> Config Class Initialized
INFO - 2025-09-26 04:41:13 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:41:13 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:41:13 --> Utf8 Class Initialized
INFO - 2025-09-26 04:41:13 --> URI Class Initialized
INFO - 2025-09-26 04:41:13 --> Router Class Initialized
INFO - 2025-09-26 04:41:13 --> Output Class Initialized
INFO - 2025-09-26 04:41:13 --> Security Class Initialized
DEBUG - 2025-09-26 04:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:41:13 --> CSRF cookie sent
INFO - 2025-09-26 04:41:13 --> CSRF token verified
INFO - 2025-09-26 04:41:13 --> Input Class Initialized
INFO - 2025-09-26 04:41:13 --> Language Class Initialized
INFO - 2025-09-26 04:41:13 --> Loader Class Initialized
INFO - 2025-09-26 04:41:13 --> Helper loaded: url_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: text_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: string_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: form_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: download_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: security_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:41:13 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:41:13 --> Form Validation Class Initialized
INFO - 2025-09-26 04:41:13 --> Model "User_model" initialized
INFO - 2025-09-26 09:41:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:41:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:41:13 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:41:13 --> Controller Class Initialized
INFO - 2025-09-26 09:41:13 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:41:13 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:41:13 --> Pagination Class Initialized
INFO - 2025-09-26 09:41:13 --> Model "Log_model" initialized
INFO - 2025-09-26 09:41:13 --> Final output sent to browser
DEBUG - 2025-09-26 09:41:13 --> Total execution time: 0.0549
INFO - 2025-09-26 04:41:13 --> Config Class Initialized
INFO - 2025-09-26 04:41:13 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:41:13 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:41:13 --> Utf8 Class Initialized
INFO - 2025-09-26 04:41:13 --> URI Class Initialized
INFO - 2025-09-26 04:41:13 --> Router Class Initialized
INFO - 2025-09-26 04:41:13 --> Output Class Initialized
INFO - 2025-09-26 04:41:13 --> Security Class Initialized
DEBUG - 2025-09-26 04:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:41:13 --> CSRF cookie sent
INFO - 2025-09-26 04:41:13 --> Input Class Initialized
INFO - 2025-09-26 04:41:13 --> Language Class Initialized
INFO - 2025-09-26 04:41:13 --> Loader Class Initialized
INFO - 2025-09-26 04:41:13 --> Helper loaded: url_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: text_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: string_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: form_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: download_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: security_helper
INFO - 2025-09-26 04:41:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:41:13 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:41:13 --> Form Validation Class Initialized
INFO - 2025-09-26 04:41:13 --> Model "User_model" initialized
INFO - 2025-09-26 09:41:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:41:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:41:13 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:41:13 --> Controller Class Initialized
INFO - 2025-09-26 09:41:13 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:41:13 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:41:13 --> Pagination Class Initialized
INFO - 2025-09-26 09:41:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-26 09:41:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:41:13 --> Model "Log_model" initialized
INFO - 2025-09-26 09:41:13 --> Final output sent to browser
DEBUG - 2025-09-26 09:41:13 --> Total execution time: 0.0543
INFO - 2025-09-26 04:41:28 --> Config Class Initialized
INFO - 2025-09-26 04:41:28 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:41:28 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:41:28 --> Utf8 Class Initialized
INFO - 2025-09-26 04:41:28 --> URI Class Initialized
INFO - 2025-09-26 04:41:28 --> Router Class Initialized
INFO - 2025-09-26 04:41:28 --> Output Class Initialized
INFO - 2025-09-26 04:41:28 --> Security Class Initialized
DEBUG - 2025-09-26 04:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:41:28 --> CSRF cookie sent
INFO - 2025-09-26 04:41:28 --> Input Class Initialized
INFO - 2025-09-26 04:41:28 --> Language Class Initialized
INFO - 2025-09-26 04:41:28 --> Loader Class Initialized
INFO - 2025-09-26 04:41:28 --> Helper loaded: url_helper
INFO - 2025-09-26 04:41:28 --> Helper loaded: text_helper
INFO - 2025-09-26 04:41:28 --> Helper loaded: string_helper
INFO - 2025-09-26 04:41:28 --> Helper loaded: form_helper
INFO - 2025-09-26 04:41:28 --> Helper loaded: download_helper
INFO - 2025-09-26 04:41:28 --> Helper loaded: security_helper
INFO - 2025-09-26 04:41:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:41:28 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:41:28 --> Form Validation Class Initialized
INFO - 2025-09-26 04:41:28 --> Model "User_model" initialized
INFO - 2025-09-26 09:41:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:41:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:41:28 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:41:28 --> Controller Class Initialized
INFO - 2025-09-26 09:41:28 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:41:28 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:41:28 --> Pagination Class Initialized
INFO - 2025-09-26 09:41:28 --> Model "Log_model" initialized
INFO - 2025-09-26 09:41:28 --> Final output sent to browser
DEBUG - 2025-09-26 09:41:28 --> Total execution time: 0.0412
INFO - 2025-09-26 04:41:32 --> Config Class Initialized
INFO - 2025-09-26 04:41:32 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:41:32 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:41:32 --> Utf8 Class Initialized
INFO - 2025-09-26 04:41:32 --> URI Class Initialized
INFO - 2025-09-26 04:41:32 --> Router Class Initialized
INFO - 2025-09-26 04:41:32 --> Output Class Initialized
INFO - 2025-09-26 04:41:32 --> Security Class Initialized
DEBUG - 2025-09-26 04:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:41:32 --> CSRF cookie sent
INFO - 2025-09-26 04:41:32 --> CSRF token verified
INFO - 2025-09-26 04:41:32 --> Input Class Initialized
INFO - 2025-09-26 04:41:32 --> Language Class Initialized
INFO - 2025-09-26 04:41:32 --> Loader Class Initialized
INFO - 2025-09-26 04:41:32 --> Helper loaded: url_helper
INFO - 2025-09-26 04:41:32 --> Helper loaded: text_helper
INFO - 2025-09-26 04:41:32 --> Helper loaded: string_helper
INFO - 2025-09-26 04:41:32 --> Helper loaded: form_helper
INFO - 2025-09-26 04:41:32 --> Helper loaded: download_helper
INFO - 2025-09-26 04:41:32 --> Helper loaded: security_helper
INFO - 2025-09-26 04:41:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:41:32 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:41:33 --> Form Validation Class Initialized
INFO - 2025-09-26 04:41:33 --> Model "User_model" initialized
INFO - 2025-09-26 09:41:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:41:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:41:33 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:41:33 --> Controller Class Initialized
INFO - 2025-09-26 09:41:33 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:41:33 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:41:33 --> Pagination Class Initialized
INFO - 2025-09-26 09:41:33 --> Model "Log_model" initialized
INFO - 2025-09-26 09:41:33 --> Final output sent to browser
DEBUG - 2025-09-26 09:41:33 --> Total execution time: 0.0585
INFO - 2025-09-26 04:41:33 --> Config Class Initialized
INFO - 2025-09-26 04:41:33 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:41:33 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:41:33 --> Utf8 Class Initialized
INFO - 2025-09-26 04:41:33 --> URI Class Initialized
INFO - 2025-09-26 04:41:33 --> Router Class Initialized
INFO - 2025-09-26 04:41:33 --> Output Class Initialized
INFO - 2025-09-26 04:41:33 --> Security Class Initialized
DEBUG - 2025-09-26 04:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:41:33 --> CSRF cookie sent
INFO - 2025-09-26 04:41:33 --> Input Class Initialized
INFO - 2025-09-26 04:41:33 --> Language Class Initialized
INFO - 2025-09-26 04:41:33 --> Loader Class Initialized
INFO - 2025-09-26 04:41:33 --> Helper loaded: url_helper
INFO - 2025-09-26 04:41:33 --> Helper loaded: text_helper
INFO - 2025-09-26 04:41:33 --> Helper loaded: string_helper
INFO - 2025-09-26 04:41:33 --> Helper loaded: form_helper
INFO - 2025-09-26 04:41:33 --> Helper loaded: download_helper
INFO - 2025-09-26 04:41:33 --> Helper loaded: security_helper
INFO - 2025-09-26 04:41:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:41:33 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:41:33 --> Form Validation Class Initialized
INFO - 2025-09-26 04:41:33 --> Model "User_model" initialized
INFO - 2025-09-26 09:41:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:41:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:41:33 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:41:33 --> Controller Class Initialized
INFO - 2025-09-26 09:41:33 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:41:33 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:41:33 --> Pagination Class Initialized
INFO - 2025-09-26 09:41:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-26 09:41:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:41:33 --> Model "Log_model" initialized
INFO - 2025-09-26 09:41:33 --> Final output sent to browser
DEBUG - 2025-09-26 09:41:33 --> Total execution time: 0.0567
INFO - 2025-09-26 04:41:34 --> Config Class Initialized
INFO - 2025-09-26 04:41:34 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:41:34 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:41:34 --> Utf8 Class Initialized
INFO - 2025-09-26 04:41:34 --> URI Class Initialized
INFO - 2025-09-26 04:41:34 --> Router Class Initialized
INFO - 2025-09-26 04:41:34 --> Output Class Initialized
INFO - 2025-09-26 04:41:34 --> Security Class Initialized
DEBUG - 2025-09-26 04:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:41:34 --> CSRF cookie sent
INFO - 2025-09-26 04:41:34 --> Input Class Initialized
INFO - 2025-09-26 04:41:34 --> Language Class Initialized
INFO - 2025-09-26 04:41:34 --> Loader Class Initialized
INFO - 2025-09-26 04:41:34 --> Helper loaded: url_helper
INFO - 2025-09-26 04:41:34 --> Helper loaded: text_helper
INFO - 2025-09-26 04:41:34 --> Helper loaded: string_helper
INFO - 2025-09-26 04:41:34 --> Helper loaded: form_helper
INFO - 2025-09-26 04:41:34 --> Helper loaded: download_helper
INFO - 2025-09-26 04:41:34 --> Helper loaded: security_helper
INFO - 2025-09-26 04:41:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:41:34 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:41:34 --> Form Validation Class Initialized
INFO - 2025-09-26 04:41:34 --> Model "User_model" initialized
INFO - 2025-09-26 09:41:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:41:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:41:34 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:41:34 --> Controller Class Initialized
INFO - 2025-09-26 09:41:34 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:41:34 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:41:34 --> Pagination Class Initialized
INFO - 2025-09-26 09:41:34 --> Model "Log_model" initialized
INFO - 2025-09-26 09:41:34 --> Final output sent to browser
DEBUG - 2025-09-26 09:41:34 --> Total execution time: 0.0379
INFO - 2025-09-26 04:41:41 --> Config Class Initialized
INFO - 2025-09-26 04:41:41 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:41:41 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:41:41 --> Utf8 Class Initialized
INFO - 2025-09-26 04:41:41 --> URI Class Initialized
INFO - 2025-09-26 04:41:41 --> Router Class Initialized
INFO - 2025-09-26 04:41:41 --> Output Class Initialized
INFO - 2025-09-26 04:41:41 --> Security Class Initialized
DEBUG - 2025-09-26 04:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:41:41 --> CSRF cookie sent
INFO - 2025-09-26 04:41:41 --> CSRF token verified
INFO - 2025-09-26 04:41:41 --> Input Class Initialized
INFO - 2025-09-26 04:41:41 --> Language Class Initialized
INFO - 2025-09-26 04:41:41 --> Loader Class Initialized
INFO - 2025-09-26 04:41:41 --> Helper loaded: url_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: text_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: string_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: form_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: download_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: security_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:41:41 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:41:41 --> Form Validation Class Initialized
INFO - 2025-09-26 04:41:41 --> Model "User_model" initialized
INFO - 2025-09-26 09:41:41 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:41:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:41:41 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:41:41 --> Controller Class Initialized
INFO - 2025-09-26 09:41:41 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:41:41 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:41:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:41:41 --> Pagination Class Initialized
INFO - 2025-09-26 09:41:41 --> Upload Class Initialized
INFO - 2025-09-26 09:41:41 --> Model "Log_model" initialized
INFO - 2025-09-26 09:41:41 --> Final output sent to browser
DEBUG - 2025-09-26 09:41:41 --> Total execution time: 0.0553
INFO - 2025-09-26 04:41:41 --> Config Class Initialized
INFO - 2025-09-26 04:41:41 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:41:41 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:41:41 --> Utf8 Class Initialized
INFO - 2025-09-26 04:41:41 --> URI Class Initialized
INFO - 2025-09-26 04:41:41 --> Router Class Initialized
INFO - 2025-09-26 04:41:41 --> Output Class Initialized
INFO - 2025-09-26 04:41:41 --> Security Class Initialized
DEBUG - 2025-09-26 04:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:41:41 --> CSRF cookie sent
INFO - 2025-09-26 04:41:41 --> Input Class Initialized
INFO - 2025-09-26 04:41:41 --> Language Class Initialized
INFO - 2025-09-26 04:41:41 --> Loader Class Initialized
INFO - 2025-09-26 04:41:41 --> Helper loaded: url_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: text_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: string_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: form_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: download_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: security_helper
INFO - 2025-09-26 04:41:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:41:41 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:41:41 --> Form Validation Class Initialized
INFO - 2025-09-26 04:41:41 --> Model "User_model" initialized
INFO - 2025-09-26 09:41:41 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:41:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:41:41 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:41:41 --> Controller Class Initialized
INFO - 2025-09-26 09:41:41 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:41:41 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-26 09:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-26 09:41:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:41:41 --> Pagination Class Initialized
INFO - 2025-09-26 09:41:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-26 09:41:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:41:41 --> Model "Log_model" initialized
INFO - 2025-09-26 09:41:41 --> Final output sent to browser
DEBUG - 2025-09-26 09:41:41 --> Total execution time: 0.0428
INFO - 2025-09-26 04:43:30 --> Config Class Initialized
INFO - 2025-09-26 04:43:30 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:43:30 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:43:30 --> Utf8 Class Initialized
INFO - 2025-09-26 04:43:30 --> URI Class Initialized
DEBUG - 2025-09-26 04:43:30 --> No URI present. Default controller set.
INFO - 2025-09-26 04:43:30 --> Router Class Initialized
INFO - 2025-09-26 04:43:30 --> Output Class Initialized
INFO - 2025-09-26 04:43:30 --> Security Class Initialized
DEBUG - 2025-09-26 04:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:43:30 --> CSRF cookie sent
INFO - 2025-09-26 04:43:30 --> Input Class Initialized
INFO - 2025-09-26 04:43:30 --> Language Class Initialized
INFO - 2025-09-26 04:43:30 --> Loader Class Initialized
INFO - 2025-09-26 04:43:30 --> Helper loaded: url_helper
INFO - 2025-09-26 04:43:30 --> Helper loaded: text_helper
INFO - 2025-09-26 04:43:30 --> Helper loaded: string_helper
INFO - 2025-09-26 04:43:30 --> Helper loaded: form_helper
INFO - 2025-09-26 04:43:30 --> Helper loaded: download_helper
INFO - 2025-09-26 04:43:30 --> Helper loaded: security_helper
INFO - 2025-09-26 04:43:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:43:30 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:43:30 --> Form Validation Class Initialized
INFO - 2025-09-26 04:43:30 --> Model "User_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:43:30 --> Controller Class Initialized
INFO - 2025-09-26 09:43:30 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Video_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:43:30 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:43:30 --> Pagination Class Initialized
INFO - 2025-09-26 09:43:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-26 09:43:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 09:43:30 --> Model "Log_model" initialized
INFO - 2025-09-26 09:43:30 --> Final output sent to browser
DEBUG - 2025-09-26 09:43:30 --> Total execution time: 0.1130
INFO - 2025-09-26 04:54:10 --> Config Class Initialized
INFO - 2025-09-26 04:54:10 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:54:10 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:54:10 --> Utf8 Class Initialized
INFO - 2025-09-26 04:54:10 --> URI Class Initialized
INFO - 2025-09-26 04:54:10 --> Router Class Initialized
INFO - 2025-09-26 04:54:10 --> Output Class Initialized
INFO - 2025-09-26 04:54:10 --> Security Class Initialized
DEBUG - 2025-09-26 04:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:54:10 --> CSRF cookie sent
INFO - 2025-09-26 04:54:10 --> Input Class Initialized
INFO - 2025-09-26 04:54:10 --> Language Class Initialized
INFO - 2025-09-26 04:54:10 --> Loader Class Initialized
INFO - 2025-09-26 04:54:10 --> Helper loaded: url_helper
INFO - 2025-09-26 04:54:10 --> Helper loaded: text_helper
INFO - 2025-09-26 04:54:10 --> Helper loaded: string_helper
INFO - 2025-09-26 04:54:10 --> Helper loaded: form_helper
INFO - 2025-09-26 04:54:10 --> Helper loaded: download_helper
INFO - 2025-09-26 04:54:10 --> Helper loaded: security_helper
INFO - 2025-09-26 04:54:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:54:10 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:54:10 --> Form Validation Class Initialized
INFO - 2025-09-26 04:54:10 --> Model "User_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:54:10 --> Controller Class Initialized
INFO - 2025-09-26 09:54:10 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Video_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:54:10 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:54:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-26 09:54:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 09:54:10 --> Model "Log_model" initialized
INFO - 2025-09-26 09:54:10 --> Final output sent to browser
DEBUG - 2025-09-26 09:54:10 --> Total execution time: 0.0479
INFO - 2025-09-26 04:54:14 --> Config Class Initialized
INFO - 2025-09-26 04:54:14 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:54:14 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:54:14 --> Utf8 Class Initialized
INFO - 2025-09-26 04:54:14 --> URI Class Initialized
DEBUG - 2025-09-26 04:54:14 --> No URI present. Default controller set.
INFO - 2025-09-26 04:54:14 --> Router Class Initialized
INFO - 2025-09-26 04:54:14 --> Output Class Initialized
INFO - 2025-09-26 04:54:14 --> Security Class Initialized
DEBUG - 2025-09-26 04:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:54:14 --> CSRF cookie sent
INFO - 2025-09-26 04:54:14 --> Input Class Initialized
INFO - 2025-09-26 04:54:14 --> Language Class Initialized
INFO - 2025-09-26 04:54:14 --> Loader Class Initialized
INFO - 2025-09-26 04:54:14 --> Helper loaded: url_helper
INFO - 2025-09-26 04:54:14 --> Helper loaded: text_helper
INFO - 2025-09-26 04:54:14 --> Helper loaded: string_helper
INFO - 2025-09-26 04:54:14 --> Helper loaded: form_helper
INFO - 2025-09-26 04:54:14 --> Helper loaded: download_helper
INFO - 2025-09-26 04:54:14 --> Helper loaded: security_helper
INFO - 2025-09-26 04:54:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:54:14 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:54:14 --> Form Validation Class Initialized
INFO - 2025-09-26 04:54:14 --> Model "User_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:54:14 --> Controller Class Initialized
INFO - 2025-09-26 09:54:14 --> Model "Berita_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Galeri_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Video_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Agenda_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Tautan_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Mitra_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Prodi_model" initialized
INFO - 2025-09-26 09:54:14 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 09:54:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 09:54:14 --> Pagination Class Initialized
INFO - 2025-09-26 09:54:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-26 09:54:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 09:54:14 --> Model "Log_model" initialized
INFO - 2025-09-26 09:54:14 --> Final output sent to browser
DEBUG - 2025-09-26 09:54:14 --> Total execution time: 0.0914
INFO - 2025-09-26 04:57:00 --> Config Class Initialized
INFO - 2025-09-26 04:57:00 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:57:00 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:57:00 --> Utf8 Class Initialized
INFO - 2025-09-26 04:57:00 --> URI Class Initialized
INFO - 2025-09-26 04:57:00 --> Router Class Initialized
INFO - 2025-09-26 04:57:00 --> Output Class Initialized
INFO - 2025-09-26 04:57:00 --> Security Class Initialized
DEBUG - 2025-09-26 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:57:00 --> CSRF cookie sent
INFO - 2025-09-26 04:57:00 --> Input Class Initialized
INFO - 2025-09-26 04:57:00 --> Language Class Initialized
INFO - 2025-09-26 04:57:00 --> Loader Class Initialized
INFO - 2025-09-26 04:57:00 --> Helper loaded: url_helper
INFO - 2025-09-26 04:57:00 --> Helper loaded: text_helper
INFO - 2025-09-26 04:57:00 --> Helper loaded: string_helper
INFO - 2025-09-26 04:57:00 --> Helper loaded: form_helper
INFO - 2025-09-26 04:57:00 --> Helper loaded: download_helper
INFO - 2025-09-26 04:57:00 --> Helper loaded: security_helper
INFO - 2025-09-26 04:57:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:57:00 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:57:00 --> Form Validation Class Initialized
INFO - 2025-09-26 04:57:00 --> Model "User_model" initialized
INFO - 2025-09-26 09:57:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:57:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:57:00 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:57:00 --> Controller Class Initialized
ERROR - 2025-09-26 09:57:21 --> SEAFILE API [GET http://192.168.11.105/api2//repos/] => HTTP 0
ERROR - 2025-09-26 09:57:21 --> RESPONSE: 
ERROR - 2025-09-26 09:57:21 --> SEAFILE LIST LIBRARIES RESPONSE: Array
(
    [error] => Failed to connect to 192.168.11.105 port 80: Timed out
)

INFO - 2025-09-26 09:57:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/seafile/list.php
INFO - 2025-09-26 09:57:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:57:21 --> Model "Log_model" initialized
INFO - 2025-09-26 09:57:21 --> Final output sent to browser
DEBUG - 2025-09-26 09:57:21 --> Total execution time: 21.4931
INFO - 2025-09-26 04:57:46 --> Config Class Initialized
INFO - 2025-09-26 04:57:46 --> Hooks Class Initialized
DEBUG - 2025-09-26 04:57:46 --> UTF-8 Support Enabled
INFO - 2025-09-26 04:57:46 --> Utf8 Class Initialized
INFO - 2025-09-26 04:57:46 --> URI Class Initialized
INFO - 2025-09-26 04:57:46 --> Router Class Initialized
INFO - 2025-09-26 04:57:46 --> Output Class Initialized
INFO - 2025-09-26 04:57:46 --> Security Class Initialized
DEBUG - 2025-09-26 04:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 04:57:46 --> CSRF cookie sent
INFO - 2025-09-26 04:57:46 --> Input Class Initialized
INFO - 2025-09-26 04:57:46 --> Language Class Initialized
INFO - 2025-09-26 04:57:46 --> Loader Class Initialized
INFO - 2025-09-26 04:57:46 --> Helper loaded: url_helper
INFO - 2025-09-26 04:57:46 --> Helper loaded: text_helper
INFO - 2025-09-26 04:57:46 --> Helper loaded: string_helper
INFO - 2025-09-26 04:57:46 --> Helper loaded: form_helper
INFO - 2025-09-26 04:57:46 --> Helper loaded: download_helper
INFO - 2025-09-26 04:57:46 --> Helper loaded: security_helper
INFO - 2025-09-26 04:57:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 04:57:46 --> Database Driver Class Initialized
DEBUG - 2025-09-26 04:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 04:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 04:57:46 --> Form Validation Class Initialized
INFO - 2025-09-26 04:57:46 --> Model "User_model" initialized
INFO - 2025-09-26 09:57:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 09:57:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 09:57:46 --> Model "Nav_model" initialized
INFO - 2025-09-26 09:57:46 --> Controller Class Initialized
ERROR - 2025-09-26 09:58:07 --> SEAFILE API [GET http://192.168.11.105/api2//repos/] => HTTP 0
ERROR - 2025-09-26 09:58:07 --> RESPONSE: 
ERROR - 2025-09-26 09:58:07 --> SEAFILE LIST LIBRARIES RESPONSE: Array
(
    [error] => Failed to connect to 192.168.11.105 port 80: Timed out
)

INFO - 2025-09-26 09:58:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/seafile/list.php
INFO - 2025-09-26 09:58:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-26 09:58:07 --> Model "Log_model" initialized
INFO - 2025-09-26 09:58:07 --> Final output sent to browser
DEBUG - 2025-09-26 09:58:07 --> Total execution time: 21.4553
INFO - 2025-09-26 08:37:41 --> Config Class Initialized
INFO - 2025-09-26 08:37:41 --> Hooks Class Initialized
DEBUG - 2025-09-26 08:37:41 --> UTF-8 Support Enabled
INFO - 2025-09-26 08:37:41 --> Utf8 Class Initialized
INFO - 2025-09-26 08:37:41 --> URI Class Initialized
DEBUG - 2025-09-26 08:37:41 --> No URI present. Default controller set.
INFO - 2025-09-26 08:37:41 --> Router Class Initialized
INFO - 2025-09-26 08:37:41 --> Output Class Initialized
INFO - 2025-09-26 08:37:42 --> Security Class Initialized
DEBUG - 2025-09-26 08:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 08:37:42 --> CSRF cookie sent
INFO - 2025-09-26 08:37:42 --> Input Class Initialized
INFO - 2025-09-26 08:37:42 --> Language Class Initialized
INFO - 2025-09-26 08:37:42 --> Loader Class Initialized
INFO - 2025-09-26 08:37:42 --> Helper loaded: url_helper
INFO - 2025-09-26 08:37:42 --> Helper loaded: text_helper
INFO - 2025-09-26 08:37:42 --> Helper loaded: string_helper
INFO - 2025-09-26 08:37:42 --> Helper loaded: form_helper
INFO - 2025-09-26 08:37:42 --> Helper loaded: download_helper
INFO - 2025-09-26 08:37:42 --> Helper loaded: security_helper
INFO - 2025-09-26 08:37:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 08:37:43 --> Database Driver Class Initialized
DEBUG - 2025-09-26 08:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 08:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 08:37:43 --> Form Validation Class Initialized
INFO - 2025-09-26 08:37:44 --> Model "User_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Nav_model" initialized
INFO - 2025-09-26 13:37:44 --> Controller Class Initialized
INFO - 2025-09-26 13:37:44 --> Model "Berita_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Galeri_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Video_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Agenda_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Tautan_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Mitra_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Prodi_model" initialized
INFO - 2025-09-26 13:37:44 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 13:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 13:37:44 --> Pagination Class Initialized
INFO - 2025-09-26 13:37:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-26 13:37:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 13:37:47 --> Model "Log_model" initialized
INFO - 2025-09-26 13:37:47 --> Final output sent to browser
DEBUG - 2025-09-26 13:37:47 --> Total execution time: 6.2908
INFO - 2025-09-26 08:37:53 --> Config Class Initialized
INFO - 2025-09-26 08:37:53 --> Hooks Class Initialized
DEBUG - 2025-09-26 08:37:53 --> UTF-8 Support Enabled
INFO - 2025-09-26 08:37:53 --> Utf8 Class Initialized
INFO - 2025-09-26 08:37:53 --> URI Class Initialized
DEBUG - 2025-09-26 08:37:53 --> No URI present. Default controller set.
INFO - 2025-09-26 08:37:53 --> Router Class Initialized
INFO - 2025-09-26 08:37:53 --> Output Class Initialized
INFO - 2025-09-26 08:37:53 --> Security Class Initialized
DEBUG - 2025-09-26 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-26 08:37:53 --> CSRF cookie sent
INFO - 2025-09-26 08:37:53 --> Input Class Initialized
INFO - 2025-09-26 08:37:53 --> Language Class Initialized
INFO - 2025-09-26 08:37:53 --> Loader Class Initialized
INFO - 2025-09-26 08:37:53 --> Helper loaded: url_helper
INFO - 2025-09-26 08:37:53 --> Helper loaded: text_helper
INFO - 2025-09-26 08:37:53 --> Helper loaded: string_helper
INFO - 2025-09-26 08:37:53 --> Helper loaded: form_helper
INFO - 2025-09-26 08:37:53 --> Helper loaded: download_helper
INFO - 2025-09-26 08:37:53 --> Helper loaded: security_helper
INFO - 2025-09-26 08:37:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-26 08:37:53 --> Database Driver Class Initialized
DEBUG - 2025-09-26 08:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-26 08:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-26 08:37:53 --> Form Validation Class Initialized
INFO - 2025-09-26 08:37:53 --> Model "User_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Nav_model" initialized
INFO - 2025-09-26 13:37:53 --> Controller Class Initialized
INFO - 2025-09-26 13:37:53 --> Model "Berita_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Galeri_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Video_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Agenda_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Tautan_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Mitra_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Jurusan_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Prodi_model" initialized
INFO - 2025-09-26 13:37:53 --> Model "Testimoni_model" initialized
INFO - 2025-09-26 13:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-26 13:37:53 --> Pagination Class Initialized
INFO - 2025-09-26 13:37:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-26 13:37:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-26 13:37:53 --> Model "Log_model" initialized
INFO - 2025-09-26 13:37:53 --> Final output sent to browser
DEBUG - 2025-09-26 13:37:53 --> Total execution time: 0.1125
