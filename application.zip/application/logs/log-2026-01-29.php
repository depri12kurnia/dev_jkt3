<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-29 03:32:56 --> Config Class Initialized
INFO - 2026-01-29 03:32:56 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:32:57 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:32:57 --> Utf8 Class Initialized
INFO - 2026-01-29 03:32:57 --> URI Class Initialized
DEBUG - 2026-01-29 03:32:57 --> No URI present. Default controller set.
INFO - 2026-01-29 03:32:57 --> Router Class Initialized
INFO - 2026-01-29 03:32:57 --> Output Class Initialized
INFO - 2026-01-29 03:32:57 --> Security Class Initialized
DEBUG - 2026-01-29 03:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:32:57 --> CSRF cookie sent
INFO - 2026-01-29 03:32:57 --> Input Class Initialized
INFO - 2026-01-29 03:32:58 --> Language Class Initialized
INFO - 2026-01-29 03:32:58 --> Loader Class Initialized
INFO - 2026-01-29 03:32:58 --> Helper loaded: url_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: text_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: string_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: form_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: download_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: security_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:32:59 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:32:59 --> Form Validation Class Initialized
INFO - 2026-01-29 03:32:59 --> Model "User_model" initialized
INFO - 2026-01-29 09:32:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:33:00 --> Controller Class Initialized
INFO - 2026-01-29 09:33:00 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Video_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:33:01 --> Pagination Class Initialized
INFO - 2026-01-29 09:33:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:33:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:33:04 --> Model "Log_model" initialized
INFO - 2026-01-29 09:33:04 --> Final output sent to browser
DEBUG - 2026-01-29 09:33:04 --> Total execution time: 8.0018
INFO - 2026-01-29 03:33:48 --> Config Class Initialized
INFO - 2026-01-29 03:33:48 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:33:48 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:33:48 --> Utf8 Class Initialized
INFO - 2026-01-29 03:33:48 --> URI Class Initialized
DEBUG - 2026-01-29 03:33:48 --> No URI present. Default controller set.
INFO - 2026-01-29 03:33:48 --> Router Class Initialized
INFO - 2026-01-29 03:33:48 --> Output Class Initialized
INFO - 2026-01-29 03:33:48 --> Security Class Initialized
DEBUG - 2026-01-29 03:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:33:48 --> CSRF cookie sent
INFO - 2026-01-29 03:33:48 --> Input Class Initialized
INFO - 2026-01-29 03:33:48 --> Language Class Initialized
INFO - 2026-01-29 03:33:48 --> Loader Class Initialized
INFO - 2026-01-29 03:33:48 --> Helper loaded: url_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: text_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: string_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: form_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: download_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: security_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:33:48 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:33:48 --> Form Validation Class Initialized
INFO - 2026-01-29 03:33:48 --> Model "User_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:33:48 --> Controller Class Initialized
INFO - 2026-01-29 09:33:48 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Video_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:33:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:33:48 --> Pagination Class Initialized
INFO - 2026-01-29 09:33:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:33:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:33:48 --> Model "Log_model" initialized
INFO - 2026-01-29 09:33:48 --> Final output sent to browser
DEBUG - 2026-01-29 09:33:48 --> Total execution time: 0.3001
INFO - 2026-01-29 03:34:06 --> Config Class Initialized
INFO - 2026-01-29 03:34:06 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:34:06 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:34:06 --> Utf8 Class Initialized
INFO - 2026-01-29 03:34:06 --> URI Class Initialized
DEBUG - 2026-01-29 03:34:06 --> No URI present. Default controller set.
INFO - 2026-01-29 03:34:06 --> Router Class Initialized
INFO - 2026-01-29 03:34:06 --> Output Class Initialized
INFO - 2026-01-29 03:34:06 --> Security Class Initialized
DEBUG - 2026-01-29 03:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:34:06 --> CSRF cookie sent
INFO - 2026-01-29 03:34:06 --> Input Class Initialized
INFO - 2026-01-29 03:34:06 --> Language Class Initialized
INFO - 2026-01-29 03:34:06 --> Loader Class Initialized
INFO - 2026-01-29 03:34:06 --> Helper loaded: url_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: text_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: string_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: form_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: download_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: security_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:34:06 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:34:06 --> Form Validation Class Initialized
INFO - 2026-01-29 03:34:06 --> Model "User_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:34:06 --> Controller Class Initialized
INFO - 2026-01-29 09:34:06 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Video_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:34:06 --> Pagination Class Initialized
INFO - 2026-01-29 09:34:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:34:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:34:06 --> Model "Log_model" initialized
INFO - 2026-01-29 09:34:06 --> Final output sent to browser
DEBUG - 2026-01-29 09:34:06 --> Total execution time: 0.3491
INFO - 2026-01-29 03:34:08 --> Config Class Initialized
INFO - 2026-01-29 03:34:08 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:34:08 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:34:08 --> Utf8 Class Initialized
INFO - 2026-01-29 03:34:08 --> URI Class Initialized
DEBUG - 2026-01-29 03:34:08 --> No URI present. Default controller set.
INFO - 2026-01-29 03:34:08 --> Router Class Initialized
INFO - 2026-01-29 03:34:08 --> Output Class Initialized
INFO - 2026-01-29 03:34:08 --> Security Class Initialized
DEBUG - 2026-01-29 03:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:34:08 --> CSRF cookie sent
INFO - 2026-01-29 03:34:08 --> Input Class Initialized
INFO - 2026-01-29 03:34:08 --> Language Class Initialized
INFO - 2026-01-29 03:34:08 --> Loader Class Initialized
INFO - 2026-01-29 03:34:08 --> Helper loaded: url_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: text_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: string_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: form_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: download_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: security_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:34:08 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:34:08 --> Form Validation Class Initialized
INFO - 2026-01-29 03:34:08 --> Model "User_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:34:08 --> Controller Class Initialized
INFO - 2026-01-29 09:34:08 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Video_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:34:08 --> Pagination Class Initialized
INFO - 2026-01-29 09:34:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:34:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:34:08 --> Model "Log_model" initialized
INFO - 2026-01-29 09:34:08 --> Final output sent to browser
DEBUG - 2026-01-29 09:34:08 --> Total execution time: 0.3556
INFO - 2026-01-29 03:35:44 --> Config Class Initialized
INFO - 2026-01-29 03:35:44 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:35:44 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:35:44 --> Utf8 Class Initialized
INFO - 2026-01-29 03:35:44 --> URI Class Initialized
DEBUG - 2026-01-29 03:35:44 --> No URI present. Default controller set.
INFO - 2026-01-29 03:35:44 --> Router Class Initialized
INFO - 2026-01-29 03:35:44 --> Output Class Initialized
INFO - 2026-01-29 03:35:44 --> Security Class Initialized
DEBUG - 2026-01-29 03:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:35:44 --> CSRF cookie sent
INFO - 2026-01-29 03:35:44 --> Input Class Initialized
INFO - 2026-01-29 03:35:44 --> Language Class Initialized
INFO - 2026-01-29 03:35:44 --> Loader Class Initialized
INFO - 2026-01-29 03:35:44 --> Helper loaded: url_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: text_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: string_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: form_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: download_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: security_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:35:44 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:35:44 --> Form Validation Class Initialized
INFO - 2026-01-29 03:35:44 --> Model "User_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:35:44 --> Controller Class Initialized
INFO - 2026-01-29 09:35:44 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Video_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:35:44 --> Pagination Class Initialized
INFO - 2026-01-29 09:35:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:35:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:35:44 --> Model "Log_model" initialized
INFO - 2026-01-29 09:35:44 --> Final output sent to browser
DEBUG - 2026-01-29 09:35:44 --> Total execution time: 0.2932
INFO - 2026-01-29 03:35:58 --> Config Class Initialized
INFO - 2026-01-29 03:35:58 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:35:58 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:35:58 --> Utf8 Class Initialized
INFO - 2026-01-29 03:35:58 --> URI Class Initialized
DEBUG - 2026-01-29 03:35:58 --> No URI present. Default controller set.
INFO - 2026-01-29 03:35:58 --> Router Class Initialized
INFO - 2026-01-29 03:35:58 --> Output Class Initialized
INFO - 2026-01-29 03:35:58 --> Security Class Initialized
DEBUG - 2026-01-29 03:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:35:58 --> CSRF cookie sent
INFO - 2026-01-29 03:35:58 --> Input Class Initialized
INFO - 2026-01-29 03:35:58 --> Language Class Initialized
INFO - 2026-01-29 03:35:58 --> Loader Class Initialized
INFO - 2026-01-29 03:35:58 --> Helper loaded: url_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: text_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: string_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: form_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: download_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: security_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:35:58 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:35:58 --> Form Validation Class Initialized
INFO - 2026-01-29 03:35:58 --> Model "User_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:35:58 --> Controller Class Initialized
INFO - 2026-01-29 09:35:58 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Video_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:35:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:35:58 --> Pagination Class Initialized
INFO - 2026-01-29 09:35:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:35:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:35:58 --> Model "Log_model" initialized
INFO - 2026-01-29 09:35:58 --> Final output sent to browser
DEBUG - 2026-01-29 09:35:58 --> Total execution time: 0.3384
INFO - 2026-01-29 03:36:01 --> Config Class Initialized
INFO - 2026-01-29 03:36:01 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:36:01 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:36:01 --> Utf8 Class Initialized
INFO - 2026-01-29 03:36:01 --> URI Class Initialized
DEBUG - 2026-01-29 03:36:01 --> No URI present. Default controller set.
INFO - 2026-01-29 03:36:01 --> Router Class Initialized
INFO - 2026-01-29 03:36:01 --> Output Class Initialized
INFO - 2026-01-29 03:36:01 --> Security Class Initialized
DEBUG - 2026-01-29 03:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:36:01 --> CSRF cookie sent
INFO - 2026-01-29 03:36:01 --> Input Class Initialized
INFO - 2026-01-29 03:36:01 --> Language Class Initialized
INFO - 2026-01-29 03:36:01 --> Loader Class Initialized
INFO - 2026-01-29 03:36:01 --> Helper loaded: url_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: text_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: string_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: form_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: download_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: security_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:36:01 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:36:01 --> Form Validation Class Initialized
INFO - 2026-01-29 03:36:01 --> Model "User_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:36:01 --> Controller Class Initialized
INFO - 2026-01-29 09:36:01 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Video_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:36:01 --> Pagination Class Initialized
INFO - 2026-01-29 09:36:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:36:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:36:01 --> Model "Log_model" initialized
INFO - 2026-01-29 09:36:01 --> Final output sent to browser
DEBUG - 2026-01-29 09:36:01 --> Total execution time: 0.2654
INFO - 2026-01-29 03:36:10 --> Config Class Initialized
INFO - 2026-01-29 03:36:10 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:36:10 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:36:10 --> Utf8 Class Initialized
INFO - 2026-01-29 03:36:10 --> URI Class Initialized
DEBUG - 2026-01-29 03:36:10 --> No URI present. Default controller set.
INFO - 2026-01-29 03:36:10 --> Router Class Initialized
INFO - 2026-01-29 03:36:10 --> Output Class Initialized
INFO - 2026-01-29 03:36:10 --> Security Class Initialized
DEBUG - 2026-01-29 03:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:36:10 --> CSRF cookie sent
INFO - 2026-01-29 03:36:10 --> Input Class Initialized
INFO - 2026-01-29 03:36:10 --> Language Class Initialized
INFO - 2026-01-29 03:36:10 --> Loader Class Initialized
INFO - 2026-01-29 03:36:10 --> Helper loaded: url_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: text_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: string_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: form_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: download_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: security_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:36:10 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:36:10 --> Form Validation Class Initialized
INFO - 2026-01-29 03:36:10 --> Model "User_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:36:10 --> Controller Class Initialized
INFO - 2026-01-29 09:36:10 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Video_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:36:10 --> Pagination Class Initialized
INFO - 2026-01-29 09:36:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:36:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:36:10 --> Model "Log_model" initialized
INFO - 2026-01-29 09:36:10 --> Final output sent to browser
DEBUG - 2026-01-29 09:36:10 --> Total execution time: 0.2845
INFO - 2026-01-29 03:36:31 --> Config Class Initialized
INFO - 2026-01-29 03:36:31 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:36:31 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:36:31 --> Utf8 Class Initialized
INFO - 2026-01-29 03:36:31 --> URI Class Initialized
DEBUG - 2026-01-29 03:36:31 --> No URI present. Default controller set.
INFO - 2026-01-29 03:36:31 --> Router Class Initialized
INFO - 2026-01-29 03:36:31 --> Output Class Initialized
INFO - 2026-01-29 03:36:31 --> Security Class Initialized
DEBUG - 2026-01-29 03:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:36:31 --> CSRF cookie sent
INFO - 2026-01-29 03:36:31 --> Input Class Initialized
INFO - 2026-01-29 03:36:31 --> Language Class Initialized
INFO - 2026-01-29 03:36:31 --> Loader Class Initialized
INFO - 2026-01-29 03:36:31 --> Helper loaded: url_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: text_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: string_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: form_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: download_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: security_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:36:31 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:36:31 --> Form Validation Class Initialized
INFO - 2026-01-29 03:36:31 --> Model "User_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:36:31 --> Controller Class Initialized
INFO - 2026-01-29 09:36:31 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Video_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:36:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:36:32 --> Pagination Class Initialized
INFO - 2026-01-29 09:36:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:36:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:36:32 --> Model "Log_model" initialized
INFO - 2026-01-29 09:36:32 --> Final output sent to browser
DEBUG - 2026-01-29 09:36:32 --> Total execution time: 0.2597
INFO - 2026-01-29 03:36:42 --> Config Class Initialized
INFO - 2026-01-29 03:36:42 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:36:42 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:36:42 --> Utf8 Class Initialized
INFO - 2026-01-29 03:36:42 --> URI Class Initialized
DEBUG - 2026-01-29 03:36:42 --> No URI present. Default controller set.
INFO - 2026-01-29 03:36:42 --> Router Class Initialized
INFO - 2026-01-29 03:36:42 --> Output Class Initialized
INFO - 2026-01-29 03:36:42 --> Security Class Initialized
DEBUG - 2026-01-29 03:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:36:42 --> CSRF cookie sent
INFO - 2026-01-29 03:36:42 --> Input Class Initialized
INFO - 2026-01-29 03:36:42 --> Language Class Initialized
INFO - 2026-01-29 03:36:42 --> Loader Class Initialized
INFO - 2026-01-29 03:36:42 --> Helper loaded: url_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: text_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: string_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: form_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: download_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: security_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:36:42 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:36:42 --> Form Validation Class Initialized
INFO - 2026-01-29 03:36:42 --> Model "User_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:36:42 --> Controller Class Initialized
INFO - 2026-01-29 09:36:42 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Video_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:36:42 --> Pagination Class Initialized
INFO - 2026-01-29 09:36:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:36:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:36:42 --> Model "Log_model" initialized
INFO - 2026-01-29 09:36:42 --> Final output sent to browser
DEBUG - 2026-01-29 09:36:42 --> Total execution time: 0.3289
INFO - 2026-01-29 03:37:19 --> Config Class Initialized
INFO - 2026-01-29 03:37:19 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:37:19 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:37:19 --> Utf8 Class Initialized
INFO - 2026-01-29 03:37:19 --> URI Class Initialized
INFO - 2026-01-29 03:37:19 --> Router Class Initialized
INFO - 2026-01-29 03:37:19 --> Output Class Initialized
INFO - 2026-01-29 03:37:20 --> Security Class Initialized
DEBUG - 2026-01-29 03:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:37:20 --> CSRF cookie sent
INFO - 2026-01-29 03:37:20 --> Input Class Initialized
INFO - 2026-01-29 03:37:20 --> Language Class Initialized
INFO - 2026-01-29 03:37:20 --> Loader Class Initialized
INFO - 2026-01-29 03:37:20 --> Helper loaded: url_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: text_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: string_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: form_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: download_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: security_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:37:20 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:37:20 --> Form Validation Class Initialized
INFO - 2026-01-29 03:37:20 --> Model "User_model" initialized
INFO - 2026-01-29 09:37:20 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:37:20 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:37:20 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:37:20 --> Controller Class Initialized
INFO - 2026-01-29 09:37:20 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:37:20 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:37:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:37:20 --> Pagination Class Initialized
INFO - 2026-01-29 09:37:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:37:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:37:20 --> Model "Log_model" initialized
INFO - 2026-01-29 09:37:20 --> Final output sent to browser
DEBUG - 2026-01-29 09:37:20 --> Total execution time: 0.5158
INFO - 2026-01-29 03:37:38 --> Config Class Initialized
INFO - 2026-01-29 03:37:38 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:37:38 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:37:38 --> Utf8 Class Initialized
INFO - 2026-01-29 03:37:38 --> URI Class Initialized
INFO - 2026-01-29 03:37:38 --> Router Class Initialized
INFO - 2026-01-29 03:37:38 --> Output Class Initialized
INFO - 2026-01-29 03:37:38 --> Security Class Initialized
DEBUG - 2026-01-29 03:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:37:38 --> CSRF cookie sent
INFO - 2026-01-29 03:37:38 --> Input Class Initialized
INFO - 2026-01-29 03:37:38 --> Language Class Initialized
INFO - 2026-01-29 03:37:38 --> Loader Class Initialized
INFO - 2026-01-29 03:37:38 --> Helper loaded: url_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: text_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: string_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: form_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: download_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: security_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:37:38 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:37:38 --> Form Validation Class Initialized
INFO - 2026-01-29 03:37:38 --> Model "User_model" initialized
INFO - 2026-01-29 09:37:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:37:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:37:38 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:37:38 --> Controller Class Initialized
INFO - 2026-01-29 09:37:38 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:37:38 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:37:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:37:38 --> Pagination Class Initialized
INFO - 2026-01-29 09:37:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:37:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:37:38 --> Model "Log_model" initialized
INFO - 2026-01-29 09:37:38 --> Final output sent to browser
DEBUG - 2026-01-29 09:37:38 --> Total execution time: 0.2154
INFO - 2026-01-29 03:37:54 --> Config Class Initialized
INFO - 2026-01-29 03:37:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:37:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:37:54 --> Utf8 Class Initialized
INFO - 2026-01-29 03:37:55 --> URI Class Initialized
INFO - 2026-01-29 03:37:55 --> Router Class Initialized
INFO - 2026-01-29 03:37:55 --> Output Class Initialized
INFO - 2026-01-29 03:37:55 --> Security Class Initialized
DEBUG - 2026-01-29 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:37:55 --> CSRF cookie sent
INFO - 2026-01-29 03:37:55 --> Input Class Initialized
INFO - 2026-01-29 03:37:55 --> Language Class Initialized
INFO - 2026-01-29 03:37:55 --> Loader Class Initialized
INFO - 2026-01-29 03:37:55 --> Helper loaded: url_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: text_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: string_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: form_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: download_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: security_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:37:55 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:37:55 --> Form Validation Class Initialized
INFO - 2026-01-29 03:37:55 --> Model "User_model" initialized
INFO - 2026-01-29 09:37:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:37:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:37:55 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:37:55 --> Controller Class Initialized
INFO - 2026-01-29 09:37:55 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:37:55 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:37:55 --> Pagination Class Initialized
INFO - 2026-01-29 09:37:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:37:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:37:55 --> Model "Log_model" initialized
INFO - 2026-01-29 09:37:55 --> Final output sent to browser
DEBUG - 2026-01-29 09:37:55 --> Total execution time: 0.3250
INFO - 2026-01-29 03:38:02 --> Config Class Initialized
INFO - 2026-01-29 03:38:02 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:38:02 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:38:02 --> Utf8 Class Initialized
INFO - 2026-01-29 03:38:02 --> URI Class Initialized
INFO - 2026-01-29 03:38:02 --> Router Class Initialized
INFO - 2026-01-29 03:38:02 --> Output Class Initialized
INFO - 2026-01-29 03:38:02 --> Security Class Initialized
DEBUG - 2026-01-29 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:38:02 --> CSRF cookie sent
INFO - 2026-01-29 03:38:02 --> Input Class Initialized
INFO - 2026-01-29 03:38:02 --> Language Class Initialized
INFO - 2026-01-29 03:38:02 --> Loader Class Initialized
INFO - 2026-01-29 03:38:02 --> Helper loaded: url_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: text_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: string_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: form_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: download_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: security_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:38:02 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:38:02 --> Form Validation Class Initialized
INFO - 2026-01-29 03:38:02 --> Model "User_model" initialized
INFO - 2026-01-29 09:38:02 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:38:02 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:38:02 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:38:02 --> Controller Class Initialized
INFO - 2026-01-29 09:38:02 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:38:02 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/read.php
INFO - 2026-01-29 09:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:38:03 --> Model "Log_model" initialized
INFO - 2026-01-29 09:38:03 --> Final output sent to browser
DEBUG - 2026-01-29 09:38:03 --> Total execution time: 0.6122
INFO - 2026-01-29 03:38:06 --> Config Class Initialized
INFO - 2026-01-29 03:38:06 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:38:06 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:38:06 --> Utf8 Class Initialized
INFO - 2026-01-29 03:38:06 --> URI Class Initialized
INFO - 2026-01-29 03:38:06 --> Router Class Initialized
INFO - 2026-01-29 03:38:06 --> Output Class Initialized
INFO - 2026-01-29 03:38:06 --> Security Class Initialized
DEBUG - 2026-01-29 03:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:38:06 --> CSRF cookie sent
INFO - 2026-01-29 03:38:06 --> Input Class Initialized
INFO - 2026-01-29 03:38:06 --> Language Class Initialized
INFO - 2026-01-29 03:38:06 --> Loader Class Initialized
INFO - 2026-01-29 03:38:06 --> Helper loaded: url_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: text_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: string_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: form_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: download_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: security_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:38:06 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:38:06 --> Form Validation Class Initialized
INFO - 2026-01-29 03:38:06 --> Model "User_model" initialized
INFO - 2026-01-29 09:38:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:38:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:38:06 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:38:06 --> Controller Class Initialized
INFO - 2026-01-29 09:38:06 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:38:06 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:38:06 --> Pagination Class Initialized
INFO - 2026-01-29 09:38:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:38:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:38:06 --> Model "Log_model" initialized
INFO - 2026-01-29 09:38:06 --> Final output sent to browser
DEBUG - 2026-01-29 09:38:06 --> Total execution time: 0.3019
INFO - 2026-01-29 03:39:08 --> Config Class Initialized
INFO - 2026-01-29 03:39:08 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:39:08 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:39:08 --> Utf8 Class Initialized
INFO - 2026-01-29 03:39:08 --> URI Class Initialized
INFO - 2026-01-29 03:39:08 --> Router Class Initialized
INFO - 2026-01-29 03:39:08 --> Output Class Initialized
INFO - 2026-01-29 03:39:08 --> Security Class Initialized
DEBUG - 2026-01-29 03:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:39:08 --> CSRF cookie sent
INFO - 2026-01-29 03:39:08 --> Input Class Initialized
INFO - 2026-01-29 03:39:08 --> Language Class Initialized
INFO - 2026-01-29 03:39:08 --> Loader Class Initialized
INFO - 2026-01-29 03:39:08 --> Helper loaded: url_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: text_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: string_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: form_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: download_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: security_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:39:08 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:39:08 --> Form Validation Class Initialized
INFO - 2026-01-29 03:39:08 --> Model "User_model" initialized
INFO - 2026-01-29 09:39:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:39:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:39:08 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:39:08 --> Controller Class Initialized
INFO - 2026-01-29 09:39:08 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:39:08 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:39:08 --> Pagination Class Initialized
INFO - 2026-01-29 09:39:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:39:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:39:08 --> Model "Log_model" initialized
INFO - 2026-01-29 09:39:08 --> Final output sent to browser
DEBUG - 2026-01-29 09:39:08 --> Total execution time: 0.2803
INFO - 2026-01-29 03:39:18 --> Config Class Initialized
INFO - 2026-01-29 03:39:18 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:39:18 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:39:18 --> Utf8 Class Initialized
INFO - 2026-01-29 03:39:18 --> URI Class Initialized
INFO - 2026-01-29 03:39:18 --> Router Class Initialized
INFO - 2026-01-29 03:39:18 --> Output Class Initialized
INFO - 2026-01-29 03:39:18 --> Security Class Initialized
DEBUG - 2026-01-29 03:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:39:18 --> CSRF cookie sent
INFO - 2026-01-29 03:39:18 --> Input Class Initialized
INFO - 2026-01-29 03:39:18 --> Language Class Initialized
INFO - 2026-01-29 03:39:18 --> Loader Class Initialized
INFO - 2026-01-29 03:39:18 --> Helper loaded: url_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: text_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: string_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: form_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: download_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: security_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:39:18 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:39:18 --> Form Validation Class Initialized
INFO - 2026-01-29 03:39:18 --> Model "User_model" initialized
INFO - 2026-01-29 09:39:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:39:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:39:18 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:39:18 --> Controller Class Initialized
INFO - 2026-01-29 09:39:18 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:39:18 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:39:18 --> Pagination Class Initialized
INFO - 2026-01-29 09:39:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:39:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:39:18 --> Model "Log_model" initialized
INFO - 2026-01-29 09:39:18 --> Final output sent to browser
DEBUG - 2026-01-29 09:39:18 --> Total execution time: 0.2394
INFO - 2026-01-29 03:42:54 --> Config Class Initialized
INFO - 2026-01-29 03:42:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:42:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:42:54 --> Utf8 Class Initialized
INFO - 2026-01-29 03:42:54 --> URI Class Initialized
INFO - 2026-01-29 03:42:54 --> Router Class Initialized
INFO - 2026-01-29 03:42:54 --> Output Class Initialized
INFO - 2026-01-29 03:42:54 --> Security Class Initialized
DEBUG - 2026-01-29 03:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:42:54 --> CSRF cookie sent
INFO - 2026-01-29 03:42:54 --> Input Class Initialized
INFO - 2026-01-29 03:42:54 --> Language Class Initialized
INFO - 2026-01-29 03:42:54 --> Loader Class Initialized
INFO - 2026-01-29 03:42:54 --> Helper loaded: url_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: text_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: string_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: form_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: download_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: security_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:42:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:42:54 --> Form Validation Class Initialized
INFO - 2026-01-29 03:42:54 --> Model "User_model" initialized
INFO - 2026-01-29 09:42:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:42:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:42:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:42:54 --> Controller Class Initialized
INFO - 2026-01-29 09:42:54 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:42:54 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:42:54 --> Pagination Class Initialized
INFO - 2026-01-29 09:42:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:42:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:42:54 --> Model "Log_model" initialized
INFO - 2026-01-29 09:42:54 --> Final output sent to browser
DEBUG - 2026-01-29 09:42:54 --> Total execution time: 0.1562
INFO - 2026-01-29 03:42:58 --> Config Class Initialized
INFO - 2026-01-29 03:42:58 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:42:58 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:42:58 --> Utf8 Class Initialized
INFO - 2026-01-29 03:42:58 --> URI Class Initialized
INFO - 2026-01-29 03:42:58 --> Router Class Initialized
INFO - 2026-01-29 03:42:58 --> Output Class Initialized
INFO - 2026-01-29 03:42:58 --> Security Class Initialized
DEBUG - 2026-01-29 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:42:58 --> CSRF cookie sent
INFO - 2026-01-29 03:42:58 --> Input Class Initialized
INFO - 2026-01-29 03:42:58 --> Language Class Initialized
INFO - 2026-01-29 03:42:58 --> Loader Class Initialized
INFO - 2026-01-29 03:42:58 --> Helper loaded: url_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: text_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: string_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: form_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: download_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: security_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:42:58 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:42:58 --> Form Validation Class Initialized
INFO - 2026-01-29 03:42:58 --> Model "User_model" initialized
INFO - 2026-01-29 09:42:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:42:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:42:58 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:42:58 --> Controller Class Initialized
INFO - 2026-01-29 09:42:58 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:42:58 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:42:58 --> Pagination Class Initialized
INFO - 2026-01-29 09:42:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:42:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:42:59 --> Model "Log_model" initialized
INFO - 2026-01-29 09:42:59 --> Final output sent to browser
DEBUG - 2026-01-29 09:42:59 --> Total execution time: 0.1300
INFO - 2026-01-29 03:43:05 --> Config Class Initialized
INFO - 2026-01-29 03:43:05 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:43:05 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:43:05 --> Utf8 Class Initialized
INFO - 2026-01-29 03:43:05 --> URI Class Initialized
INFO - 2026-01-29 03:43:05 --> Router Class Initialized
INFO - 2026-01-29 03:43:05 --> Output Class Initialized
INFO - 2026-01-29 03:43:05 --> Security Class Initialized
DEBUG - 2026-01-29 03:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:43:05 --> CSRF cookie sent
INFO - 2026-01-29 03:43:05 --> Input Class Initialized
INFO - 2026-01-29 03:43:05 --> Language Class Initialized
INFO - 2026-01-29 03:43:05 --> Loader Class Initialized
INFO - 2026-01-29 03:43:05 --> Helper loaded: url_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: text_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: string_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: form_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: download_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: security_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:43:05 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:43:05 --> Form Validation Class Initialized
INFO - 2026-01-29 03:43:05 --> Model "User_model" initialized
INFO - 2026-01-29 09:43:05 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:43:05 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:43:05 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:43:05 --> Controller Class Initialized
INFO - 2026-01-29 09:43:05 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:43:05 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:43:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:43:05 --> Pagination Class Initialized
INFO - 2026-01-29 09:43:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:43:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:43:05 --> Model "Log_model" initialized
INFO - 2026-01-29 09:43:05 --> Final output sent to browser
DEBUG - 2026-01-29 09:43:05 --> Total execution time: 0.1923
INFO - 2026-01-29 03:43:28 --> Config Class Initialized
INFO - 2026-01-29 03:43:28 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:43:28 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:43:28 --> Utf8 Class Initialized
INFO - 2026-01-29 03:43:28 --> URI Class Initialized
INFO - 2026-01-29 03:43:28 --> Router Class Initialized
INFO - 2026-01-29 03:43:28 --> Output Class Initialized
INFO - 2026-01-29 03:43:28 --> Security Class Initialized
DEBUG - 2026-01-29 03:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:43:28 --> CSRF cookie sent
INFO - 2026-01-29 03:43:28 --> Input Class Initialized
INFO - 2026-01-29 03:43:28 --> Language Class Initialized
INFO - 2026-01-29 03:43:28 --> Loader Class Initialized
INFO - 2026-01-29 03:43:28 --> Helper loaded: url_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: text_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: string_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: form_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: download_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: security_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:43:28 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:43:28 --> Form Validation Class Initialized
INFO - 2026-01-29 03:43:28 --> Model "User_model" initialized
INFO - 2026-01-29 09:43:28 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:43:28 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:43:28 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:43:28 --> Controller Class Initialized
INFO - 2026-01-29 09:43:28 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:43:28 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:43:28 --> Pagination Class Initialized
INFO - 2026-01-29 09:43:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:43:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:43:28 --> Model "Log_model" initialized
INFO - 2026-01-29 09:43:28 --> Final output sent to browser
DEBUG - 2026-01-29 09:43:28 --> Total execution time: 0.1583
INFO - 2026-01-29 03:47:54 --> Config Class Initialized
INFO - 2026-01-29 03:47:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:47:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:47:54 --> Utf8 Class Initialized
INFO - 2026-01-29 03:47:54 --> URI Class Initialized
INFO - 2026-01-29 03:47:54 --> Router Class Initialized
INFO - 2026-01-29 03:47:54 --> Output Class Initialized
INFO - 2026-01-29 03:47:54 --> Security Class Initialized
DEBUG - 2026-01-29 03:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:47:54 --> CSRF cookie sent
INFO - 2026-01-29 03:47:54 --> Input Class Initialized
INFO - 2026-01-29 03:47:54 --> Language Class Initialized
INFO - 2026-01-29 03:47:54 --> Loader Class Initialized
INFO - 2026-01-29 03:47:54 --> Helper loaded: url_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: text_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: string_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: form_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: download_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: security_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:47:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:47:54 --> Form Validation Class Initialized
INFO - 2026-01-29 03:47:54 --> Model "User_model" initialized
INFO - 2026-01-29 09:47:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:47:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:47:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:47:54 --> Controller Class Initialized
INFO - 2026-01-29 09:47:54 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:47:54 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:47:54 --> Pagination Class Initialized
INFO - 2026-01-29 09:47:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:47:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:47:54 --> Model "Log_model" initialized
INFO - 2026-01-29 09:47:54 --> Final output sent to browser
DEBUG - 2026-01-29 09:47:54 --> Total execution time: 0.2462
INFO - 2026-01-29 03:48:07 --> Config Class Initialized
INFO - 2026-01-29 03:48:07 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:48:07 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:48:07 --> Utf8 Class Initialized
INFO - 2026-01-29 03:48:07 --> URI Class Initialized
INFO - 2026-01-29 03:48:07 --> Router Class Initialized
INFO - 2026-01-29 03:48:07 --> Output Class Initialized
INFO - 2026-01-29 03:48:07 --> Security Class Initialized
DEBUG - 2026-01-29 03:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:48:07 --> CSRF cookie sent
INFO - 2026-01-29 03:48:07 --> Input Class Initialized
INFO - 2026-01-29 03:48:07 --> Language Class Initialized
INFO - 2026-01-29 03:48:07 --> Loader Class Initialized
INFO - 2026-01-29 03:48:07 --> Helper loaded: url_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: text_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: string_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: form_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: download_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: security_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:48:07 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:48:08 --> Form Validation Class Initialized
INFO - 2026-01-29 03:48:08 --> Model "User_model" initialized
INFO - 2026-01-29 09:48:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:48:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:48:08 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:48:08 --> Controller Class Initialized
INFO - 2026-01-29 09:48:08 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:48:08 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:48:08 --> Pagination Class Initialized
INFO - 2026-01-29 09:48:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:48:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:48:08 --> Model "Log_model" initialized
INFO - 2026-01-29 09:48:08 --> Final output sent to browser
DEBUG - 2026-01-29 09:48:08 --> Total execution time: 0.2964
INFO - 2026-01-29 03:56:09 --> Config Class Initialized
INFO - 2026-01-29 03:56:09 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:56:09 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:56:09 --> Utf8 Class Initialized
INFO - 2026-01-29 03:56:09 --> URI Class Initialized
DEBUG - 2026-01-29 03:56:09 --> No URI present. Default controller set.
INFO - 2026-01-29 03:56:09 --> Router Class Initialized
INFO - 2026-01-29 03:56:09 --> Output Class Initialized
INFO - 2026-01-29 03:56:09 --> Security Class Initialized
DEBUG - 2026-01-29 03:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:56:09 --> CSRF cookie sent
INFO - 2026-01-29 03:56:09 --> Input Class Initialized
INFO - 2026-01-29 03:56:09 --> Language Class Initialized
INFO - 2026-01-29 03:56:09 --> Loader Class Initialized
INFO - 2026-01-29 03:56:09 --> Helper loaded: url_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: text_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: string_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: form_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: download_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: security_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:56:09 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:56:09 --> Form Validation Class Initialized
INFO - 2026-01-29 03:56:09 --> Model "User_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:56:09 --> Controller Class Initialized
INFO - 2026-01-29 09:56:09 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Video_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:56:09 --> Pagination Class Initialized
INFO - 2026-01-29 09:56:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:56:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:56:09 --> Model "Log_model" initialized
INFO - 2026-01-29 09:56:09 --> Final output sent to browser
DEBUG - 2026-01-29 09:56:09 --> Total execution time: 0.2976
INFO - 2026-01-29 03:58:33 --> Config Class Initialized
INFO - 2026-01-29 03:58:33 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:58:33 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:58:33 --> Utf8 Class Initialized
INFO - 2026-01-29 03:58:33 --> URI Class Initialized
INFO - 2026-01-29 03:58:33 --> Router Class Initialized
INFO - 2026-01-29 03:58:33 --> Output Class Initialized
INFO - 2026-01-29 03:58:33 --> Security Class Initialized
DEBUG - 2026-01-29 03:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:58:33 --> CSRF cookie sent
INFO - 2026-01-29 03:58:33 --> Input Class Initialized
INFO - 2026-01-29 03:58:33 --> Language Class Initialized
INFO - 2026-01-29 03:58:33 --> Loader Class Initialized
INFO - 2026-01-29 03:58:33 --> Helper loaded: url_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: text_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: string_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: form_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: download_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: security_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:58:33 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:58:33 --> Form Validation Class Initialized
INFO - 2026-01-29 03:58:33 --> Model "User_model" initialized
INFO - 2026-01-29 09:58:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:58:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:58:33 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:58:33 --> Controller Class Initialized
INFO - 2026-01-29 09:58:33 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:58:33 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:58:33 --> Pagination Class Initialized
INFO - 2026-01-29 09:58:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:58:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:58:33 --> Model "Log_model" initialized
INFO - 2026-01-29 09:58:33 --> Final output sent to browser
DEBUG - 2026-01-29 09:58:33 --> Total execution time: 0.1956
INFO - 2026-01-29 03:59:17 --> Config Class Initialized
INFO - 2026-01-29 03:59:17 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:17 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:17 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:17 --> URI Class Initialized
DEBUG - 2026-01-29 03:59:17 --> No URI present. Default controller set.
INFO - 2026-01-29 03:59:17 --> Router Class Initialized
INFO - 2026-01-29 03:59:17 --> Output Class Initialized
INFO - 2026-01-29 03:59:17 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:17 --> CSRF cookie sent
INFO - 2026-01-29 03:59:17 --> Input Class Initialized
INFO - 2026-01-29 03:59:17 --> Language Class Initialized
INFO - 2026-01-29 03:59:17 --> Loader Class Initialized
INFO - 2026-01-29 03:59:17 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:17 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:17 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:17 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:17 --> Controller Class Initialized
INFO - 2026-01-29 09:59:17 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Video_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:59:17 --> Pagination Class Initialized
INFO - 2026-01-29 09:59:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:59:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:17 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:17 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:17 --> Total execution time: 0.2700
INFO - 2026-01-29 03:59:31 --> Config Class Initialized
INFO - 2026-01-29 03:59:31 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:31 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:31 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:31 --> URI Class Initialized
INFO - 2026-01-29 03:59:31 --> Router Class Initialized
INFO - 2026-01-29 03:59:31 --> Output Class Initialized
INFO - 2026-01-29 03:59:31 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:31 --> CSRF cookie sent
INFO - 2026-01-29 03:59:31 --> Input Class Initialized
INFO - 2026-01-29 03:59:31 --> Language Class Initialized
INFO - 2026-01-29 03:59:31 --> Loader Class Initialized
INFO - 2026-01-29 03:59:31 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:31 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:31 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:31 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:31 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:31 --> Controller Class Initialized
INFO - 2026-01-29 09:59:31 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:59:31 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:59:31 --> Pagination Class Initialized
INFO - 2026-01-29 09:59:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:59:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:31 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:31 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:31 --> Total execution time: 0.1811
INFO - 2026-01-29 03:59:35 --> Config Class Initialized
INFO - 2026-01-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:35 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:35 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:35 --> URI Class Initialized
INFO - 2026-01-29 03:59:35 --> Router Class Initialized
INFO - 2026-01-29 03:59:35 --> Output Class Initialized
INFO - 2026-01-29 03:59:35 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:35 --> CSRF cookie sent
INFO - 2026-01-29 03:59:35 --> Input Class Initialized
INFO - 2026-01-29 03:59:35 --> Language Class Initialized
INFO - 2026-01-29 03:59:35 --> Loader Class Initialized
INFO - 2026-01-29 03:59:35 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:35 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:35 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:35 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:35 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:35 --> Controller Class Initialized
INFO - 2026-01-29 09:59:35 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:59:35 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:59:35 --> Pagination Class Initialized
INFO - 2026-01-29 09:59:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:59:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:35 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:35 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:35 --> Total execution time: 0.1734
INFO - 2026-01-29 03:59:38 --> Config Class Initialized
INFO - 2026-01-29 03:59:38 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:38 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:38 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:38 --> URI Class Initialized
INFO - 2026-01-29 03:59:38 --> Router Class Initialized
INFO - 2026-01-29 03:59:38 --> Output Class Initialized
INFO - 2026-01-29 03:59:38 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:38 --> CSRF cookie sent
INFO - 2026-01-29 03:59:38 --> Input Class Initialized
INFO - 2026-01-29 03:59:38 --> Language Class Initialized
INFO - 2026-01-29 03:59:38 --> Loader Class Initialized
INFO - 2026-01-29 03:59:38 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:38 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:38 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:38 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:38 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:38 --> Controller Class Initialized
INFO - 2026-01-29 09:59:38 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:59:38 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:59:38 --> Pagination Class Initialized
INFO - 2026-01-29 09:59:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:59:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:38 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:38 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:38 --> Total execution time: 0.1746
INFO - 2026-01-29 03:59:41 --> Config Class Initialized
INFO - 2026-01-29 03:59:41 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:41 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:41 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:41 --> URI Class Initialized
INFO - 2026-01-29 03:59:41 --> Router Class Initialized
INFO - 2026-01-29 03:59:41 --> Output Class Initialized
INFO - 2026-01-29 03:59:41 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:41 --> CSRF cookie sent
INFO - 2026-01-29 03:59:41 --> Input Class Initialized
INFO - 2026-01-29 03:59:41 --> Language Class Initialized
INFO - 2026-01-29 03:59:41 --> Loader Class Initialized
INFO - 2026-01-29 03:59:41 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:41 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:41 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:41 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:41 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:41 --> Controller Class Initialized
INFO - 2026-01-29 09:59:41 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:59:41 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:59:41 --> Pagination Class Initialized
INFO - 2026-01-29 09:59:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:59:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:41 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:41 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:41 --> Total execution time: 0.1501
INFO - 2026-01-29 03:59:50 --> Config Class Initialized
INFO - 2026-01-29 03:59:50 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:50 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:50 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:50 --> URI Class Initialized
INFO - 2026-01-29 03:59:50 --> Router Class Initialized
INFO - 2026-01-29 03:59:50 --> Output Class Initialized
INFO - 2026-01-29 03:59:50 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:50 --> CSRF cookie sent
INFO - 2026-01-29 03:59:50 --> Input Class Initialized
INFO - 2026-01-29 03:59:50 --> Language Class Initialized
INFO - 2026-01-29 03:59:50 --> Loader Class Initialized
INFO - 2026-01-29 03:59:50 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:50 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:50 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:50 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:50 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:50 --> Controller Class Initialized
INFO - 2026-01-29 09:59:50 --> Model "Download_model" initialized
INFO - 2026-01-29 09:59:50 --> Model "Kategori_download_model" initialized
INFO - 2026-01-29 09:59:50 --> Model "Jenis_download_model" initialized
INFO - 2026-01-29 09:59:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-29 09:59:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:50 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:50 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:50 --> Total execution time: 0.1621
INFO - 2026-01-29 03:59:54 --> Config Class Initialized
INFO - 2026-01-29 03:59:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:54 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:54 --> URI Class Initialized
INFO - 2026-01-29 03:59:54 --> Router Class Initialized
INFO - 2026-01-29 03:59:54 --> Output Class Initialized
INFO - 2026-01-29 03:59:54 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:54 --> CSRF cookie sent
INFO - 2026-01-29 03:59:54 --> Input Class Initialized
INFO - 2026-01-29 03:59:54 --> Language Class Initialized
INFO - 2026-01-29 03:59:54 --> Loader Class Initialized
INFO - 2026-01-29 03:59:54 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:54 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:54 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:54 --> Controller Class Initialized
INFO - 2026-01-29 09:59:54 --> Model "Download_model" initialized
INFO - 2026-01-29 09:59:54 --> Model "Kategori_download_model" initialized
INFO - 2026-01-29 09:59:54 --> Model "Jenis_download_model" initialized
INFO - 2026-01-29 09:59:54 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"11","filename":"Sertifikat_Akreditasi_Diploma_Tiga_Keperawatan_Persahabatan_2010-2014.pdf","timestamp":"2026-01-29 09:59:54"}
INFO - 2026-01-29 04:00:33 --> Config Class Initialized
INFO - 2026-01-29 04:00:33 --> Hooks Class Initialized
DEBUG - 2026-01-29 04:00:33 --> UTF-8 Support Enabled
INFO - 2026-01-29 04:00:33 --> Utf8 Class Initialized
INFO - 2026-01-29 04:00:33 --> URI Class Initialized
INFO - 2026-01-29 04:00:33 --> Router Class Initialized
INFO - 2026-01-29 04:00:33 --> Output Class Initialized
INFO - 2026-01-29 04:00:33 --> Security Class Initialized
DEBUG - 2026-01-29 04:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 04:00:33 --> CSRF cookie sent
INFO - 2026-01-29 04:00:33 --> Input Class Initialized
INFO - 2026-01-29 04:00:33 --> Language Class Initialized
INFO - 2026-01-29 04:00:33 --> Loader Class Initialized
INFO - 2026-01-29 04:00:33 --> Helper loaded: url_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: text_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: string_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: form_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: download_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: security_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 04:00:33 --> Database Driver Class Initialized
DEBUG - 2026-01-29 04:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 04:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 04:00:33 --> Form Validation Class Initialized
INFO - 2026-01-29 04:00:33 --> Model "User_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Nav_model" initialized
INFO - 2026-01-29 10:00:33 --> Controller Class Initialized
INFO - 2026-01-29 10:00:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Prodi_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Sdm_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 10:00:34 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2026-01-29 10:00:34 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 10:00:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 10:00:34 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 10:00:34 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 10:00:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 10:00:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 10:00:34 --> Model "Log_model" initialized
INFO - 2026-01-29 10:00:34 --> Final output sent to browser
DEBUG - 2026-01-29 10:00:34 --> Total execution time: 0.2580
INFO - 2026-01-29 04:00:41 --> Config Class Initialized
INFO - 2026-01-29 04:00:41 --> Hooks Class Initialized
DEBUG - 2026-01-29 04:00:41 --> UTF-8 Support Enabled
INFO - 2026-01-29 04:00:41 --> Utf8 Class Initialized
INFO - 2026-01-29 04:00:41 --> URI Class Initialized
INFO - 2026-01-29 04:00:41 --> Router Class Initialized
INFO - 2026-01-29 04:00:41 --> Output Class Initialized
INFO - 2026-01-29 04:00:41 --> Security Class Initialized
DEBUG - 2026-01-29 04:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 04:00:41 --> CSRF cookie sent
INFO - 2026-01-29 04:00:41 --> Input Class Initialized
INFO - 2026-01-29 04:00:41 --> Language Class Initialized
INFO - 2026-01-29 04:00:41 --> Loader Class Initialized
INFO - 2026-01-29 04:00:41 --> Helper loaded: url_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: text_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: string_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: form_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: download_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: security_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 04:00:41 --> Database Driver Class Initialized
DEBUG - 2026-01-29 04:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 04:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 04:00:41 --> Form Validation Class Initialized
INFO - 2026-01-29 04:00:41 --> Model "User_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Nav_model" initialized
INFO - 2026-01-29 10:00:41 --> Controller Class Initialized
INFO - 2026-01-29 10:00:41 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Prodi_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Sdm_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 10:00:41 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2026-01-29 10:00:41 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 10:00:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 10:00:41 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 10:00:41 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 10:00:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 10:00:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 10:00:41 --> Model "Log_model" initialized
INFO - 2026-01-29 10:00:41 --> Final output sent to browser
DEBUG - 2026-01-29 10:00:41 --> Total execution time: 0.2455
INFO - 2026-01-29 07:36:53 --> Config Class Initialized
INFO - 2026-01-29 07:36:53 --> Hooks Class Initialized
DEBUG - 2026-01-29 07:36:53 --> UTF-8 Support Enabled
INFO - 2026-01-29 07:36:53 --> Utf8 Class Initialized
INFO - 2026-01-29 07:36:53 --> URI Class Initialized
INFO - 2026-01-29 07:36:53 --> Router Class Initialized
INFO - 2026-01-29 07:36:54 --> Output Class Initialized
INFO - 2026-01-29 07:36:54 --> Security Class Initialized
DEBUG - 2026-01-29 07:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 07:36:54 --> CSRF cookie sent
INFO - 2026-01-29 07:36:54 --> Input Class Initialized
INFO - 2026-01-29 07:36:54 --> Language Class Initialized
INFO - 2026-01-29 07:36:54 --> Loader Class Initialized
INFO - 2026-01-29 07:36:54 --> Helper loaded: url_helper
INFO - 2026-01-29 07:36:54 --> Helper loaded: text_helper
INFO - 2026-01-29 07:36:54 --> Helper loaded: string_helper
INFO - 2026-01-29 07:36:54 --> Helper loaded: form_helper
INFO - 2026-01-29 07:36:55 --> Helper loaded: download_helper
INFO - 2026-01-29 07:36:55 --> Helper loaded: security_helper
INFO - 2026-01-29 07:36:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 07:36:55 --> Database Driver Class Initialized
DEBUG - 2026-01-29 07:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 07:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 07:36:56 --> Form Validation Class Initialized
INFO - 2026-01-29 07:36:56 --> Model "User_model" initialized
INFO - 2026-01-29 13:36:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 13:36:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 13:36:56 --> Model "Nav_model" initialized
INFO - 2026-01-29 13:36:56 --> Controller Class Initialized
INFO - 2026-01-29 13:36:56 --> Model "Download_model" initialized
INFO - 2026-01-29 13:36:56 --> Model "Kategori_download_model" initialized
INFO - 2026-01-29 13:36:56 --> Model "Jenis_download_model" initialized
INFO - 2026-01-29 13:36:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-29 13:36:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 13:36:57 --> Model "Log_model" initialized
INFO - 2026-01-29 13:36:57 --> Final output sent to browser
DEBUG - 2026-01-29 13:36:57 --> Total execution time: 4.7364
INFO - 2026-01-29 07:37:15 --> Config Class Initialized
INFO - 2026-01-29 07:37:15 --> Hooks Class Initialized
DEBUG - 2026-01-29 07:37:15 --> UTF-8 Support Enabled
INFO - 2026-01-29 07:37:15 --> Utf8 Class Initialized
INFO - 2026-01-29 07:37:15 --> URI Class Initialized
DEBUG - 2026-01-29 07:37:15 --> No URI present. Default controller set.
INFO - 2026-01-29 07:37:15 --> Router Class Initialized
INFO - 2026-01-29 07:37:16 --> Output Class Initialized
INFO - 2026-01-29 07:37:16 --> Security Class Initialized
DEBUG - 2026-01-29 07:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 07:37:16 --> CSRF cookie sent
INFO - 2026-01-29 07:37:16 --> Input Class Initialized
INFO - 2026-01-29 07:37:16 --> Language Class Initialized
INFO - 2026-01-29 07:37:16 --> Loader Class Initialized
INFO - 2026-01-29 07:37:16 --> Helper loaded: url_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: text_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: string_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: form_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: download_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: security_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 07:37:16 --> Database Driver Class Initialized
DEBUG - 2026-01-29 07:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 07:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 07:37:16 --> Form Validation Class Initialized
INFO - 2026-01-29 07:37:16 --> Model "User_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Nav_model" initialized
INFO - 2026-01-29 13:37:16 --> Controller Class Initialized
INFO - 2026-01-29 13:37:16 --> Model "Berita_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Galeri_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Video_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Agenda_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Tautan_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Mitra_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Prodi_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 13:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 13:37:16 --> Pagination Class Initialized
INFO - 2026-01-29 13:37:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 13:37:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 13:37:18 --> Model "Log_model" initialized
INFO - 2026-01-29 13:37:18 --> Final output sent to browser
DEBUG - 2026-01-29 13:37:18 --> Total execution time: 2.9947
INFO - 2026-01-29 07:43:09 --> Config Class Initialized
INFO - 2026-01-29 07:43:09 --> Hooks Class Initialized
DEBUG - 2026-01-29 07:43:09 --> UTF-8 Support Enabled
INFO - 2026-01-29 07:43:09 --> Utf8 Class Initialized
INFO - 2026-01-29 07:43:09 --> URI Class Initialized
INFO - 2026-01-29 07:43:09 --> Router Class Initialized
INFO - 2026-01-29 07:43:09 --> Output Class Initialized
INFO - 2026-01-29 07:43:09 --> Security Class Initialized
DEBUG - 2026-01-29 07:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 07:43:09 --> CSRF cookie sent
INFO - 2026-01-29 07:43:09 --> Input Class Initialized
INFO - 2026-01-29 07:43:09 --> Language Class Initialized
INFO - 2026-01-29 07:43:09 --> Loader Class Initialized
INFO - 2026-01-29 07:43:09 --> Helper loaded: url_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: text_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: string_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: form_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: download_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: security_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 07:43:09 --> Database Driver Class Initialized
DEBUG - 2026-01-29 07:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 07:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 07:43:09 --> Form Validation Class Initialized
INFO - 2026-01-29 07:43:09 --> Model "User_model" initialized
INFO - 2026-01-29 13:43:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 13:43:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 13:43:09 --> Model "Nav_model" initialized
INFO - 2026-01-29 13:43:09 --> Controller Class Initialized
INFO - 2026-01-29 13:43:09 --> Model "Berita_model" initialized
INFO - 2026-01-29 13:43:09 --> Model "Kategori_model" initialized
INFO - 2026-01-29 13:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 13:43:09 --> Pagination Class Initialized
INFO - 2026-01-29 13:43:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 13:43:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 13:43:09 --> Model "Log_model" initialized
INFO - 2026-01-29 13:43:09 --> Final output sent to browser
DEBUG - 2026-01-29 13:43:09 --> Total execution time: 0.4616
INFO - 2026-01-29 08:14:44 --> Config Class Initialized
INFO - 2026-01-29 08:14:44 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:14:44 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:14:44 --> Utf8 Class Initialized
INFO - 2026-01-29 08:14:44 --> URI Class Initialized
DEBUG - 2026-01-29 08:14:44 --> No URI present. Default controller set.
INFO - 2026-01-29 08:14:44 --> Router Class Initialized
INFO - 2026-01-29 08:14:44 --> Output Class Initialized
INFO - 2026-01-29 08:14:44 --> Security Class Initialized
DEBUG - 2026-01-29 08:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:14:44 --> CSRF cookie sent
INFO - 2026-01-29 08:14:44 --> Input Class Initialized
INFO - 2026-01-29 08:14:44 --> Language Class Initialized
INFO - 2026-01-29 08:14:44 --> Loader Class Initialized
INFO - 2026-01-29 08:14:44 --> Helper loaded: url_helper
INFO - 2026-01-29 08:14:44 --> Helper loaded: text_helper
INFO - 2026-01-29 08:14:44 --> Helper loaded: string_helper
INFO - 2026-01-29 08:14:44 --> Helper loaded: form_helper
INFO - 2026-01-29 08:14:44 --> Helper loaded: download_helper
INFO - 2026-01-29 08:14:44 --> Helper loaded: security_helper
INFO - 2026-01-29 08:14:44 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:14:44 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:14:44 --> Form Validation Class Initialized
INFO - 2026-01-29 08:14:44 --> Model "User_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:14:44 --> Controller Class Initialized
INFO - 2026-01-29 14:14:44 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Video_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:14:44 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:14:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:14:44 --> Pagination Class Initialized
INFO - 2026-01-29 14:14:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:14:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:14:44 --> Model "Log_model" initialized
INFO - 2026-01-29 14:14:44 --> Final output sent to browser
DEBUG - 2026-01-29 14:14:44 --> Total execution time: 0.3610
INFO - 2026-01-29 08:14:49 --> Config Class Initialized
INFO - 2026-01-29 08:14:49 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:14:49 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:14:49 --> Utf8 Class Initialized
INFO - 2026-01-29 08:14:49 --> URI Class Initialized
INFO - 2026-01-29 08:14:49 --> Router Class Initialized
INFO - 2026-01-29 08:14:49 --> Output Class Initialized
INFO - 2026-01-29 08:14:49 --> Security Class Initialized
DEBUG - 2026-01-29 08:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:14:49 --> CSRF cookie sent
INFO - 2026-01-29 08:14:49 --> Input Class Initialized
INFO - 2026-01-29 08:14:49 --> Language Class Initialized
INFO - 2026-01-29 08:14:49 --> Loader Class Initialized
INFO - 2026-01-29 08:14:49 --> Helper loaded: url_helper
INFO - 2026-01-29 08:14:49 --> Helper loaded: text_helper
INFO - 2026-01-29 08:14:49 --> Helper loaded: string_helper
INFO - 2026-01-29 08:14:49 --> Helper loaded: form_helper
INFO - 2026-01-29 08:14:49 --> Helper loaded: download_helper
INFO - 2026-01-29 08:14:49 --> Helper loaded: security_helper
INFO - 2026-01-29 08:14:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:14:49 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:14:49 --> Form Validation Class Initialized
INFO - 2026-01-29 08:14:49 --> Model "User_model" initialized
INFO - 2026-01-29 14:14:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:14:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:14:49 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:14:49 --> Controller Class Initialized
DEBUG - 2026-01-29 14:14:49 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-29 14:14:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-29 14:14:49 --> Model "Log_model" initialized
INFO - 2026-01-29 14:14:49 --> Final output sent to browser
DEBUG - 2026-01-29 14:14:49 --> Total execution time: 0.2342
INFO - 2026-01-29 08:14:56 --> Config Class Initialized
INFO - 2026-01-29 08:14:56 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:14:56 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:14:56 --> Utf8 Class Initialized
INFO - 2026-01-29 08:14:56 --> URI Class Initialized
INFO - 2026-01-29 08:14:56 --> Router Class Initialized
INFO - 2026-01-29 08:14:56 --> Output Class Initialized
INFO - 2026-01-29 08:14:56 --> Security Class Initialized
DEBUG - 2026-01-29 08:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:14:56 --> CSRF cookie sent
INFO - 2026-01-29 08:14:56 --> CSRF token verified
INFO - 2026-01-29 08:14:56 --> Input Class Initialized
INFO - 2026-01-29 08:14:56 --> Language Class Initialized
INFO - 2026-01-29 08:14:56 --> Loader Class Initialized
INFO - 2026-01-29 08:14:56 --> Helper loaded: url_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: text_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: string_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: form_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: download_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: security_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:14:56 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:14:56 --> Form Validation Class Initialized
INFO - 2026-01-29 08:14:56 --> Model "User_model" initialized
INFO - 2026-01-29 14:14:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:14:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:14:56 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:14:56 --> Controller Class Initialized
DEBUG - 2026-01-29 14:14:56 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-29 14:14:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-29 08:14:56 --> Config Class Initialized
INFO - 2026-01-29 08:14:56 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:14:56 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:14:56 --> Utf8 Class Initialized
INFO - 2026-01-29 08:14:56 --> URI Class Initialized
INFO - 2026-01-29 08:14:56 --> Router Class Initialized
INFO - 2026-01-29 08:14:56 --> Output Class Initialized
INFO - 2026-01-29 08:14:56 --> Security Class Initialized
DEBUG - 2026-01-29 08:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:14:56 --> CSRF cookie sent
INFO - 2026-01-29 08:14:56 --> Input Class Initialized
INFO - 2026-01-29 08:14:56 --> Language Class Initialized
INFO - 2026-01-29 08:14:56 --> Loader Class Initialized
INFO - 2026-01-29 08:14:56 --> Helper loaded: url_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: text_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: string_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: form_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: download_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: security_helper
INFO - 2026-01-29 08:14:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:14:56 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:14:56 --> Form Validation Class Initialized
INFO - 2026-01-29 08:14:56 --> Model "User_model" initialized
INFO - 2026-01-29 14:14:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:14:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:14:56 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:14:56 --> Controller Class Initialized
INFO - 2026-01-29 14:14:56 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:14:56 --> Model "Staff_model" initialized
INFO - 2026-01-29 14:14:56 --> Model "Dasbor_model" initialized
INFO - 2026-01-29 14:14:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2026-01-29 14:15:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:15:00 --> Model "Log_model" initialized
INFO - 2026-01-29 14:15:00 --> Final output sent to browser
DEBUG - 2026-01-29 14:15:00 --> Total execution time: 3.2618
INFO - 2026-01-29 08:15:04 --> Config Class Initialized
INFO - 2026-01-29 08:15:04 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:15:04 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:15:04 --> Utf8 Class Initialized
INFO - 2026-01-29 08:15:04 --> URI Class Initialized
INFO - 2026-01-29 08:15:04 --> Router Class Initialized
INFO - 2026-01-29 08:15:04 --> Output Class Initialized
INFO - 2026-01-29 08:15:04 --> Security Class Initialized
DEBUG - 2026-01-29 08:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:15:04 --> CSRF cookie sent
INFO - 2026-01-29 08:15:04 --> Input Class Initialized
INFO - 2026-01-29 08:15:04 --> Language Class Initialized
INFO - 2026-01-29 08:15:04 --> Loader Class Initialized
INFO - 2026-01-29 08:15:04 --> Helper loaded: url_helper
INFO - 2026-01-29 08:15:04 --> Helper loaded: text_helper
INFO - 2026-01-29 08:15:04 --> Helper loaded: string_helper
INFO - 2026-01-29 08:15:04 --> Helper loaded: form_helper
INFO - 2026-01-29 08:15:04 --> Helper loaded: download_helper
INFO - 2026-01-29 08:15:04 --> Helper loaded: security_helper
INFO - 2026-01-29 08:15:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:15:04 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:15:04 --> Form Validation Class Initialized
INFO - 2026-01-29 08:15:04 --> Model "User_model" initialized
INFO - 2026-01-29 14:15:04 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:15:04 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:15:04 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:15:04 --> Controller Class Initialized
INFO - 2026-01-29 14:15:04 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:15:04 --> Model "Kategori_model" initialized
INFO - 2026-01-29 14:15:04 --> Model "Download_model" initialized
INFO - 2026-01-29 14:15:04 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:15:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/berita/list.php
INFO - 2026-01-29 14:15:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:15:04 --> Model "Log_model" initialized
INFO - 2026-01-29 14:15:04 --> Final output sent to browser
DEBUG - 2026-01-29 14:15:04 --> Total execution time: 0.2887
INFO - 2026-01-29 08:15:12 --> Config Class Initialized
INFO - 2026-01-29 08:15:12 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:15:12 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:15:12 --> Utf8 Class Initialized
INFO - 2026-01-29 08:15:12 --> URI Class Initialized
INFO - 2026-01-29 08:15:12 --> Router Class Initialized
INFO - 2026-01-29 08:15:12 --> Output Class Initialized
INFO - 2026-01-29 08:15:12 --> Security Class Initialized
DEBUG - 2026-01-29 08:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:15:12 --> CSRF cookie sent
INFO - 2026-01-29 08:15:12 --> Input Class Initialized
INFO - 2026-01-29 08:15:12 --> Language Class Initialized
INFO - 2026-01-29 08:15:12 --> Loader Class Initialized
INFO - 2026-01-29 08:15:12 --> Helper loaded: url_helper
INFO - 2026-01-29 08:15:12 --> Helper loaded: text_helper
INFO - 2026-01-29 08:15:12 --> Helper loaded: string_helper
INFO - 2026-01-29 08:15:12 --> Helper loaded: form_helper
INFO - 2026-01-29 08:15:12 --> Helper loaded: download_helper
INFO - 2026-01-29 08:15:12 --> Helper loaded: security_helper
INFO - 2026-01-29 08:15:12 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:15:12 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:15:12 --> Form Validation Class Initialized
INFO - 2026-01-29 08:15:12 --> Model "User_model" initialized
INFO - 2026-01-29 14:15:12 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:15:12 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:15:12 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:15:12 --> Controller Class Initialized
INFO - 2026-01-29 14:15:12 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:15:12 --> Model "Kategori_model" initialized
INFO - 2026-01-29 14:15:12 --> Model "Download_model" initialized
INFO - 2026-01-29 14:15:12 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:15:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/berita/tambah.php
INFO - 2026-01-29 14:15:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:15:12 --> Model "Log_model" initialized
INFO - 2026-01-29 14:15:12 --> Final output sent to browser
DEBUG - 2026-01-29 14:15:12 --> Total execution time: 0.2885
INFO - 2026-01-29 08:15:15 --> Config Class Initialized
INFO - 2026-01-29 08:15:15 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:15:15 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:15:15 --> Utf8 Class Initialized
INFO - 2026-01-29 08:15:15 --> URI Class Initialized
INFO - 2026-01-29 08:15:15 --> Router Class Initialized
INFO - 2026-01-29 08:15:15 --> Output Class Initialized
INFO - 2026-01-29 08:15:15 --> Security Class Initialized
DEBUG - 2026-01-29 08:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:15:15 --> CSRF cookie sent
INFO - 2026-01-29 08:15:15 --> Input Class Initialized
INFO - 2026-01-29 08:15:15 --> Language Class Initialized
INFO - 2026-01-29 08:15:15 --> Loader Class Initialized
INFO - 2026-01-29 08:15:15 --> Helper loaded: url_helper
INFO - 2026-01-29 08:15:15 --> Helper loaded: text_helper
INFO - 2026-01-29 08:15:15 --> Helper loaded: string_helper
INFO - 2026-01-29 08:15:15 --> Helper loaded: form_helper
INFO - 2026-01-29 08:15:15 --> Helper loaded: download_helper
INFO - 2026-01-29 08:15:15 --> Helper loaded: security_helper
INFO - 2026-01-29 08:15:15 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:15:15 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:15:15 --> Form Validation Class Initialized
INFO - 2026-01-29 08:15:15 --> Model "User_model" initialized
INFO - 2026-01-29 14:15:15 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:15:15 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:15:15 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:15:15 --> Controller Class Initialized
INFO - 2026-01-29 14:15:15 --> Model "Kategori_model" initialized
INFO - 2026-01-29 14:15:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/kategori/list.php
INFO - 2026-01-29 14:15:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:15:15 --> Model "Log_model" initialized
INFO - 2026-01-29 14:15:15 --> Final output sent to browser
DEBUG - 2026-01-29 14:15:15 --> Total execution time: 0.2931
INFO - 2026-01-29 08:16:06 --> Config Class Initialized
INFO - 2026-01-29 08:16:06 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:06 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:06 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:06 --> URI Class Initialized
INFO - 2026-01-29 08:16:06 --> Router Class Initialized
INFO - 2026-01-29 08:16:06 --> Output Class Initialized
INFO - 2026-01-29 08:16:06 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:06 --> CSRF cookie sent
INFO - 2026-01-29 08:16:06 --> Input Class Initialized
INFO - 2026-01-29 08:16:06 --> Language Class Initialized
INFO - 2026-01-29 08:16:06 --> Loader Class Initialized
INFO - 2026-01-29 08:16:06 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:06 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:06 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:06 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:06 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:06 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:06 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:06 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:06 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:06 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:06 --> Controller Class Initialized
INFO - 2026-01-29 14:16:06 --> Model "Helpdesk_model" initialized
INFO - 2026-01-29 14:16:06 --> Model "Kategori_helpdesk_model" initialized
INFO - 2026-01-29 14:16:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/helpdesk/list.php
INFO - 2026-01-29 14:16:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:16:06 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:06 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:06 --> Total execution time: 0.3273
INFO - 2026-01-29 08:16:13 --> Config Class Initialized
INFO - 2026-01-29 08:16:13 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:13 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:13 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:13 --> URI Class Initialized
INFO - 2026-01-29 08:16:13 --> Router Class Initialized
INFO - 2026-01-29 08:16:13 --> Output Class Initialized
INFO - 2026-01-29 08:16:13 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:13 --> CSRF cookie sent
INFO - 2026-01-29 08:16:13 --> Input Class Initialized
INFO - 2026-01-29 08:16:13 --> Language Class Initialized
INFO - 2026-01-29 08:16:13 --> Loader Class Initialized
INFO - 2026-01-29 08:16:13 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:13 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:13 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:13 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:13 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:13 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:13 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:13 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:13 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:13 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:13 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:13 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:13 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:13 --> Controller Class Initialized
INFO - 2026-01-29 14:16:13 --> Model "Helpdesk_model" initialized
INFO - 2026-01-29 14:16:13 --> Model "Kategori_helpdesk_model" initialized
INFO - 2026-01-29 14:16:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/helpdesk/tambah.php
INFO - 2026-01-29 14:16:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:16:13 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:13 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:13 --> Total execution time: 0.1697
INFO - 2026-01-29 08:16:18 --> Config Class Initialized
INFO - 2026-01-29 08:16:18 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:18 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:18 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:18 --> URI Class Initialized
INFO - 2026-01-29 08:16:18 --> Router Class Initialized
INFO - 2026-01-29 08:16:18 --> Output Class Initialized
INFO - 2026-01-29 08:16:18 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:18 --> CSRF cookie sent
INFO - 2026-01-29 08:16:18 --> Input Class Initialized
INFO - 2026-01-29 08:16:18 --> Language Class Initialized
INFO - 2026-01-29 08:16:18 --> Loader Class Initialized
INFO - 2026-01-29 08:16:18 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:18 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:18 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:18 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:18 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:18 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:18 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:18 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:18 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:18 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:18 --> Controller Class Initialized
INFO - 2026-01-29 14:16:18 --> Model "Sdm_model" initialized
INFO - 2026-01-29 14:16:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2026-01-29 14:16:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:16:18 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:18 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:18 --> Total execution time: 0.3913
INFO - 2026-01-29 08:16:23 --> Config Class Initialized
INFO - 2026-01-29 08:16:23 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:23 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:23 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:23 --> URI Class Initialized
INFO - 2026-01-29 08:16:23 --> Router Class Initialized
INFO - 2026-01-29 08:16:23 --> Output Class Initialized
INFO - 2026-01-29 08:16:23 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:23 --> CSRF cookie sent
INFO - 2026-01-29 08:16:23 --> Input Class Initialized
INFO - 2026-01-29 08:16:23 --> Language Class Initialized
INFO - 2026-01-29 08:16:23 --> Loader Class Initialized
INFO - 2026-01-29 08:16:23 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:23 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:23 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:23 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:23 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:23 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:23 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:23 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:23 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:23 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:23 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:23 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:23 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:23 --> Controller Class Initialized
INFO - 2026-01-29 08:16:27 --> Config Class Initialized
INFO - 2026-01-29 08:16:27 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:27 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:27 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:27 --> URI Class Initialized
INFO - 2026-01-29 08:16:27 --> Router Class Initialized
INFO - 2026-01-29 08:16:27 --> Output Class Initialized
INFO - 2026-01-29 08:16:27 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:27 --> CSRF cookie sent
INFO - 2026-01-29 08:16:27 --> Input Class Initialized
INFO - 2026-01-29 08:16:27 --> Language Class Initialized
INFO - 2026-01-29 08:16:27 --> Loader Class Initialized
INFO - 2026-01-29 08:16:27 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:27 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:27 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:27 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:27 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:27 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:27 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:27 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:34 --> Config Class Initialized
INFO - 2026-01-29 08:16:34 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:34 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:34 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:34 --> URI Class Initialized
INFO - 2026-01-29 08:16:34 --> Router Class Initialized
INFO - 2026-01-29 08:16:34 --> Output Class Initialized
INFO - 2026-01-29 08:16:34 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:34 --> CSRF cookie sent
INFO - 2026-01-29 08:16:34 --> Input Class Initialized
INFO - 2026-01-29 08:16:34 --> Language Class Initialized
INFO - 2026-01-29 08:16:34 --> Loader Class Initialized
INFO - 2026-01-29 08:16:34 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:34 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:34 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:34 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:34 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:34 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:34 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:36 --> Config Class Initialized
INFO - 2026-01-29 08:16:36 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:36 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:36 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:36 --> URI Class Initialized
INFO - 2026-01-29 08:16:36 --> Router Class Initialized
INFO - 2026-01-29 08:16:36 --> Output Class Initialized
INFO - 2026-01-29 08:16:36 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:36 --> CSRF cookie sent
INFO - 2026-01-29 08:16:36 --> Input Class Initialized
INFO - 2026-01-29 08:16:36 --> Language Class Initialized
INFO - 2026-01-29 08:16:36 --> Loader Class Initialized
INFO - 2026-01-29 08:16:36 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:36 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:36 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:36 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:36 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:36 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:36 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:36 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:41 --> Config Class Initialized
INFO - 2026-01-29 08:16:41 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:41 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:41 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:41 --> URI Class Initialized
INFO - 2026-01-29 08:16:41 --> Router Class Initialized
INFO - 2026-01-29 08:16:41 --> Output Class Initialized
INFO - 2026-01-29 08:16:41 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:41 --> CSRF cookie sent
INFO - 2026-01-29 08:16:41 --> Input Class Initialized
INFO - 2026-01-29 08:16:41 --> Language Class Initialized
INFO - 2026-01-29 08:16:41 --> Loader Class Initialized
INFO - 2026-01-29 08:16:41 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:41 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:41 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:41 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:41 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:41 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:41 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2026-01-29 14:16:45 --> SEAFILE API [GET http://192.168.11.105/api2//repos/] => HTTP 0
ERROR - 2026-01-29 14:16:45 --> RESPONSE: 
ERROR - 2026-01-29 14:16:45 --> SEAFILE LIST LIBRARIES RESPONSE: Array
(
    [error] => Failed to connect to 192.168.11.105 port 80: Timed out
)

INFO - 2026-01-29 14:16:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/seafile/list.php
INFO - 2026-01-29 14:16:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:16:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:45 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:45 --> Total execution time: 21.7936
INFO - 2026-01-29 08:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:45 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:45 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:45 --> Controller Class Initialized
INFO - 2026-01-29 14:16:45 --> Model "Helpdesk_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Kategori_helpdesk_model" initialized
INFO - 2026-01-29 14:16:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/helpdesk/tambah.php
INFO - 2026-01-29 14:16:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:16:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:45 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:45 --> Total execution time: 18.1023
INFO - 2026-01-29 08:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:45 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:45 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:45 --> Controller Class Initialized
INFO - 2026-01-29 14:16:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/activity.php
INFO - 2026-01-29 14:16:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:16:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:45 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:45 --> Total execution time: 10.7374
INFO - 2026-01-29 08:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:45 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:45 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:45 --> Controller Class Initialized
INFO - 2026-01-29 14:16:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/activity.php
INFO - 2026-01-29 14:16:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:16:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:45 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:45 --> Total execution time: 9.1676
INFO - 2026-01-29 08:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:45 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:45 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:45 --> Controller Class Initialized
INFO - 2026-01-29 14:16:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/activity.php
INFO - 2026-01-29 14:16:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:16:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:45 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:45 --> Total execution time: 3.8264
INFO - 2026-01-29 08:16:45 --> Config Class Initialized
INFO - 2026-01-29 08:16:45 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:45 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:45 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:45 --> URI Class Initialized
INFO - 2026-01-29 08:16:45 --> Router Class Initialized
INFO - 2026-01-29 08:16:45 --> Output Class Initialized
INFO - 2026-01-29 08:16:45 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:45 --> CSRF cookie sent
INFO - 2026-01-29 08:16:45 --> CSRF token verified
INFO - 2026-01-29 08:16:45 --> Input Class Initialized
INFO - 2026-01-29 08:16:45 --> Language Class Initialized
INFO - 2026-01-29 08:16:45 --> Loader Class Initialized
INFO - 2026-01-29 08:16:45 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:45 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:45 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:45 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:45 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:45 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:45 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:45 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:45 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:45 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:45 --> Controller Class Initialized
INFO - 2026-01-29 14:16:45 --> Model "Log_model" initialized
DEBUG - 2026-01-29 14:16:45 --> CSRF Token dari request POST: TIDAK ADA
DEBUG - 2026-01-29 14:16:45 --> CSRF Token yang valid: 4b1e58c0b671ee1a27bba1a6063e7793
DEBUG - 2026-01-29 14:16:45 --> Session CSRF Token: 
ERROR - 2026-01-29 14:16:45 --> CSRF Token kosong, periksa apakah dikirim dari frontend.
INFO - 2026-01-29 08:16:49 --> Config Class Initialized
INFO - 2026-01-29 08:16:49 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:49 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:49 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:49 --> URI Class Initialized
INFO - 2026-01-29 08:16:49 --> Router Class Initialized
INFO - 2026-01-29 08:16:49 --> Output Class Initialized
INFO - 2026-01-29 08:16:49 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:49 --> CSRF cookie sent
INFO - 2026-01-29 08:16:49 --> Input Class Initialized
INFO - 2026-01-29 08:16:49 --> Language Class Initialized
INFO - 2026-01-29 08:16:49 --> Loader Class Initialized
INFO - 2026-01-29 08:16:49 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:49 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:49 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:49 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:49 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:49 --> Controller Class Initialized
INFO - 2026-01-29 14:16:49 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:16:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:16:49 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:49 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:49 --> Total execution time: 0.1805
INFO - 2026-01-29 08:16:49 --> Config Class Initialized
INFO - 2026-01-29 08:16:49 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:49 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:49 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:49 --> URI Class Initialized
INFO - 2026-01-29 08:16:49 --> Router Class Initialized
INFO - 2026-01-29 08:16:49 --> Output Class Initialized
INFO - 2026-01-29 08:16:49 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:49 --> CSRF cookie sent
INFO - 2026-01-29 08:16:49 --> CSRF token verified
INFO - 2026-01-29 08:16:49 --> Input Class Initialized
INFO - 2026-01-29 08:16:49 --> Language Class Initialized
INFO - 2026-01-29 08:16:49 --> Loader Class Initialized
INFO - 2026-01-29 08:16:49 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:49 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:49 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:49 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:49 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:49 --> Controller Class Initialized
INFO - 2026-01-29 14:16:49 --> Model "M_log" initialized
INFO - 2026-01-29 14:16:50 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:50 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:50 --> Total execution time: 0.7110
INFO - 2026-01-29 08:16:54 --> Config Class Initialized
INFO - 2026-01-29 08:16:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:54 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:54 --> URI Class Initialized
INFO - 2026-01-29 08:16:54 --> Router Class Initialized
INFO - 2026-01-29 08:16:54 --> Output Class Initialized
INFO - 2026-01-29 08:16:54 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:54 --> CSRF cookie sent
INFO - 2026-01-29 08:16:54 --> CSRF token verified
INFO - 2026-01-29 08:16:54 --> Input Class Initialized
INFO - 2026-01-29 08:16:54 --> Language Class Initialized
INFO - 2026-01-29 08:16:54 --> Loader Class Initialized
INFO - 2026-01-29 08:16:54 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:54 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:54 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:54 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:54 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:54 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:54 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:54 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:54 --> Controller Class Initialized
INFO - 2026-01-29 14:16:54 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Video_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:16:54 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:16:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-29 14:16:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:16:54 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:54 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:54 --> Total execution time: 0.1746
INFO - 2026-01-29 08:16:58 --> Config Class Initialized
INFO - 2026-01-29 08:16:58 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:58 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:58 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:58 --> URI Class Initialized
INFO - 2026-01-29 08:16:58 --> Router Class Initialized
INFO - 2026-01-29 08:16:58 --> Output Class Initialized
INFO - 2026-01-29 08:16:58 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:58 --> CSRF cookie sent
INFO - 2026-01-29 08:16:58 --> Input Class Initialized
INFO - 2026-01-29 08:16:58 --> Language Class Initialized
INFO - 2026-01-29 08:16:58 --> Loader Class Initialized
INFO - 2026-01-29 08:16:58 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:58 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:58 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:58 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:58 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:58 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:58 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:58 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:58 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:58 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:58 --> Controller Class Initialized
INFO - 2026-01-29 14:16:58 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:16:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:16:58 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:58 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:58 --> Total execution time: 0.1294
INFO - 2026-01-29 08:16:59 --> Config Class Initialized
INFO - 2026-01-29 08:16:59 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:16:59 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:16:59 --> Utf8 Class Initialized
INFO - 2026-01-29 08:16:59 --> URI Class Initialized
INFO - 2026-01-29 08:16:59 --> Router Class Initialized
INFO - 2026-01-29 08:16:59 --> Output Class Initialized
INFO - 2026-01-29 08:16:59 --> Security Class Initialized
DEBUG - 2026-01-29 08:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:16:59 --> CSRF cookie sent
INFO - 2026-01-29 08:16:59 --> CSRF token verified
INFO - 2026-01-29 08:16:59 --> Input Class Initialized
INFO - 2026-01-29 08:16:59 --> Language Class Initialized
INFO - 2026-01-29 08:16:59 --> Loader Class Initialized
INFO - 2026-01-29 08:16:59 --> Helper loaded: url_helper
INFO - 2026-01-29 08:16:59 --> Helper loaded: text_helper
INFO - 2026-01-29 08:16:59 --> Helper loaded: string_helper
INFO - 2026-01-29 08:16:59 --> Helper loaded: form_helper
INFO - 2026-01-29 08:16:59 --> Helper loaded: download_helper
INFO - 2026-01-29 08:16:59 --> Helper loaded: security_helper
INFO - 2026-01-29 08:16:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:16:59 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:16:59 --> Form Validation Class Initialized
INFO - 2026-01-29 08:16:59 --> Model "User_model" initialized
INFO - 2026-01-29 14:16:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:16:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:16:59 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:16:59 --> Controller Class Initialized
INFO - 2026-01-29 14:16:59 --> Model "M_log" initialized
INFO - 2026-01-29 14:16:59 --> Model "Log_model" initialized
INFO - 2026-01-29 14:16:59 --> Final output sent to browser
DEBUG - 2026-01-29 14:16:59 --> Total execution time: 0.8541
INFO - 2026-01-29 08:17:04 --> Config Class Initialized
INFO - 2026-01-29 08:17:04 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:17:04 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:17:04 --> Utf8 Class Initialized
INFO - 2026-01-29 08:17:04 --> URI Class Initialized
INFO - 2026-01-29 08:17:04 --> Router Class Initialized
INFO - 2026-01-29 08:17:04 --> Output Class Initialized
INFO - 2026-01-29 08:17:04 --> Security Class Initialized
DEBUG - 2026-01-29 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:17:04 --> CSRF cookie sent
INFO - 2026-01-29 08:17:04 --> CSRF token verified
INFO - 2026-01-29 08:17:04 --> Input Class Initialized
INFO - 2026-01-29 08:17:04 --> Language Class Initialized
INFO - 2026-01-29 08:17:04 --> Loader Class Initialized
INFO - 2026-01-29 08:17:04 --> Helper loaded: url_helper
INFO - 2026-01-29 08:17:04 --> Helper loaded: text_helper
INFO - 2026-01-29 08:17:04 --> Helper loaded: string_helper
INFO - 2026-01-29 08:17:04 --> Helper loaded: form_helper
INFO - 2026-01-29 08:17:04 --> Helper loaded: download_helper
INFO - 2026-01-29 08:17:04 --> Helper loaded: security_helper
INFO - 2026-01-29 08:17:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:17:04 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:17:04 --> Form Validation Class Initialized
INFO - 2026-01-29 08:17:04 --> Model "User_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:17:04 --> Controller Class Initialized
INFO - 2026-01-29 14:17:04 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Video_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:17:04 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:17:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-29 14:17:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:17:04 --> Model "Log_model" initialized
INFO - 2026-01-29 14:17:04 --> Final output sent to browser
DEBUG - 2026-01-29 14:17:04 --> Total execution time: 0.2107
INFO - 2026-01-29 08:17:31 --> Config Class Initialized
INFO - 2026-01-29 08:17:31 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:17:31 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:17:31 --> Utf8 Class Initialized
INFO - 2026-01-29 08:17:31 --> URI Class Initialized
INFO - 2026-01-29 08:17:31 --> Router Class Initialized
INFO - 2026-01-29 08:17:31 --> Output Class Initialized
INFO - 2026-01-29 08:17:31 --> Security Class Initialized
DEBUG - 2026-01-29 08:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:17:31 --> CSRF cookie sent
INFO - 2026-01-29 08:17:31 --> Input Class Initialized
INFO - 2026-01-29 08:17:31 --> Language Class Initialized
INFO - 2026-01-29 08:17:31 --> Loader Class Initialized
INFO - 2026-01-29 08:17:31 --> Helper loaded: url_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: text_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: string_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: form_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: download_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: security_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:17:31 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:17:31 --> Form Validation Class Initialized
INFO - 2026-01-29 08:17:31 --> Model "User_model" initialized
INFO - 2026-01-29 14:17:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:17:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:17:31 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:17:31 --> Controller Class Initialized
INFO - 2026-01-29 14:17:31 --> Model "Log_model" initialized
INFO - 2026-01-29 14:17:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:17:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:17:31 --> Model "Log_model" initialized
INFO - 2026-01-29 14:17:31 --> Final output sent to browser
DEBUG - 2026-01-29 14:17:31 --> Total execution time: 0.1336
INFO - 2026-01-29 08:17:31 --> Config Class Initialized
INFO - 2026-01-29 08:17:31 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:17:31 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:17:31 --> Utf8 Class Initialized
INFO - 2026-01-29 08:17:31 --> URI Class Initialized
INFO - 2026-01-29 08:17:31 --> Router Class Initialized
INFO - 2026-01-29 08:17:31 --> Output Class Initialized
INFO - 2026-01-29 08:17:31 --> Security Class Initialized
DEBUG - 2026-01-29 08:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:17:31 --> CSRF cookie sent
INFO - 2026-01-29 08:17:31 --> CSRF token verified
INFO - 2026-01-29 08:17:31 --> Input Class Initialized
INFO - 2026-01-29 08:17:31 --> Language Class Initialized
INFO - 2026-01-29 08:17:31 --> Loader Class Initialized
INFO - 2026-01-29 08:17:31 --> Helper loaded: url_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: text_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: string_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: form_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: download_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: security_helper
INFO - 2026-01-29 08:17:31 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:17:31 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:17:31 --> Form Validation Class Initialized
INFO - 2026-01-29 08:17:31 --> Model "User_model" initialized
INFO - 2026-01-29 14:17:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:17:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:17:31 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:17:31 --> Controller Class Initialized
INFO - 2026-01-29 14:17:31 --> Model "M_log" initialized
INFO - 2026-01-29 14:17:32 --> Model "Log_model" initialized
INFO - 2026-01-29 14:17:32 --> Final output sent to browser
DEBUG - 2026-01-29 14:17:32 --> Total execution time: 0.5424
INFO - 2026-01-29 08:17:35 --> Config Class Initialized
INFO - 2026-01-29 08:17:35 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:17:35 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:17:35 --> Utf8 Class Initialized
INFO - 2026-01-29 08:17:35 --> URI Class Initialized
INFO - 2026-01-29 08:17:35 --> Router Class Initialized
INFO - 2026-01-29 08:17:35 --> Output Class Initialized
INFO - 2026-01-29 08:17:35 --> Security Class Initialized
DEBUG - 2026-01-29 08:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:17:35 --> CSRF cookie sent
INFO - 2026-01-29 08:17:35 --> Input Class Initialized
INFO - 2026-01-29 08:17:35 --> Language Class Initialized
INFO - 2026-01-29 08:17:35 --> Loader Class Initialized
INFO - 2026-01-29 08:17:35 --> Helper loaded: url_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: text_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: string_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: form_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: download_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: security_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:17:35 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:17:35 --> Form Validation Class Initialized
INFO - 2026-01-29 08:17:35 --> Model "User_model" initialized
INFO - 2026-01-29 14:17:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:17:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:17:35 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:17:35 --> Controller Class Initialized
INFO - 2026-01-29 14:17:35 --> Model "Log_model" initialized
INFO - 2026-01-29 14:17:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/activity.php
INFO - 2026-01-29 14:17:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:17:35 --> Model "Log_model" initialized
INFO - 2026-01-29 14:17:35 --> Final output sent to browser
DEBUG - 2026-01-29 14:17:35 --> Total execution time: 0.1328
INFO - 2026-01-29 08:17:35 --> Config Class Initialized
INFO - 2026-01-29 08:17:35 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:17:35 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:17:35 --> Utf8 Class Initialized
INFO - 2026-01-29 08:17:35 --> URI Class Initialized
INFO - 2026-01-29 08:17:35 --> Router Class Initialized
INFO - 2026-01-29 08:17:35 --> Output Class Initialized
INFO - 2026-01-29 08:17:35 --> Security Class Initialized
DEBUG - 2026-01-29 08:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:17:35 --> CSRF cookie sent
INFO - 2026-01-29 08:17:35 --> CSRF token verified
INFO - 2026-01-29 08:17:35 --> Input Class Initialized
INFO - 2026-01-29 08:17:35 --> Language Class Initialized
INFO - 2026-01-29 08:17:35 --> Loader Class Initialized
INFO - 2026-01-29 08:17:35 --> Helper loaded: url_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: text_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: string_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: form_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: download_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: security_helper
INFO - 2026-01-29 08:17:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:17:35 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:17:35 --> Form Validation Class Initialized
INFO - 2026-01-29 08:17:35 --> Model "User_model" initialized
INFO - 2026-01-29 14:17:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:17:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:17:35 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:17:35 --> Controller Class Initialized
INFO - 2026-01-29 14:17:35 --> Model "Log_model" initialized
DEBUG - 2026-01-29 14:17:35 --> CSRF Token dari request POST: TIDAK ADA
DEBUG - 2026-01-29 14:17:35 --> CSRF Token yang valid: 4b1e58c0b671ee1a27bba1a6063e7793
DEBUG - 2026-01-29 14:17:35 --> Session CSRF Token: 
ERROR - 2026-01-29 14:17:35 --> CSRF Token kosong, periksa apakah dikirim dari frontend.
INFO - 2026-01-29 08:17:55 --> Config Class Initialized
INFO - 2026-01-29 08:17:55 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:17:55 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:17:55 --> Utf8 Class Initialized
INFO - 2026-01-29 08:17:55 --> URI Class Initialized
INFO - 2026-01-29 08:17:55 --> Router Class Initialized
INFO - 2026-01-29 08:17:55 --> Output Class Initialized
INFO - 2026-01-29 08:17:55 --> Security Class Initialized
DEBUG - 2026-01-29 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:17:55 --> CSRF cookie sent
INFO - 2026-01-29 08:17:55 --> Input Class Initialized
INFO - 2026-01-29 08:17:55 --> Language Class Initialized
INFO - 2026-01-29 08:17:55 --> Loader Class Initialized
INFO - 2026-01-29 08:17:55 --> Helper loaded: url_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: text_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: string_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: form_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: download_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: security_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:17:55 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:17:55 --> Form Validation Class Initialized
INFO - 2026-01-29 08:17:55 --> Model "User_model" initialized
INFO - 2026-01-29 14:17:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:17:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:17:55 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:17:55 --> Controller Class Initialized
INFO - 2026-01-29 14:17:55 --> Model "Log_model" initialized
INFO - 2026-01-29 14:17:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:17:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:17:55 --> Model "Log_model" initialized
INFO - 2026-01-29 14:17:55 --> Final output sent to browser
DEBUG - 2026-01-29 14:17:55 --> Total execution time: 0.1349
INFO - 2026-01-29 08:17:55 --> Config Class Initialized
INFO - 2026-01-29 08:17:55 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:17:55 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:17:55 --> Utf8 Class Initialized
INFO - 2026-01-29 08:17:55 --> URI Class Initialized
INFO - 2026-01-29 08:17:55 --> Router Class Initialized
INFO - 2026-01-29 08:17:55 --> Output Class Initialized
INFO - 2026-01-29 08:17:55 --> Security Class Initialized
DEBUG - 2026-01-29 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:17:55 --> CSRF cookie sent
INFO - 2026-01-29 08:17:55 --> CSRF token verified
INFO - 2026-01-29 08:17:55 --> Input Class Initialized
INFO - 2026-01-29 08:17:55 --> Language Class Initialized
INFO - 2026-01-29 08:17:55 --> Loader Class Initialized
INFO - 2026-01-29 08:17:55 --> Helper loaded: url_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: text_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: string_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: form_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: download_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: security_helper
INFO - 2026-01-29 08:17:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:17:55 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:17:55 --> Form Validation Class Initialized
INFO - 2026-01-29 08:17:55 --> Model "User_model" initialized
INFO - 2026-01-29 14:17:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:17:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:17:55 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:17:55 --> Controller Class Initialized
INFO - 2026-01-29 14:17:55 --> Model "M_log" initialized
INFO - 2026-01-29 14:17:55 --> Model "Log_model" initialized
INFO - 2026-01-29 14:17:55 --> Final output sent to browser
DEBUG - 2026-01-29 14:17:55 --> Total execution time: 0.3695
INFO - 2026-01-29 08:18:04 --> Config Class Initialized
INFO - 2026-01-29 08:18:04 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:18:04 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:18:04 --> Utf8 Class Initialized
INFO - 2026-01-29 08:18:04 --> URI Class Initialized
INFO - 2026-01-29 08:18:04 --> Router Class Initialized
INFO - 2026-01-29 08:18:04 --> Output Class Initialized
INFO - 2026-01-29 08:18:04 --> Security Class Initialized
DEBUG - 2026-01-29 08:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:18:04 --> CSRF cookie sent
INFO - 2026-01-29 08:18:04 --> CSRF token verified
INFO - 2026-01-29 08:18:04 --> Input Class Initialized
INFO - 2026-01-29 08:18:04 --> Language Class Initialized
INFO - 2026-01-29 08:18:04 --> Loader Class Initialized
INFO - 2026-01-29 08:18:04 --> Helper loaded: url_helper
INFO - 2026-01-29 08:18:04 --> Helper loaded: text_helper
INFO - 2026-01-29 08:18:04 --> Helper loaded: string_helper
INFO - 2026-01-29 08:18:04 --> Helper loaded: form_helper
INFO - 2026-01-29 08:18:04 --> Helper loaded: download_helper
INFO - 2026-01-29 08:18:04 --> Helper loaded: security_helper
INFO - 2026-01-29 08:18:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:18:04 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:18:04 --> Form Validation Class Initialized
INFO - 2026-01-29 08:18:04 --> Model "User_model" initialized
INFO - 2026-01-29 14:18:04 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:18:04 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:18:04 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:18:04 --> Controller Class Initialized
INFO - 2026-01-29 14:18:05 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:18:05 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:18:05 --> Model "Video_model" initialized
INFO - 2026-01-29 14:18:05 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:18:05 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:18:05 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:18:05 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:18:05 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:18:05 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:18:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-29 14:18:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:18:05 --> Model "Log_model" initialized
INFO - 2026-01-29 14:18:05 --> Final output sent to browser
DEBUG - 2026-01-29 14:18:05 --> Total execution time: 0.1805
INFO - 2026-01-29 08:18:16 --> Config Class Initialized
INFO - 2026-01-29 08:18:16 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:18:16 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:18:16 --> Utf8 Class Initialized
INFO - 2026-01-29 08:18:16 --> URI Class Initialized
INFO - 2026-01-29 08:18:16 --> Router Class Initialized
INFO - 2026-01-29 08:18:16 --> Output Class Initialized
INFO - 2026-01-29 08:18:16 --> Security Class Initialized
DEBUG - 2026-01-29 08:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:18:16 --> CSRF cookie sent
INFO - 2026-01-29 08:18:16 --> Input Class Initialized
INFO - 2026-01-29 08:18:16 --> Language Class Initialized
INFO - 2026-01-29 08:18:16 --> Loader Class Initialized
INFO - 2026-01-29 08:18:16 --> Helper loaded: url_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: text_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: string_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: form_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: download_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: security_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:18:16 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:18:16 --> Form Validation Class Initialized
INFO - 2026-01-29 08:18:16 --> Model "User_model" initialized
INFO - 2026-01-29 14:18:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:18:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:18:16 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:18:16 --> Controller Class Initialized
INFO - 2026-01-29 14:18:16 --> Model "Log_model" initialized
INFO - 2026-01-29 14:18:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:18:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:18:16 --> Model "Log_model" initialized
INFO - 2026-01-29 14:18:16 --> Final output sent to browser
DEBUG - 2026-01-29 14:18:16 --> Total execution time: 0.1513
INFO - 2026-01-29 08:18:16 --> Config Class Initialized
INFO - 2026-01-29 08:18:16 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:18:16 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:18:16 --> Utf8 Class Initialized
INFO - 2026-01-29 08:18:16 --> URI Class Initialized
INFO - 2026-01-29 08:18:16 --> Router Class Initialized
INFO - 2026-01-29 08:18:16 --> Output Class Initialized
INFO - 2026-01-29 08:18:16 --> Security Class Initialized
DEBUG - 2026-01-29 08:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:18:16 --> CSRF cookie sent
INFO - 2026-01-29 08:18:16 --> CSRF token verified
INFO - 2026-01-29 08:18:16 --> Input Class Initialized
INFO - 2026-01-29 08:18:16 --> Language Class Initialized
INFO - 2026-01-29 08:18:16 --> Loader Class Initialized
INFO - 2026-01-29 08:18:16 --> Helper loaded: url_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: text_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: string_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: form_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: download_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: security_helper
INFO - 2026-01-29 08:18:16 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:18:16 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:18:16 --> Form Validation Class Initialized
INFO - 2026-01-29 08:18:16 --> Model "User_model" initialized
INFO - 2026-01-29 14:18:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:18:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:18:16 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:18:16 --> Controller Class Initialized
INFO - 2026-01-29 14:18:16 --> Model "M_log" initialized
INFO - 2026-01-29 14:18:17 --> Model "Log_model" initialized
INFO - 2026-01-29 14:18:17 --> Final output sent to browser
DEBUG - 2026-01-29 14:18:17 --> Total execution time: 0.5968
INFO - 2026-01-29 08:18:21 --> Config Class Initialized
INFO - 2026-01-29 08:18:21 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:18:21 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:18:21 --> Utf8 Class Initialized
INFO - 2026-01-29 08:18:21 --> URI Class Initialized
INFO - 2026-01-29 08:18:21 --> Router Class Initialized
INFO - 2026-01-29 08:18:21 --> Output Class Initialized
INFO - 2026-01-29 08:18:21 --> Security Class Initialized
DEBUG - 2026-01-29 08:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:18:21 --> CSRF cookie sent
INFO - 2026-01-29 08:18:21 --> CSRF token verified
INFO - 2026-01-29 08:18:21 --> Input Class Initialized
INFO - 2026-01-29 08:18:21 --> Language Class Initialized
INFO - 2026-01-29 08:18:21 --> Loader Class Initialized
INFO - 2026-01-29 08:18:21 --> Helper loaded: url_helper
INFO - 2026-01-29 08:18:21 --> Helper loaded: text_helper
INFO - 2026-01-29 08:18:21 --> Helper loaded: string_helper
INFO - 2026-01-29 08:18:21 --> Helper loaded: form_helper
INFO - 2026-01-29 08:18:21 --> Helper loaded: download_helper
INFO - 2026-01-29 08:18:21 --> Helper loaded: security_helper
INFO - 2026-01-29 08:18:21 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:18:21 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:18:21 --> Form Validation Class Initialized
INFO - 2026-01-29 08:18:21 --> Model "User_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:18:21 --> Controller Class Initialized
INFO - 2026-01-29 14:18:21 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Video_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:18:21 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:18:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-29 14:18:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:18:21 --> Model "Log_model" initialized
INFO - 2026-01-29 14:18:21 --> Final output sent to browser
DEBUG - 2026-01-29 14:18:21 --> Total execution time: 0.1711
INFO - 2026-01-29 08:18:45 --> Config Class Initialized
INFO - 2026-01-29 08:18:45 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:18:45 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:18:45 --> Utf8 Class Initialized
INFO - 2026-01-29 08:18:45 --> URI Class Initialized
INFO - 2026-01-29 08:18:45 --> Router Class Initialized
INFO - 2026-01-29 08:18:45 --> Output Class Initialized
INFO - 2026-01-29 08:18:45 --> Security Class Initialized
DEBUG - 2026-01-29 08:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:18:45 --> CSRF cookie sent
INFO - 2026-01-29 08:18:45 --> Input Class Initialized
INFO - 2026-01-29 08:18:45 --> Language Class Initialized
INFO - 2026-01-29 08:18:45 --> Loader Class Initialized
INFO - 2026-01-29 08:18:45 --> Helper loaded: url_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: text_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: string_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: form_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: download_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: security_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:18:45 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:18:45 --> Form Validation Class Initialized
INFO - 2026-01-29 08:18:45 --> Model "User_model" initialized
INFO - 2026-01-29 14:18:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:18:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:18:45 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:18:45 --> Controller Class Initialized
INFO - 2026-01-29 14:18:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:18:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:18:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:18:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:18:45 --> Final output sent to browser
DEBUG - 2026-01-29 14:18:45 --> Total execution time: 0.1368
INFO - 2026-01-29 08:18:45 --> Config Class Initialized
INFO - 2026-01-29 08:18:45 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:18:45 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:18:45 --> Utf8 Class Initialized
INFO - 2026-01-29 08:18:45 --> URI Class Initialized
INFO - 2026-01-29 08:18:45 --> Router Class Initialized
INFO - 2026-01-29 08:18:45 --> Output Class Initialized
INFO - 2026-01-29 08:18:45 --> Security Class Initialized
DEBUG - 2026-01-29 08:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:18:45 --> CSRF cookie sent
INFO - 2026-01-29 08:18:45 --> CSRF token verified
INFO - 2026-01-29 08:18:45 --> Input Class Initialized
INFO - 2026-01-29 08:18:45 --> Language Class Initialized
INFO - 2026-01-29 08:18:45 --> Loader Class Initialized
INFO - 2026-01-29 08:18:45 --> Helper loaded: url_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: text_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: string_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: form_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: download_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: security_helper
INFO - 2026-01-29 08:18:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:18:45 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:18:45 --> Form Validation Class Initialized
INFO - 2026-01-29 08:18:45 --> Model "User_model" initialized
INFO - 2026-01-29 14:18:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:18:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:18:45 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:18:45 --> Controller Class Initialized
INFO - 2026-01-29 14:18:45 --> Model "M_log" initialized
INFO - 2026-01-29 14:18:46 --> Model "Log_model" initialized
INFO - 2026-01-29 14:18:46 --> Final output sent to browser
DEBUG - 2026-01-29 14:18:46 --> Total execution time: 0.2977
INFO - 2026-01-29 08:21:47 --> Config Class Initialized
INFO - 2026-01-29 08:21:47 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:21:47 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:21:47 --> Utf8 Class Initialized
INFO - 2026-01-29 08:21:47 --> URI Class Initialized
INFO - 2026-01-29 08:21:47 --> Router Class Initialized
INFO - 2026-01-29 08:21:47 --> Output Class Initialized
INFO - 2026-01-29 08:21:47 --> Security Class Initialized
DEBUG - 2026-01-29 08:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:21:47 --> CSRF cookie sent
INFO - 2026-01-29 08:21:47 --> Input Class Initialized
INFO - 2026-01-29 08:21:47 --> Language Class Initialized
INFO - 2026-01-29 08:21:47 --> Loader Class Initialized
INFO - 2026-01-29 08:21:47 --> Helper loaded: url_helper
INFO - 2026-01-29 08:21:47 --> Helper loaded: text_helper
INFO - 2026-01-29 08:21:47 --> Helper loaded: string_helper
INFO - 2026-01-29 08:21:47 --> Helper loaded: form_helper
INFO - 2026-01-29 08:21:47 --> Helper loaded: download_helper
INFO - 2026-01-29 08:21:47 --> Helper loaded: security_helper
INFO - 2026-01-29 08:21:47 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:21:47 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:21:47 --> Form Validation Class Initialized
INFO - 2026-01-29 08:21:47 --> Model "User_model" initialized
INFO - 2026-01-29 14:21:47 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:21:47 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:21:47 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:21:47 --> Controller Class Initialized
INFO - 2026-01-29 14:21:47 --> Model "M_log" initialized
INFO - 2026-01-29 08:21:53 --> Config Class Initialized
INFO - 2026-01-29 08:21:53 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:21:53 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:21:53 --> Utf8 Class Initialized
INFO - 2026-01-29 08:21:53 --> URI Class Initialized
INFO - 2026-01-29 08:21:53 --> Router Class Initialized
INFO - 2026-01-29 08:21:53 --> Output Class Initialized
INFO - 2026-01-29 08:21:53 --> Security Class Initialized
DEBUG - 2026-01-29 08:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:21:53 --> CSRF cookie sent
INFO - 2026-01-29 08:21:53 --> Input Class Initialized
INFO - 2026-01-29 08:21:53 --> Language Class Initialized
INFO - 2026-01-29 08:21:53 --> Loader Class Initialized
INFO - 2026-01-29 08:21:53 --> Helper loaded: url_helper
INFO - 2026-01-29 08:21:53 --> Helper loaded: text_helper
INFO - 2026-01-29 08:21:53 --> Helper loaded: string_helper
INFO - 2026-01-29 08:21:53 --> Helper loaded: form_helper
INFO - 2026-01-29 08:21:53 --> Helper loaded: download_helper
INFO - 2026-01-29 08:21:53 --> Helper loaded: security_helper
INFO - 2026-01-29 08:21:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:21:53 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:21:53 --> Form Validation Class Initialized
INFO - 2026-01-29 08:21:53 --> Model "User_model" initialized
INFO - 2026-01-29 14:21:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:21:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:21:53 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:21:53 --> Controller Class Initialized
INFO - 2026-01-29 14:21:53 --> Model "Log_model" initialized
INFO - 2026-01-29 14:21:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:21:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:21:53 --> Model "Log_model" initialized
INFO - 2026-01-29 14:21:53 --> Final output sent to browser
DEBUG - 2026-01-29 14:21:53 --> Total execution time: 0.0952
INFO - 2026-01-29 08:21:54 --> Config Class Initialized
INFO - 2026-01-29 08:21:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:21:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:21:54 --> Utf8 Class Initialized
INFO - 2026-01-29 08:21:54 --> URI Class Initialized
INFO - 2026-01-29 08:21:54 --> Router Class Initialized
INFO - 2026-01-29 08:21:54 --> Output Class Initialized
INFO - 2026-01-29 08:21:54 --> Security Class Initialized
DEBUG - 2026-01-29 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:21:54 --> CSRF cookie sent
INFO - 2026-01-29 08:21:54 --> CSRF token verified
INFO - 2026-01-29 08:21:54 --> Input Class Initialized
INFO - 2026-01-29 08:21:54 --> Language Class Initialized
INFO - 2026-01-29 08:21:54 --> Loader Class Initialized
INFO - 2026-01-29 08:21:54 --> Helper loaded: url_helper
INFO - 2026-01-29 08:21:54 --> Helper loaded: text_helper
INFO - 2026-01-29 08:21:54 --> Helper loaded: string_helper
INFO - 2026-01-29 08:21:54 --> Helper loaded: form_helper
INFO - 2026-01-29 08:21:54 --> Helper loaded: download_helper
INFO - 2026-01-29 08:21:54 --> Helper loaded: security_helper
INFO - 2026-01-29 08:21:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:21:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:21:54 --> Form Validation Class Initialized
INFO - 2026-01-29 08:21:54 --> Model "User_model" initialized
INFO - 2026-01-29 14:21:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:21:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:21:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:21:54 --> Controller Class Initialized
INFO - 2026-01-29 14:21:54 --> Model "M_log" initialized
INFO - 2026-01-29 14:21:54 --> Model "Log_model" initialized
INFO - 2026-01-29 14:21:54 --> Final output sent to browser
DEBUG - 2026-01-29 14:21:54 --> Total execution time: 0.3004
INFO - 2026-01-29 08:23:12 --> Config Class Initialized
INFO - 2026-01-29 08:23:12 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:12 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:12 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:12 --> URI Class Initialized
INFO - 2026-01-29 08:23:12 --> Router Class Initialized
INFO - 2026-01-29 08:23:12 --> Output Class Initialized
INFO - 2026-01-29 08:23:12 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:12 --> CSRF cookie sent
INFO - 2026-01-29 08:23:12 --> Input Class Initialized
INFO - 2026-01-29 08:23:12 --> Language Class Initialized
INFO - 2026-01-29 08:23:12 --> Loader Class Initialized
INFO - 2026-01-29 08:23:12 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:12 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:12 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:12 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:12 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:12 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:12 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:12 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:12 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:12 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:12 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:12 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:12 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:12 --> Controller Class Initialized
INFO - 2026-01-29 14:23:12 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:23:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:23:12 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:12 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:12 --> Total execution time: 0.1974
INFO - 2026-01-29 08:23:13 --> Config Class Initialized
INFO - 2026-01-29 08:23:13 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:13 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:13 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:13 --> URI Class Initialized
INFO - 2026-01-29 08:23:13 --> Router Class Initialized
INFO - 2026-01-29 08:23:13 --> Output Class Initialized
INFO - 2026-01-29 08:23:13 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:13 --> CSRF cookie sent
INFO - 2026-01-29 08:23:13 --> CSRF token verified
INFO - 2026-01-29 08:23:13 --> Input Class Initialized
INFO - 2026-01-29 08:23:13 --> Language Class Initialized
INFO - 2026-01-29 08:23:13 --> Loader Class Initialized
INFO - 2026-01-29 08:23:13 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:13 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:13 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:13 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:13 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:13 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:13 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:13 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:13 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:13 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:13 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:13 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:13 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:13 --> Controller Class Initialized
INFO - 2026-01-29 14:23:13 --> Model "M_log" initialized
INFO - 2026-01-29 14:23:13 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:13 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:13 --> Total execution time: 0.2819
INFO - 2026-01-29 08:23:42 --> Config Class Initialized
INFO - 2026-01-29 08:23:42 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:42 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:42 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:42 --> URI Class Initialized
INFO - 2026-01-29 08:23:42 --> Router Class Initialized
INFO - 2026-01-29 08:23:42 --> Output Class Initialized
INFO - 2026-01-29 08:23:42 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:42 --> CSRF cookie sent
INFO - 2026-01-29 08:23:42 --> Input Class Initialized
INFO - 2026-01-29 08:23:42 --> Language Class Initialized
INFO - 2026-01-29 08:23:42 --> Loader Class Initialized
INFO - 2026-01-29 08:23:42 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:42 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:42 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:42 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:42 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:42 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:42 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:42 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:42 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:42 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:42 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:42 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:42 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:42 --> Controller Class Initialized
INFO - 2026-01-29 14:23:42 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:23:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:23:42 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:42 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:42 --> Total execution time: 0.1507
INFO - 2026-01-29 08:23:43 --> Config Class Initialized
INFO - 2026-01-29 08:23:43 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:43 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:43 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:43 --> URI Class Initialized
INFO - 2026-01-29 08:23:43 --> Router Class Initialized
INFO - 2026-01-29 08:23:43 --> Output Class Initialized
INFO - 2026-01-29 08:23:43 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:43 --> CSRF cookie sent
INFO - 2026-01-29 08:23:43 --> CSRF token verified
INFO - 2026-01-29 08:23:43 --> Input Class Initialized
INFO - 2026-01-29 08:23:43 --> Language Class Initialized
INFO - 2026-01-29 08:23:43 --> Loader Class Initialized
INFO - 2026-01-29 08:23:43 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:43 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:43 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:43 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:43 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:43 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:43 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:43 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:43 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:43 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:43 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:43 --> Controller Class Initialized
INFO - 2026-01-29 14:23:43 --> Model "M_log" initialized
INFO - 2026-01-29 14:23:43 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:43 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:43 --> Total execution time: 0.3122
INFO - 2026-01-29 08:23:46 --> Config Class Initialized
INFO - 2026-01-29 08:23:46 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:46 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:46 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:46 --> URI Class Initialized
INFO - 2026-01-29 08:23:46 --> Router Class Initialized
INFO - 2026-01-29 08:23:46 --> Output Class Initialized
INFO - 2026-01-29 08:23:46 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:46 --> CSRF cookie sent
INFO - 2026-01-29 08:23:46 --> CSRF token verified
INFO - 2026-01-29 08:23:46 --> Input Class Initialized
INFO - 2026-01-29 08:23:46 --> Language Class Initialized
INFO - 2026-01-29 08:23:46 --> Loader Class Initialized
INFO - 2026-01-29 08:23:46 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:46 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:46 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:46 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:46 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:46 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:46 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:46 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:46 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:46 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:46 --> Controller Class Initialized
INFO - 2026-01-29 14:23:46 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:46 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:46 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:46 --> Total execution time: 0.1949
INFO - 2026-01-29 08:23:47 --> Config Class Initialized
INFO - 2026-01-29 08:23:47 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:47 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:47 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:47 --> URI Class Initialized
INFO - 2026-01-29 08:23:47 --> Router Class Initialized
INFO - 2026-01-29 08:23:47 --> Output Class Initialized
INFO - 2026-01-29 08:23:47 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:47 --> CSRF cookie sent
INFO - 2026-01-29 08:23:47 --> CSRF token verified
INFO - 2026-01-29 08:23:47 --> Input Class Initialized
INFO - 2026-01-29 08:23:47 --> Language Class Initialized
INFO - 2026-01-29 08:23:47 --> Loader Class Initialized
INFO - 2026-01-29 08:23:47 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:47 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:47 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:47 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:47 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:47 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:47 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:47 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:47 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:47 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:47 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:47 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:47 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:47 --> Controller Class Initialized
INFO - 2026-01-29 14:23:47 --> Model "M_log" initialized
INFO - 2026-01-29 14:23:47 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:47 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:47 --> Total execution time: 0.0850
INFO - 2026-01-29 08:23:51 --> Config Class Initialized
INFO - 2026-01-29 08:23:51 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:51 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:51 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:51 --> URI Class Initialized
INFO - 2026-01-29 08:23:51 --> Router Class Initialized
INFO - 2026-01-29 08:23:51 --> Output Class Initialized
INFO - 2026-01-29 08:23:51 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:51 --> CSRF cookie sent
INFO - 2026-01-29 08:23:51 --> Input Class Initialized
INFO - 2026-01-29 08:23:51 --> Language Class Initialized
INFO - 2026-01-29 08:23:51 --> Loader Class Initialized
INFO - 2026-01-29 08:23:51 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:51 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:51 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:51 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:51 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:51 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:51 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:51 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:51 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:51 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:51 --> Controller Class Initialized
INFO - 2026-01-29 14:23:51 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:23:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:23:51 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:51 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:51 --> Total execution time: 0.1310
INFO - 2026-01-29 08:23:51 --> Config Class Initialized
INFO - 2026-01-29 08:23:51 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:51 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:51 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:51 --> URI Class Initialized
INFO - 2026-01-29 08:23:51 --> Router Class Initialized
INFO - 2026-01-29 08:23:51 --> Output Class Initialized
INFO - 2026-01-29 08:23:52 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:52 --> CSRF cookie sent
INFO - 2026-01-29 08:23:52 --> CSRF token verified
INFO - 2026-01-29 08:23:52 --> Input Class Initialized
INFO - 2026-01-29 08:23:52 --> Language Class Initialized
INFO - 2026-01-29 08:23:52 --> Loader Class Initialized
INFO - 2026-01-29 08:23:52 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:52 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:52 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:52 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:52 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:52 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:52 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:52 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:52 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:52 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:52 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:52 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:52 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:52 --> Controller Class Initialized
INFO - 2026-01-29 14:23:52 --> Model "M_log" initialized
INFO - 2026-01-29 14:23:52 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:52 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:52 --> Total execution time: 0.0744
INFO - 2026-01-29 08:23:56 --> Config Class Initialized
INFO - 2026-01-29 08:23:56 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:56 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:56 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:56 --> URI Class Initialized
INFO - 2026-01-29 08:23:56 --> Router Class Initialized
INFO - 2026-01-29 08:23:56 --> Output Class Initialized
INFO - 2026-01-29 08:23:56 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:56 --> CSRF cookie sent
INFO - 2026-01-29 08:23:56 --> Input Class Initialized
INFO - 2026-01-29 08:23:56 --> Language Class Initialized
INFO - 2026-01-29 08:23:56 --> Loader Class Initialized
INFO - 2026-01-29 08:23:56 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:56 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:56 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:56 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:56 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:56 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:56 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:56 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:56 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:56 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:56 --> Controller Class Initialized
INFO - 2026-01-29 14:23:56 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/activity.php
INFO - 2026-01-29 14:23:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:23:56 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:56 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:56 --> Total execution time: 0.1432
INFO - 2026-01-29 08:23:57 --> Config Class Initialized
INFO - 2026-01-29 08:23:57 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:57 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:57 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:57 --> URI Class Initialized
INFO - 2026-01-29 08:23:57 --> Router Class Initialized
INFO - 2026-01-29 08:23:57 --> Output Class Initialized
INFO - 2026-01-29 08:23:57 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:57 --> CSRF cookie sent
INFO - 2026-01-29 08:23:57 --> CSRF token verified
INFO - 2026-01-29 08:23:57 --> Input Class Initialized
INFO - 2026-01-29 08:23:57 --> Language Class Initialized
INFO - 2026-01-29 08:23:57 --> Loader Class Initialized
INFO - 2026-01-29 08:23:57 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:57 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:57 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:57 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:57 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:57 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:57 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:57 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:57 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:57 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:57 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:57 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:57 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:57 --> Controller Class Initialized
INFO - 2026-01-29 14:23:57 --> Model "Log_model" initialized
DEBUG - 2026-01-29 14:23:57 --> CSRF Token dari request POST: TIDAK ADA
DEBUG - 2026-01-29 14:23:57 --> CSRF Token yang valid: 4b1e58c0b671ee1a27bba1a6063e7793
DEBUG - 2026-01-29 14:23:57 --> Session CSRF Token: 
ERROR - 2026-01-29 14:23:57 --> CSRF Token kosong, periksa apakah dikirim dari frontend.
INFO - 2026-01-29 08:23:59 --> Config Class Initialized
INFO - 2026-01-29 08:23:59 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:59 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:59 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:59 --> URI Class Initialized
INFO - 2026-01-29 08:23:59 --> Router Class Initialized
INFO - 2026-01-29 08:23:59 --> Output Class Initialized
INFO - 2026-01-29 08:23:59 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:59 --> CSRF cookie sent
INFO - 2026-01-29 08:23:59 --> Input Class Initialized
INFO - 2026-01-29 08:23:59 --> Language Class Initialized
INFO - 2026-01-29 08:23:59 --> Loader Class Initialized
INFO - 2026-01-29 08:23:59 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:59 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:59 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:59 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:59 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:59 --> Controller Class Initialized
INFO - 2026-01-29 14:23:59 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:23:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:23:59 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:59 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:59 --> Total execution time: 0.0975
INFO - 2026-01-29 08:23:59 --> Config Class Initialized
INFO - 2026-01-29 08:23:59 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:23:59 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:23:59 --> Utf8 Class Initialized
INFO - 2026-01-29 08:23:59 --> URI Class Initialized
INFO - 2026-01-29 08:23:59 --> Router Class Initialized
INFO - 2026-01-29 08:23:59 --> Output Class Initialized
INFO - 2026-01-29 08:23:59 --> Security Class Initialized
DEBUG - 2026-01-29 08:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:23:59 --> CSRF cookie sent
INFO - 2026-01-29 08:23:59 --> CSRF token verified
INFO - 2026-01-29 08:23:59 --> Input Class Initialized
INFO - 2026-01-29 08:23:59 --> Language Class Initialized
INFO - 2026-01-29 08:23:59 --> Loader Class Initialized
INFO - 2026-01-29 08:23:59 --> Helper loaded: url_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: text_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: string_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: form_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: download_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: security_helper
INFO - 2026-01-29 08:23:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:23:59 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:23:59 --> Form Validation Class Initialized
INFO - 2026-01-29 08:23:59 --> Model "User_model" initialized
INFO - 2026-01-29 14:23:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:23:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:23:59 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:23:59 --> Controller Class Initialized
INFO - 2026-01-29 14:23:59 --> Model "M_log" initialized
INFO - 2026-01-29 14:23:59 --> Model "Log_model" initialized
INFO - 2026-01-29 14:23:59 --> Final output sent to browser
DEBUG - 2026-01-29 14:23:59 --> Total execution time: 0.1025
INFO - 2026-01-29 08:24:43 --> Config Class Initialized
INFO - 2026-01-29 08:24:43 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:24:43 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:24:43 --> Utf8 Class Initialized
INFO - 2026-01-29 08:24:43 --> URI Class Initialized
INFO - 2026-01-29 08:24:43 --> Router Class Initialized
INFO - 2026-01-29 08:24:43 --> Output Class Initialized
INFO - 2026-01-29 08:24:43 --> Security Class Initialized
DEBUG - 2026-01-29 08:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:24:43 --> CSRF cookie sent
INFO - 2026-01-29 08:24:43 --> Input Class Initialized
INFO - 2026-01-29 08:24:43 --> Language Class Initialized
INFO - 2026-01-29 08:24:43 --> Loader Class Initialized
INFO - 2026-01-29 08:24:43 --> Helper loaded: url_helper
INFO - 2026-01-29 08:24:43 --> Helper loaded: text_helper
INFO - 2026-01-29 08:24:43 --> Helper loaded: string_helper
INFO - 2026-01-29 08:24:43 --> Helper loaded: form_helper
INFO - 2026-01-29 08:24:43 --> Helper loaded: download_helper
INFO - 2026-01-29 08:24:43 --> Helper loaded: security_helper
INFO - 2026-01-29 08:24:43 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:24:43 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:24:43 --> Form Validation Class Initialized
INFO - 2026-01-29 08:24:43 --> Model "User_model" initialized
INFO - 2026-01-29 14:24:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:24:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:24:43 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:24:43 --> Controller Class Initialized
INFO - 2026-01-29 14:24:43 --> Model "Log_model" initialized
INFO - 2026-01-29 14:24:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/list.php
INFO - 2026-01-29 14:24:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:24:45 --> Model "Log_model" initialized
INFO - 2026-01-29 14:24:45 --> Final output sent to browser
DEBUG - 2026-01-29 14:24:45 --> Total execution time: 2.2926
INFO - 2026-01-29 08:24:46 --> Config Class Initialized
INFO - 2026-01-29 08:24:46 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:24:46 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:24:46 --> Utf8 Class Initialized
INFO - 2026-01-29 08:24:46 --> URI Class Initialized
INFO - 2026-01-29 08:24:46 --> Router Class Initialized
INFO - 2026-01-29 08:24:46 --> Output Class Initialized
INFO - 2026-01-29 08:24:46 --> Security Class Initialized
DEBUG - 2026-01-29 08:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:24:46 --> CSRF cookie sent
INFO - 2026-01-29 08:24:46 --> CSRF token verified
INFO - 2026-01-29 08:24:46 --> Input Class Initialized
INFO - 2026-01-29 08:24:46 --> Language Class Initialized
INFO - 2026-01-29 08:24:46 --> Loader Class Initialized
INFO - 2026-01-29 08:24:46 --> Helper loaded: url_helper
INFO - 2026-01-29 08:24:46 --> Helper loaded: text_helper
INFO - 2026-01-29 08:24:46 --> Helper loaded: string_helper
INFO - 2026-01-29 08:24:46 --> Helper loaded: form_helper
INFO - 2026-01-29 08:24:46 --> Helper loaded: download_helper
INFO - 2026-01-29 08:24:46 --> Helper loaded: security_helper
INFO - 2026-01-29 08:24:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:24:46 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:24:46 --> Form Validation Class Initialized
INFO - 2026-01-29 08:24:46 --> Model "User_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:24:46 --> Controller Class Initialized
INFO - 2026-01-29 14:24:46 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Video_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:24:46 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:24:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-29 14:24:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:24:46 --> Model "Log_model" initialized
INFO - 2026-01-29 14:24:46 --> Final output sent to browser
DEBUG - 2026-01-29 14:24:46 --> Total execution time: 0.1393
INFO - 2026-01-29 08:24:47 --> Config Class Initialized
INFO - 2026-01-29 08:24:47 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:24:47 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:24:47 --> Utf8 Class Initialized
INFO - 2026-01-29 08:24:47 --> URI Class Initialized
INFO - 2026-01-29 08:24:47 --> Router Class Initialized
INFO - 2026-01-29 08:24:47 --> Output Class Initialized
INFO - 2026-01-29 08:24:47 --> Security Class Initialized
DEBUG - 2026-01-29 08:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:24:47 --> CSRF cookie sent
INFO - 2026-01-29 08:24:47 --> Input Class Initialized
INFO - 2026-01-29 08:24:47 --> Language Class Initialized
INFO - 2026-01-29 08:24:47 --> Loader Class Initialized
INFO - 2026-01-29 08:24:47 --> Helper loaded: url_helper
INFO - 2026-01-29 08:24:47 --> Helper loaded: text_helper
INFO - 2026-01-29 08:24:47 --> Helper loaded: string_helper
INFO - 2026-01-29 08:24:47 --> Helper loaded: form_helper
INFO - 2026-01-29 08:24:47 --> Helper loaded: download_helper
INFO - 2026-01-29 08:24:47 --> Helper loaded: security_helper
INFO - 2026-01-29 08:24:47 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:24:47 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:24:47 --> Form Validation Class Initialized
INFO - 2026-01-29 08:24:47 --> Model "User_model" initialized
INFO - 2026-01-29 14:24:47 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:24:47 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:24:47 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:24:47 --> Controller Class Initialized
INFO - 2026-01-29 14:24:47 --> Model "Log_model" initialized
INFO - 2026-01-29 14:24:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/logs/activity.php
INFO - 2026-01-29 14:24:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:24:47 --> Model "Log_model" initialized
INFO - 2026-01-29 14:24:47 --> Final output sent to browser
DEBUG - 2026-01-29 14:24:47 --> Total execution time: 0.1159
INFO - 2026-01-29 08:24:48 --> Config Class Initialized
INFO - 2026-01-29 08:24:48 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:24:48 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:24:48 --> Utf8 Class Initialized
INFO - 2026-01-29 08:24:48 --> URI Class Initialized
INFO - 2026-01-29 08:24:48 --> Router Class Initialized
INFO - 2026-01-29 08:24:48 --> Output Class Initialized
INFO - 2026-01-29 08:24:48 --> Security Class Initialized
DEBUG - 2026-01-29 08:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:24:48 --> CSRF cookie sent
INFO - 2026-01-29 08:24:48 --> CSRF token verified
INFO - 2026-01-29 08:24:48 --> Input Class Initialized
INFO - 2026-01-29 08:24:48 --> Language Class Initialized
INFO - 2026-01-29 08:24:48 --> Loader Class Initialized
INFO - 2026-01-29 08:24:48 --> Helper loaded: url_helper
INFO - 2026-01-29 08:24:48 --> Helper loaded: text_helper
INFO - 2026-01-29 08:24:48 --> Helper loaded: string_helper
INFO - 2026-01-29 08:24:48 --> Helper loaded: form_helper
INFO - 2026-01-29 08:24:48 --> Helper loaded: download_helper
INFO - 2026-01-29 08:24:48 --> Helper loaded: security_helper
INFO - 2026-01-29 08:24:48 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:24:48 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:24:48 --> Form Validation Class Initialized
INFO - 2026-01-29 08:24:48 --> Model "User_model" initialized
INFO - 2026-01-29 14:24:48 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:24:48 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:24:48 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:24:48 --> Controller Class Initialized
INFO - 2026-01-29 14:24:48 --> Model "Log_model" initialized
DEBUG - 2026-01-29 14:24:48 --> CSRF Token dari request POST: TIDAK ADA
DEBUG - 2026-01-29 14:24:48 --> CSRF Token yang valid: 4b1e58c0b671ee1a27bba1a6063e7793
DEBUG - 2026-01-29 14:24:48 --> Session CSRF Token: 
ERROR - 2026-01-29 14:24:48 --> CSRF Token kosong, periksa apakah dikirim dari frontend.
INFO - 2026-01-29 08:24:56 --> Config Class Initialized
INFO - 2026-01-29 08:24:56 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:24:56 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:24:56 --> Utf8 Class Initialized
INFO - 2026-01-29 08:24:56 --> URI Class Initialized
INFO - 2026-01-29 08:24:56 --> Router Class Initialized
INFO - 2026-01-29 08:24:56 --> Output Class Initialized
INFO - 2026-01-29 08:24:56 --> Security Class Initialized
DEBUG - 2026-01-29 08:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:24:56 --> CSRF cookie sent
INFO - 2026-01-29 08:24:56 --> Input Class Initialized
INFO - 2026-01-29 08:24:56 --> Language Class Initialized
INFO - 2026-01-29 08:24:56 --> Loader Class Initialized
INFO - 2026-01-29 08:24:56 --> Helper loaded: url_helper
INFO - 2026-01-29 08:24:56 --> Helper loaded: text_helper
INFO - 2026-01-29 08:24:56 --> Helper loaded: string_helper
INFO - 2026-01-29 08:24:56 --> Helper loaded: form_helper
INFO - 2026-01-29 08:24:56 --> Helper loaded: download_helper
INFO - 2026-01-29 08:24:56 --> Helper loaded: security_helper
INFO - 2026-01-29 08:24:56 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:24:56 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:24:56 --> Form Validation Class Initialized
INFO - 2026-01-29 08:24:56 --> Model "User_model" initialized
INFO - 2026-01-29 14:24:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:24:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:24:56 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:24:56 --> Controller Class Initialized
INFO - 2026-01-29 14:24:56 --> Model "Monitoring_model" initialized
INFO - 2026-01-29 14:24:56 --> Model "Mperiode_model" initialized
INFO - 2026-01-29 14:24:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/monitoring/list.php
INFO - 2026-01-29 14:24:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:24:57 --> Model "Log_model" initialized
INFO - 2026-01-29 14:24:57 --> Final output sent to browser
DEBUG - 2026-01-29 14:24:57 --> Total execution time: 0.7287
INFO - 2026-01-29 08:25:01 --> Config Class Initialized
INFO - 2026-01-29 08:25:01 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:25:01 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:25:01 --> Utf8 Class Initialized
INFO - 2026-01-29 08:25:01 --> URI Class Initialized
INFO - 2026-01-29 08:25:01 --> Router Class Initialized
INFO - 2026-01-29 08:25:01 --> Output Class Initialized
INFO - 2026-01-29 08:25:01 --> Security Class Initialized
DEBUG - 2026-01-29 08:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:25:01 --> CSRF cookie sent
INFO - 2026-01-29 08:25:01 --> Input Class Initialized
INFO - 2026-01-29 08:25:01 --> Language Class Initialized
INFO - 2026-01-29 08:25:01 --> Loader Class Initialized
INFO - 2026-01-29 08:25:01 --> Helper loaded: url_helper
INFO - 2026-01-29 08:25:01 --> Helper loaded: text_helper
INFO - 2026-01-29 08:25:01 --> Helper loaded: string_helper
INFO - 2026-01-29 08:25:01 --> Helper loaded: form_helper
INFO - 2026-01-29 08:25:01 --> Helper loaded: download_helper
INFO - 2026-01-29 08:25:01 --> Helper loaded: security_helper
INFO - 2026-01-29 08:25:01 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:25:01 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:25:01 --> Form Validation Class Initialized
INFO - 2026-01-29 08:25:01 --> Model "User_model" initialized
INFO - 2026-01-29 14:25:01 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:25:01 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:25:01 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:25:01 --> Controller Class Initialized
INFO - 2026-01-29 14:25:01 --> Model "Kontributor_model" initialized
INFO - 2026-01-29 14:25:01 --> Model "Kontributor_images_model" initialized
INFO - 2026-01-29 14:25:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/kontributor/list.php
INFO - 2026-01-29 14:25:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:25:01 --> Model "Log_model" initialized
INFO - 2026-01-29 14:25:01 --> Final output sent to browser
DEBUG - 2026-01-29 14:25:01 --> Total execution time: 0.1946
INFO - 2026-01-29 08:25:08 --> Config Class Initialized
INFO - 2026-01-29 08:25:08 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:25:08 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:25:08 --> Utf8 Class Initialized
INFO - 2026-01-29 08:25:08 --> URI Class Initialized
INFO - 2026-01-29 08:25:08 --> Router Class Initialized
INFO - 2026-01-29 08:25:08 --> Output Class Initialized
INFO - 2026-01-29 08:25:08 --> Security Class Initialized
DEBUG - 2026-01-29 08:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:25:08 --> CSRF cookie sent
INFO - 2026-01-29 08:25:08 --> Input Class Initialized
INFO - 2026-01-29 08:25:08 --> Language Class Initialized
INFO - 2026-01-29 08:25:08 --> Loader Class Initialized
INFO - 2026-01-29 08:25:08 --> Helper loaded: url_helper
INFO - 2026-01-29 08:25:08 --> Helper loaded: text_helper
INFO - 2026-01-29 08:25:08 --> Helper loaded: string_helper
INFO - 2026-01-29 08:25:08 --> Helper loaded: form_helper
INFO - 2026-01-29 08:25:08 --> Helper loaded: download_helper
INFO - 2026-01-29 08:25:08 --> Helper loaded: security_helper
INFO - 2026-01-29 08:25:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:25:08 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:25:08 --> Form Validation Class Initialized
INFO - 2026-01-29 08:25:08 --> Model "User_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:25:09 --> Controller Class Initialized
INFO - 2026-01-29 14:25:09 --> Model "Kontributor_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Kontributor_images_model" initialized
INFO - 2026-01-29 14:25:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/kontributor/detail.php
INFO - 2026-01-29 14:25:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:25:09 --> Model "Log_model" initialized
INFO - 2026-01-29 14:25:09 --> Final output sent to browser
DEBUG - 2026-01-29 14:25:09 --> Total execution time: 0.2045
INFO - 2026-01-29 08:25:09 --> Config Class Initialized
INFO - 2026-01-29 08:25:09 --> Hooks Class Initialized
INFO - 2026-01-29 08:25:09 --> Config Class Initialized
INFO - 2026-01-29 08:25:09 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:25:09 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:25:09 --> Utf8 Class Initialized
DEBUG - 2026-01-29 08:25:09 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:25:09 --> Utf8 Class Initialized
INFO - 2026-01-29 08:25:09 --> URI Class Initialized
INFO - 2026-01-29 08:25:09 --> URI Class Initialized
INFO - 2026-01-29 08:25:09 --> Router Class Initialized
INFO - 2026-01-29 08:25:09 --> Router Class Initialized
INFO - 2026-01-29 08:25:09 --> Output Class Initialized
INFO - 2026-01-29 08:25:09 --> Output Class Initialized
INFO - 2026-01-29 08:25:09 --> Security Class Initialized
INFO - 2026-01-29 08:25:09 --> Security Class Initialized
DEBUG - 2026-01-29 08:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:25:09 --> CSRF cookie sent
DEBUG - 2026-01-29 08:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:25:09 --> Input Class Initialized
INFO - 2026-01-29 08:25:09 --> CSRF cookie sent
INFO - 2026-01-29 08:25:09 --> Input Class Initialized
INFO - 2026-01-29 08:25:09 --> Language Class Initialized
INFO - 2026-01-29 08:25:09 --> Language Class Initialized
INFO - 2026-01-29 08:25:09 --> Loader Class Initialized
INFO - 2026-01-29 08:25:09 --> Loader Class Initialized
INFO - 2026-01-29 08:25:09 --> Helper loaded: url_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: url_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: text_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: text_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: string_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: string_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: form_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: form_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: download_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: download_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: security_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: security_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:25:09 --> Database Driver Class Initialized
INFO - 2026-01-29 08:25:09 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2026-01-29 08:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:25:09 --> Form Validation Class Initialized
INFO - 2026-01-29 08:25:09 --> Model "User_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:25:09 --> Controller Class Initialized
INFO - 2026-01-29 14:25:09 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Video_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:25:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-29 14:25:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:25:09 --> Model "Log_model" initialized
INFO - 2026-01-29 14:25:09 --> Final output sent to browser
DEBUG - 2026-01-29 14:25:09 --> Total execution time: 0.1584
INFO - 2026-01-29 08:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:25:09 --> Form Validation Class Initialized
INFO - 2026-01-29 08:25:09 --> Model "User_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:25:09 --> Controller Class Initialized
INFO - 2026-01-29 14:25:09 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Video_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:25:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-29 14:25:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:25:09 --> Model "Log_model" initialized
INFO - 2026-01-29 14:25:09 --> Final output sent to browser
DEBUG - 2026-01-29 14:25:09 --> Total execution time: 0.2190
INFO - 2026-01-29 08:25:09 --> Config Class Initialized
INFO - 2026-01-29 08:25:09 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:25:09 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:25:09 --> Utf8 Class Initialized
INFO - 2026-01-29 08:25:09 --> URI Class Initialized
INFO - 2026-01-29 08:25:09 --> Router Class Initialized
INFO - 2026-01-29 08:25:09 --> Output Class Initialized
INFO - 2026-01-29 08:25:09 --> Security Class Initialized
DEBUG - 2026-01-29 08:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:25:09 --> CSRF cookie sent
INFO - 2026-01-29 08:25:09 --> Input Class Initialized
INFO - 2026-01-29 08:25:09 --> Language Class Initialized
INFO - 2026-01-29 08:25:09 --> Loader Class Initialized
INFO - 2026-01-29 08:25:09 --> Helper loaded: url_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: text_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: string_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: form_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: download_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: security_helper
INFO - 2026-01-29 08:25:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:25:09 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:25:09 --> Form Validation Class Initialized
INFO - 2026-01-29 08:25:09 --> Model "User_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:25:09 --> Controller Class Initialized
INFO - 2026-01-29 14:25:09 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Video_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:25:09 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:25:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-29 14:25:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:25:09 --> Model "Log_model" initialized
INFO - 2026-01-29 14:25:09 --> Final output sent to browser
DEBUG - 2026-01-29 14:25:09 --> Total execution time: 0.1349
INFO - 2026-01-29 08:25:17 --> Config Class Initialized
INFO - 2026-01-29 08:25:17 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:25:17 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:25:17 --> Utf8 Class Initialized
INFO - 2026-01-29 08:25:17 --> URI Class Initialized
INFO - 2026-01-29 08:25:17 --> Router Class Initialized
INFO - 2026-01-29 08:25:17 --> Output Class Initialized
INFO - 2026-01-29 08:25:17 --> Security Class Initialized
DEBUG - 2026-01-29 08:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:25:17 --> CSRF cookie sent
INFO - 2026-01-29 08:25:17 --> Input Class Initialized
INFO - 2026-01-29 08:25:17 --> Language Class Initialized
INFO - 2026-01-29 08:25:17 --> Loader Class Initialized
INFO - 2026-01-29 08:25:17 --> Helper loaded: url_helper
INFO - 2026-01-29 08:25:17 --> Helper loaded: text_helper
INFO - 2026-01-29 08:25:17 --> Helper loaded: string_helper
INFO - 2026-01-29 08:25:17 --> Helper loaded: form_helper
INFO - 2026-01-29 08:25:17 --> Helper loaded: download_helper
INFO - 2026-01-29 08:25:17 --> Helper loaded: security_helper
INFO - 2026-01-29 08:25:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:25:17 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:25:17 --> Form Validation Class Initialized
INFO - 2026-01-29 08:25:17 --> Model "User_model" initialized
INFO - 2026-01-29 14:25:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:25:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:25:17 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:25:17 --> Controller Class Initialized
INFO - 2026-01-29 14:25:17 --> Model "Kontributor_model" initialized
INFO - 2026-01-29 14:25:17 --> Model "Kontributor_images_model" initialized
INFO - 2026-01-29 14:25:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/kontributor/list.php
INFO - 2026-01-29 14:25:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:25:17 --> Model "Log_model" initialized
INFO - 2026-01-29 14:25:17 --> Final output sent to browser
DEBUG - 2026-01-29 14:25:17 --> Total execution time: 0.1246
INFO - 2026-01-29 08:25:54 --> Config Class Initialized
INFO - 2026-01-29 08:25:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:25:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:25:54 --> Utf8 Class Initialized
INFO - 2026-01-29 08:25:54 --> URI Class Initialized
INFO - 2026-01-29 08:25:54 --> Router Class Initialized
INFO - 2026-01-29 08:25:54 --> Output Class Initialized
INFO - 2026-01-29 08:25:54 --> Security Class Initialized
DEBUG - 2026-01-29 08:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:25:54 --> CSRF cookie sent
INFO - 2026-01-29 08:25:54 --> Input Class Initialized
INFO - 2026-01-29 08:25:54 --> Language Class Initialized
INFO - 2026-01-29 08:25:54 --> Loader Class Initialized
INFO - 2026-01-29 08:25:54 --> Helper loaded: url_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: text_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: string_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: form_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: download_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: security_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:25:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:25:54 --> Form Validation Class Initialized
INFO - 2026-01-29 08:25:54 --> Model "User_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:25:54 --> Controller Class Initialized
INFO - 2026-01-29 14:25:54 --> Model "Pages_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Download_model" initialized
INFO - 2026-01-29 14:25:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pages/list.php
INFO - 2026-01-29 14:25:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:25:54 --> Model "Log_model" initialized
INFO - 2026-01-29 14:25:54 --> Final output sent to browser
DEBUG - 2026-01-29 14:25:54 --> Total execution time: 0.1519
INFO - 2026-01-29 08:25:54 --> Config Class Initialized
INFO - 2026-01-29 08:25:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:25:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:25:54 --> Utf8 Class Initialized
INFO - 2026-01-29 08:25:54 --> URI Class Initialized
INFO - 2026-01-29 08:25:54 --> Router Class Initialized
INFO - 2026-01-29 08:25:54 --> Output Class Initialized
INFO - 2026-01-29 08:25:54 --> Security Class Initialized
DEBUG - 2026-01-29 08:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:25:54 --> CSRF cookie sent
INFO - 2026-01-29 08:25:54 --> Input Class Initialized
INFO - 2026-01-29 08:25:54 --> Language Class Initialized
INFO - 2026-01-29 08:25:54 --> Loader Class Initialized
INFO - 2026-01-29 08:25:54 --> Helper loaded: url_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: text_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: string_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: form_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: download_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: security_helper
INFO - 2026-01-29 08:25:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:25:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:25:54 --> Form Validation Class Initialized
INFO - 2026-01-29 08:25:54 --> Model "User_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:25:54 --> Controller Class Initialized
INFO - 2026-01-29 14:25:54 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Video_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:25:54 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:25:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2026-01-29 14:25:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:25:54 --> Model "Log_model" initialized
INFO - 2026-01-29 14:25:54 --> Final output sent to browser
DEBUG - 2026-01-29 14:25:54 --> Total execution time: 0.1383
INFO - 2026-01-29 08:26:00 --> Config Class Initialized
INFO - 2026-01-29 08:26:00 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:26:00 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:26:00 --> Utf8 Class Initialized
INFO - 2026-01-29 08:26:00 --> URI Class Initialized
INFO - 2026-01-29 08:26:00 --> Router Class Initialized
INFO - 2026-01-29 08:26:00 --> Output Class Initialized
INFO - 2026-01-29 08:26:00 --> Security Class Initialized
DEBUG - 2026-01-29 08:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:26:00 --> CSRF cookie sent
INFO - 2026-01-29 08:26:00 --> Input Class Initialized
INFO - 2026-01-29 08:26:00 --> Language Class Initialized
INFO - 2026-01-29 08:26:00 --> Loader Class Initialized
INFO - 2026-01-29 08:26:00 --> Helper loaded: url_helper
INFO - 2026-01-29 08:26:00 --> Helper loaded: text_helper
INFO - 2026-01-29 08:26:00 --> Helper loaded: string_helper
INFO - 2026-01-29 08:26:00 --> Helper loaded: form_helper
INFO - 2026-01-29 08:26:00 --> Helper loaded: download_helper
INFO - 2026-01-29 08:26:00 --> Helper loaded: security_helper
INFO - 2026-01-29 08:26:00 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:26:00 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:26:00 --> Form Validation Class Initialized
INFO - 2026-01-29 08:26:00 --> Model "User_model" initialized
INFO - 2026-01-29 14:26:00 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:26:00 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:26:00 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:26:00 --> Controller Class Initialized
INFO - 2026-01-29 14:26:00 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:26:00 --> Model "Staff_model" initialized
INFO - 2026-01-29 14:26:00 --> Model "Dasbor_model" initialized
INFO - 2026-01-29 14:26:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2026-01-29 14:26:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 14:26:00 --> Model "Log_model" initialized
INFO - 2026-01-29 14:26:00 --> Final output sent to browser
DEBUG - 2026-01-29 14:26:00 --> Total execution time: 0.5018
INFO - 2026-01-29 08:36:16 --> Config Class Initialized
INFO - 2026-01-29 08:36:16 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:36:16 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:36:16 --> Utf8 Class Initialized
INFO - 2026-01-29 08:36:16 --> URI Class Initialized
DEBUG - 2026-01-29 08:36:16 --> No URI present. Default controller set.
INFO - 2026-01-29 08:36:16 --> Router Class Initialized
INFO - 2026-01-29 08:36:16 --> Output Class Initialized
INFO - 2026-01-29 08:36:16 --> Security Class Initialized
DEBUG - 2026-01-29 08:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:36:16 --> CSRF cookie sent
INFO - 2026-01-29 08:36:16 --> Input Class Initialized
INFO - 2026-01-29 08:36:16 --> Language Class Initialized
INFO - 2026-01-29 08:36:16 --> Loader Class Initialized
INFO - 2026-01-29 08:36:16 --> Helper loaded: url_helper
INFO - 2026-01-29 08:36:16 --> Helper loaded: text_helper
INFO - 2026-01-29 08:36:16 --> Helper loaded: string_helper
INFO - 2026-01-29 08:36:16 --> Helper loaded: form_helper
INFO - 2026-01-29 08:36:16 --> Helper loaded: download_helper
INFO - 2026-01-29 08:36:16 --> Helper loaded: security_helper
INFO - 2026-01-29 08:36:16 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:36:16 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:36:16 --> Form Validation Class Initialized
INFO - 2026-01-29 08:36:16 --> Model "User_model" initialized
INFO - 2026-01-29 14:36:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:36:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:36:17 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:36:17 --> Controller Class Initialized
INFO - 2026-01-29 14:36:17 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:36:17 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:36:17 --> Model "Video_model" initialized
INFO - 2026-01-29 14:36:17 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:36:17 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:36:17 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:36:17 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:36:17 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:36:17 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:36:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:36:17 --> Pagination Class Initialized
INFO - 2026-01-29 14:36:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:36:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:36:17 --> Model "Log_model" initialized
INFO - 2026-01-29 14:36:17 --> Final output sent to browser
DEBUG - 2026-01-29 14:36:17 --> Total execution time: 0.2948
INFO - 2026-01-29 08:37:50 --> Config Class Initialized
INFO - 2026-01-29 08:37:50 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:37:50 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:37:50 --> Utf8 Class Initialized
INFO - 2026-01-29 08:37:50 --> URI Class Initialized
DEBUG - 2026-01-29 08:37:50 --> No URI present. Default controller set.
INFO - 2026-01-29 08:37:50 --> Router Class Initialized
INFO - 2026-01-29 08:37:50 --> Output Class Initialized
INFO - 2026-01-29 08:37:50 --> Security Class Initialized
DEBUG - 2026-01-29 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:37:50 --> CSRF cookie sent
INFO - 2026-01-29 08:37:50 --> Input Class Initialized
INFO - 2026-01-29 08:37:50 --> Language Class Initialized
INFO - 2026-01-29 08:37:50 --> Loader Class Initialized
INFO - 2026-01-29 08:37:50 --> Helper loaded: url_helper
INFO - 2026-01-29 08:37:50 --> Helper loaded: text_helper
INFO - 2026-01-29 08:37:50 --> Helper loaded: string_helper
INFO - 2026-01-29 08:37:50 --> Helper loaded: form_helper
INFO - 2026-01-29 08:37:50 --> Helper loaded: download_helper
INFO - 2026-01-29 08:37:50 --> Helper loaded: security_helper
INFO - 2026-01-29 08:37:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:37:50 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:37:50 --> Form Validation Class Initialized
INFO - 2026-01-29 08:37:50 --> Model "User_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:37:50 --> Controller Class Initialized
INFO - 2026-01-29 14:37:50 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Video_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:37:50 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:37:50 --> Pagination Class Initialized
INFO - 2026-01-29 14:37:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:37:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:37:50 --> Model "Log_model" initialized
INFO - 2026-01-29 14:37:50 --> Final output sent to browser
DEBUG - 2026-01-29 14:37:50 --> Total execution time: 0.3203
INFO - 2026-01-29 08:42:13 --> Config Class Initialized
INFO - 2026-01-29 08:42:13 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:42:13 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:42:13 --> Utf8 Class Initialized
INFO - 2026-01-29 08:42:13 --> URI Class Initialized
DEBUG - 2026-01-29 08:42:13 --> No URI present. Default controller set.
INFO - 2026-01-29 08:42:13 --> Router Class Initialized
INFO - 2026-01-29 08:42:13 --> Output Class Initialized
INFO - 2026-01-29 08:42:13 --> Security Class Initialized
DEBUG - 2026-01-29 08:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:42:13 --> CSRF cookie sent
INFO - 2026-01-29 08:42:13 --> Input Class Initialized
INFO - 2026-01-29 08:42:13 --> Language Class Initialized
INFO - 2026-01-29 08:42:13 --> Loader Class Initialized
INFO - 2026-01-29 08:42:13 --> Helper loaded: url_helper
INFO - 2026-01-29 08:42:13 --> Helper loaded: text_helper
INFO - 2026-01-29 08:42:13 --> Helper loaded: string_helper
INFO - 2026-01-29 08:42:13 --> Helper loaded: form_helper
INFO - 2026-01-29 08:42:13 --> Helper loaded: download_helper
INFO - 2026-01-29 08:42:13 --> Helper loaded: security_helper
INFO - 2026-01-29 08:42:13 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:42:13 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:42:13 --> Form Validation Class Initialized
INFO - 2026-01-29 08:42:13 --> Model "User_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:42:13 --> Controller Class Initialized
INFO - 2026-01-29 14:42:13 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Video_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:42:13 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:42:13 --> Pagination Class Initialized
INFO - 2026-01-29 14:42:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:42:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:42:13 --> Model "Log_model" initialized
INFO - 2026-01-29 14:42:13 --> Final output sent to browser
DEBUG - 2026-01-29 14:42:13 --> Total execution time: 0.2058
INFO - 2026-01-29 08:42:22 --> Config Class Initialized
INFO - 2026-01-29 08:42:22 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:42:22 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:42:22 --> Utf8 Class Initialized
INFO - 2026-01-29 08:42:22 --> URI Class Initialized
DEBUG - 2026-01-29 08:42:22 --> No URI present. Default controller set.
INFO - 2026-01-29 08:42:22 --> Router Class Initialized
INFO - 2026-01-29 08:42:22 --> Output Class Initialized
INFO - 2026-01-29 08:42:22 --> Security Class Initialized
DEBUG - 2026-01-29 08:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:42:22 --> CSRF cookie sent
INFO - 2026-01-29 08:42:22 --> Input Class Initialized
INFO - 2026-01-29 08:42:22 --> Language Class Initialized
INFO - 2026-01-29 08:42:22 --> Loader Class Initialized
INFO - 2026-01-29 08:42:23 --> Helper loaded: url_helper
INFO - 2026-01-29 08:42:23 --> Helper loaded: text_helper
INFO - 2026-01-29 08:42:23 --> Helper loaded: string_helper
INFO - 2026-01-29 08:42:23 --> Helper loaded: form_helper
INFO - 2026-01-29 08:42:23 --> Helper loaded: download_helper
INFO - 2026-01-29 08:42:23 --> Helper loaded: security_helper
INFO - 2026-01-29 08:42:23 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:42:23 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:42:23 --> Form Validation Class Initialized
INFO - 2026-01-29 08:42:23 --> Model "User_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:42:23 --> Controller Class Initialized
INFO - 2026-01-29 14:42:23 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Video_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:42:23 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:42:23 --> Pagination Class Initialized
INFO - 2026-01-29 14:42:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:42:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:42:23 --> Model "Log_model" initialized
INFO - 2026-01-29 14:42:23 --> Final output sent to browser
DEBUG - 2026-01-29 14:42:23 --> Total execution time: 0.2318
INFO - 2026-01-29 08:42:48 --> Config Class Initialized
INFO - 2026-01-29 08:42:48 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:42:48 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:42:48 --> Utf8 Class Initialized
INFO - 2026-01-29 08:42:48 --> URI Class Initialized
DEBUG - 2026-01-29 08:42:48 --> No URI present. Default controller set.
INFO - 2026-01-29 08:42:48 --> Router Class Initialized
INFO - 2026-01-29 08:42:48 --> Output Class Initialized
INFO - 2026-01-29 08:42:48 --> Security Class Initialized
DEBUG - 2026-01-29 08:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:42:48 --> CSRF cookie sent
INFO - 2026-01-29 08:42:48 --> Input Class Initialized
INFO - 2026-01-29 08:42:48 --> Language Class Initialized
INFO - 2026-01-29 08:42:48 --> Loader Class Initialized
INFO - 2026-01-29 08:42:48 --> Helper loaded: url_helper
INFO - 2026-01-29 08:42:48 --> Helper loaded: text_helper
INFO - 2026-01-29 08:42:48 --> Helper loaded: string_helper
INFO - 2026-01-29 08:42:48 --> Helper loaded: form_helper
INFO - 2026-01-29 08:42:48 --> Helper loaded: download_helper
INFO - 2026-01-29 08:42:48 --> Helper loaded: security_helper
INFO - 2026-01-29 08:42:48 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:42:48 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:42:48 --> Form Validation Class Initialized
INFO - 2026-01-29 08:42:48 --> Model "User_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:42:48 --> Controller Class Initialized
INFO - 2026-01-29 14:42:48 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Video_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:42:48 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:42:48 --> Pagination Class Initialized
INFO - 2026-01-29 14:42:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:42:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:42:48 --> Model "Log_model" initialized
INFO - 2026-01-29 14:42:48 --> Final output sent to browser
DEBUG - 2026-01-29 14:42:48 --> Total execution time: 0.2474
INFO - 2026-01-29 08:45:37 --> Config Class Initialized
INFO - 2026-01-29 08:45:37 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:45:37 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:45:37 --> Utf8 Class Initialized
INFO - 2026-01-29 08:45:37 --> URI Class Initialized
DEBUG - 2026-01-29 08:45:37 --> No URI present. Default controller set.
INFO - 2026-01-29 08:45:37 --> Router Class Initialized
INFO - 2026-01-29 08:45:37 --> Output Class Initialized
INFO - 2026-01-29 08:45:37 --> Security Class Initialized
DEBUG - 2026-01-29 08:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:45:37 --> CSRF cookie sent
INFO - 2026-01-29 08:45:37 --> Input Class Initialized
INFO - 2026-01-29 08:45:37 --> Language Class Initialized
INFO - 2026-01-29 08:45:37 --> Loader Class Initialized
INFO - 2026-01-29 08:45:37 --> Helper loaded: url_helper
INFO - 2026-01-29 08:45:37 --> Helper loaded: text_helper
INFO - 2026-01-29 08:45:37 --> Helper loaded: string_helper
INFO - 2026-01-29 08:45:37 --> Helper loaded: form_helper
INFO - 2026-01-29 08:45:37 --> Helper loaded: download_helper
INFO - 2026-01-29 08:45:37 --> Helper loaded: security_helper
INFO - 2026-01-29 08:45:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:45:37 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:45:37 --> Form Validation Class Initialized
INFO - 2026-01-29 08:45:37 --> Model "User_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:45:37 --> Controller Class Initialized
INFO - 2026-01-29 14:45:37 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Video_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:45:37 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:45:37 --> Pagination Class Initialized
INFO - 2026-01-29 14:45:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:45:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:45:37 --> Model "Log_model" initialized
INFO - 2026-01-29 14:45:37 --> Final output sent to browser
DEBUG - 2026-01-29 14:45:37 --> Total execution time: 0.2009
INFO - 2026-01-29 08:46:04 --> Config Class Initialized
INFO - 2026-01-29 08:46:04 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:46:04 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:46:04 --> Utf8 Class Initialized
INFO - 2026-01-29 08:46:04 --> URI Class Initialized
DEBUG - 2026-01-29 08:46:04 --> No URI present. Default controller set.
INFO - 2026-01-29 08:46:04 --> Router Class Initialized
INFO - 2026-01-29 08:46:04 --> Output Class Initialized
INFO - 2026-01-29 08:46:04 --> Security Class Initialized
DEBUG - 2026-01-29 08:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:46:04 --> CSRF cookie sent
INFO - 2026-01-29 08:46:04 --> Input Class Initialized
INFO - 2026-01-29 08:46:04 --> Language Class Initialized
INFO - 2026-01-29 08:46:04 --> Loader Class Initialized
INFO - 2026-01-29 08:46:04 --> Helper loaded: url_helper
INFO - 2026-01-29 08:46:04 --> Helper loaded: text_helper
INFO - 2026-01-29 08:46:04 --> Helper loaded: string_helper
INFO - 2026-01-29 08:46:04 --> Helper loaded: form_helper
INFO - 2026-01-29 08:46:04 --> Helper loaded: download_helper
INFO - 2026-01-29 08:46:04 --> Helper loaded: security_helper
INFO - 2026-01-29 08:46:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:46:04 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:46:04 --> Form Validation Class Initialized
INFO - 2026-01-29 08:46:04 --> Model "User_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:46:04 --> Controller Class Initialized
INFO - 2026-01-29 14:46:04 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Video_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:46:04 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:46:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:46:04 --> Pagination Class Initialized
INFO - 2026-01-29 14:46:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:46:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:46:04 --> Model "Log_model" initialized
INFO - 2026-01-29 14:46:04 --> Final output sent to browser
DEBUG - 2026-01-29 14:46:04 --> Total execution time: 0.2921
INFO - 2026-01-29 08:49:23 --> Config Class Initialized
INFO - 2026-01-29 08:49:23 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:49:23 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:49:23 --> Utf8 Class Initialized
INFO - 2026-01-29 08:49:23 --> URI Class Initialized
DEBUG - 2026-01-29 08:49:23 --> No URI present. Default controller set.
INFO - 2026-01-29 08:49:23 --> Router Class Initialized
INFO - 2026-01-29 08:49:23 --> Output Class Initialized
INFO - 2026-01-29 08:49:23 --> Security Class Initialized
DEBUG - 2026-01-29 08:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:49:23 --> CSRF cookie sent
INFO - 2026-01-29 08:49:23 --> Input Class Initialized
INFO - 2026-01-29 08:49:23 --> Language Class Initialized
INFO - 2026-01-29 08:49:23 --> Loader Class Initialized
INFO - 2026-01-29 08:49:23 --> Helper loaded: url_helper
INFO - 2026-01-29 08:49:23 --> Helper loaded: text_helper
INFO - 2026-01-29 08:49:23 --> Helper loaded: string_helper
INFO - 2026-01-29 08:49:23 --> Helper loaded: form_helper
INFO - 2026-01-29 08:49:23 --> Helper loaded: download_helper
INFO - 2026-01-29 08:49:23 --> Helper loaded: security_helper
INFO - 2026-01-29 08:49:23 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:49:23 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:49:23 --> Form Validation Class Initialized
INFO - 2026-01-29 08:49:23 --> Model "User_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:49:23 --> Controller Class Initialized
INFO - 2026-01-29 14:49:23 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Video_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:49:23 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:49:23 --> Pagination Class Initialized
INFO - 2026-01-29 14:49:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:49:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:49:24 --> Model "Log_model" initialized
INFO - 2026-01-29 14:49:24 --> Final output sent to browser
DEBUG - 2026-01-29 14:49:24 --> Total execution time: 0.6339
INFO - 2026-01-29 08:49:33 --> Config Class Initialized
INFO - 2026-01-29 08:49:33 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:49:33 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:49:33 --> Utf8 Class Initialized
INFO - 2026-01-29 08:49:33 --> URI Class Initialized
DEBUG - 2026-01-29 08:49:33 --> No URI present. Default controller set.
INFO - 2026-01-29 08:49:33 --> Router Class Initialized
INFO - 2026-01-29 08:49:33 --> Output Class Initialized
INFO - 2026-01-29 08:49:33 --> Security Class Initialized
DEBUG - 2026-01-29 08:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:49:33 --> CSRF cookie sent
INFO - 2026-01-29 08:49:33 --> Input Class Initialized
INFO - 2026-01-29 08:49:33 --> Language Class Initialized
INFO - 2026-01-29 08:49:33 --> Loader Class Initialized
INFO - 2026-01-29 08:49:33 --> Helper loaded: url_helper
INFO - 2026-01-29 08:49:33 --> Helper loaded: text_helper
INFO - 2026-01-29 08:49:33 --> Helper loaded: string_helper
INFO - 2026-01-29 08:49:33 --> Helper loaded: form_helper
INFO - 2026-01-29 08:49:33 --> Helper loaded: download_helper
INFO - 2026-01-29 08:49:33 --> Helper loaded: security_helper
INFO - 2026-01-29 08:49:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:49:33 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:49:33 --> Form Validation Class Initialized
INFO - 2026-01-29 08:49:33 --> Model "User_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:49:33 --> Controller Class Initialized
INFO - 2026-01-29 14:49:33 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Video_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:49:33 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:49:33 --> Pagination Class Initialized
INFO - 2026-01-29 14:49:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:49:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:49:34 --> Model "Log_model" initialized
INFO - 2026-01-29 14:49:34 --> Final output sent to browser
DEBUG - 2026-01-29 14:49:34 --> Total execution time: 0.2376
INFO - 2026-01-29 08:50:25 --> Config Class Initialized
INFO - 2026-01-29 08:50:25 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:50:25 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:50:25 --> Utf8 Class Initialized
INFO - 2026-01-29 08:50:25 --> URI Class Initialized
DEBUG - 2026-01-29 08:50:25 --> No URI present. Default controller set.
INFO - 2026-01-29 08:50:25 --> Router Class Initialized
INFO - 2026-01-29 08:50:25 --> Output Class Initialized
INFO - 2026-01-29 08:50:25 --> Security Class Initialized
DEBUG - 2026-01-29 08:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:50:25 --> CSRF cookie sent
INFO - 2026-01-29 08:50:25 --> Input Class Initialized
INFO - 2026-01-29 08:50:25 --> Language Class Initialized
INFO - 2026-01-29 08:50:25 --> Loader Class Initialized
INFO - 2026-01-29 08:50:25 --> Helper loaded: url_helper
INFO - 2026-01-29 08:50:25 --> Helper loaded: text_helper
INFO - 2026-01-29 08:50:25 --> Helper loaded: string_helper
INFO - 2026-01-29 08:50:25 --> Helper loaded: form_helper
INFO - 2026-01-29 08:50:25 --> Helper loaded: download_helper
INFO - 2026-01-29 08:50:25 --> Helper loaded: security_helper
INFO - 2026-01-29 08:50:25 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:50:25 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:50:25 --> Form Validation Class Initialized
INFO - 2026-01-29 08:50:25 --> Model "User_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:50:25 --> Controller Class Initialized
INFO - 2026-01-29 14:50:25 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Video_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:50:25 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:50:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:50:25 --> Pagination Class Initialized
INFO - 2026-01-29 14:50:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:50:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:50:26 --> Model "Log_model" initialized
INFO - 2026-01-29 14:50:26 --> Final output sent to browser
DEBUG - 2026-01-29 14:50:26 --> Total execution time: 0.4436
INFO - 2026-01-29 08:50:53 --> Config Class Initialized
INFO - 2026-01-29 08:50:53 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:50:53 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:50:53 --> Utf8 Class Initialized
INFO - 2026-01-29 08:50:53 --> URI Class Initialized
DEBUG - 2026-01-29 08:50:53 --> No URI present. Default controller set.
INFO - 2026-01-29 08:50:53 --> Router Class Initialized
INFO - 2026-01-29 08:50:53 --> Output Class Initialized
INFO - 2026-01-29 08:50:53 --> Security Class Initialized
DEBUG - 2026-01-29 08:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:50:53 --> CSRF cookie sent
INFO - 2026-01-29 08:50:53 --> Input Class Initialized
INFO - 2026-01-29 08:50:53 --> Language Class Initialized
INFO - 2026-01-29 08:50:53 --> Loader Class Initialized
INFO - 2026-01-29 08:50:53 --> Helper loaded: url_helper
INFO - 2026-01-29 08:50:53 --> Helper loaded: text_helper
INFO - 2026-01-29 08:50:53 --> Helper loaded: string_helper
INFO - 2026-01-29 08:50:53 --> Helper loaded: form_helper
INFO - 2026-01-29 08:50:53 --> Helper loaded: download_helper
INFO - 2026-01-29 08:50:53 --> Helper loaded: security_helper
INFO - 2026-01-29 08:50:53 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:50:53 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:50:53 --> Form Validation Class Initialized
INFO - 2026-01-29 08:50:53 --> Model "User_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:50:53 --> Controller Class Initialized
INFO - 2026-01-29 14:50:53 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Video_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:50:53 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:50:53 --> Pagination Class Initialized
INFO - 2026-01-29 14:50:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:50:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:50:53 --> Model "Log_model" initialized
INFO - 2026-01-29 14:50:53 --> Final output sent to browser
DEBUG - 2026-01-29 14:50:53 --> Total execution time: 0.1892
INFO - 2026-01-29 08:52:23 --> Config Class Initialized
INFO - 2026-01-29 08:52:23 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:52:23 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:52:23 --> Utf8 Class Initialized
INFO - 2026-01-29 08:52:23 --> URI Class Initialized
DEBUG - 2026-01-29 08:52:23 --> No URI present. Default controller set.
INFO - 2026-01-29 08:52:23 --> Router Class Initialized
INFO - 2026-01-29 08:52:23 --> Output Class Initialized
INFO - 2026-01-29 08:52:23 --> Security Class Initialized
DEBUG - 2026-01-29 08:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:52:23 --> CSRF cookie sent
INFO - 2026-01-29 08:52:23 --> Input Class Initialized
INFO - 2026-01-29 08:52:23 --> Language Class Initialized
INFO - 2026-01-29 08:52:23 --> Loader Class Initialized
INFO - 2026-01-29 08:52:23 --> Helper loaded: url_helper
INFO - 2026-01-29 08:52:23 --> Helper loaded: text_helper
INFO - 2026-01-29 08:52:23 --> Helper loaded: string_helper
INFO - 2026-01-29 08:52:23 --> Helper loaded: form_helper
INFO - 2026-01-29 08:52:23 --> Helper loaded: download_helper
INFO - 2026-01-29 08:52:23 --> Helper loaded: security_helper
INFO - 2026-01-29 08:52:23 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:52:23 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:52:23 --> Form Validation Class Initialized
INFO - 2026-01-29 08:52:23 --> Model "User_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:52:24 --> Controller Class Initialized
INFO - 2026-01-29 14:52:24 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Video_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:52:24 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:52:24 --> Pagination Class Initialized
INFO - 2026-01-29 14:52:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:52:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:52:24 --> Model "Log_model" initialized
INFO - 2026-01-29 14:52:24 --> Final output sent to browser
DEBUG - 2026-01-29 14:52:24 --> Total execution time: 0.2720
INFO - 2026-01-29 08:53:42 --> Config Class Initialized
INFO - 2026-01-29 08:53:42 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:53:42 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:53:42 --> Utf8 Class Initialized
INFO - 2026-01-29 08:53:42 --> URI Class Initialized
DEBUG - 2026-01-29 08:53:42 --> No URI present. Default controller set.
INFO - 2026-01-29 08:53:42 --> Router Class Initialized
INFO - 2026-01-29 08:53:42 --> Output Class Initialized
INFO - 2026-01-29 08:53:42 --> Security Class Initialized
DEBUG - 2026-01-29 08:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:53:42 --> CSRF cookie sent
INFO - 2026-01-29 08:53:42 --> Input Class Initialized
INFO - 2026-01-29 08:53:42 --> Language Class Initialized
INFO - 2026-01-29 08:53:42 --> Loader Class Initialized
INFO - 2026-01-29 08:53:42 --> Helper loaded: url_helper
INFO - 2026-01-29 08:53:42 --> Helper loaded: text_helper
INFO - 2026-01-29 08:53:42 --> Helper loaded: string_helper
INFO - 2026-01-29 08:53:42 --> Helper loaded: form_helper
INFO - 2026-01-29 08:53:42 --> Helper loaded: download_helper
INFO - 2026-01-29 08:53:42 --> Helper loaded: security_helper
INFO - 2026-01-29 08:53:42 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:53:42 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:53:42 --> Form Validation Class Initialized
INFO - 2026-01-29 08:53:42 --> Model "User_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:53:42 --> Controller Class Initialized
INFO - 2026-01-29 14:53:42 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Video_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:53:42 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:53:42 --> Pagination Class Initialized
INFO - 2026-01-29 14:53:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:53:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:53:42 --> Model "Log_model" initialized
INFO - 2026-01-29 14:53:42 --> Final output sent to browser
DEBUG - 2026-01-29 14:53:42 --> Total execution time: 0.2794
INFO - 2026-01-29 08:53:44 --> Config Class Initialized
INFO - 2026-01-29 08:53:44 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:53:44 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:53:44 --> Utf8 Class Initialized
INFO - 2026-01-29 08:53:44 --> URI Class Initialized
DEBUG - 2026-01-29 08:53:44 --> No URI present. Default controller set.
INFO - 2026-01-29 08:53:44 --> Router Class Initialized
INFO - 2026-01-29 08:53:44 --> Output Class Initialized
INFO - 2026-01-29 08:53:44 --> Security Class Initialized
DEBUG - 2026-01-29 08:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:53:44 --> CSRF cookie sent
INFO - 2026-01-29 08:53:44 --> Input Class Initialized
INFO - 2026-01-29 08:53:44 --> Language Class Initialized
INFO - 2026-01-29 08:53:44 --> Loader Class Initialized
INFO - 2026-01-29 08:53:44 --> Helper loaded: url_helper
INFO - 2026-01-29 08:53:44 --> Helper loaded: text_helper
INFO - 2026-01-29 08:53:44 --> Helper loaded: string_helper
INFO - 2026-01-29 08:53:44 --> Helper loaded: form_helper
INFO - 2026-01-29 08:53:44 --> Helper loaded: download_helper
INFO - 2026-01-29 08:53:44 --> Helper loaded: security_helper
INFO - 2026-01-29 08:53:44 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:53:44 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:53:44 --> Form Validation Class Initialized
INFO - 2026-01-29 08:53:44 --> Model "User_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:53:44 --> Controller Class Initialized
INFO - 2026-01-29 14:53:44 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Video_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:53:44 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:53:44 --> Pagination Class Initialized
INFO - 2026-01-29 14:53:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 14:53:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 14:53:44 --> Model "Log_model" initialized
INFO - 2026-01-29 14:53:44 --> Final output sent to browser
DEBUG - 2026-01-29 14:53:44 --> Total execution time: 0.2742
INFO - 2026-01-29 08:59:59 --> Config Class Initialized
INFO - 2026-01-29 08:59:59 --> Hooks Class Initialized
DEBUG - 2026-01-29 08:59:59 --> UTF-8 Support Enabled
INFO - 2026-01-29 08:59:59 --> Utf8 Class Initialized
INFO - 2026-01-29 08:59:59 --> URI Class Initialized
DEBUG - 2026-01-29 08:59:59 --> No URI present. Default controller set.
INFO - 2026-01-29 08:59:59 --> Router Class Initialized
INFO - 2026-01-29 08:59:59 --> Output Class Initialized
INFO - 2026-01-29 08:59:59 --> Security Class Initialized
DEBUG - 2026-01-29 08:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 08:59:59 --> CSRF cookie sent
INFO - 2026-01-29 08:59:59 --> Input Class Initialized
INFO - 2026-01-29 08:59:59 --> Language Class Initialized
INFO - 2026-01-29 08:59:59 --> Loader Class Initialized
INFO - 2026-01-29 08:59:59 --> Helper loaded: url_helper
INFO - 2026-01-29 08:59:59 --> Helper loaded: text_helper
INFO - 2026-01-29 08:59:59 --> Helper loaded: string_helper
INFO - 2026-01-29 08:59:59 --> Helper loaded: form_helper
INFO - 2026-01-29 08:59:59 --> Helper loaded: download_helper
INFO - 2026-01-29 08:59:59 --> Helper loaded: security_helper
INFO - 2026-01-29 08:59:59 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 08:59:59 --> Database Driver Class Initialized
DEBUG - 2026-01-29 08:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 08:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 08:59:59 --> Form Validation Class Initialized
INFO - 2026-01-29 08:59:59 --> Model "User_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Nav_model" initialized
INFO - 2026-01-29 14:59:59 --> Controller Class Initialized
INFO - 2026-01-29 14:59:59 --> Model "Berita_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Galeri_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Video_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Agenda_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Tautan_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Mitra_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Prodi_model" initialized
INFO - 2026-01-29 14:59:59 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 14:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 14:59:59 --> Pagination Class Initialized
INFO - 2026-01-29 15:00:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 15:00:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:00:00 --> Model "Log_model" initialized
INFO - 2026-01-29 15:00:00 --> Final output sent to browser
DEBUG - 2026-01-29 15:00:00 --> Total execution time: 0.7956
INFO - 2026-01-29 09:00:08 --> Config Class Initialized
INFO - 2026-01-29 09:00:08 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:00:08 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:00:08 --> Utf8 Class Initialized
INFO - 2026-01-29 09:00:08 --> URI Class Initialized
INFO - 2026-01-29 09:00:08 --> Router Class Initialized
INFO - 2026-01-29 09:00:08 --> Output Class Initialized
INFO - 2026-01-29 09:00:08 --> Security Class Initialized
DEBUG - 2026-01-29 09:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:00:08 --> CSRF cookie sent
INFO - 2026-01-29 09:00:08 --> Input Class Initialized
INFO - 2026-01-29 09:00:08 --> Language Class Initialized
INFO - 2026-01-29 09:00:08 --> Loader Class Initialized
INFO - 2026-01-29 09:00:08 --> Helper loaded: url_helper
INFO - 2026-01-29 09:00:08 --> Helper loaded: text_helper
INFO - 2026-01-29 09:00:08 --> Helper loaded: string_helper
INFO - 2026-01-29 09:00:08 --> Helper loaded: form_helper
INFO - 2026-01-29 09:00:08 --> Helper loaded: download_helper
INFO - 2026-01-29 09:00:08 --> Helper loaded: security_helper
INFO - 2026-01-29 09:00:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:00:08 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:00:08 --> Form Validation Class Initialized
INFO - 2026-01-29 09:00:08 --> Model "User_model" initialized
INFO - 2026-01-29 15:00:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:00:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:00:08 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:00:08 --> Controller Class Initialized
INFO - 2026-01-29 15:00:08 --> Model "Sdm_model" initialized
INFO - 2026-01-29 15:00:08 --> Model "Jabatansdm_model" initialized
INFO - 2026-01-29 15:00:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2026-01-29 15:00:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:00:08 --> Model "Log_model" initialized
INFO - 2026-01-29 15:00:08 --> Final output sent to browser
DEBUG - 2026-01-29 15:00:08 --> Total execution time: 0.3805
INFO - 2026-01-29 09:00:41 --> Config Class Initialized
INFO - 2026-01-29 09:00:41 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:00:41 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:00:41 --> Utf8 Class Initialized
INFO - 2026-01-29 09:00:41 --> URI Class Initialized
INFO - 2026-01-29 09:00:41 --> Router Class Initialized
INFO - 2026-01-29 09:00:41 --> Output Class Initialized
INFO - 2026-01-29 09:00:41 --> Security Class Initialized
DEBUG - 2026-01-29 09:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:00:41 --> CSRF cookie sent
INFO - 2026-01-29 09:00:41 --> Input Class Initialized
INFO - 2026-01-29 09:00:41 --> Language Class Initialized
INFO - 2026-01-29 09:00:41 --> Loader Class Initialized
INFO - 2026-01-29 09:00:41 --> Helper loaded: url_helper
INFO - 2026-01-29 09:00:41 --> Helper loaded: text_helper
INFO - 2026-01-29 09:00:41 --> Helper loaded: string_helper
INFO - 2026-01-29 09:00:41 --> Helper loaded: form_helper
INFO - 2026-01-29 09:00:41 --> Helper loaded: download_helper
INFO - 2026-01-29 09:00:41 --> Helper loaded: security_helper
INFO - 2026-01-29 09:00:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:00:41 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:00:41 --> Form Validation Class Initialized
INFO - 2026-01-29 09:00:41 --> Model "User_model" initialized
INFO - 2026-01-29 15:00:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:00:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:00:41 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:00:41 --> Controller Class Initialized
INFO - 2026-01-29 15:00:41 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:00:41 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:00:41 --> Model "Sdm_model" initialized
INFO - 2026-01-29 15:00:41 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 15:00:41 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-29 15:00:41 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:00:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:00:42 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 15:00:42 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 15:00:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 15:00:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:00:42 --> Model "Log_model" initialized
INFO - 2026-01-29 15:00:42 --> Final output sent to browser
DEBUG - 2026-01-29 15:00:42 --> Total execution time: 1.3839
INFO - 2026-01-29 09:00:51 --> Config Class Initialized
INFO - 2026-01-29 09:00:51 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:00:51 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:00:51 --> Utf8 Class Initialized
INFO - 2026-01-29 09:00:51 --> URI Class Initialized
INFO - 2026-01-29 09:00:51 --> Router Class Initialized
INFO - 2026-01-29 09:00:51 --> Output Class Initialized
INFO - 2026-01-29 09:00:51 --> Security Class Initialized
DEBUG - 2026-01-29 09:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:00:51 --> CSRF cookie sent
INFO - 2026-01-29 09:00:51 --> Input Class Initialized
INFO - 2026-01-29 09:00:51 --> Language Class Initialized
INFO - 2026-01-29 09:00:51 --> Loader Class Initialized
INFO - 2026-01-29 09:00:51 --> Helper loaded: url_helper
INFO - 2026-01-29 09:00:51 --> Helper loaded: text_helper
INFO - 2026-01-29 09:00:51 --> Helper loaded: string_helper
INFO - 2026-01-29 09:00:51 --> Helper loaded: form_helper
INFO - 2026-01-29 09:00:51 --> Helper loaded: download_helper
INFO - 2026-01-29 09:00:51 --> Helper loaded: security_helper
INFO - 2026-01-29 09:00:51 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:00:51 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:00:51 --> Form Validation Class Initialized
INFO - 2026-01-29 09:00:51 --> Model "User_model" initialized
INFO - 2026-01-29 15:00:51 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:00:51 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:00:51 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:00:51 --> Controller Class Initialized
INFO - 2026-01-29 15:00:51 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:00:51 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:00:51 --> Model "Sdm_model" initialized
INFO - 2026-01-29 15:00:51 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 15:00:51 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-29 15:00:51 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:00:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:00:51 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 15:00:51 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 15:00:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 15:00:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:00:51 --> Model "Log_model" initialized
INFO - 2026-01-29 15:00:51 --> Final output sent to browser
DEBUG - 2026-01-29 15:00:51 --> Total execution time: 0.2317
INFO - 2026-01-29 09:03:39 --> Config Class Initialized
INFO - 2026-01-29 09:03:39 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:03:39 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:03:39 --> Utf8 Class Initialized
INFO - 2026-01-29 09:03:39 --> URI Class Initialized
DEBUG - 2026-01-29 09:03:39 --> No URI present. Default controller set.
INFO - 2026-01-29 09:03:39 --> Router Class Initialized
INFO - 2026-01-29 09:03:39 --> Output Class Initialized
INFO - 2026-01-29 09:03:39 --> Security Class Initialized
DEBUG - 2026-01-29 09:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:03:39 --> CSRF cookie sent
INFO - 2026-01-29 09:03:39 --> Input Class Initialized
INFO - 2026-01-29 09:03:39 --> Language Class Initialized
INFO - 2026-01-29 09:03:39 --> Loader Class Initialized
INFO - 2026-01-29 09:03:39 --> Helper loaded: url_helper
INFO - 2026-01-29 09:03:39 --> Helper loaded: text_helper
INFO - 2026-01-29 09:03:39 --> Helper loaded: string_helper
INFO - 2026-01-29 09:03:39 --> Helper loaded: form_helper
INFO - 2026-01-29 09:03:39 --> Helper loaded: download_helper
INFO - 2026-01-29 09:03:39 --> Helper loaded: security_helper
INFO - 2026-01-29 09:03:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:03:39 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:03:39 --> Form Validation Class Initialized
INFO - 2026-01-29 09:03:39 --> Model "User_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:03:39 --> Controller Class Initialized
INFO - 2026-01-29 15:03:39 --> Model "Berita_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Galeri_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Video_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Agenda_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Tautan_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Mitra_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:03:39 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 15:03:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 15:03:39 --> Pagination Class Initialized
INFO - 2026-01-29 15:03:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 15:03:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:03:39 --> Model "Log_model" initialized
INFO - 2026-01-29 15:03:39 --> Final output sent to browser
DEBUG - 2026-01-29 15:03:39 --> Total execution time: 0.2948
INFO - 2026-01-29 09:03:46 --> Config Class Initialized
INFO - 2026-01-29 09:03:46 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:03:46 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:03:46 --> Utf8 Class Initialized
INFO - 2026-01-29 09:03:46 --> URI Class Initialized
INFO - 2026-01-29 09:03:46 --> Router Class Initialized
INFO - 2026-01-29 09:03:46 --> Output Class Initialized
INFO - 2026-01-29 09:03:46 --> Security Class Initialized
DEBUG - 2026-01-29 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:03:46 --> CSRF cookie sent
INFO - 2026-01-29 09:03:46 --> Input Class Initialized
INFO - 2026-01-29 09:03:46 --> Language Class Initialized
INFO - 2026-01-29 09:03:46 --> Loader Class Initialized
INFO - 2026-01-29 09:03:46 --> Helper loaded: url_helper
INFO - 2026-01-29 09:03:46 --> Helper loaded: text_helper
INFO - 2026-01-29 09:03:46 --> Helper loaded: string_helper
INFO - 2026-01-29 09:03:46 --> Helper loaded: form_helper
INFO - 2026-01-29 09:03:46 --> Helper loaded: download_helper
INFO - 2026-01-29 09:03:46 --> Helper loaded: security_helper
INFO - 2026-01-29 09:03:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:03:46 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:03:46 --> Form Validation Class Initialized
INFO - 2026-01-29 09:03:46 --> Model "User_model" initialized
INFO - 2026-01-29 15:03:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:03:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:03:46 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:03:46 --> Controller Class Initialized
INFO - 2026-01-29 15:03:46 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:03:46 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:03:46 --> Model "Sdm_model" initialized
INFO - 2026-01-29 15:03:46 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 15:03:46 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-29 15:03:46 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:03:46 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 15:03:46 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 15:03:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 15:03:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:03:46 --> Model "Log_model" initialized
INFO - 2026-01-29 15:03:46 --> Final output sent to browser
DEBUG - 2026-01-29 15:03:46 --> Total execution time: 0.7673
INFO - 2026-01-29 09:04:37 --> Config Class Initialized
INFO - 2026-01-29 09:04:37 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:04:37 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:04:37 --> Utf8 Class Initialized
INFO - 2026-01-29 09:04:37 --> URI Class Initialized
DEBUG - 2026-01-29 09:04:37 --> No URI present. Default controller set.
INFO - 2026-01-29 09:04:37 --> Router Class Initialized
INFO - 2026-01-29 09:04:37 --> Output Class Initialized
INFO - 2026-01-29 09:04:37 --> Security Class Initialized
DEBUG - 2026-01-29 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:04:37 --> CSRF cookie sent
INFO - 2026-01-29 09:04:37 --> Input Class Initialized
INFO - 2026-01-29 09:04:37 --> Language Class Initialized
INFO - 2026-01-29 09:04:37 --> Loader Class Initialized
INFO - 2026-01-29 09:04:37 --> Helper loaded: url_helper
INFO - 2026-01-29 09:04:37 --> Helper loaded: text_helper
INFO - 2026-01-29 09:04:37 --> Helper loaded: string_helper
INFO - 2026-01-29 09:04:37 --> Helper loaded: form_helper
INFO - 2026-01-29 09:04:37 --> Helper loaded: download_helper
INFO - 2026-01-29 09:04:37 --> Helper loaded: security_helper
INFO - 2026-01-29 09:04:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:04:37 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:04:37 --> Form Validation Class Initialized
INFO - 2026-01-29 09:04:37 --> Model "User_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:04:37 --> Controller Class Initialized
INFO - 2026-01-29 15:04:37 --> Model "Berita_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Galeri_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Video_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Agenda_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Tautan_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Mitra_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:04:37 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 15:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 15:04:37 --> Pagination Class Initialized
INFO - 2026-01-29 15:04:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 15:04:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:04:37 --> Model "Log_model" initialized
INFO - 2026-01-29 15:04:37 --> Final output sent to browser
DEBUG - 2026-01-29 15:04:37 --> Total execution time: 0.3105
INFO - 2026-01-29 09:04:46 --> Config Class Initialized
INFO - 2026-01-29 09:04:46 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:04:46 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:04:46 --> Utf8 Class Initialized
INFO - 2026-01-29 09:04:46 --> URI Class Initialized
INFO - 2026-01-29 09:04:46 --> Router Class Initialized
INFO - 2026-01-29 09:04:46 --> Output Class Initialized
INFO - 2026-01-29 09:04:46 --> Security Class Initialized
DEBUG - 2026-01-29 09:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:04:46 --> CSRF cookie sent
INFO - 2026-01-29 09:04:46 --> Input Class Initialized
INFO - 2026-01-29 09:04:46 --> Language Class Initialized
INFO - 2026-01-29 09:04:46 --> Loader Class Initialized
INFO - 2026-01-29 09:04:46 --> Helper loaded: url_helper
INFO - 2026-01-29 09:04:46 --> Helper loaded: text_helper
INFO - 2026-01-29 09:04:46 --> Helper loaded: string_helper
INFO - 2026-01-29 09:04:46 --> Helper loaded: form_helper
INFO - 2026-01-29 09:04:46 --> Helper loaded: download_helper
INFO - 2026-01-29 09:04:46 --> Helper loaded: security_helper
INFO - 2026-01-29 09:04:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:04:46 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:04:46 --> Form Validation Class Initialized
INFO - 2026-01-29 09:04:46 --> Model "User_model" initialized
INFO - 2026-01-29 15:04:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:04:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:04:46 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:04:46 --> Controller Class Initialized
INFO - 2026-01-29 15:04:46 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:04:46 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:04:46 --> Model "Sdm_model" initialized
INFO - 2026-01-29 15:04:46 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 15:04:46 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-29 15:04:47 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:04:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:04:47 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 15:04:47 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 15:04:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 15:04:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:04:47 --> Model "Log_model" initialized
INFO - 2026-01-29 15:04:47 --> Final output sent to browser
DEBUG - 2026-01-29 15:04:47 --> Total execution time: 0.5260
INFO - 2026-01-29 09:06:54 --> Config Class Initialized
INFO - 2026-01-29 09:06:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:06:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:06:54 --> Utf8 Class Initialized
INFO - 2026-01-29 09:06:54 --> URI Class Initialized
INFO - 2026-01-29 09:06:54 --> Router Class Initialized
INFO - 2026-01-29 09:06:54 --> Output Class Initialized
INFO - 2026-01-29 09:06:54 --> Security Class Initialized
DEBUG - 2026-01-29 09:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:06:54 --> CSRF cookie sent
INFO - 2026-01-29 09:06:54 --> Input Class Initialized
INFO - 2026-01-29 09:06:54 --> Language Class Initialized
INFO - 2026-01-29 09:06:54 --> Loader Class Initialized
INFO - 2026-01-29 09:06:54 --> Helper loaded: url_helper
INFO - 2026-01-29 09:06:54 --> Helper loaded: text_helper
INFO - 2026-01-29 09:06:54 --> Helper loaded: string_helper
INFO - 2026-01-29 09:06:54 --> Helper loaded: form_helper
INFO - 2026-01-29 09:06:54 --> Helper loaded: download_helper
INFO - 2026-01-29 09:06:54 --> Helper loaded: security_helper
INFO - 2026-01-29 09:06:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:06:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:06:54 --> Form Validation Class Initialized
INFO - 2026-01-29 09:06:54 --> Model "User_model" initialized
INFO - 2026-01-29 15:06:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:06:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:06:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:06:54 --> Controller Class Initialized
DEBUG - 2026-01-29 15:06:54 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-29 15:06:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2026-01-29 15:06:54 --> Model "Log_model" initialized
INFO - 2026-01-29 15:06:54 --> Final output sent to browser
DEBUG - 2026-01-29 15:06:54 --> Total execution time: 0.1388
INFO - 2026-01-29 09:07:04 --> Config Class Initialized
INFO - 2026-01-29 09:07:04 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:07:04 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:07:04 --> Utf8 Class Initialized
INFO - 2026-01-29 09:07:04 --> URI Class Initialized
INFO - 2026-01-29 09:07:04 --> Router Class Initialized
INFO - 2026-01-29 09:07:04 --> Output Class Initialized
INFO - 2026-01-29 09:07:04 --> Security Class Initialized
DEBUG - 2026-01-29 09:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:07:04 --> CSRF cookie sent
INFO - 2026-01-29 09:07:04 --> CSRF token verified
INFO - 2026-01-29 09:07:04 --> Input Class Initialized
INFO - 2026-01-29 09:07:04 --> Language Class Initialized
INFO - 2026-01-29 09:07:04 --> Loader Class Initialized
INFO - 2026-01-29 09:07:04 --> Helper loaded: url_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: text_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: string_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: form_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: download_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: security_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:07:04 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:07:04 --> Form Validation Class Initialized
INFO - 2026-01-29 09:07:04 --> Model "User_model" initialized
INFO - 2026-01-29 15:07:04 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:07:04 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:07:04 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:07:04 --> Controller Class Initialized
DEBUG - 2026-01-29 15:07:04 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2026-01-29 15:07:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-01-29 09:07:04 --> Config Class Initialized
INFO - 2026-01-29 09:07:04 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:07:04 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:07:04 --> Utf8 Class Initialized
INFO - 2026-01-29 09:07:04 --> URI Class Initialized
INFO - 2026-01-29 09:07:04 --> Router Class Initialized
INFO - 2026-01-29 09:07:04 --> Output Class Initialized
INFO - 2026-01-29 09:07:04 --> Security Class Initialized
DEBUG - 2026-01-29 09:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:07:04 --> CSRF cookie sent
INFO - 2026-01-29 09:07:04 --> Input Class Initialized
INFO - 2026-01-29 09:07:04 --> Language Class Initialized
INFO - 2026-01-29 09:07:04 --> Loader Class Initialized
INFO - 2026-01-29 09:07:04 --> Helper loaded: url_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: text_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: string_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: form_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: download_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: security_helper
INFO - 2026-01-29 09:07:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:07:04 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:07:04 --> Form Validation Class Initialized
INFO - 2026-01-29 09:07:04 --> Model "User_model" initialized
INFO - 2026-01-29 15:07:04 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:07:04 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:07:04 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:07:04 --> Controller Class Initialized
INFO - 2026-01-29 15:07:04 --> Model "Tautan_model" initialized
INFO - 2026-01-29 15:07:04 --> Model "Staff_model" initialized
INFO - 2026-01-29 15:07:04 --> Model "Dasbor_model" initialized
INFO - 2026-01-29 15:07:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2026-01-29 15:07:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 15:07:04 --> Model "Log_model" initialized
INFO - 2026-01-29 15:07:04 --> Final output sent to browser
DEBUG - 2026-01-29 15:07:04 --> Total execution time: 0.5090
INFO - 2026-01-29 09:07:31 --> Config Class Initialized
INFO - 2026-01-29 09:07:31 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:07:31 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:07:31 --> Utf8 Class Initialized
INFO - 2026-01-29 09:07:31 --> URI Class Initialized
INFO - 2026-01-29 09:07:31 --> Router Class Initialized
INFO - 2026-01-29 09:07:31 --> Output Class Initialized
INFO - 2026-01-29 09:07:31 --> Security Class Initialized
DEBUG - 2026-01-29 09:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:07:31 --> CSRF cookie sent
INFO - 2026-01-29 09:07:31 --> Input Class Initialized
INFO - 2026-01-29 09:07:31 --> Language Class Initialized
INFO - 2026-01-29 09:07:31 --> Loader Class Initialized
INFO - 2026-01-29 09:07:31 --> Helper loaded: url_helper
INFO - 2026-01-29 09:07:31 --> Helper loaded: text_helper
INFO - 2026-01-29 09:07:31 --> Helper loaded: string_helper
INFO - 2026-01-29 09:07:31 --> Helper loaded: form_helper
INFO - 2026-01-29 09:07:31 --> Helper loaded: download_helper
INFO - 2026-01-29 09:07:31 --> Helper loaded: security_helper
INFO - 2026-01-29 09:07:31 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:07:31 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:07:31 --> Form Validation Class Initialized
INFO - 2026-01-29 09:07:31 --> Model "User_model" initialized
INFO - 2026-01-29 15:07:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:07:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:07:31 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:07:31 --> Controller Class Initialized
INFO - 2026-01-29 15:07:31 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:07:31 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:07:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2026-01-29 15:07:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 15:07:31 --> Model "Log_model" initialized
INFO - 2026-01-29 15:07:31 --> Final output sent to browser
DEBUG - 2026-01-29 15:07:31 --> Total execution time: 0.7849
INFO - 2026-01-29 09:07:50 --> Config Class Initialized
INFO - 2026-01-29 09:07:50 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:07:50 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:07:50 --> Utf8 Class Initialized
INFO - 2026-01-29 09:07:50 --> URI Class Initialized
INFO - 2026-01-29 09:07:50 --> Router Class Initialized
INFO - 2026-01-29 09:07:50 --> Output Class Initialized
INFO - 2026-01-29 09:07:50 --> Security Class Initialized
DEBUG - 2026-01-29 09:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:07:50 --> CSRF cookie sent
INFO - 2026-01-29 09:07:50 --> Input Class Initialized
INFO - 2026-01-29 09:07:50 --> Language Class Initialized
INFO - 2026-01-29 09:07:50 --> Loader Class Initialized
INFO - 2026-01-29 09:07:50 --> Helper loaded: url_helper
INFO - 2026-01-29 09:07:50 --> Helper loaded: text_helper
INFO - 2026-01-29 09:07:50 --> Helper loaded: string_helper
INFO - 2026-01-29 09:07:50 --> Helper loaded: form_helper
INFO - 2026-01-29 09:07:50 --> Helper loaded: download_helper
INFO - 2026-01-29 09:07:50 --> Helper loaded: security_helper
INFO - 2026-01-29 09:07:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:07:50 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:07:50 --> Form Validation Class Initialized
INFO - 2026-01-29 09:07:50 --> Model "User_model" initialized
INFO - 2026-01-29 15:07:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:07:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:07:50 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:07:50 --> Controller Class Initialized
INFO - 2026-01-29 15:07:50 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:07:50 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:07:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2026-01-29 15:07:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 15:07:50 --> Model "Log_model" initialized
INFO - 2026-01-29 15:07:50 --> Final output sent to browser
DEBUG - 2026-01-29 15:07:50 --> Total execution time: 0.7930
INFO - 2026-01-29 09:15:18 --> Config Class Initialized
INFO - 2026-01-29 09:15:18 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:15:18 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:15:18 --> Utf8 Class Initialized
INFO - 2026-01-29 09:15:18 --> URI Class Initialized
INFO - 2026-01-29 09:15:18 --> Router Class Initialized
INFO - 2026-01-29 09:15:18 --> Output Class Initialized
INFO - 2026-01-29 09:15:18 --> Security Class Initialized
DEBUG - 2026-01-29 09:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:15:18 --> CSRF cookie sent
INFO - 2026-01-29 09:15:18 --> Input Class Initialized
INFO - 2026-01-29 09:15:18 --> Language Class Initialized
INFO - 2026-01-29 09:15:18 --> Loader Class Initialized
INFO - 2026-01-29 09:15:18 --> Helper loaded: url_helper
INFO - 2026-01-29 09:15:18 --> Helper loaded: text_helper
INFO - 2026-01-29 09:15:18 --> Helper loaded: string_helper
INFO - 2026-01-29 09:15:18 --> Helper loaded: form_helper
INFO - 2026-01-29 09:15:18 --> Helper loaded: download_helper
INFO - 2026-01-29 09:15:18 --> Helper loaded: security_helper
INFO - 2026-01-29 09:15:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:15:18 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:15:18 --> Form Validation Class Initialized
INFO - 2026-01-29 09:15:18 --> Model "User_model" initialized
INFO - 2026-01-29 15:15:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:15:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:15:18 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:15:18 --> Controller Class Initialized
INFO - 2026-01-29 15:15:18 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:15:18 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:15:18 --> Model "Sdm_model" initialized
INFO - 2026-01-29 15:15:18 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 15:15:19 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-29 15:15:19 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:15:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:15:19 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 15:15:19 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 15:15:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 15:15:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:15:19 --> Model "Log_model" initialized
INFO - 2026-01-29 15:15:19 --> Final output sent to browser
DEBUG - 2026-01-29 15:15:19 --> Total execution time: 0.2567
INFO - 2026-01-29 09:15:39 --> Config Class Initialized
INFO - 2026-01-29 09:15:39 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:15:39 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:15:39 --> Utf8 Class Initialized
INFO - 2026-01-29 09:15:39 --> URI Class Initialized
INFO - 2026-01-29 09:15:39 --> Router Class Initialized
INFO - 2026-01-29 09:15:39 --> Output Class Initialized
INFO - 2026-01-29 09:15:39 --> Security Class Initialized
DEBUG - 2026-01-29 09:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:15:39 --> CSRF cookie sent
INFO - 2026-01-29 09:15:39 --> Input Class Initialized
INFO - 2026-01-29 09:15:39 --> Language Class Initialized
INFO - 2026-01-29 09:15:39 --> Loader Class Initialized
INFO - 2026-01-29 09:15:39 --> Helper loaded: url_helper
INFO - 2026-01-29 09:15:39 --> Helper loaded: text_helper
INFO - 2026-01-29 09:15:39 --> Helper loaded: string_helper
INFO - 2026-01-29 09:15:39 --> Helper loaded: form_helper
INFO - 2026-01-29 09:15:39 --> Helper loaded: download_helper
INFO - 2026-01-29 09:15:39 --> Helper loaded: security_helper
INFO - 2026-01-29 09:15:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:15:39 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:15:39 --> Form Validation Class Initialized
INFO - 2026-01-29 09:15:39 --> Model "User_model" initialized
INFO - 2026-01-29 15:15:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:15:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:15:39 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:15:39 --> Controller Class Initialized
INFO - 2026-01-29 15:15:39 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:15:39 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:15:39 --> Model "Sdm_model" initialized
INFO - 2026-01-29 15:15:39 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 15:15:39 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-29 15:15:39 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:15:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:15:39 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 15:15:39 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 15:15:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 15:15:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:15:39 --> Model "Log_model" initialized
INFO - 2026-01-29 15:15:39 --> Final output sent to browser
DEBUG - 2026-01-29 15:15:39 --> Total execution time: 0.2957
INFO - 2026-01-29 09:18:41 --> Config Class Initialized
INFO - 2026-01-29 09:18:41 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:18:41 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:18:41 --> Utf8 Class Initialized
INFO - 2026-01-29 09:18:41 --> URI Class Initialized
INFO - 2026-01-29 09:18:41 --> Router Class Initialized
INFO - 2026-01-29 09:18:41 --> Output Class Initialized
INFO - 2026-01-29 09:18:41 --> Security Class Initialized
DEBUG - 2026-01-29 09:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:18:41 --> CSRF cookie sent
INFO - 2026-01-29 09:18:41 --> Input Class Initialized
INFO - 2026-01-29 09:18:41 --> Language Class Initialized
INFO - 2026-01-29 09:18:41 --> Loader Class Initialized
INFO - 2026-01-29 09:18:41 --> Helper loaded: url_helper
INFO - 2026-01-29 09:18:41 --> Helper loaded: text_helper
INFO - 2026-01-29 09:18:41 --> Helper loaded: string_helper
INFO - 2026-01-29 09:18:41 --> Helper loaded: form_helper
INFO - 2026-01-29 09:18:41 --> Helper loaded: download_helper
INFO - 2026-01-29 09:18:41 --> Helper loaded: security_helper
INFO - 2026-01-29 09:18:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:18:41 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:18:41 --> Form Validation Class Initialized
INFO - 2026-01-29 09:18:41 --> Model "User_model" initialized
INFO - 2026-01-29 15:18:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:18:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:18:41 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:18:41 --> Controller Class Initialized
INFO - 2026-01-29 15:18:41 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:18:41 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:18:41 --> Model "Sdm_model" initialized
INFO - 2026-01-29 15:18:41 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 15:18:41 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 5
ERROR - 2026-01-29 15:18:41 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:18:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 15:18:41 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 15:18:41 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 15:18:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 15:18:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:18:41 --> Model "Log_model" initialized
INFO - 2026-01-29 15:18:41 --> Final output sent to browser
DEBUG - 2026-01-29 15:18:41 --> Total execution time: 0.3301
INFO - 2026-01-29 09:19:35 --> Config Class Initialized
INFO - 2026-01-29 09:19:35 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:19:35 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:19:35 --> Utf8 Class Initialized
INFO - 2026-01-29 09:19:35 --> URI Class Initialized
DEBUG - 2026-01-29 09:19:35 --> No URI present. Default controller set.
INFO - 2026-01-29 09:19:35 --> Router Class Initialized
INFO - 2026-01-29 09:19:35 --> Output Class Initialized
INFO - 2026-01-29 09:19:35 --> Security Class Initialized
DEBUG - 2026-01-29 09:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:19:35 --> CSRF cookie sent
INFO - 2026-01-29 09:19:35 --> Input Class Initialized
INFO - 2026-01-29 09:19:35 --> Language Class Initialized
INFO - 2026-01-29 09:19:35 --> Loader Class Initialized
INFO - 2026-01-29 09:19:35 --> Helper loaded: url_helper
INFO - 2026-01-29 09:19:35 --> Helper loaded: text_helper
INFO - 2026-01-29 09:19:35 --> Helper loaded: string_helper
INFO - 2026-01-29 09:19:35 --> Helper loaded: form_helper
INFO - 2026-01-29 09:19:35 --> Helper loaded: download_helper
INFO - 2026-01-29 09:19:35 --> Helper loaded: security_helper
INFO - 2026-01-29 09:19:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:19:35 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:19:35 --> Form Validation Class Initialized
INFO - 2026-01-29 09:19:35 --> Model "User_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:19:35 --> Controller Class Initialized
INFO - 2026-01-29 15:19:35 --> Model "Berita_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Galeri_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Video_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Agenda_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Tautan_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Mitra_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:19:35 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 15:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 15:19:35 --> Pagination Class Initialized
INFO - 2026-01-29 15:19:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 15:19:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:19:35 --> Model "Log_model" initialized
INFO - 2026-01-29 15:19:35 --> Final output sent to browser
DEBUG - 2026-01-29 15:19:35 --> Total execution time: 0.2354
INFO - 2026-01-29 09:20:11 --> Config Class Initialized
INFO - 2026-01-29 09:20:11 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:20:11 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:20:11 --> Utf8 Class Initialized
INFO - 2026-01-29 09:20:11 --> URI Class Initialized
DEBUG - 2026-01-29 09:20:11 --> No URI present. Default controller set.
INFO - 2026-01-29 09:20:11 --> Router Class Initialized
INFO - 2026-01-29 09:20:11 --> Output Class Initialized
INFO - 2026-01-29 09:20:11 --> Security Class Initialized
DEBUG - 2026-01-29 09:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:20:11 --> CSRF cookie sent
INFO - 2026-01-29 09:20:11 --> Input Class Initialized
INFO - 2026-01-29 09:20:11 --> Language Class Initialized
INFO - 2026-01-29 09:20:11 --> Loader Class Initialized
INFO - 2026-01-29 09:20:11 --> Helper loaded: url_helper
INFO - 2026-01-29 09:20:11 --> Helper loaded: text_helper
INFO - 2026-01-29 09:20:11 --> Helper loaded: string_helper
INFO - 2026-01-29 09:20:11 --> Helper loaded: form_helper
INFO - 2026-01-29 09:20:11 --> Helper loaded: download_helper
INFO - 2026-01-29 09:20:11 --> Helper loaded: security_helper
INFO - 2026-01-29 09:20:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:20:11 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:20:11 --> Form Validation Class Initialized
INFO - 2026-01-29 09:20:11 --> Model "User_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:20:11 --> Controller Class Initialized
INFO - 2026-01-29 15:20:11 --> Model "Berita_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Galeri_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Video_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Agenda_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Tautan_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Mitra_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:20:11 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 15:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 15:20:11 --> Pagination Class Initialized
INFO - 2026-01-29 15:20:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 15:20:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:20:11 --> Model "Log_model" initialized
INFO - 2026-01-29 15:20:11 --> Final output sent to browser
DEBUG - 2026-01-29 15:20:11 --> Total execution time: 0.4337
INFO - 2026-01-29 09:22:43 --> Config Class Initialized
INFO - 2026-01-29 09:22:43 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:22:43 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:22:43 --> Utf8 Class Initialized
INFO - 2026-01-29 09:22:43 --> URI Class Initialized
INFO - 2026-01-29 09:22:43 --> Router Class Initialized
INFO - 2026-01-29 09:22:43 --> Output Class Initialized
INFO - 2026-01-29 09:22:43 --> Security Class Initialized
DEBUG - 2026-01-29 09:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:22:43 --> CSRF cookie sent
INFO - 2026-01-29 09:22:43 --> Input Class Initialized
INFO - 2026-01-29 09:22:43 --> Language Class Initialized
INFO - 2026-01-29 09:22:43 --> Loader Class Initialized
INFO - 2026-01-29 09:22:43 --> Helper loaded: url_helper
INFO - 2026-01-29 09:22:43 --> Helper loaded: text_helper
INFO - 2026-01-29 09:22:43 --> Helper loaded: string_helper
INFO - 2026-01-29 09:22:43 --> Helper loaded: form_helper
INFO - 2026-01-29 09:22:43 --> Helper loaded: download_helper
INFO - 2026-01-29 09:22:43 --> Helper loaded: security_helper
INFO - 2026-01-29 09:22:43 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:22:43 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:22:43 --> Form Validation Class Initialized
INFO - 2026-01-29 09:22:43 --> Model "User_model" initialized
INFO - 2026-01-29 15:22:43 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:22:43 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:22:43 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:22:43 --> Controller Class Initialized
INFO - 2026-01-29 15:22:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/konfigurasi/list.php
INFO - 2026-01-29 15:22:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2026-01-29 15:22:43 --> Model "Log_model" initialized
INFO - 2026-01-29 15:22:43 --> Final output sent to browser
DEBUG - 2026-01-29 15:22:43 --> Total execution time: 0.1407
INFO - 2026-01-29 09:23:28 --> Config Class Initialized
INFO - 2026-01-29 09:23:28 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:23:28 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:23:28 --> Utf8 Class Initialized
INFO - 2026-01-29 09:23:28 --> URI Class Initialized
DEBUG - 2026-01-29 09:23:28 --> No URI present. Default controller set.
INFO - 2026-01-29 09:23:28 --> Router Class Initialized
INFO - 2026-01-29 09:23:28 --> Output Class Initialized
INFO - 2026-01-29 09:23:28 --> Security Class Initialized
DEBUG - 2026-01-29 09:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:23:28 --> CSRF cookie sent
INFO - 2026-01-29 09:23:28 --> Input Class Initialized
INFO - 2026-01-29 09:23:28 --> Language Class Initialized
INFO - 2026-01-29 09:23:28 --> Loader Class Initialized
INFO - 2026-01-29 09:23:28 --> Helper loaded: url_helper
INFO - 2026-01-29 09:23:28 --> Helper loaded: text_helper
INFO - 2026-01-29 09:23:28 --> Helper loaded: string_helper
INFO - 2026-01-29 09:23:28 --> Helper loaded: form_helper
INFO - 2026-01-29 09:23:28 --> Helper loaded: download_helper
INFO - 2026-01-29 09:23:28 --> Helper loaded: security_helper
INFO - 2026-01-29 09:23:28 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:23:28 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:23:28 --> Form Validation Class Initialized
INFO - 2026-01-29 09:23:28 --> Model "User_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:23:28 --> Controller Class Initialized
INFO - 2026-01-29 15:23:28 --> Model "Berita_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Galeri_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Video_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Agenda_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Tautan_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Mitra_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:23:28 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 15:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 15:23:28 --> Pagination Class Initialized
INFO - 2026-01-29 15:23:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 15:23:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:23:28 --> Model "Log_model" initialized
INFO - 2026-01-29 15:23:28 --> Final output sent to browser
DEBUG - 2026-01-29 15:23:28 --> Total execution time: 0.2287
INFO - 2026-01-29 09:25:46 --> Config Class Initialized
INFO - 2026-01-29 09:25:46 --> Hooks Class Initialized
DEBUG - 2026-01-29 09:25:46 --> UTF-8 Support Enabled
INFO - 2026-01-29 09:25:46 --> Utf8 Class Initialized
INFO - 2026-01-29 09:25:46 --> URI Class Initialized
DEBUG - 2026-01-29 09:25:46 --> No URI present. Default controller set.
INFO - 2026-01-29 09:25:46 --> Router Class Initialized
INFO - 2026-01-29 09:25:46 --> Output Class Initialized
INFO - 2026-01-29 09:25:46 --> Security Class Initialized
DEBUG - 2026-01-29 09:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 09:25:46 --> CSRF cookie sent
INFO - 2026-01-29 09:25:46 --> Input Class Initialized
INFO - 2026-01-29 09:25:46 --> Language Class Initialized
INFO - 2026-01-29 09:25:46 --> Loader Class Initialized
INFO - 2026-01-29 09:25:46 --> Helper loaded: url_helper
INFO - 2026-01-29 09:25:46 --> Helper loaded: text_helper
INFO - 2026-01-29 09:25:46 --> Helper loaded: string_helper
INFO - 2026-01-29 09:25:46 --> Helper loaded: form_helper
INFO - 2026-01-29 09:25:46 --> Helper loaded: download_helper
INFO - 2026-01-29 09:25:46 --> Helper loaded: security_helper
INFO - 2026-01-29 09:25:46 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 09:25:46 --> Database Driver Class Initialized
DEBUG - 2026-01-29 09:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 09:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 09:25:46 --> Form Validation Class Initialized
INFO - 2026-01-29 09:25:46 --> Model "User_model" initialized
INFO - 2026-01-29 15:25:46 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 15:25:46 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 15:25:46 --> Model "Nav_model" initialized
INFO - 2026-01-29 15:25:46 --> Controller Class Initialized
INFO - 2026-01-29 15:25:46 --> Model "Berita_model" initialized
INFO - 2026-01-29 15:25:46 --> Model "Galeri_model" initialized
INFO - 2026-01-29 15:25:46 --> Model "Video_model" initialized
INFO - 2026-01-29 15:25:46 --> Model "Agenda_model" initialized
INFO - 2026-01-29 15:25:46 --> Model "Tautan_model" initialized
INFO - 2026-01-29 15:25:46 --> Model "Mitra_model" initialized
INFO - 2026-01-29 15:25:47 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 15:25:47 --> Model "Prodi_model" initialized
INFO - 2026-01-29 15:25:47 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 15:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 15:25:47 --> Pagination Class Initialized
INFO - 2026-01-29 15:25:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 15:25:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 15:25:47 --> Model "Log_model" initialized
INFO - 2026-01-29 15:25:47 --> Final output sent to browser
DEBUG - 2026-01-29 15:25:47 --> Total execution time: 0.6954
