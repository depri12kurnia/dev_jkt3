<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-12-16 04:41:02 --> Config Class Initialized
INFO - 2025-12-16 04:41:02 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:41:03 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:41:03 --> Utf8 Class Initialized
INFO - 2025-12-16 04:41:03 --> URI Class Initialized
DEBUG - 2025-12-16 04:41:03 --> No URI present. Default controller set.
INFO - 2025-12-16 04:41:03 --> Router Class Initialized
INFO - 2025-12-16 04:41:03 --> Output Class Initialized
INFO - 2025-12-16 04:41:03 --> Security Class Initialized
DEBUG - 2025-12-16 04:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:41:03 --> CSRF cookie sent
INFO - 2025-12-16 04:41:03 --> Input Class Initialized
INFO - 2025-12-16 04:41:03 --> Language Class Initialized
INFO - 2025-12-16 04:41:04 --> Loader Class Initialized
INFO - 2025-12-16 04:41:04 --> Helper loaded: url_helper
INFO - 2025-12-16 04:41:04 --> Helper loaded: text_helper
INFO - 2025-12-16 04:41:04 --> Helper loaded: string_helper
INFO - 2025-12-16 04:41:04 --> Helper loaded: form_helper
INFO - 2025-12-16 04:41:04 --> Helper loaded: download_helper
INFO - 2025-12-16 04:41:04 --> Helper loaded: security_helper
INFO - 2025-12-16 04:41:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:41:04 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:41:05 --> Form Validation Class Initialized
INFO - 2025-12-16 04:41:05 --> Model "User_model" initialized
INFO - 2025-12-16 10:41:05 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:41:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:41:06 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:41:06 --> Controller Class Initialized
INFO - 2025-12-16 10:41:06 --> Model "Berita_model" initialized
INFO - 2025-12-16 10:41:06 --> Model "Galeri_model" initialized
INFO - 2025-12-16 10:41:06 --> Model "Video_model" initialized
INFO - 2025-12-16 10:41:06 --> Model "Agenda_model" initialized
INFO - 2025-12-16 10:41:06 --> Model "Tautan_model" initialized
INFO - 2025-12-16 10:41:06 --> Model "Mitra_model" initialized
INFO - 2025-12-16 10:41:07 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 10:41:07 --> Model "Prodi_model" initialized
INFO - 2025-12-16 10:41:07 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 10:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 10:41:07 --> Pagination Class Initialized
INFO - 2025-12-16 10:41:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 10:41:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 10:41:12 --> Model "Log_model" initialized
INFO - 2025-12-16 10:41:12 --> Final output sent to browser
DEBUG - 2025-12-16 10:41:12 --> Total execution time: 9.5819
INFO - 2025-12-16 04:41:38 --> Config Class Initialized
INFO - 2025-12-16 04:41:38 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:41:38 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:41:38 --> Utf8 Class Initialized
INFO - 2025-12-16 04:41:38 --> URI Class Initialized
INFO - 2025-12-16 04:41:38 --> Router Class Initialized
INFO - 2025-12-16 04:41:38 --> Output Class Initialized
INFO - 2025-12-16 04:41:38 --> Security Class Initialized
DEBUG - 2025-12-16 04:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:41:38 --> CSRF cookie sent
INFO - 2025-12-16 04:41:38 --> Input Class Initialized
INFO - 2025-12-16 04:41:38 --> Language Class Initialized
INFO - 2025-12-16 04:41:38 --> Loader Class Initialized
INFO - 2025-12-16 04:41:38 --> Helper loaded: url_helper
INFO - 2025-12-16 04:41:38 --> Helper loaded: text_helper
INFO - 2025-12-16 04:41:38 --> Helper loaded: string_helper
INFO - 2025-12-16 04:41:38 --> Helper loaded: form_helper
INFO - 2025-12-16 04:41:38 --> Helper loaded: download_helper
INFO - 2025-12-16 04:41:38 --> Helper loaded: security_helper
INFO - 2025-12-16 04:41:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:41:38 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:41:38 --> Form Validation Class Initialized
INFO - 2025-12-16 04:41:38 --> Model "User_model" initialized
INFO - 2025-12-16 10:41:38 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:41:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:41:38 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:41:38 --> Controller Class Initialized
DEBUG - 2025-12-16 10:41:38 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:41:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-12-16 10:41:39 --> Model "Log_model" initialized
INFO - 2025-12-16 10:41:39 --> Final output sent to browser
DEBUG - 2025-12-16 10:41:39 --> Total execution time: 0.7688
INFO - 2025-12-16 04:41:50 --> Config Class Initialized
INFO - 2025-12-16 04:41:50 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:41:50 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:41:50 --> Utf8 Class Initialized
INFO - 2025-12-16 04:41:50 --> URI Class Initialized
INFO - 2025-12-16 04:41:50 --> Router Class Initialized
INFO - 2025-12-16 04:41:50 --> Output Class Initialized
INFO - 2025-12-16 04:41:50 --> Security Class Initialized
DEBUG - 2025-12-16 04:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:41:50 --> CSRF cookie sent
INFO - 2025-12-16 04:41:50 --> CSRF token verified
INFO - 2025-12-16 04:41:50 --> Input Class Initialized
INFO - 2025-12-16 04:41:50 --> Language Class Initialized
INFO - 2025-12-16 04:41:50 --> Loader Class Initialized
INFO - 2025-12-16 04:41:50 --> Helper loaded: url_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: text_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: string_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: form_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: download_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: security_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:41:50 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:41:50 --> Form Validation Class Initialized
INFO - 2025-12-16 04:41:50 --> Model "User_model" initialized
INFO - 2025-12-16 10:41:50 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:41:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:41:50 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:41:50 --> Controller Class Initialized
DEBUG - 2025-12-16 10:41:50 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:41:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-16 04:41:50 --> Config Class Initialized
INFO - 2025-12-16 04:41:50 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:41:50 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:41:50 --> Utf8 Class Initialized
INFO - 2025-12-16 04:41:50 --> URI Class Initialized
INFO - 2025-12-16 04:41:50 --> Router Class Initialized
INFO - 2025-12-16 04:41:50 --> Output Class Initialized
INFO - 2025-12-16 04:41:50 --> Security Class Initialized
DEBUG - 2025-12-16 04:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:41:50 --> CSRF cookie sent
INFO - 2025-12-16 04:41:50 --> Input Class Initialized
INFO - 2025-12-16 04:41:50 --> Language Class Initialized
INFO - 2025-12-16 04:41:50 --> Loader Class Initialized
INFO - 2025-12-16 04:41:50 --> Helper loaded: url_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: text_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: string_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: form_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: download_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: security_helper
INFO - 2025-12-16 04:41:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:41:50 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:41:50 --> Form Validation Class Initialized
INFO - 2025-12-16 04:41:50 --> Model "User_model" initialized
INFO - 2025-12-16 10:41:50 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:41:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:41:50 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:41:50 --> Controller Class Initialized
DEBUG - 2025-12-16 10:41:50 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:41:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-12-16 10:41:50 --> Model "Log_model" initialized
INFO - 2025-12-16 10:41:50 --> Final output sent to browser
DEBUG - 2025-12-16 10:41:50 --> Total execution time: 0.1049
INFO - 2025-12-16 04:42:03 --> Config Class Initialized
INFO - 2025-12-16 04:42:03 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:42:03 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:42:03 --> Utf8 Class Initialized
INFO - 2025-12-16 04:42:03 --> URI Class Initialized
INFO - 2025-12-16 04:42:03 --> Router Class Initialized
INFO - 2025-12-16 04:42:03 --> Output Class Initialized
INFO - 2025-12-16 04:42:03 --> Security Class Initialized
DEBUG - 2025-12-16 04:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:42:03 --> CSRF cookie sent
INFO - 2025-12-16 04:42:03 --> CSRF token verified
INFO - 2025-12-16 04:42:03 --> Input Class Initialized
INFO - 2025-12-16 04:42:03 --> Language Class Initialized
INFO - 2025-12-16 04:42:03 --> Loader Class Initialized
INFO - 2025-12-16 04:42:03 --> Helper loaded: url_helper
INFO - 2025-12-16 04:42:03 --> Helper loaded: text_helper
INFO - 2025-12-16 04:42:03 --> Helper loaded: string_helper
INFO - 2025-12-16 04:42:03 --> Helper loaded: form_helper
INFO - 2025-12-16 04:42:03 --> Helper loaded: download_helper
INFO - 2025-12-16 04:42:03 --> Helper loaded: security_helper
INFO - 2025-12-16 04:42:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:42:03 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:42:03 --> Form Validation Class Initialized
INFO - 2025-12-16 04:42:03 --> Model "User_model" initialized
INFO - 2025-12-16 10:42:03 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:42:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:42:03 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:42:03 --> Controller Class Initialized
DEBUG - 2025-12-16 10:42:03 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:42:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-16 04:42:03 --> Config Class Initialized
INFO - 2025-12-16 04:42:03 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:42:03 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:42:03 --> Utf8 Class Initialized
INFO - 2025-12-16 04:42:03 --> URI Class Initialized
INFO - 2025-12-16 04:42:03 --> Router Class Initialized
INFO - 2025-12-16 04:42:03 --> Output Class Initialized
INFO - 2025-12-16 04:42:03 --> Security Class Initialized
DEBUG - 2025-12-16 04:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:42:03 --> CSRF cookie sent
INFO - 2025-12-16 04:42:03 --> Input Class Initialized
INFO - 2025-12-16 04:42:04 --> Language Class Initialized
INFO - 2025-12-16 04:42:04 --> Loader Class Initialized
INFO - 2025-12-16 04:42:04 --> Helper loaded: url_helper
INFO - 2025-12-16 04:42:04 --> Helper loaded: text_helper
INFO - 2025-12-16 04:42:04 --> Helper loaded: string_helper
INFO - 2025-12-16 04:42:04 --> Helper loaded: form_helper
INFO - 2025-12-16 04:42:04 --> Helper loaded: download_helper
INFO - 2025-12-16 04:42:04 --> Helper loaded: security_helper
INFO - 2025-12-16 04:42:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:42:04 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:42:04 --> Form Validation Class Initialized
INFO - 2025-12-16 04:42:04 --> Model "User_model" initialized
INFO - 2025-12-16 10:42:04 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:42:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:42:04 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:42:04 --> Controller Class Initialized
DEBUG - 2025-12-16 10:42:04 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:42:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-12-16 10:42:04 --> Model "Log_model" initialized
INFO - 2025-12-16 10:42:04 --> Final output sent to browser
DEBUG - 2025-12-16 10:42:04 --> Total execution time: 0.1792
INFO - 2025-12-16 04:42:11 --> Config Class Initialized
INFO - 2025-12-16 04:42:11 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:42:11 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:42:11 --> Utf8 Class Initialized
INFO - 2025-12-16 04:42:11 --> URI Class Initialized
INFO - 2025-12-16 04:42:11 --> Router Class Initialized
INFO - 2025-12-16 04:42:11 --> Output Class Initialized
INFO - 2025-12-16 04:42:11 --> Security Class Initialized
DEBUG - 2025-12-16 04:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:42:11 --> CSRF cookie sent
INFO - 2025-12-16 04:42:11 --> CSRF token verified
INFO - 2025-12-16 04:42:11 --> Input Class Initialized
INFO - 2025-12-16 04:42:11 --> Language Class Initialized
INFO - 2025-12-16 04:42:11 --> Loader Class Initialized
INFO - 2025-12-16 04:42:11 --> Helper loaded: url_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: text_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: string_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: form_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: download_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: security_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:42:11 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:42:11 --> Form Validation Class Initialized
INFO - 2025-12-16 04:42:11 --> Model "User_model" initialized
INFO - 2025-12-16 10:42:11 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:42:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:42:11 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:42:11 --> Controller Class Initialized
DEBUG - 2025-12-16 10:42:11 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:42:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-16 04:42:11 --> Config Class Initialized
INFO - 2025-12-16 04:42:11 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:42:11 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:42:11 --> Utf8 Class Initialized
INFO - 2025-12-16 04:42:11 --> URI Class Initialized
INFO - 2025-12-16 04:42:11 --> Router Class Initialized
INFO - 2025-12-16 04:42:11 --> Output Class Initialized
INFO - 2025-12-16 04:42:11 --> Security Class Initialized
DEBUG - 2025-12-16 04:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:42:11 --> CSRF cookie sent
INFO - 2025-12-16 04:42:11 --> Input Class Initialized
INFO - 2025-12-16 04:42:11 --> Language Class Initialized
INFO - 2025-12-16 04:42:11 --> Loader Class Initialized
INFO - 2025-12-16 04:42:11 --> Helper loaded: url_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: text_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: string_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: form_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: download_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: security_helper
INFO - 2025-12-16 04:42:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:42:11 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:42:11 --> Form Validation Class Initialized
INFO - 2025-12-16 04:42:11 --> Model "User_model" initialized
INFO - 2025-12-16 10:42:11 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:42:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:42:11 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:42:11 --> Controller Class Initialized
DEBUG - 2025-12-16 10:42:11 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:42:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-12-16 10:42:11 --> Model "Log_model" initialized
INFO - 2025-12-16 10:42:11 --> Final output sent to browser
DEBUG - 2025-12-16 10:42:11 --> Total execution time: 0.1089
INFO - 2025-12-16 04:42:22 --> Config Class Initialized
INFO - 2025-12-16 04:42:22 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:42:22 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:42:22 --> Utf8 Class Initialized
INFO - 2025-12-16 04:42:22 --> URI Class Initialized
INFO - 2025-12-16 04:42:22 --> Router Class Initialized
INFO - 2025-12-16 04:42:22 --> Output Class Initialized
INFO - 2025-12-16 04:42:22 --> Security Class Initialized
DEBUG - 2025-12-16 04:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:42:22 --> CSRF cookie sent
INFO - 2025-12-16 04:42:22 --> CSRF token verified
INFO - 2025-12-16 04:42:22 --> Input Class Initialized
INFO - 2025-12-16 04:42:22 --> Language Class Initialized
INFO - 2025-12-16 04:42:22 --> Loader Class Initialized
INFO - 2025-12-16 04:42:22 --> Helper loaded: url_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: text_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: string_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: form_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: download_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: security_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:42:22 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:42:22 --> Form Validation Class Initialized
INFO - 2025-12-16 04:42:22 --> Model "User_model" initialized
INFO - 2025-12-16 10:42:22 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:42:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:42:22 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:42:22 --> Controller Class Initialized
DEBUG - 2025-12-16 10:42:22 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:42:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-16 04:42:22 --> Config Class Initialized
INFO - 2025-12-16 04:42:22 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:42:22 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:42:22 --> Utf8 Class Initialized
INFO - 2025-12-16 04:42:22 --> URI Class Initialized
INFO - 2025-12-16 04:42:22 --> Router Class Initialized
INFO - 2025-12-16 04:42:22 --> Output Class Initialized
INFO - 2025-12-16 04:42:22 --> Security Class Initialized
DEBUG - 2025-12-16 04:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:42:22 --> CSRF cookie sent
INFO - 2025-12-16 04:42:22 --> Input Class Initialized
INFO - 2025-12-16 04:42:22 --> Language Class Initialized
INFO - 2025-12-16 04:42:22 --> Loader Class Initialized
INFO - 2025-12-16 04:42:22 --> Helper loaded: url_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: text_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: string_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: form_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: download_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: security_helper
INFO - 2025-12-16 04:42:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:42:22 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:42:22 --> Form Validation Class Initialized
INFO - 2025-12-16 04:42:22 --> Model "User_model" initialized
INFO - 2025-12-16 10:42:22 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:42:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:42:22 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:42:22 --> Controller Class Initialized
DEBUG - 2025-12-16 10:42:22 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:42:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-12-16 10:42:22 --> Model "Log_model" initialized
INFO - 2025-12-16 10:42:22 --> Final output sent to browser
DEBUG - 2025-12-16 10:42:22 --> Total execution time: 0.0947
INFO - 2025-12-16 04:42:30 --> Config Class Initialized
INFO - 2025-12-16 04:42:30 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:42:30 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:42:30 --> Utf8 Class Initialized
INFO - 2025-12-16 04:42:30 --> URI Class Initialized
INFO - 2025-12-16 04:42:30 --> Router Class Initialized
INFO - 2025-12-16 04:42:30 --> Output Class Initialized
INFO - 2025-12-16 04:42:30 --> Security Class Initialized
DEBUG - 2025-12-16 04:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:42:30 --> CSRF cookie sent
INFO - 2025-12-16 04:42:30 --> CSRF token verified
INFO - 2025-12-16 04:42:30 --> Input Class Initialized
INFO - 2025-12-16 04:42:30 --> Language Class Initialized
INFO - 2025-12-16 04:42:30 --> Loader Class Initialized
INFO - 2025-12-16 04:42:30 --> Helper loaded: url_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: text_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: string_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: form_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: download_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: security_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:42:30 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:42:30 --> Form Validation Class Initialized
INFO - 2025-12-16 04:42:30 --> Model "User_model" initialized
INFO - 2025-12-16 10:42:30 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:42:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:42:30 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:42:30 --> Controller Class Initialized
DEBUG - 2025-12-16 10:42:30 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:42:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-16 04:42:30 --> Config Class Initialized
INFO - 2025-12-16 04:42:30 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:42:30 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:42:30 --> Utf8 Class Initialized
INFO - 2025-12-16 04:42:30 --> URI Class Initialized
INFO - 2025-12-16 04:42:30 --> Router Class Initialized
INFO - 2025-12-16 04:42:30 --> Output Class Initialized
INFO - 2025-12-16 04:42:30 --> Security Class Initialized
DEBUG - 2025-12-16 04:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:42:30 --> CSRF cookie sent
INFO - 2025-12-16 04:42:30 --> Input Class Initialized
INFO - 2025-12-16 04:42:30 --> Language Class Initialized
INFO - 2025-12-16 04:42:30 --> Loader Class Initialized
INFO - 2025-12-16 04:42:30 --> Helper loaded: url_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: text_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: string_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: form_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: download_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: security_helper
INFO - 2025-12-16 04:42:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:42:30 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:42:30 --> Form Validation Class Initialized
INFO - 2025-12-16 04:42:30 --> Model "User_model" initialized
INFO - 2025-12-16 10:42:30 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:42:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:42:30 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:42:30 --> Controller Class Initialized
DEBUG - 2025-12-16 10:42:30 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:42:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-12-16 10:42:30 --> Model "Log_model" initialized
INFO - 2025-12-16 10:42:30 --> Final output sent to browser
DEBUG - 2025-12-16 10:42:30 --> Total execution time: 0.0977
INFO - 2025-12-16 04:42:38 --> Config Class Initialized
INFO - 2025-12-16 04:42:38 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:42:38 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:42:38 --> Utf8 Class Initialized
INFO - 2025-12-16 04:42:38 --> URI Class Initialized
INFO - 2025-12-16 04:42:38 --> Router Class Initialized
INFO - 2025-12-16 04:42:38 --> Output Class Initialized
INFO - 2025-12-16 04:42:38 --> Security Class Initialized
DEBUG - 2025-12-16 04:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:42:38 --> CSRF cookie sent
INFO - 2025-12-16 04:42:38 --> CSRF token verified
INFO - 2025-12-16 04:42:38 --> Input Class Initialized
INFO - 2025-12-16 04:42:38 --> Language Class Initialized
INFO - 2025-12-16 04:42:38 --> Loader Class Initialized
INFO - 2025-12-16 04:42:38 --> Helper loaded: url_helper
INFO - 2025-12-16 04:42:38 --> Helper loaded: text_helper
INFO - 2025-12-16 04:42:38 --> Helper loaded: string_helper
INFO - 2025-12-16 04:42:38 --> Helper loaded: form_helper
INFO - 2025-12-16 04:42:38 --> Helper loaded: download_helper
INFO - 2025-12-16 04:42:38 --> Helper loaded: security_helper
INFO - 2025-12-16 04:42:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:42:39 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:42:39 --> Form Validation Class Initialized
INFO - 2025-12-16 04:42:39 --> Model "User_model" initialized
INFO - 2025-12-16 10:42:39 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:42:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:42:39 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:42:39 --> Controller Class Initialized
DEBUG - 2025-12-16 10:42:39 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-12-16 10:42:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-16 04:42:39 --> Config Class Initialized
INFO - 2025-12-16 04:42:39 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:42:39 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:42:39 --> Utf8 Class Initialized
INFO - 2025-12-16 04:42:39 --> URI Class Initialized
INFO - 2025-12-16 04:42:39 --> Router Class Initialized
INFO - 2025-12-16 04:42:39 --> Output Class Initialized
INFO - 2025-12-16 04:42:39 --> Security Class Initialized
DEBUG - 2025-12-16 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:42:39 --> CSRF cookie sent
INFO - 2025-12-16 04:42:39 --> Input Class Initialized
INFO - 2025-12-16 04:42:39 --> Language Class Initialized
INFO - 2025-12-16 04:42:39 --> Loader Class Initialized
INFO - 2025-12-16 04:42:39 --> Helper loaded: url_helper
INFO - 2025-12-16 04:42:39 --> Helper loaded: text_helper
INFO - 2025-12-16 04:42:39 --> Helper loaded: string_helper
INFO - 2025-12-16 04:42:39 --> Helper loaded: form_helper
INFO - 2025-12-16 04:42:39 --> Helper loaded: download_helper
INFO - 2025-12-16 04:42:39 --> Helper loaded: security_helper
INFO - 2025-12-16 04:42:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:42:39 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:42:39 --> Form Validation Class Initialized
INFO - 2025-12-16 04:42:39 --> Model "User_model" initialized
INFO - 2025-12-16 10:42:39 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:42:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:42:39 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:42:39 --> Controller Class Initialized
INFO - 2025-12-16 10:42:39 --> Model "Tautan_model" initialized
INFO - 2025-12-16 10:42:39 --> Model "Staff_model" initialized
INFO - 2025-12-16 10:42:39 --> Model "Dasbor_model" initialized
INFO - 2025-12-16 10:42:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-12-16 10:42:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-16 10:42:43 --> Model "Log_model" initialized
INFO - 2025-12-16 10:42:43 --> Final output sent to browser
DEBUG - 2025-12-16 10:42:43 --> Total execution time: 4.7466
INFO - 2025-12-16 04:43:03 --> Config Class Initialized
INFO - 2025-12-16 04:43:03 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:43:03 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:43:03 --> Utf8 Class Initialized
INFO - 2025-12-16 04:43:03 --> URI Class Initialized
INFO - 2025-12-16 04:43:03 --> Router Class Initialized
INFO - 2025-12-16 04:43:03 --> Output Class Initialized
INFO - 2025-12-16 04:43:04 --> Security Class Initialized
DEBUG - 2025-12-16 04:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:43:04 --> CSRF cookie sent
INFO - 2025-12-16 04:43:04 --> Input Class Initialized
INFO - 2025-12-16 04:43:04 --> Language Class Initialized
INFO - 2025-12-16 04:43:04 --> Loader Class Initialized
INFO - 2025-12-16 04:43:04 --> Helper loaded: url_helper
INFO - 2025-12-16 04:43:04 --> Helper loaded: text_helper
INFO - 2025-12-16 04:43:04 --> Helper loaded: string_helper
INFO - 2025-12-16 04:43:04 --> Helper loaded: form_helper
INFO - 2025-12-16 04:43:04 --> Helper loaded: download_helper
INFO - 2025-12-16 04:43:04 --> Helper loaded: security_helper
INFO - 2025-12-16 04:43:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:43:04 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:43:04 --> Form Validation Class Initialized
INFO - 2025-12-16 04:43:04 --> Model "User_model" initialized
INFO - 2025-12-16 10:43:04 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:43:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:43:04 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:43:04 --> Controller Class Initialized
INFO - 2025-12-16 10:43:04 --> Model "Helpdesk_model" initialized
INFO - 2025-12-16 10:43:04 --> Model "Kategori_helpdesk_model" initialized
INFO - 2025-12-16 10:43:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/helpdesk/list.php
INFO - 2025-12-16 10:43:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-12-16 10:43:04 --> Model "Log_model" initialized
INFO - 2025-12-16 10:43:04 --> Final output sent to browser
DEBUG - 2025-12-16 10:43:04 --> Total execution time: 0.5446
INFO - 2025-12-16 04:44:15 --> Config Class Initialized
INFO - 2025-12-16 04:44:15 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:44:15 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:44:15 --> Utf8 Class Initialized
INFO - 2025-12-16 04:44:15 --> URI Class Initialized
DEBUG - 2025-12-16 04:44:15 --> No URI present. Default controller set.
INFO - 2025-12-16 04:44:15 --> Router Class Initialized
INFO - 2025-12-16 04:44:15 --> Output Class Initialized
INFO - 2025-12-16 04:44:15 --> Security Class Initialized
DEBUG - 2025-12-16 04:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:44:15 --> CSRF cookie sent
INFO - 2025-12-16 04:44:15 --> Input Class Initialized
INFO - 2025-12-16 04:44:15 --> Language Class Initialized
INFO - 2025-12-16 04:44:15 --> Loader Class Initialized
INFO - 2025-12-16 04:44:15 --> Helper loaded: url_helper
INFO - 2025-12-16 04:44:15 --> Helper loaded: text_helper
INFO - 2025-12-16 04:44:15 --> Helper loaded: string_helper
INFO - 2025-12-16 04:44:15 --> Helper loaded: form_helper
INFO - 2025-12-16 04:44:15 --> Helper loaded: download_helper
INFO - 2025-12-16 04:44:15 --> Helper loaded: security_helper
INFO - 2025-12-16 04:44:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:44:15 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:44:15 --> Form Validation Class Initialized
INFO - 2025-12-16 04:44:15 --> Model "User_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:44:15 --> Controller Class Initialized
INFO - 2025-12-16 10:44:15 --> Model "Berita_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Galeri_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Video_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Agenda_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Tautan_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Mitra_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Prodi_model" initialized
INFO - 2025-12-16 10:44:15 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 10:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 10:44:15 --> Pagination Class Initialized
INFO - 2025-12-16 10:44:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 10:44:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 10:44:15 --> Model "Log_model" initialized
INFO - 2025-12-16 10:44:15 --> Final output sent to browser
DEBUG - 2025-12-16 10:44:15 --> Total execution time: 0.2734
INFO - 2025-12-16 04:44:55 --> Config Class Initialized
INFO - 2025-12-16 04:44:55 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:44:55 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:44:55 --> Utf8 Class Initialized
INFO - 2025-12-16 04:44:55 --> URI Class Initialized
DEBUG - 2025-12-16 04:44:55 --> No URI present. Default controller set.
INFO - 2025-12-16 04:44:55 --> Router Class Initialized
INFO - 2025-12-16 04:44:55 --> Output Class Initialized
INFO - 2025-12-16 04:44:55 --> Security Class Initialized
DEBUG - 2025-12-16 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:44:55 --> CSRF cookie sent
INFO - 2025-12-16 04:44:55 --> Input Class Initialized
INFO - 2025-12-16 04:44:55 --> Language Class Initialized
INFO - 2025-12-16 04:44:55 --> Loader Class Initialized
INFO - 2025-12-16 04:44:55 --> Helper loaded: url_helper
INFO - 2025-12-16 04:44:55 --> Helper loaded: text_helper
INFO - 2025-12-16 04:44:55 --> Helper loaded: string_helper
INFO - 2025-12-16 04:44:55 --> Helper loaded: form_helper
INFO - 2025-12-16 04:44:55 --> Helper loaded: download_helper
INFO - 2025-12-16 04:44:55 --> Helper loaded: security_helper
INFO - 2025-12-16 04:44:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:44:55 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:44:55 --> Form Validation Class Initialized
INFO - 2025-12-16 04:44:55 --> Model "User_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:44:55 --> Controller Class Initialized
INFO - 2025-12-16 10:44:55 --> Model "Berita_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Galeri_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Video_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Agenda_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Tautan_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Mitra_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Prodi_model" initialized
INFO - 2025-12-16 10:44:55 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 10:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 10:44:55 --> Pagination Class Initialized
INFO - 2025-12-16 10:44:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 10:44:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 10:44:55 --> Model "Log_model" initialized
INFO - 2025-12-16 10:44:55 --> Final output sent to browser
DEBUG - 2025-12-16 10:44:55 --> Total execution time: 0.3789
INFO - 2025-12-16 04:45:13 --> Config Class Initialized
INFO - 2025-12-16 04:45:13 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:45:13 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:45:13 --> Utf8 Class Initialized
INFO - 2025-12-16 04:45:13 --> URI Class Initialized
DEBUG - 2025-12-16 04:45:13 --> No URI present. Default controller set.
INFO - 2025-12-16 04:45:13 --> Router Class Initialized
INFO - 2025-12-16 04:45:13 --> Output Class Initialized
INFO - 2025-12-16 04:45:13 --> Security Class Initialized
DEBUG - 2025-12-16 04:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:45:13 --> CSRF cookie sent
INFO - 2025-12-16 04:45:13 --> Input Class Initialized
INFO - 2025-12-16 04:45:13 --> Language Class Initialized
INFO - 2025-12-16 04:45:13 --> Loader Class Initialized
INFO - 2025-12-16 04:45:13 --> Helper loaded: url_helper
INFO - 2025-12-16 04:45:13 --> Helper loaded: text_helper
INFO - 2025-12-16 04:45:13 --> Helper loaded: string_helper
INFO - 2025-12-16 04:45:13 --> Helper loaded: form_helper
INFO - 2025-12-16 04:45:13 --> Helper loaded: download_helper
INFO - 2025-12-16 04:45:13 --> Helper loaded: security_helper
INFO - 2025-12-16 04:45:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:45:13 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:45:13 --> Form Validation Class Initialized
INFO - 2025-12-16 04:45:13 --> Model "User_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:45:13 --> Controller Class Initialized
INFO - 2025-12-16 10:45:13 --> Model "Berita_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Galeri_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Video_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Agenda_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Tautan_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Mitra_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Prodi_model" initialized
INFO - 2025-12-16 10:45:13 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 10:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 10:45:13 --> Pagination Class Initialized
INFO - 2025-12-16 10:45:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 10:45:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 10:45:13 --> Model "Log_model" initialized
INFO - 2025-12-16 10:45:13 --> Final output sent to browser
DEBUG - 2025-12-16 10:45:13 --> Total execution time: 0.3160
INFO - 2025-12-16 04:45:15 --> Config Class Initialized
INFO - 2025-12-16 04:45:15 --> Hooks Class Initialized
DEBUG - 2025-12-16 04:45:15 --> UTF-8 Support Enabled
INFO - 2025-12-16 04:45:15 --> Utf8 Class Initialized
INFO - 2025-12-16 04:45:15 --> URI Class Initialized
DEBUG - 2025-12-16 04:45:15 --> No URI present. Default controller set.
INFO - 2025-12-16 04:45:15 --> Router Class Initialized
INFO - 2025-12-16 04:45:15 --> Output Class Initialized
INFO - 2025-12-16 04:45:15 --> Security Class Initialized
DEBUG - 2025-12-16 04:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 04:45:15 --> CSRF cookie sent
INFO - 2025-12-16 04:45:15 --> Input Class Initialized
INFO - 2025-12-16 04:45:15 --> Language Class Initialized
INFO - 2025-12-16 04:45:15 --> Loader Class Initialized
INFO - 2025-12-16 04:45:15 --> Helper loaded: url_helper
INFO - 2025-12-16 04:45:15 --> Helper loaded: text_helper
INFO - 2025-12-16 04:45:15 --> Helper loaded: string_helper
INFO - 2025-12-16 04:45:15 --> Helper loaded: form_helper
INFO - 2025-12-16 04:45:15 --> Helper loaded: download_helper
INFO - 2025-12-16 04:45:15 --> Helper loaded: security_helper
INFO - 2025-12-16 04:45:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 04:45:15 --> Database Driver Class Initialized
DEBUG - 2025-12-16 04:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 04:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 04:45:15 --> Form Validation Class Initialized
INFO - 2025-12-16 04:45:15 --> Model "User_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Nav_model" initialized
INFO - 2025-12-16 10:45:15 --> Controller Class Initialized
INFO - 2025-12-16 10:45:15 --> Model "Berita_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Galeri_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Video_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Agenda_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Tautan_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Mitra_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Prodi_model" initialized
INFO - 2025-12-16 10:45:15 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 10:45:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 10:45:15 --> Pagination Class Initialized
INFO - 2025-12-16 10:45:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 10:45:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 10:45:15 --> Model "Log_model" initialized
INFO - 2025-12-16 10:45:15 --> Final output sent to browser
DEBUG - 2025-12-16 10:45:15 --> Total execution time: 0.2962
INFO - 2025-12-16 07:15:47 --> Config Class Initialized
INFO - 2025-12-16 07:15:47 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:15:47 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:15:47 --> Utf8 Class Initialized
INFO - 2025-12-16 07:15:47 --> URI Class Initialized
DEBUG - 2025-12-16 07:15:48 --> No URI present. Default controller set.
INFO - 2025-12-16 07:15:48 --> Router Class Initialized
INFO - 2025-12-16 07:15:48 --> Output Class Initialized
INFO - 2025-12-16 07:15:48 --> Security Class Initialized
DEBUG - 2025-12-16 07:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:15:48 --> CSRF cookie sent
INFO - 2025-12-16 07:15:48 --> Input Class Initialized
INFO - 2025-12-16 07:15:48 --> Language Class Initialized
INFO - 2025-12-16 07:15:48 --> Loader Class Initialized
INFO - 2025-12-16 07:15:48 --> Helper loaded: url_helper
INFO - 2025-12-16 07:15:48 --> Helper loaded: text_helper
INFO - 2025-12-16 07:15:48 --> Helper loaded: string_helper
INFO - 2025-12-16 07:15:48 --> Helper loaded: form_helper
INFO - 2025-12-16 07:15:48 --> Helper loaded: download_helper
INFO - 2025-12-16 07:15:48 --> Helper loaded: security_helper
INFO - 2025-12-16 07:15:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:15:49 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:15:49 --> Form Validation Class Initialized
INFO - 2025-12-16 07:15:49 --> Model "User_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:15:49 --> Controller Class Initialized
INFO - 2025-12-16 13:15:49 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Video_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:15:49 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:15:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:15:50 --> Pagination Class Initialized
INFO - 2025-12-16 13:15:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:15:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:15:52 --> Model "Log_model" initialized
INFO - 2025-12-16 13:15:52 --> Final output sent to browser
DEBUG - 2025-12-16 13:15:52 --> Total execution time: 4.8932
INFO - 2025-12-16 07:16:08 --> Config Class Initialized
INFO - 2025-12-16 07:16:08 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:16:08 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:16:08 --> Utf8 Class Initialized
INFO - 2025-12-16 07:16:08 --> URI Class Initialized
DEBUG - 2025-12-16 07:16:08 --> No URI present. Default controller set.
INFO - 2025-12-16 07:16:08 --> Router Class Initialized
INFO - 2025-12-16 07:16:08 --> Output Class Initialized
INFO - 2025-12-16 07:16:08 --> Security Class Initialized
DEBUG - 2025-12-16 07:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:16:08 --> CSRF cookie sent
INFO - 2025-12-16 07:16:08 --> Input Class Initialized
INFO - 2025-12-16 07:16:08 --> Language Class Initialized
INFO - 2025-12-16 07:16:08 --> Loader Class Initialized
INFO - 2025-12-16 07:16:08 --> Helper loaded: url_helper
INFO - 2025-12-16 07:16:08 --> Helper loaded: text_helper
INFO - 2025-12-16 07:16:08 --> Helper loaded: string_helper
INFO - 2025-12-16 07:16:08 --> Helper loaded: form_helper
INFO - 2025-12-16 07:16:08 --> Helper loaded: download_helper
INFO - 2025-12-16 07:16:08 --> Helper loaded: security_helper
INFO - 2025-12-16 07:16:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:16:08 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:16:09 --> Form Validation Class Initialized
INFO - 2025-12-16 07:16:09 --> Model "User_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:16:09 --> Controller Class Initialized
INFO - 2025-12-16 13:16:09 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Video_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:16:09 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:16:09 --> Pagination Class Initialized
INFO - 2025-12-16 13:16:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:16:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:16:09 --> Model "Log_model" initialized
INFO - 2025-12-16 13:16:09 --> Final output sent to browser
DEBUG - 2025-12-16 13:16:09 --> Total execution time: 0.3547
INFO - 2025-12-16 07:19:44 --> Config Class Initialized
INFO - 2025-12-16 07:19:44 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:19:44 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:19:44 --> Utf8 Class Initialized
INFO - 2025-12-16 07:19:44 --> URI Class Initialized
DEBUG - 2025-12-16 07:19:44 --> No URI present. Default controller set.
INFO - 2025-12-16 07:19:44 --> Router Class Initialized
INFO - 2025-12-16 07:19:44 --> Output Class Initialized
INFO - 2025-12-16 07:19:44 --> Security Class Initialized
DEBUG - 2025-12-16 07:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:19:44 --> CSRF cookie sent
INFO - 2025-12-16 07:19:44 --> Input Class Initialized
INFO - 2025-12-16 07:19:44 --> Language Class Initialized
INFO - 2025-12-16 07:19:44 --> Loader Class Initialized
INFO - 2025-12-16 07:19:44 --> Helper loaded: url_helper
INFO - 2025-12-16 07:19:44 --> Helper loaded: text_helper
INFO - 2025-12-16 07:19:44 --> Helper loaded: string_helper
INFO - 2025-12-16 07:19:44 --> Helper loaded: form_helper
INFO - 2025-12-16 07:19:44 --> Helper loaded: download_helper
INFO - 2025-12-16 07:19:44 --> Helper loaded: security_helper
INFO - 2025-12-16 07:19:44 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:19:44 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:19:44 --> Form Validation Class Initialized
INFO - 2025-12-16 07:19:44 --> Model "User_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:19:44 --> Controller Class Initialized
INFO - 2025-12-16 13:19:44 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Video_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:19:44 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:19:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:19:45 --> Pagination Class Initialized
INFO - 2025-12-16 13:19:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:19:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:19:45 --> Model "Log_model" initialized
INFO - 2025-12-16 13:19:45 --> Final output sent to browser
DEBUG - 2025-12-16 13:19:45 --> Total execution time: 0.2077
INFO - 2025-12-16 07:20:00 --> Config Class Initialized
INFO - 2025-12-16 07:20:00 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:20:00 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:20:00 --> Utf8 Class Initialized
INFO - 2025-12-16 07:20:00 --> URI Class Initialized
INFO - 2025-12-16 07:20:00 --> Router Class Initialized
INFO - 2025-12-16 07:20:00 --> Output Class Initialized
INFO - 2025-12-16 07:20:00 --> Security Class Initialized
DEBUG - 2025-12-16 07:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:20:00 --> CSRF cookie sent
INFO - 2025-12-16 07:20:00 --> Input Class Initialized
INFO - 2025-12-16 07:20:00 --> Language Class Initialized
INFO - 2025-12-16 07:20:00 --> Loader Class Initialized
INFO - 2025-12-16 07:20:00 --> Helper loaded: url_helper
INFO - 2025-12-16 07:20:00 --> Helper loaded: text_helper
INFO - 2025-12-16 07:20:00 --> Helper loaded: string_helper
INFO - 2025-12-16 07:20:00 --> Helper loaded: form_helper
INFO - 2025-12-16 07:20:00 --> Helper loaded: download_helper
INFO - 2025-12-16 07:20:00 --> Helper loaded: security_helper
INFO - 2025-12-16 07:20:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:20:00 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:20:00 --> Form Validation Class Initialized
INFO - 2025-12-16 07:20:00 --> Model "User_model" initialized
INFO - 2025-12-16 13:20:00 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:20:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:20:00 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:20:00 --> Controller Class Initialized
INFO - 2025-12-16 13:20:00 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:20:00 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:20:00 --> Model "Sdm_model" initialized
INFO - 2025-12-16 13:20:00 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-12-16 13:20:00 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2025-12-16 13:20:00 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-16 13:20:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-12-16 13:20:00 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2025-12-16 13:20:00 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2025-12-16 13:20:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-12-16 13:20:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:20:00 --> Model "Log_model" initialized
INFO - 2025-12-16 13:20:00 --> Final output sent to browser
DEBUG - 2025-12-16 13:20:00 --> Total execution time: 0.2067
INFO - 2025-12-16 07:20:23 --> Config Class Initialized
INFO - 2025-12-16 07:20:23 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:20:23 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:20:23 --> Utf8 Class Initialized
INFO - 2025-12-16 07:20:23 --> URI Class Initialized
INFO - 2025-12-16 07:20:23 --> Router Class Initialized
INFO - 2025-12-16 07:20:23 --> Output Class Initialized
INFO - 2025-12-16 07:20:23 --> Security Class Initialized
DEBUG - 2025-12-16 07:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:20:23 --> CSRF cookie sent
INFO - 2025-12-16 07:20:23 --> Input Class Initialized
INFO - 2025-12-16 07:20:23 --> Language Class Initialized
INFO - 2025-12-16 07:20:23 --> Loader Class Initialized
INFO - 2025-12-16 07:20:23 --> Helper loaded: url_helper
INFO - 2025-12-16 07:20:23 --> Helper loaded: text_helper
INFO - 2025-12-16 07:20:23 --> Helper loaded: string_helper
INFO - 2025-12-16 07:20:23 --> Helper loaded: form_helper
INFO - 2025-12-16 07:20:23 --> Helper loaded: download_helper
INFO - 2025-12-16 07:20:23 --> Helper loaded: security_helper
INFO - 2025-12-16 07:20:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:20:23 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:20:23 --> Form Validation Class Initialized
INFO - 2025-12-16 07:20:23 --> Model "User_model" initialized
INFO - 2025-12-16 13:20:23 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:20:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:20:23 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:20:23 --> Controller Class Initialized
INFO - 2025-12-16 13:20:23 --> Model "Sdm_model" initialized
INFO - 2025-12-16 13:20:23 --> Model "Jabatansdm_model" initialized
INFO - 2025-12-16 13:20:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2025-12-16 13:20:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:20:23 --> Model "Log_model" initialized
INFO - 2025-12-16 13:20:23 --> Final output sent to browser
DEBUG - 2025-12-16 13:20:23 --> Total execution time: 0.2071
INFO - 2025-12-16 07:20:30 --> Config Class Initialized
INFO - 2025-12-16 07:20:30 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:20:30 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:20:30 --> Utf8 Class Initialized
INFO - 2025-12-16 07:20:30 --> URI Class Initialized
INFO - 2025-12-16 07:20:30 --> Router Class Initialized
INFO - 2025-12-16 07:20:30 --> Output Class Initialized
INFO - 2025-12-16 07:20:30 --> Security Class Initialized
DEBUG - 2025-12-16 07:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:20:30 --> CSRF cookie sent
INFO - 2025-12-16 07:20:30 --> Input Class Initialized
INFO - 2025-12-16 07:20:30 --> Language Class Initialized
INFO - 2025-12-16 07:20:30 --> Loader Class Initialized
INFO - 2025-12-16 07:20:30 --> Helper loaded: url_helper
INFO - 2025-12-16 07:20:30 --> Helper loaded: text_helper
INFO - 2025-12-16 07:20:30 --> Helper loaded: string_helper
INFO - 2025-12-16 07:20:30 --> Helper loaded: form_helper
INFO - 2025-12-16 07:20:30 --> Helper loaded: download_helper
INFO - 2025-12-16 07:20:30 --> Helper loaded: security_helper
INFO - 2025-12-16 07:20:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:20:30 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:20:30 --> Form Validation Class Initialized
INFO - 2025-12-16 07:20:30 --> Model "User_model" initialized
INFO - 2025-12-16 13:20:30 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:20:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:20:30 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:20:30 --> Controller Class Initialized
INFO - 2025-12-16 13:20:30 --> Model "Pages_model" initialized
INFO - 2025-12-16 13:20:30 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:20:30 --> Model "Download_model" initialized
INFO - 2025-12-16 13:20:30 --> Model "Kategori_download_model" initialized
INFO - 2025-12-16 13:20:30 --> Model "Jenis_download_model" initialized
INFO - 2025-12-16 13:20:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2025-12-16 13:20:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:20:30 --> Model "Log_model" initialized
INFO - 2025-12-16 13:20:30 --> Final output sent to browser
DEBUG - 2025-12-16 13:20:30 --> Total execution time: 0.1719
INFO - 2025-12-16 07:20:43 --> Config Class Initialized
INFO - 2025-12-16 07:20:43 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:20:43 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:20:43 --> Utf8 Class Initialized
INFO - 2025-12-16 07:20:43 --> URI Class Initialized
DEBUG - 2025-12-16 07:20:43 --> No URI present. Default controller set.
INFO - 2025-12-16 07:20:43 --> Router Class Initialized
INFO - 2025-12-16 07:20:43 --> Output Class Initialized
INFO - 2025-12-16 07:20:43 --> Security Class Initialized
DEBUG - 2025-12-16 07:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:20:43 --> CSRF cookie sent
INFO - 2025-12-16 07:20:43 --> Input Class Initialized
INFO - 2025-12-16 07:20:43 --> Language Class Initialized
INFO - 2025-12-16 07:20:43 --> Loader Class Initialized
INFO - 2025-12-16 07:20:43 --> Helper loaded: url_helper
INFO - 2025-12-16 07:20:43 --> Helper loaded: text_helper
INFO - 2025-12-16 07:20:43 --> Helper loaded: string_helper
INFO - 2025-12-16 07:20:43 --> Helper loaded: form_helper
INFO - 2025-12-16 07:20:43 --> Helper loaded: download_helper
INFO - 2025-12-16 07:20:43 --> Helper loaded: security_helper
INFO - 2025-12-16 07:20:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:20:43 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:20:43 --> Form Validation Class Initialized
INFO - 2025-12-16 07:20:43 --> Model "User_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:20:43 --> Controller Class Initialized
INFO - 2025-12-16 13:20:43 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Video_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:20:43 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:20:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:20:43 --> Pagination Class Initialized
INFO - 2025-12-16 13:20:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:20:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:20:43 --> Model "Log_model" initialized
INFO - 2025-12-16 13:20:43 --> Final output sent to browser
DEBUG - 2025-12-16 13:20:43 --> Total execution time: 0.2410
INFO - 2025-12-16 07:21:00 --> Config Class Initialized
INFO - 2025-12-16 07:21:00 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:21:00 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:21:00 --> Utf8 Class Initialized
INFO - 2025-12-16 07:21:00 --> URI Class Initialized
DEBUG - 2025-12-16 07:21:00 --> No URI present. Default controller set.
INFO - 2025-12-16 07:21:00 --> Router Class Initialized
INFO - 2025-12-16 07:21:00 --> Output Class Initialized
INFO - 2025-12-16 07:21:00 --> Security Class Initialized
DEBUG - 2025-12-16 07:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:21:00 --> CSRF cookie sent
INFO - 2025-12-16 07:21:00 --> Input Class Initialized
INFO - 2025-12-16 07:21:00 --> Language Class Initialized
INFO - 2025-12-16 07:21:00 --> Loader Class Initialized
INFO - 2025-12-16 07:21:00 --> Helper loaded: url_helper
INFO - 2025-12-16 07:21:00 --> Helper loaded: text_helper
INFO - 2025-12-16 07:21:00 --> Helper loaded: string_helper
INFO - 2025-12-16 07:21:00 --> Helper loaded: form_helper
INFO - 2025-12-16 07:21:00 --> Helper loaded: download_helper
INFO - 2025-12-16 07:21:00 --> Helper loaded: security_helper
INFO - 2025-12-16 07:21:00 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:21:00 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:21:00 --> Form Validation Class Initialized
INFO - 2025-12-16 07:21:00 --> Model "User_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:21:00 --> Controller Class Initialized
INFO - 2025-12-16 13:21:00 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Video_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:21:00 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:21:00 --> Pagination Class Initialized
INFO - 2025-12-16 13:21:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:21:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:21:00 --> Model "Log_model" initialized
INFO - 2025-12-16 13:21:00 --> Final output sent to browser
DEBUG - 2025-12-16 13:21:00 --> Total execution time: 0.2013
INFO - 2025-12-16 07:26:44 --> Config Class Initialized
INFO - 2025-12-16 07:26:44 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:26:45 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:26:45 --> Utf8 Class Initialized
INFO - 2025-12-16 07:26:45 --> URI Class Initialized
DEBUG - 2025-12-16 07:26:45 --> No URI present. Default controller set.
INFO - 2025-12-16 07:26:45 --> Router Class Initialized
INFO - 2025-12-16 07:26:45 --> Output Class Initialized
INFO - 2025-12-16 07:26:45 --> Security Class Initialized
DEBUG - 2025-12-16 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:26:45 --> CSRF cookie sent
INFO - 2025-12-16 07:26:45 --> Input Class Initialized
INFO - 2025-12-16 07:26:45 --> Language Class Initialized
INFO - 2025-12-16 07:26:45 --> Loader Class Initialized
INFO - 2025-12-16 07:26:45 --> Helper loaded: url_helper
INFO - 2025-12-16 07:26:45 --> Helper loaded: text_helper
INFO - 2025-12-16 07:26:45 --> Helper loaded: string_helper
INFO - 2025-12-16 07:26:45 --> Helper loaded: form_helper
INFO - 2025-12-16 07:26:45 --> Helper loaded: download_helper
INFO - 2025-12-16 07:26:45 --> Helper loaded: security_helper
INFO - 2025-12-16 07:26:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:26:45 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:26:45 --> Form Validation Class Initialized
INFO - 2025-12-16 07:26:45 --> Model "User_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:26:45 --> Controller Class Initialized
INFO - 2025-12-16 13:26:45 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Video_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:26:45 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:26:45 --> Pagination Class Initialized
INFO - 2025-12-16 13:26:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:26:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:26:45 --> Model "Log_model" initialized
INFO - 2025-12-16 13:26:45 --> Final output sent to browser
DEBUG - 2025-12-16 13:26:45 --> Total execution time: 0.2572
INFO - 2025-12-16 07:26:52 --> Config Class Initialized
INFO - 2025-12-16 07:26:52 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:26:52 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:26:52 --> Utf8 Class Initialized
INFO - 2025-12-16 07:26:52 --> URI Class Initialized
DEBUG - 2025-12-16 07:26:52 --> No URI present. Default controller set.
INFO - 2025-12-16 07:26:52 --> Router Class Initialized
INFO - 2025-12-16 07:26:52 --> Output Class Initialized
INFO - 2025-12-16 07:26:52 --> Security Class Initialized
DEBUG - 2025-12-16 07:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:26:52 --> CSRF cookie sent
INFO - 2025-12-16 07:26:52 --> Input Class Initialized
INFO - 2025-12-16 07:26:52 --> Language Class Initialized
INFO - 2025-12-16 07:26:52 --> Loader Class Initialized
INFO - 2025-12-16 07:26:52 --> Helper loaded: url_helper
INFO - 2025-12-16 07:26:52 --> Helper loaded: text_helper
INFO - 2025-12-16 07:26:52 --> Helper loaded: string_helper
INFO - 2025-12-16 07:26:52 --> Helper loaded: form_helper
INFO - 2025-12-16 07:26:52 --> Helper loaded: download_helper
INFO - 2025-12-16 07:26:52 --> Helper loaded: security_helper
INFO - 2025-12-16 07:26:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:26:52 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:26:52 --> Form Validation Class Initialized
INFO - 2025-12-16 07:26:52 --> Model "User_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:26:52 --> Controller Class Initialized
INFO - 2025-12-16 13:26:52 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Video_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:26:52 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:26:53 --> Pagination Class Initialized
INFO - 2025-12-16 13:26:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:26:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:26:53 --> Model "Log_model" initialized
INFO - 2025-12-16 13:26:53 --> Final output sent to browser
DEBUG - 2025-12-16 13:26:53 --> Total execution time: 0.1981
INFO - 2025-12-16 07:27:49 --> Config Class Initialized
INFO - 2025-12-16 07:27:49 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:27:49 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:27:49 --> Utf8 Class Initialized
INFO - 2025-12-16 07:27:49 --> URI Class Initialized
DEBUG - 2025-12-16 07:27:49 --> No URI present. Default controller set.
INFO - 2025-12-16 07:27:49 --> Router Class Initialized
INFO - 2025-12-16 07:27:49 --> Output Class Initialized
INFO - 2025-12-16 07:27:49 --> Security Class Initialized
DEBUG - 2025-12-16 07:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:27:49 --> CSRF cookie sent
INFO - 2025-12-16 07:27:49 --> Input Class Initialized
INFO - 2025-12-16 07:27:49 --> Language Class Initialized
INFO - 2025-12-16 07:27:49 --> Loader Class Initialized
INFO - 2025-12-16 07:27:49 --> Helper loaded: url_helper
INFO - 2025-12-16 07:27:49 --> Helper loaded: text_helper
INFO - 2025-12-16 07:27:49 --> Helper loaded: string_helper
INFO - 2025-12-16 07:27:49 --> Helper loaded: form_helper
INFO - 2025-12-16 07:27:49 --> Helper loaded: download_helper
INFO - 2025-12-16 07:27:49 --> Helper loaded: security_helper
INFO - 2025-12-16 07:27:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:27:49 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:27:49 --> Form Validation Class Initialized
INFO - 2025-12-16 07:27:49 --> Model "User_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:27:49 --> Controller Class Initialized
INFO - 2025-12-16 13:27:49 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Video_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:27:49 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:27:50 --> Pagination Class Initialized
INFO - 2025-12-16 13:27:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:27:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:27:50 --> Model "Log_model" initialized
INFO - 2025-12-16 13:27:50 --> Final output sent to browser
DEBUG - 2025-12-16 13:27:50 --> Total execution time: 0.2525
INFO - 2025-12-16 07:27:58 --> Config Class Initialized
INFO - 2025-12-16 07:27:58 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:27:58 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:27:58 --> Utf8 Class Initialized
INFO - 2025-12-16 07:27:58 --> URI Class Initialized
DEBUG - 2025-12-16 07:27:58 --> No URI present. Default controller set.
INFO - 2025-12-16 07:27:58 --> Router Class Initialized
INFO - 2025-12-16 07:27:58 --> Output Class Initialized
INFO - 2025-12-16 07:27:58 --> Security Class Initialized
DEBUG - 2025-12-16 07:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:27:58 --> CSRF cookie sent
INFO - 2025-12-16 07:27:58 --> Input Class Initialized
INFO - 2025-12-16 07:27:58 --> Language Class Initialized
INFO - 2025-12-16 07:27:58 --> Loader Class Initialized
INFO - 2025-12-16 07:27:58 --> Helper loaded: url_helper
INFO - 2025-12-16 07:27:58 --> Helper loaded: text_helper
INFO - 2025-12-16 07:27:58 --> Helper loaded: string_helper
INFO - 2025-12-16 07:27:58 --> Helper loaded: form_helper
INFO - 2025-12-16 07:27:58 --> Helper loaded: download_helper
INFO - 2025-12-16 07:27:58 --> Helper loaded: security_helper
INFO - 2025-12-16 07:27:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:27:58 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:27:58 --> Form Validation Class Initialized
INFO - 2025-12-16 07:27:58 --> Model "User_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:27:58 --> Controller Class Initialized
INFO - 2025-12-16 13:27:58 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Video_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:27:58 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:27:58 --> Pagination Class Initialized
INFO - 2025-12-16 13:27:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:27:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:27:59 --> Model "Log_model" initialized
INFO - 2025-12-16 13:27:59 --> Final output sent to browser
DEBUG - 2025-12-16 13:27:59 --> Total execution time: 0.2355
INFO - 2025-12-16 07:28:36 --> Config Class Initialized
INFO - 2025-12-16 07:28:36 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:28:36 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:28:36 --> Utf8 Class Initialized
INFO - 2025-12-16 07:28:36 --> URI Class Initialized
DEBUG - 2025-12-16 07:28:36 --> No URI present. Default controller set.
INFO - 2025-12-16 07:28:36 --> Router Class Initialized
INFO - 2025-12-16 07:28:36 --> Output Class Initialized
INFO - 2025-12-16 07:28:36 --> Security Class Initialized
DEBUG - 2025-12-16 07:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:28:36 --> CSRF cookie sent
INFO - 2025-12-16 07:28:36 --> Input Class Initialized
INFO - 2025-12-16 07:28:36 --> Language Class Initialized
INFO - 2025-12-16 07:28:36 --> Loader Class Initialized
INFO - 2025-12-16 07:28:36 --> Helper loaded: url_helper
INFO - 2025-12-16 07:28:36 --> Helper loaded: text_helper
INFO - 2025-12-16 07:28:36 --> Helper loaded: string_helper
INFO - 2025-12-16 07:28:36 --> Helper loaded: form_helper
INFO - 2025-12-16 07:28:36 --> Helper loaded: download_helper
INFO - 2025-12-16 07:28:36 --> Helper loaded: security_helper
INFO - 2025-12-16 07:28:36 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:28:36 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:28:36 --> Form Validation Class Initialized
INFO - 2025-12-16 07:28:36 --> Model "User_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:28:36 --> Controller Class Initialized
INFO - 2025-12-16 13:28:36 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Video_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:28:36 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:28:36 --> Pagination Class Initialized
INFO - 2025-12-16 13:28:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:28:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:28:36 --> Model "Log_model" initialized
INFO - 2025-12-16 13:28:36 --> Final output sent to browser
DEBUG - 2025-12-16 13:28:36 --> Total execution time: 0.2522
INFO - 2025-12-16 07:29:19 --> Config Class Initialized
INFO - 2025-12-16 07:29:19 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:29:19 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:29:19 --> Utf8 Class Initialized
INFO - 2025-12-16 07:29:19 --> URI Class Initialized
DEBUG - 2025-12-16 07:29:19 --> No URI present. Default controller set.
INFO - 2025-12-16 07:29:19 --> Router Class Initialized
INFO - 2025-12-16 07:29:19 --> Output Class Initialized
INFO - 2025-12-16 07:29:19 --> Security Class Initialized
DEBUG - 2025-12-16 07:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:29:19 --> CSRF cookie sent
INFO - 2025-12-16 07:29:19 --> Input Class Initialized
INFO - 2025-12-16 07:29:19 --> Language Class Initialized
INFO - 2025-12-16 07:29:19 --> Loader Class Initialized
INFO - 2025-12-16 07:29:19 --> Helper loaded: url_helper
INFO - 2025-12-16 07:29:19 --> Helper loaded: text_helper
INFO - 2025-12-16 07:29:19 --> Helper loaded: string_helper
INFO - 2025-12-16 07:29:19 --> Helper loaded: form_helper
INFO - 2025-12-16 07:29:19 --> Helper loaded: download_helper
INFO - 2025-12-16 07:29:19 --> Helper loaded: security_helper
INFO - 2025-12-16 07:29:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:29:19 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:29:19 --> Form Validation Class Initialized
INFO - 2025-12-16 07:29:19 --> Model "User_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:29:19 --> Controller Class Initialized
INFO - 2025-12-16 13:29:19 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Video_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:29:19 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:29:19 --> Pagination Class Initialized
INFO - 2025-12-16 13:29:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:29:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:29:19 --> Model "Log_model" initialized
INFO - 2025-12-16 13:29:19 --> Final output sent to browser
DEBUG - 2025-12-16 13:29:19 --> Total execution time: 0.2987
INFO - 2025-12-16 07:29:31 --> Config Class Initialized
INFO - 2025-12-16 07:29:31 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:29:31 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:29:31 --> Utf8 Class Initialized
INFO - 2025-12-16 07:29:31 --> URI Class Initialized
DEBUG - 2025-12-16 07:29:31 --> No URI present. Default controller set.
INFO - 2025-12-16 07:29:31 --> Router Class Initialized
INFO - 2025-12-16 07:29:31 --> Output Class Initialized
INFO - 2025-12-16 07:29:31 --> Security Class Initialized
DEBUG - 2025-12-16 07:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:29:31 --> CSRF cookie sent
INFO - 2025-12-16 07:29:31 --> Input Class Initialized
INFO - 2025-12-16 07:29:31 --> Language Class Initialized
INFO - 2025-12-16 07:29:31 --> Loader Class Initialized
INFO - 2025-12-16 07:29:31 --> Helper loaded: url_helper
INFO - 2025-12-16 07:29:31 --> Helper loaded: text_helper
INFO - 2025-12-16 07:29:31 --> Helper loaded: string_helper
INFO - 2025-12-16 07:29:31 --> Helper loaded: form_helper
INFO - 2025-12-16 07:29:31 --> Helper loaded: download_helper
INFO - 2025-12-16 07:29:31 --> Helper loaded: security_helper
INFO - 2025-12-16 07:29:31 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:29:31 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:29:31 --> Form Validation Class Initialized
INFO - 2025-12-16 07:29:31 --> Model "User_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:29:31 --> Controller Class Initialized
INFO - 2025-12-16 13:29:31 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Video_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:29:31 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:29:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:29:31 --> Pagination Class Initialized
INFO - 2025-12-16 13:29:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:29:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:29:31 --> Model "Log_model" initialized
INFO - 2025-12-16 13:29:31 --> Final output sent to browser
DEBUG - 2025-12-16 13:29:31 --> Total execution time: 0.2510
INFO - 2025-12-16 07:29:59 --> Config Class Initialized
INFO - 2025-12-16 07:29:59 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:29:59 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:29:59 --> Utf8 Class Initialized
INFO - 2025-12-16 07:29:59 --> URI Class Initialized
DEBUG - 2025-12-16 07:29:59 --> No URI present. Default controller set.
INFO - 2025-12-16 07:29:59 --> Router Class Initialized
INFO - 2025-12-16 07:29:59 --> Output Class Initialized
INFO - 2025-12-16 07:29:59 --> Security Class Initialized
DEBUG - 2025-12-16 07:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:29:59 --> CSRF cookie sent
INFO - 2025-12-16 07:29:59 --> Input Class Initialized
INFO - 2025-12-16 07:29:59 --> Language Class Initialized
INFO - 2025-12-16 07:29:59 --> Loader Class Initialized
INFO - 2025-12-16 07:29:59 --> Helper loaded: url_helper
INFO - 2025-12-16 07:29:59 --> Helper loaded: text_helper
INFO - 2025-12-16 07:29:59 --> Helper loaded: string_helper
INFO - 2025-12-16 07:29:59 --> Helper loaded: form_helper
INFO - 2025-12-16 07:29:59 --> Helper loaded: download_helper
INFO - 2025-12-16 07:29:59 --> Helper loaded: security_helper
INFO - 2025-12-16 07:29:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:29:59 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:29:59 --> Form Validation Class Initialized
INFO - 2025-12-16 07:29:59 --> Model "User_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:29:59 --> Controller Class Initialized
INFO - 2025-12-16 13:29:59 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Video_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:29:59 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:29:59 --> Pagination Class Initialized
INFO - 2025-12-16 13:29:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:29:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:29:59 --> Model "Log_model" initialized
INFO - 2025-12-16 13:29:59 --> Final output sent to browser
DEBUG - 2025-12-16 13:29:59 --> Total execution time: 0.2987
INFO - 2025-12-16 07:30:07 --> Config Class Initialized
INFO - 2025-12-16 07:30:07 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:30:07 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:30:07 --> Utf8 Class Initialized
INFO - 2025-12-16 07:30:07 --> URI Class Initialized
INFO - 2025-12-16 07:30:07 --> Router Class Initialized
INFO - 2025-12-16 07:30:07 --> Output Class Initialized
INFO - 2025-12-16 07:30:07 --> Security Class Initialized
DEBUG - 2025-12-16 07:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:30:07 --> CSRF cookie sent
INFO - 2025-12-16 07:30:07 --> Input Class Initialized
INFO - 2025-12-16 07:30:07 --> Language Class Initialized
INFO - 2025-12-16 07:30:07 --> Loader Class Initialized
INFO - 2025-12-16 07:30:07 --> Helper loaded: url_helper
INFO - 2025-12-16 07:30:07 --> Helper loaded: text_helper
INFO - 2025-12-16 07:30:07 --> Helper loaded: string_helper
INFO - 2025-12-16 07:30:07 --> Helper loaded: form_helper
INFO - 2025-12-16 07:30:07 --> Helper loaded: download_helper
INFO - 2025-12-16 07:30:07 --> Helper loaded: security_helper
INFO - 2025-12-16 07:30:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:30:08 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:30:08 --> Form Validation Class Initialized
INFO - 2025-12-16 07:30:08 --> Model "User_model" initialized
INFO - 2025-12-16 13:30:08 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:30:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:30:08 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:30:08 --> Controller Class Initialized
INFO - 2025-12-16 13:30:08 --> Model "Sdm_model" initialized
INFO - 2025-12-16 13:30:08 --> Model "Jabatansdm_model" initialized
INFO - 2025-12-16 13:30:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-12-16 13:30:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:30:08 --> Model "Log_model" initialized
INFO - 2025-12-16 13:30:08 --> Final output sent to browser
DEBUG - 2025-12-16 13:30:08 --> Total execution time: 0.1536
INFO - 2025-12-16 07:31:35 --> Config Class Initialized
INFO - 2025-12-16 07:31:35 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:31:35 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:31:35 --> Utf8 Class Initialized
INFO - 2025-12-16 07:31:35 --> URI Class Initialized
INFO - 2025-12-16 07:31:35 --> Router Class Initialized
INFO - 2025-12-16 07:31:35 --> Output Class Initialized
INFO - 2025-12-16 07:31:35 --> Security Class Initialized
DEBUG - 2025-12-16 07:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:31:35 --> CSRF cookie sent
INFO - 2025-12-16 07:31:35 --> Input Class Initialized
INFO - 2025-12-16 07:31:35 --> Language Class Initialized
INFO - 2025-12-16 07:31:35 --> Loader Class Initialized
INFO - 2025-12-16 07:31:35 --> Helper loaded: url_helper
INFO - 2025-12-16 07:31:35 --> Helper loaded: text_helper
INFO - 2025-12-16 07:31:35 --> Helper loaded: string_helper
INFO - 2025-12-16 07:31:35 --> Helper loaded: form_helper
INFO - 2025-12-16 07:31:35 --> Helper loaded: download_helper
INFO - 2025-12-16 07:31:35 --> Helper loaded: security_helper
INFO - 2025-12-16 07:31:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:31:35 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:31:35 --> Form Validation Class Initialized
INFO - 2025-12-16 07:31:35 --> Model "User_model" initialized
INFO - 2025-12-16 13:31:35 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:31:35 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:31:35 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:31:35 --> Controller Class Initialized
INFO - 2025-12-16 13:31:35 --> Model "Sdm_model" initialized
INFO - 2025-12-16 13:31:35 --> Model "Jabatansdm_model" initialized
INFO - 2025-12-16 13:31:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2025-12-16 13:31:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:31:35 --> Model "Log_model" initialized
INFO - 2025-12-16 13:31:35 --> Final output sent to browser
DEBUG - 2025-12-16 13:31:35 --> Total execution time: 0.2139
INFO - 2025-12-16 07:31:37 --> Config Class Initialized
INFO - 2025-12-16 07:31:37 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:31:37 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:31:37 --> Utf8 Class Initialized
INFO - 2025-12-16 07:31:37 --> URI Class Initialized
INFO - 2025-12-16 07:31:37 --> Router Class Initialized
INFO - 2025-12-16 07:31:37 --> Output Class Initialized
INFO - 2025-12-16 07:31:37 --> Security Class Initialized
DEBUG - 2025-12-16 07:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:31:37 --> CSRF cookie sent
INFO - 2025-12-16 07:31:37 --> Input Class Initialized
INFO - 2025-12-16 07:31:37 --> Language Class Initialized
INFO - 2025-12-16 07:31:37 --> Loader Class Initialized
INFO - 2025-12-16 07:31:37 --> Helper loaded: url_helper
INFO - 2025-12-16 07:31:37 --> Helper loaded: text_helper
INFO - 2025-12-16 07:31:37 --> Helper loaded: string_helper
INFO - 2025-12-16 07:31:37 --> Helper loaded: form_helper
INFO - 2025-12-16 07:31:37 --> Helper loaded: download_helper
INFO - 2025-12-16 07:31:37 --> Helper loaded: security_helper
INFO - 2025-12-16 07:31:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:31:37 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:31:37 --> Form Validation Class Initialized
INFO - 2025-12-16 07:31:37 --> Model "User_model" initialized
INFO - 2025-12-16 13:31:37 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:31:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:31:37 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:31:37 --> Controller Class Initialized
INFO - 2025-12-16 13:31:37 --> Model "Sdm_model" initialized
INFO - 2025-12-16 13:31:37 --> Model "Jabatansdm_model" initialized
INFO - 2025-12-16 13:31:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-12-16 13:31:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:31:37 --> Model "Log_model" initialized
INFO - 2025-12-16 13:31:37 --> Final output sent to browser
DEBUG - 2025-12-16 13:31:37 --> Total execution time: 0.1357
INFO - 2025-12-16 07:31:59 --> Config Class Initialized
INFO - 2025-12-16 07:31:59 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:31:59 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:31:59 --> Utf8 Class Initialized
INFO - 2025-12-16 07:31:59 --> URI Class Initialized
DEBUG - 2025-12-16 07:31:59 --> No URI present. Default controller set.
INFO - 2025-12-16 07:31:59 --> Router Class Initialized
INFO - 2025-12-16 07:31:59 --> Output Class Initialized
INFO - 2025-12-16 07:31:59 --> Security Class Initialized
DEBUG - 2025-12-16 07:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:31:59 --> CSRF cookie sent
INFO - 2025-12-16 07:31:59 --> Input Class Initialized
INFO - 2025-12-16 07:31:59 --> Language Class Initialized
INFO - 2025-12-16 07:31:59 --> Loader Class Initialized
INFO - 2025-12-16 07:31:59 --> Helper loaded: url_helper
INFO - 2025-12-16 07:31:59 --> Helper loaded: text_helper
INFO - 2025-12-16 07:31:59 --> Helper loaded: string_helper
INFO - 2025-12-16 07:31:59 --> Helper loaded: form_helper
INFO - 2025-12-16 07:31:59 --> Helper loaded: download_helper
INFO - 2025-12-16 07:31:59 --> Helper loaded: security_helper
INFO - 2025-12-16 07:31:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:31:59 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:31:59 --> Form Validation Class Initialized
INFO - 2025-12-16 07:31:59 --> Model "User_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:31:59 --> Controller Class Initialized
INFO - 2025-12-16 13:31:59 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Video_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:31:59 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:31:59 --> Pagination Class Initialized
INFO - 2025-12-16 13:31:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:31:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:31:59 --> Model "Log_model" initialized
INFO - 2025-12-16 13:31:59 --> Final output sent to browser
DEBUG - 2025-12-16 13:31:59 --> Total execution time: 0.3081
INFO - 2025-12-16 07:32:52 --> Config Class Initialized
INFO - 2025-12-16 07:32:52 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:32:52 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:32:52 --> Utf8 Class Initialized
INFO - 2025-12-16 07:32:52 --> URI Class Initialized
DEBUG - 2025-12-16 07:32:52 --> No URI present. Default controller set.
INFO - 2025-12-16 07:32:52 --> Router Class Initialized
INFO - 2025-12-16 07:32:52 --> Output Class Initialized
INFO - 2025-12-16 07:32:52 --> Security Class Initialized
DEBUG - 2025-12-16 07:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:32:52 --> CSRF cookie sent
INFO - 2025-12-16 07:32:52 --> Input Class Initialized
INFO - 2025-12-16 07:32:52 --> Language Class Initialized
INFO - 2025-12-16 07:32:52 --> Loader Class Initialized
INFO - 2025-12-16 07:32:52 --> Helper loaded: url_helper
INFO - 2025-12-16 07:32:52 --> Helper loaded: text_helper
INFO - 2025-12-16 07:32:52 --> Helper loaded: string_helper
INFO - 2025-12-16 07:32:52 --> Helper loaded: form_helper
INFO - 2025-12-16 07:32:52 --> Helper loaded: download_helper
INFO - 2025-12-16 07:32:52 --> Helper loaded: security_helper
INFO - 2025-12-16 07:32:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:32:52 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:32:52 --> Form Validation Class Initialized
INFO - 2025-12-16 07:32:52 --> Model "User_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:32:52 --> Controller Class Initialized
INFO - 2025-12-16 13:32:52 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Video_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:32:52 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:32:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:32:52 --> Pagination Class Initialized
INFO - 2025-12-16 13:32:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:32:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:32:52 --> Model "Log_model" initialized
INFO - 2025-12-16 13:32:52 --> Final output sent to browser
DEBUG - 2025-12-16 13:32:52 --> Total execution time: 0.1703
INFO - 2025-12-16 07:38:32 --> Config Class Initialized
INFO - 2025-12-16 07:38:32 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:38:32 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:38:32 --> Utf8 Class Initialized
INFO - 2025-12-16 07:38:32 --> URI Class Initialized
DEBUG - 2025-12-16 07:38:32 --> No URI present. Default controller set.
INFO - 2025-12-16 07:38:32 --> Router Class Initialized
INFO - 2025-12-16 07:38:32 --> Output Class Initialized
INFO - 2025-12-16 07:38:32 --> Security Class Initialized
DEBUG - 2025-12-16 07:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:38:32 --> CSRF cookie sent
INFO - 2025-12-16 07:38:32 --> Input Class Initialized
INFO - 2025-12-16 07:38:32 --> Language Class Initialized
INFO - 2025-12-16 07:38:32 --> Loader Class Initialized
INFO - 2025-12-16 07:38:32 --> Helper loaded: url_helper
INFO - 2025-12-16 07:38:32 --> Helper loaded: text_helper
INFO - 2025-12-16 07:38:32 --> Helper loaded: string_helper
INFO - 2025-12-16 07:38:32 --> Helper loaded: form_helper
INFO - 2025-12-16 07:38:32 --> Helper loaded: download_helper
INFO - 2025-12-16 07:38:32 --> Helper loaded: security_helper
INFO - 2025-12-16 07:38:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:38:32 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:38:32 --> Form Validation Class Initialized
INFO - 2025-12-16 07:38:32 --> Model "User_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:38:32 --> Controller Class Initialized
INFO - 2025-12-16 13:38:32 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Video_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:38:32 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:38:32 --> Pagination Class Initialized
INFO - 2025-12-16 13:38:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:38:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:38:32 --> Model "Log_model" initialized
INFO - 2025-12-16 13:38:32 --> Final output sent to browser
DEBUG - 2025-12-16 13:38:32 --> Total execution time: 0.2521
INFO - 2025-12-16 07:38:39 --> Config Class Initialized
INFO - 2025-12-16 07:38:39 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:38:39 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:38:39 --> Utf8 Class Initialized
INFO - 2025-12-16 07:38:39 --> URI Class Initialized
DEBUG - 2025-12-16 07:38:39 --> No URI present. Default controller set.
INFO - 2025-12-16 07:38:39 --> Router Class Initialized
INFO - 2025-12-16 07:38:39 --> Output Class Initialized
INFO - 2025-12-16 07:38:39 --> Security Class Initialized
DEBUG - 2025-12-16 07:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:38:39 --> CSRF cookie sent
INFO - 2025-12-16 07:38:39 --> Input Class Initialized
INFO - 2025-12-16 07:38:39 --> Language Class Initialized
INFO - 2025-12-16 07:38:39 --> Loader Class Initialized
INFO - 2025-12-16 07:38:39 --> Helper loaded: url_helper
INFO - 2025-12-16 07:38:39 --> Helper loaded: text_helper
INFO - 2025-12-16 07:38:39 --> Helper loaded: string_helper
INFO - 2025-12-16 07:38:39 --> Helper loaded: form_helper
INFO - 2025-12-16 07:38:39 --> Helper loaded: download_helper
INFO - 2025-12-16 07:38:39 --> Helper loaded: security_helper
INFO - 2025-12-16 07:38:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:38:39 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:38:39 --> Form Validation Class Initialized
INFO - 2025-12-16 07:38:39 --> Model "User_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:38:39 --> Controller Class Initialized
INFO - 2025-12-16 13:38:39 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Video_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:38:39 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:38:39 --> Pagination Class Initialized
INFO - 2025-12-16 13:38:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:38:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:38:40 --> Model "Log_model" initialized
INFO - 2025-12-16 13:38:40 --> Final output sent to browser
DEBUG - 2025-12-16 13:38:40 --> Total execution time: 0.2324
INFO - 2025-12-16 07:39:02 --> Config Class Initialized
INFO - 2025-12-16 07:39:02 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:39:02 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:39:02 --> Utf8 Class Initialized
INFO - 2025-12-16 07:39:02 --> URI Class Initialized
DEBUG - 2025-12-16 07:39:02 --> No URI present. Default controller set.
INFO - 2025-12-16 07:39:02 --> Router Class Initialized
INFO - 2025-12-16 07:39:02 --> Output Class Initialized
INFO - 2025-12-16 07:39:02 --> Security Class Initialized
DEBUG - 2025-12-16 07:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:39:02 --> CSRF cookie sent
INFO - 2025-12-16 07:39:02 --> Input Class Initialized
INFO - 2025-12-16 07:39:02 --> Language Class Initialized
INFO - 2025-12-16 07:39:02 --> Loader Class Initialized
INFO - 2025-12-16 07:39:02 --> Helper loaded: url_helper
INFO - 2025-12-16 07:39:02 --> Helper loaded: text_helper
INFO - 2025-12-16 07:39:02 --> Helper loaded: string_helper
INFO - 2025-12-16 07:39:02 --> Helper loaded: form_helper
INFO - 2025-12-16 07:39:02 --> Helper loaded: download_helper
INFO - 2025-12-16 07:39:02 --> Helper loaded: security_helper
INFO - 2025-12-16 07:39:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:39:02 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:39:02 --> Form Validation Class Initialized
INFO - 2025-12-16 07:39:03 --> Model "User_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:39:03 --> Controller Class Initialized
INFO - 2025-12-16 13:39:03 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Video_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:39:03 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:39:03 --> Pagination Class Initialized
INFO - 2025-12-16 13:39:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:39:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:39:03 --> Model "Log_model" initialized
INFO - 2025-12-16 13:39:03 --> Final output sent to browser
DEBUG - 2025-12-16 13:39:03 --> Total execution time: 0.3074
INFO - 2025-12-16 07:39:21 --> Config Class Initialized
INFO - 2025-12-16 07:39:21 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:39:21 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:39:21 --> Utf8 Class Initialized
INFO - 2025-12-16 07:39:21 --> URI Class Initialized
DEBUG - 2025-12-16 07:39:21 --> No URI present. Default controller set.
INFO - 2025-12-16 07:39:21 --> Router Class Initialized
INFO - 2025-12-16 07:39:21 --> Output Class Initialized
INFO - 2025-12-16 07:39:21 --> Security Class Initialized
DEBUG - 2025-12-16 07:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:39:21 --> CSRF cookie sent
INFO - 2025-12-16 07:39:21 --> Input Class Initialized
INFO - 2025-12-16 07:39:21 --> Language Class Initialized
INFO - 2025-12-16 07:39:21 --> Loader Class Initialized
INFO - 2025-12-16 07:39:21 --> Helper loaded: url_helper
INFO - 2025-12-16 07:39:21 --> Helper loaded: text_helper
INFO - 2025-12-16 07:39:21 --> Helper loaded: string_helper
INFO - 2025-12-16 07:39:21 --> Helper loaded: form_helper
INFO - 2025-12-16 07:39:21 --> Helper loaded: download_helper
INFO - 2025-12-16 07:39:21 --> Helper loaded: security_helper
INFO - 2025-12-16 07:39:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:39:21 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:39:21 --> Form Validation Class Initialized
INFO - 2025-12-16 07:39:21 --> Model "User_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:39:21 --> Controller Class Initialized
INFO - 2025-12-16 13:39:21 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Video_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:39:21 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:39:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:39:21 --> Pagination Class Initialized
INFO - 2025-12-16 13:39:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:39:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:39:21 --> Model "Log_model" initialized
INFO - 2025-12-16 13:39:21 --> Final output sent to browser
DEBUG - 2025-12-16 13:39:21 --> Total execution time: 0.2741
INFO - 2025-12-16 07:39:27 --> Config Class Initialized
INFO - 2025-12-16 07:39:27 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:39:27 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:39:27 --> Utf8 Class Initialized
INFO - 2025-12-16 07:39:27 --> URI Class Initialized
DEBUG - 2025-12-16 07:39:27 --> No URI present. Default controller set.
INFO - 2025-12-16 07:39:27 --> Router Class Initialized
INFO - 2025-12-16 07:39:27 --> Output Class Initialized
INFO - 2025-12-16 07:39:27 --> Security Class Initialized
DEBUG - 2025-12-16 07:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:39:27 --> CSRF cookie sent
INFO - 2025-12-16 07:39:27 --> Input Class Initialized
INFO - 2025-12-16 07:39:27 --> Language Class Initialized
INFO - 2025-12-16 07:39:27 --> Loader Class Initialized
INFO - 2025-12-16 07:39:27 --> Helper loaded: url_helper
INFO - 2025-12-16 07:39:27 --> Helper loaded: text_helper
INFO - 2025-12-16 07:39:27 --> Helper loaded: string_helper
INFO - 2025-12-16 07:39:27 --> Helper loaded: form_helper
INFO - 2025-12-16 07:39:27 --> Helper loaded: download_helper
INFO - 2025-12-16 07:39:27 --> Helper loaded: security_helper
INFO - 2025-12-16 07:39:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:39:27 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:39:27 --> Form Validation Class Initialized
INFO - 2025-12-16 07:39:27 --> Model "User_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:39:27 --> Controller Class Initialized
INFO - 2025-12-16 13:39:27 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Video_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:39:27 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:39:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:39:27 --> Pagination Class Initialized
INFO - 2025-12-16 13:39:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:39:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:39:27 --> Model "Log_model" initialized
INFO - 2025-12-16 13:39:27 --> Final output sent to browser
DEBUG - 2025-12-16 13:39:27 --> Total execution time: 0.1989
INFO - 2025-12-16 07:39:42 --> Config Class Initialized
INFO - 2025-12-16 07:39:42 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:39:42 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:39:42 --> Utf8 Class Initialized
INFO - 2025-12-16 07:39:42 --> URI Class Initialized
DEBUG - 2025-12-16 07:39:42 --> No URI present. Default controller set.
INFO - 2025-12-16 07:39:42 --> Router Class Initialized
INFO - 2025-12-16 07:39:42 --> Output Class Initialized
INFO - 2025-12-16 07:39:42 --> Security Class Initialized
DEBUG - 2025-12-16 07:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:39:42 --> CSRF cookie sent
INFO - 2025-12-16 07:39:42 --> Input Class Initialized
INFO - 2025-12-16 07:39:42 --> Language Class Initialized
INFO - 2025-12-16 07:39:42 --> Loader Class Initialized
INFO - 2025-12-16 07:39:42 --> Helper loaded: url_helper
INFO - 2025-12-16 07:39:42 --> Helper loaded: text_helper
INFO - 2025-12-16 07:39:42 --> Helper loaded: string_helper
INFO - 2025-12-16 07:39:42 --> Helper loaded: form_helper
INFO - 2025-12-16 07:39:42 --> Helper loaded: download_helper
INFO - 2025-12-16 07:39:42 --> Helper loaded: security_helper
INFO - 2025-12-16 07:39:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:39:42 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:39:42 --> Form Validation Class Initialized
INFO - 2025-12-16 07:39:42 --> Model "User_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:39:42 --> Controller Class Initialized
INFO - 2025-12-16 13:39:42 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Video_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:39:42 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:39:42 --> Pagination Class Initialized
INFO - 2025-12-16 13:39:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:39:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:39:42 --> Model "Log_model" initialized
INFO - 2025-12-16 13:39:42 --> Final output sent to browser
DEBUG - 2025-12-16 13:39:42 --> Total execution time: 0.2356
INFO - 2025-12-16 07:40:01 --> Config Class Initialized
INFO - 2025-12-16 07:40:01 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:40:01 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:40:01 --> Utf8 Class Initialized
INFO - 2025-12-16 07:40:01 --> URI Class Initialized
DEBUG - 2025-12-16 07:40:01 --> No URI present. Default controller set.
INFO - 2025-12-16 07:40:01 --> Router Class Initialized
INFO - 2025-12-16 07:40:01 --> Output Class Initialized
INFO - 2025-12-16 07:40:01 --> Security Class Initialized
DEBUG - 2025-12-16 07:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:40:01 --> CSRF cookie sent
INFO - 2025-12-16 07:40:01 --> Input Class Initialized
INFO - 2025-12-16 07:40:01 --> Language Class Initialized
INFO - 2025-12-16 07:40:01 --> Loader Class Initialized
INFO - 2025-12-16 07:40:01 --> Helper loaded: url_helper
INFO - 2025-12-16 07:40:01 --> Helper loaded: text_helper
INFO - 2025-12-16 07:40:01 --> Helper loaded: string_helper
INFO - 2025-12-16 07:40:01 --> Helper loaded: form_helper
INFO - 2025-12-16 07:40:01 --> Helper loaded: download_helper
INFO - 2025-12-16 07:40:01 --> Helper loaded: security_helper
INFO - 2025-12-16 07:40:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:40:01 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:40:01 --> Form Validation Class Initialized
INFO - 2025-12-16 07:40:01 --> Model "User_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:40:01 --> Controller Class Initialized
INFO - 2025-12-16 13:40:01 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Video_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:40:01 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:40:01 --> Pagination Class Initialized
INFO - 2025-12-16 13:40:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:40:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:40:01 --> Model "Log_model" initialized
INFO - 2025-12-16 13:40:01 --> Final output sent to browser
DEBUG - 2025-12-16 13:40:01 --> Total execution time: 0.1814
INFO - 2025-12-16 07:40:05 --> Config Class Initialized
INFO - 2025-12-16 07:40:05 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:40:05 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:40:05 --> Utf8 Class Initialized
INFO - 2025-12-16 07:40:05 --> URI Class Initialized
DEBUG - 2025-12-16 07:40:05 --> No URI present. Default controller set.
INFO - 2025-12-16 07:40:05 --> Router Class Initialized
INFO - 2025-12-16 07:40:05 --> Output Class Initialized
INFO - 2025-12-16 07:40:05 --> Security Class Initialized
DEBUG - 2025-12-16 07:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:40:05 --> CSRF cookie sent
INFO - 2025-12-16 07:40:05 --> Input Class Initialized
INFO - 2025-12-16 07:40:05 --> Language Class Initialized
INFO - 2025-12-16 07:40:05 --> Loader Class Initialized
INFO - 2025-12-16 07:40:05 --> Helper loaded: url_helper
INFO - 2025-12-16 07:40:05 --> Helper loaded: text_helper
INFO - 2025-12-16 07:40:05 --> Helper loaded: string_helper
INFO - 2025-12-16 07:40:05 --> Helper loaded: form_helper
INFO - 2025-12-16 07:40:05 --> Helper loaded: download_helper
INFO - 2025-12-16 07:40:05 --> Helper loaded: security_helper
INFO - 2025-12-16 07:40:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:40:05 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:40:05 --> Form Validation Class Initialized
INFO - 2025-12-16 07:40:05 --> Model "User_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:40:05 --> Controller Class Initialized
INFO - 2025-12-16 13:40:05 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Video_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:40:05 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:40:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:40:05 --> Pagination Class Initialized
INFO - 2025-12-16 13:40:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:40:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:40:06 --> Model "Log_model" initialized
INFO - 2025-12-16 13:40:06 --> Final output sent to browser
DEBUG - 2025-12-16 13:40:06 --> Total execution time: 0.1627
INFO - 2025-12-16 07:40:17 --> Config Class Initialized
INFO - 2025-12-16 07:40:17 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:40:17 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:40:17 --> Utf8 Class Initialized
INFO - 2025-12-16 07:40:17 --> URI Class Initialized
DEBUG - 2025-12-16 07:40:17 --> No URI present. Default controller set.
INFO - 2025-12-16 07:40:17 --> Router Class Initialized
INFO - 2025-12-16 07:40:17 --> Output Class Initialized
INFO - 2025-12-16 07:40:17 --> Security Class Initialized
DEBUG - 2025-12-16 07:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:40:17 --> CSRF cookie sent
INFO - 2025-12-16 07:40:17 --> Input Class Initialized
INFO - 2025-12-16 07:40:17 --> Language Class Initialized
INFO - 2025-12-16 07:40:17 --> Loader Class Initialized
INFO - 2025-12-16 07:40:17 --> Helper loaded: url_helper
INFO - 2025-12-16 07:40:17 --> Helper loaded: text_helper
INFO - 2025-12-16 07:40:17 --> Helper loaded: string_helper
INFO - 2025-12-16 07:40:17 --> Helper loaded: form_helper
INFO - 2025-12-16 07:40:17 --> Helper loaded: download_helper
INFO - 2025-12-16 07:40:17 --> Helper loaded: security_helper
INFO - 2025-12-16 07:40:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:40:17 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:40:17 --> Form Validation Class Initialized
INFO - 2025-12-16 07:40:17 --> Model "User_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:40:17 --> Controller Class Initialized
INFO - 2025-12-16 13:40:17 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Video_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:40:17 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:40:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:40:17 --> Pagination Class Initialized
INFO - 2025-12-16 13:40:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:40:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:40:17 --> Model "Log_model" initialized
INFO - 2025-12-16 13:40:17 --> Final output sent to browser
DEBUG - 2025-12-16 13:40:17 --> Total execution time: 0.2577
INFO - 2025-12-16 07:40:33 --> Config Class Initialized
INFO - 2025-12-16 07:40:33 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:40:33 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:40:33 --> Utf8 Class Initialized
INFO - 2025-12-16 07:40:33 --> URI Class Initialized
DEBUG - 2025-12-16 07:40:33 --> No URI present. Default controller set.
INFO - 2025-12-16 07:40:33 --> Router Class Initialized
INFO - 2025-12-16 07:40:33 --> Output Class Initialized
INFO - 2025-12-16 07:40:33 --> Security Class Initialized
DEBUG - 2025-12-16 07:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:40:33 --> CSRF cookie sent
INFO - 2025-12-16 07:40:33 --> Input Class Initialized
INFO - 2025-12-16 07:40:33 --> Language Class Initialized
INFO - 2025-12-16 07:40:33 --> Loader Class Initialized
INFO - 2025-12-16 07:40:33 --> Helper loaded: url_helper
INFO - 2025-12-16 07:40:33 --> Helper loaded: text_helper
INFO - 2025-12-16 07:40:33 --> Helper loaded: string_helper
INFO - 2025-12-16 07:40:33 --> Helper loaded: form_helper
INFO - 2025-12-16 07:40:33 --> Helper loaded: download_helper
INFO - 2025-12-16 07:40:33 --> Helper loaded: security_helper
INFO - 2025-12-16 07:40:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:40:33 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:40:33 --> Form Validation Class Initialized
INFO - 2025-12-16 07:40:33 --> Model "User_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:40:33 --> Controller Class Initialized
INFO - 2025-12-16 13:40:33 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Video_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:40:33 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:40:33 --> Pagination Class Initialized
INFO - 2025-12-16 13:40:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:40:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:40:33 --> Model "Log_model" initialized
INFO - 2025-12-16 13:40:33 --> Final output sent to browser
DEBUG - 2025-12-16 13:40:33 --> Total execution time: 0.2107
INFO - 2025-12-16 07:40:45 --> Config Class Initialized
INFO - 2025-12-16 07:40:45 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:40:45 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:40:45 --> Utf8 Class Initialized
INFO - 2025-12-16 07:40:45 --> URI Class Initialized
DEBUG - 2025-12-16 07:40:45 --> No URI present. Default controller set.
INFO - 2025-12-16 07:40:45 --> Router Class Initialized
INFO - 2025-12-16 07:40:45 --> Output Class Initialized
INFO - 2025-12-16 07:40:45 --> Security Class Initialized
DEBUG - 2025-12-16 07:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:40:45 --> CSRF cookie sent
INFO - 2025-12-16 07:40:45 --> Input Class Initialized
INFO - 2025-12-16 07:40:45 --> Language Class Initialized
INFO - 2025-12-16 07:40:45 --> Loader Class Initialized
INFO - 2025-12-16 07:40:45 --> Helper loaded: url_helper
INFO - 2025-12-16 07:40:45 --> Helper loaded: text_helper
INFO - 2025-12-16 07:40:45 --> Helper loaded: string_helper
INFO - 2025-12-16 07:40:45 --> Helper loaded: form_helper
INFO - 2025-12-16 07:40:45 --> Helper loaded: download_helper
INFO - 2025-12-16 07:40:45 --> Helper loaded: security_helper
INFO - 2025-12-16 07:40:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:40:45 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:40:45 --> Form Validation Class Initialized
INFO - 2025-12-16 07:40:45 --> Model "User_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:40:45 --> Controller Class Initialized
INFO - 2025-12-16 13:40:45 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Video_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:40:45 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:40:45 --> Pagination Class Initialized
INFO - 2025-12-16 13:40:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:40:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:40:45 --> Model "Log_model" initialized
INFO - 2025-12-16 13:40:45 --> Final output sent to browser
DEBUG - 2025-12-16 13:40:45 --> Total execution time: 0.2124
INFO - 2025-12-16 07:40:56 --> Config Class Initialized
INFO - 2025-12-16 07:40:56 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:40:56 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:40:56 --> Utf8 Class Initialized
INFO - 2025-12-16 07:40:56 --> URI Class Initialized
DEBUG - 2025-12-16 07:40:56 --> No URI present. Default controller set.
INFO - 2025-12-16 07:40:56 --> Router Class Initialized
INFO - 2025-12-16 07:40:56 --> Output Class Initialized
INFO - 2025-12-16 07:40:56 --> Security Class Initialized
DEBUG - 2025-12-16 07:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:40:56 --> CSRF cookie sent
INFO - 2025-12-16 07:40:56 --> Input Class Initialized
INFO - 2025-12-16 07:40:56 --> Language Class Initialized
INFO - 2025-12-16 07:40:56 --> Loader Class Initialized
INFO - 2025-12-16 07:40:56 --> Helper loaded: url_helper
INFO - 2025-12-16 07:40:56 --> Helper loaded: text_helper
INFO - 2025-12-16 07:40:56 --> Helper loaded: string_helper
INFO - 2025-12-16 07:40:56 --> Helper loaded: form_helper
INFO - 2025-12-16 07:40:56 --> Helper loaded: download_helper
INFO - 2025-12-16 07:40:56 --> Helper loaded: security_helper
INFO - 2025-12-16 07:40:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:40:56 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:40:56 --> Form Validation Class Initialized
INFO - 2025-12-16 07:40:56 --> Model "User_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:40:56 --> Controller Class Initialized
INFO - 2025-12-16 13:40:56 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Video_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:40:56 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:40:56 --> Pagination Class Initialized
INFO - 2025-12-16 13:40:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:40:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:40:56 --> Model "Log_model" initialized
INFO - 2025-12-16 13:40:56 --> Final output sent to browser
DEBUG - 2025-12-16 13:40:56 --> Total execution time: 0.2665
INFO - 2025-12-16 07:41:09 --> Config Class Initialized
INFO - 2025-12-16 07:41:09 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:41:09 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:41:09 --> Utf8 Class Initialized
INFO - 2025-12-16 07:41:09 --> URI Class Initialized
DEBUG - 2025-12-16 07:41:09 --> No URI present. Default controller set.
INFO - 2025-12-16 07:41:09 --> Router Class Initialized
INFO - 2025-12-16 07:41:09 --> Output Class Initialized
INFO - 2025-12-16 07:41:09 --> Security Class Initialized
DEBUG - 2025-12-16 07:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:41:09 --> CSRF cookie sent
INFO - 2025-12-16 07:41:09 --> Input Class Initialized
INFO - 2025-12-16 07:41:09 --> Language Class Initialized
INFO - 2025-12-16 07:41:09 --> Loader Class Initialized
INFO - 2025-12-16 07:41:09 --> Helper loaded: url_helper
INFO - 2025-12-16 07:41:09 --> Helper loaded: text_helper
INFO - 2025-12-16 07:41:09 --> Helper loaded: string_helper
INFO - 2025-12-16 07:41:09 --> Helper loaded: form_helper
INFO - 2025-12-16 07:41:09 --> Helper loaded: download_helper
INFO - 2025-12-16 07:41:09 --> Helper loaded: security_helper
INFO - 2025-12-16 07:41:09 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:41:09 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:41:09 --> Form Validation Class Initialized
INFO - 2025-12-16 07:41:09 --> Model "User_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:41:09 --> Controller Class Initialized
INFO - 2025-12-16 13:41:09 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Video_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:41:09 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:41:10 --> Pagination Class Initialized
INFO - 2025-12-16 13:41:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:41:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:41:10 --> Model "Log_model" initialized
INFO - 2025-12-16 13:41:10 --> Final output sent to browser
DEBUG - 2025-12-16 13:41:10 --> Total execution time: 0.2944
INFO - 2025-12-16 07:41:41 --> Config Class Initialized
INFO - 2025-12-16 07:41:41 --> Hooks Class Initialized
DEBUG - 2025-12-16 07:41:41 --> UTF-8 Support Enabled
INFO - 2025-12-16 07:41:41 --> Utf8 Class Initialized
INFO - 2025-12-16 07:41:41 --> URI Class Initialized
DEBUG - 2025-12-16 07:41:41 --> No URI present. Default controller set.
INFO - 2025-12-16 07:41:41 --> Router Class Initialized
INFO - 2025-12-16 07:41:41 --> Output Class Initialized
INFO - 2025-12-16 07:41:41 --> Security Class Initialized
DEBUG - 2025-12-16 07:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-16 07:41:41 --> CSRF cookie sent
INFO - 2025-12-16 07:41:41 --> Input Class Initialized
INFO - 2025-12-16 07:41:41 --> Language Class Initialized
INFO - 2025-12-16 07:41:41 --> Loader Class Initialized
INFO - 2025-12-16 07:41:41 --> Helper loaded: url_helper
INFO - 2025-12-16 07:41:41 --> Helper loaded: text_helper
INFO - 2025-12-16 07:41:41 --> Helper loaded: string_helper
INFO - 2025-12-16 07:41:41 --> Helper loaded: form_helper
INFO - 2025-12-16 07:41:41 --> Helper loaded: download_helper
INFO - 2025-12-16 07:41:41 --> Helper loaded: security_helper
INFO - 2025-12-16 07:41:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-12-16 07:41:41 --> Database Driver Class Initialized
DEBUG - 2025-12-16 07:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-12-16 07:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-16 07:41:41 --> Form Validation Class Initialized
INFO - 2025-12-16 07:41:41 --> Model "User_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Kunjungan_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Nav_model" initialized
INFO - 2025-12-16 13:41:41 --> Controller Class Initialized
INFO - 2025-12-16 13:41:41 --> Model "Berita_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Galeri_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Video_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Agenda_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Tautan_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Mitra_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Jurusan_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Prodi_model" initialized
INFO - 2025-12-16 13:41:41 --> Model "Testimoni_model" initialized
INFO - 2025-12-16 13:41:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-12-16 13:41:41 --> Pagination Class Initialized
INFO - 2025-12-16 13:41:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-12-16 13:41:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-12-16 13:41:41 --> Model "Log_model" initialized
INFO - 2025-12-16 13:41:41 --> Final output sent to browser
DEBUG - 2025-12-16 13:41:41 --> Total execution time: 0.2819
