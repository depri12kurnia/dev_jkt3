<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-06 08:57:13 --> Config Class Initialized
INFO - 2025-11-06 08:57:13 --> Hooks Class Initialized
DEBUG - 2025-11-06 08:57:14 --> UTF-8 Support Enabled
INFO - 2025-11-06 08:57:14 --> Utf8 Class Initialized
INFO - 2025-11-06 08:57:14 --> URI Class Initialized
DEBUG - 2025-11-06 08:57:14 --> No URI present. Default controller set.
INFO - 2025-11-06 08:57:14 --> Router Class Initialized
INFO - 2025-11-06 08:57:14 --> Output Class Initialized
INFO - 2025-11-06 08:57:14 --> Security Class Initialized
DEBUG - 2025-11-06 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-06 08:57:14 --> CSRF cookie sent
INFO - 2025-11-06 08:57:14 --> Input Class Initialized
INFO - 2025-11-06 08:57:14 --> Language Class Initialized
INFO - 2025-11-06 08:57:15 --> Loader Class Initialized
INFO - 2025-11-06 08:57:15 --> Helper loaded: url_helper
INFO - 2025-11-06 08:57:15 --> Helper loaded: text_helper
INFO - 2025-11-06 08:57:15 --> Helper loaded: string_helper
INFO - 2025-11-06 08:57:15 --> Helper loaded: form_helper
INFO - 2025-11-06 08:57:15 --> Helper loaded: download_helper
INFO - 2025-11-06 08:57:15 --> Helper loaded: security_helper
INFO - 2025-11-06 08:57:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-06 08:57:16 --> Database Driver Class Initialized
DEBUG - 2025-11-06 08:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-06 08:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-06 08:57:16 --> Form Validation Class Initialized
INFO - 2025-11-06 08:57:16 --> Model "User_model" initialized
INFO - 2025-11-06 14:57:16 --> Model "Kunjungan_model" initialized
INFO - 2025-11-06 14:57:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-06 14:57:17 --> Model "Nav_model" initialized
INFO - 2025-11-06 14:57:17 --> Controller Class Initialized
INFO - 2025-11-06 14:57:17 --> Model "Berita_model" initialized
INFO - 2025-11-06 14:57:17 --> Model "Galeri_model" initialized
INFO - 2025-11-06 14:57:17 --> Model "Video_model" initialized
INFO - 2025-11-06 14:57:17 --> Model "Agenda_model" initialized
INFO - 2025-11-06 14:57:17 --> Model "Tautan_model" initialized
INFO - 2025-11-06 14:57:17 --> Model "Mitra_model" initialized
INFO - 2025-11-06 14:57:17 --> Model "Jurusan_model" initialized
INFO - 2025-11-06 14:57:17 --> Model "Prodi_model" initialized
INFO - 2025-11-06 14:57:17 --> Model "Testimoni_model" initialized
INFO - 2025-11-06 14:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-06 14:57:18 --> Pagination Class Initialized
INFO - 2025-11-06 14:57:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-06 14:57:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-06 14:57:21 --> Model "Log_model" initialized
INFO - 2025-11-06 14:57:21 --> Final output sent to browser
DEBUG - 2025-11-06 14:57:21 --> Total execution time: 8.1135
INFO - 2025-11-06 08:57:33 --> Config Class Initialized
INFO - 2025-11-06 08:57:33 --> Hooks Class Initialized
DEBUG - 2025-11-06 08:57:33 --> UTF-8 Support Enabled
INFO - 2025-11-06 08:57:33 --> Utf8 Class Initialized
INFO - 2025-11-06 08:57:33 --> URI Class Initialized
DEBUG - 2025-11-06 08:57:33 --> No URI present. Default controller set.
INFO - 2025-11-06 08:57:33 --> Router Class Initialized
INFO - 2025-11-06 08:57:33 --> Output Class Initialized
INFO - 2025-11-06 08:57:33 --> Security Class Initialized
DEBUG - 2025-11-06 08:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-06 08:57:33 --> CSRF cookie sent
INFO - 2025-11-06 08:57:33 --> Input Class Initialized
INFO - 2025-11-06 08:57:33 --> Language Class Initialized
INFO - 2025-11-06 08:57:33 --> Loader Class Initialized
INFO - 2025-11-06 08:57:33 --> Helper loaded: url_helper
INFO - 2025-11-06 08:57:33 --> Helper loaded: text_helper
INFO - 2025-11-06 08:57:33 --> Helper loaded: string_helper
INFO - 2025-11-06 08:57:33 --> Helper loaded: form_helper
INFO - 2025-11-06 08:57:33 --> Helper loaded: download_helper
INFO - 2025-11-06 08:57:33 --> Helper loaded: security_helper
INFO - 2025-11-06 08:57:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-06 08:57:33 --> Database Driver Class Initialized
DEBUG - 2025-11-06 08:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-06 08:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-06 08:57:33 --> Form Validation Class Initialized
INFO - 2025-11-06 08:57:33 --> Model "User_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Kunjungan_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Nav_model" initialized
INFO - 2025-11-06 14:57:33 --> Controller Class Initialized
INFO - 2025-11-06 14:57:33 --> Model "Berita_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Galeri_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Video_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Agenda_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Tautan_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Mitra_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Jurusan_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Prodi_model" initialized
INFO - 2025-11-06 14:57:33 --> Model "Testimoni_model" initialized
INFO - 2025-11-06 14:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-06 14:57:33 --> Pagination Class Initialized
INFO - 2025-11-06 14:57:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-06 14:57:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-06 14:57:33 --> Model "Log_model" initialized
INFO - 2025-11-06 14:57:33 --> Final output sent to browser
DEBUG - 2025-11-06 14:57:33 --> Total execution time: 0.1098
INFO - 2025-11-06 08:57:45 --> Config Class Initialized
INFO - 2025-11-06 08:57:45 --> Hooks Class Initialized
DEBUG - 2025-11-06 08:57:45 --> UTF-8 Support Enabled
INFO - 2025-11-06 08:57:45 --> Utf8 Class Initialized
INFO - 2025-11-06 08:57:45 --> URI Class Initialized
DEBUG - 2025-11-06 08:57:45 --> No URI present. Default controller set.
INFO - 2025-11-06 08:57:45 --> Router Class Initialized
INFO - 2025-11-06 08:57:45 --> Output Class Initialized
INFO - 2025-11-06 08:57:45 --> Security Class Initialized
DEBUG - 2025-11-06 08:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-06 08:57:45 --> CSRF cookie sent
INFO - 2025-11-06 08:57:45 --> Input Class Initialized
INFO - 2025-11-06 08:57:45 --> Language Class Initialized
INFO - 2025-11-06 08:57:45 --> Loader Class Initialized
INFO - 2025-11-06 08:57:45 --> Helper loaded: url_helper
INFO - 2025-11-06 08:57:45 --> Helper loaded: text_helper
INFO - 2025-11-06 08:57:45 --> Helper loaded: string_helper
INFO - 2025-11-06 08:57:45 --> Helper loaded: form_helper
INFO - 2025-11-06 08:57:45 --> Helper loaded: download_helper
INFO - 2025-11-06 08:57:45 --> Helper loaded: security_helper
INFO - 2025-11-06 08:57:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-06 08:57:45 --> Database Driver Class Initialized
DEBUG - 2025-11-06 08:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-06 08:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-06 08:57:45 --> Form Validation Class Initialized
INFO - 2025-11-06 08:57:45 --> Model "User_model" initialized
INFO - 2025-11-06 14:57:45 --> Model "Kunjungan_model" initialized
INFO - 2025-11-06 14:57:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-06 14:57:45 --> Model "Nav_model" initialized
INFO - 2025-11-06 14:57:45 --> Controller Class Initialized
INFO - 2025-11-06 14:57:45 --> Model "Berita_model" initialized
INFO - 2025-11-06 14:57:45 --> Model "Galeri_model" initialized
INFO - 2025-11-06 14:57:45 --> Model "Video_model" initialized
INFO - 2025-11-06 14:57:45 --> Model "Agenda_model" initialized
INFO - 2025-11-06 14:57:45 --> Model "Tautan_model" initialized
INFO - 2025-11-06 14:57:46 --> Model "Mitra_model" initialized
INFO - 2025-11-06 14:57:46 --> Model "Jurusan_model" initialized
INFO - 2025-11-06 14:57:46 --> Model "Prodi_model" initialized
INFO - 2025-11-06 14:57:46 --> Model "Testimoni_model" initialized
INFO - 2025-11-06 14:57:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-06 14:57:46 --> Pagination Class Initialized
INFO - 2025-11-06 14:57:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-06 14:57:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-06 14:57:46 --> Model "Log_model" initialized
INFO - 2025-11-06 14:57:46 --> Final output sent to browser
DEBUG - 2025-11-06 14:57:46 --> Total execution time: 0.2220
INFO - 2025-11-06 08:57:47 --> Config Class Initialized
INFO - 2025-11-06 08:57:47 --> Hooks Class Initialized
DEBUG - 2025-11-06 08:57:47 --> UTF-8 Support Enabled
INFO - 2025-11-06 08:57:47 --> Utf8 Class Initialized
INFO - 2025-11-06 08:57:47 --> URI Class Initialized
DEBUG - 2025-11-06 08:57:47 --> No URI present. Default controller set.
INFO - 2025-11-06 08:57:47 --> Router Class Initialized
INFO - 2025-11-06 08:57:47 --> Output Class Initialized
INFO - 2025-11-06 08:57:47 --> Security Class Initialized
DEBUG - 2025-11-06 08:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-06 08:57:47 --> CSRF cookie sent
INFO - 2025-11-06 08:57:47 --> Input Class Initialized
INFO - 2025-11-06 08:57:47 --> Language Class Initialized
INFO - 2025-11-06 08:57:47 --> Loader Class Initialized
INFO - 2025-11-06 08:57:47 --> Helper loaded: url_helper
INFO - 2025-11-06 08:57:47 --> Helper loaded: text_helper
INFO - 2025-11-06 08:57:47 --> Helper loaded: string_helper
INFO - 2025-11-06 08:57:47 --> Helper loaded: form_helper
INFO - 2025-11-06 08:57:47 --> Helper loaded: download_helper
INFO - 2025-11-06 08:57:47 --> Helper loaded: security_helper
INFO - 2025-11-06 08:57:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-11-06 08:57:47 --> Database Driver Class Initialized
DEBUG - 2025-11-06 08:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-06 08:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-06 08:57:47 --> Form Validation Class Initialized
INFO - 2025-11-06 08:57:47 --> Model "User_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Kunjungan_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Nav_model" initialized
INFO - 2025-11-06 14:57:47 --> Controller Class Initialized
INFO - 2025-11-06 14:57:47 --> Model "Berita_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Galeri_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Video_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Agenda_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Tautan_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Mitra_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Jurusan_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Prodi_model" initialized
INFO - 2025-11-06 14:57:47 --> Model "Testimoni_model" initialized
INFO - 2025-11-06 14:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-06 14:57:48 --> Pagination Class Initialized
INFO - 2025-11-06 14:57:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-11-06 14:57:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-11-06 14:57:48 --> Model "Log_model" initialized
INFO - 2025-11-06 14:57:48 --> Final output sent to browser
DEBUG - 2025-11-06 14:57:48 --> Total execution time: 0.1477
