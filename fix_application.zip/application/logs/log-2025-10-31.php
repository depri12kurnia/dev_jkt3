<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-31 08:48:17 --> Config Class Initialized
INFO - 2025-10-31 08:48:17 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:48:17 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:48:17 --> Utf8 Class Initialized
INFO - 2025-10-31 08:48:17 --> URI Class Initialized
DEBUG - 2025-10-31 08:48:17 --> No URI present. Default controller set.
INFO - 2025-10-31 08:48:17 --> Router Class Initialized
INFO - 2025-10-31 08:48:17 --> Output Class Initialized
INFO - 2025-10-31 08:48:17 --> Security Class Initialized
DEBUG - 2025-10-31 08:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:48:18 --> CSRF cookie sent
INFO - 2025-10-31 08:48:18 --> Input Class Initialized
INFO - 2025-10-31 08:48:18 --> Language Class Initialized
INFO - 2025-10-31 08:48:18 --> Loader Class Initialized
INFO - 2025-10-31 08:48:18 --> Helper loaded: url_helper
INFO - 2025-10-31 08:48:18 --> Helper loaded: text_helper
INFO - 2025-10-31 08:48:18 --> Helper loaded: string_helper
INFO - 2025-10-31 08:48:18 --> Helper loaded: form_helper
INFO - 2025-10-31 08:48:18 --> Helper loaded: download_helper
INFO - 2025-10-31 08:48:18 --> Helper loaded: security_helper
INFO - 2025-10-31 08:48:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:48:19 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:48:19 --> Form Validation Class Initialized
INFO - 2025-10-31 08:48:19 --> Model "User_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:48:20 --> Controller Class Initialized
INFO - 2025-10-31 14:48:20 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Video_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:48:20 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:48:21 --> Pagination Class Initialized
INFO - 2025-10-31 14:48:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:48:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:48:23 --> Model "Log_model" initialized
INFO - 2025-10-31 14:48:23 --> Final output sent to browser
DEBUG - 2025-10-31 14:48:23 --> Total execution time: 6.7187
INFO - 2025-10-31 08:48:44 --> Config Class Initialized
INFO - 2025-10-31 08:48:44 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:48:44 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:48:44 --> Utf8 Class Initialized
INFO - 2025-10-31 08:48:44 --> URI Class Initialized
INFO - 2025-10-31 08:48:44 --> Router Class Initialized
INFO - 2025-10-31 08:48:44 --> Output Class Initialized
INFO - 2025-10-31 08:48:44 --> Security Class Initialized
DEBUG - 2025-10-31 08:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:48:44 --> CSRF cookie sent
INFO - 2025-10-31 08:48:44 --> Input Class Initialized
INFO - 2025-10-31 08:48:44 --> Language Class Initialized
INFO - 2025-10-31 08:48:44 --> Loader Class Initialized
INFO - 2025-10-31 08:48:44 --> Helper loaded: url_helper
INFO - 2025-10-31 08:48:44 --> Helper loaded: text_helper
INFO - 2025-10-31 08:48:44 --> Helper loaded: string_helper
INFO - 2025-10-31 08:48:44 --> Helper loaded: form_helper
INFO - 2025-10-31 08:48:44 --> Helper loaded: download_helper
INFO - 2025-10-31 08:48:44 --> Helper loaded: security_helper
INFO - 2025-10-31 08:48:44 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:48:44 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:48:44 --> Form Validation Class Initialized
INFO - 2025-10-31 08:48:44 --> Model "User_model" initialized
INFO - 2025-10-31 14:48:44 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:48:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:48:44 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:48:44 --> Controller Class Initialized
INFO - 2025-10-31 14:48:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\kebijakan-cookies.php
INFO - 2025-10-31 14:48:44 --> Model "Log_model" initialized
INFO - 2025-10-31 14:48:44 --> Final output sent to browser
DEBUG - 2025-10-31 14:48:44 --> Total execution time: 0.0961
INFO - 2025-10-31 08:48:50 --> Config Class Initialized
INFO - 2025-10-31 08:48:50 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:48:50 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:48:50 --> Utf8 Class Initialized
INFO - 2025-10-31 08:48:50 --> URI Class Initialized
DEBUG - 2025-10-31 08:48:50 --> No URI present. Default controller set.
INFO - 2025-10-31 08:48:50 --> Router Class Initialized
INFO - 2025-10-31 08:48:50 --> Output Class Initialized
INFO - 2025-10-31 08:48:50 --> Security Class Initialized
DEBUG - 2025-10-31 08:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:48:50 --> CSRF cookie sent
INFO - 2025-10-31 08:48:50 --> Input Class Initialized
INFO - 2025-10-31 08:48:50 --> Language Class Initialized
INFO - 2025-10-31 08:48:50 --> Loader Class Initialized
INFO - 2025-10-31 08:48:50 --> Helper loaded: url_helper
INFO - 2025-10-31 08:48:50 --> Helper loaded: text_helper
INFO - 2025-10-31 08:48:50 --> Helper loaded: string_helper
INFO - 2025-10-31 08:48:50 --> Helper loaded: form_helper
INFO - 2025-10-31 08:48:50 --> Helper loaded: download_helper
INFO - 2025-10-31 08:48:50 --> Helper loaded: security_helper
INFO - 2025-10-31 08:48:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:48:50 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:48:50 --> Form Validation Class Initialized
INFO - 2025-10-31 08:48:50 --> Model "User_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:48:50 --> Controller Class Initialized
INFO - 2025-10-31 14:48:50 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Video_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:48:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:48:50 --> Pagination Class Initialized
INFO - 2025-10-31 14:48:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:48:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:48:50 --> Model "Log_model" initialized
INFO - 2025-10-31 14:48:50 --> Final output sent to browser
DEBUG - 2025-10-31 14:48:50 --> Total execution time: 0.0949
INFO - 2025-10-31 08:48:57 --> Config Class Initialized
INFO - 2025-10-31 08:48:57 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:48:57 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:48:57 --> Utf8 Class Initialized
INFO - 2025-10-31 08:48:57 --> URI Class Initialized
INFO - 2025-10-31 08:48:57 --> Router Class Initialized
INFO - 2025-10-31 08:48:57 --> Output Class Initialized
INFO - 2025-10-31 08:48:57 --> Security Class Initialized
DEBUG - 2025-10-31 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:48:57 --> CSRF cookie sent
INFO - 2025-10-31 08:48:57 --> Input Class Initialized
INFO - 2025-10-31 08:48:57 --> Language Class Initialized
INFO - 2025-10-31 08:48:57 --> Loader Class Initialized
INFO - 2025-10-31 08:48:57 --> Helper loaded: url_helper
INFO - 2025-10-31 08:48:57 --> Helper loaded: text_helper
INFO - 2025-10-31 08:48:57 --> Helper loaded: string_helper
INFO - 2025-10-31 08:48:57 --> Helper loaded: form_helper
INFO - 2025-10-31 08:48:57 --> Helper loaded: download_helper
INFO - 2025-10-31 08:48:57 --> Helper loaded: security_helper
INFO - 2025-10-31 08:48:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:48:57 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:48:57 --> Form Validation Class Initialized
INFO - 2025-10-31 08:48:57 --> Model "User_model" initialized
INFO - 2025-10-31 14:48:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:48:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:48:57 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:48:57 --> Controller Class Initialized
INFO - 2025-10-31 14:48:57 --> Model "Pusat_model" initialized
INFO - 2025-10-31 14:48:57 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:48:57 --> Model "Sdm_model" initialized
INFO - 2025-10-31 14:48:57 --> Model "Sdm_pusat_model" initialized
INFO - 2025-10-31 14:48:57 --> Query SDM berhasil untuk pusat: Pusat Penjamin Mutu, Total: 1
INFO - 2025-10-31 14:48:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-10-31 14:48:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:48:57 --> Model "Log_model" initialized
INFO - 2025-10-31 14:48:57 --> Final output sent to browser
DEBUG - 2025-10-31 14:48:57 --> Total execution time: 0.3869
INFO - 2025-10-31 08:49:18 --> Config Class Initialized
INFO - 2025-10-31 08:49:18 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:49:18 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:49:18 --> Utf8 Class Initialized
INFO - 2025-10-31 08:49:18 --> URI Class Initialized
DEBUG - 2025-10-31 08:49:18 --> No URI present. Default controller set.
INFO - 2025-10-31 08:49:18 --> Router Class Initialized
INFO - 2025-10-31 08:49:18 --> Output Class Initialized
INFO - 2025-10-31 08:49:18 --> Security Class Initialized
DEBUG - 2025-10-31 08:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:49:18 --> CSRF cookie sent
INFO - 2025-10-31 08:49:18 --> Input Class Initialized
INFO - 2025-10-31 08:49:18 --> Language Class Initialized
INFO - 2025-10-31 08:49:18 --> Loader Class Initialized
INFO - 2025-10-31 08:49:18 --> Helper loaded: url_helper
INFO - 2025-10-31 08:49:18 --> Helper loaded: text_helper
INFO - 2025-10-31 08:49:18 --> Helper loaded: string_helper
INFO - 2025-10-31 08:49:18 --> Helper loaded: form_helper
INFO - 2025-10-31 08:49:18 --> Helper loaded: download_helper
INFO - 2025-10-31 08:49:18 --> Helper loaded: security_helper
INFO - 2025-10-31 08:49:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:49:18 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:49:18 --> Form Validation Class Initialized
INFO - 2025-10-31 08:49:18 --> Model "User_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:49:18 --> Controller Class Initialized
INFO - 2025-10-31 14:49:18 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Video_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:49:18 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:49:18 --> Pagination Class Initialized
INFO - 2025-10-31 14:49:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:49:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:49:18 --> Model "Log_model" initialized
INFO - 2025-10-31 14:49:18 --> Final output sent to browser
DEBUG - 2025-10-31 14:49:18 --> Total execution time: 0.1069
INFO - 2025-10-31 08:49:34 --> Config Class Initialized
INFO - 2025-10-31 08:49:34 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:49:34 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:49:34 --> Utf8 Class Initialized
INFO - 2025-10-31 08:49:34 --> URI Class Initialized
DEBUG - 2025-10-31 08:49:34 --> No URI present. Default controller set.
INFO - 2025-10-31 08:49:34 --> Router Class Initialized
INFO - 2025-10-31 08:49:34 --> Output Class Initialized
INFO - 2025-10-31 08:49:34 --> Security Class Initialized
DEBUG - 2025-10-31 08:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:49:34 --> CSRF cookie sent
INFO - 2025-10-31 08:49:34 --> Input Class Initialized
INFO - 2025-10-31 08:49:34 --> Language Class Initialized
INFO - 2025-10-31 08:49:34 --> Loader Class Initialized
INFO - 2025-10-31 08:49:34 --> Helper loaded: url_helper
INFO - 2025-10-31 08:49:34 --> Helper loaded: text_helper
INFO - 2025-10-31 08:49:34 --> Helper loaded: string_helper
INFO - 2025-10-31 08:49:34 --> Helper loaded: form_helper
INFO - 2025-10-31 08:49:34 --> Helper loaded: download_helper
INFO - 2025-10-31 08:49:34 --> Helper loaded: security_helper
INFO - 2025-10-31 08:49:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:49:34 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:49:34 --> Form Validation Class Initialized
INFO - 2025-10-31 08:49:34 --> Model "User_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:49:34 --> Controller Class Initialized
INFO - 2025-10-31 14:49:34 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Video_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:49:34 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:49:34 --> Pagination Class Initialized
INFO - 2025-10-31 14:49:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:49:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:49:34 --> Model "Log_model" initialized
INFO - 2025-10-31 14:49:34 --> Final output sent to browser
DEBUG - 2025-10-31 14:49:34 --> Total execution time: 0.0947
INFO - 2025-10-31 08:50:16 --> Config Class Initialized
INFO - 2025-10-31 08:50:16 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:50:16 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:50:16 --> Utf8 Class Initialized
INFO - 2025-10-31 08:50:16 --> URI Class Initialized
INFO - 2025-10-31 08:50:16 --> Router Class Initialized
INFO - 2025-10-31 08:50:16 --> Output Class Initialized
INFO - 2025-10-31 08:50:16 --> Security Class Initialized
DEBUG - 2025-10-31 08:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:50:16 --> CSRF cookie sent
INFO - 2025-10-31 08:50:16 --> Input Class Initialized
INFO - 2025-10-31 08:50:16 --> Language Class Initialized
INFO - 2025-10-31 08:50:16 --> Loader Class Initialized
INFO - 2025-10-31 08:50:16 --> Helper loaded: url_helper
INFO - 2025-10-31 08:50:16 --> Helper loaded: text_helper
INFO - 2025-10-31 08:50:16 --> Helper loaded: string_helper
INFO - 2025-10-31 08:50:16 --> Helper loaded: form_helper
INFO - 2025-10-31 08:50:16 --> Helper loaded: download_helper
INFO - 2025-10-31 08:50:16 --> Helper loaded: security_helper
INFO - 2025-10-31 08:50:16 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:50:16 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:50:16 --> Form Validation Class Initialized
INFO - 2025-10-31 08:50:16 --> Model "User_model" initialized
INFO - 2025-10-31 14:50:16 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:50:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:50:16 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:50:16 --> Controller Class Initialized
INFO - 2025-10-31 14:50:16 --> Model "Download_model" initialized
INFO - 2025-10-31 14:50:16 --> Model "Kategori_download_model" initialized
INFO - 2025-10-31 14:50:17 --> Model "Jenis_download_model" initialized
INFO - 2025-10-31 14:50:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2025-10-31 14:50:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:50:17 --> Model "Log_model" initialized
INFO - 2025-10-31 14:50:17 --> Final output sent to browser
DEBUG - 2025-10-31 14:50:17 --> Total execution time: 0.4602
INFO - 2025-10-31 08:50:29 --> Config Class Initialized
INFO - 2025-10-31 08:50:29 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:50:29 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:50:29 --> Utf8 Class Initialized
INFO - 2025-10-31 08:50:29 --> URI Class Initialized
DEBUG - 2025-10-31 08:50:29 --> No URI present. Default controller set.
INFO - 2025-10-31 08:50:29 --> Router Class Initialized
INFO - 2025-10-31 08:50:29 --> Output Class Initialized
INFO - 2025-10-31 08:50:29 --> Security Class Initialized
DEBUG - 2025-10-31 08:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:50:29 --> CSRF cookie sent
INFO - 2025-10-31 08:50:29 --> Input Class Initialized
INFO - 2025-10-31 08:50:29 --> Language Class Initialized
INFO - 2025-10-31 08:50:29 --> Loader Class Initialized
INFO - 2025-10-31 08:50:29 --> Helper loaded: url_helper
INFO - 2025-10-31 08:50:29 --> Helper loaded: text_helper
INFO - 2025-10-31 08:50:29 --> Helper loaded: string_helper
INFO - 2025-10-31 08:50:29 --> Helper loaded: form_helper
INFO - 2025-10-31 08:50:29 --> Helper loaded: download_helper
INFO - 2025-10-31 08:50:29 --> Helper loaded: security_helper
INFO - 2025-10-31 08:50:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:50:29 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:50:29 --> Form Validation Class Initialized
INFO - 2025-10-31 08:50:29 --> Model "User_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:50:29 --> Controller Class Initialized
INFO - 2025-10-31 14:50:29 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Video_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:50:29 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:50:29 --> Pagination Class Initialized
INFO - 2025-10-31 14:50:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:50:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:50:29 --> Model "Log_model" initialized
INFO - 2025-10-31 14:50:29 --> Final output sent to browser
DEBUG - 2025-10-31 14:50:29 --> Total execution time: 0.0989
INFO - 2025-10-31 08:50:50 --> Config Class Initialized
INFO - 2025-10-31 08:50:50 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:50:50 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:50:50 --> Utf8 Class Initialized
INFO - 2025-10-31 08:50:50 --> URI Class Initialized
DEBUG - 2025-10-31 08:50:50 --> No URI present. Default controller set.
INFO - 2025-10-31 08:50:50 --> Router Class Initialized
INFO - 2025-10-31 08:50:50 --> Output Class Initialized
INFO - 2025-10-31 08:50:50 --> Security Class Initialized
DEBUG - 2025-10-31 08:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:50:50 --> CSRF cookie sent
INFO - 2025-10-31 08:50:50 --> Input Class Initialized
INFO - 2025-10-31 08:50:50 --> Language Class Initialized
INFO - 2025-10-31 08:50:50 --> Loader Class Initialized
INFO - 2025-10-31 08:50:50 --> Helper loaded: url_helper
INFO - 2025-10-31 08:50:50 --> Helper loaded: text_helper
INFO - 2025-10-31 08:50:50 --> Helper loaded: string_helper
INFO - 2025-10-31 08:50:50 --> Helper loaded: form_helper
INFO - 2025-10-31 08:50:50 --> Helper loaded: download_helper
INFO - 2025-10-31 08:50:50 --> Helper loaded: security_helper
INFO - 2025-10-31 08:50:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:50:50 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:50:50 --> Form Validation Class Initialized
INFO - 2025-10-31 08:50:50 --> Model "User_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:50:50 --> Controller Class Initialized
INFO - 2025-10-31 14:50:50 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Video_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:50:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:50:50 --> Pagination Class Initialized
INFO - 2025-10-31 14:50:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:50:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:50:50 --> Model "Log_model" initialized
INFO - 2025-10-31 14:50:50 --> Final output sent to browser
DEBUG - 2025-10-31 14:50:50 --> Total execution time: 0.0953
INFO - 2025-10-31 08:50:56 --> Config Class Initialized
INFO - 2025-10-31 08:50:56 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:50:56 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:50:56 --> Utf8 Class Initialized
INFO - 2025-10-31 08:50:56 --> URI Class Initialized
DEBUG - 2025-10-31 08:50:56 --> No URI present. Default controller set.
INFO - 2025-10-31 08:50:56 --> Router Class Initialized
INFO - 2025-10-31 08:50:56 --> Output Class Initialized
INFO - 2025-10-31 08:50:56 --> Security Class Initialized
DEBUG - 2025-10-31 08:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:50:56 --> CSRF cookie sent
INFO - 2025-10-31 08:50:56 --> Input Class Initialized
INFO - 2025-10-31 08:50:56 --> Language Class Initialized
INFO - 2025-10-31 08:50:56 --> Loader Class Initialized
INFO - 2025-10-31 08:50:56 --> Helper loaded: url_helper
INFO - 2025-10-31 08:50:56 --> Helper loaded: text_helper
INFO - 2025-10-31 08:50:56 --> Helper loaded: string_helper
INFO - 2025-10-31 08:50:56 --> Helper loaded: form_helper
INFO - 2025-10-31 08:50:56 --> Helper loaded: download_helper
INFO - 2025-10-31 08:50:56 --> Helper loaded: security_helper
INFO - 2025-10-31 08:50:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:50:56 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:50:56 --> Form Validation Class Initialized
INFO - 2025-10-31 08:50:56 --> Model "User_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:50:56 --> Controller Class Initialized
INFO - 2025-10-31 14:50:56 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Video_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:50:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:50:56 --> Pagination Class Initialized
INFO - 2025-10-31 14:50:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:50:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:50:56 --> Model "Log_model" initialized
INFO - 2025-10-31 14:50:56 --> Final output sent to browser
DEBUG - 2025-10-31 14:50:56 --> Total execution time: 0.0946
INFO - 2025-10-31 08:51:59 --> Config Class Initialized
INFO - 2025-10-31 08:51:59 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:51:59 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:51:59 --> Utf8 Class Initialized
INFO - 2025-10-31 08:51:59 --> URI Class Initialized
DEBUG - 2025-10-31 08:51:59 --> No URI present. Default controller set.
INFO - 2025-10-31 08:51:59 --> Router Class Initialized
INFO - 2025-10-31 08:51:59 --> Output Class Initialized
INFO - 2025-10-31 08:51:59 --> Security Class Initialized
DEBUG - 2025-10-31 08:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:51:59 --> CSRF cookie sent
INFO - 2025-10-31 08:51:59 --> Input Class Initialized
INFO - 2025-10-31 08:51:59 --> Language Class Initialized
INFO - 2025-10-31 08:51:59 --> Loader Class Initialized
INFO - 2025-10-31 08:51:59 --> Helper loaded: url_helper
INFO - 2025-10-31 08:51:59 --> Helper loaded: text_helper
INFO - 2025-10-31 08:51:59 --> Helper loaded: string_helper
INFO - 2025-10-31 08:51:59 --> Helper loaded: form_helper
INFO - 2025-10-31 08:51:59 --> Helper loaded: download_helper
INFO - 2025-10-31 08:51:59 --> Helper loaded: security_helper
INFO - 2025-10-31 08:51:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:51:59 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:51:59 --> Form Validation Class Initialized
INFO - 2025-10-31 08:51:59 --> Model "User_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:51:59 --> Controller Class Initialized
INFO - 2025-10-31 14:51:59 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Video_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:51:59 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:51:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:51:59 --> Pagination Class Initialized
INFO - 2025-10-31 14:51:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:51:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:51:59 --> Model "Log_model" initialized
INFO - 2025-10-31 14:51:59 --> Final output sent to browser
DEBUG - 2025-10-31 14:51:59 --> Total execution time: 0.1250
INFO - 2025-10-31 08:52:42 --> Config Class Initialized
INFO - 2025-10-31 08:52:42 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:52:42 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:52:42 --> Utf8 Class Initialized
INFO - 2025-10-31 08:52:42 --> URI Class Initialized
DEBUG - 2025-10-31 08:52:42 --> No URI present. Default controller set.
INFO - 2025-10-31 08:52:42 --> Router Class Initialized
INFO - 2025-10-31 08:52:42 --> Output Class Initialized
INFO - 2025-10-31 08:52:42 --> Security Class Initialized
DEBUG - 2025-10-31 08:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:52:42 --> CSRF cookie sent
INFO - 2025-10-31 08:52:42 --> Input Class Initialized
INFO - 2025-10-31 08:52:42 --> Language Class Initialized
INFO - 2025-10-31 08:52:42 --> Loader Class Initialized
INFO - 2025-10-31 08:52:42 --> Helper loaded: url_helper
INFO - 2025-10-31 08:52:42 --> Helper loaded: text_helper
INFO - 2025-10-31 08:52:42 --> Helper loaded: string_helper
INFO - 2025-10-31 08:52:42 --> Helper loaded: form_helper
INFO - 2025-10-31 08:52:42 --> Helper loaded: download_helper
INFO - 2025-10-31 08:52:42 --> Helper loaded: security_helper
INFO - 2025-10-31 08:52:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:52:42 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:52:42 --> Form Validation Class Initialized
INFO - 2025-10-31 08:52:42 --> Model "User_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:52:42 --> Controller Class Initialized
INFO - 2025-10-31 14:52:42 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Video_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:52:42 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:52:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:52:42 --> Pagination Class Initialized
INFO - 2025-10-31 14:52:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:52:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:52:42 --> Model "Log_model" initialized
INFO - 2025-10-31 14:52:42 --> Final output sent to browser
DEBUG - 2025-10-31 14:52:42 --> Total execution time: 0.0950
INFO - 2025-10-31 08:53:09 --> Config Class Initialized
INFO - 2025-10-31 08:53:09 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:53:09 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:53:09 --> Utf8 Class Initialized
INFO - 2025-10-31 08:53:09 --> URI Class Initialized
DEBUG - 2025-10-31 08:53:09 --> No URI present. Default controller set.
INFO - 2025-10-31 08:53:09 --> Router Class Initialized
INFO - 2025-10-31 08:53:09 --> Output Class Initialized
INFO - 2025-10-31 08:53:09 --> Security Class Initialized
DEBUG - 2025-10-31 08:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:53:09 --> CSRF cookie sent
INFO - 2025-10-31 08:53:09 --> Input Class Initialized
INFO - 2025-10-31 08:53:09 --> Language Class Initialized
INFO - 2025-10-31 08:53:09 --> Loader Class Initialized
INFO - 2025-10-31 08:53:09 --> Helper loaded: url_helper
INFO - 2025-10-31 08:53:09 --> Helper loaded: text_helper
INFO - 2025-10-31 08:53:09 --> Helper loaded: string_helper
INFO - 2025-10-31 08:53:09 --> Helper loaded: form_helper
INFO - 2025-10-31 08:53:09 --> Helper loaded: download_helper
INFO - 2025-10-31 08:53:09 --> Helper loaded: security_helper
INFO - 2025-10-31 08:53:09 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:53:09 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:53:09 --> Form Validation Class Initialized
INFO - 2025-10-31 08:53:09 --> Model "User_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:53:09 --> Controller Class Initialized
INFO - 2025-10-31 14:53:09 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Video_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:53:09 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:53:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:53:09 --> Pagination Class Initialized
INFO - 2025-10-31 14:53:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:53:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:53:09 --> Model "Log_model" initialized
INFO - 2025-10-31 14:53:09 --> Final output sent to browser
DEBUG - 2025-10-31 14:53:09 --> Total execution time: 0.3712
INFO - 2025-10-31 08:53:48 --> Config Class Initialized
INFO - 2025-10-31 08:53:48 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:53:48 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:53:48 --> Utf8 Class Initialized
INFO - 2025-10-31 08:53:48 --> URI Class Initialized
DEBUG - 2025-10-31 08:53:48 --> No URI present. Default controller set.
INFO - 2025-10-31 08:53:48 --> Router Class Initialized
INFO - 2025-10-31 08:53:48 --> Output Class Initialized
INFO - 2025-10-31 08:53:48 --> Security Class Initialized
DEBUG - 2025-10-31 08:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:53:48 --> CSRF cookie sent
INFO - 2025-10-31 08:53:48 --> Input Class Initialized
INFO - 2025-10-31 08:53:48 --> Language Class Initialized
INFO - 2025-10-31 08:53:48 --> Loader Class Initialized
INFO - 2025-10-31 08:53:48 --> Helper loaded: url_helper
INFO - 2025-10-31 08:53:48 --> Helper loaded: text_helper
INFO - 2025-10-31 08:53:48 --> Helper loaded: string_helper
INFO - 2025-10-31 08:53:48 --> Helper loaded: form_helper
INFO - 2025-10-31 08:53:48 --> Helper loaded: download_helper
INFO - 2025-10-31 08:53:48 --> Helper loaded: security_helper
INFO - 2025-10-31 08:53:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:53:48 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:53:48 --> Form Validation Class Initialized
INFO - 2025-10-31 08:53:48 --> Model "User_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:53:48 --> Controller Class Initialized
INFO - 2025-10-31 14:53:48 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Video_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Agenda_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Mitra_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Prodi_model" initialized
INFO - 2025-10-31 14:53:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 14:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 14:53:48 --> Pagination Class Initialized
INFO - 2025-10-31 14:53:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 14:53:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 14:53:48 --> Model "Log_model" initialized
INFO - 2025-10-31 14:53:48 --> Final output sent to browser
DEBUG - 2025-10-31 14:53:48 --> Total execution time: 0.2695
INFO - 2025-10-31 08:53:52 --> Config Class Initialized
INFO - 2025-10-31 08:53:52 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:53:52 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:53:52 --> Utf8 Class Initialized
INFO - 2025-10-31 08:53:52 --> URI Class Initialized
INFO - 2025-10-31 08:53:52 --> Router Class Initialized
INFO - 2025-10-31 08:53:52 --> Output Class Initialized
INFO - 2025-10-31 08:53:52 --> Security Class Initialized
DEBUG - 2025-10-31 08:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:53:52 --> CSRF cookie sent
INFO - 2025-10-31 08:53:52 --> Input Class Initialized
INFO - 2025-10-31 08:53:52 --> Language Class Initialized
INFO - 2025-10-31 08:53:52 --> Loader Class Initialized
INFO - 2025-10-31 08:53:52 --> Helper loaded: url_helper
INFO - 2025-10-31 08:53:52 --> Helper loaded: text_helper
INFO - 2025-10-31 08:53:52 --> Helper loaded: string_helper
INFO - 2025-10-31 08:53:52 --> Helper loaded: form_helper
INFO - 2025-10-31 08:53:52 --> Helper loaded: download_helper
INFO - 2025-10-31 08:53:52 --> Helper loaded: security_helper
INFO - 2025-10-31 08:53:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:53:52 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:53:52 --> Form Validation Class Initialized
INFO - 2025-10-31 08:53:52 --> Model "User_model" initialized
INFO - 2025-10-31 14:53:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:53:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:53:52 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:53:52 --> Controller Class Initialized
DEBUG - 2025-10-31 14:53:52 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-10-31 14:53:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-10-31 14:53:52 --> Model "Log_model" initialized
INFO - 2025-10-31 14:53:52 --> Final output sent to browser
DEBUG - 2025-10-31 14:53:52 --> Total execution time: 0.3039
INFO - 2025-10-31 08:54:02 --> Config Class Initialized
INFO - 2025-10-31 08:54:02 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:54:02 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:54:02 --> Utf8 Class Initialized
INFO - 2025-10-31 08:54:02 --> URI Class Initialized
INFO - 2025-10-31 08:54:02 --> Router Class Initialized
INFO - 2025-10-31 08:54:02 --> Output Class Initialized
INFO - 2025-10-31 08:54:02 --> Security Class Initialized
DEBUG - 2025-10-31 08:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:54:02 --> CSRF cookie sent
INFO - 2025-10-31 08:54:02 --> CSRF token verified
INFO - 2025-10-31 08:54:02 --> Input Class Initialized
INFO - 2025-10-31 08:54:02 --> Language Class Initialized
INFO - 2025-10-31 08:54:02 --> Loader Class Initialized
INFO - 2025-10-31 08:54:02 --> Helper loaded: url_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: text_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: string_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: form_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: download_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: security_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:54:02 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:54:02 --> Form Validation Class Initialized
INFO - 2025-10-31 08:54:02 --> Model "User_model" initialized
INFO - 2025-10-31 14:54:02 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:54:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:54:02 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:54:02 --> Controller Class Initialized
DEBUG - 2025-10-31 14:54:02 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-10-31 14:54:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-31 08:54:02 --> Config Class Initialized
INFO - 2025-10-31 08:54:02 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:54:02 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:54:02 --> Utf8 Class Initialized
INFO - 2025-10-31 08:54:02 --> URI Class Initialized
INFO - 2025-10-31 08:54:02 --> Router Class Initialized
INFO - 2025-10-31 08:54:02 --> Output Class Initialized
INFO - 2025-10-31 08:54:02 --> Security Class Initialized
DEBUG - 2025-10-31 08:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:54:02 --> CSRF cookie sent
INFO - 2025-10-31 08:54:02 --> Input Class Initialized
INFO - 2025-10-31 08:54:02 --> Language Class Initialized
INFO - 2025-10-31 08:54:02 --> Loader Class Initialized
INFO - 2025-10-31 08:54:02 --> Helper loaded: url_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: text_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: string_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: form_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: download_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: security_helper
INFO - 2025-10-31 08:54:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:54:02 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:54:02 --> Form Validation Class Initialized
INFO - 2025-10-31 08:54:02 --> Model "User_model" initialized
INFO - 2025-10-31 14:54:02 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:54:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:54:02 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:54:02 --> Controller Class Initialized
INFO - 2025-10-31 14:54:02 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:54:03 --> Model "Staff_model" initialized
INFO - 2025-10-31 14:54:03 --> Model "Dasbor_model" initialized
INFO - 2025-10-31 14:54:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-10-31 14:54:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-31 14:54:04 --> Model "Log_model" initialized
INFO - 2025-10-31 14:54:04 --> Final output sent to browser
DEBUG - 2025-10-31 14:54:04 --> Total execution time: 1.4501
INFO - 2025-10-31 08:54:12 --> Config Class Initialized
INFO - 2025-10-31 08:54:12 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:54:12 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:54:12 --> Utf8 Class Initialized
INFO - 2025-10-31 08:54:12 --> URI Class Initialized
INFO - 2025-10-31 08:54:12 --> Router Class Initialized
INFO - 2025-10-31 08:54:12 --> Output Class Initialized
INFO - 2025-10-31 08:54:12 --> Security Class Initialized
DEBUG - 2025-10-31 08:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:54:12 --> CSRF cookie sent
INFO - 2025-10-31 08:54:12 --> Input Class Initialized
INFO - 2025-10-31 08:54:12 --> Language Class Initialized
INFO - 2025-10-31 08:54:12 --> Loader Class Initialized
INFO - 2025-10-31 08:54:12 --> Helper loaded: url_helper
INFO - 2025-10-31 08:54:12 --> Helper loaded: text_helper
INFO - 2025-10-31 08:54:12 --> Helper loaded: string_helper
INFO - 2025-10-31 08:54:12 --> Helper loaded: form_helper
INFO - 2025-10-31 08:54:12 --> Helper loaded: download_helper
INFO - 2025-10-31 08:54:12 --> Helper loaded: security_helper
INFO - 2025-10-31 08:54:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:54:12 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:54:12 --> Form Validation Class Initialized
INFO - 2025-10-31 08:54:12 --> Model "User_model" initialized
INFO - 2025-10-31 14:54:12 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:54:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:54:12 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:54:12 --> Controller Class Initialized
INFO - 2025-10-31 14:54:12 --> Model "Berita_model" initialized
INFO - 2025-10-31 14:54:12 --> Model "Kategori_model" initialized
INFO - 2025-10-31 14:54:12 --> Model "Download_model" initialized
INFO - 2025-10-31 14:54:12 --> Model "Galeri_model" initialized
INFO - 2025-10-31 14:54:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/berita/list.php
INFO - 2025-10-31 14:54:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-31 14:54:13 --> Model "Log_model" initialized
INFO - 2025-10-31 14:54:13 --> Final output sent to browser
DEBUG - 2025-10-31 14:54:13 --> Total execution time: 0.4194
INFO - 2025-10-31 08:54:45 --> Config Class Initialized
INFO - 2025-10-31 08:54:45 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:54:45 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:54:45 --> Utf8 Class Initialized
INFO - 2025-10-31 08:54:45 --> URI Class Initialized
INFO - 2025-10-31 08:54:45 --> Router Class Initialized
INFO - 2025-10-31 08:54:45 --> Output Class Initialized
INFO - 2025-10-31 08:54:45 --> Security Class Initialized
DEBUG - 2025-10-31 08:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:54:45 --> CSRF cookie sent
INFO - 2025-10-31 08:54:45 --> Input Class Initialized
INFO - 2025-10-31 08:54:45 --> Language Class Initialized
INFO - 2025-10-31 08:54:45 --> Loader Class Initialized
INFO - 2025-10-31 08:54:45 --> Helper loaded: url_helper
INFO - 2025-10-31 08:54:45 --> Helper loaded: text_helper
INFO - 2025-10-31 08:54:45 --> Helper loaded: string_helper
INFO - 2025-10-31 08:54:45 --> Helper loaded: form_helper
INFO - 2025-10-31 08:54:45 --> Helper loaded: download_helper
INFO - 2025-10-31 08:54:45 --> Helper loaded: security_helper
INFO - 2025-10-31 08:54:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:54:45 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:54:45 --> Form Validation Class Initialized
INFO - 2025-10-31 08:54:45 --> Model "User_model" initialized
INFO - 2025-10-31 14:54:45 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:54:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:54:45 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:54:45 --> Controller Class Initialized
INFO - 2025-10-31 08:54:54 --> Config Class Initialized
INFO - 2025-10-31 08:54:54 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:54:54 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:54:54 --> Utf8 Class Initialized
INFO - 2025-10-31 08:54:54 --> URI Class Initialized
INFO - 2025-10-31 08:54:54 --> Router Class Initialized
INFO - 2025-10-31 08:54:54 --> Output Class Initialized
INFO - 2025-10-31 08:54:54 --> Security Class Initialized
DEBUG - 2025-10-31 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:54:54 --> CSRF cookie sent
INFO - 2025-10-31 08:54:54 --> Input Class Initialized
INFO - 2025-10-31 08:54:54 --> Language Class Initialized
INFO - 2025-10-31 08:54:54 --> Loader Class Initialized
INFO - 2025-10-31 08:54:54 --> Helper loaded: url_helper
INFO - 2025-10-31 08:54:54 --> Helper loaded: text_helper
INFO - 2025-10-31 08:54:54 --> Helper loaded: string_helper
INFO - 2025-10-31 08:54:54 --> Helper loaded: form_helper
INFO - 2025-10-31 08:54:54 --> Helper loaded: download_helper
INFO - 2025-10-31 08:54:54 --> Helper loaded: security_helper
INFO - 2025-10-31 08:54:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:54:54 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 08:55:01 --> Config Class Initialized
INFO - 2025-10-31 08:55:01 --> Hooks Class Initialized
DEBUG - 2025-10-31 08:55:01 --> UTF-8 Support Enabled
INFO - 2025-10-31 08:55:01 --> Utf8 Class Initialized
INFO - 2025-10-31 08:55:01 --> URI Class Initialized
INFO - 2025-10-31 08:55:01 --> Router Class Initialized
INFO - 2025-10-31 08:55:01 --> Output Class Initialized
INFO - 2025-10-31 08:55:01 --> Security Class Initialized
DEBUG - 2025-10-31 08:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 08:55:01 --> CSRF cookie sent
INFO - 2025-10-31 08:55:01 --> Input Class Initialized
INFO - 2025-10-31 08:55:01 --> Language Class Initialized
INFO - 2025-10-31 08:55:01 --> Loader Class Initialized
INFO - 2025-10-31 08:55:01 --> Helper loaded: url_helper
INFO - 2025-10-31 08:55:01 --> Helper loaded: text_helper
INFO - 2025-10-31 08:55:01 --> Helper loaded: string_helper
INFO - 2025-10-31 08:55:01 --> Helper loaded: form_helper
INFO - 2025-10-31 08:55:01 --> Helper loaded: download_helper
INFO - 2025-10-31 08:55:01 --> Helper loaded: security_helper
INFO - 2025-10-31 08:55:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 08:55:01 --> Database Driver Class Initialized
DEBUG - 2025-10-31 08:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2025-10-31 14:55:06 --> SEAFILE API [GET http://192.168.11.105/api2//repos/] => HTTP 0
ERROR - 2025-10-31 14:55:06 --> RESPONSE: 
ERROR - 2025-10-31 14:55:06 --> SEAFILE LIST LIBRARIES RESPONSE: Array
(
    [error] => Failed to connect to 192.168.11.105 port 80: Timed out
)

INFO - 2025-10-31 14:55:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/seafile/list.php
INFO - 2025-10-31 14:55:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-31 14:55:06 --> Model "Log_model" initialized
INFO - 2025-10-31 14:55:06 --> Final output sent to browser
DEBUG - 2025-10-31 14:55:06 --> Total execution time: 21.5993
INFO - 2025-10-31 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:55:06 --> Form Validation Class Initialized
INFO - 2025-10-31 08:55:06 --> Model "User_model" initialized
INFO - 2025-10-31 14:55:06 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:55:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:55:06 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:55:06 --> Controller Class Initialized
INFO - 2025-10-31 14:55:06 --> Model "Sdm_model" initialized
INFO - 2025-10-31 14:55:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2025-10-31 14:55:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-31 14:55:07 --> Model "Log_model" initialized
INFO - 2025-10-31 14:55:07 --> Final output sent to browser
DEBUG - 2025-10-31 14:55:07 --> Total execution time: 12.9668
INFO - 2025-10-31 08:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 08:55:07 --> Form Validation Class Initialized
INFO - 2025-10-31 08:55:07 --> Model "User_model" initialized
INFO - 2025-10-31 14:55:07 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 14:55:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 14:55:07 --> Model "Nav_model" initialized
INFO - 2025-10-31 14:55:07 --> Controller Class Initialized
INFO - 2025-10-31 14:55:07 --> Model "Tautan_model" initialized
INFO - 2025-10-31 14:55:07 --> Model "Staff_model" initialized
INFO - 2025-10-31 14:55:07 --> Model "Dasbor_model" initialized
INFO - 2025-10-31 14:55:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-10-31 14:55:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-31 14:55:07 --> Model "Log_model" initialized
INFO - 2025-10-31 14:55:07 --> Final output sent to browser
DEBUG - 2025-10-31 14:55:07 --> Total execution time: 5.6949
INFO - 2025-10-31 10:13:43 --> Config Class Initialized
INFO - 2025-10-31 10:13:43 --> Hooks Class Initialized
DEBUG - 2025-10-31 10:13:43 --> UTF-8 Support Enabled
INFO - 2025-10-31 10:13:43 --> Utf8 Class Initialized
INFO - 2025-10-31 10:13:43 --> URI Class Initialized
DEBUG - 2025-10-31 10:13:43 --> No URI present. Default controller set.
INFO - 2025-10-31 10:13:43 --> Router Class Initialized
INFO - 2025-10-31 10:13:43 --> Output Class Initialized
INFO - 2025-10-31 10:13:43 --> Security Class Initialized
DEBUG - 2025-10-31 10:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-31 10:13:43 --> CSRF cookie sent
INFO - 2025-10-31 10:13:43 --> Input Class Initialized
INFO - 2025-10-31 10:13:43 --> Language Class Initialized
INFO - 2025-10-31 10:13:43 --> Loader Class Initialized
INFO - 2025-10-31 10:13:43 --> Helper loaded: url_helper
INFO - 2025-10-31 10:13:43 --> Helper loaded: text_helper
INFO - 2025-10-31 10:13:43 --> Helper loaded: string_helper
INFO - 2025-10-31 10:13:43 --> Helper loaded: form_helper
INFO - 2025-10-31 10:13:43 --> Helper loaded: download_helper
INFO - 2025-10-31 10:13:43 --> Helper loaded: security_helper
INFO - 2025-10-31 10:13:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-31 10:13:43 --> Database Driver Class Initialized
DEBUG - 2025-10-31 10:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-31 10:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-31 10:13:43 --> Form Validation Class Initialized
INFO - 2025-10-31 10:13:43 --> Model "User_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Kunjungan_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Nav_model" initialized
INFO - 2025-10-31 16:13:43 --> Controller Class Initialized
INFO - 2025-10-31 16:13:43 --> Model "Berita_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Galeri_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Video_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Agenda_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Tautan_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Mitra_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Jurusan_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Prodi_model" initialized
INFO - 2025-10-31 16:13:43 --> Model "Testimoni_model" initialized
INFO - 2025-10-31 16:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-31 16:13:43 --> Pagination Class Initialized
INFO - 2025-10-31 16:13:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-31 16:13:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-31 16:13:43 --> Model "Log_model" initialized
INFO - 2025-10-31 16:13:43 --> Final output sent to browser
DEBUG - 2025-10-31 16:13:43 --> Total execution time: 0.2141
