<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-09-19 03:43:26 --> Config Class Initialized
INFO - 2025-09-19 03:43:26 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:43:26 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:43:26 --> Utf8 Class Initialized
INFO - 2025-09-19 03:43:27 --> URI Class Initialized
DEBUG - 2025-09-19 03:43:27 --> No URI present. Default controller set.
INFO - 2025-09-19 03:43:27 --> Router Class Initialized
INFO - 2025-09-19 03:43:27 --> Output Class Initialized
INFO - 2025-09-19 03:43:27 --> Security Class Initialized
DEBUG - 2025-09-19 03:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:43:27 --> CSRF cookie sent
INFO - 2025-09-19 03:43:27 --> Input Class Initialized
INFO - 2025-09-19 03:43:27 --> Language Class Initialized
INFO - 2025-09-19 03:43:27 --> Loader Class Initialized
INFO - 2025-09-19 03:43:27 --> Helper loaded: url_helper
INFO - 2025-09-19 03:43:27 --> Helper loaded: text_helper
INFO - 2025-09-19 03:43:27 --> Helper loaded: string_helper
INFO - 2025-09-19 03:43:27 --> Helper loaded: form_helper
INFO - 2025-09-19 03:43:27 --> Helper loaded: download_helper
INFO - 2025-09-19 03:43:27 --> Helper loaded: security_helper
INFO - 2025-09-19 03:43:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:43:28 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:43:28 --> Form Validation Class Initialized
INFO - 2025-09-19 03:43:28 --> Model "User_model" initialized
INFO - 2025-09-19 08:43:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:43:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:43:28 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:43:28 --> Controller Class Initialized
INFO - 2025-09-19 08:43:28 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:43:28 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:43:28 --> Model "Video_model" initialized
INFO - 2025-09-19 08:43:28 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:43:28 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:43:28 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:43:29 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:43:29 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:43:29 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:43:29 --> Pagination Class Initialized
INFO - 2025-09-19 08:43:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:43:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:43:32 --> Model "Log_model" initialized
INFO - 2025-09-19 08:43:32 --> Final output sent to browser
DEBUG - 2025-09-19 08:43:32 --> Total execution time: 5.9075
INFO - 2025-09-19 03:46:51 --> Config Class Initialized
INFO - 2025-09-19 03:46:51 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:46:51 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:46:51 --> Utf8 Class Initialized
INFO - 2025-09-19 03:46:51 --> URI Class Initialized
DEBUG - 2025-09-19 03:46:51 --> No URI present. Default controller set.
INFO - 2025-09-19 03:46:51 --> Router Class Initialized
INFO - 2025-09-19 03:46:51 --> Output Class Initialized
INFO - 2025-09-19 03:46:51 --> Security Class Initialized
DEBUG - 2025-09-19 03:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:46:51 --> CSRF cookie sent
INFO - 2025-09-19 03:46:51 --> Input Class Initialized
INFO - 2025-09-19 03:46:51 --> Language Class Initialized
INFO - 2025-09-19 03:46:51 --> Loader Class Initialized
INFO - 2025-09-19 03:46:51 --> Helper loaded: url_helper
INFO - 2025-09-19 03:46:51 --> Helper loaded: text_helper
INFO - 2025-09-19 03:46:51 --> Helper loaded: string_helper
INFO - 2025-09-19 03:46:51 --> Helper loaded: form_helper
INFO - 2025-09-19 03:46:51 --> Helper loaded: download_helper
INFO - 2025-09-19 03:46:51 --> Helper loaded: security_helper
INFO - 2025-09-19 03:46:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:46:51 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:46:51 --> Form Validation Class Initialized
INFO - 2025-09-19 03:46:51 --> Model "User_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:46:51 --> Controller Class Initialized
INFO - 2025-09-19 08:46:51 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Video_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:46:51 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:46:51 --> Pagination Class Initialized
INFO - 2025-09-19 08:46:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:46:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:46:51 --> Model "Log_model" initialized
INFO - 2025-09-19 08:46:51 --> Final output sent to browser
DEBUG - 2025-09-19 08:46:51 --> Total execution time: 0.2201
INFO - 2025-09-19 03:47:11 --> Config Class Initialized
INFO - 2025-09-19 03:47:11 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:47:11 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:47:11 --> Utf8 Class Initialized
INFO - 2025-09-19 03:47:11 --> URI Class Initialized
DEBUG - 2025-09-19 03:47:11 --> No URI present. Default controller set.
INFO - 2025-09-19 03:47:11 --> Router Class Initialized
INFO - 2025-09-19 03:47:11 --> Output Class Initialized
INFO - 2025-09-19 03:47:11 --> Security Class Initialized
DEBUG - 2025-09-19 03:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:47:11 --> CSRF cookie sent
INFO - 2025-09-19 03:47:11 --> Input Class Initialized
INFO - 2025-09-19 03:47:11 --> Language Class Initialized
INFO - 2025-09-19 03:47:11 --> Loader Class Initialized
INFO - 2025-09-19 03:47:11 --> Helper loaded: url_helper
INFO - 2025-09-19 03:47:11 --> Helper loaded: text_helper
INFO - 2025-09-19 03:47:11 --> Helper loaded: string_helper
INFO - 2025-09-19 03:47:11 --> Helper loaded: form_helper
INFO - 2025-09-19 03:47:11 --> Helper loaded: download_helper
INFO - 2025-09-19 03:47:11 --> Helper loaded: security_helper
INFO - 2025-09-19 03:47:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:47:11 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:47:11 --> Form Validation Class Initialized
INFO - 2025-09-19 03:47:11 --> Model "User_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:47:11 --> Controller Class Initialized
INFO - 2025-09-19 08:47:11 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Video_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:47:11 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:47:11 --> Pagination Class Initialized
INFO - 2025-09-19 08:47:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:47:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:47:11 --> Model "Log_model" initialized
INFO - 2025-09-19 08:47:11 --> Final output sent to browser
DEBUG - 2025-09-19 08:47:11 --> Total execution time: 0.1145
INFO - 2025-09-19 03:47:24 --> Config Class Initialized
INFO - 2025-09-19 03:47:24 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:47:24 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:47:24 --> Utf8 Class Initialized
INFO - 2025-09-19 03:47:24 --> URI Class Initialized
DEBUG - 2025-09-19 03:47:24 --> No URI present. Default controller set.
INFO - 2025-09-19 03:47:24 --> Router Class Initialized
INFO - 2025-09-19 03:47:24 --> Output Class Initialized
INFO - 2025-09-19 03:47:24 --> Security Class Initialized
DEBUG - 2025-09-19 03:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:47:24 --> CSRF cookie sent
INFO - 2025-09-19 03:47:24 --> Input Class Initialized
INFO - 2025-09-19 03:47:24 --> Language Class Initialized
INFO - 2025-09-19 03:47:24 --> Loader Class Initialized
INFO - 2025-09-19 03:47:24 --> Helper loaded: url_helper
INFO - 2025-09-19 03:47:24 --> Helper loaded: text_helper
INFO - 2025-09-19 03:47:24 --> Helper loaded: string_helper
INFO - 2025-09-19 03:47:24 --> Helper loaded: form_helper
INFO - 2025-09-19 03:47:24 --> Helper loaded: download_helper
INFO - 2025-09-19 03:47:24 --> Helper loaded: security_helper
INFO - 2025-09-19 03:47:24 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:47:24 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:47:24 --> Form Validation Class Initialized
INFO - 2025-09-19 03:47:24 --> Model "User_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:47:24 --> Controller Class Initialized
INFO - 2025-09-19 08:47:24 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Video_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:47:24 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:47:24 --> Pagination Class Initialized
INFO - 2025-09-19 08:47:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:47:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:47:24 --> Model "Log_model" initialized
INFO - 2025-09-19 08:47:24 --> Final output sent to browser
DEBUG - 2025-09-19 08:47:24 --> Total execution time: 0.0936
INFO - 2025-09-19 03:47:26 --> Config Class Initialized
INFO - 2025-09-19 03:47:26 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:47:26 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:47:26 --> Utf8 Class Initialized
INFO - 2025-09-19 03:47:26 --> URI Class Initialized
DEBUG - 2025-09-19 03:47:26 --> No URI present. Default controller set.
INFO - 2025-09-19 03:47:26 --> Router Class Initialized
INFO - 2025-09-19 03:47:26 --> Output Class Initialized
INFO - 2025-09-19 03:47:26 --> Security Class Initialized
DEBUG - 2025-09-19 03:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:47:26 --> CSRF cookie sent
INFO - 2025-09-19 03:47:26 --> Input Class Initialized
INFO - 2025-09-19 03:47:26 --> Language Class Initialized
INFO - 2025-09-19 03:47:26 --> Loader Class Initialized
INFO - 2025-09-19 03:47:26 --> Helper loaded: url_helper
INFO - 2025-09-19 03:47:26 --> Helper loaded: text_helper
INFO - 2025-09-19 03:47:26 --> Helper loaded: string_helper
INFO - 2025-09-19 03:47:26 --> Helper loaded: form_helper
INFO - 2025-09-19 03:47:26 --> Helper loaded: download_helper
INFO - 2025-09-19 03:47:26 --> Helper loaded: security_helper
INFO - 2025-09-19 03:47:26 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:47:26 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:47:27 --> Form Validation Class Initialized
INFO - 2025-09-19 03:47:27 --> Model "User_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:47:27 --> Controller Class Initialized
INFO - 2025-09-19 08:47:27 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Video_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:47:27 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:47:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:47:27 --> Pagination Class Initialized
INFO - 2025-09-19 08:47:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:47:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:47:27 --> Model "Log_model" initialized
INFO - 2025-09-19 08:47:27 --> Final output sent to browser
DEBUG - 2025-09-19 08:47:27 --> Total execution time: 0.1223
INFO - 2025-09-19 03:49:31 --> Config Class Initialized
INFO - 2025-09-19 03:49:31 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:49:31 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:49:31 --> Utf8 Class Initialized
INFO - 2025-09-19 03:49:31 --> URI Class Initialized
DEBUG - 2025-09-19 03:49:31 --> No URI present. Default controller set.
INFO - 2025-09-19 03:49:31 --> Router Class Initialized
INFO - 2025-09-19 03:49:31 --> Output Class Initialized
INFO - 2025-09-19 03:49:31 --> Security Class Initialized
DEBUG - 2025-09-19 03:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:49:31 --> CSRF cookie sent
INFO - 2025-09-19 03:49:31 --> Input Class Initialized
INFO - 2025-09-19 03:49:31 --> Language Class Initialized
INFO - 2025-09-19 03:49:31 --> Loader Class Initialized
INFO - 2025-09-19 03:49:31 --> Helper loaded: url_helper
INFO - 2025-09-19 03:49:31 --> Helper loaded: text_helper
INFO - 2025-09-19 03:49:31 --> Helper loaded: string_helper
INFO - 2025-09-19 03:49:31 --> Helper loaded: form_helper
INFO - 2025-09-19 03:49:31 --> Helper loaded: download_helper
INFO - 2025-09-19 03:49:31 --> Helper loaded: security_helper
INFO - 2025-09-19 03:49:31 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:49:31 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:49:31 --> Form Validation Class Initialized
INFO - 2025-09-19 03:49:31 --> Model "User_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:49:31 --> Controller Class Initialized
INFO - 2025-09-19 08:49:31 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Video_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:49:31 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:49:31 --> Pagination Class Initialized
INFO - 2025-09-19 08:49:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:49:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:49:31 --> Model "Log_model" initialized
INFO - 2025-09-19 08:49:31 --> Final output sent to browser
DEBUG - 2025-09-19 08:49:31 --> Total execution time: 0.0866
INFO - 2025-09-19 03:49:44 --> Config Class Initialized
INFO - 2025-09-19 03:49:44 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:49:44 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:49:44 --> Utf8 Class Initialized
INFO - 2025-09-19 03:49:44 --> URI Class Initialized
DEBUG - 2025-09-19 03:49:44 --> No URI present. Default controller set.
INFO - 2025-09-19 03:49:44 --> Router Class Initialized
INFO - 2025-09-19 03:49:44 --> Output Class Initialized
INFO - 2025-09-19 03:49:44 --> Security Class Initialized
DEBUG - 2025-09-19 03:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:49:44 --> CSRF cookie sent
INFO - 2025-09-19 03:49:44 --> Input Class Initialized
INFO - 2025-09-19 03:49:44 --> Language Class Initialized
INFO - 2025-09-19 03:49:44 --> Loader Class Initialized
INFO - 2025-09-19 03:49:44 --> Helper loaded: url_helper
INFO - 2025-09-19 03:49:44 --> Helper loaded: text_helper
INFO - 2025-09-19 03:49:44 --> Helper loaded: string_helper
INFO - 2025-09-19 03:49:44 --> Helper loaded: form_helper
INFO - 2025-09-19 03:49:44 --> Helper loaded: download_helper
INFO - 2025-09-19 03:49:44 --> Helper loaded: security_helper
INFO - 2025-09-19 03:49:44 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:49:44 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:49:44 --> Form Validation Class Initialized
INFO - 2025-09-19 03:49:44 --> Model "User_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:49:44 --> Controller Class Initialized
INFO - 2025-09-19 08:49:44 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Video_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:49:44 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:49:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:49:45 --> Pagination Class Initialized
INFO - 2025-09-19 08:49:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:49:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:49:45 --> Model "Log_model" initialized
INFO - 2025-09-19 08:49:45 --> Final output sent to browser
DEBUG - 2025-09-19 08:49:45 --> Total execution time: 0.0919
INFO - 2025-09-19 03:49:47 --> Config Class Initialized
INFO - 2025-09-19 03:49:47 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:49:47 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:49:47 --> Utf8 Class Initialized
INFO - 2025-09-19 03:49:47 --> URI Class Initialized
DEBUG - 2025-09-19 03:49:47 --> No URI present. Default controller set.
INFO - 2025-09-19 03:49:47 --> Router Class Initialized
INFO - 2025-09-19 03:49:47 --> Output Class Initialized
INFO - 2025-09-19 03:49:47 --> Security Class Initialized
DEBUG - 2025-09-19 03:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:49:47 --> CSRF cookie sent
INFO - 2025-09-19 03:49:47 --> Input Class Initialized
INFO - 2025-09-19 03:49:47 --> Language Class Initialized
INFO - 2025-09-19 03:49:47 --> Loader Class Initialized
INFO - 2025-09-19 03:49:47 --> Helper loaded: url_helper
INFO - 2025-09-19 03:49:47 --> Helper loaded: text_helper
INFO - 2025-09-19 03:49:47 --> Helper loaded: string_helper
INFO - 2025-09-19 03:49:47 --> Helper loaded: form_helper
INFO - 2025-09-19 03:49:47 --> Helper loaded: download_helper
INFO - 2025-09-19 03:49:47 --> Helper loaded: security_helper
INFO - 2025-09-19 03:49:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:49:47 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:49:47 --> Form Validation Class Initialized
INFO - 2025-09-19 03:49:47 --> Model "User_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:49:47 --> Controller Class Initialized
INFO - 2025-09-19 08:49:47 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Video_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:49:47 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:49:47 --> Pagination Class Initialized
INFO - 2025-09-19 08:49:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:49:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:49:47 --> Model "Log_model" initialized
INFO - 2025-09-19 08:49:47 --> Final output sent to browser
DEBUG - 2025-09-19 08:49:47 --> Total execution time: 0.1111
INFO - 2025-09-19 03:55:19 --> Config Class Initialized
INFO - 2025-09-19 03:55:19 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:55:19 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:55:19 --> Utf8 Class Initialized
INFO - 2025-09-19 03:55:19 --> URI Class Initialized
DEBUG - 2025-09-19 03:55:19 --> No URI present. Default controller set.
INFO - 2025-09-19 03:55:19 --> Router Class Initialized
INFO - 2025-09-19 03:55:19 --> Output Class Initialized
INFO - 2025-09-19 03:55:19 --> Security Class Initialized
DEBUG - 2025-09-19 03:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:55:19 --> CSRF cookie sent
INFO - 2025-09-19 03:55:19 --> Input Class Initialized
INFO - 2025-09-19 03:55:19 --> Language Class Initialized
INFO - 2025-09-19 03:55:19 --> Loader Class Initialized
INFO - 2025-09-19 03:55:19 --> Helper loaded: url_helper
INFO - 2025-09-19 03:55:19 --> Helper loaded: text_helper
INFO - 2025-09-19 03:55:19 --> Helper loaded: string_helper
INFO - 2025-09-19 03:55:19 --> Helper loaded: form_helper
INFO - 2025-09-19 03:55:19 --> Helper loaded: download_helper
INFO - 2025-09-19 03:55:19 --> Helper loaded: security_helper
INFO - 2025-09-19 03:55:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:55:19 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:55:19 --> Form Validation Class Initialized
INFO - 2025-09-19 03:55:19 --> Model "User_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:55:19 --> Controller Class Initialized
INFO - 2025-09-19 08:55:19 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Video_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:55:19 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:55:19 --> Pagination Class Initialized
INFO - 2025-09-19 08:55:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:55:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:55:19 --> Model "Log_model" initialized
INFO - 2025-09-19 08:55:19 --> Final output sent to browser
DEBUG - 2025-09-19 08:55:19 --> Total execution time: 0.1104
INFO - 2025-09-19 03:55:40 --> Config Class Initialized
INFO - 2025-09-19 03:55:40 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:55:40 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:55:40 --> Utf8 Class Initialized
INFO - 2025-09-19 03:55:40 --> URI Class Initialized
DEBUG - 2025-09-19 03:55:40 --> No URI present. Default controller set.
INFO - 2025-09-19 03:55:40 --> Router Class Initialized
INFO - 2025-09-19 03:55:40 --> Output Class Initialized
INFO - 2025-09-19 03:55:40 --> Security Class Initialized
DEBUG - 2025-09-19 03:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:55:40 --> CSRF cookie sent
INFO - 2025-09-19 03:55:40 --> Input Class Initialized
INFO - 2025-09-19 03:55:40 --> Language Class Initialized
INFO - 2025-09-19 03:55:40 --> Loader Class Initialized
INFO - 2025-09-19 03:55:40 --> Helper loaded: url_helper
INFO - 2025-09-19 03:55:40 --> Helper loaded: text_helper
INFO - 2025-09-19 03:55:40 --> Helper loaded: string_helper
INFO - 2025-09-19 03:55:40 --> Helper loaded: form_helper
INFO - 2025-09-19 03:55:40 --> Helper loaded: download_helper
INFO - 2025-09-19 03:55:40 --> Helper loaded: security_helper
INFO - 2025-09-19 03:55:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:55:40 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:55:40 --> Form Validation Class Initialized
INFO - 2025-09-19 03:55:40 --> Model "User_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:55:40 --> Controller Class Initialized
INFO - 2025-09-19 08:55:40 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Video_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:55:40 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:55:40 --> Pagination Class Initialized
INFO - 2025-09-19 08:55:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:55:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:55:40 --> Model "Log_model" initialized
INFO - 2025-09-19 08:55:40 --> Final output sent to browser
DEBUG - 2025-09-19 08:55:40 --> Total execution time: 0.1185
INFO - 2025-09-19 03:55:43 --> Config Class Initialized
INFO - 2025-09-19 03:55:43 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:55:43 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:55:43 --> Utf8 Class Initialized
INFO - 2025-09-19 03:55:43 --> URI Class Initialized
DEBUG - 2025-09-19 03:55:43 --> No URI present. Default controller set.
INFO - 2025-09-19 03:55:43 --> Router Class Initialized
INFO - 2025-09-19 03:55:43 --> Output Class Initialized
INFO - 2025-09-19 03:55:43 --> Security Class Initialized
DEBUG - 2025-09-19 03:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:55:43 --> CSRF cookie sent
INFO - 2025-09-19 03:55:43 --> Input Class Initialized
INFO - 2025-09-19 03:55:43 --> Language Class Initialized
INFO - 2025-09-19 03:55:43 --> Loader Class Initialized
INFO - 2025-09-19 03:55:43 --> Helper loaded: url_helper
INFO - 2025-09-19 03:55:43 --> Helper loaded: text_helper
INFO - 2025-09-19 03:55:43 --> Helper loaded: string_helper
INFO - 2025-09-19 03:55:43 --> Helper loaded: form_helper
INFO - 2025-09-19 03:55:43 --> Helper loaded: download_helper
INFO - 2025-09-19 03:55:43 --> Helper loaded: security_helper
INFO - 2025-09-19 03:55:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:55:43 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:55:43 --> Form Validation Class Initialized
INFO - 2025-09-19 03:55:43 --> Model "User_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:55:43 --> Controller Class Initialized
INFO - 2025-09-19 08:55:43 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Video_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:55:43 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:55:43 --> Pagination Class Initialized
INFO - 2025-09-19 08:55:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:55:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:55:43 --> Model "Log_model" initialized
INFO - 2025-09-19 08:55:43 --> Final output sent to browser
DEBUG - 2025-09-19 08:55:43 --> Total execution time: 0.1096
INFO - 2025-09-19 03:57:54 --> Config Class Initialized
INFO - 2025-09-19 03:57:54 --> Hooks Class Initialized
DEBUG - 2025-09-19 03:57:54 --> UTF-8 Support Enabled
INFO - 2025-09-19 03:57:54 --> Utf8 Class Initialized
INFO - 2025-09-19 03:57:54 --> URI Class Initialized
DEBUG - 2025-09-19 03:57:54 --> No URI present. Default controller set.
INFO - 2025-09-19 03:57:54 --> Router Class Initialized
INFO - 2025-09-19 03:57:54 --> Output Class Initialized
INFO - 2025-09-19 03:57:54 --> Security Class Initialized
DEBUG - 2025-09-19 03:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 03:57:54 --> CSRF cookie sent
INFO - 2025-09-19 03:57:54 --> Input Class Initialized
INFO - 2025-09-19 03:57:54 --> Language Class Initialized
INFO - 2025-09-19 03:57:54 --> Loader Class Initialized
INFO - 2025-09-19 03:57:54 --> Helper loaded: url_helper
INFO - 2025-09-19 03:57:54 --> Helper loaded: text_helper
INFO - 2025-09-19 03:57:54 --> Helper loaded: string_helper
INFO - 2025-09-19 03:57:54 --> Helper loaded: form_helper
INFO - 2025-09-19 03:57:54 --> Helper loaded: download_helper
INFO - 2025-09-19 03:57:54 --> Helper loaded: security_helper
INFO - 2025-09-19 03:57:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 03:57:54 --> Database Driver Class Initialized
DEBUG - 2025-09-19 03:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 03:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 03:57:54 --> Form Validation Class Initialized
INFO - 2025-09-19 03:57:54 --> Model "User_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Nav_model" initialized
INFO - 2025-09-19 08:57:54 --> Controller Class Initialized
INFO - 2025-09-19 08:57:54 --> Model "Berita_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Galeri_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Video_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Agenda_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Tautan_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Mitra_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Prodi_model" initialized
INFO - 2025-09-19 08:57:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 08:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 08:57:54 --> Pagination Class Initialized
INFO - 2025-09-19 08:57:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 08:57:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 08:57:54 --> Model "Log_model" initialized
INFO - 2025-09-19 08:57:54 --> Final output sent to browser
DEBUG - 2025-09-19 08:57:54 --> Total execution time: 0.0840
INFO - 2025-09-19 04:03:34 --> Config Class Initialized
INFO - 2025-09-19 04:03:34 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:03:34 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:03:34 --> Utf8 Class Initialized
INFO - 2025-09-19 04:03:34 --> URI Class Initialized
INFO - 2025-09-19 04:03:34 --> Router Class Initialized
INFO - 2025-09-19 04:03:34 --> Output Class Initialized
INFO - 2025-09-19 04:03:34 --> Security Class Initialized
DEBUG - 2025-09-19 04:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:03:34 --> CSRF cookie sent
INFO - 2025-09-19 04:03:34 --> Input Class Initialized
INFO - 2025-09-19 04:03:34 --> Language Class Initialized
INFO - 2025-09-19 04:03:34 --> Loader Class Initialized
INFO - 2025-09-19 04:03:34 --> Helper loaded: url_helper
INFO - 2025-09-19 04:03:34 --> Helper loaded: text_helper
INFO - 2025-09-19 04:03:34 --> Helper loaded: string_helper
INFO - 2025-09-19 04:03:34 --> Helper loaded: form_helper
INFO - 2025-09-19 04:03:34 --> Helper loaded: download_helper
INFO - 2025-09-19 04:03:34 --> Helper loaded: security_helper
INFO - 2025-09-19 04:03:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:03:34 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:03:34 --> Form Validation Class Initialized
INFO - 2025-09-19 04:03:34 --> Model "User_model" initialized
INFO - 2025-09-19 09:03:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:03:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:03:34 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:03:34 --> Controller Class Initialized
DEBUG - 2025-09-19 09:03:34 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:03:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:03:35 --> Model "Log_model" initialized
INFO - 2025-09-19 09:03:35 --> Final output sent to browser
DEBUG - 2025-09-19 09:03:35 --> Total execution time: 0.1779
INFO - 2025-09-19 04:03:37 --> Config Class Initialized
INFO - 2025-09-19 04:03:37 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:03:37 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:03:37 --> Utf8 Class Initialized
INFO - 2025-09-19 04:03:37 --> URI Class Initialized
INFO - 2025-09-19 04:03:37 --> Router Class Initialized
INFO - 2025-09-19 04:03:37 --> Output Class Initialized
INFO - 2025-09-19 04:03:37 --> Security Class Initialized
DEBUG - 2025-09-19 04:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:03:37 --> CSRF cookie sent
INFO - 2025-09-19 04:03:37 --> Input Class Initialized
INFO - 2025-09-19 04:03:37 --> Language Class Initialized
INFO - 2025-09-19 04:03:37 --> Loader Class Initialized
INFO - 2025-09-19 04:03:37 --> Helper loaded: url_helper
INFO - 2025-09-19 04:03:37 --> Helper loaded: text_helper
INFO - 2025-09-19 04:03:37 --> Helper loaded: string_helper
INFO - 2025-09-19 04:03:37 --> Helper loaded: form_helper
INFO - 2025-09-19 04:03:37 --> Helper loaded: download_helper
INFO - 2025-09-19 04:03:37 --> Helper loaded: security_helper
INFO - 2025-09-19 04:03:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:03:37 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:03:37 --> Form Validation Class Initialized
INFO - 2025-09-19 04:03:37 --> Model "User_model" initialized
INFO - 2025-09-19 09:03:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:03:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:03:37 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:03:37 --> Controller Class Initialized
DEBUG - 2025-09-19 09:03:37 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:03:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:03:37 --> Model "Log_model" initialized
INFO - 2025-09-19 09:03:37 --> Final output sent to browser
DEBUG - 2025-09-19 09:03:37 --> Total execution time: 0.0502
INFO - 2025-09-19 04:03:43 --> Config Class Initialized
INFO - 2025-09-19 04:03:43 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:03:43 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:03:43 --> Utf8 Class Initialized
INFO - 2025-09-19 04:03:43 --> URI Class Initialized
INFO - 2025-09-19 04:03:43 --> Router Class Initialized
INFO - 2025-09-19 04:03:43 --> Output Class Initialized
INFO - 2025-09-19 04:03:43 --> Security Class Initialized
DEBUG - 2025-09-19 04:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:03:43 --> CSRF cookie sent
INFO - 2025-09-19 04:03:43 --> Input Class Initialized
INFO - 2025-09-19 04:03:43 --> Language Class Initialized
INFO - 2025-09-19 04:03:43 --> Loader Class Initialized
INFO - 2025-09-19 04:03:43 --> Helper loaded: url_helper
INFO - 2025-09-19 04:03:43 --> Helper loaded: text_helper
INFO - 2025-09-19 04:03:43 --> Helper loaded: string_helper
INFO - 2025-09-19 04:03:43 --> Helper loaded: form_helper
INFO - 2025-09-19 04:03:43 --> Helper loaded: download_helper
INFO - 2025-09-19 04:03:43 --> Helper loaded: security_helper
INFO - 2025-09-19 04:03:43 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:03:43 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:03:43 --> Form Validation Class Initialized
INFO - 2025-09-19 04:03:43 --> Model "User_model" initialized
INFO - 2025-09-19 09:03:43 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:03:43 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:03:43 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:03:43 --> Controller Class Initialized
DEBUG - 2025-09-19 09:03:43 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:03:43 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:03:43 --> Model "Log_model" initialized
INFO - 2025-09-19 09:03:43 --> Final output sent to browser
DEBUG - 2025-09-19 09:03:43 --> Total execution time: 0.0338
INFO - 2025-09-19 04:03:46 --> Config Class Initialized
INFO - 2025-09-19 04:03:46 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:03:46 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:03:46 --> Utf8 Class Initialized
INFO - 2025-09-19 04:03:46 --> URI Class Initialized
INFO - 2025-09-19 04:03:46 --> Router Class Initialized
INFO - 2025-09-19 04:03:46 --> Output Class Initialized
INFO - 2025-09-19 04:03:46 --> Security Class Initialized
DEBUG - 2025-09-19 04:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:03:46 --> CSRF cookie sent
INFO - 2025-09-19 04:03:46 --> Input Class Initialized
INFO - 2025-09-19 04:03:46 --> Language Class Initialized
INFO - 2025-09-19 04:03:46 --> Loader Class Initialized
INFO - 2025-09-19 04:03:46 --> Helper loaded: url_helper
INFO - 2025-09-19 04:03:46 --> Helper loaded: text_helper
INFO - 2025-09-19 04:03:46 --> Helper loaded: string_helper
INFO - 2025-09-19 04:03:46 --> Helper loaded: form_helper
INFO - 2025-09-19 04:03:46 --> Helper loaded: download_helper
INFO - 2025-09-19 04:03:46 --> Helper loaded: security_helper
INFO - 2025-09-19 04:03:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:03:46 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:03:46 --> Form Validation Class Initialized
INFO - 2025-09-19 04:03:46 --> Model "User_model" initialized
INFO - 2025-09-19 09:03:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:03:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:03:46 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:03:46 --> Controller Class Initialized
DEBUG - 2025-09-19 09:03:46 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:03:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:03:46 --> Model "Log_model" initialized
INFO - 2025-09-19 09:03:46 --> Final output sent to browser
DEBUG - 2025-09-19 09:03:46 --> Total execution time: 0.0544
INFO - 2025-09-19 04:04:16 --> Config Class Initialized
INFO - 2025-09-19 04:04:16 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:04:16 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:04:16 --> Utf8 Class Initialized
INFO - 2025-09-19 04:04:16 --> URI Class Initialized
INFO - 2025-09-19 04:04:16 --> Router Class Initialized
INFO - 2025-09-19 04:04:16 --> Output Class Initialized
INFO - 2025-09-19 04:04:16 --> Security Class Initialized
DEBUG - 2025-09-19 04:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:04:16 --> CSRF cookie sent
INFO - 2025-09-19 04:04:16 --> Input Class Initialized
INFO - 2025-09-19 04:04:16 --> Language Class Initialized
INFO - 2025-09-19 04:04:16 --> Loader Class Initialized
INFO - 2025-09-19 04:04:16 --> Helper loaded: url_helper
INFO - 2025-09-19 04:04:16 --> Helper loaded: text_helper
INFO - 2025-09-19 04:04:16 --> Helper loaded: string_helper
INFO - 2025-09-19 04:04:16 --> Helper loaded: form_helper
INFO - 2025-09-19 04:04:16 --> Helper loaded: download_helper
INFO - 2025-09-19 04:04:16 --> Helper loaded: security_helper
INFO - 2025-09-19 04:04:16 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:04:16 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:04:16 --> Form Validation Class Initialized
INFO - 2025-09-19 04:04:16 --> Model "User_model" initialized
INFO - 2025-09-19 09:04:16 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:04:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:04:16 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:04:16 --> Controller Class Initialized
DEBUG - 2025-09-19 09:04:16 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:04:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:04:16 --> Model "Log_model" initialized
INFO - 2025-09-19 09:04:16 --> Final output sent to browser
DEBUG - 2025-09-19 09:04:16 --> Total execution time: 0.0440
INFO - 2025-09-19 04:04:17 --> Config Class Initialized
INFO - 2025-09-19 04:04:17 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:04:17 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:04:17 --> Utf8 Class Initialized
INFO - 2025-09-19 04:04:17 --> URI Class Initialized
INFO - 2025-09-19 04:04:17 --> Router Class Initialized
INFO - 2025-09-19 04:04:17 --> Output Class Initialized
INFO - 2025-09-19 04:04:17 --> Security Class Initialized
DEBUG - 2025-09-19 04:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:04:17 --> CSRF cookie sent
INFO - 2025-09-19 04:04:17 --> Input Class Initialized
INFO - 2025-09-19 04:04:17 --> Language Class Initialized
INFO - 2025-09-19 04:04:17 --> Loader Class Initialized
INFO - 2025-09-19 04:04:17 --> Helper loaded: url_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: text_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: string_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: form_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: download_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: security_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:04:17 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:04:17 --> Form Validation Class Initialized
INFO - 2025-09-19 04:04:17 --> Model "User_model" initialized
INFO - 2025-09-19 09:04:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:04:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:04:17 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:04:17 --> Controller Class Initialized
DEBUG - 2025-09-19 09:04:17 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:04:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:04:17 --> Model "Log_model" initialized
INFO - 2025-09-19 09:04:17 --> Final output sent to browser
DEBUG - 2025-09-19 09:04:17 --> Total execution time: 0.0544
INFO - 2025-09-19 04:04:17 --> Config Class Initialized
INFO - 2025-09-19 04:04:17 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:04:17 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:04:17 --> Utf8 Class Initialized
INFO - 2025-09-19 04:04:17 --> URI Class Initialized
INFO - 2025-09-19 04:04:17 --> Router Class Initialized
INFO - 2025-09-19 04:04:17 --> Output Class Initialized
INFO - 2025-09-19 04:04:17 --> Security Class Initialized
DEBUG - 2025-09-19 04:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:04:17 --> CSRF cookie sent
INFO - 2025-09-19 04:04:17 --> Input Class Initialized
INFO - 2025-09-19 04:04:17 --> Language Class Initialized
INFO - 2025-09-19 04:04:17 --> Loader Class Initialized
INFO - 2025-09-19 04:04:17 --> Helper loaded: url_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: text_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: string_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: form_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: download_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: security_helper
INFO - 2025-09-19 04:04:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:04:17 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:04:17 --> Form Validation Class Initialized
INFO - 2025-09-19 04:04:17 --> Model "User_model" initialized
INFO - 2025-09-19 09:04:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:04:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:04:17 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:04:17 --> Controller Class Initialized
DEBUG - 2025-09-19 09:04:17 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:04:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:04:17 --> Model "Log_model" initialized
INFO - 2025-09-19 09:04:17 --> Final output sent to browser
DEBUG - 2025-09-19 09:04:17 --> Total execution time: 0.0484
INFO - 2025-09-19 04:04:18 --> Config Class Initialized
INFO - 2025-09-19 04:04:18 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:04:18 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:04:18 --> Utf8 Class Initialized
INFO - 2025-09-19 04:04:18 --> URI Class Initialized
INFO - 2025-09-19 04:04:18 --> Router Class Initialized
INFO - 2025-09-19 04:04:18 --> Output Class Initialized
INFO - 2025-09-19 04:04:18 --> Security Class Initialized
DEBUG - 2025-09-19 04:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:04:18 --> CSRF cookie sent
INFO - 2025-09-19 04:04:18 --> Input Class Initialized
INFO - 2025-09-19 04:04:18 --> Language Class Initialized
INFO - 2025-09-19 04:04:18 --> Loader Class Initialized
INFO - 2025-09-19 04:04:18 --> Helper loaded: url_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: text_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: string_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: form_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: download_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: security_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:04:18 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:04:18 --> Form Validation Class Initialized
INFO - 2025-09-19 04:04:18 --> Model "User_model" initialized
INFO - 2025-09-19 09:04:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:04:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:04:18 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:04:18 --> Controller Class Initialized
DEBUG - 2025-09-19 09:04:18 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:04:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:04:18 --> Model "Log_model" initialized
INFO - 2025-09-19 09:04:18 --> Final output sent to browser
DEBUG - 2025-09-19 09:04:18 --> Total execution time: 0.0595
INFO - 2025-09-19 04:04:18 --> Config Class Initialized
INFO - 2025-09-19 04:04:18 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:04:18 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:04:18 --> Utf8 Class Initialized
INFO - 2025-09-19 04:04:18 --> URI Class Initialized
INFO - 2025-09-19 04:04:18 --> Router Class Initialized
INFO - 2025-09-19 04:04:18 --> Output Class Initialized
INFO - 2025-09-19 04:04:18 --> Security Class Initialized
DEBUG - 2025-09-19 04:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:04:18 --> CSRF cookie sent
INFO - 2025-09-19 04:04:18 --> Input Class Initialized
INFO - 2025-09-19 04:04:18 --> Language Class Initialized
INFO - 2025-09-19 04:04:18 --> Loader Class Initialized
INFO - 2025-09-19 04:04:18 --> Helper loaded: url_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: text_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: string_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: form_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: download_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: security_helper
INFO - 2025-09-19 04:04:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:04:18 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:04:18 --> Form Validation Class Initialized
INFO - 2025-09-19 04:04:18 --> Model "User_model" initialized
INFO - 2025-09-19 09:04:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:04:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:04:18 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:04:18 --> Controller Class Initialized
DEBUG - 2025-09-19 09:04:18 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:04:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:04:18 --> Model "Log_model" initialized
INFO - 2025-09-19 09:04:18 --> Final output sent to browser
DEBUG - 2025-09-19 09:04:18 --> Total execution time: 0.0363
INFO - 2025-09-19 04:05:07 --> Config Class Initialized
INFO - 2025-09-19 04:05:07 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:05:07 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:05:07 --> Utf8 Class Initialized
INFO - 2025-09-19 04:05:07 --> URI Class Initialized
INFO - 2025-09-19 04:05:07 --> Router Class Initialized
INFO - 2025-09-19 04:05:07 --> Output Class Initialized
INFO - 2025-09-19 04:05:07 --> Security Class Initialized
DEBUG - 2025-09-19 04:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:05:07 --> CSRF cookie sent
INFO - 2025-09-19 04:05:07 --> Input Class Initialized
INFO - 2025-09-19 04:05:07 --> Language Class Initialized
INFO - 2025-09-19 04:05:07 --> Loader Class Initialized
INFO - 2025-09-19 04:05:07 --> Helper loaded: url_helper
INFO - 2025-09-19 04:05:07 --> Helper loaded: text_helper
INFO - 2025-09-19 04:05:07 --> Helper loaded: string_helper
INFO - 2025-09-19 04:05:07 --> Helper loaded: form_helper
INFO - 2025-09-19 04:05:07 --> Helper loaded: download_helper
INFO - 2025-09-19 04:05:07 --> Helper loaded: security_helper
INFO - 2025-09-19 04:05:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:05:07 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:05:07 --> Form Validation Class Initialized
INFO - 2025-09-19 04:05:07 --> Model "User_model" initialized
INFO - 2025-09-19 09:05:07 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:05:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:05:07 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:05:07 --> Controller Class Initialized
DEBUG - 2025-09-19 09:05:07 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:05:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:05:07 --> Model "Log_model" initialized
INFO - 2025-09-19 09:05:07 --> Final output sent to browser
DEBUG - 2025-09-19 09:05:07 --> Total execution time: 0.0335
INFO - 2025-09-19 04:06:50 --> Config Class Initialized
INFO - 2025-09-19 04:06:50 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:06:50 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:06:50 --> Utf8 Class Initialized
INFO - 2025-09-19 04:06:50 --> URI Class Initialized
INFO - 2025-09-19 04:06:50 --> Router Class Initialized
INFO - 2025-09-19 04:06:50 --> Output Class Initialized
INFO - 2025-09-19 04:06:50 --> Security Class Initialized
DEBUG - 2025-09-19 04:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:06:50 --> CSRF cookie sent
INFO - 2025-09-19 04:06:50 --> Input Class Initialized
INFO - 2025-09-19 04:06:50 --> Language Class Initialized
INFO - 2025-09-19 04:06:50 --> Loader Class Initialized
INFO - 2025-09-19 04:06:50 --> Helper loaded: url_helper
INFO - 2025-09-19 04:06:50 --> Helper loaded: text_helper
INFO - 2025-09-19 04:06:50 --> Helper loaded: string_helper
INFO - 2025-09-19 04:06:50 --> Helper loaded: form_helper
INFO - 2025-09-19 04:06:50 --> Helper loaded: download_helper
INFO - 2025-09-19 04:06:50 --> Helper loaded: security_helper
INFO - 2025-09-19 04:06:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:06:50 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:06:50 --> Form Validation Class Initialized
INFO - 2025-09-19 04:06:50 --> Model "User_model" initialized
INFO - 2025-09-19 09:06:50 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:06:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:06:50 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:06:50 --> Controller Class Initialized
DEBUG - 2025-09-19 09:06:50 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:06:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:06:50 --> Model "Log_model" initialized
INFO - 2025-09-19 09:06:50 --> Final output sent to browser
DEBUG - 2025-09-19 09:06:50 --> Total execution time: 0.0500
INFO - 2025-09-19 04:06:52 --> Config Class Initialized
INFO - 2025-09-19 04:06:52 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:06:52 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:06:52 --> Utf8 Class Initialized
INFO - 2025-09-19 04:06:52 --> URI Class Initialized
INFO - 2025-09-19 04:06:52 --> Router Class Initialized
INFO - 2025-09-19 04:06:52 --> Output Class Initialized
INFO - 2025-09-19 04:06:52 --> Security Class Initialized
DEBUG - 2025-09-19 04:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:06:52 --> CSRF cookie sent
INFO - 2025-09-19 04:06:52 --> Input Class Initialized
INFO - 2025-09-19 04:06:52 --> Language Class Initialized
INFO - 2025-09-19 04:06:52 --> Loader Class Initialized
INFO - 2025-09-19 04:06:52 --> Helper loaded: url_helper
INFO - 2025-09-19 04:06:52 --> Helper loaded: text_helper
INFO - 2025-09-19 04:06:52 --> Helper loaded: string_helper
INFO - 2025-09-19 04:06:52 --> Helper loaded: form_helper
INFO - 2025-09-19 04:06:52 --> Helper loaded: download_helper
INFO - 2025-09-19 04:06:52 --> Helper loaded: security_helper
INFO - 2025-09-19 04:06:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:06:52 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:06:52 --> Form Validation Class Initialized
INFO - 2025-09-19 04:06:52 --> Model "User_model" initialized
INFO - 2025-09-19 09:06:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:06:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:06:52 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:06:52 --> Controller Class Initialized
DEBUG - 2025-09-19 09:06:52 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:06:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:06:52 --> Model "Log_model" initialized
INFO - 2025-09-19 09:06:52 --> Final output sent to browser
DEBUG - 2025-09-19 09:06:52 --> Total execution time: 0.0592
INFO - 2025-09-19 04:07:35 --> Config Class Initialized
INFO - 2025-09-19 04:07:35 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:07:35 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:07:35 --> Utf8 Class Initialized
INFO - 2025-09-19 04:07:35 --> URI Class Initialized
INFO - 2025-09-19 04:07:35 --> Router Class Initialized
INFO - 2025-09-19 04:07:35 --> Output Class Initialized
INFO - 2025-09-19 04:07:35 --> Security Class Initialized
DEBUG - 2025-09-19 04:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:07:35 --> CSRF cookie sent
INFO - 2025-09-19 04:07:35 --> Input Class Initialized
INFO - 2025-09-19 04:07:35 --> Language Class Initialized
INFO - 2025-09-19 04:07:35 --> Loader Class Initialized
INFO - 2025-09-19 04:07:35 --> Helper loaded: url_helper
INFO - 2025-09-19 04:07:35 --> Helper loaded: text_helper
INFO - 2025-09-19 04:07:35 --> Helper loaded: string_helper
INFO - 2025-09-19 04:07:35 --> Helper loaded: form_helper
INFO - 2025-09-19 04:07:35 --> Helper loaded: download_helper
INFO - 2025-09-19 04:07:35 --> Helper loaded: security_helper
INFO - 2025-09-19 04:07:35 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:07:35 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:07:35 --> Form Validation Class Initialized
INFO - 2025-09-19 04:07:35 --> Model "User_model" initialized
INFO - 2025-09-19 09:07:35 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:07:35 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:07:35 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:07:35 --> Controller Class Initialized
DEBUG - 2025-09-19 09:07:35 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:07:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:07:35 --> Model "Log_model" initialized
INFO - 2025-09-19 09:07:35 --> Final output sent to browser
DEBUG - 2025-09-19 09:07:35 --> Total execution time: 0.0414
INFO - 2025-09-19 04:08:45 --> Config Class Initialized
INFO - 2025-09-19 04:08:45 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:08:45 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:08:45 --> Utf8 Class Initialized
INFO - 2025-09-19 04:08:45 --> URI Class Initialized
INFO - 2025-09-19 04:08:45 --> Router Class Initialized
INFO - 2025-09-19 04:08:45 --> Output Class Initialized
INFO - 2025-09-19 04:08:45 --> Security Class Initialized
DEBUG - 2025-09-19 04:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:08:45 --> CSRF cookie sent
INFO - 2025-09-19 04:08:45 --> Input Class Initialized
INFO - 2025-09-19 04:08:45 --> Language Class Initialized
INFO - 2025-09-19 04:08:45 --> Loader Class Initialized
INFO - 2025-09-19 04:08:45 --> Helper loaded: url_helper
INFO - 2025-09-19 04:08:45 --> Helper loaded: text_helper
INFO - 2025-09-19 04:08:45 --> Helper loaded: string_helper
INFO - 2025-09-19 04:08:45 --> Helper loaded: form_helper
INFO - 2025-09-19 04:08:45 --> Helper loaded: download_helper
INFO - 2025-09-19 04:08:45 --> Helper loaded: security_helper
INFO - 2025-09-19 04:08:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:08:45 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:08:45 --> Form Validation Class Initialized
INFO - 2025-09-19 04:08:45 --> Model "User_model" initialized
INFO - 2025-09-19 09:08:45 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:08:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:08:45 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:08:45 --> Controller Class Initialized
DEBUG - 2025-09-19 09:08:45 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:08:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 09:08:45 --> Model "Log_model" initialized
INFO - 2025-09-19 09:08:45 --> Final output sent to browser
DEBUG - 2025-09-19 09:08:45 --> Total execution time: 0.0527
INFO - 2025-09-19 04:08:56 --> Config Class Initialized
INFO - 2025-09-19 04:08:56 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:08:56 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:08:56 --> Utf8 Class Initialized
INFO - 2025-09-19 04:08:56 --> URI Class Initialized
INFO - 2025-09-19 04:08:56 --> Router Class Initialized
INFO - 2025-09-19 04:08:56 --> Output Class Initialized
INFO - 2025-09-19 04:08:56 --> Security Class Initialized
DEBUG - 2025-09-19 04:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:08:56 --> CSRF cookie sent
INFO - 2025-09-19 04:08:56 --> CSRF token verified
INFO - 2025-09-19 04:08:56 --> Input Class Initialized
INFO - 2025-09-19 04:08:56 --> Language Class Initialized
INFO - 2025-09-19 04:08:56 --> Loader Class Initialized
INFO - 2025-09-19 04:08:56 --> Helper loaded: url_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: text_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: string_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: form_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: download_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: security_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:08:56 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:08:56 --> Form Validation Class Initialized
INFO - 2025-09-19 04:08:56 --> Model "User_model" initialized
INFO - 2025-09-19 09:08:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:08:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:08:56 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:08:56 --> Controller Class Initialized
DEBUG - 2025-09-19 09:08:56 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 09:08:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 04:08:56 --> Config Class Initialized
INFO - 2025-09-19 04:08:56 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:08:56 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:08:56 --> Utf8 Class Initialized
INFO - 2025-09-19 04:08:56 --> URI Class Initialized
INFO - 2025-09-19 04:08:56 --> Router Class Initialized
INFO - 2025-09-19 04:08:56 --> Output Class Initialized
INFO - 2025-09-19 04:08:56 --> Security Class Initialized
DEBUG - 2025-09-19 04:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:08:56 --> CSRF cookie sent
INFO - 2025-09-19 04:08:56 --> Input Class Initialized
INFO - 2025-09-19 04:08:56 --> Language Class Initialized
INFO - 2025-09-19 04:08:56 --> Loader Class Initialized
INFO - 2025-09-19 04:08:56 --> Helper loaded: url_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: text_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: string_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: form_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: download_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: security_helper
INFO - 2025-09-19 04:08:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:08:56 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:08:56 --> Form Validation Class Initialized
INFO - 2025-09-19 04:08:56 --> Model "User_model" initialized
INFO - 2025-09-19 09:08:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:08:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:08:56 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:08:56 --> Controller Class Initialized
INFO - 2025-09-19 09:08:56 --> Model "Tautan_model" initialized
INFO - 2025-09-19 09:08:56 --> Model "Staff_model" initialized
INFO - 2025-09-19 09:08:57 --> Model "Dasbor_model" initialized
INFO - 2025-09-19 09:08:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-09-19 09:08:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:08:58 --> Model "Log_model" initialized
INFO - 2025-09-19 09:08:58 --> Final output sent to browser
DEBUG - 2025-09-19 09:08:58 --> Total execution time: 1.5348
INFO - 2025-09-19 04:09:06 --> Config Class Initialized
INFO - 2025-09-19 04:09:06 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:09:06 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:09:06 --> Utf8 Class Initialized
INFO - 2025-09-19 04:09:06 --> URI Class Initialized
INFO - 2025-09-19 04:09:06 --> Router Class Initialized
INFO - 2025-09-19 04:09:06 --> Output Class Initialized
INFO - 2025-09-19 04:09:06 --> Security Class Initialized
DEBUG - 2025-09-19 04:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:09:06 --> CSRF cookie sent
INFO - 2025-09-19 04:09:06 --> Input Class Initialized
INFO - 2025-09-19 04:09:06 --> Language Class Initialized
INFO - 2025-09-19 04:09:06 --> Loader Class Initialized
INFO - 2025-09-19 04:09:06 --> Helper loaded: url_helper
INFO - 2025-09-19 04:09:06 --> Helper loaded: text_helper
INFO - 2025-09-19 04:09:06 --> Helper loaded: string_helper
INFO - 2025-09-19 04:09:06 --> Helper loaded: form_helper
INFO - 2025-09-19 04:09:06 --> Helper loaded: download_helper
INFO - 2025-09-19 04:09:06 --> Helper loaded: security_helper
INFO - 2025-09-19 04:09:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:09:06 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:09:06 --> Form Validation Class Initialized
INFO - 2025-09-19 04:09:06 --> Model "User_model" initialized
INFO - 2025-09-19 09:09:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:09:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:09:06 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:09:06 --> Controller Class Initialized
INFO - 2025-09-19 09:09:06 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:09:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:09:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-19 09:09:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:09:08 --> Model "Log_model" initialized
INFO - 2025-09-19 09:09:08 --> Final output sent to browser
DEBUG - 2025-09-19 09:09:08 --> Total execution time: 1.2418
INFO - 2025-09-19 04:09:10 --> Config Class Initialized
INFO - 2025-09-19 04:09:10 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:09:10 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:09:10 --> Utf8 Class Initialized
INFO - 2025-09-19 04:09:10 --> URI Class Initialized
INFO - 2025-09-19 04:09:10 --> Router Class Initialized
INFO - 2025-09-19 04:09:10 --> Output Class Initialized
INFO - 2025-09-19 04:09:10 --> Security Class Initialized
DEBUG - 2025-09-19 04:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:09:10 --> CSRF cookie sent
INFO - 2025-09-19 04:09:10 --> Input Class Initialized
INFO - 2025-09-19 04:09:10 --> Language Class Initialized
INFO - 2025-09-19 04:09:10 --> Loader Class Initialized
INFO - 2025-09-19 04:09:10 --> Helper loaded: url_helper
INFO - 2025-09-19 04:09:10 --> Helper loaded: text_helper
INFO - 2025-09-19 04:09:10 --> Helper loaded: string_helper
INFO - 2025-09-19 04:09:10 --> Helper loaded: form_helper
INFO - 2025-09-19 04:09:10 --> Helper loaded: download_helper
INFO - 2025-09-19 04:09:10 --> Helper loaded: security_helper
INFO - 2025-09-19 04:09:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:09:10 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:09:10 --> Form Validation Class Initialized
INFO - 2025-09-19 04:09:10 --> Model "User_model" initialized
INFO - 2025-09-19 09:09:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:09:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:09:10 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:09:10 --> Controller Class Initialized
INFO - 2025-09-19 09:09:10 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:09:10 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:09:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:09:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:09:11 --> Model "Log_model" initialized
INFO - 2025-09-19 09:09:11 --> Final output sent to browser
DEBUG - 2025-09-19 09:09:11 --> Total execution time: 0.7690
INFO - 2025-09-19 04:09:52 --> Config Class Initialized
INFO - 2025-09-19 04:09:52 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:09:52 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:09:52 --> Utf8 Class Initialized
INFO - 2025-09-19 04:09:52 --> URI Class Initialized
INFO - 2025-09-19 04:09:52 --> Router Class Initialized
INFO - 2025-09-19 04:09:52 --> Output Class Initialized
INFO - 2025-09-19 04:09:52 --> Security Class Initialized
DEBUG - 2025-09-19 04:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:09:52 --> CSRF cookie sent
INFO - 2025-09-19 04:09:52 --> Input Class Initialized
INFO - 2025-09-19 04:09:52 --> Language Class Initialized
INFO - 2025-09-19 04:09:52 --> Loader Class Initialized
INFO - 2025-09-19 04:09:52 --> Helper loaded: url_helper
INFO - 2025-09-19 04:09:52 --> Helper loaded: text_helper
INFO - 2025-09-19 04:09:52 --> Helper loaded: string_helper
INFO - 2025-09-19 04:09:52 --> Helper loaded: form_helper
INFO - 2025-09-19 04:09:52 --> Helper loaded: download_helper
INFO - 2025-09-19 04:09:52 --> Helper loaded: security_helper
INFO - 2025-09-19 04:09:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:09:52 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:09:52 --> Form Validation Class Initialized
INFO - 2025-09-19 04:09:52 --> Model "User_model" initialized
INFO - 2025-09-19 09:09:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:09:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:09:52 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:09:52 --> Controller Class Initialized
INFO - 2025-09-19 09:09:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:09:52 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:09:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:09:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:09:52 --> Model "Log_model" initialized
INFO - 2025-09-19 09:09:52 --> Final output sent to browser
DEBUG - 2025-09-19 09:09:52 --> Total execution time: 0.3580
INFO - 2025-09-19 04:11:06 --> Config Class Initialized
INFO - 2025-09-19 04:11:06 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:11:06 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:11:06 --> Utf8 Class Initialized
INFO - 2025-09-19 04:11:06 --> URI Class Initialized
INFO - 2025-09-19 04:11:06 --> Router Class Initialized
INFO - 2025-09-19 04:11:06 --> Output Class Initialized
INFO - 2025-09-19 04:11:06 --> Security Class Initialized
DEBUG - 2025-09-19 04:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:11:06 --> CSRF cookie sent
INFO - 2025-09-19 04:11:06 --> CSRF token verified
INFO - 2025-09-19 04:11:06 --> Input Class Initialized
INFO - 2025-09-19 04:11:06 --> Language Class Initialized
INFO - 2025-09-19 04:11:06 --> Loader Class Initialized
INFO - 2025-09-19 04:11:06 --> Helper loaded: url_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: text_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: string_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: form_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: download_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: security_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:11:06 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:11:06 --> Form Validation Class Initialized
INFO - 2025-09-19 04:11:06 --> Model "User_model" initialized
INFO - 2025-09-19 09:11:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:11:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:11:06 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:11:06 --> Controller Class Initialized
INFO - 2025-09-19 09:11:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:11:06 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:11:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 04:11:06 --> Config Class Initialized
INFO - 2025-09-19 04:11:06 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:11:06 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:11:06 --> Utf8 Class Initialized
INFO - 2025-09-19 04:11:06 --> URI Class Initialized
INFO - 2025-09-19 04:11:06 --> Router Class Initialized
INFO - 2025-09-19 04:11:06 --> Output Class Initialized
INFO - 2025-09-19 04:11:06 --> Security Class Initialized
DEBUG - 2025-09-19 04:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:11:06 --> CSRF cookie sent
INFO - 2025-09-19 04:11:06 --> Input Class Initialized
INFO - 2025-09-19 04:11:06 --> Language Class Initialized
INFO - 2025-09-19 04:11:06 --> Loader Class Initialized
INFO - 2025-09-19 04:11:06 --> Helper loaded: url_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: text_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: string_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: form_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: download_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: security_helper
INFO - 2025-09-19 04:11:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:11:06 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:11:06 --> Form Validation Class Initialized
INFO - 2025-09-19 04:11:06 --> Model "User_model" initialized
INFO - 2025-09-19 09:11:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:11:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:11:06 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:11:06 --> Controller Class Initialized
INFO - 2025-09-19 09:11:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:11:06 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:11:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:11:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:11:06 --> Model "Log_model" initialized
INFO - 2025-09-19 09:11:06 --> Final output sent to browser
DEBUG - 2025-09-19 09:11:06 --> Total execution time: 0.0496
INFO - 2025-09-19 04:11:09 --> Config Class Initialized
INFO - 2025-09-19 04:11:09 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:11:09 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:11:09 --> Utf8 Class Initialized
INFO - 2025-09-19 04:11:09 --> URI Class Initialized
DEBUG - 2025-09-19 04:11:09 --> No URI present. Default controller set.
INFO - 2025-09-19 04:11:09 --> Router Class Initialized
INFO - 2025-09-19 04:11:09 --> Output Class Initialized
INFO - 2025-09-19 04:11:09 --> Security Class Initialized
DEBUG - 2025-09-19 04:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:11:09 --> CSRF cookie sent
INFO - 2025-09-19 04:11:09 --> Input Class Initialized
INFO - 2025-09-19 04:11:09 --> Language Class Initialized
INFO - 2025-09-19 04:11:09 --> Loader Class Initialized
INFO - 2025-09-19 04:11:09 --> Helper loaded: url_helper
INFO - 2025-09-19 04:11:09 --> Helper loaded: text_helper
INFO - 2025-09-19 04:11:09 --> Helper loaded: string_helper
INFO - 2025-09-19 04:11:09 --> Helper loaded: form_helper
INFO - 2025-09-19 04:11:09 --> Helper loaded: download_helper
INFO - 2025-09-19 04:11:09 --> Helper loaded: security_helper
INFO - 2025-09-19 04:11:09 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:11:09 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:11:09 --> Form Validation Class Initialized
INFO - 2025-09-19 04:11:09 --> Model "User_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:11:09 --> Controller Class Initialized
INFO - 2025-09-19 09:11:09 --> Model "Berita_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Galeri_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Video_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Agenda_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Tautan_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Mitra_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:11:09 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 09:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 09:11:09 --> Pagination Class Initialized
INFO - 2025-09-19 09:11:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 09:11:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:11:09 --> Model "Log_model" initialized
INFO - 2025-09-19 09:11:09 --> Final output sent to browser
DEBUG - 2025-09-19 09:11:09 --> Total execution time: 0.1459
INFO - 2025-09-19 04:11:15 --> Config Class Initialized
INFO - 2025-09-19 04:11:15 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:11:15 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:11:15 --> Utf8 Class Initialized
INFO - 2025-09-19 04:11:15 --> URI Class Initialized
INFO - 2025-09-19 04:11:15 --> Router Class Initialized
INFO - 2025-09-19 04:11:15 --> Output Class Initialized
INFO - 2025-09-19 04:11:15 --> Security Class Initialized
DEBUG - 2025-09-19 04:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:11:15 --> CSRF cookie sent
INFO - 2025-09-19 04:11:15 --> Input Class Initialized
INFO - 2025-09-19 04:11:15 --> Language Class Initialized
INFO - 2025-09-19 04:11:15 --> Loader Class Initialized
INFO - 2025-09-19 04:11:15 --> Helper loaded: url_helper
INFO - 2025-09-19 04:11:15 --> Helper loaded: text_helper
INFO - 2025-09-19 04:11:15 --> Helper loaded: string_helper
INFO - 2025-09-19 04:11:15 --> Helper loaded: form_helper
INFO - 2025-09-19 04:11:15 --> Helper loaded: download_helper
INFO - 2025-09-19 04:11:15 --> Helper loaded: security_helper
INFO - 2025-09-19 04:11:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:11:15 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:11:15 --> Form Validation Class Initialized
INFO - 2025-09-19 04:11:15 --> Model "User_model" initialized
INFO - 2025-09-19 09:11:15 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:11:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:11:15 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:11:15 --> Controller Class Initialized
INFO - 2025-09-19 09:11:15 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:11:15 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:11:15 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:11:15 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:11:15 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:11:16 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-19 09:11:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-19 09:11:16 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:11:16 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:11:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:11:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:11:16 --> Model "Log_model" initialized
INFO - 2025-09-19 09:11:16 --> Final output sent to browser
DEBUG - 2025-09-19 09:11:16 --> Total execution time: 0.7813
INFO - 2025-09-19 04:13:18 --> Config Class Initialized
INFO - 2025-09-19 04:13:18 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:13:18 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:13:18 --> Utf8 Class Initialized
INFO - 2025-09-19 04:13:18 --> URI Class Initialized
INFO - 2025-09-19 04:13:18 --> Router Class Initialized
INFO - 2025-09-19 04:13:18 --> Output Class Initialized
INFO - 2025-09-19 04:13:18 --> Security Class Initialized
DEBUG - 2025-09-19 04:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:13:18 --> CSRF cookie sent
INFO - 2025-09-19 04:13:18 --> Input Class Initialized
INFO - 2025-09-19 04:13:18 --> Language Class Initialized
INFO - 2025-09-19 04:13:18 --> Loader Class Initialized
INFO - 2025-09-19 04:13:18 --> Helper loaded: url_helper
INFO - 2025-09-19 04:13:18 --> Helper loaded: text_helper
INFO - 2025-09-19 04:13:18 --> Helper loaded: string_helper
INFO - 2025-09-19 04:13:18 --> Helper loaded: form_helper
INFO - 2025-09-19 04:13:18 --> Helper loaded: download_helper
INFO - 2025-09-19 04:13:18 --> Helper loaded: security_helper
INFO - 2025-09-19 04:13:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:13:18 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:13:18 --> Form Validation Class Initialized
INFO - 2025-09-19 04:13:18 --> Model "User_model" initialized
INFO - 2025-09-19 09:13:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:13:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:13:18 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:13:18 --> Controller Class Initialized
INFO - 2025-09-19 09:13:18 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:13:18 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:13:18 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:13:18 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:13:18 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:13:18 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-19 09:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-19 09:13:18 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:13:18 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:13:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:13:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:13:18 --> Model "Log_model" initialized
INFO - 2025-09-19 09:13:18 --> Final output sent to browser
DEBUG - 2025-09-19 09:13:18 --> Total execution time: 0.1876
INFO - 2025-09-19 04:14:02 --> Config Class Initialized
INFO - 2025-09-19 04:14:02 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:14:02 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:14:02 --> Utf8 Class Initialized
INFO - 2025-09-19 04:14:02 --> URI Class Initialized
INFO - 2025-09-19 04:14:02 --> Router Class Initialized
INFO - 2025-09-19 04:14:02 --> Output Class Initialized
INFO - 2025-09-19 04:14:02 --> Security Class Initialized
DEBUG - 2025-09-19 04:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:14:02 --> CSRF cookie sent
INFO - 2025-09-19 04:14:02 --> Input Class Initialized
INFO - 2025-09-19 04:14:02 --> Language Class Initialized
INFO - 2025-09-19 04:14:02 --> Loader Class Initialized
INFO - 2025-09-19 04:14:02 --> Helper loaded: url_helper
INFO - 2025-09-19 04:14:02 --> Helper loaded: text_helper
INFO - 2025-09-19 04:14:02 --> Helper loaded: string_helper
INFO - 2025-09-19 04:14:02 --> Helper loaded: form_helper
INFO - 2025-09-19 04:14:02 --> Helper loaded: download_helper
INFO - 2025-09-19 04:14:02 --> Helper loaded: security_helper
INFO - 2025-09-19 04:14:02 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:14:02 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:14:02 --> Form Validation Class Initialized
INFO - 2025-09-19 04:14:02 --> Model "User_model" initialized
INFO - 2025-09-19 09:14:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:14:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:14:02 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:14:02 --> Controller Class Initialized
INFO - 2025-09-19 09:14:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:14:02 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:14:02 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:14:02 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:14:02 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:14:02 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:14:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:14:02 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:14:02 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:14:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:14:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:14:02 --> Model "Log_model" initialized
INFO - 2025-09-19 09:14:02 --> Final output sent to browser
DEBUG - 2025-09-19 09:14:02 --> Total execution time: 0.1893
INFO - 2025-09-19 04:18:46 --> Config Class Initialized
INFO - 2025-09-19 04:18:46 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:18:46 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:18:46 --> Utf8 Class Initialized
INFO - 2025-09-19 04:18:46 --> URI Class Initialized
INFO - 2025-09-19 04:18:46 --> Router Class Initialized
INFO - 2025-09-19 04:18:46 --> Output Class Initialized
INFO - 2025-09-19 04:18:46 --> Security Class Initialized
DEBUG - 2025-09-19 04:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:18:46 --> CSRF cookie sent
INFO - 2025-09-19 04:18:46 --> Input Class Initialized
INFO - 2025-09-19 04:18:46 --> Language Class Initialized
INFO - 2025-09-19 04:18:46 --> Loader Class Initialized
INFO - 2025-09-19 04:18:46 --> Helper loaded: url_helper
INFO - 2025-09-19 04:18:46 --> Helper loaded: text_helper
INFO - 2025-09-19 04:18:46 --> Helper loaded: string_helper
INFO - 2025-09-19 04:18:46 --> Helper loaded: form_helper
INFO - 2025-09-19 04:18:46 --> Helper loaded: download_helper
INFO - 2025-09-19 04:18:46 --> Helper loaded: security_helper
INFO - 2025-09-19 04:18:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:18:46 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:18:46 --> Form Validation Class Initialized
INFO - 2025-09-19 04:18:46 --> Model "User_model" initialized
INFO - 2025-09-19 09:18:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:18:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:18:46 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:18:46 --> Controller Class Initialized
INFO - 2025-09-19 09:18:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:18:46 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:18:46 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:18:46 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:18:46 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:18:46 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:18:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:18:46 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:18:46 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:18:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:18:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:18:46 --> Model "Log_model" initialized
INFO - 2025-09-19 09:18:46 --> Final output sent to browser
DEBUG - 2025-09-19 09:18:46 --> Total execution time: 0.0871
INFO - 2025-09-19 04:20:21 --> Config Class Initialized
INFO - 2025-09-19 04:20:21 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:20:21 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:20:21 --> Utf8 Class Initialized
INFO - 2025-09-19 04:20:21 --> URI Class Initialized
INFO - 2025-09-19 04:20:21 --> Router Class Initialized
INFO - 2025-09-19 04:20:21 --> Output Class Initialized
INFO - 2025-09-19 04:20:21 --> Security Class Initialized
DEBUG - 2025-09-19 04:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:20:21 --> CSRF cookie sent
INFO - 2025-09-19 04:20:21 --> Input Class Initialized
INFO - 2025-09-19 04:20:21 --> Language Class Initialized
INFO - 2025-09-19 04:20:21 --> Loader Class Initialized
INFO - 2025-09-19 04:20:21 --> Helper loaded: url_helper
INFO - 2025-09-19 04:20:21 --> Helper loaded: text_helper
INFO - 2025-09-19 04:20:21 --> Helper loaded: string_helper
INFO - 2025-09-19 04:20:21 --> Helper loaded: form_helper
INFO - 2025-09-19 04:20:21 --> Helper loaded: download_helper
INFO - 2025-09-19 04:20:21 --> Helper loaded: security_helper
INFO - 2025-09-19 04:20:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:20:21 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:20:21 --> Form Validation Class Initialized
INFO - 2025-09-19 04:20:21 --> Model "User_model" initialized
INFO - 2025-09-19 09:20:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:20:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:20:21 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:20:21 --> Controller Class Initialized
INFO - 2025-09-19 09:20:21 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:20:21 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:20:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-19 09:20:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:20:21 --> Model "Log_model" initialized
INFO - 2025-09-19 09:20:21 --> Final output sent to browser
DEBUG - 2025-09-19 09:20:21 --> Total execution time: 0.0460
INFO - 2025-09-19 04:20:25 --> Config Class Initialized
INFO - 2025-09-19 04:20:25 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:20:25 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:20:25 --> Utf8 Class Initialized
INFO - 2025-09-19 04:20:25 --> URI Class Initialized
INFO - 2025-09-19 04:20:25 --> Router Class Initialized
INFO - 2025-09-19 04:20:25 --> Output Class Initialized
INFO - 2025-09-19 04:20:25 --> Security Class Initialized
DEBUG - 2025-09-19 04:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:20:25 --> CSRF cookie sent
INFO - 2025-09-19 04:20:25 --> Input Class Initialized
INFO - 2025-09-19 04:20:25 --> Language Class Initialized
INFO - 2025-09-19 04:20:25 --> Loader Class Initialized
INFO - 2025-09-19 04:20:25 --> Helper loaded: url_helper
INFO - 2025-09-19 04:20:25 --> Helper loaded: text_helper
INFO - 2025-09-19 04:20:25 --> Helper loaded: string_helper
INFO - 2025-09-19 04:20:25 --> Helper loaded: form_helper
INFO - 2025-09-19 04:20:25 --> Helper loaded: download_helper
INFO - 2025-09-19 04:20:25 --> Helper loaded: security_helper
INFO - 2025-09-19 04:20:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:20:25 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:20:25 --> Form Validation Class Initialized
INFO - 2025-09-19 04:20:25 --> Model "User_model" initialized
INFO - 2025-09-19 09:20:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:20:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:20:25 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:20:25 --> Controller Class Initialized
INFO - 2025-09-19 09:20:25 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:20:25 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:20:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-19 09:20:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:20:26 --> Model "Log_model" initialized
INFO - 2025-09-19 09:20:26 --> Final output sent to browser
DEBUG - 2025-09-19 09:20:26 --> Total execution time: 0.6885
INFO - 2025-09-19 04:20:38 --> Config Class Initialized
INFO - 2025-09-19 04:20:38 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:20:38 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:20:38 --> Utf8 Class Initialized
INFO - 2025-09-19 04:20:38 --> URI Class Initialized
INFO - 2025-09-19 04:20:38 --> Router Class Initialized
INFO - 2025-09-19 04:20:38 --> Output Class Initialized
INFO - 2025-09-19 04:20:38 --> Security Class Initialized
DEBUG - 2025-09-19 04:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:20:38 --> CSRF cookie sent
INFO - 2025-09-19 04:20:38 --> CSRF token verified
INFO - 2025-09-19 04:20:38 --> Input Class Initialized
INFO - 2025-09-19 04:20:38 --> Language Class Initialized
INFO - 2025-09-19 04:20:38 --> Loader Class Initialized
INFO - 2025-09-19 04:20:38 --> Helper loaded: url_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: text_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: string_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: form_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: download_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: security_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:20:38 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:20:38 --> Form Validation Class Initialized
INFO - 2025-09-19 04:20:38 --> Model "User_model" initialized
INFO - 2025-09-19 09:20:38 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:20:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:20:38 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:20:38 --> Controller Class Initialized
INFO - 2025-09-19 09:20:38 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:20:38 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:20:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 04:20:38 --> Config Class Initialized
INFO - 2025-09-19 04:20:38 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:20:38 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:20:38 --> Utf8 Class Initialized
INFO - 2025-09-19 04:20:38 --> URI Class Initialized
INFO - 2025-09-19 04:20:38 --> Router Class Initialized
INFO - 2025-09-19 04:20:38 --> Output Class Initialized
INFO - 2025-09-19 04:20:38 --> Security Class Initialized
DEBUG - 2025-09-19 04:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:20:38 --> CSRF cookie sent
INFO - 2025-09-19 04:20:38 --> Input Class Initialized
INFO - 2025-09-19 04:20:38 --> Language Class Initialized
INFO - 2025-09-19 04:20:38 --> Loader Class Initialized
INFO - 2025-09-19 04:20:38 --> Helper loaded: url_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: text_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: string_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: form_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: download_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: security_helper
INFO - 2025-09-19 04:20:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:20:38 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:20:38 --> Form Validation Class Initialized
INFO - 2025-09-19 04:20:38 --> Model "User_model" initialized
INFO - 2025-09-19 09:20:38 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:20:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:20:38 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:20:38 --> Controller Class Initialized
INFO - 2025-09-19 09:20:38 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:20:38 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:20:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-19 09:20:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:20:38 --> Model "Log_model" initialized
INFO - 2025-09-19 09:20:38 --> Final output sent to browser
DEBUG - 2025-09-19 09:20:38 --> Total execution time: 0.0425
INFO - 2025-09-19 04:20:40 --> Config Class Initialized
INFO - 2025-09-19 04:20:40 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:20:40 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:20:40 --> Utf8 Class Initialized
INFO - 2025-09-19 04:20:40 --> URI Class Initialized
INFO - 2025-09-19 04:20:40 --> Router Class Initialized
INFO - 2025-09-19 04:20:40 --> Output Class Initialized
INFO - 2025-09-19 04:20:40 --> Security Class Initialized
DEBUG - 2025-09-19 04:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:20:40 --> CSRF cookie sent
INFO - 2025-09-19 04:20:40 --> Input Class Initialized
INFO - 2025-09-19 04:20:40 --> Language Class Initialized
INFO - 2025-09-19 04:20:40 --> Loader Class Initialized
INFO - 2025-09-19 04:20:40 --> Helper loaded: url_helper
INFO - 2025-09-19 04:20:40 --> Helper loaded: text_helper
INFO - 2025-09-19 04:20:40 --> Helper loaded: string_helper
INFO - 2025-09-19 04:20:40 --> Helper loaded: form_helper
INFO - 2025-09-19 04:20:40 --> Helper loaded: download_helper
INFO - 2025-09-19 04:20:40 --> Helper loaded: security_helper
INFO - 2025-09-19 04:20:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:20:40 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:20:40 --> Form Validation Class Initialized
INFO - 2025-09-19 04:20:40 --> Model "User_model" initialized
INFO - 2025-09-19 09:20:40 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:20:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:20:40 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:20:40 --> Controller Class Initialized
INFO - 2025-09-19 09:20:40 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:20:40 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:20:40 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:20:40 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:20:40 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:20:40 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:20:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:20:40 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:20:40 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:20:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:20:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:20:40 --> Model "Log_model" initialized
INFO - 2025-09-19 09:20:40 --> Final output sent to browser
DEBUG - 2025-09-19 09:20:40 --> Total execution time: 0.0634
INFO - 2025-09-19 04:20:46 --> Config Class Initialized
INFO - 2025-09-19 04:20:46 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:20:46 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:20:46 --> Utf8 Class Initialized
INFO - 2025-09-19 04:20:46 --> URI Class Initialized
INFO - 2025-09-19 04:20:46 --> Router Class Initialized
INFO - 2025-09-19 04:20:46 --> Output Class Initialized
INFO - 2025-09-19 04:20:46 --> Security Class Initialized
DEBUG - 2025-09-19 04:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:20:46 --> CSRF cookie sent
INFO - 2025-09-19 04:20:46 --> Input Class Initialized
INFO - 2025-09-19 04:20:46 --> Language Class Initialized
INFO - 2025-09-19 04:20:46 --> Loader Class Initialized
INFO - 2025-09-19 04:20:46 --> Helper loaded: url_helper
INFO - 2025-09-19 04:20:46 --> Helper loaded: text_helper
INFO - 2025-09-19 04:20:46 --> Helper loaded: string_helper
INFO - 2025-09-19 04:20:46 --> Helper loaded: form_helper
INFO - 2025-09-19 04:20:46 --> Helper loaded: download_helper
INFO - 2025-09-19 04:20:46 --> Helper loaded: security_helper
INFO - 2025-09-19 04:20:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:20:46 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:20:46 --> Form Validation Class Initialized
INFO - 2025-09-19 04:20:46 --> Model "User_model" initialized
INFO - 2025-09-19 09:20:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:20:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:20:46 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:20:46 --> Controller Class Initialized
INFO - 2025-09-19 09:20:46 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:20:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:20:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-19 09:20:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:20:46 --> Model "Log_model" initialized
INFO - 2025-09-19 09:20:46 --> Final output sent to browser
DEBUG - 2025-09-19 09:20:46 --> Total execution time: 0.0572
INFO - 2025-09-19 04:20:52 --> Config Class Initialized
INFO - 2025-09-19 04:20:52 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:20:52 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:20:52 --> Utf8 Class Initialized
INFO - 2025-09-19 04:20:52 --> URI Class Initialized
INFO - 2025-09-19 04:20:52 --> Router Class Initialized
INFO - 2025-09-19 04:20:52 --> Output Class Initialized
INFO - 2025-09-19 04:20:52 --> Security Class Initialized
DEBUG - 2025-09-19 04:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:20:52 --> CSRF cookie sent
INFO - 2025-09-19 04:20:52 --> CSRF token verified
INFO - 2025-09-19 04:20:52 --> Input Class Initialized
INFO - 2025-09-19 04:20:52 --> Language Class Initialized
INFO - 2025-09-19 04:20:52 --> Loader Class Initialized
INFO - 2025-09-19 04:20:52 --> Helper loaded: url_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: text_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: string_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: form_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: download_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: security_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:20:52 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:20:52 --> Form Validation Class Initialized
INFO - 2025-09-19 04:20:52 --> Model "User_model" initialized
INFO - 2025-09-19 09:20:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:20:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:20:52 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:20:52 --> Controller Class Initialized
INFO - 2025-09-19 09:20:52 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:20:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:20:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 04:20:52 --> Config Class Initialized
INFO - 2025-09-19 04:20:52 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:20:52 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:20:52 --> Utf8 Class Initialized
INFO - 2025-09-19 04:20:52 --> URI Class Initialized
INFO - 2025-09-19 04:20:52 --> Router Class Initialized
INFO - 2025-09-19 04:20:52 --> Output Class Initialized
INFO - 2025-09-19 04:20:52 --> Security Class Initialized
DEBUG - 2025-09-19 04:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:20:52 --> CSRF cookie sent
INFO - 2025-09-19 04:20:52 --> Input Class Initialized
INFO - 2025-09-19 04:20:52 --> Language Class Initialized
INFO - 2025-09-19 04:20:52 --> Loader Class Initialized
INFO - 2025-09-19 04:20:52 --> Helper loaded: url_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: text_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: string_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: form_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: download_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: security_helper
INFO - 2025-09-19 04:20:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:20:52 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:20:52 --> Form Validation Class Initialized
INFO - 2025-09-19 04:20:52 --> Model "User_model" initialized
INFO - 2025-09-19 09:20:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:20:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:20:52 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:20:52 --> Controller Class Initialized
INFO - 2025-09-19 09:20:52 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:20:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:20:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-19 09:20:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:20:53 --> Model "Log_model" initialized
INFO - 2025-09-19 09:20:53 --> Final output sent to browser
DEBUG - 2025-09-19 09:20:53 --> Total execution time: 0.0477
INFO - 2025-09-19 04:20:55 --> Config Class Initialized
INFO - 2025-09-19 04:20:55 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:20:55 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:20:55 --> Utf8 Class Initialized
INFO - 2025-09-19 04:20:55 --> URI Class Initialized
INFO - 2025-09-19 04:20:55 --> Router Class Initialized
INFO - 2025-09-19 04:20:55 --> Output Class Initialized
INFO - 2025-09-19 04:20:55 --> Security Class Initialized
DEBUG - 2025-09-19 04:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:20:55 --> CSRF cookie sent
INFO - 2025-09-19 04:20:55 --> Input Class Initialized
INFO - 2025-09-19 04:20:55 --> Language Class Initialized
INFO - 2025-09-19 04:20:55 --> Loader Class Initialized
INFO - 2025-09-19 04:20:55 --> Helper loaded: url_helper
INFO - 2025-09-19 04:20:55 --> Helper loaded: text_helper
INFO - 2025-09-19 04:20:55 --> Helper loaded: string_helper
INFO - 2025-09-19 04:20:55 --> Helper loaded: form_helper
INFO - 2025-09-19 04:20:55 --> Helper loaded: download_helper
INFO - 2025-09-19 04:20:55 --> Helper loaded: security_helper
INFO - 2025-09-19 04:20:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:20:55 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:20:55 --> Form Validation Class Initialized
INFO - 2025-09-19 04:20:55 --> Model "User_model" initialized
INFO - 2025-09-19 09:20:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:20:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:20:55 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:20:55 --> Controller Class Initialized
INFO - 2025-09-19 09:20:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:20:55 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:20:55 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:20:55 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:20:55 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:20:55 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:20:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:20:55 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:20:55 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:20:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:20:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:20:55 --> Model "Log_model" initialized
INFO - 2025-09-19 09:20:55 --> Final output sent to browser
DEBUG - 2025-09-19 09:20:55 --> Total execution time: 0.0640
INFO - 2025-09-19 04:21:53 --> Config Class Initialized
INFO - 2025-09-19 04:21:53 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:21:53 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:21:53 --> Utf8 Class Initialized
INFO - 2025-09-19 04:21:53 --> URI Class Initialized
INFO - 2025-09-19 04:21:53 --> Router Class Initialized
INFO - 2025-09-19 04:21:53 --> Output Class Initialized
INFO - 2025-09-19 04:21:53 --> Security Class Initialized
DEBUG - 2025-09-19 04:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:21:53 --> CSRF cookie sent
INFO - 2025-09-19 04:21:53 --> Input Class Initialized
INFO - 2025-09-19 04:21:53 --> Language Class Initialized
INFO - 2025-09-19 04:21:53 --> Loader Class Initialized
INFO - 2025-09-19 04:21:53 --> Helper loaded: url_helper
INFO - 2025-09-19 04:21:53 --> Helper loaded: text_helper
INFO - 2025-09-19 04:21:53 --> Helper loaded: string_helper
INFO - 2025-09-19 04:21:53 --> Helper loaded: form_helper
INFO - 2025-09-19 04:21:53 --> Helper loaded: download_helper
INFO - 2025-09-19 04:21:53 --> Helper loaded: security_helper
INFO - 2025-09-19 04:21:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:21:53 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:21:53 --> Form Validation Class Initialized
INFO - 2025-09-19 04:21:53 --> Model "User_model" initialized
INFO - 2025-09-19 09:21:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:21:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:21:53 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:21:53 --> Controller Class Initialized
INFO - 2025-09-19 09:21:53 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:21:53 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:21:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:21:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:21:53 --> Model "Log_model" initialized
INFO - 2025-09-19 09:21:53 --> Final output sent to browser
DEBUG - 2025-09-19 09:21:53 --> Total execution time: 0.0441
INFO - 2025-09-19 04:21:57 --> Config Class Initialized
INFO - 2025-09-19 04:21:57 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:21:57 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:21:57 --> Utf8 Class Initialized
INFO - 2025-09-19 04:21:57 --> URI Class Initialized
INFO - 2025-09-19 04:21:57 --> Router Class Initialized
INFO - 2025-09-19 04:21:57 --> Output Class Initialized
INFO - 2025-09-19 04:21:57 --> Security Class Initialized
DEBUG - 2025-09-19 04:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:21:57 --> CSRF cookie sent
INFO - 2025-09-19 04:21:57 --> Input Class Initialized
INFO - 2025-09-19 04:21:57 --> Language Class Initialized
INFO - 2025-09-19 04:21:57 --> Loader Class Initialized
INFO - 2025-09-19 04:21:57 --> Helper loaded: url_helper
INFO - 2025-09-19 04:21:57 --> Helper loaded: text_helper
INFO - 2025-09-19 04:21:57 --> Helper loaded: string_helper
INFO - 2025-09-19 04:21:57 --> Helper loaded: form_helper
INFO - 2025-09-19 04:21:57 --> Helper loaded: download_helper
INFO - 2025-09-19 04:21:57 --> Helper loaded: security_helper
INFO - 2025-09-19 04:21:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:21:57 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:21:57 --> Form Validation Class Initialized
INFO - 2025-09-19 04:21:57 --> Model "User_model" initialized
INFO - 2025-09-19 09:21:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:21:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:21:57 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:21:57 --> Controller Class Initialized
INFO - 2025-09-19 09:21:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:21:57 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:21:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:21:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:21:57 --> Model "Log_model" initialized
INFO - 2025-09-19 09:21:57 --> Final output sent to browser
DEBUG - 2025-09-19 09:21:57 --> Total execution time: 0.0544
INFO - 2025-09-19 04:24:22 --> Config Class Initialized
INFO - 2025-09-19 04:24:22 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:24:22 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:24:22 --> Utf8 Class Initialized
INFO - 2025-09-19 04:24:22 --> URI Class Initialized
INFO - 2025-09-19 04:24:22 --> Router Class Initialized
INFO - 2025-09-19 04:24:22 --> Output Class Initialized
INFO - 2025-09-19 04:24:22 --> Security Class Initialized
DEBUG - 2025-09-19 04:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:24:22 --> CSRF cookie sent
INFO - 2025-09-19 04:24:22 --> Input Class Initialized
INFO - 2025-09-19 04:24:22 --> Language Class Initialized
INFO - 2025-09-19 04:24:22 --> Loader Class Initialized
INFO - 2025-09-19 04:24:22 --> Helper loaded: url_helper
INFO - 2025-09-19 04:24:22 --> Helper loaded: text_helper
INFO - 2025-09-19 04:24:22 --> Helper loaded: string_helper
INFO - 2025-09-19 04:24:22 --> Helper loaded: form_helper
INFO - 2025-09-19 04:24:22 --> Helper loaded: download_helper
INFO - 2025-09-19 04:24:22 --> Helper loaded: security_helper
INFO - 2025-09-19 04:24:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:24:22 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:24:22 --> Form Validation Class Initialized
INFO - 2025-09-19 04:24:22 --> Model "User_model" initialized
INFO - 2025-09-19 09:24:22 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:24:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:24:22 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:24:22 --> Controller Class Initialized
INFO - 2025-09-19 09:24:22 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:24:22 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:24:22 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:24:22 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:24:22 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:24:22 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:24:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:24:22 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:24:22 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:24:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:24:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:24:22 --> Model "Log_model" initialized
INFO - 2025-09-19 09:24:22 --> Final output sent to browser
DEBUG - 2025-09-19 09:24:22 --> Total execution time: 0.0891
INFO - 2025-09-19 04:24:25 --> Config Class Initialized
INFO - 2025-09-19 04:24:25 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:24:25 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:24:25 --> Utf8 Class Initialized
INFO - 2025-09-19 04:24:25 --> URI Class Initialized
INFO - 2025-09-19 04:24:25 --> Router Class Initialized
INFO - 2025-09-19 04:24:25 --> Output Class Initialized
INFO - 2025-09-19 04:24:25 --> Security Class Initialized
DEBUG - 2025-09-19 04:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:24:25 --> CSRF cookie sent
INFO - 2025-09-19 04:24:25 --> Input Class Initialized
INFO - 2025-09-19 04:24:25 --> Language Class Initialized
INFO - 2025-09-19 04:24:25 --> Loader Class Initialized
INFO - 2025-09-19 04:24:25 --> Helper loaded: url_helper
INFO - 2025-09-19 04:24:25 --> Helper loaded: text_helper
INFO - 2025-09-19 04:24:25 --> Helper loaded: string_helper
INFO - 2025-09-19 04:24:25 --> Helper loaded: form_helper
INFO - 2025-09-19 04:24:25 --> Helper loaded: download_helper
INFO - 2025-09-19 04:24:25 --> Helper loaded: security_helper
INFO - 2025-09-19 04:24:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:24:25 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:24:25 --> Form Validation Class Initialized
INFO - 2025-09-19 04:24:25 --> Model "User_model" initialized
INFO - 2025-09-19 09:24:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:24:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:24:25 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:24:25 --> Controller Class Initialized
INFO - 2025-09-19 09:24:25 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:24:25 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:24:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:24:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:24:25 --> Model "Log_model" initialized
INFO - 2025-09-19 09:24:25 --> Final output sent to browser
DEBUG - 2025-09-19 09:24:25 --> Total execution time: 0.0605
INFO - 2025-09-19 04:24:28 --> Config Class Initialized
INFO - 2025-09-19 04:24:28 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:24:28 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:24:28 --> Utf8 Class Initialized
INFO - 2025-09-19 04:24:28 --> URI Class Initialized
INFO - 2025-09-19 04:24:28 --> Router Class Initialized
INFO - 2025-09-19 04:24:28 --> Output Class Initialized
INFO - 2025-09-19 04:24:28 --> Security Class Initialized
DEBUG - 2025-09-19 04:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:24:28 --> CSRF cookie sent
INFO - 2025-09-19 04:24:28 --> Input Class Initialized
INFO - 2025-09-19 04:24:28 --> Language Class Initialized
INFO - 2025-09-19 04:24:28 --> Loader Class Initialized
INFO - 2025-09-19 04:24:28 --> Helper loaded: url_helper
INFO - 2025-09-19 04:24:28 --> Helper loaded: text_helper
INFO - 2025-09-19 04:24:28 --> Helper loaded: string_helper
INFO - 2025-09-19 04:24:28 --> Helper loaded: form_helper
INFO - 2025-09-19 04:24:28 --> Helper loaded: download_helper
INFO - 2025-09-19 04:24:28 --> Helper loaded: security_helper
INFO - 2025-09-19 04:24:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:24:28 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:24:28 --> Form Validation Class Initialized
INFO - 2025-09-19 04:24:28 --> Model "User_model" initialized
INFO - 2025-09-19 09:24:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:24:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:24:28 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:24:28 --> Controller Class Initialized
INFO - 2025-09-19 09:24:28 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:24:28 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:24:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:24:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:24:28 --> Model "Log_model" initialized
INFO - 2025-09-19 09:24:28 --> Final output sent to browser
DEBUG - 2025-09-19 09:24:28 --> Total execution time: 0.0375
INFO - 2025-09-19 04:24:37 --> Config Class Initialized
INFO - 2025-09-19 04:24:37 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:24:37 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:24:37 --> Utf8 Class Initialized
INFO - 2025-09-19 04:24:37 --> URI Class Initialized
INFO - 2025-09-19 04:24:37 --> Router Class Initialized
INFO - 2025-09-19 04:24:37 --> Output Class Initialized
INFO - 2025-09-19 04:24:37 --> Security Class Initialized
DEBUG - 2025-09-19 04:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:24:37 --> CSRF cookie sent
INFO - 2025-09-19 04:24:37 --> Input Class Initialized
INFO - 2025-09-19 04:24:37 --> Language Class Initialized
INFO - 2025-09-19 04:24:37 --> Loader Class Initialized
INFO - 2025-09-19 04:24:37 --> Helper loaded: url_helper
INFO - 2025-09-19 04:24:37 --> Helper loaded: text_helper
INFO - 2025-09-19 04:24:37 --> Helper loaded: string_helper
INFO - 2025-09-19 04:24:37 --> Helper loaded: form_helper
INFO - 2025-09-19 04:24:37 --> Helper loaded: download_helper
INFO - 2025-09-19 04:24:37 --> Helper loaded: security_helper
INFO - 2025-09-19 04:24:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:24:37 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:24:37 --> Form Validation Class Initialized
INFO - 2025-09-19 04:24:37 --> Model "User_model" initialized
INFO - 2025-09-19 09:24:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:24:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:24:37 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:24:37 --> Controller Class Initialized
INFO - 2025-09-19 09:24:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:24:37 --> Model "Prodi_model" initialized
INFO - 2025-09-19 04:24:40 --> Config Class Initialized
INFO - 2025-09-19 04:24:40 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:24:40 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:24:40 --> Utf8 Class Initialized
INFO - 2025-09-19 04:24:40 --> URI Class Initialized
INFO - 2025-09-19 04:24:40 --> Router Class Initialized
INFO - 2025-09-19 04:24:40 --> Output Class Initialized
INFO - 2025-09-19 04:24:40 --> Security Class Initialized
DEBUG - 2025-09-19 04:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:24:40 --> CSRF cookie sent
INFO - 2025-09-19 04:24:40 --> Input Class Initialized
INFO - 2025-09-19 04:24:40 --> Language Class Initialized
INFO - 2025-09-19 04:24:40 --> Loader Class Initialized
INFO - 2025-09-19 04:24:40 --> Helper loaded: url_helper
INFO - 2025-09-19 04:24:40 --> Helper loaded: text_helper
INFO - 2025-09-19 04:24:40 --> Helper loaded: string_helper
INFO - 2025-09-19 04:24:40 --> Helper loaded: form_helper
INFO - 2025-09-19 04:24:40 --> Helper loaded: download_helper
INFO - 2025-09-19 04:24:40 --> Helper loaded: security_helper
INFO - 2025-09-19 04:24:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:24:40 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:24:40 --> Form Validation Class Initialized
INFO - 2025-09-19 04:24:40 --> Model "User_model" initialized
INFO - 2025-09-19 09:24:40 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:24:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:24:40 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:24:40 --> Controller Class Initialized
INFO - 2025-09-19 09:24:40 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:24:40 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:24:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:24:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:24:40 --> Model "Log_model" initialized
INFO - 2025-09-19 09:24:40 --> Final output sent to browser
DEBUG - 2025-09-19 09:24:40 --> Total execution time: 0.0642
INFO - 2025-09-19 04:25:14 --> Config Class Initialized
INFO - 2025-09-19 04:25:14 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:25:14 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:25:14 --> Utf8 Class Initialized
INFO - 2025-09-19 04:25:14 --> URI Class Initialized
INFO - 2025-09-19 04:25:14 --> Router Class Initialized
INFO - 2025-09-19 04:25:14 --> Output Class Initialized
INFO - 2025-09-19 04:25:14 --> Security Class Initialized
DEBUG - 2025-09-19 04:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:25:14 --> CSRF cookie sent
INFO - 2025-09-19 04:25:14 --> Input Class Initialized
INFO - 2025-09-19 04:25:14 --> Language Class Initialized
INFO - 2025-09-19 04:25:14 --> Loader Class Initialized
INFO - 2025-09-19 04:25:14 --> Helper loaded: url_helper
INFO - 2025-09-19 04:25:14 --> Helper loaded: text_helper
INFO - 2025-09-19 04:25:14 --> Helper loaded: string_helper
INFO - 2025-09-19 04:25:14 --> Helper loaded: form_helper
INFO - 2025-09-19 04:25:14 --> Helper loaded: download_helper
INFO - 2025-09-19 04:25:14 --> Helper loaded: security_helper
INFO - 2025-09-19 04:25:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:25:14 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:25:14 --> Form Validation Class Initialized
INFO - 2025-09-19 04:25:14 --> Model "User_model" initialized
INFO - 2025-09-19 09:25:14 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:25:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:25:14 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:25:14 --> Controller Class Initialized
INFO - 2025-09-19 09:25:14 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:25:14 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:25:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:25:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:25:14 --> Model "Log_model" initialized
INFO - 2025-09-19 09:25:14 --> Final output sent to browser
DEBUG - 2025-09-19 09:25:14 --> Total execution time: 0.0603
INFO - 2025-09-19 04:25:37 --> Config Class Initialized
INFO - 2025-09-19 04:25:37 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:25:37 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:25:37 --> Utf8 Class Initialized
INFO - 2025-09-19 04:25:37 --> URI Class Initialized
INFO - 2025-09-19 04:25:37 --> Router Class Initialized
INFO - 2025-09-19 04:25:37 --> Output Class Initialized
INFO - 2025-09-19 04:25:37 --> Security Class Initialized
DEBUG - 2025-09-19 04:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:25:37 --> CSRF cookie sent
INFO - 2025-09-19 04:25:37 --> Input Class Initialized
INFO - 2025-09-19 04:25:37 --> Language Class Initialized
INFO - 2025-09-19 04:25:38 --> Loader Class Initialized
INFO - 2025-09-19 04:25:38 --> Helper loaded: url_helper
INFO - 2025-09-19 04:25:38 --> Helper loaded: text_helper
INFO - 2025-09-19 04:25:38 --> Helper loaded: string_helper
INFO - 2025-09-19 04:25:38 --> Helper loaded: form_helper
INFO - 2025-09-19 04:25:38 --> Helper loaded: download_helper
INFO - 2025-09-19 04:25:38 --> Helper loaded: security_helper
INFO - 2025-09-19 04:25:38 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:25:38 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:25:38 --> Form Validation Class Initialized
INFO - 2025-09-19 04:25:38 --> Model "User_model" initialized
INFO - 2025-09-19 09:25:38 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:25:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:25:38 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:25:38 --> Controller Class Initialized
INFO - 2025-09-19 09:25:38 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:25:38 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:25:38 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:25:38 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:25:38 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:25:38 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:25:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:25:38 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:25:38 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:25:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:25:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:25:38 --> Model "Log_model" initialized
INFO - 2025-09-19 09:25:38 --> Final output sent to browser
DEBUG - 2025-09-19 09:25:38 --> Total execution time: 0.0886
INFO - 2025-09-19 04:27:44 --> Config Class Initialized
INFO - 2025-09-19 04:27:44 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:27:44 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:27:44 --> Utf8 Class Initialized
INFO - 2025-09-19 04:27:44 --> URI Class Initialized
INFO - 2025-09-19 04:27:44 --> Router Class Initialized
INFO - 2025-09-19 04:27:44 --> Output Class Initialized
INFO - 2025-09-19 04:27:44 --> Security Class Initialized
DEBUG - 2025-09-19 04:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:27:44 --> CSRF cookie sent
INFO - 2025-09-19 04:27:44 --> Input Class Initialized
INFO - 2025-09-19 04:27:44 --> Language Class Initialized
INFO - 2025-09-19 04:27:44 --> Loader Class Initialized
INFO - 2025-09-19 04:27:44 --> Helper loaded: url_helper
INFO - 2025-09-19 04:27:44 --> Helper loaded: text_helper
INFO - 2025-09-19 04:27:44 --> Helper loaded: string_helper
INFO - 2025-09-19 04:27:44 --> Helper loaded: form_helper
INFO - 2025-09-19 04:27:44 --> Helper loaded: download_helper
INFO - 2025-09-19 04:27:44 --> Helper loaded: security_helper
INFO - 2025-09-19 04:27:44 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:27:44 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:27:44 --> Form Validation Class Initialized
INFO - 2025-09-19 04:27:44 --> Model "User_model" initialized
INFO - 2025-09-19 09:27:44 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:27:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:27:44 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:27:44 --> Controller Class Initialized
INFO - 2025-09-19 09:27:44 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:27:44 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:27:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:27:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:27:44 --> Model "Log_model" initialized
INFO - 2025-09-19 09:27:44 --> Final output sent to browser
DEBUG - 2025-09-19 09:27:44 --> Total execution time: 0.3496
INFO - 2025-09-19 04:28:04 --> Config Class Initialized
INFO - 2025-09-19 04:28:04 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:28:04 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:28:04 --> Utf8 Class Initialized
INFO - 2025-09-19 04:28:04 --> URI Class Initialized
INFO - 2025-09-19 04:28:04 --> Router Class Initialized
INFO - 2025-09-19 04:28:04 --> Output Class Initialized
INFO - 2025-09-19 04:28:04 --> Security Class Initialized
DEBUG - 2025-09-19 04:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:28:04 --> CSRF cookie sent
INFO - 2025-09-19 04:28:04 --> Input Class Initialized
INFO - 2025-09-19 04:28:04 --> Language Class Initialized
INFO - 2025-09-19 04:28:04 --> Loader Class Initialized
INFO - 2025-09-19 04:28:04 --> Helper loaded: url_helper
INFO - 2025-09-19 04:28:04 --> Helper loaded: text_helper
INFO - 2025-09-19 04:28:04 --> Helper loaded: string_helper
INFO - 2025-09-19 04:28:04 --> Helper loaded: form_helper
INFO - 2025-09-19 04:28:04 --> Helper loaded: download_helper
INFO - 2025-09-19 04:28:04 --> Helper loaded: security_helper
INFO - 2025-09-19 04:28:04 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:28:04 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:28:04 --> Form Validation Class Initialized
INFO - 2025-09-19 04:28:04 --> Model "User_model" initialized
INFO - 2025-09-19 09:28:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:28:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:28:04 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:28:04 --> Controller Class Initialized
INFO - 2025-09-19 09:28:04 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:28:04 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:28:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:28:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:28:05 --> Model "Log_model" initialized
INFO - 2025-09-19 09:28:05 --> Final output sent to browser
DEBUG - 2025-09-19 09:28:05 --> Total execution time: 0.3464
INFO - 2025-09-19 04:29:07 --> Config Class Initialized
INFO - 2025-09-19 04:29:07 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:29:07 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:29:07 --> Utf8 Class Initialized
INFO - 2025-09-19 04:29:07 --> URI Class Initialized
INFO - 2025-09-19 04:29:07 --> Router Class Initialized
INFO - 2025-09-19 04:29:07 --> Output Class Initialized
INFO - 2025-09-19 04:29:07 --> Security Class Initialized
DEBUG - 2025-09-19 04:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:29:07 --> CSRF cookie sent
INFO - 2025-09-19 04:29:07 --> Input Class Initialized
INFO - 2025-09-19 04:29:07 --> Language Class Initialized
INFO - 2025-09-19 04:29:07 --> Loader Class Initialized
INFO - 2025-09-19 04:29:07 --> Helper loaded: url_helper
INFO - 2025-09-19 04:29:07 --> Helper loaded: text_helper
INFO - 2025-09-19 04:29:07 --> Helper loaded: string_helper
INFO - 2025-09-19 04:29:07 --> Helper loaded: form_helper
INFO - 2025-09-19 04:29:07 --> Helper loaded: download_helper
INFO - 2025-09-19 04:29:07 --> Helper loaded: security_helper
INFO - 2025-09-19 04:29:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:29:07 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:29:07 --> Form Validation Class Initialized
INFO - 2025-09-19 04:29:07 --> Model "User_model" initialized
INFO - 2025-09-19 09:29:07 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:29:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:29:07 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:29:07 --> Controller Class Initialized
INFO - 2025-09-19 09:29:07 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:29:07 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:29:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:29:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:29:08 --> Model "Log_model" initialized
INFO - 2025-09-19 09:29:08 --> Final output sent to browser
DEBUG - 2025-09-19 09:29:08 --> Total execution time: 0.3404
INFO - 2025-09-19 04:29:24 --> Config Class Initialized
INFO - 2025-09-19 04:29:24 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:29:24 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:29:24 --> Utf8 Class Initialized
INFO - 2025-09-19 04:29:24 --> URI Class Initialized
INFO - 2025-09-19 04:29:24 --> Router Class Initialized
INFO - 2025-09-19 04:29:24 --> Output Class Initialized
INFO - 2025-09-19 04:29:24 --> Security Class Initialized
DEBUG - 2025-09-19 04:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:29:24 --> CSRF cookie sent
INFO - 2025-09-19 04:29:24 --> Input Class Initialized
INFO - 2025-09-19 04:29:24 --> Language Class Initialized
INFO - 2025-09-19 04:29:24 --> Loader Class Initialized
INFO - 2025-09-19 04:29:24 --> Helper loaded: url_helper
INFO - 2025-09-19 04:29:24 --> Helper loaded: text_helper
INFO - 2025-09-19 04:29:24 --> Helper loaded: string_helper
INFO - 2025-09-19 04:29:24 --> Helper loaded: form_helper
INFO - 2025-09-19 04:29:24 --> Helper loaded: download_helper
INFO - 2025-09-19 04:29:24 --> Helper loaded: security_helper
INFO - 2025-09-19 04:29:24 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:29:24 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:29:24 --> Form Validation Class Initialized
INFO - 2025-09-19 04:29:24 --> Model "User_model" initialized
INFO - 2025-09-19 09:29:24 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:29:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:29:24 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:29:24 --> Controller Class Initialized
INFO - 2025-09-19 09:29:24 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:29:24 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:29:24 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:29:24 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:29:24 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:29:24 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:29:24 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:29:24 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:29:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:29:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:29:24 --> Model "Log_model" initialized
INFO - 2025-09-19 09:29:24 --> Final output sent to browser
DEBUG - 2025-09-19 09:29:24 --> Total execution time: 0.1046
INFO - 2025-09-19 04:30:53 --> Config Class Initialized
INFO - 2025-09-19 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:30:53 --> Utf8 Class Initialized
INFO - 2025-09-19 04:30:53 --> URI Class Initialized
INFO - 2025-09-19 04:30:53 --> Router Class Initialized
INFO - 2025-09-19 04:30:53 --> Output Class Initialized
INFO - 2025-09-19 04:30:53 --> Security Class Initialized
DEBUG - 2025-09-19 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:30:53 --> CSRF cookie sent
INFO - 2025-09-19 04:30:53 --> Input Class Initialized
INFO - 2025-09-19 04:30:53 --> Language Class Initialized
INFO - 2025-09-19 04:30:53 --> Loader Class Initialized
INFO - 2025-09-19 04:30:53 --> Helper loaded: url_helper
INFO - 2025-09-19 04:30:53 --> Helper loaded: text_helper
INFO - 2025-09-19 04:30:53 --> Helper loaded: string_helper
INFO - 2025-09-19 04:30:53 --> Helper loaded: form_helper
INFO - 2025-09-19 04:30:53 --> Helper loaded: download_helper
INFO - 2025-09-19 04:30:53 --> Helper loaded: security_helper
INFO - 2025-09-19 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:30:53 --> Form Validation Class Initialized
INFO - 2025-09-19 04:30:53 --> Model "User_model" initialized
INFO - 2025-09-19 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:30:53 --> Controller Class Initialized
INFO - 2025-09-19 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:30:53 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:30:53 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:30:53 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:30:53 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:30:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:30:53 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:30:53 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:30:53 --> Model "Log_model" initialized
INFO - 2025-09-19 09:30:53 --> Final output sent to browser
DEBUG - 2025-09-19 09:30:53 --> Total execution time: 0.0894
INFO - 2025-09-19 04:31:07 --> Config Class Initialized
INFO - 2025-09-19 04:31:07 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:31:07 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:31:07 --> Utf8 Class Initialized
INFO - 2025-09-19 04:31:07 --> URI Class Initialized
INFO - 2025-09-19 04:31:07 --> Router Class Initialized
INFO - 2025-09-19 04:31:07 --> Output Class Initialized
INFO - 2025-09-19 04:31:07 --> Security Class Initialized
DEBUG - 2025-09-19 04:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:31:07 --> CSRF cookie sent
INFO - 2025-09-19 04:31:07 --> Input Class Initialized
INFO - 2025-09-19 04:31:07 --> Language Class Initialized
INFO - 2025-09-19 04:31:07 --> Loader Class Initialized
INFO - 2025-09-19 04:31:07 --> Helper loaded: url_helper
INFO - 2025-09-19 04:31:07 --> Helper loaded: text_helper
INFO - 2025-09-19 04:31:07 --> Helper loaded: string_helper
INFO - 2025-09-19 04:31:07 --> Helper loaded: form_helper
INFO - 2025-09-19 04:31:07 --> Helper loaded: download_helper
INFO - 2025-09-19 04:31:07 --> Helper loaded: security_helper
INFO - 2025-09-19 04:31:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:31:07 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:31:07 --> Form Validation Class Initialized
INFO - 2025-09-19 04:31:07 --> Model "User_model" initialized
INFO - 2025-09-19 09:31:07 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:31:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:31:07 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:31:07 --> Controller Class Initialized
INFO - 2025-09-19 09:31:07 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:31:07 --> Model "Jabatansdm_model" initialized
INFO - 2025-09-19 09:31:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/detail.php
INFO - 2025-09-19 09:31:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:31:07 --> Model "Log_model" initialized
INFO - 2025-09-19 09:31:07 --> Final output sent to browser
DEBUG - 2025-09-19 09:31:07 --> Total execution time: 0.1816
INFO - 2025-09-19 04:31:16 --> Config Class Initialized
INFO - 2025-09-19 04:31:16 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:31:16 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:31:16 --> Utf8 Class Initialized
INFO - 2025-09-19 04:31:16 --> URI Class Initialized
INFO - 2025-09-19 04:31:16 --> Router Class Initialized
INFO - 2025-09-19 04:31:16 --> Output Class Initialized
INFO - 2025-09-19 04:31:16 --> Security Class Initialized
DEBUG - 2025-09-19 04:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:31:16 --> CSRF cookie sent
INFO - 2025-09-19 04:31:16 --> Input Class Initialized
INFO - 2025-09-19 04:31:16 --> Language Class Initialized
INFO - 2025-09-19 04:31:16 --> Loader Class Initialized
INFO - 2025-09-19 04:31:16 --> Helper loaded: url_helper
INFO - 2025-09-19 04:31:16 --> Helper loaded: text_helper
INFO - 2025-09-19 04:31:16 --> Helper loaded: string_helper
INFO - 2025-09-19 04:31:16 --> Helper loaded: form_helper
INFO - 2025-09-19 04:31:16 --> Helper loaded: download_helper
INFO - 2025-09-19 04:31:16 --> Helper loaded: security_helper
INFO - 2025-09-19 04:31:16 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:31:16 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:31:17 --> Form Validation Class Initialized
INFO - 2025-09-19 04:31:17 --> Model "User_model" initialized
INFO - 2025-09-19 09:31:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:31:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:31:17 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:31:17 --> Controller Class Initialized
INFO - 2025-09-19 09:31:17 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:31:17 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:31:17 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:31:17 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:31:17 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:31:17 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:31:17 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:31:17 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:31:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:31:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:31:17 --> Model "Log_model" initialized
INFO - 2025-09-19 09:31:17 --> Final output sent to browser
DEBUG - 2025-09-19 09:31:17 --> Total execution time: 0.0818
INFO - 2025-09-19 04:33:18 --> Config Class Initialized
INFO - 2025-09-19 04:33:18 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:33:18 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:33:18 --> Utf8 Class Initialized
INFO - 2025-09-19 04:33:18 --> URI Class Initialized
INFO - 2025-09-19 04:33:18 --> Router Class Initialized
INFO - 2025-09-19 04:33:18 --> Output Class Initialized
INFO - 2025-09-19 04:33:18 --> Security Class Initialized
DEBUG - 2025-09-19 04:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:33:18 --> CSRF cookie sent
INFO - 2025-09-19 04:33:18 --> CSRF token verified
INFO - 2025-09-19 04:33:18 --> Input Class Initialized
INFO - 2025-09-19 04:33:18 --> Language Class Initialized
INFO - 2025-09-19 04:33:19 --> Loader Class Initialized
INFO - 2025-09-19 04:33:19 --> Helper loaded: url_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: text_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: string_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: form_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: download_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: security_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:33:19 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:33:19 --> Form Validation Class Initialized
INFO - 2025-09-19 04:33:19 --> Model "User_model" initialized
INFO - 2025-09-19 09:33:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:33:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:33:19 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:33:19 --> Controller Class Initialized
INFO - 2025-09-19 09:33:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:33:19 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:33:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 04:33:19 --> Config Class Initialized
INFO - 2025-09-19 04:33:19 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:33:19 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:33:19 --> Utf8 Class Initialized
INFO - 2025-09-19 04:33:19 --> URI Class Initialized
INFO - 2025-09-19 04:33:19 --> Router Class Initialized
INFO - 2025-09-19 04:33:19 --> Output Class Initialized
INFO - 2025-09-19 04:33:19 --> Security Class Initialized
DEBUG - 2025-09-19 04:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:33:19 --> CSRF cookie sent
INFO - 2025-09-19 04:33:19 --> Input Class Initialized
INFO - 2025-09-19 04:33:19 --> Language Class Initialized
INFO - 2025-09-19 04:33:19 --> Loader Class Initialized
INFO - 2025-09-19 04:33:19 --> Helper loaded: url_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: text_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: string_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: form_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: download_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: security_helper
INFO - 2025-09-19 04:33:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:33:19 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:33:19 --> Form Validation Class Initialized
INFO - 2025-09-19 04:33:19 --> Model "User_model" initialized
INFO - 2025-09-19 09:33:19 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:33:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:33:19 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:33:19 --> Controller Class Initialized
INFO - 2025-09-19 09:33:19 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:33:19 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:33:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:33:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:33:19 --> Model "Log_model" initialized
INFO - 2025-09-19 09:33:19 --> Final output sent to browser
DEBUG - 2025-09-19 09:33:19 --> Total execution time: 0.0493
INFO - 2025-09-19 04:33:20 --> Config Class Initialized
INFO - 2025-09-19 04:33:20 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:33:20 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:33:20 --> Utf8 Class Initialized
INFO - 2025-09-19 04:33:20 --> URI Class Initialized
INFO - 2025-09-19 04:33:20 --> Router Class Initialized
INFO - 2025-09-19 04:33:20 --> Output Class Initialized
INFO - 2025-09-19 04:33:20 --> Security Class Initialized
DEBUG - 2025-09-19 04:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:33:20 --> CSRF cookie sent
INFO - 2025-09-19 04:33:20 --> Input Class Initialized
INFO - 2025-09-19 04:33:20 --> Language Class Initialized
INFO - 2025-09-19 04:33:20 --> Loader Class Initialized
INFO - 2025-09-19 04:33:20 --> Helper loaded: url_helper
INFO - 2025-09-19 04:33:20 --> Helper loaded: text_helper
INFO - 2025-09-19 04:33:20 --> Helper loaded: string_helper
INFO - 2025-09-19 04:33:20 --> Helper loaded: form_helper
INFO - 2025-09-19 04:33:20 --> Helper loaded: download_helper
INFO - 2025-09-19 04:33:20 --> Helper loaded: security_helper
INFO - 2025-09-19 04:33:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:33:20 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:33:20 --> Form Validation Class Initialized
INFO - 2025-09-19 04:33:20 --> Model "User_model" initialized
INFO - 2025-09-19 09:33:20 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:33:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:33:20 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:33:20 --> Controller Class Initialized
INFO - 2025-09-19 09:33:20 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:33:20 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:33:20 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:33:20 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:33:20 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2025-09-19 09:33:20 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:33:20 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:33:20 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:33:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:33:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:33:20 --> Model "Log_model" initialized
INFO - 2025-09-19 09:33:20 --> Final output sent to browser
DEBUG - 2025-09-19 09:33:20 --> Total execution time: 0.0859
INFO - 2025-09-19 04:34:49 --> Config Class Initialized
INFO - 2025-09-19 04:34:49 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:34:49 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:34:49 --> Utf8 Class Initialized
INFO - 2025-09-19 04:34:49 --> URI Class Initialized
INFO - 2025-09-19 04:34:49 --> Router Class Initialized
INFO - 2025-09-19 04:34:49 --> Output Class Initialized
INFO - 2025-09-19 04:34:49 --> Security Class Initialized
DEBUG - 2025-09-19 04:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:34:49 --> CSRF cookie sent
INFO - 2025-09-19 04:34:49 --> Input Class Initialized
INFO - 2025-09-19 04:34:49 --> Language Class Initialized
INFO - 2025-09-19 04:34:49 --> Loader Class Initialized
INFO - 2025-09-19 04:34:49 --> Helper loaded: url_helper
INFO - 2025-09-19 04:34:49 --> Helper loaded: text_helper
INFO - 2025-09-19 04:34:49 --> Helper loaded: string_helper
INFO - 2025-09-19 04:34:49 --> Helper loaded: form_helper
INFO - 2025-09-19 04:34:49 --> Helper loaded: download_helper
INFO - 2025-09-19 04:34:49 --> Helper loaded: security_helper
INFO - 2025-09-19 04:34:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:34:49 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:34:49 --> Form Validation Class Initialized
INFO - 2025-09-19 04:34:49 --> Model "User_model" initialized
INFO - 2025-09-19 09:34:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:34:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:34:49 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:34:49 --> Controller Class Initialized
INFO - 2025-09-19 09:34:49 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:34:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:34:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/list.php
INFO - 2025-09-19 09:34:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:34:49 --> Model "Log_model" initialized
INFO - 2025-09-19 09:34:49 --> Final output sent to browser
DEBUG - 2025-09-19 09:34:49 --> Total execution time: 0.0559
INFO - 2025-09-19 04:34:55 --> Config Class Initialized
INFO - 2025-09-19 04:34:55 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:34:55 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:34:55 --> Utf8 Class Initialized
INFO - 2025-09-19 04:34:55 --> URI Class Initialized
INFO - 2025-09-19 04:34:55 --> Router Class Initialized
INFO - 2025-09-19 04:34:55 --> Output Class Initialized
INFO - 2025-09-19 04:34:55 --> Security Class Initialized
DEBUG - 2025-09-19 04:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:34:55 --> CSRF cookie sent
INFO - 2025-09-19 04:34:55 --> Input Class Initialized
INFO - 2025-09-19 04:34:55 --> Language Class Initialized
INFO - 2025-09-19 04:34:55 --> Loader Class Initialized
INFO - 2025-09-19 04:34:55 --> Helper loaded: url_helper
INFO - 2025-09-19 04:34:55 --> Helper loaded: text_helper
INFO - 2025-09-19 04:34:55 --> Helper loaded: string_helper
INFO - 2025-09-19 04:34:55 --> Helper loaded: form_helper
INFO - 2025-09-19 04:34:55 --> Helper loaded: download_helper
INFO - 2025-09-19 04:34:55 --> Helper loaded: security_helper
INFO - 2025-09-19 04:34:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:34:55 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:34:55 --> Form Validation Class Initialized
INFO - 2025-09-19 04:34:55 --> Model "User_model" initialized
INFO - 2025-09-19 09:34:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:34:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:34:55 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:34:55 --> Controller Class Initialized
INFO - 2025-09-19 09:34:55 --> Model "Pusat_model" initialized
INFO - 2025-09-19 09:34:55 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:34:55 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:34:56 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-19 09:34:56 --> Query SDM berhasil untuk pusat: Pusat Penelitian dan Pengabdian Masyarakat, Total: 1
INFO - 2025-09-19 09:34:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-19 09:34:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:34:56 --> Model "Log_model" initialized
INFO - 2025-09-19 09:34:56 --> Final output sent to browser
DEBUG - 2025-09-19 09:34:56 --> Total execution time: 0.4142
INFO - 2025-09-19 04:35:11 --> Config Class Initialized
INFO - 2025-09-19 04:35:11 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:35:11 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:35:11 --> Utf8 Class Initialized
INFO - 2025-09-19 04:35:11 --> URI Class Initialized
INFO - 2025-09-19 04:35:11 --> Router Class Initialized
INFO - 2025-09-19 04:35:11 --> Output Class Initialized
INFO - 2025-09-19 04:35:11 --> Security Class Initialized
DEBUG - 2025-09-19 04:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:35:11 --> CSRF cookie sent
INFO - 2025-09-19 04:35:11 --> Input Class Initialized
INFO - 2025-09-19 04:35:11 --> Language Class Initialized
INFO - 2025-09-19 04:35:11 --> Loader Class Initialized
INFO - 2025-09-19 04:35:11 --> Helper loaded: url_helper
INFO - 2025-09-19 04:35:11 --> Helper loaded: text_helper
INFO - 2025-09-19 04:35:11 --> Helper loaded: string_helper
INFO - 2025-09-19 04:35:11 --> Helper loaded: form_helper
INFO - 2025-09-19 04:35:11 --> Helper loaded: download_helper
INFO - 2025-09-19 04:35:11 --> Helper loaded: security_helper
INFO - 2025-09-19 04:35:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:35:11 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:35:11 --> Form Validation Class Initialized
INFO - 2025-09-19 04:35:11 --> Model "User_model" initialized
INFO - 2025-09-19 09:35:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:35:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:35:11 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:35:11 --> Controller Class Initialized
INFO - 2025-09-19 09:35:11 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:35:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:35:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/prodi/edit.php
INFO - 2025-09-19 09:35:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:35:11 --> Model "Log_model" initialized
INFO - 2025-09-19 09:35:11 --> Final output sent to browser
DEBUG - 2025-09-19 09:35:11 --> Total execution time: 0.0564
INFO - 2025-09-19 04:35:32 --> Config Class Initialized
INFO - 2025-09-19 04:35:32 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:35:32 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:35:32 --> Utf8 Class Initialized
INFO - 2025-09-19 04:35:32 --> URI Class Initialized
INFO - 2025-09-19 04:35:32 --> Router Class Initialized
INFO - 2025-09-19 04:35:32 --> Output Class Initialized
INFO - 2025-09-19 04:35:32 --> Security Class Initialized
DEBUG - 2025-09-19 04:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:35:32 --> CSRF cookie sent
INFO - 2025-09-19 04:35:32 --> Input Class Initialized
INFO - 2025-09-19 04:35:32 --> Language Class Initialized
INFO - 2025-09-19 04:35:32 --> Loader Class Initialized
INFO - 2025-09-19 04:35:32 --> Helper loaded: url_helper
INFO - 2025-09-19 04:35:32 --> Helper loaded: text_helper
INFO - 2025-09-19 04:35:32 --> Helper loaded: string_helper
INFO - 2025-09-19 04:35:32 --> Helper loaded: form_helper
INFO - 2025-09-19 04:35:32 --> Helper loaded: download_helper
INFO - 2025-09-19 04:35:32 --> Helper loaded: security_helper
INFO - 2025-09-19 04:35:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:35:32 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:35:32 --> Form Validation Class Initialized
INFO - 2025-09-19 04:35:32 --> Model "User_model" initialized
INFO - 2025-09-19 09:35:32 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:35:32 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:35:32 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:35:32 --> Controller Class Initialized
INFO - 2025-09-19 09:35:32 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:35:32 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:35:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:35:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:35:32 --> Model "Log_model" initialized
INFO - 2025-09-19 09:35:32 --> Final output sent to browser
DEBUG - 2025-09-19 09:35:32 --> Total execution time: 0.0462
INFO - 2025-09-19 04:35:34 --> Config Class Initialized
INFO - 2025-09-19 04:35:34 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:35:34 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:35:34 --> Utf8 Class Initialized
INFO - 2025-09-19 04:35:34 --> URI Class Initialized
INFO - 2025-09-19 04:35:34 --> Router Class Initialized
INFO - 2025-09-19 04:35:34 --> Output Class Initialized
INFO - 2025-09-19 04:35:34 --> Security Class Initialized
DEBUG - 2025-09-19 04:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:35:34 --> CSRF cookie sent
INFO - 2025-09-19 04:35:34 --> Input Class Initialized
INFO - 2025-09-19 04:35:34 --> Language Class Initialized
INFO - 2025-09-19 04:35:34 --> Loader Class Initialized
INFO - 2025-09-19 04:35:34 --> Helper loaded: url_helper
INFO - 2025-09-19 04:35:34 --> Helper loaded: text_helper
INFO - 2025-09-19 04:35:34 --> Helper loaded: string_helper
INFO - 2025-09-19 04:35:34 --> Helper loaded: form_helper
INFO - 2025-09-19 04:35:34 --> Helper loaded: download_helper
INFO - 2025-09-19 04:35:34 --> Helper loaded: security_helper
INFO - 2025-09-19 04:35:34 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:35:34 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:35:34 --> Form Validation Class Initialized
INFO - 2025-09-19 04:35:34 --> Model "User_model" initialized
INFO - 2025-09-19 09:35:34 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:35:34 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:35:34 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:35:34 --> Controller Class Initialized
INFO - 2025-09-19 09:35:34 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:35:34 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:35:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:35:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:35:34 --> Model "Log_model" initialized
INFO - 2025-09-19 09:35:34 --> Final output sent to browser
DEBUG - 2025-09-19 09:35:34 --> Total execution time: 0.0515
INFO - 2025-09-19 04:36:17 --> Config Class Initialized
INFO - 2025-09-19 04:36:17 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:36:17 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:36:17 --> Utf8 Class Initialized
INFO - 2025-09-19 04:36:17 --> URI Class Initialized
INFO - 2025-09-19 04:36:17 --> Router Class Initialized
INFO - 2025-09-19 04:36:17 --> Output Class Initialized
INFO - 2025-09-19 04:36:17 --> Security Class Initialized
DEBUG - 2025-09-19 04:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:36:17 --> CSRF cookie sent
INFO - 2025-09-19 04:36:17 --> CSRF token verified
INFO - 2025-09-19 04:36:17 --> Input Class Initialized
INFO - 2025-09-19 04:36:17 --> Language Class Initialized
INFO - 2025-09-19 04:36:17 --> Loader Class Initialized
INFO - 2025-09-19 04:36:17 --> Helper loaded: url_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: text_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: string_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: form_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: download_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: security_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:36:17 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:36:17 --> Form Validation Class Initialized
INFO - 2025-09-19 04:36:17 --> Model "User_model" initialized
INFO - 2025-09-19 09:36:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:36:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:36:17 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:36:17 --> Controller Class Initialized
INFO - 2025-09-19 09:36:17 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:36:17 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:36:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 04:36:17 --> Config Class Initialized
INFO - 2025-09-19 04:36:17 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:36:17 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:36:17 --> Utf8 Class Initialized
INFO - 2025-09-19 04:36:17 --> URI Class Initialized
INFO - 2025-09-19 04:36:17 --> Router Class Initialized
INFO - 2025-09-19 04:36:17 --> Output Class Initialized
INFO - 2025-09-19 04:36:17 --> Security Class Initialized
DEBUG - 2025-09-19 04:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:36:17 --> CSRF cookie sent
INFO - 2025-09-19 04:36:17 --> Input Class Initialized
INFO - 2025-09-19 04:36:17 --> Language Class Initialized
INFO - 2025-09-19 04:36:17 --> Loader Class Initialized
INFO - 2025-09-19 04:36:17 --> Helper loaded: url_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: text_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: string_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: form_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: download_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: security_helper
INFO - 2025-09-19 04:36:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:36:17 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:36:17 --> Form Validation Class Initialized
INFO - 2025-09-19 04:36:17 --> Model "User_model" initialized
INFO - 2025-09-19 09:36:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:36:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:36:17 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:36:17 --> Controller Class Initialized
INFO - 2025-09-19 09:36:17 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:36:17 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:36:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:36:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:36:17 --> Model "Log_model" initialized
INFO - 2025-09-19 09:36:17 --> Final output sent to browser
DEBUG - 2025-09-19 09:36:17 --> Total execution time: 0.0482
INFO - 2025-09-19 04:36:23 --> Config Class Initialized
INFO - 2025-09-19 04:36:23 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:36:23 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:36:23 --> Utf8 Class Initialized
INFO - 2025-09-19 04:36:23 --> URI Class Initialized
INFO - 2025-09-19 04:36:23 --> Router Class Initialized
INFO - 2025-09-19 04:36:23 --> Output Class Initialized
INFO - 2025-09-19 04:36:23 --> Security Class Initialized
DEBUG - 2025-09-19 04:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:36:23 --> CSRF cookie sent
INFO - 2025-09-19 04:36:23 --> Input Class Initialized
INFO - 2025-09-19 04:36:23 --> Language Class Initialized
INFO - 2025-09-19 04:36:23 --> Loader Class Initialized
INFO - 2025-09-19 04:36:23 --> Helper loaded: url_helper
INFO - 2025-09-19 04:36:23 --> Helper loaded: text_helper
INFO - 2025-09-19 04:36:23 --> Helper loaded: string_helper
INFO - 2025-09-19 04:36:23 --> Helper loaded: form_helper
INFO - 2025-09-19 04:36:23 --> Helper loaded: download_helper
INFO - 2025-09-19 04:36:23 --> Helper loaded: security_helper
INFO - 2025-09-19 04:36:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:36:23 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:36:23 --> Form Validation Class Initialized
INFO - 2025-09-19 04:36:23 --> Model "User_model" initialized
INFO - 2025-09-19 09:36:23 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:36:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:36:23 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:36:23 --> Controller Class Initialized
INFO - 2025-09-19 09:36:23 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:36:23 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:36:23 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:36:23 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:36:23 --> Query SDM berhasil untuk jurusan: Kebidanan, Total: 0
ERROR - 2025-09-19 09:36:23 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:36:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:36:23 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:36:23 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:36:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:36:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:36:23 --> Model "Log_model" initialized
INFO - 2025-09-19 09:36:23 --> Final output sent to browser
DEBUG - 2025-09-19 09:36:23 --> Total execution time: 0.0739
INFO - 2025-09-19 04:36:40 --> Config Class Initialized
INFO - 2025-09-19 04:36:40 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:36:40 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:36:40 --> Utf8 Class Initialized
INFO - 2025-09-19 04:36:40 --> URI Class Initialized
INFO - 2025-09-19 04:36:40 --> Router Class Initialized
INFO - 2025-09-19 04:36:40 --> Output Class Initialized
INFO - 2025-09-19 04:36:40 --> Security Class Initialized
DEBUG - 2025-09-19 04:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:36:40 --> CSRF cookie sent
INFO - 2025-09-19 04:36:40 --> Input Class Initialized
INFO - 2025-09-19 04:36:40 --> Language Class Initialized
INFO - 2025-09-19 04:36:40 --> Loader Class Initialized
INFO - 2025-09-19 04:36:40 --> Helper loaded: url_helper
INFO - 2025-09-19 04:36:40 --> Helper loaded: text_helper
INFO - 2025-09-19 04:36:40 --> Helper loaded: string_helper
INFO - 2025-09-19 04:36:40 --> Helper loaded: form_helper
INFO - 2025-09-19 04:36:40 --> Helper loaded: download_helper
INFO - 2025-09-19 04:36:40 --> Helper loaded: security_helper
INFO - 2025-09-19 04:36:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:36:40 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:36:40 --> Form Validation Class Initialized
INFO - 2025-09-19 04:36:40 --> Model "User_model" initialized
INFO - 2025-09-19 09:36:40 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:36:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:36:40 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:36:40 --> Controller Class Initialized
INFO - 2025-09-19 09:36:40 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:36:40 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:36:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:36:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:36:40 --> Model "Log_model" initialized
INFO - 2025-09-19 09:36:40 --> Final output sent to browser
DEBUG - 2025-09-19 09:36:40 --> Total execution time: 0.0417
INFO - 2025-09-19 04:37:37 --> Config Class Initialized
INFO - 2025-09-19 04:37:37 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:37:37 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:37:37 --> Utf8 Class Initialized
INFO - 2025-09-19 04:37:37 --> URI Class Initialized
INFO - 2025-09-19 04:37:37 --> Router Class Initialized
INFO - 2025-09-19 04:37:37 --> Output Class Initialized
INFO - 2025-09-19 04:37:37 --> Security Class Initialized
DEBUG - 2025-09-19 04:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:37:37 --> CSRF cookie sent
INFO - 2025-09-19 04:37:37 --> CSRF token verified
INFO - 2025-09-19 04:37:37 --> Input Class Initialized
INFO - 2025-09-19 04:37:37 --> Language Class Initialized
INFO - 2025-09-19 04:37:37 --> Loader Class Initialized
INFO - 2025-09-19 04:37:37 --> Helper loaded: url_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: text_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: string_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: form_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: download_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: security_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:37:37 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:37:37 --> Form Validation Class Initialized
INFO - 2025-09-19 04:37:37 --> Model "User_model" initialized
INFO - 2025-09-19 09:37:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:37:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:37:37 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:37:37 --> Controller Class Initialized
INFO - 2025-09-19 09:37:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:37:37 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:37:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 04:37:37 --> Config Class Initialized
INFO - 2025-09-19 04:37:37 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:37:37 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:37:37 --> Utf8 Class Initialized
INFO - 2025-09-19 04:37:37 --> URI Class Initialized
INFO - 2025-09-19 04:37:37 --> Router Class Initialized
INFO - 2025-09-19 04:37:37 --> Output Class Initialized
INFO - 2025-09-19 04:37:37 --> Security Class Initialized
DEBUG - 2025-09-19 04:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:37:37 --> CSRF cookie sent
INFO - 2025-09-19 04:37:37 --> Input Class Initialized
INFO - 2025-09-19 04:37:37 --> Language Class Initialized
INFO - 2025-09-19 04:37:37 --> Loader Class Initialized
INFO - 2025-09-19 04:37:37 --> Helper loaded: url_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: text_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: string_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: form_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: download_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: security_helper
INFO - 2025-09-19 04:37:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:37:37 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:37:37 --> Form Validation Class Initialized
INFO - 2025-09-19 04:37:37 --> Model "User_model" initialized
INFO - 2025-09-19 09:37:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:37:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:37:37 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:37:37 --> Controller Class Initialized
INFO - 2025-09-19 09:37:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:37:37 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:37:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:37:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:37:37 --> Model "Log_model" initialized
INFO - 2025-09-19 09:37:37 --> Final output sent to browser
DEBUG - 2025-09-19 09:37:37 --> Total execution time: 0.0566
INFO - 2025-09-19 04:37:42 --> Config Class Initialized
INFO - 2025-09-19 04:37:42 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:37:42 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:37:42 --> Utf8 Class Initialized
INFO - 2025-09-19 04:37:42 --> URI Class Initialized
INFO - 2025-09-19 04:37:42 --> Router Class Initialized
INFO - 2025-09-19 04:37:42 --> Output Class Initialized
INFO - 2025-09-19 04:37:42 --> Security Class Initialized
DEBUG - 2025-09-19 04:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:37:42 --> CSRF cookie sent
INFO - 2025-09-19 04:37:42 --> Input Class Initialized
INFO - 2025-09-19 04:37:42 --> Language Class Initialized
INFO - 2025-09-19 04:37:42 --> Loader Class Initialized
INFO - 2025-09-19 04:37:42 --> Helper loaded: url_helper
INFO - 2025-09-19 04:37:42 --> Helper loaded: text_helper
INFO - 2025-09-19 04:37:42 --> Helper loaded: string_helper
INFO - 2025-09-19 04:37:42 --> Helper loaded: form_helper
INFO - 2025-09-19 04:37:42 --> Helper loaded: download_helper
INFO - 2025-09-19 04:37:42 --> Helper loaded: security_helper
INFO - 2025-09-19 04:37:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:37:42 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:37:42 --> Form Validation Class Initialized
INFO - 2025-09-19 04:37:42 --> Model "User_model" initialized
INFO - 2025-09-19 09:37:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:37:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:37:42 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:37:42 --> Controller Class Initialized
INFO - 2025-09-19 09:37:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:37:42 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:37:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:37:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:37:42 --> Model "Log_model" initialized
INFO - 2025-09-19 09:37:42 --> Final output sent to browser
DEBUG - 2025-09-19 09:37:42 --> Total execution time: 0.0595
INFO - 2025-09-19 04:38:25 --> Config Class Initialized
INFO - 2025-09-19 04:38:25 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:38:25 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:38:25 --> Utf8 Class Initialized
INFO - 2025-09-19 04:38:25 --> URI Class Initialized
INFO - 2025-09-19 04:38:25 --> Router Class Initialized
INFO - 2025-09-19 04:38:25 --> Output Class Initialized
INFO - 2025-09-19 04:38:25 --> Security Class Initialized
DEBUG - 2025-09-19 04:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:38:25 --> CSRF cookie sent
INFO - 2025-09-19 04:38:25 --> CSRF token verified
INFO - 2025-09-19 04:38:25 --> Input Class Initialized
INFO - 2025-09-19 04:38:25 --> Language Class Initialized
INFO - 2025-09-19 04:38:25 --> Loader Class Initialized
INFO - 2025-09-19 04:38:25 --> Helper loaded: url_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: text_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: string_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: form_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: download_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: security_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:38:25 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:38:25 --> Form Validation Class Initialized
INFO - 2025-09-19 04:38:25 --> Model "User_model" initialized
INFO - 2025-09-19 09:38:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:38:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:38:25 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:38:25 --> Controller Class Initialized
INFO - 2025-09-19 09:38:25 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:38:25 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:38:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 04:38:25 --> Config Class Initialized
INFO - 2025-09-19 04:38:25 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:38:25 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:38:25 --> Utf8 Class Initialized
INFO - 2025-09-19 04:38:25 --> URI Class Initialized
INFO - 2025-09-19 04:38:25 --> Router Class Initialized
INFO - 2025-09-19 04:38:25 --> Output Class Initialized
INFO - 2025-09-19 04:38:25 --> Security Class Initialized
DEBUG - 2025-09-19 04:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:38:25 --> CSRF cookie sent
INFO - 2025-09-19 04:38:25 --> Input Class Initialized
INFO - 2025-09-19 04:38:25 --> Language Class Initialized
INFO - 2025-09-19 04:38:25 --> Loader Class Initialized
INFO - 2025-09-19 04:38:25 --> Helper loaded: url_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: text_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: string_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: form_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: download_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: security_helper
INFO - 2025-09-19 04:38:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:38:25 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:38:25 --> Form Validation Class Initialized
INFO - 2025-09-19 04:38:25 --> Model "User_model" initialized
INFO - 2025-09-19 09:38:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:38:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:38:25 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:38:25 --> Controller Class Initialized
INFO - 2025-09-19 09:38:25 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:38:25 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:38:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:38:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:38:25 --> Model "Log_model" initialized
INFO - 2025-09-19 09:38:25 --> Final output sent to browser
DEBUG - 2025-09-19 09:38:25 --> Total execution time: 0.0395
INFO - 2025-09-19 04:38:33 --> Config Class Initialized
INFO - 2025-09-19 04:38:33 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:38:33 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:38:33 --> Utf8 Class Initialized
INFO - 2025-09-19 04:38:33 --> URI Class Initialized
INFO - 2025-09-19 04:38:33 --> Router Class Initialized
INFO - 2025-09-19 04:38:33 --> Output Class Initialized
INFO - 2025-09-19 04:38:33 --> Security Class Initialized
DEBUG - 2025-09-19 04:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:38:33 --> CSRF cookie sent
INFO - 2025-09-19 04:38:33 --> Input Class Initialized
INFO - 2025-09-19 04:38:33 --> Language Class Initialized
INFO - 2025-09-19 04:38:33 --> Loader Class Initialized
INFO - 2025-09-19 04:38:33 --> Helper loaded: url_helper
INFO - 2025-09-19 04:38:33 --> Helper loaded: text_helper
INFO - 2025-09-19 04:38:33 --> Helper loaded: string_helper
INFO - 2025-09-19 04:38:33 --> Helper loaded: form_helper
INFO - 2025-09-19 04:38:33 --> Helper loaded: download_helper
INFO - 2025-09-19 04:38:33 --> Helper loaded: security_helper
INFO - 2025-09-19 04:38:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:38:33 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:38:33 --> Form Validation Class Initialized
INFO - 2025-09-19 04:38:33 --> Model "User_model" initialized
INFO - 2025-09-19 09:38:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:38:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:38:33 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:38:33 --> Controller Class Initialized
INFO - 2025-09-19 09:38:33 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:38:33 --> Model "Prodi_model" initialized
INFO - 2025-09-19 04:38:36 --> Config Class Initialized
INFO - 2025-09-19 04:38:36 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:38:36 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:38:36 --> Utf8 Class Initialized
INFO - 2025-09-19 04:38:36 --> URI Class Initialized
INFO - 2025-09-19 04:38:36 --> Router Class Initialized
INFO - 2025-09-19 04:38:36 --> Output Class Initialized
INFO - 2025-09-19 04:38:36 --> Security Class Initialized
DEBUG - 2025-09-19 04:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:38:36 --> CSRF cookie sent
INFO - 2025-09-19 04:38:36 --> Input Class Initialized
INFO - 2025-09-19 04:38:36 --> Language Class Initialized
INFO - 2025-09-19 04:38:36 --> Loader Class Initialized
INFO - 2025-09-19 04:38:36 --> Helper loaded: url_helper
INFO - 2025-09-19 04:38:36 --> Helper loaded: text_helper
INFO - 2025-09-19 04:38:36 --> Helper loaded: string_helper
INFO - 2025-09-19 04:38:36 --> Helper loaded: form_helper
INFO - 2025-09-19 04:38:36 --> Helper loaded: download_helper
INFO - 2025-09-19 04:38:36 --> Helper loaded: security_helper
INFO - 2025-09-19 04:38:36 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:38:36 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:38:36 --> Form Validation Class Initialized
INFO - 2025-09-19 04:38:36 --> Model "User_model" initialized
INFO - 2025-09-19 09:38:36 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:38:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:38:36 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:38:36 --> Controller Class Initialized
INFO - 2025-09-19 09:38:36 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:38:36 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:38:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:38:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:38:36 --> Model "Log_model" initialized
INFO - 2025-09-19 09:38:36 --> Final output sent to browser
DEBUG - 2025-09-19 09:38:36 --> Total execution time: 0.0517
INFO - 2025-09-19 04:38:40 --> Config Class Initialized
INFO - 2025-09-19 04:38:40 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:38:40 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:38:40 --> Utf8 Class Initialized
INFO - 2025-09-19 04:38:40 --> URI Class Initialized
INFO - 2025-09-19 04:38:40 --> Router Class Initialized
INFO - 2025-09-19 04:38:40 --> Output Class Initialized
INFO - 2025-09-19 04:38:40 --> Security Class Initialized
DEBUG - 2025-09-19 04:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:38:40 --> CSRF cookie sent
INFO - 2025-09-19 04:38:40 --> Input Class Initialized
INFO - 2025-09-19 04:38:40 --> Language Class Initialized
INFO - 2025-09-19 04:38:40 --> Loader Class Initialized
INFO - 2025-09-19 04:38:40 --> Helper loaded: url_helper
INFO - 2025-09-19 04:38:40 --> Helper loaded: text_helper
INFO - 2025-09-19 04:38:40 --> Helper loaded: string_helper
INFO - 2025-09-19 04:38:40 --> Helper loaded: form_helper
INFO - 2025-09-19 04:38:40 --> Helper loaded: download_helper
INFO - 2025-09-19 04:38:40 --> Helper loaded: security_helper
INFO - 2025-09-19 04:38:40 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:38:40 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:38:40 --> Form Validation Class Initialized
INFO - 2025-09-19 04:38:40 --> Model "User_model" initialized
INFO - 2025-09-19 09:38:40 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:38:40 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:38:40 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:38:40 --> Controller Class Initialized
INFO - 2025-09-19 09:38:40 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:38:40 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:38:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:38:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:38:40 --> Model "Log_model" initialized
INFO - 2025-09-19 09:38:40 --> Final output sent to browser
DEBUG - 2025-09-19 09:38:40 --> Total execution time: 0.0437
INFO - 2025-09-19 04:38:47 --> Config Class Initialized
INFO - 2025-09-19 04:38:47 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:38:47 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:38:47 --> Utf8 Class Initialized
INFO - 2025-09-19 04:38:47 --> URI Class Initialized
INFO - 2025-09-19 04:38:47 --> Router Class Initialized
INFO - 2025-09-19 04:38:47 --> Output Class Initialized
INFO - 2025-09-19 04:38:47 --> Security Class Initialized
DEBUG - 2025-09-19 04:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:38:47 --> CSRF cookie sent
INFO - 2025-09-19 04:38:47 --> CSRF token verified
INFO - 2025-09-19 04:38:47 --> Input Class Initialized
INFO - 2025-09-19 04:38:47 --> Language Class Initialized
INFO - 2025-09-19 04:38:47 --> Loader Class Initialized
INFO - 2025-09-19 04:38:47 --> Helper loaded: url_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: text_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: string_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: form_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: download_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: security_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:38:47 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:38:47 --> Form Validation Class Initialized
INFO - 2025-09-19 04:38:47 --> Model "User_model" initialized
INFO - 2025-09-19 09:38:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:38:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:38:47 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:38:47 --> Controller Class Initialized
INFO - 2025-09-19 09:38:47 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:38:47 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:38:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 04:38:47 --> Config Class Initialized
INFO - 2025-09-19 04:38:47 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:38:47 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:38:47 --> Utf8 Class Initialized
INFO - 2025-09-19 04:38:47 --> URI Class Initialized
INFO - 2025-09-19 04:38:47 --> Router Class Initialized
INFO - 2025-09-19 04:38:47 --> Output Class Initialized
INFO - 2025-09-19 04:38:47 --> Security Class Initialized
DEBUG - 2025-09-19 04:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:38:47 --> CSRF cookie sent
INFO - 2025-09-19 04:38:47 --> Input Class Initialized
INFO - 2025-09-19 04:38:47 --> Language Class Initialized
INFO - 2025-09-19 04:38:47 --> Loader Class Initialized
INFO - 2025-09-19 04:38:47 --> Helper loaded: url_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: text_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: string_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: form_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: download_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: security_helper
INFO - 2025-09-19 04:38:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:38:47 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:38:47 --> Form Validation Class Initialized
INFO - 2025-09-19 04:38:47 --> Model "User_model" initialized
INFO - 2025-09-19 09:38:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:38:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:38:47 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:38:47 --> Controller Class Initialized
INFO - 2025-09-19 09:38:47 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:38:47 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:38:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:38:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:38:47 --> Model "Log_model" initialized
INFO - 2025-09-19 09:38:47 --> Final output sent to browser
DEBUG - 2025-09-19 09:38:47 --> Total execution time: 0.0616
INFO - 2025-09-19 04:38:51 --> Config Class Initialized
INFO - 2025-09-19 04:38:51 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:38:51 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:38:51 --> Utf8 Class Initialized
INFO - 2025-09-19 04:38:51 --> URI Class Initialized
INFO - 2025-09-19 04:38:51 --> Router Class Initialized
INFO - 2025-09-19 04:38:51 --> Output Class Initialized
INFO - 2025-09-19 04:38:51 --> Security Class Initialized
DEBUG - 2025-09-19 04:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:38:51 --> CSRF cookie sent
INFO - 2025-09-19 04:38:51 --> Input Class Initialized
INFO - 2025-09-19 04:38:51 --> Language Class Initialized
INFO - 2025-09-19 04:38:51 --> Loader Class Initialized
INFO - 2025-09-19 04:38:51 --> Helper loaded: url_helper
INFO - 2025-09-19 04:38:51 --> Helper loaded: text_helper
INFO - 2025-09-19 04:38:51 --> Helper loaded: string_helper
INFO - 2025-09-19 04:38:51 --> Helper loaded: form_helper
INFO - 2025-09-19 04:38:51 --> Helper loaded: download_helper
INFO - 2025-09-19 04:38:51 --> Helper loaded: security_helper
INFO - 2025-09-19 04:38:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:38:51 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:38:51 --> Form Validation Class Initialized
INFO - 2025-09-19 04:38:51 --> Model "User_model" initialized
INFO - 2025-09-19 09:38:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:38:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:38:51 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:38:51 --> Controller Class Initialized
INFO - 2025-09-19 09:38:51 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:38:51 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:38:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:38:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:38:51 --> Model "Log_model" initialized
INFO - 2025-09-19 09:38:51 --> Final output sent to browser
DEBUG - 2025-09-19 09:38:51 --> Total execution time: 0.0472
INFO - 2025-09-19 04:38:55 --> Config Class Initialized
INFO - 2025-09-19 04:38:55 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:38:55 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:38:55 --> Utf8 Class Initialized
INFO - 2025-09-19 04:38:55 --> URI Class Initialized
INFO - 2025-09-19 04:38:55 --> Router Class Initialized
INFO - 2025-09-19 04:38:55 --> Output Class Initialized
INFO - 2025-09-19 04:38:55 --> Security Class Initialized
DEBUG - 2025-09-19 04:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:38:55 --> CSRF cookie sent
INFO - 2025-09-19 04:38:55 --> CSRF token verified
INFO - 2025-09-19 04:38:55 --> Input Class Initialized
INFO - 2025-09-19 04:38:55 --> Language Class Initialized
INFO - 2025-09-19 04:38:55 --> Loader Class Initialized
INFO - 2025-09-19 04:38:55 --> Helper loaded: url_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: text_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: string_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: form_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: download_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: security_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:38:55 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:38:55 --> Form Validation Class Initialized
INFO - 2025-09-19 04:38:55 --> Model "User_model" initialized
INFO - 2025-09-19 09:38:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:38:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:38:55 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:38:55 --> Controller Class Initialized
INFO - 2025-09-19 09:38:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:38:55 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:38:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 04:38:55 --> Config Class Initialized
INFO - 2025-09-19 04:38:55 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:38:55 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:38:55 --> Utf8 Class Initialized
INFO - 2025-09-19 04:38:55 --> URI Class Initialized
INFO - 2025-09-19 04:38:55 --> Router Class Initialized
INFO - 2025-09-19 04:38:55 --> Output Class Initialized
INFO - 2025-09-19 04:38:55 --> Security Class Initialized
DEBUG - 2025-09-19 04:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:38:55 --> CSRF cookie sent
INFO - 2025-09-19 04:38:55 --> Input Class Initialized
INFO - 2025-09-19 04:38:55 --> Language Class Initialized
INFO - 2025-09-19 04:38:55 --> Loader Class Initialized
INFO - 2025-09-19 04:38:55 --> Helper loaded: url_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: text_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: string_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: form_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: download_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: security_helper
INFO - 2025-09-19 04:38:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:38:55 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:38:55 --> Form Validation Class Initialized
INFO - 2025-09-19 04:38:55 --> Model "User_model" initialized
INFO - 2025-09-19 09:38:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:38:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:38:55 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:38:55 --> Controller Class Initialized
INFO - 2025-09-19 09:38:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:38:55 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:38:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/list.php
INFO - 2025-09-19 09:38:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:38:55 --> Model "Log_model" initialized
INFO - 2025-09-19 09:38:55 --> Final output sent to browser
DEBUG - 2025-09-19 09:38:55 --> Total execution time: 0.0554
INFO - 2025-09-19 04:39:01 --> Config Class Initialized
INFO - 2025-09-19 04:39:01 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:39:01 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:39:01 --> Utf8 Class Initialized
INFO - 2025-09-19 04:39:01 --> URI Class Initialized
INFO - 2025-09-19 04:39:01 --> Router Class Initialized
INFO - 2025-09-19 04:39:01 --> Output Class Initialized
INFO - 2025-09-19 04:39:01 --> Security Class Initialized
DEBUG - 2025-09-19 04:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:39:01 --> CSRF cookie sent
INFO - 2025-09-19 04:39:01 --> Input Class Initialized
INFO - 2025-09-19 04:39:01 --> Language Class Initialized
INFO - 2025-09-19 04:39:01 --> Loader Class Initialized
INFO - 2025-09-19 04:39:01 --> Helper loaded: url_helper
INFO - 2025-09-19 04:39:01 --> Helper loaded: text_helper
INFO - 2025-09-19 04:39:01 --> Helper loaded: string_helper
INFO - 2025-09-19 04:39:01 --> Helper loaded: form_helper
INFO - 2025-09-19 04:39:01 --> Helper loaded: download_helper
INFO - 2025-09-19 04:39:01 --> Helper loaded: security_helper
INFO - 2025-09-19 04:39:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:39:01 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:39:01 --> Form Validation Class Initialized
INFO - 2025-09-19 04:39:01 --> Model "User_model" initialized
INFO - 2025-09-19 09:39:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:39:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:39:01 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:39:01 --> Controller Class Initialized
INFO - 2025-09-19 09:39:01 --> Model "Pusat_model" initialized
INFO - 2025-09-19 09:39:01 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:39:01 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:39:01 --> Model "Sdm_pusat_model" initialized
INFO - 2025-09-19 09:39:01 --> Query SDM berhasil untuk pusat: Pusat Penelitian dan Pengabdian Masyarakat, Total: 1
INFO - 2025-09-19 09:39:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-09-19 09:39:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:39:01 --> Model "Log_model" initialized
INFO - 2025-09-19 09:39:01 --> Final output sent to browser
DEBUG - 2025-09-19 09:39:01 --> Total execution time: 0.0729
INFO - 2025-09-19 04:39:20 --> Config Class Initialized
INFO - 2025-09-19 04:39:20 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:39:20 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:39:20 --> Utf8 Class Initialized
INFO - 2025-09-19 04:39:20 --> URI Class Initialized
INFO - 2025-09-19 04:39:20 --> Router Class Initialized
INFO - 2025-09-19 04:39:20 --> Output Class Initialized
INFO - 2025-09-19 04:39:20 --> Security Class Initialized
DEBUG - 2025-09-19 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:39:20 --> CSRF cookie sent
INFO - 2025-09-19 04:39:20 --> Input Class Initialized
INFO - 2025-09-19 04:39:20 --> Language Class Initialized
INFO - 2025-09-19 04:39:20 --> Loader Class Initialized
INFO - 2025-09-19 04:39:20 --> Helper loaded: url_helper
INFO - 2025-09-19 04:39:20 --> Helper loaded: text_helper
INFO - 2025-09-19 04:39:20 --> Helper loaded: string_helper
INFO - 2025-09-19 04:39:20 --> Helper loaded: form_helper
INFO - 2025-09-19 04:39:20 --> Helper loaded: download_helper
INFO - 2025-09-19 04:39:20 --> Helper loaded: security_helper
INFO - 2025-09-19 04:39:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:39:20 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:39:20 --> Form Validation Class Initialized
INFO - 2025-09-19 04:39:20 --> Model "User_model" initialized
INFO - 2025-09-19 09:39:20 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:39:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:39:20 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:39:20 --> Controller Class Initialized
INFO - 2025-09-19 09:39:20 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:39:20 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:39:20 --> Model "Sdm_model" initialized
INFO - 2025-09-19 09:39:20 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-19 09:39:20 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 0
ERROR - 2025-09-19 09:39:20 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:39:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2025-09-19 09:39:20 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-19 09:39:20 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-19 09:39:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-19 09:39:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:39:20 --> Model "Log_model" initialized
INFO - 2025-09-19 09:39:20 --> Final output sent to browser
DEBUG - 2025-09-19 09:39:20 --> Total execution time: 0.0804
INFO - 2025-09-19 04:42:52 --> Config Class Initialized
INFO - 2025-09-19 04:42:52 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:42:52 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:42:52 --> Utf8 Class Initialized
INFO - 2025-09-19 04:42:52 --> URI Class Initialized
INFO - 2025-09-19 04:42:52 --> Router Class Initialized
INFO - 2025-09-19 04:42:52 --> Output Class Initialized
INFO - 2025-09-19 04:42:52 --> Security Class Initialized
DEBUG - 2025-09-19 04:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:42:52 --> CSRF cookie sent
INFO - 2025-09-19 04:42:52 --> Input Class Initialized
INFO - 2025-09-19 04:42:52 --> Language Class Initialized
INFO - 2025-09-19 04:42:52 --> Loader Class Initialized
INFO - 2025-09-19 04:42:52 --> Helper loaded: url_helper
INFO - 2025-09-19 04:42:52 --> Helper loaded: text_helper
INFO - 2025-09-19 04:42:52 --> Helper loaded: string_helper
INFO - 2025-09-19 04:42:52 --> Helper loaded: form_helper
INFO - 2025-09-19 04:42:52 --> Helper loaded: download_helper
INFO - 2025-09-19 04:42:52 --> Helper loaded: security_helper
INFO - 2025-09-19 04:42:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:42:52 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:42:52 --> Form Validation Class Initialized
INFO - 2025-09-19 04:42:52 --> Model "User_model" initialized
INFO - 2025-09-19 09:42:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:42:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:42:52 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:42:52 --> Controller Class Initialized
INFO - 2025-09-19 09:42:52 --> Model "Download_model" initialized
INFO - 2025-09-19 09:42:52 --> Model "Kategori_download_model" initialized
INFO - 2025-09-19 09:42:52 --> Model "Jenis_download_model" initialized
INFO - 2025-09-19 09:42:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2025-09-19 09:42:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:42:52 --> Model "Log_model" initialized
INFO - 2025-09-19 09:42:52 --> Final output sent to browser
DEBUG - 2025-09-19 09:42:52 --> Total execution time: 0.2995
INFO - 2025-09-19 04:43:13 --> Config Class Initialized
INFO - 2025-09-19 04:43:13 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:43:13 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:43:13 --> Utf8 Class Initialized
INFO - 2025-09-19 04:43:13 --> URI Class Initialized
INFO - 2025-09-19 04:43:13 --> Router Class Initialized
INFO - 2025-09-19 04:43:13 --> Output Class Initialized
INFO - 2025-09-19 04:43:13 --> Security Class Initialized
DEBUG - 2025-09-19 04:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:43:13 --> CSRF cookie sent
INFO - 2025-09-19 04:43:13 --> Input Class Initialized
INFO - 2025-09-19 04:43:13 --> Language Class Initialized
INFO - 2025-09-19 04:43:13 --> Loader Class Initialized
INFO - 2025-09-19 04:43:13 --> Helper loaded: url_helper
INFO - 2025-09-19 04:43:13 --> Helper loaded: text_helper
INFO - 2025-09-19 04:43:13 --> Helper loaded: string_helper
INFO - 2025-09-19 04:43:13 --> Helper loaded: form_helper
INFO - 2025-09-19 04:43:13 --> Helper loaded: download_helper
INFO - 2025-09-19 04:43:13 --> Helper loaded: security_helper
INFO - 2025-09-19 04:43:13 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:43:13 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:43:13 --> Form Validation Class Initialized
INFO - 2025-09-19 04:43:13 --> Model "User_model" initialized
INFO - 2025-09-19 09:43:13 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:43:13 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:43:13 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:43:13 --> Controller Class Initialized
INFO - 2025-09-19 09:43:13 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:43:13 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:43:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/jurusan/edit.php
INFO - 2025-09-19 09:43:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 09:43:13 --> Model "Log_model" initialized
INFO - 2025-09-19 09:43:13 --> Final output sent to browser
DEBUG - 2025-09-19 09:43:13 --> Total execution time: 0.0511
INFO - 2025-09-19 04:52:49 --> Config Class Initialized
INFO - 2025-09-19 04:52:49 --> Hooks Class Initialized
DEBUG - 2025-09-19 04:52:49 --> UTF-8 Support Enabled
INFO - 2025-09-19 04:52:49 --> Utf8 Class Initialized
INFO - 2025-09-19 04:52:49 --> URI Class Initialized
DEBUG - 2025-09-19 04:52:50 --> No URI present. Default controller set.
INFO - 2025-09-19 04:52:50 --> Router Class Initialized
INFO - 2025-09-19 04:52:50 --> Output Class Initialized
INFO - 2025-09-19 04:52:50 --> Security Class Initialized
DEBUG - 2025-09-19 04:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 04:52:50 --> CSRF cookie sent
INFO - 2025-09-19 04:52:50 --> Input Class Initialized
INFO - 2025-09-19 04:52:50 --> Language Class Initialized
INFO - 2025-09-19 04:52:50 --> Loader Class Initialized
INFO - 2025-09-19 04:52:50 --> Helper loaded: url_helper
INFO - 2025-09-19 04:52:50 --> Helper loaded: text_helper
INFO - 2025-09-19 04:52:51 --> Helper loaded: string_helper
INFO - 2025-09-19 04:52:51 --> Helper loaded: form_helper
INFO - 2025-09-19 04:52:51 --> Helper loaded: download_helper
INFO - 2025-09-19 04:52:51 --> Helper loaded: security_helper
INFO - 2025-09-19 04:52:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 04:52:51 --> Database Driver Class Initialized
DEBUG - 2025-09-19 04:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 04:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 04:52:52 --> Form Validation Class Initialized
INFO - 2025-09-19 04:52:52 --> Model "User_model" initialized
INFO - 2025-09-19 09:52:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 09:52:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 09:52:52 --> Model "Nav_model" initialized
INFO - 2025-09-19 09:52:52 --> Controller Class Initialized
INFO - 2025-09-19 09:52:53 --> Model "Berita_model" initialized
INFO - 2025-09-19 09:52:53 --> Model "Galeri_model" initialized
INFO - 2025-09-19 09:52:53 --> Model "Video_model" initialized
INFO - 2025-09-19 09:52:53 --> Model "Agenda_model" initialized
INFO - 2025-09-19 09:52:53 --> Model "Tautan_model" initialized
INFO - 2025-09-19 09:52:53 --> Model "Mitra_model" initialized
INFO - 2025-09-19 09:52:53 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 09:52:53 --> Model "Prodi_model" initialized
INFO - 2025-09-19 09:52:53 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 09:52:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 09:52:53 --> Pagination Class Initialized
INFO - 2025-09-19 09:52:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 09:52:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 09:52:56 --> Model "Log_model" initialized
INFO - 2025-09-19 09:52:56 --> Final output sent to browser
DEBUG - 2025-09-19 09:52:56 --> Total execution time: 7.1444
INFO - 2025-09-19 05:08:51 --> Config Class Initialized
INFO - 2025-09-19 05:08:51 --> Hooks Class Initialized
DEBUG - 2025-09-19 05:08:51 --> UTF-8 Support Enabled
INFO - 2025-09-19 05:08:51 --> Utf8 Class Initialized
INFO - 2025-09-19 05:08:51 --> URI Class Initialized
DEBUG - 2025-09-19 05:08:51 --> No URI present. Default controller set.
INFO - 2025-09-19 05:08:51 --> Router Class Initialized
INFO - 2025-09-19 05:08:51 --> Output Class Initialized
INFO - 2025-09-19 05:08:51 --> Security Class Initialized
DEBUG - 2025-09-19 05:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 05:08:51 --> CSRF cookie sent
INFO - 2025-09-19 05:08:51 --> Input Class Initialized
INFO - 2025-09-19 05:08:51 --> Language Class Initialized
INFO - 2025-09-19 05:08:51 --> Loader Class Initialized
INFO - 2025-09-19 05:08:51 --> Helper loaded: url_helper
INFO - 2025-09-19 05:08:51 --> Helper loaded: text_helper
INFO - 2025-09-19 05:08:51 --> Helper loaded: string_helper
INFO - 2025-09-19 05:08:51 --> Helper loaded: form_helper
INFO - 2025-09-19 05:08:51 --> Helper loaded: download_helper
INFO - 2025-09-19 05:08:51 --> Helper loaded: security_helper
INFO - 2025-09-19 05:08:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 05:08:51 --> Database Driver Class Initialized
DEBUG - 2025-09-19 05:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 05:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 05:08:51 --> Form Validation Class Initialized
INFO - 2025-09-19 05:08:51 --> Model "User_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Nav_model" initialized
INFO - 2025-09-19 10:08:51 --> Controller Class Initialized
INFO - 2025-09-19 10:08:51 --> Model "Berita_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Galeri_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Video_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Agenda_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Tautan_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Mitra_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Prodi_model" initialized
INFO - 2025-09-19 10:08:51 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 10:08:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 10:08:51 --> Pagination Class Initialized
INFO - 2025-09-19 10:08:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 10:08:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 10:08:51 --> Model "Log_model" initialized
INFO - 2025-09-19 10:08:51 --> Final output sent to browser
DEBUG - 2025-09-19 10:08:51 --> Total execution time: 0.1240
INFO - 2025-09-19 05:09:15 --> Config Class Initialized
INFO - 2025-09-19 05:09:15 --> Hooks Class Initialized
DEBUG - 2025-09-19 05:09:15 --> UTF-8 Support Enabled
INFO - 2025-09-19 05:09:15 --> Utf8 Class Initialized
INFO - 2025-09-19 05:09:15 --> URI Class Initialized
INFO - 2025-09-19 05:09:15 --> Router Class Initialized
INFO - 2025-09-19 05:09:15 --> Output Class Initialized
INFO - 2025-09-19 05:09:15 --> Security Class Initialized
DEBUG - 2025-09-19 05:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 05:09:15 --> CSRF cookie sent
INFO - 2025-09-19 05:09:15 --> Input Class Initialized
INFO - 2025-09-19 05:09:15 --> Language Class Initialized
INFO - 2025-09-19 05:09:15 --> Loader Class Initialized
INFO - 2025-09-19 05:09:15 --> Helper loaded: url_helper
INFO - 2025-09-19 05:09:15 --> Helper loaded: text_helper
INFO - 2025-09-19 05:09:15 --> Helper loaded: string_helper
INFO - 2025-09-19 05:09:15 --> Helper loaded: form_helper
INFO - 2025-09-19 05:09:15 --> Helper loaded: download_helper
INFO - 2025-09-19 05:09:15 --> Helper loaded: security_helper
INFO - 2025-09-19 05:09:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 05:09:15 --> Database Driver Class Initialized
DEBUG - 2025-09-19 05:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 05:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 05:09:15 --> Form Validation Class Initialized
INFO - 2025-09-19 05:09:15 --> Model "User_model" initialized
INFO - 2025-09-19 10:09:15 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 10:09:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 10:09:15 --> Model "Nav_model" initialized
INFO - 2025-09-19 10:09:15 --> Controller Class Initialized
DEBUG - 2025-09-19 10:09:15 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 10:09:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-19 10:09:15 --> Model "Log_model" initialized
INFO - 2025-09-19 10:09:15 --> Final output sent to browser
DEBUG - 2025-09-19 10:09:15 --> Total execution time: 0.1445
INFO - 2025-09-19 05:09:25 --> Config Class Initialized
INFO - 2025-09-19 05:09:25 --> Hooks Class Initialized
DEBUG - 2025-09-19 05:09:25 --> UTF-8 Support Enabled
INFO - 2025-09-19 05:09:25 --> Utf8 Class Initialized
INFO - 2025-09-19 05:09:25 --> URI Class Initialized
INFO - 2025-09-19 05:09:25 --> Router Class Initialized
INFO - 2025-09-19 05:09:25 --> Output Class Initialized
INFO - 2025-09-19 05:09:25 --> Security Class Initialized
DEBUG - 2025-09-19 05:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 05:09:25 --> CSRF cookie sent
INFO - 2025-09-19 05:09:25 --> CSRF token verified
INFO - 2025-09-19 05:09:25 --> Input Class Initialized
INFO - 2025-09-19 05:09:25 --> Language Class Initialized
INFO - 2025-09-19 05:09:25 --> Loader Class Initialized
INFO - 2025-09-19 05:09:25 --> Helper loaded: url_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: text_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: string_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: form_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: download_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: security_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 05:09:25 --> Database Driver Class Initialized
DEBUG - 2025-09-19 05:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 05:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 05:09:25 --> Form Validation Class Initialized
INFO - 2025-09-19 05:09:25 --> Model "User_model" initialized
INFO - 2025-09-19 10:09:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 10:09:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 10:09:25 --> Model "Nav_model" initialized
INFO - 2025-09-19 10:09:25 --> Controller Class Initialized
DEBUG - 2025-09-19 10:09:25 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-19 10:09:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-19 05:09:25 --> Config Class Initialized
INFO - 2025-09-19 05:09:25 --> Hooks Class Initialized
DEBUG - 2025-09-19 05:09:25 --> UTF-8 Support Enabled
INFO - 2025-09-19 05:09:25 --> Utf8 Class Initialized
INFO - 2025-09-19 05:09:25 --> URI Class Initialized
INFO - 2025-09-19 05:09:25 --> Router Class Initialized
INFO - 2025-09-19 05:09:25 --> Output Class Initialized
INFO - 2025-09-19 05:09:25 --> Security Class Initialized
DEBUG - 2025-09-19 05:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 05:09:25 --> CSRF cookie sent
INFO - 2025-09-19 05:09:25 --> Input Class Initialized
INFO - 2025-09-19 05:09:25 --> Language Class Initialized
INFO - 2025-09-19 05:09:25 --> Loader Class Initialized
INFO - 2025-09-19 05:09:25 --> Helper loaded: url_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: text_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: string_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: form_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: download_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: security_helper
INFO - 2025-09-19 05:09:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 05:09:25 --> Database Driver Class Initialized
DEBUG - 2025-09-19 05:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 05:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 05:09:25 --> Form Validation Class Initialized
INFO - 2025-09-19 05:09:25 --> Model "User_model" initialized
INFO - 2025-09-19 10:09:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 10:09:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 10:09:25 --> Model "Nav_model" initialized
INFO - 2025-09-19 10:09:25 --> Controller Class Initialized
INFO - 2025-09-19 10:09:25 --> Model "Tautan_model" initialized
INFO - 2025-09-19 10:09:25 --> Model "Staff_model" initialized
INFO - 2025-09-19 10:09:25 --> Model "Dasbor_model" initialized
INFO - 2025-09-19 10:09:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-09-19 10:09:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-19 10:09:26 --> Model "Log_model" initialized
INFO - 2025-09-19 10:09:26 --> Final output sent to browser
DEBUG - 2025-09-19 10:09:26 --> Total execution time: 1.3729
INFO - 2025-09-19 05:29:53 --> Config Class Initialized
INFO - 2025-09-19 05:29:53 --> Hooks Class Initialized
DEBUG - 2025-09-19 05:29:53 --> UTF-8 Support Enabled
INFO - 2025-09-19 05:29:53 --> Utf8 Class Initialized
INFO - 2025-09-19 05:29:53 --> URI Class Initialized
DEBUG - 2025-09-19 05:29:53 --> No URI present. Default controller set.
INFO - 2025-09-19 05:29:53 --> Router Class Initialized
INFO - 2025-09-19 05:29:53 --> Output Class Initialized
INFO - 2025-09-19 05:29:53 --> Security Class Initialized
DEBUG - 2025-09-19 05:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 05:29:53 --> CSRF cookie sent
INFO - 2025-09-19 05:29:53 --> Input Class Initialized
INFO - 2025-09-19 05:29:53 --> Language Class Initialized
INFO - 2025-09-19 05:29:53 --> Loader Class Initialized
INFO - 2025-09-19 05:29:53 --> Helper loaded: url_helper
INFO - 2025-09-19 05:29:53 --> Helper loaded: text_helper
INFO - 2025-09-19 05:29:53 --> Helper loaded: string_helper
INFO - 2025-09-19 05:29:53 --> Helper loaded: form_helper
INFO - 2025-09-19 05:29:53 --> Helper loaded: download_helper
INFO - 2025-09-19 05:29:53 --> Helper loaded: security_helper
INFO - 2025-09-19 05:29:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 05:29:53 --> Database Driver Class Initialized
DEBUG - 2025-09-19 05:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 05:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 05:29:53 --> Form Validation Class Initialized
INFO - 2025-09-19 05:29:53 --> Model "User_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Nav_model" initialized
INFO - 2025-09-19 10:29:53 --> Controller Class Initialized
INFO - 2025-09-19 10:29:53 --> Model "Berita_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Galeri_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Video_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Agenda_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Tautan_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Mitra_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Prodi_model" initialized
INFO - 2025-09-19 10:29:53 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 10:29:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 10:29:53 --> Pagination Class Initialized
INFO - 2025-09-19 10:29:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 10:29:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 10:29:53 --> Model "Log_model" initialized
INFO - 2025-09-19 10:29:53 --> Final output sent to browser
DEBUG - 2025-09-19 10:29:53 --> Total execution time: 0.1878
INFO - 2025-09-19 06:08:44 --> Config Class Initialized
INFO - 2025-09-19 06:08:44 --> Hooks Class Initialized
DEBUG - 2025-09-19 06:08:44 --> UTF-8 Support Enabled
INFO - 2025-09-19 06:08:44 --> Utf8 Class Initialized
INFO - 2025-09-19 06:08:44 --> URI Class Initialized
DEBUG - 2025-09-19 06:08:44 --> No URI present. Default controller set.
INFO - 2025-09-19 06:08:44 --> Router Class Initialized
INFO - 2025-09-19 06:08:45 --> Output Class Initialized
INFO - 2025-09-19 06:08:45 --> Security Class Initialized
DEBUG - 2025-09-19 06:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 06:08:45 --> CSRF cookie sent
INFO - 2025-09-19 06:08:45 --> Input Class Initialized
INFO - 2025-09-19 06:08:45 --> Language Class Initialized
INFO - 2025-09-19 06:08:45 --> Loader Class Initialized
INFO - 2025-09-19 06:08:45 --> Helper loaded: url_helper
INFO - 2025-09-19 06:08:45 --> Helper loaded: text_helper
INFO - 2025-09-19 06:08:45 --> Helper loaded: string_helper
INFO - 2025-09-19 06:08:45 --> Helper loaded: form_helper
INFO - 2025-09-19 06:08:45 --> Helper loaded: download_helper
INFO - 2025-09-19 06:08:45 --> Helper loaded: security_helper
INFO - 2025-09-19 06:08:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 06:08:45 --> Database Driver Class Initialized
DEBUG - 2025-09-19 06:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 06:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 06:08:45 --> Form Validation Class Initialized
INFO - 2025-09-19 06:08:45 --> Model "User_model" initialized
INFO - 2025-09-19 11:08:45 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 11:08:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 11:08:45 --> Model "Nav_model" initialized
INFO - 2025-09-19 11:08:45 --> Controller Class Initialized
INFO - 2025-09-19 11:08:45 --> Model "Berita_model" initialized
INFO - 2025-09-19 11:08:45 --> Model "Galeri_model" initialized
INFO - 2025-09-19 11:08:45 --> Model "Video_model" initialized
INFO - 2025-09-19 11:08:45 --> Model "Agenda_model" initialized
INFO - 2025-09-19 11:08:45 --> Model "Tautan_model" initialized
INFO - 2025-09-19 11:08:45 --> Model "Mitra_model" initialized
INFO - 2025-09-19 11:08:45 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 11:08:46 --> Model "Prodi_model" initialized
INFO - 2025-09-19 11:08:46 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 11:08:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 11:08:46 --> Pagination Class Initialized
INFO - 2025-09-19 11:08:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 11:08:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 11:08:48 --> Model "Log_model" initialized
INFO - 2025-09-19 11:08:48 --> Final output sent to browser
DEBUG - 2025-09-19 11:08:48 --> Total execution time: 3.3969
INFO - 2025-09-19 06:09:20 --> Config Class Initialized
INFO - 2025-09-19 06:09:20 --> Hooks Class Initialized
DEBUG - 2025-09-19 06:09:20 --> UTF-8 Support Enabled
INFO - 2025-09-19 06:09:20 --> Utf8 Class Initialized
INFO - 2025-09-19 06:09:20 --> URI Class Initialized
DEBUG - 2025-09-19 06:09:20 --> No URI present. Default controller set.
INFO - 2025-09-19 06:09:20 --> Router Class Initialized
INFO - 2025-09-19 06:09:20 --> Output Class Initialized
INFO - 2025-09-19 06:09:20 --> Security Class Initialized
DEBUG - 2025-09-19 06:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 06:09:20 --> CSRF cookie sent
INFO - 2025-09-19 06:09:20 --> Input Class Initialized
INFO - 2025-09-19 06:09:20 --> Language Class Initialized
INFO - 2025-09-19 06:09:20 --> Loader Class Initialized
INFO - 2025-09-19 06:09:20 --> Helper loaded: url_helper
INFO - 2025-09-19 06:09:20 --> Helper loaded: text_helper
INFO - 2025-09-19 06:09:20 --> Helper loaded: string_helper
INFO - 2025-09-19 06:09:20 --> Helper loaded: form_helper
INFO - 2025-09-19 06:09:20 --> Helper loaded: download_helper
INFO - 2025-09-19 06:09:20 --> Helper loaded: security_helper
INFO - 2025-09-19 06:09:20 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 06:09:20 --> Database Driver Class Initialized
DEBUG - 2025-09-19 06:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 06:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 06:09:20 --> Form Validation Class Initialized
INFO - 2025-09-19 06:09:20 --> Model "User_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Nav_model" initialized
INFO - 2025-09-19 11:09:20 --> Controller Class Initialized
INFO - 2025-09-19 11:09:20 --> Model "Berita_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Galeri_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Video_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Agenda_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Tautan_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Mitra_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Prodi_model" initialized
INFO - 2025-09-19 11:09:20 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 11:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 11:09:20 --> Pagination Class Initialized
INFO - 2025-09-19 11:09:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 11:09:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 11:09:20 --> Model "Log_model" initialized
INFO - 2025-09-19 11:09:20 --> Final output sent to browser
DEBUG - 2025-09-19 11:09:20 --> Total execution time: 0.1387
INFO - 2025-09-19 06:09:28 --> Config Class Initialized
INFO - 2025-09-19 06:09:28 --> Hooks Class Initialized
DEBUG - 2025-09-19 06:09:28 --> UTF-8 Support Enabled
INFO - 2025-09-19 06:09:28 --> Utf8 Class Initialized
INFO - 2025-09-19 06:09:28 --> URI Class Initialized
DEBUG - 2025-09-19 06:09:28 --> No URI present. Default controller set.
INFO - 2025-09-19 06:09:28 --> Router Class Initialized
INFO - 2025-09-19 06:09:28 --> Output Class Initialized
INFO - 2025-09-19 06:09:28 --> Security Class Initialized
DEBUG - 2025-09-19 06:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 06:09:28 --> CSRF cookie sent
INFO - 2025-09-19 06:09:28 --> Input Class Initialized
INFO - 2025-09-19 06:09:28 --> Language Class Initialized
INFO - 2025-09-19 06:09:28 --> Loader Class Initialized
INFO - 2025-09-19 06:09:28 --> Helper loaded: url_helper
INFO - 2025-09-19 06:09:28 --> Helper loaded: text_helper
INFO - 2025-09-19 06:09:28 --> Helper loaded: string_helper
INFO - 2025-09-19 06:09:28 --> Helper loaded: form_helper
INFO - 2025-09-19 06:09:28 --> Helper loaded: download_helper
INFO - 2025-09-19 06:09:28 --> Helper loaded: security_helper
INFO - 2025-09-19 06:09:28 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 06:09:28 --> Database Driver Class Initialized
DEBUG - 2025-09-19 06:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 06:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 06:09:28 --> Form Validation Class Initialized
INFO - 2025-09-19 06:09:28 --> Model "User_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Nav_model" initialized
INFO - 2025-09-19 11:09:28 --> Controller Class Initialized
INFO - 2025-09-19 11:09:28 --> Model "Berita_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Galeri_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Video_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Agenda_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Tautan_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Mitra_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Prodi_model" initialized
INFO - 2025-09-19 11:09:28 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 11:09:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 11:09:28 --> Pagination Class Initialized
INFO - 2025-09-19 11:09:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 11:09:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 11:09:28 --> Model "Log_model" initialized
INFO - 2025-09-19 11:09:28 --> Final output sent to browser
DEBUG - 2025-09-19 11:09:28 --> Total execution time: 0.1025
INFO - 2025-09-19 06:09:42 --> Config Class Initialized
INFO - 2025-09-19 06:09:42 --> Hooks Class Initialized
DEBUG - 2025-09-19 06:09:42 --> UTF-8 Support Enabled
INFO - 2025-09-19 06:09:42 --> Utf8 Class Initialized
INFO - 2025-09-19 06:09:42 --> URI Class Initialized
DEBUG - 2025-09-19 06:09:42 --> No URI present. Default controller set.
INFO - 2025-09-19 06:09:42 --> Router Class Initialized
INFO - 2025-09-19 06:09:42 --> Output Class Initialized
INFO - 2025-09-19 06:09:42 --> Security Class Initialized
DEBUG - 2025-09-19 06:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 06:09:42 --> CSRF cookie sent
INFO - 2025-09-19 06:09:42 --> Input Class Initialized
INFO - 2025-09-19 06:09:42 --> Language Class Initialized
INFO - 2025-09-19 06:09:42 --> Loader Class Initialized
INFO - 2025-09-19 06:09:42 --> Helper loaded: url_helper
INFO - 2025-09-19 06:09:42 --> Helper loaded: text_helper
INFO - 2025-09-19 06:09:42 --> Helper loaded: string_helper
INFO - 2025-09-19 06:09:42 --> Helper loaded: form_helper
INFO - 2025-09-19 06:09:42 --> Helper loaded: download_helper
INFO - 2025-09-19 06:09:42 --> Helper loaded: security_helper
INFO - 2025-09-19 06:09:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 06:09:42 --> Database Driver Class Initialized
DEBUG - 2025-09-19 06:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 06:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 06:09:42 --> Form Validation Class Initialized
INFO - 2025-09-19 06:09:42 --> Model "User_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Nav_model" initialized
INFO - 2025-09-19 11:09:42 --> Controller Class Initialized
INFO - 2025-09-19 11:09:42 --> Model "Berita_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Galeri_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Video_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Agenda_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Tautan_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Mitra_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Prodi_model" initialized
INFO - 2025-09-19 11:09:42 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 11:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 11:09:42 --> Pagination Class Initialized
INFO - 2025-09-19 11:09:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 11:09:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 11:09:42 --> Model "Log_model" initialized
INFO - 2025-09-19 11:09:42 --> Final output sent to browser
DEBUG - 2025-09-19 11:09:42 --> Total execution time: 0.1176
INFO - 2025-09-19 06:09:44 --> Config Class Initialized
INFO - 2025-09-19 06:09:44 --> Hooks Class Initialized
DEBUG - 2025-09-19 06:09:44 --> UTF-8 Support Enabled
INFO - 2025-09-19 06:09:44 --> Utf8 Class Initialized
INFO - 2025-09-19 06:09:44 --> URI Class Initialized
DEBUG - 2025-09-19 06:09:44 --> No URI present. Default controller set.
INFO - 2025-09-19 06:09:44 --> Router Class Initialized
INFO - 2025-09-19 06:09:44 --> Output Class Initialized
INFO - 2025-09-19 06:09:44 --> Security Class Initialized
DEBUG - 2025-09-19 06:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 06:09:44 --> CSRF cookie sent
INFO - 2025-09-19 06:09:44 --> Input Class Initialized
INFO - 2025-09-19 06:09:44 --> Language Class Initialized
INFO - 2025-09-19 06:09:44 --> Loader Class Initialized
INFO - 2025-09-19 06:09:44 --> Helper loaded: url_helper
INFO - 2025-09-19 06:09:44 --> Helper loaded: text_helper
INFO - 2025-09-19 06:09:44 --> Helper loaded: string_helper
INFO - 2025-09-19 06:09:44 --> Helper loaded: form_helper
INFO - 2025-09-19 06:09:44 --> Helper loaded: download_helper
INFO - 2025-09-19 06:09:44 --> Helper loaded: security_helper
INFO - 2025-09-19 06:09:44 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 06:09:44 --> Database Driver Class Initialized
DEBUG - 2025-09-19 06:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 06:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 06:09:44 --> Form Validation Class Initialized
INFO - 2025-09-19 06:09:44 --> Model "User_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Nav_model" initialized
INFO - 2025-09-19 11:09:44 --> Controller Class Initialized
INFO - 2025-09-19 11:09:44 --> Model "Berita_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Galeri_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Video_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Agenda_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Tautan_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Mitra_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Prodi_model" initialized
INFO - 2025-09-19 11:09:44 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 11:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 11:09:44 --> Pagination Class Initialized
INFO - 2025-09-19 11:09:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 11:09:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 11:09:45 --> Model "Log_model" initialized
INFO - 2025-09-19 11:09:45 --> Final output sent to browser
DEBUG - 2025-09-19 11:09:45 --> Total execution time: 0.1191
INFO - 2025-09-19 06:16:27 --> Config Class Initialized
INFO - 2025-09-19 06:16:27 --> Hooks Class Initialized
DEBUG - 2025-09-19 06:16:27 --> UTF-8 Support Enabled
INFO - 2025-09-19 06:16:27 --> Utf8 Class Initialized
INFO - 2025-09-19 06:16:27 --> URI Class Initialized
DEBUG - 2025-09-19 06:16:27 --> No URI present. Default controller set.
INFO - 2025-09-19 06:16:27 --> Router Class Initialized
INFO - 2025-09-19 06:16:27 --> Output Class Initialized
INFO - 2025-09-19 06:16:27 --> Security Class Initialized
DEBUG - 2025-09-19 06:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 06:16:27 --> CSRF cookie sent
INFO - 2025-09-19 06:16:27 --> Input Class Initialized
INFO - 2025-09-19 06:16:27 --> Language Class Initialized
INFO - 2025-09-19 06:16:27 --> Loader Class Initialized
INFO - 2025-09-19 06:16:27 --> Helper loaded: url_helper
INFO - 2025-09-19 06:16:27 --> Helper loaded: text_helper
INFO - 2025-09-19 06:16:27 --> Helper loaded: string_helper
INFO - 2025-09-19 06:16:27 --> Helper loaded: form_helper
INFO - 2025-09-19 06:16:27 --> Helper loaded: download_helper
INFO - 2025-09-19 06:16:27 --> Helper loaded: security_helper
INFO - 2025-09-19 06:16:27 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 06:16:27 --> Database Driver Class Initialized
DEBUG - 2025-09-19 06:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 06:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 06:16:27 --> Form Validation Class Initialized
INFO - 2025-09-19 06:16:27 --> Model "User_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Nav_model" initialized
INFO - 2025-09-19 11:16:27 --> Controller Class Initialized
INFO - 2025-09-19 11:16:27 --> Model "Berita_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Galeri_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Video_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Agenda_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Tautan_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Mitra_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Prodi_model" initialized
INFO - 2025-09-19 11:16:27 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 11:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 11:16:27 --> Pagination Class Initialized
INFO - 2025-09-19 11:16:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 11:16:27 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 11:16:27 --> Model "Log_model" initialized
INFO - 2025-09-19 11:16:27 --> Final output sent to browser
DEBUG - 2025-09-19 11:16:27 --> Total execution time: 0.1101
INFO - 2025-09-19 08:34:42 --> Config Class Initialized
INFO - 2025-09-19 08:34:42 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:34:42 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:34:42 --> Utf8 Class Initialized
INFO - 2025-09-19 08:34:42 --> URI Class Initialized
DEBUG - 2025-09-19 08:34:42 --> No URI present. Default controller set.
INFO - 2025-09-19 08:34:42 --> Router Class Initialized
INFO - 2025-09-19 08:34:42 --> Output Class Initialized
INFO - 2025-09-19 08:34:42 --> Security Class Initialized
DEBUG - 2025-09-19 08:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:34:42 --> CSRF cookie sent
INFO - 2025-09-19 08:34:42 --> Input Class Initialized
INFO - 2025-09-19 08:34:42 --> Language Class Initialized
INFO - 2025-09-19 08:34:42 --> Loader Class Initialized
INFO - 2025-09-19 08:34:42 --> Helper loaded: url_helper
INFO - 2025-09-19 08:34:42 --> Helper loaded: text_helper
INFO - 2025-09-19 08:34:42 --> Helper loaded: string_helper
INFO - 2025-09-19 08:34:42 --> Helper loaded: form_helper
INFO - 2025-09-19 08:34:42 --> Helper loaded: download_helper
INFO - 2025-09-19 08:34:42 --> Helper loaded: security_helper
INFO - 2025-09-19 08:34:42 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:34:42 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:34:42 --> Form Validation Class Initialized
INFO - 2025-09-19 08:34:42 --> Model "User_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:34:42 --> Controller Class Initialized
INFO - 2025-09-19 13:34:42 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Video_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:34:42 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:34:42 --> Pagination Class Initialized
INFO - 2025-09-19 13:34:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:34:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:34:42 --> Model "Log_model" initialized
INFO - 2025-09-19 13:34:42 --> Final output sent to browser
DEBUG - 2025-09-19 13:34:42 --> Total execution time: 0.1262
INFO - 2025-09-19 08:37:24 --> Config Class Initialized
INFO - 2025-09-19 08:37:24 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:37:24 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:37:24 --> Utf8 Class Initialized
INFO - 2025-09-19 08:37:24 --> URI Class Initialized
DEBUG - 2025-09-19 08:37:24 --> No URI present. Default controller set.
INFO - 2025-09-19 08:37:24 --> Router Class Initialized
INFO - 2025-09-19 08:37:24 --> Output Class Initialized
INFO - 2025-09-19 08:37:24 --> Security Class Initialized
DEBUG - 2025-09-19 08:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:37:24 --> CSRF cookie sent
INFO - 2025-09-19 08:37:24 --> Input Class Initialized
INFO - 2025-09-19 08:37:24 --> Language Class Initialized
INFO - 2025-09-19 08:37:24 --> Loader Class Initialized
INFO - 2025-09-19 08:37:24 --> Helper loaded: url_helper
INFO - 2025-09-19 08:37:24 --> Helper loaded: text_helper
INFO - 2025-09-19 08:37:24 --> Helper loaded: string_helper
INFO - 2025-09-19 08:37:24 --> Helper loaded: form_helper
INFO - 2025-09-19 08:37:24 --> Helper loaded: download_helper
INFO - 2025-09-19 08:37:24 --> Helper loaded: security_helper
INFO - 2025-09-19 08:37:24 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:37:24 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:37:24 --> Form Validation Class Initialized
INFO - 2025-09-19 08:37:24 --> Model "User_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:37:24 --> Controller Class Initialized
INFO - 2025-09-19 13:37:24 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Video_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:37:24 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:37:24 --> Pagination Class Initialized
INFO - 2025-09-19 13:37:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:37:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:37:24 --> Model "Log_model" initialized
INFO - 2025-09-19 13:37:24 --> Final output sent to browser
DEBUG - 2025-09-19 13:37:24 --> Total execution time: 0.3186
INFO - 2025-09-19 08:37:37 --> Config Class Initialized
INFO - 2025-09-19 08:37:37 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:37:37 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:37:37 --> Utf8 Class Initialized
INFO - 2025-09-19 08:37:37 --> URI Class Initialized
DEBUG - 2025-09-19 08:37:37 --> No URI present. Default controller set.
INFO - 2025-09-19 08:37:37 --> Router Class Initialized
INFO - 2025-09-19 08:37:37 --> Output Class Initialized
INFO - 2025-09-19 08:37:37 --> Security Class Initialized
DEBUG - 2025-09-19 08:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:37:37 --> CSRF cookie sent
INFO - 2025-09-19 08:37:37 --> Input Class Initialized
INFO - 2025-09-19 08:37:37 --> Language Class Initialized
INFO - 2025-09-19 08:37:37 --> Loader Class Initialized
INFO - 2025-09-19 08:37:37 --> Helper loaded: url_helper
INFO - 2025-09-19 08:37:37 --> Helper loaded: text_helper
INFO - 2025-09-19 08:37:37 --> Helper loaded: string_helper
INFO - 2025-09-19 08:37:37 --> Helper loaded: form_helper
INFO - 2025-09-19 08:37:37 --> Helper loaded: download_helper
INFO - 2025-09-19 08:37:37 --> Helper loaded: security_helper
INFO - 2025-09-19 08:37:37 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:37:37 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:37:37 --> Form Validation Class Initialized
INFO - 2025-09-19 08:37:37 --> Model "User_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:37:37 --> Controller Class Initialized
INFO - 2025-09-19 13:37:37 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Video_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:37:37 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:37:37 --> Pagination Class Initialized
INFO - 2025-09-19 13:37:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:37:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:37:37 --> Model "Log_model" initialized
INFO - 2025-09-19 13:37:37 --> Final output sent to browser
DEBUG - 2025-09-19 13:37:37 --> Total execution time: 0.1363
INFO - 2025-09-19 08:37:52 --> Config Class Initialized
INFO - 2025-09-19 08:37:52 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:37:52 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:37:52 --> Utf8 Class Initialized
INFO - 2025-09-19 08:37:52 --> URI Class Initialized
DEBUG - 2025-09-19 08:37:52 --> No URI present. Default controller set.
INFO - 2025-09-19 08:37:52 --> Router Class Initialized
INFO - 2025-09-19 08:37:52 --> Output Class Initialized
INFO - 2025-09-19 08:37:52 --> Security Class Initialized
DEBUG - 2025-09-19 08:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:37:52 --> CSRF cookie sent
INFO - 2025-09-19 08:37:52 --> Input Class Initialized
INFO - 2025-09-19 08:37:52 --> Language Class Initialized
INFO - 2025-09-19 08:37:52 --> Loader Class Initialized
INFO - 2025-09-19 08:37:52 --> Helper loaded: url_helper
INFO - 2025-09-19 08:37:52 --> Helper loaded: text_helper
INFO - 2025-09-19 08:37:52 --> Helper loaded: string_helper
INFO - 2025-09-19 08:37:52 --> Helper loaded: form_helper
INFO - 2025-09-19 08:37:52 --> Helper loaded: download_helper
INFO - 2025-09-19 08:37:52 --> Helper loaded: security_helper
INFO - 2025-09-19 08:37:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:37:52 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:37:52 --> Form Validation Class Initialized
INFO - 2025-09-19 08:37:52 --> Model "User_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:37:52 --> Controller Class Initialized
INFO - 2025-09-19 13:37:52 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Video_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:37:52 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:37:52 --> Pagination Class Initialized
INFO - 2025-09-19 13:37:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:37:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:37:52 --> Model "Log_model" initialized
INFO - 2025-09-19 13:37:52 --> Final output sent to browser
DEBUG - 2025-09-19 13:37:52 --> Total execution time: 0.1168
INFO - 2025-09-19 08:37:55 --> Config Class Initialized
INFO - 2025-09-19 08:37:55 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:37:55 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:37:55 --> Utf8 Class Initialized
INFO - 2025-09-19 08:37:55 --> URI Class Initialized
DEBUG - 2025-09-19 08:37:55 --> No URI present. Default controller set.
INFO - 2025-09-19 08:37:55 --> Router Class Initialized
INFO - 2025-09-19 08:37:55 --> Output Class Initialized
INFO - 2025-09-19 08:37:55 --> Security Class Initialized
DEBUG - 2025-09-19 08:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:37:55 --> CSRF cookie sent
INFO - 2025-09-19 08:37:55 --> Input Class Initialized
INFO - 2025-09-19 08:37:55 --> Language Class Initialized
INFO - 2025-09-19 08:37:55 --> Loader Class Initialized
INFO - 2025-09-19 08:37:55 --> Helper loaded: url_helper
INFO - 2025-09-19 08:37:55 --> Helper loaded: text_helper
INFO - 2025-09-19 08:37:55 --> Helper loaded: string_helper
INFO - 2025-09-19 08:37:55 --> Helper loaded: form_helper
INFO - 2025-09-19 08:37:55 --> Helper loaded: download_helper
INFO - 2025-09-19 08:37:55 --> Helper loaded: security_helper
INFO - 2025-09-19 08:37:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:37:55 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:37:55 --> Form Validation Class Initialized
INFO - 2025-09-19 08:37:55 --> Model "User_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:37:55 --> Controller Class Initialized
INFO - 2025-09-19 13:37:55 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Video_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:37:55 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:37:55 --> Pagination Class Initialized
INFO - 2025-09-19 13:37:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:37:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:37:55 --> Model "Log_model" initialized
INFO - 2025-09-19 13:37:55 --> Final output sent to browser
DEBUG - 2025-09-19 13:37:55 --> Total execution time: 0.1308
INFO - 2025-09-19 08:38:03 --> Config Class Initialized
INFO - 2025-09-19 08:38:03 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:38:03 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:38:03 --> Utf8 Class Initialized
INFO - 2025-09-19 08:38:03 --> URI Class Initialized
DEBUG - 2025-09-19 08:38:03 --> No URI present. Default controller set.
INFO - 2025-09-19 08:38:03 --> Router Class Initialized
INFO - 2025-09-19 08:38:03 --> Output Class Initialized
INFO - 2025-09-19 08:38:03 --> Security Class Initialized
DEBUG - 2025-09-19 08:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:38:03 --> CSRF cookie sent
INFO - 2025-09-19 08:38:03 --> Input Class Initialized
INFO - 2025-09-19 08:38:03 --> Language Class Initialized
INFO - 2025-09-19 08:38:03 --> Loader Class Initialized
INFO - 2025-09-19 08:38:03 --> Helper loaded: url_helper
INFO - 2025-09-19 08:38:03 --> Helper loaded: text_helper
INFO - 2025-09-19 08:38:03 --> Helper loaded: string_helper
INFO - 2025-09-19 08:38:03 --> Helper loaded: form_helper
INFO - 2025-09-19 08:38:03 --> Helper loaded: download_helper
INFO - 2025-09-19 08:38:03 --> Helper loaded: security_helper
INFO - 2025-09-19 08:38:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:38:03 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:38:03 --> Form Validation Class Initialized
INFO - 2025-09-19 08:38:03 --> Model "User_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:38:03 --> Controller Class Initialized
INFO - 2025-09-19 13:38:03 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Video_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:38:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:38:03 --> Pagination Class Initialized
INFO - 2025-09-19 13:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:38:03 --> Model "Log_model" initialized
INFO - 2025-09-19 13:38:03 --> Final output sent to browser
DEBUG - 2025-09-19 13:38:03 --> Total execution time: 0.1297
INFO - 2025-09-19 08:38:18 --> Config Class Initialized
INFO - 2025-09-19 08:38:18 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:38:18 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:38:18 --> Utf8 Class Initialized
INFO - 2025-09-19 08:38:18 --> URI Class Initialized
DEBUG - 2025-09-19 08:38:18 --> No URI present. Default controller set.
INFO - 2025-09-19 08:38:18 --> Router Class Initialized
INFO - 2025-09-19 08:38:18 --> Output Class Initialized
INFO - 2025-09-19 08:38:18 --> Security Class Initialized
DEBUG - 2025-09-19 08:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:38:18 --> CSRF cookie sent
INFO - 2025-09-19 08:38:18 --> Input Class Initialized
INFO - 2025-09-19 08:38:18 --> Language Class Initialized
INFO - 2025-09-19 08:38:18 --> Loader Class Initialized
INFO - 2025-09-19 08:38:18 --> Helper loaded: url_helper
INFO - 2025-09-19 08:38:18 --> Helper loaded: text_helper
INFO - 2025-09-19 08:38:18 --> Helper loaded: string_helper
INFO - 2025-09-19 08:38:18 --> Helper loaded: form_helper
INFO - 2025-09-19 08:38:18 --> Helper loaded: download_helper
INFO - 2025-09-19 08:38:18 --> Helper loaded: security_helper
INFO - 2025-09-19 08:38:18 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:38:18 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:38:18 --> Form Validation Class Initialized
INFO - 2025-09-19 08:38:18 --> Model "User_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:38:18 --> Controller Class Initialized
INFO - 2025-09-19 13:38:18 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Video_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:38:18 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:38:18 --> Pagination Class Initialized
INFO - 2025-09-19 13:38:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:38:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:38:18 --> Model "Log_model" initialized
INFO - 2025-09-19 13:38:18 --> Final output sent to browser
DEBUG - 2025-09-19 13:38:18 --> Total execution time: 0.2235
INFO - 2025-09-19 08:38:21 --> Config Class Initialized
INFO - 2025-09-19 08:38:21 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:38:21 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:38:21 --> Utf8 Class Initialized
INFO - 2025-09-19 08:38:21 --> URI Class Initialized
DEBUG - 2025-09-19 08:38:21 --> No URI present. Default controller set.
INFO - 2025-09-19 08:38:21 --> Router Class Initialized
INFO - 2025-09-19 08:38:21 --> Output Class Initialized
INFO - 2025-09-19 08:38:21 --> Security Class Initialized
DEBUG - 2025-09-19 08:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:38:21 --> CSRF cookie sent
INFO - 2025-09-19 08:38:21 --> Input Class Initialized
INFO - 2025-09-19 08:38:21 --> Language Class Initialized
INFO - 2025-09-19 08:38:21 --> Loader Class Initialized
INFO - 2025-09-19 08:38:21 --> Helper loaded: url_helper
INFO - 2025-09-19 08:38:21 --> Helper loaded: text_helper
INFO - 2025-09-19 08:38:21 --> Helper loaded: string_helper
INFO - 2025-09-19 08:38:21 --> Helper loaded: form_helper
INFO - 2025-09-19 08:38:21 --> Helper loaded: download_helper
INFO - 2025-09-19 08:38:21 --> Helper loaded: security_helper
INFO - 2025-09-19 08:38:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:38:21 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:38:21 --> Form Validation Class Initialized
INFO - 2025-09-19 08:38:21 --> Model "User_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:38:21 --> Controller Class Initialized
INFO - 2025-09-19 13:38:21 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Video_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:38:21 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:38:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:38:21 --> Pagination Class Initialized
INFO - 2025-09-19 13:38:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:38:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:38:21 --> Model "Log_model" initialized
INFO - 2025-09-19 13:38:21 --> Final output sent to browser
DEBUG - 2025-09-19 13:38:21 --> Total execution time: 0.1363
INFO - 2025-09-19 08:38:31 --> Config Class Initialized
INFO - 2025-09-19 08:38:31 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:38:31 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:38:31 --> Utf8 Class Initialized
INFO - 2025-09-19 08:38:31 --> URI Class Initialized
DEBUG - 2025-09-19 08:38:31 --> No URI present. Default controller set.
INFO - 2025-09-19 08:38:31 --> Router Class Initialized
INFO - 2025-09-19 08:38:31 --> Output Class Initialized
INFO - 2025-09-19 08:38:31 --> Security Class Initialized
DEBUG - 2025-09-19 08:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:38:31 --> CSRF cookie sent
INFO - 2025-09-19 08:38:31 --> Input Class Initialized
INFO - 2025-09-19 08:38:31 --> Language Class Initialized
INFO - 2025-09-19 08:38:31 --> Loader Class Initialized
INFO - 2025-09-19 08:38:31 --> Helper loaded: url_helper
INFO - 2025-09-19 08:38:31 --> Helper loaded: text_helper
INFO - 2025-09-19 08:38:31 --> Helper loaded: string_helper
INFO - 2025-09-19 08:38:31 --> Helper loaded: form_helper
INFO - 2025-09-19 08:38:31 --> Helper loaded: download_helper
INFO - 2025-09-19 08:38:31 --> Helper loaded: security_helper
INFO - 2025-09-19 08:38:31 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:38:31 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:38:31 --> Form Validation Class Initialized
INFO - 2025-09-19 08:38:31 --> Model "User_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:38:31 --> Controller Class Initialized
INFO - 2025-09-19 13:38:31 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Video_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:38:31 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:38:31 --> Pagination Class Initialized
INFO - 2025-09-19 13:38:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:38:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:38:31 --> Model "Log_model" initialized
INFO - 2025-09-19 13:38:31 --> Final output sent to browser
DEBUG - 2025-09-19 13:38:31 --> Total execution time: 0.1569
INFO - 2025-09-19 08:38:46 --> Config Class Initialized
INFO - 2025-09-19 08:38:46 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:38:46 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:38:46 --> Utf8 Class Initialized
INFO - 2025-09-19 08:38:46 --> URI Class Initialized
DEBUG - 2025-09-19 08:38:46 --> No URI present. Default controller set.
INFO - 2025-09-19 08:38:46 --> Router Class Initialized
INFO - 2025-09-19 08:38:46 --> Output Class Initialized
INFO - 2025-09-19 08:38:46 --> Security Class Initialized
DEBUG - 2025-09-19 08:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:38:46 --> CSRF cookie sent
INFO - 2025-09-19 08:38:46 --> Input Class Initialized
INFO - 2025-09-19 08:38:46 --> Language Class Initialized
INFO - 2025-09-19 08:38:46 --> Loader Class Initialized
INFO - 2025-09-19 08:38:46 --> Helper loaded: url_helper
INFO - 2025-09-19 08:38:46 --> Helper loaded: text_helper
INFO - 2025-09-19 08:38:46 --> Helper loaded: string_helper
INFO - 2025-09-19 08:38:46 --> Helper loaded: form_helper
INFO - 2025-09-19 08:38:46 --> Helper loaded: download_helper
INFO - 2025-09-19 08:38:46 --> Helper loaded: security_helper
INFO - 2025-09-19 08:38:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:38:46 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:38:46 --> Form Validation Class Initialized
INFO - 2025-09-19 08:38:46 --> Model "User_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:38:46 --> Controller Class Initialized
INFO - 2025-09-19 13:38:46 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Video_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:38:46 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:38:46 --> Pagination Class Initialized
INFO - 2025-09-19 13:38:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:38:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:38:46 --> Model "Log_model" initialized
INFO - 2025-09-19 13:38:46 --> Final output sent to browser
DEBUG - 2025-09-19 13:38:46 --> Total execution time: 0.1285
INFO - 2025-09-19 08:38:49 --> Config Class Initialized
INFO - 2025-09-19 08:38:49 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:38:49 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:38:49 --> Utf8 Class Initialized
INFO - 2025-09-19 08:38:49 --> URI Class Initialized
DEBUG - 2025-09-19 08:38:49 --> No URI present. Default controller set.
INFO - 2025-09-19 08:38:49 --> Router Class Initialized
INFO - 2025-09-19 08:38:49 --> Output Class Initialized
INFO - 2025-09-19 08:38:49 --> Security Class Initialized
DEBUG - 2025-09-19 08:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:38:49 --> CSRF cookie sent
INFO - 2025-09-19 08:38:49 --> Input Class Initialized
INFO - 2025-09-19 08:38:49 --> Language Class Initialized
INFO - 2025-09-19 08:38:49 --> Loader Class Initialized
INFO - 2025-09-19 08:38:49 --> Helper loaded: url_helper
INFO - 2025-09-19 08:38:49 --> Helper loaded: text_helper
INFO - 2025-09-19 08:38:49 --> Helper loaded: string_helper
INFO - 2025-09-19 08:38:49 --> Helper loaded: form_helper
INFO - 2025-09-19 08:38:49 --> Helper loaded: download_helper
INFO - 2025-09-19 08:38:49 --> Helper loaded: security_helper
INFO - 2025-09-19 08:38:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:38:49 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:38:49 --> Form Validation Class Initialized
INFO - 2025-09-19 08:38:49 --> Model "User_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:38:49 --> Controller Class Initialized
INFO - 2025-09-19 13:38:49 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Video_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:38:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:38:49 --> Pagination Class Initialized
INFO - 2025-09-19 13:38:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:38:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:38:49 --> Model "Log_model" initialized
INFO - 2025-09-19 13:38:49 --> Final output sent to browser
DEBUG - 2025-09-19 13:38:49 --> Total execution time: 0.1395
INFO - 2025-09-19 08:41:14 --> Config Class Initialized
INFO - 2025-09-19 08:41:14 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:41:14 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:41:14 --> Utf8 Class Initialized
INFO - 2025-09-19 08:41:14 --> URI Class Initialized
DEBUG - 2025-09-19 08:41:14 --> No URI present. Default controller set.
INFO - 2025-09-19 08:41:14 --> Router Class Initialized
INFO - 2025-09-19 08:41:14 --> Output Class Initialized
INFO - 2025-09-19 08:41:14 --> Security Class Initialized
DEBUG - 2025-09-19 08:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:41:14 --> CSRF cookie sent
INFO - 2025-09-19 08:41:14 --> Input Class Initialized
INFO - 2025-09-19 08:41:14 --> Language Class Initialized
INFO - 2025-09-19 08:41:14 --> Loader Class Initialized
INFO - 2025-09-19 08:41:14 --> Helper loaded: url_helper
INFO - 2025-09-19 08:41:14 --> Helper loaded: text_helper
INFO - 2025-09-19 08:41:14 --> Helper loaded: string_helper
INFO - 2025-09-19 08:41:14 --> Helper loaded: form_helper
INFO - 2025-09-19 08:41:14 --> Helper loaded: download_helper
INFO - 2025-09-19 08:41:14 --> Helper loaded: security_helper
INFO - 2025-09-19 08:41:14 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:41:14 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:41:14 --> Form Validation Class Initialized
INFO - 2025-09-19 08:41:14 --> Model "User_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:41:14 --> Controller Class Initialized
INFO - 2025-09-19 13:41:14 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Video_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:41:14 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:41:14 --> Pagination Class Initialized
INFO - 2025-09-19 13:41:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:41:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:41:14 --> Model "Log_model" initialized
INFO - 2025-09-19 13:41:14 --> Final output sent to browser
DEBUG - 2025-09-19 13:41:14 --> Total execution time: 0.1279
INFO - 2025-09-19 08:41:32 --> Config Class Initialized
INFO - 2025-09-19 08:41:32 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:41:32 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:41:32 --> Utf8 Class Initialized
INFO - 2025-09-19 08:41:32 --> URI Class Initialized
DEBUG - 2025-09-19 08:41:32 --> No URI present. Default controller set.
INFO - 2025-09-19 08:41:32 --> Router Class Initialized
INFO - 2025-09-19 08:41:32 --> Output Class Initialized
INFO - 2025-09-19 08:41:32 --> Security Class Initialized
DEBUG - 2025-09-19 08:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:41:32 --> CSRF cookie sent
INFO - 2025-09-19 08:41:32 --> Input Class Initialized
INFO - 2025-09-19 08:41:32 --> Language Class Initialized
INFO - 2025-09-19 08:41:32 --> Loader Class Initialized
INFO - 2025-09-19 08:41:32 --> Helper loaded: url_helper
INFO - 2025-09-19 08:41:32 --> Helper loaded: text_helper
INFO - 2025-09-19 08:41:32 --> Helper loaded: string_helper
INFO - 2025-09-19 08:41:32 --> Helper loaded: form_helper
INFO - 2025-09-19 08:41:32 --> Helper loaded: download_helper
INFO - 2025-09-19 08:41:32 --> Helper loaded: security_helper
INFO - 2025-09-19 08:41:32 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:41:32 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:41:32 --> Form Validation Class Initialized
INFO - 2025-09-19 08:41:32 --> Model "User_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:41:32 --> Controller Class Initialized
INFO - 2025-09-19 13:41:32 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Video_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:41:32 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:41:32 --> Pagination Class Initialized
INFO - 2025-09-19 13:41:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:41:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:41:32 --> Model "Log_model" initialized
INFO - 2025-09-19 13:41:32 --> Final output sent to browser
DEBUG - 2025-09-19 13:41:32 --> Total execution time: 0.1260
INFO - 2025-09-19 08:41:45 --> Config Class Initialized
INFO - 2025-09-19 08:41:45 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:41:45 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:41:45 --> Utf8 Class Initialized
INFO - 2025-09-19 08:41:45 --> URI Class Initialized
DEBUG - 2025-09-19 08:41:45 --> No URI present. Default controller set.
INFO - 2025-09-19 08:41:45 --> Router Class Initialized
INFO - 2025-09-19 08:41:45 --> Output Class Initialized
INFO - 2025-09-19 08:41:45 --> Security Class Initialized
DEBUG - 2025-09-19 08:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:41:45 --> CSRF cookie sent
INFO - 2025-09-19 08:41:45 --> Input Class Initialized
INFO - 2025-09-19 08:41:45 --> Language Class Initialized
INFO - 2025-09-19 08:41:45 --> Loader Class Initialized
INFO - 2025-09-19 08:41:45 --> Helper loaded: url_helper
INFO - 2025-09-19 08:41:45 --> Helper loaded: text_helper
INFO - 2025-09-19 08:41:45 --> Helper loaded: string_helper
INFO - 2025-09-19 08:41:45 --> Helper loaded: form_helper
INFO - 2025-09-19 08:41:45 --> Helper loaded: download_helper
INFO - 2025-09-19 08:41:45 --> Helper loaded: security_helper
INFO - 2025-09-19 08:41:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:41:45 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:41:46 --> Form Validation Class Initialized
INFO - 2025-09-19 08:41:46 --> Model "User_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:41:46 --> Controller Class Initialized
INFO - 2025-09-19 13:41:46 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Video_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:41:46 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:41:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:41:46 --> Pagination Class Initialized
INFO - 2025-09-19 13:41:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:41:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:41:46 --> Model "Log_model" initialized
INFO - 2025-09-19 13:41:46 --> Final output sent to browser
DEBUG - 2025-09-19 13:41:46 --> Total execution time: 0.1516
INFO - 2025-09-19 08:41:53 --> Config Class Initialized
INFO - 2025-09-19 08:41:53 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:41:53 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:41:53 --> Utf8 Class Initialized
INFO - 2025-09-19 08:41:53 --> URI Class Initialized
DEBUG - 2025-09-19 08:41:53 --> No URI present. Default controller set.
INFO - 2025-09-19 08:41:53 --> Router Class Initialized
INFO - 2025-09-19 08:41:53 --> Output Class Initialized
INFO - 2025-09-19 08:41:53 --> Security Class Initialized
DEBUG - 2025-09-19 08:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:41:53 --> CSRF cookie sent
INFO - 2025-09-19 08:41:53 --> Input Class Initialized
INFO - 2025-09-19 08:41:53 --> Language Class Initialized
INFO - 2025-09-19 08:41:53 --> Loader Class Initialized
INFO - 2025-09-19 08:41:53 --> Helper loaded: url_helper
INFO - 2025-09-19 08:41:53 --> Helper loaded: text_helper
INFO - 2025-09-19 08:41:53 --> Helper loaded: string_helper
INFO - 2025-09-19 08:41:53 --> Helper loaded: form_helper
INFO - 2025-09-19 08:41:53 --> Helper loaded: download_helper
INFO - 2025-09-19 08:41:53 --> Helper loaded: security_helper
INFO - 2025-09-19 08:41:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:41:53 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:41:53 --> Form Validation Class Initialized
INFO - 2025-09-19 08:41:53 --> Model "User_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:41:53 --> Controller Class Initialized
INFO - 2025-09-19 13:41:53 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Video_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:41:53 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:41:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:41:53 --> Pagination Class Initialized
INFO - 2025-09-19 13:41:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:41:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:41:53 --> Model "Log_model" initialized
INFO - 2025-09-19 13:41:53 --> Final output sent to browser
DEBUG - 2025-09-19 13:41:53 --> Total execution time: 0.1026
INFO - 2025-09-19 08:42:10 --> Config Class Initialized
INFO - 2025-09-19 08:42:10 --> Hooks Class Initialized
DEBUG - 2025-09-19 08:42:10 --> UTF-8 Support Enabled
INFO - 2025-09-19 08:42:10 --> Utf8 Class Initialized
INFO - 2025-09-19 08:42:10 --> URI Class Initialized
DEBUG - 2025-09-19 08:42:10 --> No URI present. Default controller set.
INFO - 2025-09-19 08:42:10 --> Router Class Initialized
INFO - 2025-09-19 08:42:10 --> Output Class Initialized
INFO - 2025-09-19 08:42:10 --> Security Class Initialized
DEBUG - 2025-09-19 08:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-19 08:42:10 --> CSRF cookie sent
INFO - 2025-09-19 08:42:10 --> Input Class Initialized
INFO - 2025-09-19 08:42:10 --> Language Class Initialized
INFO - 2025-09-19 08:42:10 --> Loader Class Initialized
INFO - 2025-09-19 08:42:10 --> Helper loaded: url_helper
INFO - 2025-09-19 08:42:10 --> Helper loaded: text_helper
INFO - 2025-09-19 08:42:10 --> Helper loaded: string_helper
INFO - 2025-09-19 08:42:10 --> Helper loaded: form_helper
INFO - 2025-09-19 08:42:10 --> Helper loaded: download_helper
INFO - 2025-09-19 08:42:10 --> Helper loaded: security_helper
INFO - 2025-09-19 08:42:10 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-19 08:42:10 --> Database Driver Class Initialized
DEBUG - 2025-09-19 08:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-19 08:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-19 08:42:10 --> Form Validation Class Initialized
INFO - 2025-09-19 08:42:10 --> Model "User_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Nav_model" initialized
INFO - 2025-09-19 13:42:11 --> Controller Class Initialized
INFO - 2025-09-19 13:42:11 --> Model "Berita_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Galeri_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Video_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Agenda_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Tautan_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Mitra_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Prodi_model" initialized
INFO - 2025-09-19 13:42:11 --> Model "Testimoni_model" initialized
INFO - 2025-09-19 13:42:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-19 13:42:11 --> Pagination Class Initialized
INFO - 2025-09-19 13:42:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-19 13:42:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-19 13:42:11 --> Model "Log_model" initialized
INFO - 2025-09-19 13:42:11 --> Final output sent to browser
DEBUG - 2025-09-19 13:42:11 --> Total execution time: 0.1409
