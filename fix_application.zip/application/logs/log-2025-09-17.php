<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-09-17 03:42:08 --> Config Class Initialized
INFO - 2025-09-17 03:42:08 --> Hooks Class Initialized
DEBUG - 2025-09-17 03:42:09 --> UTF-8 Support Enabled
INFO - 2025-09-17 03:42:09 --> Utf8 Class Initialized
INFO - 2025-09-17 03:42:09 --> URI Class Initialized
DEBUG - 2025-09-17 03:42:09 --> No URI present. Default controller set.
INFO - 2025-09-17 03:42:09 --> Router Class Initialized
INFO - 2025-09-17 03:42:09 --> Output Class Initialized
INFO - 2025-09-17 03:42:09 --> Security Class Initialized
DEBUG - 2025-09-17 03:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 03:42:09 --> CSRF cookie sent
INFO - 2025-09-17 03:42:09 --> Input Class Initialized
INFO - 2025-09-17 03:42:09 --> Language Class Initialized
INFO - 2025-09-17 03:42:09 --> Loader Class Initialized
INFO - 2025-09-17 03:42:10 --> Helper loaded: url_helper
INFO - 2025-09-17 03:42:10 --> Helper loaded: text_helper
INFO - 2025-09-17 03:42:10 --> Helper loaded: string_helper
INFO - 2025-09-17 03:42:10 --> Helper loaded: form_helper
INFO - 2025-09-17 03:42:10 --> Helper loaded: download_helper
INFO - 2025-09-17 03:42:10 --> Helper loaded: security_helper
INFO - 2025-09-17 03:42:10 --> Database Driver Class Initialized
DEBUG - 2025-09-17 03:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 03:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 03:42:10 --> Form Validation Class Initialized
INFO - 2025-09-17 03:42:10 --> Model "User_model" initialized
INFO - 2025-09-17 08:42:10 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 08:42:10 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 08:42:10 --> Model "Nav_model" initialized
INFO - 2025-09-17 08:42:10 --> Controller Class Initialized
INFO - 2025-09-17 08:42:10 --> Model "Berita_model" initialized
INFO - 2025-09-17 08:42:10 --> Model "Galeri_model" initialized
INFO - 2025-09-17 08:42:11 --> Model "Video_model" initialized
INFO - 2025-09-17 08:42:11 --> Model "Agenda_model" initialized
INFO - 2025-09-17 08:42:11 --> Model "Tautan_model" initialized
INFO - 2025-09-17 08:42:11 --> Model "Mitra_model" initialized
INFO - 2025-09-17 08:42:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 08:42:11 --> Model "Prodi_model" initialized
INFO - 2025-09-17 08:42:11 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 08:42:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 08:42:11 --> Pagination Class Initialized
INFO - 2025-09-17 08:42:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 08:42:13 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 08:42:13 --> Model "Log_model" initialized
INFO - 2025-09-17 08:42:13 --> Final output sent to browser
DEBUG - 2025-09-17 08:42:13 --> Total execution time: 4.5154
INFO - 2025-09-17 03:42:20 --> Config Class Initialized
INFO - 2025-09-17 03:42:20 --> Hooks Class Initialized
DEBUG - 2025-09-17 03:42:20 --> UTF-8 Support Enabled
INFO - 2025-09-17 03:42:20 --> Utf8 Class Initialized
INFO - 2025-09-17 03:42:20 --> URI Class Initialized
DEBUG - 2025-09-17 03:42:20 --> No URI present. Default controller set.
INFO - 2025-09-17 03:42:20 --> Router Class Initialized
INFO - 2025-09-17 03:42:20 --> Output Class Initialized
INFO - 2025-09-17 03:42:20 --> Security Class Initialized
DEBUG - 2025-09-17 03:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 03:42:20 --> CSRF cookie sent
INFO - 2025-09-17 03:42:20 --> Input Class Initialized
INFO - 2025-09-17 03:42:20 --> Language Class Initialized
INFO - 2025-09-17 03:42:20 --> Loader Class Initialized
INFO - 2025-09-17 03:42:20 --> Helper loaded: url_helper
INFO - 2025-09-17 03:42:20 --> Helper loaded: text_helper
INFO - 2025-09-17 03:42:20 --> Helper loaded: string_helper
INFO - 2025-09-17 03:42:20 --> Helper loaded: form_helper
INFO - 2025-09-17 03:42:20 --> Helper loaded: download_helper
INFO - 2025-09-17 03:42:20 --> Helper loaded: security_helper
INFO - 2025-09-17 03:42:20 --> Database Driver Class Initialized
DEBUG - 2025-09-17 03:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 03:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 03:42:20 --> Form Validation Class Initialized
INFO - 2025-09-17 03:42:20 --> Model "User_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Nav_model" initialized
INFO - 2025-09-17 08:42:20 --> Controller Class Initialized
INFO - 2025-09-17 08:42:20 --> Model "Berita_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Galeri_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Video_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Agenda_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Tautan_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Mitra_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Prodi_model" initialized
INFO - 2025-09-17 08:42:20 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 08:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 08:42:21 --> Pagination Class Initialized
INFO - 2025-09-17 08:42:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 08:42:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 08:42:21 --> Model "Log_model" initialized
INFO - 2025-09-17 08:42:21 --> Final output sent to browser
DEBUG - 2025-09-17 08:42:21 --> Total execution time: 0.1776
INFO - 2025-09-17 03:42:39 --> Config Class Initialized
INFO - 2025-09-17 03:42:39 --> Hooks Class Initialized
INFO - 2025-09-17 03:42:39 --> Config Class Initialized
INFO - 2025-09-17 03:42:39 --> Hooks Class Initialized
INFO - 2025-09-17 03:42:39 --> Config Class Initialized
INFO - 2025-09-17 03:42:39 --> Hooks Class Initialized
INFO - 2025-09-17 03:42:39 --> Config Class Initialized
INFO - 2025-09-17 03:42:39 --> Hooks Class Initialized
DEBUG - 2025-09-17 03:42:39 --> UTF-8 Support Enabled
INFO - 2025-09-17 03:42:39 --> Utf8 Class Initialized
INFO - 2025-09-17 03:42:39 --> URI Class Initialized
DEBUG - 2025-09-17 03:42:39 --> UTF-8 Support Enabled
INFO - 2025-09-17 03:42:39 --> Utf8 Class Initialized
DEBUG - 2025-09-17 03:42:39 --> UTF-8 Support Enabled
INFO - 2025-09-17 03:42:39 --> Utf8 Class Initialized
DEBUG - 2025-09-17 03:42:39 --> UTF-8 Support Enabled
INFO - 2025-09-17 03:42:39 --> Utf8 Class Initialized
INFO - 2025-09-17 03:42:39 --> Router Class Initialized
INFO - 2025-09-17 03:42:39 --> URI Class Initialized
INFO - 2025-09-17 03:42:39 --> URI Class Initialized
INFO - 2025-09-17 03:42:39 --> URI Class Initialized
INFO - 2025-09-17 03:42:39 --> Output Class Initialized
INFO - 2025-09-17 03:42:39 --> Router Class Initialized
INFO - 2025-09-17 03:42:39 --> Router Class Initialized
INFO - 2025-09-17 03:42:39 --> Router Class Initialized
INFO - 2025-09-17 03:42:39 --> Security Class Initialized
INFO - 2025-09-17 03:42:39 --> Output Class Initialized
INFO - 2025-09-17 03:42:39 --> Output Class Initialized
INFO - 2025-09-17 03:42:39 --> Output Class Initialized
DEBUG - 2025-09-17 03:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 03:42:39 --> CSRF cookie sent
INFO - 2025-09-17 03:42:39 --> Input Class Initialized
INFO - 2025-09-17 03:42:39 --> Security Class Initialized
INFO - 2025-09-17 03:42:39 --> Language Class Initialized
INFO - 2025-09-17 03:42:39 --> Security Class Initialized
INFO - 2025-09-17 03:42:39 --> Security Class Initialized
DEBUG - 2025-09-17 03:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 03:42:39 --> CSRF cookie sent
INFO - 2025-09-17 03:42:39 --> Input Class Initialized
DEBUG - 2025-09-17 03:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 03:42:39 --> CSRF cookie sent
DEBUG - 2025-09-17 03:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 03:42:39 --> Input Class Initialized
INFO - 2025-09-17 03:42:39 --> CSRF cookie sent
INFO - 2025-09-17 03:42:39 --> Language Class Initialized
INFO - 2025-09-17 03:42:39 --> Input Class Initialized
INFO - 2025-09-17 03:42:39 --> Loader Class Initialized
INFO - 2025-09-17 03:42:39 --> Language Class Initialized
INFO - 2025-09-17 03:42:39 --> Language Class Initialized
INFO - 2025-09-17 03:42:39 --> Helper loaded: url_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: text_helper
INFO - 2025-09-17 03:42:39 --> Loader Class Initialized
INFO - 2025-09-17 03:42:39 --> Helper loaded: string_helper
INFO - 2025-09-17 03:42:39 --> Loader Class Initialized
INFO - 2025-09-17 03:42:39 --> Loader Class Initialized
INFO - 2025-09-17 03:42:39 --> Helper loaded: form_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: url_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: url_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: url_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: download_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: text_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: text_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: text_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: security_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: string_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: string_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: string_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: form_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: form_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: form_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: download_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: download_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: download_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: security_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: security_helper
INFO - 2025-09-17 03:42:39 --> Helper loaded: security_helper
INFO - 2025-09-17 03:42:39 --> Database Driver Class Initialized
INFO - 2025-09-17 03:42:39 --> Database Driver Class Initialized
INFO - 2025-09-17 03:42:39 --> Database Driver Class Initialized
INFO - 2025-09-17 03:42:39 --> Database Driver Class Initialized
DEBUG - 2025-09-17 03:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-17 03:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 03:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 03:42:39 --> Form Validation Class Initialized
INFO - 2025-09-17 03:42:39 --> Model "User_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Kunjungan_model" initialized
DEBUG - 2025-09-17 03:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-17 03:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 08:42:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Nav_model" initialized
INFO - 2025-09-17 08:42:39 --> Controller Class Initialized
INFO - 2025-09-17 08:42:39 --> Model "Berita_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Galeri_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Video_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Agenda_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Tautan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Mitra_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Prodi_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 08:42:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 08:42:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 08:42:39 --> Model "Log_model" initialized
INFO - 2025-09-17 08:42:39 --> Final output sent to browser
DEBUG - 2025-09-17 08:42:39 --> Total execution time: 0.2134
INFO - 2025-09-17 03:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 03:42:39 --> Form Validation Class Initialized
INFO - 2025-09-17 03:42:39 --> Model "User_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Nav_model" initialized
INFO - 2025-09-17 08:42:39 --> Controller Class Initialized
INFO - 2025-09-17 08:42:39 --> Model "Berita_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Galeri_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Video_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Agenda_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Tautan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Mitra_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Prodi_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 08:42:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 08:42:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 08:42:39 --> Model "Log_model" initialized
INFO - 2025-09-17 08:42:39 --> Final output sent to browser
DEBUG - 2025-09-17 08:42:39 --> Total execution time: 0.2952
INFO - 2025-09-17 03:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 03:42:39 --> Form Validation Class Initialized
INFO - 2025-09-17 03:42:39 --> Model "User_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Nav_model" initialized
INFO - 2025-09-17 08:42:39 --> Controller Class Initialized
INFO - 2025-09-17 08:42:39 --> Model "Berita_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Galeri_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Video_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Agenda_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Tautan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Mitra_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Prodi_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 08:42:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 08:42:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 08:42:39 --> Model "Log_model" initialized
INFO - 2025-09-17 08:42:39 --> Final output sent to browser
DEBUG - 2025-09-17 08:42:39 --> Total execution time: 0.3631
INFO - 2025-09-17 03:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 03:42:39 --> Form Validation Class Initialized
INFO - 2025-09-17 03:42:39 --> Model "User_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Nav_model" initialized
INFO - 2025-09-17 08:42:39 --> Controller Class Initialized
INFO - 2025-09-17 08:42:39 --> Model "Berita_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Galeri_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Video_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Agenda_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Tautan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Mitra_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Prodi_model" initialized
INFO - 2025-09-17 08:42:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 08:42:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 08:42:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 08:42:39 --> Model "Log_model" initialized
INFO - 2025-09-17 08:42:39 --> Final output sent to browser
DEBUG - 2025-09-17 08:42:39 --> Total execution time: 0.4373
INFO - 2025-09-17 05:51:32 --> Config Class Initialized
INFO - 2025-09-17 05:51:32 --> Hooks Class Initialized
DEBUG - 2025-09-17 05:51:33 --> UTF-8 Support Enabled
INFO - 2025-09-17 05:51:33 --> Utf8 Class Initialized
INFO - 2025-09-17 05:51:33 --> URI Class Initialized
DEBUG - 2025-09-17 05:51:33 --> No URI present. Default controller set.
INFO - 2025-09-17 05:51:33 --> Router Class Initialized
INFO - 2025-09-17 05:51:33 --> Output Class Initialized
INFO - 2025-09-17 05:51:33 --> Security Class Initialized
DEBUG - 2025-09-17 05:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 05:51:33 --> CSRF cookie sent
INFO - 2025-09-17 05:51:33 --> Input Class Initialized
INFO - 2025-09-17 05:51:33 --> Language Class Initialized
INFO - 2025-09-17 05:51:34 --> Loader Class Initialized
INFO - 2025-09-17 05:51:34 --> Helper loaded: url_helper
INFO - 2025-09-17 05:51:34 --> Helper loaded: text_helper
INFO - 2025-09-17 05:51:34 --> Helper loaded: string_helper
INFO - 2025-09-17 05:51:34 --> Helper loaded: form_helper
INFO - 2025-09-17 05:51:34 --> Helper loaded: download_helper
INFO - 2025-09-17 05:51:34 --> Helper loaded: security_helper
INFO - 2025-09-17 05:51:34 --> Database Driver Class Initialized
ERROR - 2025-09-17 05:51:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 05:51:35 --> Unable to connect to the database
DEBUG - 2025-09-17 05:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 05:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 05:51:35 --> Form Validation Class Initialized
INFO - 2025-09-17 05:51:35 --> Database Driver Class Initialized
ERROR - 2025-09-17 05:51:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 05:51:35 --> Unable to connect to the database
INFO - 2025-09-17 05:51:35 --> Model "User_model" initialized
INFO - 2025-09-17 10:51:35 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 10:51:35 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
INFO - 2025-09-17 10:51:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 10:51:36 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
INFO - 2025-09-17 10:51:36 --> Model "Nav_model" initialized
INFO - 2025-09-17 10:51:36 --> Controller Class Initialized
INFO - 2025-09-17 10:51:36 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
INFO - 2025-09-17 10:51:36 --> Model "Berita_model" initialized
INFO - 2025-09-17 10:51:36 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
INFO - 2025-09-17 10:51:36 --> Model "Galeri_model" initialized
INFO - 2025-09-17 10:51:36 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
INFO - 2025-09-17 10:51:36 --> Model "Video_model" initialized
INFO - 2025-09-17 10:51:36 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
INFO - 2025-09-17 10:51:36 --> Model "Agenda_model" initialized
INFO - 2025-09-17 10:51:36 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
INFO - 2025-09-17 10:51:36 --> Model "Tautan_model" initialized
INFO - 2025-09-17 10:51:36 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
INFO - 2025-09-17 10:51:36 --> Model "Mitra_model" initialized
INFO - 2025-09-17 10:51:36 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
INFO - 2025-09-17 10:51:36 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 10:51:36 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
INFO - 2025-09-17 10:51:36 --> Model "Prodi_model" initialized
INFO - 2025-09-17 10:51:36 --> Model "Testimoni_model" initialized
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:36 --> Unable to connect to the database
ERROR - 2025-09-17 10:51:36 --> Query error: Unknown database 'db_jkt3' - Invalid query: SELECT *
FROM `konfigurasi`
ORDER BY `id_konfigurasi` DESC
ERROR - 2025-09-17 10:51:36 --> Severity: error --> Exception: Call to a member function row() on bool D:\xampp\htdocs\dev_jkt3\application\models\Konfigurasi_model.php 16
ERROR - 2025-09-17 10:51:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\dev_jkt3\system\core\Exceptions.php:272) D:\xampp\htdocs\dev_jkt3\system\core\Common.php 571
INFO - 2025-09-17 05:51:38 --> Config Class Initialized
INFO - 2025-09-17 05:51:38 --> Hooks Class Initialized
DEBUG - 2025-09-17 05:51:38 --> UTF-8 Support Enabled
INFO - 2025-09-17 05:51:38 --> Utf8 Class Initialized
INFO - 2025-09-17 05:51:38 --> URI Class Initialized
DEBUG - 2025-09-17 05:51:38 --> No URI present. Default controller set.
INFO - 2025-09-17 05:51:38 --> Router Class Initialized
INFO - 2025-09-17 05:51:38 --> Output Class Initialized
INFO - 2025-09-17 05:51:38 --> Security Class Initialized
DEBUG - 2025-09-17 05:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 05:51:38 --> CSRF cookie sent
INFO - 2025-09-17 05:51:38 --> Input Class Initialized
INFO - 2025-09-17 05:51:38 --> Language Class Initialized
INFO - 2025-09-17 05:51:38 --> Loader Class Initialized
INFO - 2025-09-17 05:51:38 --> Helper loaded: url_helper
INFO - 2025-09-17 05:51:38 --> Helper loaded: text_helper
INFO - 2025-09-17 05:51:38 --> Helper loaded: string_helper
INFO - 2025-09-17 05:51:38 --> Helper loaded: form_helper
INFO - 2025-09-17 05:51:38 --> Helper loaded: download_helper
INFO - 2025-09-17 05:51:38 --> Helper loaded: security_helper
INFO - 2025-09-17 05:51:38 --> Database Driver Class Initialized
ERROR - 2025-09-17 05:51:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 05:51:38 --> Unable to connect to the database
DEBUG - 2025-09-17 05:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 05:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 05:51:38 --> Form Validation Class Initialized
INFO - 2025-09-17 05:51:38 --> Database Driver Class Initialized
ERROR - 2025-09-17 05:51:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 05:51:38 --> Unable to connect to the database
INFO - 2025-09-17 05:51:38 --> Model "User_model" initialized
INFO - 2025-09-17 10:51:38 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 10:51:38 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:38 --> Unable to connect to the database
INFO - 2025-09-17 10:51:38 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 10:51:38 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:38 --> Unable to connect to the database
INFO - 2025-09-17 10:51:38 --> Model "Nav_model" initialized
INFO - 2025-09-17 10:51:38 --> Controller Class Initialized
INFO - 2025-09-17 10:51:38 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:38 --> Unable to connect to the database
INFO - 2025-09-17 10:51:38 --> Model "Berita_model" initialized
INFO - 2025-09-17 10:51:38 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:38 --> Unable to connect to the database
INFO - 2025-09-17 10:51:38 --> Model "Galeri_model" initialized
INFO - 2025-09-17 10:51:38 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:39 --> Unable to connect to the database
INFO - 2025-09-17 10:51:39 --> Model "Video_model" initialized
INFO - 2025-09-17 10:51:39 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:39 --> Unable to connect to the database
INFO - 2025-09-17 10:51:39 --> Model "Agenda_model" initialized
INFO - 2025-09-17 10:51:39 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:39 --> Unable to connect to the database
INFO - 2025-09-17 10:51:39 --> Model "Tautan_model" initialized
INFO - 2025-09-17 10:51:39 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:39 --> Unable to connect to the database
INFO - 2025-09-17 10:51:39 --> Model "Mitra_model" initialized
INFO - 2025-09-17 10:51:39 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:39 --> Unable to connect to the database
INFO - 2025-09-17 10:51:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 10:51:39 --> Database Driver Class Initialized
ERROR - 2025-09-17 10:51:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:39 --> Unable to connect to the database
INFO - 2025-09-17 10:51:39 --> Model "Prodi_model" initialized
INFO - 2025-09-17 10:51:39 --> Model "Testimoni_model" initialized
ERROR - 2025-09-17 10:51:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_jkt3' D:\xampp\htdocs\dev_jkt3\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 10:51:39 --> Unable to connect to the database
ERROR - 2025-09-17 10:51:39 --> Query error: Unknown database 'db_jkt3' - Invalid query: SELECT *
FROM `konfigurasi`
ORDER BY `id_konfigurasi` DESC
ERROR - 2025-09-17 10:51:39 --> Severity: error --> Exception: Call to a member function row() on bool D:\xampp\htdocs\dev_jkt3\application\models\Konfigurasi_model.php 16
ERROR - 2025-09-17 10:51:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\dev_jkt3\system\core\Exceptions.php:272) D:\xampp\htdocs\dev_jkt3\system\core\Common.php 571
INFO - 2025-09-17 05:51:54 --> Config Class Initialized
INFO - 2025-09-17 05:51:54 --> Hooks Class Initialized
DEBUG - 2025-09-17 05:51:54 --> UTF-8 Support Enabled
INFO - 2025-09-17 05:51:54 --> Utf8 Class Initialized
INFO - 2025-09-17 05:51:54 --> URI Class Initialized
DEBUG - 2025-09-17 05:51:54 --> No URI present. Default controller set.
INFO - 2025-09-17 05:51:54 --> Router Class Initialized
INFO - 2025-09-17 05:51:54 --> Output Class Initialized
INFO - 2025-09-17 05:51:54 --> Security Class Initialized
DEBUG - 2025-09-17 05:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 05:51:54 --> CSRF cookie sent
INFO - 2025-09-17 05:51:54 --> Input Class Initialized
INFO - 2025-09-17 05:51:54 --> Language Class Initialized
INFO - 2025-09-17 05:51:54 --> Loader Class Initialized
INFO - 2025-09-17 05:51:54 --> Helper loaded: url_helper
INFO - 2025-09-17 05:51:54 --> Helper loaded: text_helper
INFO - 2025-09-17 05:51:54 --> Helper loaded: string_helper
INFO - 2025-09-17 05:51:54 --> Helper loaded: form_helper
INFO - 2025-09-17 05:51:54 --> Helper loaded: download_helper
INFO - 2025-09-17 05:51:54 --> Helper loaded: security_helper
INFO - 2025-09-17 05:51:54 --> Database Driver Class Initialized
DEBUG - 2025-09-17 05:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 05:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 05:51:54 --> Form Validation Class Initialized
INFO - 2025-09-17 05:51:54 --> Model "User_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Nav_model" initialized
INFO - 2025-09-17 10:51:54 --> Controller Class Initialized
INFO - 2025-09-17 10:51:54 --> Model "Berita_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Galeri_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Video_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Agenda_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Tautan_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Mitra_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Prodi_model" initialized
INFO - 2025-09-17 10:51:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 10:51:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 10:51:55 --> Pagination Class Initialized
INFO - 2025-09-17 10:51:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 10:51:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 10:51:57 --> Model "Log_model" initialized
INFO - 2025-09-17 10:51:57 --> Final output sent to browser
DEBUG - 2025-09-17 10:51:57 --> Total execution time: 2.2913
INFO - 2025-09-17 05:52:03 --> Config Class Initialized
INFO - 2025-09-17 05:52:03 --> Hooks Class Initialized
INFO - 2025-09-17 05:52:03 --> Config Class Initialized
INFO - 2025-09-17 05:52:03 --> Hooks Class Initialized
INFO - 2025-09-17 05:52:03 --> Config Class Initialized
INFO - 2025-09-17 05:52:03 --> Config Class Initialized
INFO - 2025-09-17 05:52:03 --> Hooks Class Initialized
INFO - 2025-09-17 05:52:03 --> Hooks Class Initialized
DEBUG - 2025-09-17 05:52:03 --> UTF-8 Support Enabled
INFO - 2025-09-17 05:52:03 --> Utf8 Class Initialized
INFO - 2025-09-17 05:52:03 --> URI Class Initialized
DEBUG - 2025-09-17 05:52:03 --> UTF-8 Support Enabled
INFO - 2025-09-17 05:52:03 --> Utf8 Class Initialized
DEBUG - 2025-09-17 05:52:03 --> UTF-8 Support Enabled
INFO - 2025-09-17 05:52:03 --> Utf8 Class Initialized
DEBUG - 2025-09-17 05:52:03 --> UTF-8 Support Enabled
INFO - 2025-09-17 05:52:03 --> URI Class Initialized
INFO - 2025-09-17 05:52:03 --> Utf8 Class Initialized
INFO - 2025-09-17 05:52:03 --> Router Class Initialized
INFO - 2025-09-17 05:52:03 --> URI Class Initialized
INFO - 2025-09-17 05:52:03 --> URI Class Initialized
INFO - 2025-09-17 05:52:03 --> Output Class Initialized
INFO - 2025-09-17 05:52:03 --> Router Class Initialized
INFO - 2025-09-17 05:52:03 --> Router Class Initialized
INFO - 2025-09-17 05:52:03 --> Router Class Initialized
INFO - 2025-09-17 05:52:03 --> Security Class Initialized
INFO - 2025-09-17 05:52:03 --> Output Class Initialized
INFO - 2025-09-17 05:52:03 --> Output Class Initialized
INFO - 2025-09-17 05:52:03 --> Output Class Initialized
INFO - 2025-09-17 05:52:03 --> Security Class Initialized
DEBUG - 2025-09-17 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 05:52:03 --> Security Class Initialized
INFO - 2025-09-17 05:52:03 --> CSRF cookie sent
INFO - 2025-09-17 05:52:03 --> Input Class Initialized
INFO - 2025-09-17 05:52:03 --> Security Class Initialized
DEBUG - 2025-09-17 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 05:52:03 --> Language Class Initialized
INFO - 2025-09-17 05:52:03 --> CSRF cookie sent
INFO - 2025-09-17 05:52:03 --> Input Class Initialized
DEBUG - 2025-09-17 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 05:52:03 --> CSRF cookie sent
INFO - 2025-09-17 05:52:03 --> Input Class Initialized
DEBUG - 2025-09-17 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 05:52:03 --> Language Class Initialized
INFO - 2025-09-17 05:52:03 --> CSRF cookie sent
INFO - 2025-09-17 05:52:03 --> Input Class Initialized
INFO - 2025-09-17 05:52:03 --> Language Class Initialized
INFO - 2025-09-17 05:52:03 --> Language Class Initialized
INFO - 2025-09-17 05:52:03 --> Loader Class Initialized
INFO - 2025-09-17 05:52:03 --> Loader Class Initialized
INFO - 2025-09-17 05:52:03 --> Helper loaded: url_helper
INFO - 2025-09-17 05:52:03 --> Loader Class Initialized
INFO - 2025-09-17 05:52:03 --> Helper loaded: url_helper
INFO - 2025-09-17 05:52:03 --> Loader Class Initialized
INFO - 2025-09-17 05:52:03 --> Helper loaded: text_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: url_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: text_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: string_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: url_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: string_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: text_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: form_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: text_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: string_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: form_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: download_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: string_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: download_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: security_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: form_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: form_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: download_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: security_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: security_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: download_helper
INFO - 2025-09-17 05:52:03 --> Helper loaded: security_helper
INFO - 2025-09-17 05:52:03 --> Database Driver Class Initialized
INFO - 2025-09-17 05:52:03 --> Database Driver Class Initialized
INFO - 2025-09-17 05:52:03 --> Database Driver Class Initialized
INFO - 2025-09-17 05:52:03 --> Database Driver Class Initialized
DEBUG - 2025-09-17 05:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-17 05:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 05:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 05:52:03 --> Form Validation Class Initialized
DEBUG - 2025-09-17 05:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 05:52:03 --> Model "User_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Nav_model" initialized
INFO - 2025-09-17 10:52:03 --> Controller Class Initialized
INFO - 2025-09-17 10:52:03 --> Model "Berita_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Galeri_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Video_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Agenda_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Tautan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Mitra_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Prodi_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Testimoni_model" initialized
DEBUG - 2025-09-17 05:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 10:52:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 10:52:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 10:52:03 --> Model "Log_model" initialized
INFO - 2025-09-17 10:52:03 --> Final output sent to browser
DEBUG - 2025-09-17 10:52:03 --> Total execution time: 0.1792
INFO - 2025-09-17 05:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 05:52:03 --> Form Validation Class Initialized
INFO - 2025-09-17 05:52:03 --> Model "User_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Nav_model" initialized
INFO - 2025-09-17 10:52:03 --> Controller Class Initialized
INFO - 2025-09-17 10:52:03 --> Model "Berita_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Galeri_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Video_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Agenda_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Tautan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Mitra_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Prodi_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 10:52:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 10:52:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 10:52:03 --> Model "Log_model" initialized
INFO - 2025-09-17 10:52:03 --> Final output sent to browser
DEBUG - 2025-09-17 10:52:03 --> Total execution time: 0.2148
INFO - 2025-09-17 05:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 05:52:03 --> Form Validation Class Initialized
INFO - 2025-09-17 05:52:03 --> Model "User_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Nav_model" initialized
INFO - 2025-09-17 10:52:03 --> Controller Class Initialized
INFO - 2025-09-17 10:52:03 --> Model "Berita_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Galeri_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Video_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Agenda_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Tautan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Mitra_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Prodi_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 10:52:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 10:52:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 10:52:03 --> Model "Log_model" initialized
INFO - 2025-09-17 10:52:03 --> Final output sent to browser
DEBUG - 2025-09-17 10:52:03 --> Total execution time: 0.2555
INFO - 2025-09-17 05:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 05:52:03 --> Form Validation Class Initialized
INFO - 2025-09-17 05:52:03 --> Model "User_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Nav_model" initialized
INFO - 2025-09-17 10:52:03 --> Controller Class Initialized
INFO - 2025-09-17 10:52:03 --> Model "Berita_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Galeri_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Video_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Agenda_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Tautan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Mitra_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Prodi_model" initialized
INFO - 2025-09-17 10:52:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 10:52:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 10:52:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 10:52:03 --> Model "Log_model" initialized
INFO - 2025-09-17 10:52:03 --> Final output sent to browser
DEBUG - 2025-09-17 10:52:03 --> Total execution time: 0.3056
INFO - 2025-09-17 07:52:46 --> Config Class Initialized
INFO - 2025-09-17 07:52:46 --> Hooks Class Initialized
DEBUG - 2025-09-17 07:52:46 --> UTF-8 Support Enabled
INFO - 2025-09-17 07:52:46 --> Utf8 Class Initialized
INFO - 2025-09-17 07:52:46 --> URI Class Initialized
INFO - 2025-09-17 07:52:46 --> Router Class Initialized
INFO - 2025-09-17 07:52:46 --> Output Class Initialized
INFO - 2025-09-17 07:52:46 --> Security Class Initialized
DEBUG - 2025-09-17 07:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 07:52:46 --> CSRF cookie sent
INFO - 2025-09-17 07:52:46 --> Input Class Initialized
INFO - 2025-09-17 07:52:46 --> Language Class Initialized
INFO - 2025-09-17 07:52:46 --> Loader Class Initialized
INFO - 2025-09-17 07:52:46 --> Helper loaded: url_helper
INFO - 2025-09-17 07:52:46 --> Helper loaded: text_helper
INFO - 2025-09-17 07:52:46 --> Helper loaded: string_helper
INFO - 2025-09-17 07:52:46 --> Helper loaded: form_helper
INFO - 2025-09-17 07:52:46 --> Helper loaded: download_helper
INFO - 2025-09-17 07:52:46 --> Helper loaded: security_helper
INFO - 2025-09-17 07:52:46 --> Database Driver Class Initialized
DEBUG - 2025-09-17 07:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 07:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 07:52:46 --> Form Validation Class Initialized
INFO - 2025-09-17 07:52:46 --> Model "User_model" initialized
INFO - 2025-09-17 12:52:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 12:52:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 12:52:46 --> Model "Nav_model" initialized
INFO - 2025-09-17 12:52:46 --> Controller Class Initialized
DEBUG - 2025-09-17 12:52:46 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-17 12:52:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-17 12:52:46 --> Model "Log_model" initialized
INFO - 2025-09-17 12:52:46 --> Final output sent to browser
DEBUG - 2025-09-17 12:52:46 --> Total execution time: 0.1610
INFO - 2025-09-17 07:52:52 --> Config Class Initialized
INFO - 2025-09-17 07:52:52 --> Hooks Class Initialized
DEBUG - 2025-09-17 07:52:52 --> UTF-8 Support Enabled
INFO - 2025-09-17 07:52:52 --> Utf8 Class Initialized
INFO - 2025-09-17 07:52:52 --> URI Class Initialized
INFO - 2025-09-17 07:52:52 --> Router Class Initialized
INFO - 2025-09-17 07:52:52 --> Output Class Initialized
INFO - 2025-09-17 07:52:52 --> Security Class Initialized
DEBUG - 2025-09-17 07:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 07:52:52 --> CSRF cookie sent
INFO - 2025-09-17 07:52:52 --> CSRF token verified
INFO - 2025-09-17 07:52:52 --> Input Class Initialized
INFO - 2025-09-17 07:52:52 --> Language Class Initialized
INFO - 2025-09-17 07:52:52 --> Loader Class Initialized
INFO - 2025-09-17 07:52:52 --> Helper loaded: url_helper
INFO - 2025-09-17 07:52:52 --> Helper loaded: text_helper
INFO - 2025-09-17 07:52:52 --> Helper loaded: string_helper
INFO - 2025-09-17 07:52:52 --> Helper loaded: form_helper
INFO - 2025-09-17 07:52:52 --> Helper loaded: download_helper
INFO - 2025-09-17 07:52:52 --> Helper loaded: security_helper
INFO - 2025-09-17 07:52:52 --> Database Driver Class Initialized
DEBUG - 2025-09-17 07:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 07:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 07:52:52 --> Form Validation Class Initialized
INFO - 2025-09-17 07:52:52 --> Model "User_model" initialized
INFO - 2025-09-17 12:52:52 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 12:52:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 12:52:52 --> Model "Nav_model" initialized
INFO - 2025-09-17 12:52:52 --> Controller Class Initialized
DEBUG - 2025-09-17 12:52:52 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-17 12:52:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-17 07:52:52 --> Config Class Initialized
INFO - 2025-09-17 07:52:52 --> Hooks Class Initialized
DEBUG - 2025-09-17 07:52:52 --> UTF-8 Support Enabled
INFO - 2025-09-17 07:52:52 --> Utf8 Class Initialized
INFO - 2025-09-17 07:52:52 --> URI Class Initialized
INFO - 2025-09-17 07:52:52 --> Router Class Initialized
INFO - 2025-09-17 07:52:52 --> Output Class Initialized
INFO - 2025-09-17 07:52:52 --> Security Class Initialized
DEBUG - 2025-09-17 07:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 07:52:52 --> CSRF cookie sent
INFO - 2025-09-17 07:52:52 --> Input Class Initialized
INFO - 2025-09-17 07:52:52 --> Language Class Initialized
INFO - 2025-09-17 07:52:52 --> Loader Class Initialized
INFO - 2025-09-17 07:52:52 --> Helper loaded: url_helper
INFO - 2025-09-17 07:52:52 --> Helper loaded: text_helper
INFO - 2025-09-17 07:52:52 --> Helper loaded: string_helper
INFO - 2025-09-17 07:52:52 --> Helper loaded: form_helper
INFO - 2025-09-17 07:52:52 --> Helper loaded: download_helper
INFO - 2025-09-17 07:52:52 --> Helper loaded: security_helper
INFO - 2025-09-17 07:52:53 --> Database Driver Class Initialized
DEBUG - 2025-09-17 07:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 07:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 07:52:53 --> Form Validation Class Initialized
INFO - 2025-09-17 07:52:53 --> Model "User_model" initialized
INFO - 2025-09-17 12:52:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 12:52:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 12:52:53 --> Model "Nav_model" initialized
INFO - 2025-09-17 12:52:53 --> Controller Class Initialized
INFO - 2025-09-17 12:52:53 --> Model "Tautan_model" initialized
INFO - 2025-09-17 12:52:53 --> Model "Staff_model" initialized
INFO - 2025-09-17 12:52:53 --> Model "Dasbor_model" initialized
INFO - 2025-09-17 12:52:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-09-17 12:52:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-17 12:52:53 --> Model "Log_model" initialized
INFO - 2025-09-17 12:52:54 --> Final output sent to browser
DEBUG - 2025-09-17 12:52:54 --> Total execution time: 1.0666
INFO - 2025-09-17 07:52:59 --> Config Class Initialized
INFO - 2025-09-17 07:52:59 --> Hooks Class Initialized
DEBUG - 2025-09-17 07:52:59 --> UTF-8 Support Enabled
INFO - 2025-09-17 07:52:59 --> Utf8 Class Initialized
INFO - 2025-09-17 07:52:59 --> URI Class Initialized
INFO - 2025-09-17 07:52:59 --> Router Class Initialized
INFO - 2025-09-17 07:52:59 --> Output Class Initialized
INFO - 2025-09-17 07:52:59 --> Security Class Initialized
DEBUG - 2025-09-17 07:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 07:52:59 --> CSRF cookie sent
INFO - 2025-09-17 07:52:59 --> Input Class Initialized
INFO - 2025-09-17 07:52:59 --> Language Class Initialized
INFO - 2025-09-17 07:52:59 --> Loader Class Initialized
INFO - 2025-09-17 07:52:59 --> Helper loaded: url_helper
INFO - 2025-09-17 07:52:59 --> Helper loaded: text_helper
INFO - 2025-09-17 07:52:59 --> Helper loaded: string_helper
INFO - 2025-09-17 07:52:59 --> Helper loaded: form_helper
INFO - 2025-09-17 07:52:59 --> Helper loaded: download_helper
INFO - 2025-09-17 07:52:59 --> Helper loaded: security_helper
INFO - 2025-09-17 07:52:59 --> Database Driver Class Initialized
DEBUG - 2025-09-17 07:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 07:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 07:52:59 --> Form Validation Class Initialized
INFO - 2025-09-17 07:52:59 --> Model "User_model" initialized
INFO - 2025-09-17 12:52:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 12:52:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 12:52:59 --> Model "Nav_model" initialized
INFO - 2025-09-17 12:52:59 --> Controller Class Initialized
INFO - 2025-09-17 12:52:59 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 12:52:59 --> Model "Konfigurasi_model" initialized
DEBUG - 2025-09-17 12:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2025-09-17 12:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 12:52:59 --> Pagination Class Initialized
INFO - 2025-09-17 12:52:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/testimoni/list.php
INFO - 2025-09-17 12:52:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-17 12:52:59 --> Model "Log_model" initialized
INFO - 2025-09-17 12:52:59 --> Final output sent to browser
DEBUG - 2025-09-17 12:52:59 --> Total execution time: 0.1901
INFO - 2025-09-17 08:54:49 --> Config Class Initialized
INFO - 2025-09-17 08:54:49 --> Hooks Class Initialized
DEBUG - 2025-09-17 08:54:49 --> UTF-8 Support Enabled
INFO - 2025-09-17 08:54:49 --> Utf8 Class Initialized
INFO - 2025-09-17 08:54:49 --> URI Class Initialized
DEBUG - 2025-09-17 08:54:49 --> No URI present. Default controller set.
INFO - 2025-09-17 08:54:49 --> Router Class Initialized
INFO - 2025-09-17 08:54:49 --> Output Class Initialized
INFO - 2025-09-17 08:54:49 --> Security Class Initialized
DEBUG - 2025-09-17 08:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 08:54:49 --> CSRF cookie sent
INFO - 2025-09-17 08:54:49 --> Input Class Initialized
INFO - 2025-09-17 08:54:49 --> Language Class Initialized
INFO - 2025-09-17 08:54:49 --> Loader Class Initialized
INFO - 2025-09-17 08:54:49 --> Helper loaded: url_helper
INFO - 2025-09-17 08:54:49 --> Helper loaded: text_helper
INFO - 2025-09-17 08:54:49 --> Helper loaded: string_helper
INFO - 2025-09-17 08:54:49 --> Helper loaded: form_helper
INFO - 2025-09-17 08:54:49 --> Helper loaded: download_helper
INFO - 2025-09-17 08:54:49 --> Helper loaded: security_helper
INFO - 2025-09-17 08:54:49 --> Database Driver Class Initialized
DEBUG - 2025-09-17 08:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 08:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 08:54:49 --> Form Validation Class Initialized
INFO - 2025-09-17 08:54:49 --> Model "User_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Nav_model" initialized
INFO - 2025-09-17 13:54:49 --> Controller Class Initialized
INFO - 2025-09-17 13:54:49 --> Model "Berita_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Galeri_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Video_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Agenda_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Tautan_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Mitra_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Prodi_model" initialized
INFO - 2025-09-17 13:54:49 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 13:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 13:54:49 --> Pagination Class Initialized
INFO - 2025-09-17 13:54:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 13:54:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 13:54:50 --> Model "Log_model" initialized
INFO - 2025-09-17 13:54:50 --> Final output sent to browser
DEBUG - 2025-09-17 13:54:50 --> Total execution time: 0.2291
INFO - 2025-09-17 08:55:01 --> Config Class Initialized
INFO - 2025-09-17 08:55:01 --> Hooks Class Initialized
INFO - 2025-09-17 08:55:01 --> Config Class Initialized
INFO - 2025-09-17 08:55:01 --> Config Class Initialized
INFO - 2025-09-17 08:55:01 --> Hooks Class Initialized
INFO - 2025-09-17 08:55:01 --> Hooks Class Initialized
DEBUG - 2025-09-17 08:55:01 --> UTF-8 Support Enabled
INFO - 2025-09-17 08:55:01 --> Config Class Initialized
INFO - 2025-09-17 08:55:01 --> Utf8 Class Initialized
INFO - 2025-09-17 08:55:01 --> Hooks Class Initialized
INFO - 2025-09-17 08:55:01 --> URI Class Initialized
DEBUG - 2025-09-17 08:55:01 --> UTF-8 Support Enabled
INFO - 2025-09-17 08:55:01 --> Utf8 Class Initialized
DEBUG - 2025-09-17 08:55:01 --> UTF-8 Support Enabled
INFO - 2025-09-17 08:55:01 --> Utf8 Class Initialized
DEBUG - 2025-09-17 08:55:01 --> UTF-8 Support Enabled
INFO - 2025-09-17 08:55:01 --> Utf8 Class Initialized
INFO - 2025-09-17 08:55:01 --> Router Class Initialized
INFO - 2025-09-17 08:55:01 --> URI Class Initialized
INFO - 2025-09-17 08:55:01 --> URI Class Initialized
INFO - 2025-09-17 08:55:01 --> URI Class Initialized
INFO - 2025-09-17 08:55:01 --> Router Class Initialized
INFO - 2025-09-17 08:55:01 --> Router Class Initialized
INFO - 2025-09-17 08:55:01 --> Output Class Initialized
INFO - 2025-09-17 08:55:01 --> Router Class Initialized
INFO - 2025-09-17 08:55:01 --> Output Class Initialized
INFO - 2025-09-17 08:55:01 --> Security Class Initialized
INFO - 2025-09-17 08:55:01 --> Output Class Initialized
INFO - 2025-09-17 08:55:01 --> Output Class Initialized
DEBUG - 2025-09-17 08:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 08:55:01 --> CSRF cookie sent
INFO - 2025-09-17 08:55:01 --> Security Class Initialized
INFO - 2025-09-17 08:55:01 --> Input Class Initialized
INFO - 2025-09-17 08:55:01 --> Security Class Initialized
INFO - 2025-09-17 08:55:01 --> Security Class Initialized
INFO - 2025-09-17 08:55:01 --> Language Class Initialized
DEBUG - 2025-09-17 08:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-17 08:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 08:55:01 --> CSRF cookie sent
INFO - 2025-09-17 08:55:01 --> CSRF cookie sent
INFO - 2025-09-17 08:55:01 --> Input Class Initialized
INFO - 2025-09-17 08:55:01 --> Input Class Initialized
DEBUG - 2025-09-17 08:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 08:55:01 --> CSRF cookie sent
INFO - 2025-09-17 08:55:01 --> Input Class Initialized
INFO - 2025-09-17 08:55:01 --> Language Class Initialized
INFO - 2025-09-17 08:55:01 --> Language Class Initialized
INFO - 2025-09-17 08:55:01 --> Loader Class Initialized
INFO - 2025-09-17 08:55:01 --> Language Class Initialized
INFO - 2025-09-17 08:55:01 --> Helper loaded: url_helper
INFO - 2025-09-17 08:55:01 --> Loader Class Initialized
INFO - 2025-09-17 08:55:01 --> Loader Class Initialized
INFO - 2025-09-17 08:55:01 --> Helper loaded: text_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: url_helper
INFO - 2025-09-17 08:55:01 --> Loader Class Initialized
INFO - 2025-09-17 08:55:01 --> Helper loaded: string_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: text_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: url_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: string_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: form_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: url_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: text_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: form_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: download_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: text_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: string_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: security_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: download_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: string_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: security_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: form_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: download_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: form_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: security_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: download_helper
INFO - 2025-09-17 08:55:01 --> Helper loaded: security_helper
INFO - 2025-09-17 08:55:01 --> Database Driver Class Initialized
INFO - 2025-09-17 08:55:01 --> Database Driver Class Initialized
INFO - 2025-09-17 08:55:01 --> Database Driver Class Initialized
DEBUG - 2025-09-17 08:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 08:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 08:55:01 --> Database Driver Class Initialized
DEBUG - 2025-09-17 08:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 08:55:01 --> Form Validation Class Initialized
INFO - 2025-09-17 08:55:01 --> Model "User_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Kunjungan_model" initialized
DEBUG - 2025-09-17 08:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 13:55:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Nav_model" initialized
INFO - 2025-09-17 13:55:01 --> Controller Class Initialized
INFO - 2025-09-17 13:55:01 --> Model "Berita_model" initialized
DEBUG - 2025-09-17 08:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 13:55:01 --> Model "Galeri_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Video_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Agenda_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Tautan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Mitra_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Prodi_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 13:55:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 13:55:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 13:55:01 --> Model "Log_model" initialized
INFO - 2025-09-17 13:55:01 --> Final output sent to browser
DEBUG - 2025-09-17 13:55:01 --> Total execution time: 0.1423
INFO - 2025-09-17 08:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 08:55:01 --> Form Validation Class Initialized
INFO - 2025-09-17 08:55:01 --> Model "User_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Nav_model" initialized
INFO - 2025-09-17 13:55:01 --> Controller Class Initialized
INFO - 2025-09-17 13:55:01 --> Model "Berita_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Galeri_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Video_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Agenda_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Tautan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Mitra_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Prodi_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 13:55:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 13:55:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 13:55:01 --> Model "Log_model" initialized
INFO - 2025-09-17 13:55:01 --> Final output sent to browser
DEBUG - 2025-09-17 13:55:01 --> Total execution time: 0.2003
INFO - 2025-09-17 08:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 08:55:01 --> Form Validation Class Initialized
INFO - 2025-09-17 08:55:01 --> Model "User_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Nav_model" initialized
INFO - 2025-09-17 13:55:01 --> Controller Class Initialized
INFO - 2025-09-17 13:55:01 --> Model "Berita_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Galeri_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Video_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Agenda_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Tautan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Mitra_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Prodi_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 13:55:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 13:55:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 13:55:01 --> Model "Log_model" initialized
INFO - 2025-09-17 13:55:01 --> Final output sent to browser
DEBUG - 2025-09-17 13:55:01 --> Total execution time: 0.2634
INFO - 2025-09-17 08:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 08:55:01 --> Form Validation Class Initialized
INFO - 2025-09-17 08:55:01 --> Model "User_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Nav_model" initialized
INFO - 2025-09-17 13:55:01 --> Controller Class Initialized
INFO - 2025-09-17 13:55:01 --> Model "Berita_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Galeri_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Video_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Agenda_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Tautan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Mitra_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Prodi_model" initialized
INFO - 2025-09-17 13:55:01 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 13:55:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 13:55:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 13:55:01 --> Model "Log_model" initialized
INFO - 2025-09-17 13:55:01 --> Final output sent to browser
DEBUG - 2025-09-17 13:55:01 --> Total execution time: 0.3245
INFO - 2025-09-17 08:55:15 --> Config Class Initialized
INFO - 2025-09-17 08:55:15 --> Hooks Class Initialized
DEBUG - 2025-09-17 08:55:15 --> UTF-8 Support Enabled
INFO - 2025-09-17 08:55:15 --> Utf8 Class Initialized
INFO - 2025-09-17 08:55:15 --> URI Class Initialized
INFO - 2025-09-17 08:55:15 --> Router Class Initialized
INFO - 2025-09-17 08:55:16 --> Output Class Initialized
INFO - 2025-09-17 08:55:16 --> Security Class Initialized
DEBUG - 2025-09-17 08:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 08:55:16 --> CSRF cookie sent
INFO - 2025-09-17 08:55:16 --> Input Class Initialized
INFO - 2025-09-17 08:55:16 --> Language Class Initialized
INFO - 2025-09-17 08:55:16 --> Loader Class Initialized
INFO - 2025-09-17 08:55:16 --> Helper loaded: url_helper
INFO - 2025-09-17 08:55:16 --> Helper loaded: text_helper
INFO - 2025-09-17 08:55:16 --> Helper loaded: string_helper
INFO - 2025-09-17 08:55:16 --> Helper loaded: form_helper
INFO - 2025-09-17 08:55:16 --> Helper loaded: download_helper
INFO - 2025-09-17 08:55:16 --> Helper loaded: security_helper
INFO - 2025-09-17 08:55:16 --> Database Driver Class Initialized
DEBUG - 2025-09-17 08:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 08:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 08:55:16 --> Form Validation Class Initialized
INFO - 2025-09-17 08:55:16 --> Model "User_model" initialized
INFO - 2025-09-17 13:55:16 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 13:55:16 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 13:55:16 --> Model "Nav_model" initialized
INFO - 2025-09-17 13:55:16 --> Controller Class Initialized
INFO - 2025-09-17 13:55:16 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 13:55:16 --> Model "Prodi_model" initialized
INFO - 2025-09-17 13:55:16 --> Model "Sdm_model" initialized
INFO - 2025-09-17 13:55:16 --> Model "Sdm_jurusan_model" initialized
INFO - 2025-09-17 13:55:16 --> Query SDM berhasil untuk jurusan: Teknologi Laboratorium Medis, Total: 0
ERROR - 2025-09-17 13:55:16 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-17 13:55:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 36
ERROR - 2025-09-17 13:55:16 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
ERROR - 2025-09-17 13:55:16 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 466
INFO - 2025-09-17 13:55:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2025-09-17 13:55:16 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 13:55:16 --> Model "Log_model" initialized
INFO - 2025-09-17 13:55:16 --> Final output sent to browser
DEBUG - 2025-09-17 13:55:16 --> Total execution time: 0.2002
INFO - 2025-09-17 09:04:32 --> Config Class Initialized
INFO - 2025-09-17 09:04:32 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:04:33 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:04:33 --> Utf8 Class Initialized
INFO - 2025-09-17 09:04:33 --> URI Class Initialized
DEBUG - 2025-09-17 09:04:33 --> No URI present. Default controller set.
INFO - 2025-09-17 09:04:33 --> Router Class Initialized
INFO - 2025-09-17 09:04:33 --> Output Class Initialized
INFO - 2025-09-17 09:04:33 --> Security Class Initialized
DEBUG - 2025-09-17 09:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:04:33 --> CSRF cookie sent
INFO - 2025-09-17 09:04:33 --> Input Class Initialized
INFO - 2025-09-17 09:04:33 --> Language Class Initialized
INFO - 2025-09-17 09:04:33 --> Loader Class Initialized
INFO - 2025-09-17 09:04:33 --> Helper loaded: url_helper
INFO - 2025-09-17 09:04:33 --> Helper loaded: text_helper
INFO - 2025-09-17 09:04:33 --> Helper loaded: string_helper
INFO - 2025-09-17 09:04:33 --> Helper loaded: form_helper
INFO - 2025-09-17 09:04:33 --> Helper loaded: download_helper
INFO - 2025-09-17 09:04:33 --> Helper loaded: security_helper
INFO - 2025-09-17 09:04:33 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:04:33 --> Form Validation Class Initialized
INFO - 2025-09-17 09:04:33 --> Model "User_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:04:33 --> Controller Class Initialized
INFO - 2025-09-17 14:04:33 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Video_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:04:33 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:04:33 --> Pagination Class Initialized
INFO - 2025-09-17 14:04:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:04:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:04:33 --> Model "Log_model" initialized
INFO - 2025-09-17 14:04:33 --> Final output sent to browser
DEBUG - 2025-09-17 14:04:33 --> Total execution time: 0.2243
INFO - 2025-09-17 09:04:51 --> Config Class Initialized
INFO - 2025-09-17 09:04:51 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:04:51 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:04:51 --> Utf8 Class Initialized
INFO - 2025-09-17 09:04:51 --> URI Class Initialized
DEBUG - 2025-09-17 09:04:51 --> No URI present. Default controller set.
INFO - 2025-09-17 09:04:51 --> Router Class Initialized
INFO - 2025-09-17 09:04:51 --> Output Class Initialized
INFO - 2025-09-17 09:04:51 --> Security Class Initialized
DEBUG - 2025-09-17 09:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:04:51 --> CSRF cookie sent
INFO - 2025-09-17 09:04:51 --> Input Class Initialized
INFO - 2025-09-17 09:04:51 --> Language Class Initialized
INFO - 2025-09-17 09:04:51 --> Loader Class Initialized
INFO - 2025-09-17 09:04:51 --> Helper loaded: url_helper
INFO - 2025-09-17 09:04:51 --> Helper loaded: text_helper
INFO - 2025-09-17 09:04:51 --> Helper loaded: string_helper
INFO - 2025-09-17 09:04:51 --> Helper loaded: form_helper
INFO - 2025-09-17 09:04:51 --> Helper loaded: download_helper
INFO - 2025-09-17 09:04:51 --> Helper loaded: security_helper
INFO - 2025-09-17 09:04:51 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:04:51 --> Form Validation Class Initialized
INFO - 2025-09-17 09:04:51 --> Model "User_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:04:51 --> Controller Class Initialized
INFO - 2025-09-17 14:04:51 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Video_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:04:51 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:04:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:04:51 --> Pagination Class Initialized
INFO - 2025-09-17 14:04:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:04:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:04:51 --> Model "Log_model" initialized
INFO - 2025-09-17 14:04:52 --> Final output sent to browser
DEBUG - 2025-09-17 14:04:52 --> Total execution time: 0.2498
INFO - 2025-09-17 09:05:09 --> Config Class Initialized
INFO - 2025-09-17 09:05:09 --> Hooks Class Initialized
INFO - 2025-09-17 09:05:09 --> Config Class Initialized
INFO - 2025-09-17 09:05:09 --> Hooks Class Initialized
INFO - 2025-09-17 09:05:09 --> Config Class Initialized
INFO - 2025-09-17 09:05:09 --> Hooks Class Initialized
INFO - 2025-09-17 09:05:09 --> Config Class Initialized
DEBUG - 2025-09-17 09:05:09 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:05:09 --> Hooks Class Initialized
INFO - 2025-09-17 09:05:09 --> Utf8 Class Initialized
DEBUG - 2025-09-17 09:05:09 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:05:09 --> Utf8 Class Initialized
INFO - 2025-09-17 09:05:09 --> URI Class Initialized
DEBUG - 2025-09-17 09:05:09 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:05:09 --> Utf8 Class Initialized
INFO - 2025-09-17 09:05:09 --> URI Class Initialized
INFO - 2025-09-17 09:05:09 --> Router Class Initialized
DEBUG - 2025-09-17 09:05:09 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:05:09 --> Utf8 Class Initialized
INFO - 2025-09-17 09:05:09 --> URI Class Initialized
INFO - 2025-09-17 09:05:09 --> Router Class Initialized
INFO - 2025-09-17 09:05:09 --> Output Class Initialized
INFO - 2025-09-17 09:05:09 --> URI Class Initialized
INFO - 2025-09-17 09:05:09 --> Router Class Initialized
INFO - 2025-09-17 09:05:09 --> Output Class Initialized
INFO - 2025-09-17 09:05:09 --> Security Class Initialized
INFO - 2025-09-17 09:05:09 --> Router Class Initialized
INFO - 2025-09-17 09:05:09 --> Security Class Initialized
INFO - 2025-09-17 09:05:09 --> Output Class Initialized
DEBUG - 2025-09-17 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:05:09 --> CSRF cookie sent
INFO - 2025-09-17 09:05:09 --> Input Class Initialized
DEBUG - 2025-09-17 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:05:09 --> Output Class Initialized
INFO - 2025-09-17 09:05:09 --> CSRF cookie sent
INFO - 2025-09-17 09:05:09 --> Security Class Initialized
INFO - 2025-09-17 09:05:09 --> Input Class Initialized
INFO - 2025-09-17 09:05:09 --> Language Class Initialized
INFO - 2025-09-17 09:05:09 --> Security Class Initialized
INFO - 2025-09-17 09:05:09 --> Language Class Initialized
DEBUG - 2025-09-17 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:05:09 --> CSRF cookie sent
INFO - 2025-09-17 09:05:09 --> Input Class Initialized
DEBUG - 2025-09-17 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:05:09 --> CSRF cookie sent
INFO - 2025-09-17 09:05:09 --> Language Class Initialized
INFO - 2025-09-17 09:05:09 --> Loader Class Initialized
INFO - 2025-09-17 09:05:09 --> Input Class Initialized
INFO - 2025-09-17 09:05:09 --> Loader Class Initialized
INFO - 2025-09-17 09:05:09 --> Language Class Initialized
INFO - 2025-09-17 09:05:09 --> Helper loaded: url_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: url_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: text_helper
INFO - 2025-09-17 09:05:09 --> Loader Class Initialized
INFO - 2025-09-17 09:05:09 --> Helper loaded: text_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: string_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: url_helper
INFO - 2025-09-17 09:05:09 --> Loader Class Initialized
INFO - 2025-09-17 09:05:09 --> Helper loaded: string_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: form_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: text_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: url_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: form_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: download_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: string_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: download_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: security_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: text_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: security_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: string_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: form_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: download_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: form_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: security_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: download_helper
INFO - 2025-09-17 09:05:09 --> Helper loaded: security_helper
INFO - 2025-09-17 09:05:09 --> Database Driver Class Initialized
INFO - 2025-09-17 09:05:09 --> Database Driver Class Initialized
INFO - 2025-09-17 09:05:09 --> Database Driver Class Initialized
INFO - 2025-09-17 09:05:09 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:05:09 --> Form Validation Class Initialized
DEBUG - 2025-09-17 09:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:05:09 --> Model "User_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:05:09 --> Controller Class Initialized
DEBUG - 2025-09-17 09:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-17 09:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 14:05:09 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Video_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:05:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:05:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:05:09 --> Model "Log_model" initialized
INFO - 2025-09-17 14:05:09 --> Final output sent to browser
DEBUG - 2025-09-17 14:05:09 --> Total execution time: 0.2192
INFO - 2025-09-17 09:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:05:09 --> Form Validation Class Initialized
INFO - 2025-09-17 09:05:09 --> Model "User_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:05:09 --> Controller Class Initialized
INFO - 2025-09-17 14:05:09 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Video_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:05:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:05:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:05:09 --> Model "Log_model" initialized
INFO - 2025-09-17 14:05:09 --> Final output sent to browser
DEBUG - 2025-09-17 14:05:09 --> Total execution time: 0.3237
INFO - 2025-09-17 09:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:05:09 --> Form Validation Class Initialized
INFO - 2025-09-17 09:05:09 --> Model "User_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:05:09 --> Controller Class Initialized
INFO - 2025-09-17 14:05:09 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Video_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:05:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:05:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:05:09 --> Model "Log_model" initialized
INFO - 2025-09-17 14:05:09 --> Final output sent to browser
DEBUG - 2025-09-17 14:05:09 --> Total execution time: 0.4095
INFO - 2025-09-17 09:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:05:09 --> Form Validation Class Initialized
INFO - 2025-09-17 09:05:09 --> Model "User_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:05:09 --> Controller Class Initialized
INFO - 2025-09-17 14:05:09 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Video_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:05:09 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:05:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:05:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:05:09 --> Model "Log_model" initialized
INFO - 2025-09-17 14:05:09 --> Final output sent to browser
DEBUG - 2025-09-17 14:05:09 --> Total execution time: 0.6081
INFO - 2025-09-17 09:05:10 --> Config Class Initialized
INFO - 2025-09-17 09:05:10 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:05:10 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:05:10 --> Utf8 Class Initialized
INFO - 2025-09-17 09:05:10 --> URI Class Initialized
DEBUG - 2025-09-17 09:05:10 --> No URI present. Default controller set.
INFO - 2025-09-17 09:05:10 --> Router Class Initialized
INFO - 2025-09-17 09:05:10 --> Output Class Initialized
INFO - 2025-09-17 09:05:10 --> Security Class Initialized
DEBUG - 2025-09-17 09:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:05:11 --> CSRF cookie sent
INFO - 2025-09-17 09:05:11 --> Input Class Initialized
INFO - 2025-09-17 09:05:11 --> Language Class Initialized
INFO - 2025-09-17 09:05:11 --> Loader Class Initialized
INFO - 2025-09-17 09:05:11 --> Helper loaded: url_helper
INFO - 2025-09-17 09:05:11 --> Helper loaded: text_helper
INFO - 2025-09-17 09:05:11 --> Helper loaded: string_helper
INFO - 2025-09-17 09:05:11 --> Helper loaded: form_helper
INFO - 2025-09-17 09:05:11 --> Helper loaded: download_helper
INFO - 2025-09-17 09:05:11 --> Helper loaded: security_helper
INFO - 2025-09-17 09:05:11 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:05:11 --> Form Validation Class Initialized
INFO - 2025-09-17 09:05:11 --> Model "User_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:05:11 --> Controller Class Initialized
INFO - 2025-09-17 14:05:11 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Video_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:05:11 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:05:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:05:11 --> Pagination Class Initialized
INFO - 2025-09-17 14:05:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:05:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:05:11 --> Model "Log_model" initialized
INFO - 2025-09-17 14:05:11 --> Final output sent to browser
DEBUG - 2025-09-17 14:05:11 --> Total execution time: 0.3226
INFO - 2025-09-17 09:05:17 --> Config Class Initialized
INFO - 2025-09-17 09:05:17 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:05:17 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:05:17 --> Utf8 Class Initialized
INFO - 2025-09-17 09:05:17 --> URI Class Initialized
DEBUG - 2025-09-17 09:05:17 --> No URI present. Default controller set.
INFO - 2025-09-17 09:05:17 --> Router Class Initialized
INFO - 2025-09-17 09:05:17 --> Output Class Initialized
INFO - 2025-09-17 09:05:17 --> Security Class Initialized
DEBUG - 2025-09-17 09:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:05:17 --> CSRF cookie sent
INFO - 2025-09-17 09:05:17 --> Input Class Initialized
INFO - 2025-09-17 09:05:17 --> Language Class Initialized
INFO - 2025-09-17 09:05:17 --> Loader Class Initialized
INFO - 2025-09-17 09:05:17 --> Helper loaded: url_helper
INFO - 2025-09-17 09:05:17 --> Helper loaded: text_helper
INFO - 2025-09-17 09:05:17 --> Helper loaded: string_helper
INFO - 2025-09-17 09:05:17 --> Helper loaded: form_helper
INFO - 2025-09-17 09:05:17 --> Helper loaded: download_helper
INFO - 2025-09-17 09:05:17 --> Helper loaded: security_helper
INFO - 2025-09-17 09:05:17 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:05:17 --> Form Validation Class Initialized
INFO - 2025-09-17 09:05:17 --> Model "User_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:05:17 --> Controller Class Initialized
INFO - 2025-09-17 14:05:17 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Video_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:05:17 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:05:17 --> Pagination Class Initialized
INFO - 2025-09-17 14:05:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:05:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:05:17 --> Model "Log_model" initialized
INFO - 2025-09-17 14:05:17 --> Final output sent to browser
DEBUG - 2025-09-17 14:05:17 --> Total execution time: 0.3156
INFO - 2025-09-17 09:08:30 --> Config Class Initialized
INFO - 2025-09-17 09:08:30 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:08:30 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:08:30 --> Utf8 Class Initialized
INFO - 2025-09-17 09:08:30 --> URI Class Initialized
DEBUG - 2025-09-17 09:08:30 --> No URI present. Default controller set.
INFO - 2025-09-17 09:08:30 --> Router Class Initialized
INFO - 2025-09-17 09:08:30 --> Output Class Initialized
INFO - 2025-09-17 09:08:30 --> Security Class Initialized
DEBUG - 2025-09-17 09:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:08:30 --> CSRF cookie sent
INFO - 2025-09-17 09:08:30 --> Input Class Initialized
INFO - 2025-09-17 09:08:30 --> Language Class Initialized
INFO - 2025-09-17 09:08:30 --> Loader Class Initialized
INFO - 2025-09-17 09:08:30 --> Helper loaded: url_helper
INFO - 2025-09-17 09:08:30 --> Helper loaded: text_helper
INFO - 2025-09-17 09:08:30 --> Helper loaded: string_helper
INFO - 2025-09-17 09:08:30 --> Helper loaded: form_helper
INFO - 2025-09-17 09:08:30 --> Helper loaded: download_helper
INFO - 2025-09-17 09:08:30 --> Helper loaded: security_helper
INFO - 2025-09-17 09:08:30 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:08:30 --> Form Validation Class Initialized
INFO - 2025-09-17 09:08:30 --> Model "User_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:08:30 --> Controller Class Initialized
INFO - 2025-09-17 14:08:30 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Video_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:08:30 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:08:30 --> Pagination Class Initialized
INFO - 2025-09-17 14:08:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:08:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:08:30 --> Model "Log_model" initialized
INFO - 2025-09-17 14:08:30 --> Final output sent to browser
DEBUG - 2025-09-17 14:08:30 --> Total execution time: 0.2638
INFO - 2025-09-17 09:08:39 --> Config Class Initialized
INFO - 2025-09-17 09:08:39 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:08:39 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:08:39 --> Utf8 Class Initialized
INFO - 2025-09-17 09:08:39 --> URI Class Initialized
DEBUG - 2025-09-17 09:08:39 --> No URI present. Default controller set.
INFO - 2025-09-17 09:08:39 --> Router Class Initialized
INFO - 2025-09-17 09:08:39 --> Output Class Initialized
INFO - 2025-09-17 09:08:39 --> Security Class Initialized
DEBUG - 2025-09-17 09:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:08:39 --> CSRF cookie sent
INFO - 2025-09-17 09:08:39 --> Input Class Initialized
INFO - 2025-09-17 09:08:39 --> Language Class Initialized
INFO - 2025-09-17 09:08:39 --> Loader Class Initialized
INFO - 2025-09-17 09:08:39 --> Helper loaded: url_helper
INFO - 2025-09-17 09:08:39 --> Helper loaded: text_helper
INFO - 2025-09-17 09:08:39 --> Helper loaded: string_helper
INFO - 2025-09-17 09:08:39 --> Helper loaded: form_helper
INFO - 2025-09-17 09:08:39 --> Helper loaded: download_helper
INFO - 2025-09-17 09:08:39 --> Helper loaded: security_helper
INFO - 2025-09-17 09:08:39 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:08:39 --> Form Validation Class Initialized
INFO - 2025-09-17 09:08:39 --> Model "User_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:08:39 --> Controller Class Initialized
INFO - 2025-09-17 14:08:39 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Video_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:08:39 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:08:39 --> Pagination Class Initialized
INFO - 2025-09-17 14:08:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:08:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:08:39 --> Model "Log_model" initialized
INFO - 2025-09-17 14:08:39 --> Final output sent to browser
DEBUG - 2025-09-17 14:08:39 --> Total execution time: 0.3128
INFO - 2025-09-17 09:08:55 --> Config Class Initialized
INFO - 2025-09-17 09:08:55 --> Hooks Class Initialized
INFO - 2025-09-17 09:08:55 --> Config Class Initialized
INFO - 2025-09-17 09:08:55 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:08:55 --> UTF-8 Support Enabled
DEBUG - 2025-09-17 09:08:55 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:08:55 --> Utf8 Class Initialized
INFO - 2025-09-17 09:08:55 --> Utf8 Class Initialized
INFO - 2025-09-17 09:08:55 --> URI Class Initialized
INFO - 2025-09-17 09:08:55 --> URI Class Initialized
INFO - 2025-09-17 09:08:55 --> Router Class Initialized
INFO - 2025-09-17 09:08:55 --> Router Class Initialized
INFO - 2025-09-17 09:08:55 --> Output Class Initialized
INFO - 2025-09-17 09:08:55 --> Output Class Initialized
INFO - 2025-09-17 09:08:55 --> Security Class Initialized
INFO - 2025-09-17 09:08:55 --> Security Class Initialized
DEBUG - 2025-09-17 09:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-17 09:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:08:55 --> CSRF cookie sent
INFO - 2025-09-17 09:08:55 --> CSRF cookie sent
INFO - 2025-09-17 09:08:55 --> Input Class Initialized
INFO - 2025-09-17 09:08:55 --> Input Class Initialized
INFO - 2025-09-17 09:08:55 --> Language Class Initialized
INFO - 2025-09-17 09:08:55 --> Language Class Initialized
INFO - 2025-09-17 09:08:55 --> Loader Class Initialized
INFO - 2025-09-17 09:08:55 --> Loader Class Initialized
INFO - 2025-09-17 09:08:55 --> Helper loaded: url_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: url_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: text_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: text_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: string_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: string_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: form_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: form_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: download_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: download_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: security_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: security_helper
INFO - 2025-09-17 09:08:55 --> Database Driver Class Initialized
INFO - 2025-09-17 09:08:55 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:08:55 --> Form Validation Class Initialized
DEBUG - 2025-09-17 09:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:08:55 --> Model "User_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:08:55 --> Controller Class Initialized
INFO - 2025-09-17 14:08:55 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Video_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:08:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:08:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:08:55 --> Model "Log_model" initialized
INFO - 2025-09-17 14:08:55 --> Final output sent to browser
DEBUG - 2025-09-17 14:08:55 --> Total execution time: 0.2471
INFO - 2025-09-17 09:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:08:55 --> Form Validation Class Initialized
INFO - 2025-09-17 09:08:55 --> Model "User_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:08:55 --> Controller Class Initialized
INFO - 2025-09-17 14:08:55 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Video_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:08:55 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:08:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:08:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:08:55 --> Model "Log_model" initialized
INFO - 2025-09-17 14:08:55 --> Final output sent to browser
DEBUG - 2025-09-17 14:08:55 --> Total execution time: 0.3332
INFO - 2025-09-17 09:08:55 --> Config Class Initialized
INFO - 2025-09-17 09:08:55 --> Config Class Initialized
INFO - 2025-09-17 09:08:55 --> Hooks Class Initialized
INFO - 2025-09-17 09:08:55 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:08:55 --> UTF-8 Support Enabled
DEBUG - 2025-09-17 09:08:55 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:08:55 --> Utf8 Class Initialized
INFO - 2025-09-17 09:08:55 --> Utf8 Class Initialized
INFO - 2025-09-17 09:08:55 --> URI Class Initialized
INFO - 2025-09-17 09:08:55 --> URI Class Initialized
INFO - 2025-09-17 09:08:55 --> Router Class Initialized
INFO - 2025-09-17 09:08:55 --> Router Class Initialized
INFO - 2025-09-17 09:08:55 --> Output Class Initialized
INFO - 2025-09-17 09:08:55 --> Output Class Initialized
INFO - 2025-09-17 09:08:55 --> Security Class Initialized
INFO - 2025-09-17 09:08:55 --> Security Class Initialized
DEBUG - 2025-09-17 09:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:08:55 --> CSRF cookie sent
DEBUG - 2025-09-17 09:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:08:55 --> Input Class Initialized
INFO - 2025-09-17 09:08:55 --> CSRF cookie sent
INFO - 2025-09-17 09:08:55 --> Input Class Initialized
INFO - 2025-09-17 09:08:55 --> Language Class Initialized
INFO - 2025-09-17 09:08:55 --> Language Class Initialized
INFO - 2025-09-17 09:08:55 --> Loader Class Initialized
INFO - 2025-09-17 09:08:55 --> Loader Class Initialized
INFO - 2025-09-17 09:08:55 --> Helper loaded: url_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: url_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: text_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: text_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: string_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: string_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: form_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: form_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: download_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: download_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: security_helper
INFO - 2025-09-17 09:08:55 --> Helper loaded: security_helper
INFO - 2025-09-17 09:08:56 --> Database Driver Class Initialized
INFO - 2025-09-17 09:08:56 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:08:56 --> Form Validation Class Initialized
INFO - 2025-09-17 09:08:56 --> Model "User_model" initialized
DEBUG - 2025-09-17 09:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 14:08:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:08:56 --> Controller Class Initialized
INFO - 2025-09-17 14:08:56 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Video_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:08:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:08:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:08:56 --> Model "Log_model" initialized
INFO - 2025-09-17 14:08:56 --> Final output sent to browser
DEBUG - 2025-09-17 14:08:56 --> Total execution time: 0.2572
INFO - 2025-09-17 09:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:08:56 --> Form Validation Class Initialized
INFO - 2025-09-17 09:08:56 --> Model "User_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:08:56 --> Controller Class Initialized
INFO - 2025-09-17 14:08:56 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Video_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:08:56 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:08:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:08:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:08:56 --> Model "Log_model" initialized
INFO - 2025-09-17 14:08:56 --> Final output sent to browser
DEBUG - 2025-09-17 14:08:56 --> Total execution time: 0.4442
INFO - 2025-09-17 09:08:57 --> Config Class Initialized
INFO - 2025-09-17 09:08:57 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:08:57 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:08:57 --> Utf8 Class Initialized
INFO - 2025-09-17 09:08:57 --> URI Class Initialized
DEBUG - 2025-09-17 09:08:57 --> No URI present. Default controller set.
INFO - 2025-09-17 09:08:57 --> Router Class Initialized
INFO - 2025-09-17 09:08:57 --> Output Class Initialized
INFO - 2025-09-17 09:08:57 --> Security Class Initialized
DEBUG - 2025-09-17 09:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:08:57 --> CSRF cookie sent
INFO - 2025-09-17 09:08:57 --> Input Class Initialized
INFO - 2025-09-17 09:08:57 --> Language Class Initialized
INFO - 2025-09-17 09:08:57 --> Loader Class Initialized
INFO - 2025-09-17 09:08:57 --> Helper loaded: url_helper
INFO - 2025-09-17 09:08:57 --> Helper loaded: text_helper
INFO - 2025-09-17 09:08:57 --> Helper loaded: string_helper
INFO - 2025-09-17 09:08:57 --> Helper loaded: form_helper
INFO - 2025-09-17 09:08:57 --> Helper loaded: download_helper
INFO - 2025-09-17 09:08:57 --> Helper loaded: security_helper
INFO - 2025-09-17 09:08:57 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:08:57 --> Form Validation Class Initialized
INFO - 2025-09-17 09:08:57 --> Model "User_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:08:57 --> Controller Class Initialized
INFO - 2025-09-17 14:08:57 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Video_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:08:57 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:08:58 --> Pagination Class Initialized
INFO - 2025-09-17 14:08:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:08:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:08:58 --> Model "Log_model" initialized
INFO - 2025-09-17 14:08:58 --> Final output sent to browser
DEBUG - 2025-09-17 14:08:58 --> Total execution time: 0.4015
INFO - 2025-09-17 09:08:59 --> Config Class Initialized
INFO - 2025-09-17 09:08:59 --> Config Class Initialized
INFO - 2025-09-17 09:08:59 --> Hooks Class Initialized
INFO - 2025-09-17 09:08:59 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:08:59 --> UTF-8 Support Enabled
DEBUG - 2025-09-17 09:08:59 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:08:59 --> Utf8 Class Initialized
INFO - 2025-09-17 09:08:59 --> Utf8 Class Initialized
INFO - 2025-09-17 09:08:59 --> URI Class Initialized
INFO - 2025-09-17 09:08:59 --> URI Class Initialized
INFO - 2025-09-17 09:08:59 --> Router Class Initialized
INFO - 2025-09-17 09:08:59 --> Router Class Initialized
INFO - 2025-09-17 09:08:59 --> Output Class Initialized
INFO - 2025-09-17 09:08:59 --> Output Class Initialized
INFO - 2025-09-17 09:08:59 --> Security Class Initialized
INFO - 2025-09-17 09:08:59 --> Security Class Initialized
DEBUG - 2025-09-17 09:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:08:59 --> CSRF cookie sent
INFO - 2025-09-17 09:08:59 --> Input Class Initialized
DEBUG - 2025-09-17 09:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:08:59 --> CSRF cookie sent
INFO - 2025-09-17 09:08:59 --> Input Class Initialized
INFO - 2025-09-17 09:08:59 --> Language Class Initialized
INFO - 2025-09-17 09:08:59 --> Language Class Initialized
INFO - 2025-09-17 09:08:59 --> Loader Class Initialized
INFO - 2025-09-17 09:08:59 --> Loader Class Initialized
INFO - 2025-09-17 09:08:59 --> Helper loaded: url_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: url_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: text_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: text_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: string_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: string_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: form_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: form_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: download_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: download_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: security_helper
INFO - 2025-09-17 09:08:59 --> Helper loaded: security_helper
INFO - 2025-09-17 09:08:59 --> Database Driver Class Initialized
INFO - 2025-09-17 09:08:59 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-17 09:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:08:59 --> Form Validation Class Initialized
INFO - 2025-09-17 09:08:59 --> Model "User_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:08:59 --> Controller Class Initialized
INFO - 2025-09-17 14:08:59 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Video_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:08:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:08:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:08:59 --> Model "Log_model" initialized
INFO - 2025-09-17 14:08:59 --> Final output sent to browser
DEBUG - 2025-09-17 14:08:59 --> Total execution time: 0.1988
INFO - 2025-09-17 09:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:08:59 --> Form Validation Class Initialized
INFO - 2025-09-17 09:08:59 --> Model "User_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:08:59 --> Controller Class Initialized
INFO - 2025-09-17 14:08:59 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Video_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:08:59 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:08:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:08:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:08:59 --> Model "Log_model" initialized
INFO - 2025-09-17 14:08:59 --> Final output sent to browser
DEBUG - 2025-09-17 14:08:59 --> Total execution time: 0.2812
INFO - 2025-09-17 09:09:03 --> Config Class Initialized
INFO - 2025-09-17 09:09:03 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:09:03 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:09:03 --> Utf8 Class Initialized
INFO - 2025-09-17 09:09:03 --> URI Class Initialized
DEBUG - 2025-09-17 09:09:03 --> No URI present. Default controller set.
INFO - 2025-09-17 09:09:03 --> Router Class Initialized
INFO - 2025-09-17 09:09:03 --> Output Class Initialized
INFO - 2025-09-17 09:09:03 --> Security Class Initialized
DEBUG - 2025-09-17 09:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:09:03 --> CSRF cookie sent
INFO - 2025-09-17 09:09:03 --> Input Class Initialized
INFO - 2025-09-17 09:09:03 --> Language Class Initialized
INFO - 2025-09-17 09:09:03 --> Loader Class Initialized
INFO - 2025-09-17 09:09:03 --> Helper loaded: url_helper
INFO - 2025-09-17 09:09:03 --> Helper loaded: text_helper
INFO - 2025-09-17 09:09:03 --> Helper loaded: string_helper
INFO - 2025-09-17 09:09:03 --> Helper loaded: form_helper
INFO - 2025-09-17 09:09:03 --> Helper loaded: download_helper
INFO - 2025-09-17 09:09:03 --> Helper loaded: security_helper
INFO - 2025-09-17 09:09:03 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:09:03 --> Form Validation Class Initialized
INFO - 2025-09-17 09:09:03 --> Model "User_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:09:04 --> Controller Class Initialized
INFO - 2025-09-17 14:09:04 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Video_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:09:04 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:09:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:09:04 --> Pagination Class Initialized
INFO - 2025-09-17 14:09:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:09:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:09:04 --> Model "Log_model" initialized
INFO - 2025-09-17 14:09:04 --> Final output sent to browser
DEBUG - 2025-09-17 14:09:04 --> Total execution time: 0.4620
INFO - 2025-09-17 09:10:26 --> Config Class Initialized
INFO - 2025-09-17 09:10:26 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:10:26 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:10:26 --> Utf8 Class Initialized
INFO - 2025-09-17 09:10:26 --> URI Class Initialized
DEBUG - 2025-09-17 09:10:26 --> No URI present. Default controller set.
INFO - 2025-09-17 09:10:26 --> Router Class Initialized
INFO - 2025-09-17 09:10:26 --> Output Class Initialized
INFO - 2025-09-17 09:10:26 --> Security Class Initialized
DEBUG - 2025-09-17 09:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:10:26 --> CSRF cookie sent
INFO - 2025-09-17 09:10:26 --> Input Class Initialized
INFO - 2025-09-17 09:10:26 --> Language Class Initialized
INFO - 2025-09-17 09:10:26 --> Loader Class Initialized
INFO - 2025-09-17 09:10:26 --> Helper loaded: url_helper
INFO - 2025-09-17 09:10:26 --> Helper loaded: text_helper
INFO - 2025-09-17 09:10:26 --> Helper loaded: string_helper
INFO - 2025-09-17 09:10:26 --> Helper loaded: form_helper
INFO - 2025-09-17 09:10:26 --> Helper loaded: download_helper
INFO - 2025-09-17 09:10:26 --> Helper loaded: security_helper
INFO - 2025-09-17 09:10:26 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:10:26 --> Form Validation Class Initialized
INFO - 2025-09-17 09:10:26 --> Model "User_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:10:26 --> Controller Class Initialized
INFO - 2025-09-17 14:10:26 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Video_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:10:26 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:10:26 --> Pagination Class Initialized
INFO - 2025-09-17 14:10:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:10:26 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:10:26 --> Model "Log_model" initialized
INFO - 2025-09-17 14:10:26 --> Final output sent to browser
DEBUG - 2025-09-17 14:10:26 --> Total execution time: 0.2618
INFO - 2025-09-17 09:13:25 --> Config Class Initialized
INFO - 2025-09-17 09:13:25 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:13:25 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:13:25 --> Utf8 Class Initialized
INFO - 2025-09-17 09:13:25 --> URI Class Initialized
DEBUG - 2025-09-17 09:13:25 --> No URI present. Default controller set.
INFO - 2025-09-17 09:13:25 --> Router Class Initialized
INFO - 2025-09-17 09:13:25 --> Output Class Initialized
INFO - 2025-09-17 09:13:25 --> Security Class Initialized
DEBUG - 2025-09-17 09:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:13:25 --> CSRF cookie sent
INFO - 2025-09-17 09:13:25 --> Input Class Initialized
INFO - 2025-09-17 09:13:25 --> Language Class Initialized
INFO - 2025-09-17 09:13:25 --> Loader Class Initialized
INFO - 2025-09-17 09:13:25 --> Helper loaded: url_helper
INFO - 2025-09-17 09:13:25 --> Helper loaded: text_helper
INFO - 2025-09-17 09:13:25 --> Helper loaded: string_helper
INFO - 2025-09-17 09:13:25 --> Helper loaded: form_helper
INFO - 2025-09-17 09:13:25 --> Helper loaded: download_helper
INFO - 2025-09-17 09:13:25 --> Helper loaded: security_helper
INFO - 2025-09-17 09:13:25 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:13:25 --> Form Validation Class Initialized
INFO - 2025-09-17 09:13:25 --> Model "User_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:13:25 --> Controller Class Initialized
INFO - 2025-09-17 14:13:25 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Video_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:13:25 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:13:25 --> Pagination Class Initialized
INFO - 2025-09-17 14:13:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:13:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:13:25 --> Model "Log_model" initialized
INFO - 2025-09-17 14:13:25 --> Final output sent to browser
DEBUG - 2025-09-17 14:13:25 --> Total execution time: 0.2550
INFO - 2025-09-17 09:13:45 --> Config Class Initialized
INFO - 2025-09-17 09:13:45 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:13:45 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:13:45 --> Utf8 Class Initialized
INFO - 2025-09-17 09:13:45 --> URI Class Initialized
DEBUG - 2025-09-17 09:13:45 --> No URI present. Default controller set.
INFO - 2025-09-17 09:13:45 --> Router Class Initialized
INFO - 2025-09-17 09:13:45 --> Output Class Initialized
INFO - 2025-09-17 09:13:45 --> Security Class Initialized
DEBUG - 2025-09-17 09:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:13:45 --> CSRF cookie sent
INFO - 2025-09-17 09:13:45 --> Input Class Initialized
INFO - 2025-09-17 09:13:45 --> Language Class Initialized
INFO - 2025-09-17 09:13:45 --> Loader Class Initialized
INFO - 2025-09-17 09:13:45 --> Helper loaded: url_helper
INFO - 2025-09-17 09:13:45 --> Helper loaded: text_helper
INFO - 2025-09-17 09:13:45 --> Helper loaded: string_helper
INFO - 2025-09-17 09:13:45 --> Helper loaded: form_helper
INFO - 2025-09-17 09:13:45 --> Helper loaded: download_helper
INFO - 2025-09-17 09:13:45 --> Helper loaded: security_helper
INFO - 2025-09-17 09:13:45 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:13:45 --> Form Validation Class Initialized
INFO - 2025-09-17 09:13:46 --> Model "User_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:13:46 --> Controller Class Initialized
INFO - 2025-09-17 14:13:46 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Video_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:13:46 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:13:46 --> Pagination Class Initialized
INFO - 2025-09-17 14:13:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:13:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:13:46 --> Model "Log_model" initialized
INFO - 2025-09-17 14:13:46 --> Final output sent to browser
DEBUG - 2025-09-17 14:13:46 --> Total execution time: 0.3524
INFO - 2025-09-17 09:13:54 --> Config Class Initialized
INFO - 2025-09-17 09:13:54 --> Hooks Class Initialized
INFO - 2025-09-17 09:13:54 --> Config Class Initialized
INFO - 2025-09-17 09:13:54 --> Config Class Initialized
INFO - 2025-09-17 09:13:54 --> Hooks Class Initialized
INFO - 2025-09-17 09:13:54 --> Hooks Class Initialized
INFO - 2025-09-17 09:13:54 --> Config Class Initialized
INFO - 2025-09-17 09:13:54 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:13:54 --> UTF-8 Support Enabled
DEBUG - 2025-09-17 09:13:54 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:13:54 --> Utf8 Class Initialized
INFO - 2025-09-17 09:13:54 --> Utf8 Class Initialized
INFO - 2025-09-17 09:13:54 --> URI Class Initialized
INFO - 2025-09-17 09:13:54 --> URI Class Initialized
DEBUG - 2025-09-17 09:13:54 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:13:54 --> Utf8 Class Initialized
INFO - 2025-09-17 09:13:54 --> URI Class Initialized
INFO - 2025-09-17 09:13:54 --> Router Class Initialized
INFO - 2025-09-17 09:13:54 --> Router Class Initialized
DEBUG - 2025-09-17 09:13:54 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:13:54 --> Utf8 Class Initialized
INFO - 2025-09-17 09:13:54 --> Router Class Initialized
INFO - 2025-09-17 09:13:54 --> URI Class Initialized
INFO - 2025-09-17 09:13:54 --> Output Class Initialized
INFO - 2025-09-17 09:13:54 --> Output Class Initialized
INFO - 2025-09-17 09:13:54 --> Router Class Initialized
INFO - 2025-09-17 09:13:54 --> Security Class Initialized
INFO - 2025-09-17 09:13:54 --> Output Class Initialized
INFO - 2025-09-17 09:13:54 --> Security Class Initialized
DEBUG - 2025-09-17 09:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:13:54 --> Output Class Initialized
INFO - 2025-09-17 09:13:54 --> CSRF cookie sent
INFO - 2025-09-17 09:13:54 --> Security Class Initialized
INFO - 2025-09-17 09:13:54 --> Input Class Initialized
INFO - 2025-09-17 09:13:54 --> Security Class Initialized
DEBUG - 2025-09-17 09:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:13:54 --> CSRF cookie sent
INFO - 2025-09-17 09:13:54 --> Input Class Initialized
INFO - 2025-09-17 09:13:54 --> Language Class Initialized
INFO - 2025-09-17 09:13:54 --> Language Class Initialized
DEBUG - 2025-09-17 09:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-17 09:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:13:54 --> CSRF cookie sent
INFO - 2025-09-17 09:13:54 --> CSRF cookie sent
INFO - 2025-09-17 09:13:54 --> Input Class Initialized
INFO - 2025-09-17 09:13:54 --> Input Class Initialized
INFO - 2025-09-17 09:13:54 --> Loader Class Initialized
INFO - 2025-09-17 09:13:54 --> Language Class Initialized
INFO - 2025-09-17 09:13:54 --> Language Class Initialized
INFO - 2025-09-17 09:13:54 --> Helper loaded: url_helper
INFO - 2025-09-17 09:13:54 --> Loader Class Initialized
INFO - 2025-09-17 09:13:54 --> Loader Class Initialized
INFO - 2025-09-17 09:13:54 --> Helper loaded: text_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: string_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: url_helper
INFO - 2025-09-17 09:13:54 --> Loader Class Initialized
INFO - 2025-09-17 09:13:54 --> Helper loaded: url_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: form_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: text_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: download_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: text_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: string_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: security_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: url_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: string_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: form_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: text_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: form_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: download_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: download_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: security_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: security_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: string_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: form_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: download_helper
INFO - 2025-09-17 09:13:54 --> Helper loaded: security_helper
INFO - 2025-09-17 09:13:54 --> Database Driver Class Initialized
INFO - 2025-09-17 09:13:54 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:13:54 --> Database Driver Class Initialized
INFO - 2025-09-17 09:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:13:54 --> Database Driver Class Initialized
INFO - 2025-09-17 09:13:54 --> Form Validation Class Initialized
DEBUG - 2025-09-17 09:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:13:54 --> Model "User_model" initialized
DEBUG - 2025-09-17 09:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 14:13:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:13:54 --> Controller Class Initialized
INFO - 2025-09-17 14:13:54 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Video_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Jurusan_model" initialized
DEBUG - 2025-09-17 09:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 14:13:54 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:13:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:13:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:13:54 --> Model "Log_model" initialized
INFO - 2025-09-17 14:13:54 --> Final output sent to browser
DEBUG - 2025-09-17 14:13:54 --> Total execution time: 0.1455
INFO - 2025-09-17 09:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:13:54 --> Form Validation Class Initialized
INFO - 2025-09-17 09:13:54 --> Model "User_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:13:54 --> Controller Class Initialized
INFO - 2025-09-17 14:13:54 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Video_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:13:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:13:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:13:54 --> Model "Log_model" initialized
INFO - 2025-09-17 14:13:54 --> Final output sent to browser
DEBUG - 2025-09-17 14:13:54 --> Total execution time: 0.2006
INFO - 2025-09-17 09:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:13:54 --> Form Validation Class Initialized
INFO - 2025-09-17 09:13:54 --> Model "User_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:13:54 --> Controller Class Initialized
INFO - 2025-09-17 14:13:54 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Video_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:13:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:13:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:13:54 --> Model "Log_model" initialized
INFO - 2025-09-17 14:13:54 --> Final output sent to browser
DEBUG - 2025-09-17 14:13:54 --> Total execution time: 0.2611
INFO - 2025-09-17 09:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:13:54 --> Form Validation Class Initialized
INFO - 2025-09-17 09:13:54 --> Model "User_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:13:54 --> Controller Class Initialized
INFO - 2025-09-17 14:13:54 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Video_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:13:54 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:13:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:13:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:13:54 --> Model "Log_model" initialized
INFO - 2025-09-17 14:13:54 --> Final output sent to browser
DEBUG - 2025-09-17 14:13:54 --> Total execution time: 0.3071
INFO - 2025-09-17 09:14:09 --> Config Class Initialized
INFO - 2025-09-17 09:14:09 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:14:09 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:14:09 --> Utf8 Class Initialized
INFO - 2025-09-17 09:14:09 --> URI Class Initialized
DEBUG - 2025-09-17 09:14:09 --> No URI present. Default controller set.
INFO - 2025-09-17 09:14:09 --> Router Class Initialized
INFO - 2025-09-17 09:14:09 --> Output Class Initialized
INFO - 2025-09-17 09:14:09 --> Security Class Initialized
DEBUG - 2025-09-17 09:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:14:09 --> CSRF cookie sent
INFO - 2025-09-17 09:14:09 --> Input Class Initialized
INFO - 2025-09-17 09:14:09 --> Language Class Initialized
INFO - 2025-09-17 09:14:09 --> Loader Class Initialized
INFO - 2025-09-17 09:14:09 --> Helper loaded: url_helper
INFO - 2025-09-17 09:14:09 --> Helper loaded: text_helper
INFO - 2025-09-17 09:14:09 --> Helper loaded: string_helper
INFO - 2025-09-17 09:14:09 --> Helper loaded: form_helper
INFO - 2025-09-17 09:14:09 --> Helper loaded: download_helper
INFO - 2025-09-17 09:14:09 --> Helper loaded: security_helper
INFO - 2025-09-17 09:14:09 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:14:09 --> Form Validation Class Initialized
INFO - 2025-09-17 09:14:09 --> Model "User_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:14:09 --> Controller Class Initialized
INFO - 2025-09-17 14:14:09 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Video_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:14:09 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:14:09 --> Pagination Class Initialized
INFO - 2025-09-17 14:14:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:14:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:14:09 --> Model "Log_model" initialized
INFO - 2025-09-17 14:14:09 --> Final output sent to browser
DEBUG - 2025-09-17 14:14:09 --> Total execution time: 0.1921
INFO - 2025-09-17 09:14:42 --> Config Class Initialized
INFO - 2025-09-17 09:14:42 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:14:42 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:14:42 --> Utf8 Class Initialized
INFO - 2025-09-17 09:14:42 --> URI Class Initialized
DEBUG - 2025-09-17 09:14:42 --> No URI present. Default controller set.
INFO - 2025-09-17 09:14:42 --> Router Class Initialized
INFO - 2025-09-17 09:14:42 --> Output Class Initialized
INFO - 2025-09-17 09:14:42 --> Security Class Initialized
DEBUG - 2025-09-17 09:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:14:42 --> CSRF cookie sent
INFO - 2025-09-17 09:14:42 --> Input Class Initialized
INFO - 2025-09-17 09:14:42 --> Language Class Initialized
INFO - 2025-09-17 09:14:42 --> Loader Class Initialized
INFO - 2025-09-17 09:14:42 --> Helper loaded: url_helper
INFO - 2025-09-17 09:14:42 --> Helper loaded: text_helper
INFO - 2025-09-17 09:14:42 --> Helper loaded: string_helper
INFO - 2025-09-17 09:14:42 --> Helper loaded: form_helper
INFO - 2025-09-17 09:14:42 --> Helper loaded: download_helper
INFO - 2025-09-17 09:14:42 --> Helper loaded: security_helper
INFO - 2025-09-17 09:14:42 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:14:42 --> Form Validation Class Initialized
INFO - 2025-09-17 09:14:42 --> Model "User_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:14:42 --> Controller Class Initialized
INFO - 2025-09-17 14:14:42 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Video_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:14:42 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:14:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:14:42 --> Pagination Class Initialized
INFO - 2025-09-17 14:14:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:14:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:14:42 --> Model "Log_model" initialized
INFO - 2025-09-17 14:14:42 --> Final output sent to browser
DEBUG - 2025-09-17 14:14:42 --> Total execution time: 0.2202
INFO - 2025-09-17 09:14:51 --> Config Class Initialized
INFO - 2025-09-17 09:14:51 --> Hooks Class Initialized
INFO - 2025-09-17 09:14:51 --> Config Class Initialized
INFO - 2025-09-17 09:14:51 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:14:51 --> UTF-8 Support Enabled
DEBUG - 2025-09-17 09:14:51 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:14:51 --> Utf8 Class Initialized
INFO - 2025-09-17 09:14:51 --> Utf8 Class Initialized
INFO - 2025-09-17 09:14:51 --> URI Class Initialized
INFO - 2025-09-17 09:14:51 --> URI Class Initialized
INFO - 2025-09-17 09:14:51 --> Router Class Initialized
INFO - 2025-09-17 09:14:51 --> Router Class Initialized
INFO - 2025-09-17 09:14:51 --> Output Class Initialized
INFO - 2025-09-17 09:14:51 --> Output Class Initialized
INFO - 2025-09-17 09:14:51 --> Security Class Initialized
INFO - 2025-09-17 09:14:51 --> Security Class Initialized
DEBUG - 2025-09-17 09:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-17 09:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:14:51 --> CSRF cookie sent
INFO - 2025-09-17 09:14:51 --> CSRF cookie sent
INFO - 2025-09-17 09:14:51 --> Input Class Initialized
INFO - 2025-09-17 09:14:51 --> Input Class Initialized
INFO - 2025-09-17 09:14:51 --> Language Class Initialized
INFO - 2025-09-17 09:14:51 --> Language Class Initialized
INFO - 2025-09-17 09:14:51 --> Loader Class Initialized
INFO - 2025-09-17 09:14:51 --> Loader Class Initialized
INFO - 2025-09-17 09:14:51 --> Helper loaded: url_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: url_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: text_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: text_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: string_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: string_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: form_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: form_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: download_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: download_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: security_helper
INFO - 2025-09-17 09:14:51 --> Helper loaded: security_helper
INFO - 2025-09-17 09:14:51 --> Database Driver Class Initialized
INFO - 2025-09-17 09:14:51 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-17 09:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:14:51 --> Form Validation Class Initialized
INFO - 2025-09-17 09:14:51 --> Model "User_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:14:51 --> Controller Class Initialized
INFO - 2025-09-17 14:14:51 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Video_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:14:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:14:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:14:51 --> Model "Log_model" initialized
INFO - 2025-09-17 14:14:51 --> Final output sent to browser
DEBUG - 2025-09-17 14:14:51 --> Total execution time: 0.2123
INFO - 2025-09-17 09:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:14:51 --> Form Validation Class Initialized
INFO - 2025-09-17 09:14:51 --> Model "User_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:14:51 --> Controller Class Initialized
INFO - 2025-09-17 14:14:51 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Video_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:14:51 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:14:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:14:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:14:51 --> Model "Log_model" initialized
INFO - 2025-09-17 14:14:51 --> Final output sent to browser
DEBUG - 2025-09-17 14:14:51 --> Total execution time: 0.3101
INFO - 2025-09-17 09:14:53 --> Config Class Initialized
INFO - 2025-09-17 09:14:53 --> Hooks Class Initialized
INFO - 2025-09-17 09:14:53 --> Config Class Initialized
INFO - 2025-09-17 09:14:53 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:14:53 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:14:53 --> Utf8 Class Initialized
DEBUG - 2025-09-17 09:14:53 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:14:53 --> Utf8 Class Initialized
INFO - 2025-09-17 09:14:53 --> URI Class Initialized
INFO - 2025-09-17 09:14:53 --> URI Class Initialized
INFO - 2025-09-17 09:14:53 --> Router Class Initialized
INFO - 2025-09-17 09:14:53 --> Router Class Initialized
INFO - 2025-09-17 09:14:53 --> Output Class Initialized
INFO - 2025-09-17 09:14:53 --> Output Class Initialized
INFO - 2025-09-17 09:14:53 --> Security Class Initialized
INFO - 2025-09-17 09:14:53 --> Security Class Initialized
DEBUG - 2025-09-17 09:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:14:53 --> CSRF cookie sent
DEBUG - 2025-09-17 09:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:14:53 --> Input Class Initialized
INFO - 2025-09-17 09:14:53 --> CSRF cookie sent
INFO - 2025-09-17 09:14:53 --> Input Class Initialized
INFO - 2025-09-17 09:14:53 --> Language Class Initialized
INFO - 2025-09-17 09:14:53 --> Language Class Initialized
INFO - 2025-09-17 09:14:53 --> Loader Class Initialized
INFO - 2025-09-17 09:14:53 --> Loader Class Initialized
INFO - 2025-09-17 09:14:53 --> Helper loaded: url_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: url_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: text_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: text_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: string_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: string_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: form_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: form_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: download_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: download_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: security_helper
INFO - 2025-09-17 09:14:53 --> Helper loaded: security_helper
INFO - 2025-09-17 09:14:53 --> Database Driver Class Initialized
INFO - 2025-09-17 09:14:53 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-17 09:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:14:53 --> Form Validation Class Initialized
INFO - 2025-09-17 09:14:53 --> Model "User_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:14:53 --> Controller Class Initialized
INFO - 2025-09-17 14:14:53 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Video_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:14:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:14:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:14:53 --> Model "Log_model" initialized
INFO - 2025-09-17 14:14:53 --> Final output sent to browser
DEBUG - 2025-09-17 14:14:53 --> Total execution time: 0.2165
INFO - 2025-09-17 09:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:14:53 --> Form Validation Class Initialized
INFO - 2025-09-17 09:14:53 --> Model "User_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:14:53 --> Controller Class Initialized
INFO - 2025-09-17 14:14:53 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Video_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:14:53 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:14:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:14:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:14:53 --> Model "Log_model" initialized
INFO - 2025-09-17 14:14:53 --> Final output sent to browser
DEBUG - 2025-09-17 14:14:53 --> Total execution time: 0.3131
INFO - 2025-09-17 09:15:00 --> Config Class Initialized
INFO - 2025-09-17 09:15:00 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:15:00 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:15:00 --> Utf8 Class Initialized
INFO - 2025-09-17 09:15:00 --> URI Class Initialized
DEBUG - 2025-09-17 09:15:00 --> No URI present. Default controller set.
INFO - 2025-09-17 09:15:00 --> Router Class Initialized
INFO - 2025-09-17 09:15:00 --> Output Class Initialized
INFO - 2025-09-17 09:15:00 --> Security Class Initialized
DEBUG - 2025-09-17 09:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:15:00 --> CSRF cookie sent
INFO - 2025-09-17 09:15:00 --> Input Class Initialized
INFO - 2025-09-17 09:15:00 --> Language Class Initialized
INFO - 2025-09-17 09:15:00 --> Loader Class Initialized
INFO - 2025-09-17 09:15:00 --> Helper loaded: url_helper
INFO - 2025-09-17 09:15:00 --> Helper loaded: text_helper
INFO - 2025-09-17 09:15:00 --> Helper loaded: string_helper
INFO - 2025-09-17 09:15:00 --> Helper loaded: form_helper
INFO - 2025-09-17 09:15:00 --> Helper loaded: download_helper
INFO - 2025-09-17 09:15:00 --> Helper loaded: security_helper
INFO - 2025-09-17 09:15:00 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:15:00 --> Form Validation Class Initialized
INFO - 2025-09-17 09:15:00 --> Model "User_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:15:00 --> Controller Class Initialized
INFO - 2025-09-17 14:15:00 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Video_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:15:00 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:15:00 --> Pagination Class Initialized
INFO - 2025-09-17 14:15:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:15:00 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:15:00 --> Model "Log_model" initialized
INFO - 2025-09-17 14:15:00 --> Final output sent to browser
DEBUG - 2025-09-17 14:15:00 --> Total execution time: 0.3350
INFO - 2025-09-17 09:15:02 --> Config Class Initialized
INFO - 2025-09-17 09:15:02 --> Hooks Class Initialized
INFO - 2025-09-17 09:15:02 --> Config Class Initialized
INFO - 2025-09-17 09:15:02 --> Hooks Class Initialized
INFO - 2025-09-17 09:15:02 --> Config Class Initialized
INFO - 2025-09-17 09:15:02 --> Config Class Initialized
INFO - 2025-09-17 09:15:02 --> Hooks Class Initialized
INFO - 2025-09-17 09:15:02 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:15:02 --> UTF-8 Support Enabled
DEBUG - 2025-09-17 09:15:02 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:15:02 --> Utf8 Class Initialized
INFO - 2025-09-17 09:15:02 --> Utf8 Class Initialized
DEBUG - 2025-09-17 09:15:02 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:15:02 --> Utf8 Class Initialized
INFO - 2025-09-17 09:15:02 --> URI Class Initialized
DEBUG - 2025-09-17 09:15:02 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:15:02 --> Utf8 Class Initialized
INFO - 2025-09-17 09:15:02 --> URI Class Initialized
INFO - 2025-09-17 09:15:02 --> URI Class Initialized
INFO - 2025-09-17 09:15:02 --> URI Class Initialized
INFO - 2025-09-17 09:15:02 --> Router Class Initialized
INFO - 2025-09-17 09:15:02 --> Router Class Initialized
INFO - 2025-09-17 09:15:02 --> Router Class Initialized
INFO - 2025-09-17 09:15:02 --> Router Class Initialized
INFO - 2025-09-17 09:15:02 --> Output Class Initialized
INFO - 2025-09-17 09:15:02 --> Output Class Initialized
INFO - 2025-09-17 09:15:02 --> Output Class Initialized
INFO - 2025-09-17 09:15:02 --> Security Class Initialized
INFO - 2025-09-17 09:15:02 --> Security Class Initialized
INFO - 2025-09-17 09:15:02 --> Security Class Initialized
INFO - 2025-09-17 09:15:02 --> Output Class Initialized
DEBUG - 2025-09-17 09:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:15:02 --> Security Class Initialized
INFO - 2025-09-17 09:15:02 --> CSRF cookie sent
DEBUG - 2025-09-17 09:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-17 09:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:15:02 --> Input Class Initialized
INFO - 2025-09-17 09:15:02 --> CSRF cookie sent
INFO - 2025-09-17 09:15:02 --> CSRF cookie sent
DEBUG - 2025-09-17 09:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:15:02 --> Input Class Initialized
INFO - 2025-09-17 09:15:02 --> Input Class Initialized
INFO - 2025-09-17 09:15:02 --> Language Class Initialized
INFO - 2025-09-17 09:15:02 --> CSRF cookie sent
INFO - 2025-09-17 09:15:02 --> Input Class Initialized
INFO - 2025-09-17 09:15:02 --> Language Class Initialized
INFO - 2025-09-17 09:15:02 --> Language Class Initialized
INFO - 2025-09-17 09:15:02 --> Language Class Initialized
INFO - 2025-09-17 09:15:02 --> Loader Class Initialized
INFO - 2025-09-17 09:15:02 --> Loader Class Initialized
INFO - 2025-09-17 09:15:02 --> Helper loaded: url_helper
INFO - 2025-09-17 09:15:02 --> Loader Class Initialized
INFO - 2025-09-17 09:15:02 --> Loader Class Initialized
INFO - 2025-09-17 09:15:02 --> Helper loaded: text_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: url_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: string_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: text_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: url_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: url_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: form_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: string_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: text_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: text_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: download_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: string_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: string_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: security_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: form_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: form_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: form_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: download_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: download_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: download_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: security_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: security_helper
INFO - 2025-09-17 09:15:02 --> Helper loaded: security_helper
INFO - 2025-09-17 09:15:02 --> Database Driver Class Initialized
INFO - 2025-09-17 09:15:02 --> Database Driver Class Initialized
INFO - 2025-09-17 09:15:02 --> Database Driver Class Initialized
INFO - 2025-09-17 09:15:02 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:15:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-09-17 09:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-17 09:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-17 09:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:15:02 --> Form Validation Class Initialized
INFO - 2025-09-17 09:15:02 --> Model "User_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:15:02 --> Controller Class Initialized
INFO - 2025-09-17 14:15:02 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Video_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:15:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:15:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:15:02 --> Model "Log_model" initialized
INFO - 2025-09-17 14:15:02 --> Final output sent to browser
DEBUG - 2025-09-17 14:15:02 --> Total execution time: 0.1693
INFO - 2025-09-17 09:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:15:02 --> Form Validation Class Initialized
INFO - 2025-09-17 09:15:02 --> Model "User_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:15:02 --> Controller Class Initialized
INFO - 2025-09-17 14:15:02 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Video_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:15:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:15:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:15:02 --> Model "Log_model" initialized
INFO - 2025-09-17 14:15:02 --> Final output sent to browser
DEBUG - 2025-09-17 14:15:02 --> Total execution time: 0.2504
INFO - 2025-09-17 09:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:15:02 --> Form Validation Class Initialized
INFO - 2025-09-17 09:15:02 --> Model "User_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:15:02 --> Controller Class Initialized
INFO - 2025-09-17 14:15:02 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Video_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:15:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:15:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:15:02 --> Model "Log_model" initialized
INFO - 2025-09-17 14:15:02 --> Final output sent to browser
DEBUG - 2025-09-17 14:15:02 --> Total execution time: 0.3221
INFO - 2025-09-17 09:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:15:02 --> Form Validation Class Initialized
INFO - 2025-09-17 09:15:02 --> Model "User_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:15:02 --> Controller Class Initialized
INFO - 2025-09-17 14:15:02 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Video_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:15:02 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:15:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:15:02 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:15:02 --> Model "Log_model" initialized
INFO - 2025-09-17 14:15:02 --> Final output sent to browser
DEBUG - 2025-09-17 14:15:02 --> Total execution time: 0.3897
INFO - 2025-09-17 09:15:06 --> Config Class Initialized
INFO - 2025-09-17 09:15:06 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:15:06 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:15:06 --> Utf8 Class Initialized
INFO - 2025-09-17 09:15:06 --> URI Class Initialized
DEBUG - 2025-09-17 09:15:06 --> No URI present. Default controller set.
INFO - 2025-09-17 09:15:06 --> Router Class Initialized
INFO - 2025-09-17 09:15:06 --> Output Class Initialized
INFO - 2025-09-17 09:15:06 --> Security Class Initialized
DEBUG - 2025-09-17 09:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:15:06 --> CSRF cookie sent
INFO - 2025-09-17 09:15:06 --> Input Class Initialized
INFO - 2025-09-17 09:15:06 --> Language Class Initialized
INFO - 2025-09-17 09:15:06 --> Loader Class Initialized
INFO - 2025-09-17 09:15:06 --> Helper loaded: url_helper
INFO - 2025-09-17 09:15:06 --> Helper loaded: text_helper
INFO - 2025-09-17 09:15:06 --> Helper loaded: string_helper
INFO - 2025-09-17 09:15:06 --> Helper loaded: form_helper
INFO - 2025-09-17 09:15:06 --> Helper loaded: download_helper
INFO - 2025-09-17 09:15:06 --> Helper loaded: security_helper
INFO - 2025-09-17 09:15:06 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:15:06 --> Form Validation Class Initialized
INFO - 2025-09-17 09:15:06 --> Model "User_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:15:06 --> Controller Class Initialized
INFO - 2025-09-17 14:15:06 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Video_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:15:06 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:15:06 --> Pagination Class Initialized
INFO - 2025-09-17 14:15:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:15:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:15:06 --> Model "Log_model" initialized
INFO - 2025-09-17 14:15:06 --> Final output sent to browser
DEBUG - 2025-09-17 14:15:06 --> Total execution time: 0.3274
INFO - 2025-09-17 09:19:36 --> Config Class Initialized
INFO - 2025-09-17 09:19:36 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:19:36 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:19:36 --> Utf8 Class Initialized
INFO - 2025-09-17 09:19:36 --> URI Class Initialized
DEBUG - 2025-09-17 09:19:36 --> No URI present. Default controller set.
INFO - 2025-09-17 09:19:36 --> Router Class Initialized
INFO - 2025-09-17 09:19:36 --> Output Class Initialized
INFO - 2025-09-17 09:19:36 --> Security Class Initialized
DEBUG - 2025-09-17 09:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:19:36 --> CSRF cookie sent
INFO - 2025-09-17 09:19:36 --> Input Class Initialized
INFO - 2025-09-17 09:19:36 --> Language Class Initialized
INFO - 2025-09-17 09:19:36 --> Loader Class Initialized
INFO - 2025-09-17 09:19:36 --> Helper loaded: url_helper
INFO - 2025-09-17 09:19:36 --> Helper loaded: text_helper
INFO - 2025-09-17 09:19:36 --> Helper loaded: string_helper
INFO - 2025-09-17 09:19:36 --> Helper loaded: form_helper
INFO - 2025-09-17 09:19:36 --> Helper loaded: download_helper
INFO - 2025-09-17 09:19:36 --> Helper loaded: security_helper
INFO - 2025-09-17 09:19:36 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:19:36 --> Form Validation Class Initialized
INFO - 2025-09-17 09:19:36 --> Model "User_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:19:36 --> Controller Class Initialized
INFO - 2025-09-17 14:19:36 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Video_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:19:36 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:19:36 --> Pagination Class Initialized
INFO - 2025-09-17 14:19:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:19:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:19:36 --> Model "Log_model" initialized
INFO - 2025-09-17 14:19:36 --> Final output sent to browser
DEBUG - 2025-09-17 14:19:36 --> Total execution time: 0.2470
INFO - 2025-09-17 09:19:46 --> Config Class Initialized
INFO - 2025-09-17 09:19:46 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:19:46 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:19:46 --> Utf8 Class Initialized
INFO - 2025-09-17 09:19:46 --> URI Class Initialized
DEBUG - 2025-09-17 09:19:46 --> No URI present. Default controller set.
INFO - 2025-09-17 09:19:46 --> Router Class Initialized
INFO - 2025-09-17 09:19:46 --> Output Class Initialized
INFO - 2025-09-17 09:19:46 --> Security Class Initialized
DEBUG - 2025-09-17 09:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:19:46 --> CSRF cookie sent
INFO - 2025-09-17 09:19:46 --> Input Class Initialized
INFO - 2025-09-17 09:19:46 --> Language Class Initialized
INFO - 2025-09-17 09:19:46 --> Loader Class Initialized
INFO - 2025-09-17 09:19:46 --> Helper loaded: url_helper
INFO - 2025-09-17 09:19:46 --> Helper loaded: text_helper
INFO - 2025-09-17 09:19:46 --> Helper loaded: string_helper
INFO - 2025-09-17 09:19:46 --> Helper loaded: form_helper
INFO - 2025-09-17 09:19:46 --> Helper loaded: download_helper
INFO - 2025-09-17 09:19:46 --> Helper loaded: security_helper
INFO - 2025-09-17 09:19:46 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:19:46 --> Form Validation Class Initialized
INFO - 2025-09-17 09:19:46 --> Model "User_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:19:46 --> Controller Class Initialized
INFO - 2025-09-17 14:19:46 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Video_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:19:46 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:19:46 --> Pagination Class Initialized
INFO - 2025-09-17 14:19:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:19:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:19:46 --> Model "Log_model" initialized
INFO - 2025-09-17 14:19:46 --> Final output sent to browser
DEBUG - 2025-09-17 14:19:46 --> Total execution time: 0.3359
INFO - 2025-09-17 09:20:03 --> Config Class Initialized
INFO - 2025-09-17 09:20:03 --> Config Class Initialized
INFO - 2025-09-17 09:20:03 --> Hooks Class Initialized
INFO - 2025-09-17 09:20:03 --> Hooks Class Initialized
INFO - 2025-09-17 09:20:03 --> Config Class Initialized
INFO - 2025-09-17 09:20:03 --> Config Class Initialized
INFO - 2025-09-17 09:20:03 --> Hooks Class Initialized
INFO - 2025-09-17 09:20:03 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:20:03 --> UTF-8 Support Enabled
DEBUG - 2025-09-17 09:20:03 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:20:03 --> Utf8 Class Initialized
INFO - 2025-09-17 09:20:03 --> Utf8 Class Initialized
DEBUG - 2025-09-17 09:20:03 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:20:03 --> Utf8 Class Initialized
DEBUG - 2025-09-17 09:20:03 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:20:03 --> URI Class Initialized
INFO - 2025-09-17 09:20:03 --> URI Class Initialized
INFO - 2025-09-17 09:20:03 --> Utf8 Class Initialized
INFO - 2025-09-17 09:20:03 --> URI Class Initialized
INFO - 2025-09-17 09:20:03 --> Router Class Initialized
INFO - 2025-09-17 09:20:03 --> URI Class Initialized
INFO - 2025-09-17 09:20:03 --> Router Class Initialized
INFO - 2025-09-17 09:20:03 --> Router Class Initialized
INFO - 2025-09-17 09:20:03 --> Router Class Initialized
INFO - 2025-09-17 09:20:03 --> Output Class Initialized
INFO - 2025-09-17 09:20:03 --> Output Class Initialized
INFO - 2025-09-17 09:20:03 --> Output Class Initialized
INFO - 2025-09-17 09:20:03 --> Output Class Initialized
INFO - 2025-09-17 09:20:03 --> Security Class Initialized
INFO - 2025-09-17 09:20:03 --> Security Class Initialized
INFO - 2025-09-17 09:20:03 --> Security Class Initialized
INFO - 2025-09-17 09:20:03 --> Security Class Initialized
DEBUG - 2025-09-17 09:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-17 09:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:20:03 --> CSRF cookie sent
INFO - 2025-09-17 09:20:03 --> CSRF cookie sent
INFO - 2025-09-17 09:20:03 --> Input Class Initialized
INFO - 2025-09-17 09:20:03 --> Input Class Initialized
DEBUG - 2025-09-17 09:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-17 09:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:20:03 --> Language Class Initialized
INFO - 2025-09-17 09:20:03 --> CSRF cookie sent
INFO - 2025-09-17 09:20:03 --> CSRF cookie sent
INFO - 2025-09-17 09:20:03 --> Language Class Initialized
INFO - 2025-09-17 09:20:03 --> Input Class Initialized
INFO - 2025-09-17 09:20:03 --> Input Class Initialized
INFO - 2025-09-17 09:20:03 --> Language Class Initialized
INFO - 2025-09-17 09:20:03 --> Language Class Initialized
INFO - 2025-09-17 09:20:03 --> Loader Class Initialized
INFO - 2025-09-17 09:20:03 --> Loader Class Initialized
INFO - 2025-09-17 09:20:03 --> Loader Class Initialized
INFO - 2025-09-17 09:20:03 --> Loader Class Initialized
INFO - 2025-09-17 09:20:03 --> Helper loaded: url_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: url_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: text_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: text_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: url_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: url_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: string_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: string_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: text_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: text_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: form_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: form_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: string_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: string_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: download_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: download_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: security_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: form_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: security_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: form_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: download_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: download_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: security_helper
INFO - 2025-09-17 09:20:03 --> Helper loaded: security_helper
INFO - 2025-09-17 09:20:03 --> Database Driver Class Initialized
INFO - 2025-09-17 09:20:03 --> Database Driver Class Initialized
INFO - 2025-09-17 09:20:03 --> Database Driver Class Initialized
INFO - 2025-09-17 09:20:03 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-17 09:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:20:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-09-17 09:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:20:03 --> Form Validation Class Initialized
INFO - 2025-09-17 09:20:03 --> Model "User_model" initialized
DEBUG - 2025-09-17 09:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 14:20:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:20:03 --> Controller Class Initialized
INFO - 2025-09-17 14:20:03 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Video_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:20:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:20:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:20:03 --> Model "Log_model" initialized
INFO - 2025-09-17 14:20:03 --> Final output sent to browser
DEBUG - 2025-09-17 14:20:03 --> Total execution time: 0.2819
INFO - 2025-09-17 09:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:20:03 --> Form Validation Class Initialized
INFO - 2025-09-17 09:20:03 --> Model "User_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:20:03 --> Controller Class Initialized
INFO - 2025-09-17 14:20:03 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Video_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:20:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:20:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:20:03 --> Model "Log_model" initialized
INFO - 2025-09-17 14:20:03 --> Final output sent to browser
DEBUG - 2025-09-17 14:20:03 --> Total execution time: 0.4396
INFO - 2025-09-17 09:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:20:03 --> Form Validation Class Initialized
INFO - 2025-09-17 09:20:03 --> Model "User_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:20:03 --> Controller Class Initialized
INFO - 2025-09-17 14:20:03 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Video_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:20:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:20:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:20:03 --> Model "Log_model" initialized
INFO - 2025-09-17 14:20:03 --> Final output sent to browser
DEBUG - 2025-09-17 14:20:03 --> Total execution time: 0.5975
INFO - 2025-09-17 09:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:20:03 --> Form Validation Class Initialized
INFO - 2025-09-17 09:20:03 --> Model "User_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:20:03 --> Controller Class Initialized
INFO - 2025-09-17 14:20:03 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Video_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:20:03 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:20:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-09-17 14:20:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:20:03 --> Model "Log_model" initialized
INFO - 2025-09-17 14:20:03 --> Final output sent to browser
DEBUG - 2025-09-17 14:20:03 --> Total execution time: 0.7007
INFO - 2025-09-17 09:20:05 --> Config Class Initialized
INFO - 2025-09-17 09:20:05 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:20:05 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:20:05 --> Utf8 Class Initialized
INFO - 2025-09-17 09:20:05 --> URI Class Initialized
DEBUG - 2025-09-17 09:20:05 --> No URI present. Default controller set.
INFO - 2025-09-17 09:20:05 --> Router Class Initialized
INFO - 2025-09-17 09:20:05 --> Output Class Initialized
INFO - 2025-09-17 09:20:05 --> Security Class Initialized
DEBUG - 2025-09-17 09:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:20:05 --> CSRF cookie sent
INFO - 2025-09-17 09:20:05 --> Input Class Initialized
INFO - 2025-09-17 09:20:05 --> Language Class Initialized
INFO - 2025-09-17 09:20:05 --> Loader Class Initialized
INFO - 2025-09-17 09:20:05 --> Helper loaded: url_helper
INFO - 2025-09-17 09:20:05 --> Helper loaded: text_helper
INFO - 2025-09-17 09:20:05 --> Helper loaded: string_helper
INFO - 2025-09-17 09:20:05 --> Helper loaded: form_helper
INFO - 2025-09-17 09:20:05 --> Helper loaded: download_helper
INFO - 2025-09-17 09:20:05 --> Helper loaded: security_helper
INFO - 2025-09-17 09:20:05 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:20:05 --> Form Validation Class Initialized
INFO - 2025-09-17 09:20:05 --> Model "User_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:20:05 --> Controller Class Initialized
INFO - 2025-09-17 14:20:05 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Video_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:20:05 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:20:05 --> Pagination Class Initialized
INFO - 2025-09-17 14:20:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:20:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:20:05 --> Model "Log_model" initialized
INFO - 2025-09-17 14:20:05 --> Final output sent to browser
DEBUG - 2025-09-17 14:20:05 --> Total execution time: 0.3438
INFO - 2025-09-17 09:20:11 --> Config Class Initialized
INFO - 2025-09-17 09:20:11 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:20:11 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:20:11 --> Utf8 Class Initialized
INFO - 2025-09-17 09:20:11 --> URI Class Initialized
DEBUG - 2025-09-17 09:20:11 --> No URI present. Default controller set.
INFO - 2025-09-17 09:20:11 --> Router Class Initialized
INFO - 2025-09-17 09:20:11 --> Output Class Initialized
INFO - 2025-09-17 09:20:11 --> Security Class Initialized
DEBUG - 2025-09-17 09:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:20:11 --> CSRF cookie sent
INFO - 2025-09-17 09:20:11 --> Input Class Initialized
INFO - 2025-09-17 09:20:11 --> Language Class Initialized
INFO - 2025-09-17 09:20:11 --> Loader Class Initialized
INFO - 2025-09-17 09:20:11 --> Helper loaded: url_helper
INFO - 2025-09-17 09:20:11 --> Helper loaded: text_helper
INFO - 2025-09-17 09:20:11 --> Helper loaded: string_helper
INFO - 2025-09-17 09:20:11 --> Helper loaded: form_helper
INFO - 2025-09-17 09:20:11 --> Helper loaded: download_helper
INFO - 2025-09-17 09:20:11 --> Helper loaded: security_helper
INFO - 2025-09-17 09:20:11 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:20:11 --> Form Validation Class Initialized
INFO - 2025-09-17 09:20:11 --> Model "User_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:20:11 --> Controller Class Initialized
INFO - 2025-09-17 14:20:11 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Video_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:20:11 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:20:11 --> Pagination Class Initialized
INFO - 2025-09-17 14:20:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:20:11 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:20:11 --> Model "Log_model" initialized
INFO - 2025-09-17 14:20:11 --> Final output sent to browser
DEBUG - 2025-09-17 14:20:11 --> Total execution time: 0.3468
INFO - 2025-09-17 09:27:57 --> Config Class Initialized
INFO - 2025-09-17 09:27:57 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:27:57 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:27:57 --> Utf8 Class Initialized
INFO - 2025-09-17 09:27:57 --> URI Class Initialized
DEBUG - 2025-09-17 09:27:57 --> No URI present. Default controller set.
INFO - 2025-09-17 09:27:57 --> Router Class Initialized
INFO - 2025-09-17 09:27:57 --> Output Class Initialized
INFO - 2025-09-17 09:27:57 --> Security Class Initialized
DEBUG - 2025-09-17 09:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:27:57 --> CSRF cookie sent
INFO - 2025-09-17 09:27:57 --> Input Class Initialized
INFO - 2025-09-17 09:27:57 --> Language Class Initialized
INFO - 2025-09-17 09:27:57 --> Loader Class Initialized
INFO - 2025-09-17 09:27:57 --> Helper loaded: url_helper
INFO - 2025-09-17 09:27:57 --> Helper loaded: text_helper
INFO - 2025-09-17 09:27:57 --> Helper loaded: string_helper
INFO - 2025-09-17 09:27:57 --> Helper loaded: form_helper
INFO - 2025-09-17 09:27:57 --> Helper loaded: download_helper
INFO - 2025-09-17 09:27:57 --> Helper loaded: security_helper
INFO - 2025-09-17 09:27:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:27:57 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:27:57 --> Form Validation Class Initialized
INFO - 2025-09-17 09:27:57 --> Model "User_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:27:57 --> Controller Class Initialized
INFO - 2025-09-17 14:27:57 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Video_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:27:57 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:27:57 --> Pagination Class Initialized
INFO - 2025-09-17 14:27:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:27:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:27:57 --> Model "Log_model" initialized
INFO - 2025-09-17 14:27:57 --> Final output sent to browser
DEBUG - 2025-09-17 14:27:57 --> Total execution time: 0.3844
INFO - 2025-09-17 09:28:01 --> Config Class Initialized
INFO - 2025-09-17 09:28:01 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:28:01 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:28:01 --> Utf8 Class Initialized
INFO - 2025-09-17 09:28:01 --> URI Class Initialized
DEBUG - 2025-09-17 09:28:01 --> No URI present. Default controller set.
INFO - 2025-09-17 09:28:01 --> Router Class Initialized
INFO - 2025-09-17 09:28:01 --> Output Class Initialized
INFO - 2025-09-17 09:28:01 --> Security Class Initialized
DEBUG - 2025-09-17 09:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:28:01 --> CSRF cookie sent
INFO - 2025-09-17 09:28:01 --> Input Class Initialized
INFO - 2025-09-17 09:28:01 --> Language Class Initialized
INFO - 2025-09-17 09:28:01 --> Loader Class Initialized
INFO - 2025-09-17 09:28:01 --> Helper loaded: url_helper
INFO - 2025-09-17 09:28:01 --> Helper loaded: text_helper
INFO - 2025-09-17 09:28:01 --> Helper loaded: string_helper
INFO - 2025-09-17 09:28:01 --> Helper loaded: form_helper
INFO - 2025-09-17 09:28:01 --> Helper loaded: download_helper
INFO - 2025-09-17 09:28:01 --> Helper loaded: security_helper
INFO - 2025-09-17 09:28:01 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:28:01 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:28:01 --> Form Validation Class Initialized
INFO - 2025-09-17 09:28:01 --> Model "User_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:28:01 --> Controller Class Initialized
INFO - 2025-09-17 14:28:01 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Video_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:28:01 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:28:01 --> Pagination Class Initialized
INFO - 2025-09-17 14:28:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:28:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:28:01 --> Model "Log_model" initialized
INFO - 2025-09-17 14:28:01 --> Final output sent to browser
DEBUG - 2025-09-17 14:28:01 --> Total execution time: 0.1919
INFO - 2025-09-17 09:28:36 --> Config Class Initialized
INFO - 2025-09-17 09:28:36 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:28:36 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:28:36 --> Utf8 Class Initialized
INFO - 2025-09-17 09:28:36 --> URI Class Initialized
DEBUG - 2025-09-17 09:28:36 --> No URI present. Default controller set.
INFO - 2025-09-17 09:28:36 --> Router Class Initialized
INFO - 2025-09-17 09:28:36 --> Output Class Initialized
INFO - 2025-09-17 09:28:36 --> Security Class Initialized
DEBUG - 2025-09-17 09:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:28:36 --> CSRF cookie sent
INFO - 2025-09-17 09:28:36 --> Input Class Initialized
INFO - 2025-09-17 09:28:36 --> Language Class Initialized
INFO - 2025-09-17 09:28:36 --> Loader Class Initialized
INFO - 2025-09-17 09:28:36 --> Helper loaded: url_helper
INFO - 2025-09-17 09:28:36 --> Helper loaded: text_helper
INFO - 2025-09-17 09:28:36 --> Helper loaded: string_helper
INFO - 2025-09-17 09:28:36 --> Helper loaded: form_helper
INFO - 2025-09-17 09:28:36 --> Helper loaded: download_helper
INFO - 2025-09-17 09:28:36 --> Helper loaded: security_helper
INFO - 2025-09-17 09:28:36 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:28:36 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:28:36 --> Form Validation Class Initialized
INFO - 2025-09-17 09:28:36 --> Model "User_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:28:36 --> Controller Class Initialized
INFO - 2025-09-17 14:28:36 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Video_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:28:36 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:28:36 --> Pagination Class Initialized
INFO - 2025-09-17 14:28:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:28:36 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:28:36 --> Model "Log_model" initialized
INFO - 2025-09-17 14:28:36 --> Final output sent to browser
DEBUG - 2025-09-17 14:28:36 --> Total execution time: 0.1806
INFO - 2025-09-17 09:30:21 --> Config Class Initialized
INFO - 2025-09-17 09:30:21 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:30:21 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:30:21 --> Utf8 Class Initialized
INFO - 2025-09-17 09:30:21 --> URI Class Initialized
DEBUG - 2025-09-17 09:30:21 --> No URI present. Default controller set.
INFO - 2025-09-17 09:30:21 --> Router Class Initialized
INFO - 2025-09-17 09:30:21 --> Output Class Initialized
INFO - 2025-09-17 09:30:21 --> Security Class Initialized
DEBUG - 2025-09-17 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:30:21 --> CSRF cookie sent
INFO - 2025-09-17 09:30:21 --> Input Class Initialized
INFO - 2025-09-17 09:30:21 --> Language Class Initialized
INFO - 2025-09-17 09:30:21 --> Loader Class Initialized
INFO - 2025-09-17 09:30:21 --> Helper loaded: url_helper
INFO - 2025-09-17 09:30:21 --> Helper loaded: text_helper
INFO - 2025-09-17 09:30:21 --> Helper loaded: string_helper
INFO - 2025-09-17 09:30:21 --> Helper loaded: form_helper
INFO - 2025-09-17 09:30:21 --> Helper loaded: download_helper
INFO - 2025-09-17 09:30:21 --> Helper loaded: security_helper
INFO - 2025-09-17 09:30:21 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:30:21 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:30:21 --> Form Validation Class Initialized
INFO - 2025-09-17 09:30:21 --> Model "User_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:30:21 --> Controller Class Initialized
INFO - 2025-09-17 14:30:21 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Video_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:30:21 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:30:21 --> Pagination Class Initialized
INFO - 2025-09-17 14:30:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:30:21 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:30:21 --> Model "Log_model" initialized
INFO - 2025-09-17 14:30:21 --> Final output sent to browser
DEBUG - 2025-09-17 14:30:21 --> Total execution time: 0.2933
INFO - 2025-09-17 09:30:30 --> Config Class Initialized
INFO - 2025-09-17 09:30:30 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:30:30 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:30:30 --> Utf8 Class Initialized
INFO - 2025-09-17 09:30:30 --> URI Class Initialized
DEBUG - 2025-09-17 09:30:30 --> No URI present. Default controller set.
INFO - 2025-09-17 09:30:30 --> Router Class Initialized
INFO - 2025-09-17 09:30:30 --> Output Class Initialized
INFO - 2025-09-17 09:30:30 --> Security Class Initialized
DEBUG - 2025-09-17 09:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:30:30 --> CSRF cookie sent
INFO - 2025-09-17 09:30:30 --> Input Class Initialized
INFO - 2025-09-17 09:30:30 --> Language Class Initialized
INFO - 2025-09-17 09:30:30 --> Loader Class Initialized
INFO - 2025-09-17 09:30:30 --> Helper loaded: url_helper
INFO - 2025-09-17 09:30:30 --> Helper loaded: text_helper
INFO - 2025-09-17 09:30:30 --> Helper loaded: string_helper
INFO - 2025-09-17 09:30:30 --> Helper loaded: form_helper
INFO - 2025-09-17 09:30:30 --> Helper loaded: download_helper
INFO - 2025-09-17 09:30:30 --> Helper loaded: security_helper
INFO - 2025-09-17 09:30:30 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:30:30 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:30:30 --> Form Validation Class Initialized
INFO - 2025-09-17 09:30:30 --> Model "User_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:30:30 --> Controller Class Initialized
INFO - 2025-09-17 14:30:30 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Video_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:30:30 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:30:30 --> Pagination Class Initialized
INFO - 2025-09-17 14:30:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:30:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:30:31 --> Model "Log_model" initialized
INFO - 2025-09-17 14:30:31 --> Final output sent to browser
DEBUG - 2025-09-17 14:30:31 --> Total execution time: 0.3304
INFO - 2025-09-17 09:32:54 --> Config Class Initialized
INFO - 2025-09-17 09:32:54 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:32:54 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:32:54 --> Utf8 Class Initialized
INFO - 2025-09-17 09:32:54 --> URI Class Initialized
INFO - 2025-09-17 09:32:54 --> Router Class Initialized
INFO - 2025-09-17 09:32:54 --> Output Class Initialized
INFO - 2025-09-17 09:32:54 --> Security Class Initialized
DEBUG - 2025-09-17 09:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:32:54 --> CSRF cookie sent
INFO - 2025-09-17 09:32:54 --> Input Class Initialized
INFO - 2025-09-17 09:32:54 --> Language Class Initialized
INFO - 2025-09-17 09:32:54 --> Loader Class Initialized
INFO - 2025-09-17 09:32:54 --> Helper loaded: url_helper
INFO - 2025-09-17 09:32:54 --> Helper loaded: text_helper
INFO - 2025-09-17 09:32:54 --> Helper loaded: string_helper
INFO - 2025-09-17 09:32:54 --> Helper loaded: form_helper
INFO - 2025-09-17 09:32:54 --> Helper loaded: download_helper
INFO - 2025-09-17 09:32:54 --> Helper loaded: security_helper
INFO - 2025-09-17 09:32:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:32:54 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:32:54 --> Form Validation Class Initialized
INFO - 2025-09-17 09:32:54 --> Model "User_model" initialized
INFO - 2025-09-17 14:32:54 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:32:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:32:54 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:32:54 --> Controller Class Initialized
DEBUG - 2025-09-17 14:32:54 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-17 14:32:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-09-17 14:32:54 --> Model "Log_model" initialized
INFO - 2025-09-17 14:32:54 --> Final output sent to browser
DEBUG - 2025-09-17 14:32:54 --> Total execution time: 0.1327
INFO - 2025-09-17 09:33:06 --> Config Class Initialized
INFO - 2025-09-17 09:33:06 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:33:06 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:33:06 --> Utf8 Class Initialized
INFO - 2025-09-17 09:33:06 --> URI Class Initialized
INFO - 2025-09-17 09:33:06 --> Router Class Initialized
INFO - 2025-09-17 09:33:06 --> Output Class Initialized
INFO - 2025-09-17 09:33:06 --> Security Class Initialized
DEBUG - 2025-09-17 09:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:33:06 --> CSRF cookie sent
INFO - 2025-09-17 09:33:06 --> CSRF token verified
INFO - 2025-09-17 09:33:06 --> Input Class Initialized
INFO - 2025-09-17 09:33:06 --> Language Class Initialized
INFO - 2025-09-17 09:33:06 --> Loader Class Initialized
INFO - 2025-09-17 09:33:06 --> Helper loaded: url_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: text_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: string_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: form_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: download_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: security_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:33:06 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:33:06 --> Form Validation Class Initialized
INFO - 2025-09-17 09:33:06 --> Model "User_model" initialized
INFO - 2025-09-17 14:33:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:33:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:33:06 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:33:06 --> Controller Class Initialized
DEBUG - 2025-09-17 14:33:06 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-09-17 14:33:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-09-17 09:33:06 --> Config Class Initialized
INFO - 2025-09-17 09:33:06 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:33:06 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:33:06 --> Utf8 Class Initialized
INFO - 2025-09-17 09:33:06 --> URI Class Initialized
INFO - 2025-09-17 09:33:06 --> Router Class Initialized
INFO - 2025-09-17 09:33:06 --> Output Class Initialized
INFO - 2025-09-17 09:33:06 --> Security Class Initialized
DEBUG - 2025-09-17 09:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:33:06 --> CSRF cookie sent
INFO - 2025-09-17 09:33:06 --> Input Class Initialized
INFO - 2025-09-17 09:33:06 --> Language Class Initialized
INFO - 2025-09-17 09:33:06 --> Loader Class Initialized
INFO - 2025-09-17 09:33:06 --> Helper loaded: url_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: text_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: string_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: form_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: download_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: security_helper
INFO - 2025-09-17 09:33:06 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:33:06 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:33:06 --> Form Validation Class Initialized
INFO - 2025-09-17 09:33:06 --> Model "User_model" initialized
INFO - 2025-09-17 14:33:06 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:33:06 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:33:06 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:33:06 --> Controller Class Initialized
INFO - 2025-09-17 14:33:06 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:33:06 --> Model "Staff_model" initialized
INFO - 2025-09-17 14:33:06 --> Model "Dasbor_model" initialized
INFO - 2025-09-17 14:33:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-09-17 14:33:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-09-17 14:33:06 --> Model "Log_model" initialized
INFO - 2025-09-17 14:33:06 --> Final output sent to browser
DEBUG - 2025-09-17 14:33:06 --> Total execution time: 0.5575
INFO - 2025-09-17 09:57:08 --> Config Class Initialized
INFO - 2025-09-17 09:57:08 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:57:08 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:57:08 --> Utf8 Class Initialized
INFO - 2025-09-17 09:57:08 --> URI Class Initialized
DEBUG - 2025-09-17 09:57:08 --> No URI present. Default controller set.
INFO - 2025-09-17 09:57:08 --> Router Class Initialized
INFO - 2025-09-17 09:57:08 --> Output Class Initialized
INFO - 2025-09-17 09:57:08 --> Security Class Initialized
DEBUG - 2025-09-17 09:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:57:08 --> CSRF cookie sent
INFO - 2025-09-17 09:57:08 --> Input Class Initialized
INFO - 2025-09-17 09:57:08 --> Language Class Initialized
INFO - 2025-09-17 09:57:08 --> Loader Class Initialized
INFO - 2025-09-17 09:57:08 --> Helper loaded: url_helper
INFO - 2025-09-17 09:57:08 --> Helper loaded: text_helper
INFO - 2025-09-17 09:57:08 --> Helper loaded: string_helper
INFO - 2025-09-17 09:57:08 --> Helper loaded: form_helper
INFO - 2025-09-17 09:57:08 --> Helper loaded: download_helper
INFO - 2025-09-17 09:57:08 --> Helper loaded: security_helper
INFO - 2025-09-17 09:57:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:57:08 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:57:08 --> Form Validation Class Initialized
INFO - 2025-09-17 09:57:08 --> Model "User_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:57:08 --> Controller Class Initialized
INFO - 2025-09-17 14:57:08 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Video_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:57:08 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:57:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:57:08 --> Pagination Class Initialized
INFO - 2025-09-17 14:57:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:57:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:57:08 --> Model "Log_model" initialized
INFO - 2025-09-17 14:57:08 --> Final output sent to browser
DEBUG - 2025-09-17 14:57:08 --> Total execution time: 0.2336
INFO - 2025-09-17 09:58:47 --> Config Class Initialized
INFO - 2025-09-17 09:58:47 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:58:47 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:58:47 --> Utf8 Class Initialized
INFO - 2025-09-17 09:58:47 --> URI Class Initialized
DEBUG - 2025-09-17 09:58:47 --> No URI present. Default controller set.
INFO - 2025-09-17 09:58:47 --> Router Class Initialized
INFO - 2025-09-17 09:58:47 --> Output Class Initialized
INFO - 2025-09-17 09:58:47 --> Security Class Initialized
DEBUG - 2025-09-17 09:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:58:47 --> CSRF cookie sent
INFO - 2025-09-17 09:58:47 --> Input Class Initialized
INFO - 2025-09-17 09:58:47 --> Language Class Initialized
INFO - 2025-09-17 09:58:47 --> Loader Class Initialized
INFO - 2025-09-17 09:58:47 --> Helper loaded: url_helper
INFO - 2025-09-17 09:58:47 --> Helper loaded: text_helper
INFO - 2025-09-17 09:58:47 --> Helper loaded: string_helper
INFO - 2025-09-17 09:58:47 --> Helper loaded: form_helper
INFO - 2025-09-17 09:58:47 --> Helper loaded: download_helper
INFO - 2025-09-17 09:58:47 --> Helper loaded: security_helper
INFO - 2025-09-17 09:58:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:58:47 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:58:47 --> Form Validation Class Initialized
INFO - 2025-09-17 09:58:47 --> Model "User_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:58:47 --> Controller Class Initialized
INFO - 2025-09-17 14:58:47 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Video_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:58:47 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:58:47 --> Pagination Class Initialized
INFO - 2025-09-17 14:58:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:58:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:58:47 --> Model "Log_model" initialized
INFO - 2025-09-17 14:58:47 --> Final output sent to browser
DEBUG - 2025-09-17 14:58:47 --> Total execution time: 0.1600
INFO - 2025-09-17 09:58:58 --> Config Class Initialized
INFO - 2025-09-17 09:58:58 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:58:58 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:58:58 --> Utf8 Class Initialized
INFO - 2025-09-17 09:58:58 --> URI Class Initialized
DEBUG - 2025-09-17 09:58:58 --> No URI present. Default controller set.
INFO - 2025-09-17 09:58:58 --> Router Class Initialized
INFO - 2025-09-17 09:58:58 --> Output Class Initialized
INFO - 2025-09-17 09:58:58 --> Security Class Initialized
DEBUG - 2025-09-17 09:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:58:58 --> CSRF cookie sent
INFO - 2025-09-17 09:58:58 --> Input Class Initialized
INFO - 2025-09-17 09:58:58 --> Language Class Initialized
INFO - 2025-09-17 09:58:58 --> Loader Class Initialized
INFO - 2025-09-17 09:58:58 --> Helper loaded: url_helper
INFO - 2025-09-17 09:58:58 --> Helper loaded: text_helper
INFO - 2025-09-17 09:58:58 --> Helper loaded: string_helper
INFO - 2025-09-17 09:58:58 --> Helper loaded: form_helper
INFO - 2025-09-17 09:58:58 --> Helper loaded: download_helper
INFO - 2025-09-17 09:58:58 --> Helper loaded: security_helper
INFO - 2025-09-17 09:58:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:58:58 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:58:58 --> Form Validation Class Initialized
INFO - 2025-09-17 09:58:58 --> Model "User_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:58:58 --> Controller Class Initialized
INFO - 2025-09-17 14:58:58 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Video_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:58:58 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:58:58 --> Pagination Class Initialized
INFO - 2025-09-17 14:58:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:58:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:58:58 --> Model "Log_model" initialized
INFO - 2025-09-17 14:58:58 --> Final output sent to browser
DEBUG - 2025-09-17 14:58:58 --> Total execution time: 0.1450
INFO - 2025-09-17 09:59:47 --> Config Class Initialized
INFO - 2025-09-17 09:59:47 --> Hooks Class Initialized
DEBUG - 2025-09-17 09:59:47 --> UTF-8 Support Enabled
INFO - 2025-09-17 09:59:47 --> Utf8 Class Initialized
INFO - 2025-09-17 09:59:47 --> URI Class Initialized
DEBUG - 2025-09-17 09:59:47 --> No URI present. Default controller set.
INFO - 2025-09-17 09:59:47 --> Router Class Initialized
INFO - 2025-09-17 09:59:47 --> Output Class Initialized
INFO - 2025-09-17 09:59:47 --> Security Class Initialized
DEBUG - 2025-09-17 09:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 09:59:47 --> CSRF cookie sent
INFO - 2025-09-17 09:59:47 --> Input Class Initialized
INFO - 2025-09-17 09:59:47 --> Language Class Initialized
INFO - 2025-09-17 09:59:47 --> Loader Class Initialized
INFO - 2025-09-17 09:59:47 --> Helper loaded: url_helper
INFO - 2025-09-17 09:59:47 --> Helper loaded: text_helper
INFO - 2025-09-17 09:59:47 --> Helper loaded: string_helper
INFO - 2025-09-17 09:59:47 --> Helper loaded: form_helper
INFO - 2025-09-17 09:59:47 --> Helper loaded: download_helper
INFO - 2025-09-17 09:59:47 --> Helper loaded: security_helper
INFO - 2025-09-17 09:59:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 09:59:47 --> Database Driver Class Initialized
DEBUG - 2025-09-17 09:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 09:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 09:59:47 --> Form Validation Class Initialized
INFO - 2025-09-17 09:59:47 --> Model "User_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Nav_model" initialized
INFO - 2025-09-17 14:59:47 --> Controller Class Initialized
INFO - 2025-09-17 14:59:47 --> Model "Berita_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Galeri_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Video_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Agenda_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Tautan_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Mitra_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Prodi_model" initialized
INFO - 2025-09-17 14:59:47 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 14:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 14:59:47 --> Pagination Class Initialized
INFO - 2025-09-17 14:59:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 14:59:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 14:59:47 --> Model "Log_model" initialized
INFO - 2025-09-17 14:59:47 --> Final output sent to browser
DEBUG - 2025-09-17 14:59:47 --> Total execution time: 0.1446
INFO - 2025-09-17 10:00:17 --> Config Class Initialized
INFO - 2025-09-17 10:00:17 --> Hooks Class Initialized
DEBUG - 2025-09-17 10:00:17 --> UTF-8 Support Enabled
INFO - 2025-09-17 10:00:17 --> Utf8 Class Initialized
INFO - 2025-09-17 10:00:17 --> URI Class Initialized
DEBUG - 2025-09-17 10:00:17 --> No URI present. Default controller set.
INFO - 2025-09-17 10:00:17 --> Router Class Initialized
INFO - 2025-09-17 10:00:17 --> Output Class Initialized
INFO - 2025-09-17 10:00:17 --> Security Class Initialized
DEBUG - 2025-09-17 10:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 10:00:17 --> CSRF cookie sent
INFO - 2025-09-17 10:00:17 --> Input Class Initialized
INFO - 2025-09-17 10:00:17 --> Language Class Initialized
INFO - 2025-09-17 10:00:17 --> Loader Class Initialized
INFO - 2025-09-17 10:00:17 --> Helper loaded: url_helper
INFO - 2025-09-17 10:00:17 --> Helper loaded: text_helper
INFO - 2025-09-17 10:00:17 --> Helper loaded: string_helper
INFO - 2025-09-17 10:00:17 --> Helper loaded: form_helper
INFO - 2025-09-17 10:00:17 --> Helper loaded: download_helper
INFO - 2025-09-17 10:00:17 --> Helper loaded: security_helper
INFO - 2025-09-17 10:00:17 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 10:00:17 --> Database Driver Class Initialized
DEBUG - 2025-09-17 10:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 10:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 10:00:17 --> Form Validation Class Initialized
INFO - 2025-09-17 10:00:17 --> Model "User_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Nav_model" initialized
INFO - 2025-09-17 15:00:17 --> Controller Class Initialized
INFO - 2025-09-17 15:00:17 --> Model "Berita_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Galeri_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Video_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Agenda_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Tautan_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Mitra_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Prodi_model" initialized
INFO - 2025-09-17 15:00:17 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 15:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 15:00:17 --> Pagination Class Initialized
INFO - 2025-09-17 15:00:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 15:00:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 15:00:17 --> Model "Log_model" initialized
INFO - 2025-09-17 15:00:17 --> Final output sent to browser
DEBUG - 2025-09-17 15:00:17 --> Total execution time: 0.1309
INFO - 2025-09-17 10:00:50 --> Config Class Initialized
INFO - 2025-09-17 10:00:50 --> Hooks Class Initialized
DEBUG - 2025-09-17 10:00:50 --> UTF-8 Support Enabled
INFO - 2025-09-17 10:00:50 --> Utf8 Class Initialized
INFO - 2025-09-17 10:00:50 --> URI Class Initialized
DEBUG - 2025-09-17 10:00:50 --> No URI present. Default controller set.
INFO - 2025-09-17 10:00:50 --> Router Class Initialized
INFO - 2025-09-17 10:00:50 --> Output Class Initialized
INFO - 2025-09-17 10:00:50 --> Security Class Initialized
DEBUG - 2025-09-17 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 10:00:50 --> CSRF cookie sent
INFO - 2025-09-17 10:00:50 --> Input Class Initialized
INFO - 2025-09-17 10:00:50 --> Language Class Initialized
INFO - 2025-09-17 10:00:50 --> Loader Class Initialized
INFO - 2025-09-17 10:00:50 --> Helper loaded: url_helper
INFO - 2025-09-17 10:00:50 --> Helper loaded: text_helper
INFO - 2025-09-17 10:00:50 --> Helper loaded: string_helper
INFO - 2025-09-17 10:00:50 --> Helper loaded: form_helper
INFO - 2025-09-17 10:00:50 --> Helper loaded: download_helper
INFO - 2025-09-17 10:00:50 --> Helper loaded: security_helper
INFO - 2025-09-17 10:00:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 10:00:50 --> Database Driver Class Initialized
DEBUG - 2025-09-17 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 10:00:50 --> Form Validation Class Initialized
INFO - 2025-09-17 10:00:50 --> Model "User_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Nav_model" initialized
INFO - 2025-09-17 15:00:50 --> Controller Class Initialized
INFO - 2025-09-17 15:00:50 --> Model "Berita_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Galeri_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Video_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Agenda_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Tautan_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Mitra_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Prodi_model" initialized
INFO - 2025-09-17 15:00:50 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 15:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 15:00:50 --> Pagination Class Initialized
INFO - 2025-09-17 15:00:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 15:00:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 15:00:50 --> Model "Log_model" initialized
INFO - 2025-09-17 15:00:50 --> Final output sent to browser
DEBUG - 2025-09-17 15:00:50 --> Total execution time: 0.1263
INFO - 2025-09-17 10:01:59 --> Config Class Initialized
INFO - 2025-09-17 10:01:59 --> Hooks Class Initialized
DEBUG - 2025-09-17 10:01:59 --> UTF-8 Support Enabled
INFO - 2025-09-17 10:01:59 --> Utf8 Class Initialized
INFO - 2025-09-17 10:01:59 --> URI Class Initialized
DEBUG - 2025-09-17 10:01:59 --> No URI present. Default controller set.
INFO - 2025-09-17 10:01:59 --> Router Class Initialized
INFO - 2025-09-17 10:01:59 --> Output Class Initialized
INFO - 2025-09-17 10:01:59 --> Security Class Initialized
DEBUG - 2025-09-17 10:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 10:01:59 --> CSRF cookie sent
INFO - 2025-09-17 10:01:59 --> Input Class Initialized
INFO - 2025-09-17 10:01:59 --> Language Class Initialized
INFO - 2025-09-17 10:01:59 --> Loader Class Initialized
INFO - 2025-09-17 10:01:59 --> Helper loaded: url_helper
INFO - 2025-09-17 10:01:59 --> Helper loaded: text_helper
INFO - 2025-09-17 10:01:59 --> Helper loaded: string_helper
INFO - 2025-09-17 10:01:59 --> Helper loaded: form_helper
INFO - 2025-09-17 10:01:59 --> Helper loaded: download_helper
INFO - 2025-09-17 10:01:59 --> Helper loaded: security_helper
INFO - 2025-09-17 10:01:59 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 10:01:59 --> Database Driver Class Initialized
DEBUG - 2025-09-17 10:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 10:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 10:01:59 --> Form Validation Class Initialized
INFO - 2025-09-17 10:01:59 --> Model "User_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Nav_model" initialized
INFO - 2025-09-17 15:01:59 --> Controller Class Initialized
INFO - 2025-09-17 15:01:59 --> Model "Berita_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Galeri_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Video_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Agenda_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Tautan_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Mitra_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Prodi_model" initialized
INFO - 2025-09-17 15:01:59 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 15:01:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 15:01:59 --> Pagination Class Initialized
INFO - 2025-09-17 15:01:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 15:01:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 15:01:59 --> Model "Log_model" initialized
INFO - 2025-09-17 15:01:59 --> Final output sent to browser
DEBUG - 2025-09-17 15:01:59 --> Total execution time: 0.2537
INFO - 2025-09-17 10:02:55 --> Config Class Initialized
INFO - 2025-09-17 10:02:55 --> Hooks Class Initialized
DEBUG - 2025-09-17 10:02:55 --> UTF-8 Support Enabled
INFO - 2025-09-17 10:02:55 --> Utf8 Class Initialized
INFO - 2025-09-17 10:02:55 --> URI Class Initialized
DEBUG - 2025-09-17 10:02:55 --> No URI present. Default controller set.
INFO - 2025-09-17 10:02:55 --> Router Class Initialized
INFO - 2025-09-17 10:02:55 --> Output Class Initialized
INFO - 2025-09-17 10:02:55 --> Security Class Initialized
DEBUG - 2025-09-17 10:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 10:02:55 --> CSRF cookie sent
INFO - 2025-09-17 10:02:55 --> Input Class Initialized
INFO - 2025-09-17 10:02:55 --> Language Class Initialized
INFO - 2025-09-17 10:02:55 --> Loader Class Initialized
INFO - 2025-09-17 10:02:55 --> Helper loaded: url_helper
INFO - 2025-09-17 10:02:55 --> Helper loaded: text_helper
INFO - 2025-09-17 10:02:55 --> Helper loaded: string_helper
INFO - 2025-09-17 10:02:55 --> Helper loaded: form_helper
INFO - 2025-09-17 10:02:55 --> Helper loaded: download_helper
INFO - 2025-09-17 10:02:55 --> Helper loaded: security_helper
INFO - 2025-09-17 10:02:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 10:02:55 --> Database Driver Class Initialized
DEBUG - 2025-09-17 10:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 10:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 10:02:55 --> Form Validation Class Initialized
INFO - 2025-09-17 10:02:55 --> Model "User_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Nav_model" initialized
INFO - 2025-09-17 15:02:55 --> Controller Class Initialized
INFO - 2025-09-17 15:02:55 --> Model "Berita_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Galeri_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Video_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Agenda_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Tautan_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Mitra_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Prodi_model" initialized
INFO - 2025-09-17 15:02:55 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 15:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 15:02:55 --> Pagination Class Initialized
INFO - 2025-09-17 15:02:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 15:02:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 15:02:55 --> Model "Log_model" initialized
INFO - 2025-09-17 15:02:55 --> Final output sent to browser
DEBUG - 2025-09-17 15:02:55 --> Total execution time: 0.1419
INFO - 2025-09-17 10:03:09 --> Config Class Initialized
INFO - 2025-09-17 10:03:09 --> Hooks Class Initialized
DEBUG - 2025-09-17 10:03:09 --> UTF-8 Support Enabled
INFO - 2025-09-17 10:03:09 --> Utf8 Class Initialized
INFO - 2025-09-17 10:03:09 --> URI Class Initialized
DEBUG - 2025-09-17 10:03:09 --> No URI present. Default controller set.
INFO - 2025-09-17 10:03:09 --> Router Class Initialized
INFO - 2025-09-17 10:03:09 --> Output Class Initialized
INFO - 2025-09-17 10:03:09 --> Security Class Initialized
DEBUG - 2025-09-17 10:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 10:03:09 --> CSRF cookie sent
INFO - 2025-09-17 10:03:09 --> Input Class Initialized
INFO - 2025-09-17 10:03:09 --> Language Class Initialized
INFO - 2025-09-17 10:03:09 --> Loader Class Initialized
INFO - 2025-09-17 10:03:09 --> Helper loaded: url_helper
INFO - 2025-09-17 10:03:09 --> Helper loaded: text_helper
INFO - 2025-09-17 10:03:09 --> Helper loaded: string_helper
INFO - 2025-09-17 10:03:09 --> Helper loaded: form_helper
INFO - 2025-09-17 10:03:09 --> Helper loaded: download_helper
INFO - 2025-09-17 10:03:09 --> Helper loaded: security_helper
INFO - 2025-09-17 10:03:09 --> Helper loaded: image_optimizer_helper
INFO - 2025-09-17 10:03:09 --> Database Driver Class Initialized
DEBUG - 2025-09-17 10:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 10:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 10:03:09 --> Form Validation Class Initialized
INFO - 2025-09-17 10:03:09 --> Model "User_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Kunjungan_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Konfigurasi_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Nav_model" initialized
INFO - 2025-09-17 15:03:09 --> Controller Class Initialized
INFO - 2025-09-17 15:03:09 --> Model "Berita_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Galeri_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Video_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Agenda_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Tautan_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Mitra_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Jurusan_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Prodi_model" initialized
INFO - 2025-09-17 15:03:09 --> Model "Testimoni_model" initialized
INFO - 2025-09-17 15:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-09-17 15:03:09 --> Pagination Class Initialized
INFO - 2025-09-17 15:03:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-09-17 15:03:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-09-17 15:03:09 --> Model "Log_model" initialized
INFO - 2025-09-17 15:03:09 --> Final output sent to browser
DEBUG - 2025-09-17 15:03:09 --> Total execution time: 0.1360
