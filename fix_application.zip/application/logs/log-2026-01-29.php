<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-29 03:32:56 --> Config Class Initialized
INFO - 2026-01-29 03:32:56 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:32:57 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:32:57 --> Utf8 Class Initialized
INFO - 2026-01-29 03:32:57 --> URI Class Initialized
DEBUG - 2026-01-29 03:32:57 --> No URI present. Default controller set.
INFO - 2026-01-29 03:32:57 --> Router Class Initialized
INFO - 2026-01-29 03:32:57 --> Output Class Initialized
INFO - 2026-01-29 03:32:57 --> Security Class Initialized
DEBUG - 2026-01-29 03:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:32:57 --> CSRF cookie sent
INFO - 2026-01-29 03:32:57 --> Input Class Initialized
INFO - 2026-01-29 03:32:58 --> Language Class Initialized
INFO - 2026-01-29 03:32:58 --> Loader Class Initialized
INFO - 2026-01-29 03:32:58 --> Helper loaded: url_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: text_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: string_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: form_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: download_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: security_helper
INFO - 2026-01-29 03:32:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:32:59 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:32:59 --> Form Validation Class Initialized
INFO - 2026-01-29 03:32:59 --> Model "User_model" initialized
INFO - 2026-01-29 09:32:59 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:33:00 --> Controller Class Initialized
INFO - 2026-01-29 09:33:00 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Video_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:33:00 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:33:01 --> Pagination Class Initialized
INFO - 2026-01-29 09:33:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:33:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:33:04 --> Model "Log_model" initialized
INFO - 2026-01-29 09:33:04 --> Final output sent to browser
DEBUG - 2026-01-29 09:33:04 --> Total execution time: 8.0018
INFO - 2026-01-29 03:33:48 --> Config Class Initialized
INFO - 2026-01-29 03:33:48 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:33:48 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:33:48 --> Utf8 Class Initialized
INFO - 2026-01-29 03:33:48 --> URI Class Initialized
DEBUG - 2026-01-29 03:33:48 --> No URI present. Default controller set.
INFO - 2026-01-29 03:33:48 --> Router Class Initialized
INFO - 2026-01-29 03:33:48 --> Output Class Initialized
INFO - 2026-01-29 03:33:48 --> Security Class Initialized
DEBUG - 2026-01-29 03:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:33:48 --> CSRF cookie sent
INFO - 2026-01-29 03:33:48 --> Input Class Initialized
INFO - 2026-01-29 03:33:48 --> Language Class Initialized
INFO - 2026-01-29 03:33:48 --> Loader Class Initialized
INFO - 2026-01-29 03:33:48 --> Helper loaded: url_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: text_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: string_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: form_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: download_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: security_helper
INFO - 2026-01-29 03:33:48 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:33:48 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:33:48 --> Form Validation Class Initialized
INFO - 2026-01-29 03:33:48 --> Model "User_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:33:48 --> Controller Class Initialized
INFO - 2026-01-29 09:33:48 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Video_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:33:48 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:33:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:33:48 --> Pagination Class Initialized
INFO - 2026-01-29 09:33:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:33:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:33:48 --> Model "Log_model" initialized
INFO - 2026-01-29 09:33:48 --> Final output sent to browser
DEBUG - 2026-01-29 09:33:48 --> Total execution time: 0.3001
INFO - 2026-01-29 03:34:06 --> Config Class Initialized
INFO - 2026-01-29 03:34:06 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:34:06 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:34:06 --> Utf8 Class Initialized
INFO - 2026-01-29 03:34:06 --> URI Class Initialized
DEBUG - 2026-01-29 03:34:06 --> No URI present. Default controller set.
INFO - 2026-01-29 03:34:06 --> Router Class Initialized
INFO - 2026-01-29 03:34:06 --> Output Class Initialized
INFO - 2026-01-29 03:34:06 --> Security Class Initialized
DEBUG - 2026-01-29 03:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:34:06 --> CSRF cookie sent
INFO - 2026-01-29 03:34:06 --> Input Class Initialized
INFO - 2026-01-29 03:34:06 --> Language Class Initialized
INFO - 2026-01-29 03:34:06 --> Loader Class Initialized
INFO - 2026-01-29 03:34:06 --> Helper loaded: url_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: text_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: string_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: form_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: download_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: security_helper
INFO - 2026-01-29 03:34:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:34:06 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:34:06 --> Form Validation Class Initialized
INFO - 2026-01-29 03:34:06 --> Model "User_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:34:06 --> Controller Class Initialized
INFO - 2026-01-29 09:34:06 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Video_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:34:06 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:34:06 --> Pagination Class Initialized
INFO - 2026-01-29 09:34:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:34:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:34:06 --> Model "Log_model" initialized
INFO - 2026-01-29 09:34:06 --> Final output sent to browser
DEBUG - 2026-01-29 09:34:06 --> Total execution time: 0.3491
INFO - 2026-01-29 03:34:08 --> Config Class Initialized
INFO - 2026-01-29 03:34:08 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:34:08 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:34:08 --> Utf8 Class Initialized
INFO - 2026-01-29 03:34:08 --> URI Class Initialized
DEBUG - 2026-01-29 03:34:08 --> No URI present. Default controller set.
INFO - 2026-01-29 03:34:08 --> Router Class Initialized
INFO - 2026-01-29 03:34:08 --> Output Class Initialized
INFO - 2026-01-29 03:34:08 --> Security Class Initialized
DEBUG - 2026-01-29 03:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:34:08 --> CSRF cookie sent
INFO - 2026-01-29 03:34:08 --> Input Class Initialized
INFO - 2026-01-29 03:34:08 --> Language Class Initialized
INFO - 2026-01-29 03:34:08 --> Loader Class Initialized
INFO - 2026-01-29 03:34:08 --> Helper loaded: url_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: text_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: string_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: form_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: download_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: security_helper
INFO - 2026-01-29 03:34:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:34:08 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:34:08 --> Form Validation Class Initialized
INFO - 2026-01-29 03:34:08 --> Model "User_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:34:08 --> Controller Class Initialized
INFO - 2026-01-29 09:34:08 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Video_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:34:08 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:34:08 --> Pagination Class Initialized
INFO - 2026-01-29 09:34:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:34:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:34:08 --> Model "Log_model" initialized
INFO - 2026-01-29 09:34:08 --> Final output sent to browser
DEBUG - 2026-01-29 09:34:08 --> Total execution time: 0.3556
INFO - 2026-01-29 03:35:44 --> Config Class Initialized
INFO - 2026-01-29 03:35:44 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:35:44 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:35:44 --> Utf8 Class Initialized
INFO - 2026-01-29 03:35:44 --> URI Class Initialized
DEBUG - 2026-01-29 03:35:44 --> No URI present. Default controller set.
INFO - 2026-01-29 03:35:44 --> Router Class Initialized
INFO - 2026-01-29 03:35:44 --> Output Class Initialized
INFO - 2026-01-29 03:35:44 --> Security Class Initialized
DEBUG - 2026-01-29 03:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:35:44 --> CSRF cookie sent
INFO - 2026-01-29 03:35:44 --> Input Class Initialized
INFO - 2026-01-29 03:35:44 --> Language Class Initialized
INFO - 2026-01-29 03:35:44 --> Loader Class Initialized
INFO - 2026-01-29 03:35:44 --> Helper loaded: url_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: text_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: string_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: form_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: download_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: security_helper
INFO - 2026-01-29 03:35:44 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:35:44 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:35:44 --> Form Validation Class Initialized
INFO - 2026-01-29 03:35:44 --> Model "User_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:35:44 --> Controller Class Initialized
INFO - 2026-01-29 09:35:44 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Video_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:35:44 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:35:44 --> Pagination Class Initialized
INFO - 2026-01-29 09:35:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:35:44 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:35:44 --> Model "Log_model" initialized
INFO - 2026-01-29 09:35:44 --> Final output sent to browser
DEBUG - 2026-01-29 09:35:44 --> Total execution time: 0.2932
INFO - 2026-01-29 03:35:58 --> Config Class Initialized
INFO - 2026-01-29 03:35:58 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:35:58 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:35:58 --> Utf8 Class Initialized
INFO - 2026-01-29 03:35:58 --> URI Class Initialized
DEBUG - 2026-01-29 03:35:58 --> No URI present. Default controller set.
INFO - 2026-01-29 03:35:58 --> Router Class Initialized
INFO - 2026-01-29 03:35:58 --> Output Class Initialized
INFO - 2026-01-29 03:35:58 --> Security Class Initialized
DEBUG - 2026-01-29 03:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:35:58 --> CSRF cookie sent
INFO - 2026-01-29 03:35:58 --> Input Class Initialized
INFO - 2026-01-29 03:35:58 --> Language Class Initialized
INFO - 2026-01-29 03:35:58 --> Loader Class Initialized
INFO - 2026-01-29 03:35:58 --> Helper loaded: url_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: text_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: string_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: form_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: download_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: security_helper
INFO - 2026-01-29 03:35:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:35:58 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:35:58 --> Form Validation Class Initialized
INFO - 2026-01-29 03:35:58 --> Model "User_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:35:58 --> Controller Class Initialized
INFO - 2026-01-29 09:35:58 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Video_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:35:58 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:35:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:35:58 --> Pagination Class Initialized
INFO - 2026-01-29 09:35:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:35:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:35:58 --> Model "Log_model" initialized
INFO - 2026-01-29 09:35:58 --> Final output sent to browser
DEBUG - 2026-01-29 09:35:58 --> Total execution time: 0.3384
INFO - 2026-01-29 03:36:01 --> Config Class Initialized
INFO - 2026-01-29 03:36:01 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:36:01 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:36:01 --> Utf8 Class Initialized
INFO - 2026-01-29 03:36:01 --> URI Class Initialized
DEBUG - 2026-01-29 03:36:01 --> No URI present. Default controller set.
INFO - 2026-01-29 03:36:01 --> Router Class Initialized
INFO - 2026-01-29 03:36:01 --> Output Class Initialized
INFO - 2026-01-29 03:36:01 --> Security Class Initialized
DEBUG - 2026-01-29 03:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:36:01 --> CSRF cookie sent
INFO - 2026-01-29 03:36:01 --> Input Class Initialized
INFO - 2026-01-29 03:36:01 --> Language Class Initialized
INFO - 2026-01-29 03:36:01 --> Loader Class Initialized
INFO - 2026-01-29 03:36:01 --> Helper loaded: url_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: text_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: string_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: form_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: download_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: security_helper
INFO - 2026-01-29 03:36:01 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:36:01 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:36:01 --> Form Validation Class Initialized
INFO - 2026-01-29 03:36:01 --> Model "User_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:36:01 --> Controller Class Initialized
INFO - 2026-01-29 09:36:01 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Video_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:36:01 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:36:01 --> Pagination Class Initialized
INFO - 2026-01-29 09:36:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:36:01 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:36:01 --> Model "Log_model" initialized
INFO - 2026-01-29 09:36:01 --> Final output sent to browser
DEBUG - 2026-01-29 09:36:01 --> Total execution time: 0.2654
INFO - 2026-01-29 03:36:10 --> Config Class Initialized
INFO - 2026-01-29 03:36:10 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:36:10 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:36:10 --> Utf8 Class Initialized
INFO - 2026-01-29 03:36:10 --> URI Class Initialized
DEBUG - 2026-01-29 03:36:10 --> No URI present. Default controller set.
INFO - 2026-01-29 03:36:10 --> Router Class Initialized
INFO - 2026-01-29 03:36:10 --> Output Class Initialized
INFO - 2026-01-29 03:36:10 --> Security Class Initialized
DEBUG - 2026-01-29 03:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:36:10 --> CSRF cookie sent
INFO - 2026-01-29 03:36:10 --> Input Class Initialized
INFO - 2026-01-29 03:36:10 --> Language Class Initialized
INFO - 2026-01-29 03:36:10 --> Loader Class Initialized
INFO - 2026-01-29 03:36:10 --> Helper loaded: url_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: text_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: string_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: form_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: download_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: security_helper
INFO - 2026-01-29 03:36:10 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:36:10 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:36:10 --> Form Validation Class Initialized
INFO - 2026-01-29 03:36:10 --> Model "User_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:36:10 --> Controller Class Initialized
INFO - 2026-01-29 09:36:10 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Video_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:36:10 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:36:10 --> Pagination Class Initialized
INFO - 2026-01-29 09:36:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:36:10 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:36:10 --> Model "Log_model" initialized
INFO - 2026-01-29 09:36:10 --> Final output sent to browser
DEBUG - 2026-01-29 09:36:10 --> Total execution time: 0.2845
INFO - 2026-01-29 03:36:31 --> Config Class Initialized
INFO - 2026-01-29 03:36:31 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:36:31 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:36:31 --> Utf8 Class Initialized
INFO - 2026-01-29 03:36:31 --> URI Class Initialized
DEBUG - 2026-01-29 03:36:31 --> No URI present. Default controller set.
INFO - 2026-01-29 03:36:31 --> Router Class Initialized
INFO - 2026-01-29 03:36:31 --> Output Class Initialized
INFO - 2026-01-29 03:36:31 --> Security Class Initialized
DEBUG - 2026-01-29 03:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:36:31 --> CSRF cookie sent
INFO - 2026-01-29 03:36:31 --> Input Class Initialized
INFO - 2026-01-29 03:36:31 --> Language Class Initialized
INFO - 2026-01-29 03:36:31 --> Loader Class Initialized
INFO - 2026-01-29 03:36:31 --> Helper loaded: url_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: text_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: string_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: form_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: download_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: security_helper
INFO - 2026-01-29 03:36:31 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:36:31 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:36:31 --> Form Validation Class Initialized
INFO - 2026-01-29 03:36:31 --> Model "User_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:36:31 --> Controller Class Initialized
INFO - 2026-01-29 09:36:31 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Video_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:36:31 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:36:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:36:32 --> Pagination Class Initialized
INFO - 2026-01-29 09:36:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:36:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:36:32 --> Model "Log_model" initialized
INFO - 2026-01-29 09:36:32 --> Final output sent to browser
DEBUG - 2026-01-29 09:36:32 --> Total execution time: 0.2597
INFO - 2026-01-29 03:36:42 --> Config Class Initialized
INFO - 2026-01-29 03:36:42 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:36:42 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:36:42 --> Utf8 Class Initialized
INFO - 2026-01-29 03:36:42 --> URI Class Initialized
DEBUG - 2026-01-29 03:36:42 --> No URI present. Default controller set.
INFO - 2026-01-29 03:36:42 --> Router Class Initialized
INFO - 2026-01-29 03:36:42 --> Output Class Initialized
INFO - 2026-01-29 03:36:42 --> Security Class Initialized
DEBUG - 2026-01-29 03:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:36:42 --> CSRF cookie sent
INFO - 2026-01-29 03:36:42 --> Input Class Initialized
INFO - 2026-01-29 03:36:42 --> Language Class Initialized
INFO - 2026-01-29 03:36:42 --> Loader Class Initialized
INFO - 2026-01-29 03:36:42 --> Helper loaded: url_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: text_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: string_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: form_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: download_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: security_helper
INFO - 2026-01-29 03:36:42 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:36:42 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:36:42 --> Form Validation Class Initialized
INFO - 2026-01-29 03:36:42 --> Model "User_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:36:42 --> Controller Class Initialized
INFO - 2026-01-29 09:36:42 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Video_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:36:42 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:36:42 --> Pagination Class Initialized
INFO - 2026-01-29 09:36:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:36:42 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:36:42 --> Model "Log_model" initialized
INFO - 2026-01-29 09:36:42 --> Final output sent to browser
DEBUG - 2026-01-29 09:36:42 --> Total execution time: 0.3289
INFO - 2026-01-29 03:37:19 --> Config Class Initialized
INFO - 2026-01-29 03:37:19 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:37:19 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:37:19 --> Utf8 Class Initialized
INFO - 2026-01-29 03:37:19 --> URI Class Initialized
INFO - 2026-01-29 03:37:19 --> Router Class Initialized
INFO - 2026-01-29 03:37:19 --> Output Class Initialized
INFO - 2026-01-29 03:37:20 --> Security Class Initialized
DEBUG - 2026-01-29 03:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:37:20 --> CSRF cookie sent
INFO - 2026-01-29 03:37:20 --> Input Class Initialized
INFO - 2026-01-29 03:37:20 --> Language Class Initialized
INFO - 2026-01-29 03:37:20 --> Loader Class Initialized
INFO - 2026-01-29 03:37:20 --> Helper loaded: url_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: text_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: string_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: form_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: download_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: security_helper
INFO - 2026-01-29 03:37:20 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:37:20 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:37:20 --> Form Validation Class Initialized
INFO - 2026-01-29 03:37:20 --> Model "User_model" initialized
INFO - 2026-01-29 09:37:20 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:37:20 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:37:20 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:37:20 --> Controller Class Initialized
INFO - 2026-01-29 09:37:20 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:37:20 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:37:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:37:20 --> Pagination Class Initialized
INFO - 2026-01-29 09:37:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:37:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:37:20 --> Model "Log_model" initialized
INFO - 2026-01-29 09:37:20 --> Final output sent to browser
DEBUG - 2026-01-29 09:37:20 --> Total execution time: 0.5158
INFO - 2026-01-29 03:37:38 --> Config Class Initialized
INFO - 2026-01-29 03:37:38 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:37:38 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:37:38 --> Utf8 Class Initialized
INFO - 2026-01-29 03:37:38 --> URI Class Initialized
INFO - 2026-01-29 03:37:38 --> Router Class Initialized
INFO - 2026-01-29 03:37:38 --> Output Class Initialized
INFO - 2026-01-29 03:37:38 --> Security Class Initialized
DEBUG - 2026-01-29 03:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:37:38 --> CSRF cookie sent
INFO - 2026-01-29 03:37:38 --> Input Class Initialized
INFO - 2026-01-29 03:37:38 --> Language Class Initialized
INFO - 2026-01-29 03:37:38 --> Loader Class Initialized
INFO - 2026-01-29 03:37:38 --> Helper loaded: url_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: text_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: string_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: form_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: download_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: security_helper
INFO - 2026-01-29 03:37:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:37:38 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:37:38 --> Form Validation Class Initialized
INFO - 2026-01-29 03:37:38 --> Model "User_model" initialized
INFO - 2026-01-29 09:37:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:37:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:37:38 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:37:38 --> Controller Class Initialized
INFO - 2026-01-29 09:37:38 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:37:38 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:37:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:37:38 --> Pagination Class Initialized
INFO - 2026-01-29 09:37:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:37:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:37:38 --> Model "Log_model" initialized
INFO - 2026-01-29 09:37:38 --> Final output sent to browser
DEBUG - 2026-01-29 09:37:38 --> Total execution time: 0.2154
INFO - 2026-01-29 03:37:54 --> Config Class Initialized
INFO - 2026-01-29 03:37:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:37:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:37:54 --> Utf8 Class Initialized
INFO - 2026-01-29 03:37:55 --> URI Class Initialized
INFO - 2026-01-29 03:37:55 --> Router Class Initialized
INFO - 2026-01-29 03:37:55 --> Output Class Initialized
INFO - 2026-01-29 03:37:55 --> Security Class Initialized
DEBUG - 2026-01-29 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:37:55 --> CSRF cookie sent
INFO - 2026-01-29 03:37:55 --> Input Class Initialized
INFO - 2026-01-29 03:37:55 --> Language Class Initialized
INFO - 2026-01-29 03:37:55 --> Loader Class Initialized
INFO - 2026-01-29 03:37:55 --> Helper loaded: url_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: text_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: string_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: form_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: download_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: security_helper
INFO - 2026-01-29 03:37:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:37:55 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:37:55 --> Form Validation Class Initialized
INFO - 2026-01-29 03:37:55 --> Model "User_model" initialized
INFO - 2026-01-29 09:37:55 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:37:55 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:37:55 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:37:55 --> Controller Class Initialized
INFO - 2026-01-29 09:37:55 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:37:55 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:37:55 --> Pagination Class Initialized
INFO - 2026-01-29 09:37:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:37:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:37:55 --> Model "Log_model" initialized
INFO - 2026-01-29 09:37:55 --> Final output sent to browser
DEBUG - 2026-01-29 09:37:55 --> Total execution time: 0.3250
INFO - 2026-01-29 03:38:02 --> Config Class Initialized
INFO - 2026-01-29 03:38:02 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:38:02 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:38:02 --> Utf8 Class Initialized
INFO - 2026-01-29 03:38:02 --> URI Class Initialized
INFO - 2026-01-29 03:38:02 --> Router Class Initialized
INFO - 2026-01-29 03:38:02 --> Output Class Initialized
INFO - 2026-01-29 03:38:02 --> Security Class Initialized
DEBUG - 2026-01-29 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:38:02 --> CSRF cookie sent
INFO - 2026-01-29 03:38:02 --> Input Class Initialized
INFO - 2026-01-29 03:38:02 --> Language Class Initialized
INFO - 2026-01-29 03:38:02 --> Loader Class Initialized
INFO - 2026-01-29 03:38:02 --> Helper loaded: url_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: text_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: string_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: form_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: download_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: security_helper
INFO - 2026-01-29 03:38:02 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:38:02 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:38:02 --> Form Validation Class Initialized
INFO - 2026-01-29 03:38:02 --> Model "User_model" initialized
INFO - 2026-01-29 09:38:02 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:38:02 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:38:02 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:38:02 --> Controller Class Initialized
INFO - 2026-01-29 09:38:02 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:38:02 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/read.php
INFO - 2026-01-29 09:38:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:38:03 --> Model "Log_model" initialized
INFO - 2026-01-29 09:38:03 --> Final output sent to browser
DEBUG - 2026-01-29 09:38:03 --> Total execution time: 0.6122
INFO - 2026-01-29 03:38:06 --> Config Class Initialized
INFO - 2026-01-29 03:38:06 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:38:06 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:38:06 --> Utf8 Class Initialized
INFO - 2026-01-29 03:38:06 --> URI Class Initialized
INFO - 2026-01-29 03:38:06 --> Router Class Initialized
INFO - 2026-01-29 03:38:06 --> Output Class Initialized
INFO - 2026-01-29 03:38:06 --> Security Class Initialized
DEBUG - 2026-01-29 03:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:38:06 --> CSRF cookie sent
INFO - 2026-01-29 03:38:06 --> Input Class Initialized
INFO - 2026-01-29 03:38:06 --> Language Class Initialized
INFO - 2026-01-29 03:38:06 --> Loader Class Initialized
INFO - 2026-01-29 03:38:06 --> Helper loaded: url_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: text_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: string_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: form_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: download_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: security_helper
INFO - 2026-01-29 03:38:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:38:06 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:38:06 --> Form Validation Class Initialized
INFO - 2026-01-29 03:38:06 --> Model "User_model" initialized
INFO - 2026-01-29 09:38:06 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:38:06 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:38:06 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:38:06 --> Controller Class Initialized
INFO - 2026-01-29 09:38:06 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:38:06 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:38:06 --> Pagination Class Initialized
INFO - 2026-01-29 09:38:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:38:06 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:38:06 --> Model "Log_model" initialized
INFO - 2026-01-29 09:38:06 --> Final output sent to browser
DEBUG - 2026-01-29 09:38:06 --> Total execution time: 0.3019
INFO - 2026-01-29 03:39:08 --> Config Class Initialized
INFO - 2026-01-29 03:39:08 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:39:08 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:39:08 --> Utf8 Class Initialized
INFO - 2026-01-29 03:39:08 --> URI Class Initialized
INFO - 2026-01-29 03:39:08 --> Router Class Initialized
INFO - 2026-01-29 03:39:08 --> Output Class Initialized
INFO - 2026-01-29 03:39:08 --> Security Class Initialized
DEBUG - 2026-01-29 03:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:39:08 --> CSRF cookie sent
INFO - 2026-01-29 03:39:08 --> Input Class Initialized
INFO - 2026-01-29 03:39:08 --> Language Class Initialized
INFO - 2026-01-29 03:39:08 --> Loader Class Initialized
INFO - 2026-01-29 03:39:08 --> Helper loaded: url_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: text_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: string_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: form_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: download_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: security_helper
INFO - 2026-01-29 03:39:08 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:39:08 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:39:08 --> Form Validation Class Initialized
INFO - 2026-01-29 03:39:08 --> Model "User_model" initialized
INFO - 2026-01-29 09:39:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:39:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:39:08 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:39:08 --> Controller Class Initialized
INFO - 2026-01-29 09:39:08 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:39:08 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:39:08 --> Pagination Class Initialized
INFO - 2026-01-29 09:39:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:39:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:39:08 --> Model "Log_model" initialized
INFO - 2026-01-29 09:39:08 --> Final output sent to browser
DEBUG - 2026-01-29 09:39:08 --> Total execution time: 0.2803
INFO - 2026-01-29 03:39:18 --> Config Class Initialized
INFO - 2026-01-29 03:39:18 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:39:18 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:39:18 --> Utf8 Class Initialized
INFO - 2026-01-29 03:39:18 --> URI Class Initialized
INFO - 2026-01-29 03:39:18 --> Router Class Initialized
INFO - 2026-01-29 03:39:18 --> Output Class Initialized
INFO - 2026-01-29 03:39:18 --> Security Class Initialized
DEBUG - 2026-01-29 03:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:39:18 --> CSRF cookie sent
INFO - 2026-01-29 03:39:18 --> Input Class Initialized
INFO - 2026-01-29 03:39:18 --> Language Class Initialized
INFO - 2026-01-29 03:39:18 --> Loader Class Initialized
INFO - 2026-01-29 03:39:18 --> Helper loaded: url_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: text_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: string_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: form_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: download_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: security_helper
INFO - 2026-01-29 03:39:18 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:39:18 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:39:18 --> Form Validation Class Initialized
INFO - 2026-01-29 03:39:18 --> Model "User_model" initialized
INFO - 2026-01-29 09:39:18 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:39:18 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:39:18 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:39:18 --> Controller Class Initialized
INFO - 2026-01-29 09:39:18 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:39:18 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:39:18 --> Pagination Class Initialized
INFO - 2026-01-29 09:39:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:39:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:39:18 --> Model "Log_model" initialized
INFO - 2026-01-29 09:39:18 --> Final output sent to browser
DEBUG - 2026-01-29 09:39:18 --> Total execution time: 0.2394
INFO - 2026-01-29 03:42:54 --> Config Class Initialized
INFO - 2026-01-29 03:42:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:42:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:42:54 --> Utf8 Class Initialized
INFO - 2026-01-29 03:42:54 --> URI Class Initialized
INFO - 2026-01-29 03:42:54 --> Router Class Initialized
INFO - 2026-01-29 03:42:54 --> Output Class Initialized
INFO - 2026-01-29 03:42:54 --> Security Class Initialized
DEBUG - 2026-01-29 03:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:42:54 --> CSRF cookie sent
INFO - 2026-01-29 03:42:54 --> Input Class Initialized
INFO - 2026-01-29 03:42:54 --> Language Class Initialized
INFO - 2026-01-29 03:42:54 --> Loader Class Initialized
INFO - 2026-01-29 03:42:54 --> Helper loaded: url_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: text_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: string_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: form_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: download_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: security_helper
INFO - 2026-01-29 03:42:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:42:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:42:54 --> Form Validation Class Initialized
INFO - 2026-01-29 03:42:54 --> Model "User_model" initialized
INFO - 2026-01-29 09:42:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:42:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:42:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:42:54 --> Controller Class Initialized
INFO - 2026-01-29 09:42:54 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:42:54 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:42:54 --> Pagination Class Initialized
INFO - 2026-01-29 09:42:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:42:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:42:54 --> Model "Log_model" initialized
INFO - 2026-01-29 09:42:54 --> Final output sent to browser
DEBUG - 2026-01-29 09:42:54 --> Total execution time: 0.1562
INFO - 2026-01-29 03:42:58 --> Config Class Initialized
INFO - 2026-01-29 03:42:58 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:42:58 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:42:58 --> Utf8 Class Initialized
INFO - 2026-01-29 03:42:58 --> URI Class Initialized
INFO - 2026-01-29 03:42:58 --> Router Class Initialized
INFO - 2026-01-29 03:42:58 --> Output Class Initialized
INFO - 2026-01-29 03:42:58 --> Security Class Initialized
DEBUG - 2026-01-29 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:42:58 --> CSRF cookie sent
INFO - 2026-01-29 03:42:58 --> Input Class Initialized
INFO - 2026-01-29 03:42:58 --> Language Class Initialized
INFO - 2026-01-29 03:42:58 --> Loader Class Initialized
INFO - 2026-01-29 03:42:58 --> Helper loaded: url_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: text_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: string_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: form_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: download_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: security_helper
INFO - 2026-01-29 03:42:58 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:42:58 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:42:58 --> Form Validation Class Initialized
INFO - 2026-01-29 03:42:58 --> Model "User_model" initialized
INFO - 2026-01-29 09:42:58 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:42:58 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:42:58 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:42:58 --> Controller Class Initialized
INFO - 2026-01-29 09:42:58 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:42:58 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:42:58 --> Pagination Class Initialized
INFO - 2026-01-29 09:42:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:42:59 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:42:59 --> Model "Log_model" initialized
INFO - 2026-01-29 09:42:59 --> Final output sent to browser
DEBUG - 2026-01-29 09:42:59 --> Total execution time: 0.1300
INFO - 2026-01-29 03:43:05 --> Config Class Initialized
INFO - 2026-01-29 03:43:05 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:43:05 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:43:05 --> Utf8 Class Initialized
INFO - 2026-01-29 03:43:05 --> URI Class Initialized
INFO - 2026-01-29 03:43:05 --> Router Class Initialized
INFO - 2026-01-29 03:43:05 --> Output Class Initialized
INFO - 2026-01-29 03:43:05 --> Security Class Initialized
DEBUG - 2026-01-29 03:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:43:05 --> CSRF cookie sent
INFO - 2026-01-29 03:43:05 --> Input Class Initialized
INFO - 2026-01-29 03:43:05 --> Language Class Initialized
INFO - 2026-01-29 03:43:05 --> Loader Class Initialized
INFO - 2026-01-29 03:43:05 --> Helper loaded: url_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: text_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: string_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: form_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: download_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: security_helper
INFO - 2026-01-29 03:43:05 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:43:05 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:43:05 --> Form Validation Class Initialized
INFO - 2026-01-29 03:43:05 --> Model "User_model" initialized
INFO - 2026-01-29 09:43:05 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:43:05 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:43:05 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:43:05 --> Controller Class Initialized
INFO - 2026-01-29 09:43:05 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:43:05 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:43:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:43:05 --> Pagination Class Initialized
INFO - 2026-01-29 09:43:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:43:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:43:05 --> Model "Log_model" initialized
INFO - 2026-01-29 09:43:05 --> Final output sent to browser
DEBUG - 2026-01-29 09:43:05 --> Total execution time: 0.1923
INFO - 2026-01-29 03:43:28 --> Config Class Initialized
INFO - 2026-01-29 03:43:28 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:43:28 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:43:28 --> Utf8 Class Initialized
INFO - 2026-01-29 03:43:28 --> URI Class Initialized
INFO - 2026-01-29 03:43:28 --> Router Class Initialized
INFO - 2026-01-29 03:43:28 --> Output Class Initialized
INFO - 2026-01-29 03:43:28 --> Security Class Initialized
DEBUG - 2026-01-29 03:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:43:28 --> CSRF cookie sent
INFO - 2026-01-29 03:43:28 --> Input Class Initialized
INFO - 2026-01-29 03:43:28 --> Language Class Initialized
INFO - 2026-01-29 03:43:28 --> Loader Class Initialized
INFO - 2026-01-29 03:43:28 --> Helper loaded: url_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: text_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: string_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: form_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: download_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: security_helper
INFO - 2026-01-29 03:43:28 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:43:28 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:43:28 --> Form Validation Class Initialized
INFO - 2026-01-29 03:43:28 --> Model "User_model" initialized
INFO - 2026-01-29 09:43:28 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:43:28 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:43:28 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:43:28 --> Controller Class Initialized
INFO - 2026-01-29 09:43:28 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:43:28 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:43:28 --> Pagination Class Initialized
INFO - 2026-01-29 09:43:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:43:28 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:43:28 --> Model "Log_model" initialized
INFO - 2026-01-29 09:43:28 --> Final output sent to browser
DEBUG - 2026-01-29 09:43:28 --> Total execution time: 0.1583
INFO - 2026-01-29 03:47:54 --> Config Class Initialized
INFO - 2026-01-29 03:47:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:47:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:47:54 --> Utf8 Class Initialized
INFO - 2026-01-29 03:47:54 --> URI Class Initialized
INFO - 2026-01-29 03:47:54 --> Router Class Initialized
INFO - 2026-01-29 03:47:54 --> Output Class Initialized
INFO - 2026-01-29 03:47:54 --> Security Class Initialized
DEBUG - 2026-01-29 03:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:47:54 --> CSRF cookie sent
INFO - 2026-01-29 03:47:54 --> Input Class Initialized
INFO - 2026-01-29 03:47:54 --> Language Class Initialized
INFO - 2026-01-29 03:47:54 --> Loader Class Initialized
INFO - 2026-01-29 03:47:54 --> Helper loaded: url_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: text_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: string_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: form_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: download_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: security_helper
INFO - 2026-01-29 03:47:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:47:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:47:54 --> Form Validation Class Initialized
INFO - 2026-01-29 03:47:54 --> Model "User_model" initialized
INFO - 2026-01-29 09:47:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:47:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:47:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:47:54 --> Controller Class Initialized
INFO - 2026-01-29 09:47:54 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:47:54 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:47:54 --> Pagination Class Initialized
INFO - 2026-01-29 09:47:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:47:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:47:54 --> Model "Log_model" initialized
INFO - 2026-01-29 09:47:54 --> Final output sent to browser
DEBUG - 2026-01-29 09:47:54 --> Total execution time: 0.2462
INFO - 2026-01-29 03:48:07 --> Config Class Initialized
INFO - 2026-01-29 03:48:07 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:48:07 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:48:07 --> Utf8 Class Initialized
INFO - 2026-01-29 03:48:07 --> URI Class Initialized
INFO - 2026-01-29 03:48:07 --> Router Class Initialized
INFO - 2026-01-29 03:48:07 --> Output Class Initialized
INFO - 2026-01-29 03:48:07 --> Security Class Initialized
DEBUG - 2026-01-29 03:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:48:07 --> CSRF cookie sent
INFO - 2026-01-29 03:48:07 --> Input Class Initialized
INFO - 2026-01-29 03:48:07 --> Language Class Initialized
INFO - 2026-01-29 03:48:07 --> Loader Class Initialized
INFO - 2026-01-29 03:48:07 --> Helper loaded: url_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: text_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: string_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: form_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: download_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: security_helper
INFO - 2026-01-29 03:48:07 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:48:07 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:48:08 --> Form Validation Class Initialized
INFO - 2026-01-29 03:48:08 --> Model "User_model" initialized
INFO - 2026-01-29 09:48:08 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:48:08 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:48:08 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:48:08 --> Controller Class Initialized
INFO - 2026-01-29 09:48:08 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:48:08 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:48:08 --> Pagination Class Initialized
INFO - 2026-01-29 09:48:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:48:08 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:48:08 --> Model "Log_model" initialized
INFO - 2026-01-29 09:48:08 --> Final output sent to browser
DEBUG - 2026-01-29 09:48:08 --> Total execution time: 0.2964
INFO - 2026-01-29 03:56:09 --> Config Class Initialized
INFO - 2026-01-29 03:56:09 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:56:09 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:56:09 --> Utf8 Class Initialized
INFO - 2026-01-29 03:56:09 --> URI Class Initialized
DEBUG - 2026-01-29 03:56:09 --> No URI present. Default controller set.
INFO - 2026-01-29 03:56:09 --> Router Class Initialized
INFO - 2026-01-29 03:56:09 --> Output Class Initialized
INFO - 2026-01-29 03:56:09 --> Security Class Initialized
DEBUG - 2026-01-29 03:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:56:09 --> CSRF cookie sent
INFO - 2026-01-29 03:56:09 --> Input Class Initialized
INFO - 2026-01-29 03:56:09 --> Language Class Initialized
INFO - 2026-01-29 03:56:09 --> Loader Class Initialized
INFO - 2026-01-29 03:56:09 --> Helper loaded: url_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: text_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: string_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: form_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: download_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: security_helper
INFO - 2026-01-29 03:56:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:56:09 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:56:09 --> Form Validation Class Initialized
INFO - 2026-01-29 03:56:09 --> Model "User_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:56:09 --> Controller Class Initialized
INFO - 2026-01-29 09:56:09 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Video_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:56:09 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:56:09 --> Pagination Class Initialized
INFO - 2026-01-29 09:56:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:56:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:56:09 --> Model "Log_model" initialized
INFO - 2026-01-29 09:56:09 --> Final output sent to browser
DEBUG - 2026-01-29 09:56:09 --> Total execution time: 0.2976
INFO - 2026-01-29 03:58:33 --> Config Class Initialized
INFO - 2026-01-29 03:58:33 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:58:33 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:58:33 --> Utf8 Class Initialized
INFO - 2026-01-29 03:58:33 --> URI Class Initialized
INFO - 2026-01-29 03:58:33 --> Router Class Initialized
INFO - 2026-01-29 03:58:33 --> Output Class Initialized
INFO - 2026-01-29 03:58:33 --> Security Class Initialized
DEBUG - 2026-01-29 03:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:58:33 --> CSRF cookie sent
INFO - 2026-01-29 03:58:33 --> Input Class Initialized
INFO - 2026-01-29 03:58:33 --> Language Class Initialized
INFO - 2026-01-29 03:58:33 --> Loader Class Initialized
INFO - 2026-01-29 03:58:33 --> Helper loaded: url_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: text_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: string_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: form_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: download_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: security_helper
INFO - 2026-01-29 03:58:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:58:33 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:58:33 --> Form Validation Class Initialized
INFO - 2026-01-29 03:58:33 --> Model "User_model" initialized
INFO - 2026-01-29 09:58:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:58:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:58:33 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:58:33 --> Controller Class Initialized
INFO - 2026-01-29 09:58:33 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:58:33 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:58:33 --> Pagination Class Initialized
INFO - 2026-01-29 09:58:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:58:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:58:33 --> Model "Log_model" initialized
INFO - 2026-01-29 09:58:33 --> Final output sent to browser
DEBUG - 2026-01-29 09:58:33 --> Total execution time: 0.1956
INFO - 2026-01-29 03:59:17 --> Config Class Initialized
INFO - 2026-01-29 03:59:17 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:17 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:17 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:17 --> URI Class Initialized
DEBUG - 2026-01-29 03:59:17 --> No URI present. Default controller set.
INFO - 2026-01-29 03:59:17 --> Router Class Initialized
INFO - 2026-01-29 03:59:17 --> Output Class Initialized
INFO - 2026-01-29 03:59:17 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:17 --> CSRF cookie sent
INFO - 2026-01-29 03:59:17 --> Input Class Initialized
INFO - 2026-01-29 03:59:17 --> Language Class Initialized
INFO - 2026-01-29 03:59:17 --> Loader Class Initialized
INFO - 2026-01-29 03:59:17 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:17 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:17 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:17 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:17 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:17 --> Controller Class Initialized
INFO - 2026-01-29 09:59:17 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Galeri_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Video_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Agenda_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Tautan_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Mitra_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Prodi_model" initialized
INFO - 2026-01-29 09:59:17 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 09:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:59:17 --> Pagination Class Initialized
INFO - 2026-01-29 09:59:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 09:59:17 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:17 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:17 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:17 --> Total execution time: 0.2700
INFO - 2026-01-29 03:59:31 --> Config Class Initialized
INFO - 2026-01-29 03:59:31 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:31 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:31 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:31 --> URI Class Initialized
INFO - 2026-01-29 03:59:31 --> Router Class Initialized
INFO - 2026-01-29 03:59:31 --> Output Class Initialized
INFO - 2026-01-29 03:59:31 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:31 --> CSRF cookie sent
INFO - 2026-01-29 03:59:31 --> Input Class Initialized
INFO - 2026-01-29 03:59:31 --> Language Class Initialized
INFO - 2026-01-29 03:59:31 --> Loader Class Initialized
INFO - 2026-01-29 03:59:31 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:31 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:31 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:31 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:31 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:31 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:31 --> Controller Class Initialized
INFO - 2026-01-29 09:59:31 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:59:31 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:59:31 --> Pagination Class Initialized
INFO - 2026-01-29 09:59:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:59:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:31 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:31 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:31 --> Total execution time: 0.1811
INFO - 2026-01-29 03:59:35 --> Config Class Initialized
INFO - 2026-01-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:35 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:35 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:35 --> URI Class Initialized
INFO - 2026-01-29 03:59:35 --> Router Class Initialized
INFO - 2026-01-29 03:59:35 --> Output Class Initialized
INFO - 2026-01-29 03:59:35 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:35 --> CSRF cookie sent
INFO - 2026-01-29 03:59:35 --> Input Class Initialized
INFO - 2026-01-29 03:59:35 --> Language Class Initialized
INFO - 2026-01-29 03:59:35 --> Loader Class Initialized
INFO - 2026-01-29 03:59:35 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:35 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:35 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:35 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:35 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:35 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:35 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:35 --> Controller Class Initialized
INFO - 2026-01-29 09:59:35 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:59:35 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:59:35 --> Pagination Class Initialized
INFO - 2026-01-29 09:59:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:59:35 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:35 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:35 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:35 --> Total execution time: 0.1734
INFO - 2026-01-29 03:59:38 --> Config Class Initialized
INFO - 2026-01-29 03:59:38 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:38 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:38 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:38 --> URI Class Initialized
INFO - 2026-01-29 03:59:38 --> Router Class Initialized
INFO - 2026-01-29 03:59:38 --> Output Class Initialized
INFO - 2026-01-29 03:59:38 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:38 --> CSRF cookie sent
INFO - 2026-01-29 03:59:38 --> Input Class Initialized
INFO - 2026-01-29 03:59:38 --> Language Class Initialized
INFO - 2026-01-29 03:59:38 --> Loader Class Initialized
INFO - 2026-01-29 03:59:38 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:38 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:38 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:38 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:38 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:38 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:38 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:38 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:38 --> Controller Class Initialized
INFO - 2026-01-29 09:59:38 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:59:38 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:59:38 --> Pagination Class Initialized
INFO - 2026-01-29 09:59:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:59:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:38 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:38 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:38 --> Total execution time: 0.1746
INFO - 2026-01-29 03:59:41 --> Config Class Initialized
INFO - 2026-01-29 03:59:41 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:41 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:41 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:41 --> URI Class Initialized
INFO - 2026-01-29 03:59:41 --> Router Class Initialized
INFO - 2026-01-29 03:59:41 --> Output Class Initialized
INFO - 2026-01-29 03:59:41 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:41 --> CSRF cookie sent
INFO - 2026-01-29 03:59:41 --> Input Class Initialized
INFO - 2026-01-29 03:59:41 --> Language Class Initialized
INFO - 2026-01-29 03:59:41 --> Loader Class Initialized
INFO - 2026-01-29 03:59:41 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:41 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:41 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:41 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:41 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:41 --> Controller Class Initialized
INFO - 2026-01-29 09:59:41 --> Model "Berita_model" initialized
INFO - 2026-01-29 09:59:41 --> Model "Kategori_model" initialized
INFO - 2026-01-29 09:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 09:59:41 --> Pagination Class Initialized
INFO - 2026-01-29 09:59:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 09:59:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:41 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:41 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:41 --> Total execution time: 0.1501
INFO - 2026-01-29 03:59:50 --> Config Class Initialized
INFO - 2026-01-29 03:59:50 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:50 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:50 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:50 --> URI Class Initialized
INFO - 2026-01-29 03:59:50 --> Router Class Initialized
INFO - 2026-01-29 03:59:50 --> Output Class Initialized
INFO - 2026-01-29 03:59:50 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:50 --> CSRF cookie sent
INFO - 2026-01-29 03:59:50 --> Input Class Initialized
INFO - 2026-01-29 03:59:50 --> Language Class Initialized
INFO - 2026-01-29 03:59:50 --> Loader Class Initialized
INFO - 2026-01-29 03:59:50 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:50 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:50 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:50 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:50 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:50 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:50 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:50 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:50 --> Controller Class Initialized
INFO - 2026-01-29 09:59:50 --> Model "Download_model" initialized
INFO - 2026-01-29 09:59:50 --> Model "Kategori_download_model" initialized
INFO - 2026-01-29 09:59:50 --> Model "Jenis_download_model" initialized
INFO - 2026-01-29 09:59:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/akreditasi.php
INFO - 2026-01-29 09:59:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 09:59:50 --> Model "Log_model" initialized
INFO - 2026-01-29 09:59:50 --> Final output sent to browser
DEBUG - 2026-01-29 09:59:50 --> Total execution time: 0.1621
INFO - 2026-01-29 03:59:54 --> Config Class Initialized
INFO - 2026-01-29 03:59:54 --> Hooks Class Initialized
DEBUG - 2026-01-29 03:59:54 --> UTF-8 Support Enabled
INFO - 2026-01-29 03:59:54 --> Utf8 Class Initialized
INFO - 2026-01-29 03:59:54 --> URI Class Initialized
INFO - 2026-01-29 03:59:54 --> Router Class Initialized
INFO - 2026-01-29 03:59:54 --> Output Class Initialized
INFO - 2026-01-29 03:59:54 --> Security Class Initialized
DEBUG - 2026-01-29 03:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 03:59:54 --> CSRF cookie sent
INFO - 2026-01-29 03:59:54 --> Input Class Initialized
INFO - 2026-01-29 03:59:54 --> Language Class Initialized
INFO - 2026-01-29 03:59:54 --> Loader Class Initialized
INFO - 2026-01-29 03:59:54 --> Helper loaded: url_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: text_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: string_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: form_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: download_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: security_helper
INFO - 2026-01-29 03:59:54 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 03:59:54 --> Database Driver Class Initialized
DEBUG - 2026-01-29 03:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 03:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 03:59:54 --> Form Validation Class Initialized
INFO - 2026-01-29 03:59:54 --> Model "User_model" initialized
INFO - 2026-01-29 09:59:54 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 09:59:54 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 09:59:54 --> Model "Nav_model" initialized
INFO - 2026-01-29 09:59:54 --> Controller Class Initialized
INFO - 2026-01-29 09:59:54 --> Model "Download_model" initialized
INFO - 2026-01-29 09:59:54 --> Model "Kategori_download_model" initialized
INFO - 2026-01-29 09:59:54 --> Model "Jenis_download_model" initialized
INFO - 2026-01-29 09:59:54 --> File downloaded: {"ip_address":"::1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/144.0.0.0 Safari\/537.36","download_id":"11","filename":"Sertifikat_Akreditasi_Diploma_Tiga_Keperawatan_Persahabatan_2010-2014.pdf","timestamp":"2026-01-29 09:59:54"}
INFO - 2026-01-29 04:00:33 --> Config Class Initialized
INFO - 2026-01-29 04:00:33 --> Hooks Class Initialized
DEBUG - 2026-01-29 04:00:33 --> UTF-8 Support Enabled
INFO - 2026-01-29 04:00:33 --> Utf8 Class Initialized
INFO - 2026-01-29 04:00:33 --> URI Class Initialized
INFO - 2026-01-29 04:00:33 --> Router Class Initialized
INFO - 2026-01-29 04:00:33 --> Output Class Initialized
INFO - 2026-01-29 04:00:33 --> Security Class Initialized
DEBUG - 2026-01-29 04:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 04:00:33 --> CSRF cookie sent
INFO - 2026-01-29 04:00:33 --> Input Class Initialized
INFO - 2026-01-29 04:00:33 --> Language Class Initialized
INFO - 2026-01-29 04:00:33 --> Loader Class Initialized
INFO - 2026-01-29 04:00:33 --> Helper loaded: url_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: text_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: string_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: form_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: download_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: security_helper
INFO - 2026-01-29 04:00:33 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 04:00:33 --> Database Driver Class Initialized
DEBUG - 2026-01-29 04:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 04:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 04:00:33 --> Form Validation Class Initialized
INFO - 2026-01-29 04:00:33 --> Model "User_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Nav_model" initialized
INFO - 2026-01-29 10:00:33 --> Controller Class Initialized
INFO - 2026-01-29 10:00:33 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Prodi_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Sdm_model" initialized
INFO - 2026-01-29 10:00:33 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 10:00:34 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2026-01-29 10:00:34 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 10:00:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 10:00:34 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 10:00:34 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 10:00:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 10:00:34 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 10:00:34 --> Model "Log_model" initialized
INFO - 2026-01-29 10:00:34 --> Final output sent to browser
DEBUG - 2026-01-29 10:00:34 --> Total execution time: 0.2580
INFO - 2026-01-29 04:00:41 --> Config Class Initialized
INFO - 2026-01-29 04:00:41 --> Hooks Class Initialized
DEBUG - 2026-01-29 04:00:41 --> UTF-8 Support Enabled
INFO - 2026-01-29 04:00:41 --> Utf8 Class Initialized
INFO - 2026-01-29 04:00:41 --> URI Class Initialized
INFO - 2026-01-29 04:00:41 --> Router Class Initialized
INFO - 2026-01-29 04:00:41 --> Output Class Initialized
INFO - 2026-01-29 04:00:41 --> Security Class Initialized
DEBUG - 2026-01-29 04:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 04:00:41 --> CSRF cookie sent
INFO - 2026-01-29 04:00:41 --> Input Class Initialized
INFO - 2026-01-29 04:00:41 --> Language Class Initialized
INFO - 2026-01-29 04:00:41 --> Loader Class Initialized
INFO - 2026-01-29 04:00:41 --> Helper loaded: url_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: text_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: string_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: form_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: download_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: security_helper
INFO - 2026-01-29 04:00:41 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 04:00:41 --> Database Driver Class Initialized
DEBUG - 2026-01-29 04:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 04:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 04:00:41 --> Form Validation Class Initialized
INFO - 2026-01-29 04:00:41 --> Model "User_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Nav_model" initialized
INFO - 2026-01-29 10:00:41 --> Controller Class Initialized
INFO - 2026-01-29 10:00:41 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Prodi_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Sdm_model" initialized
INFO - 2026-01-29 10:00:41 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-29 10:00:41 --> Query SDM berhasil untuk jurusan: Fisioterapi, Total: 1
ERROR - 2026-01-29 10:00:41 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 10:00:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-29 10:00:41 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-29 10:00:41 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-29 10:00:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-29 10:00:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 10:00:41 --> Model "Log_model" initialized
INFO - 2026-01-29 10:00:41 --> Final output sent to browser
DEBUG - 2026-01-29 10:00:41 --> Total execution time: 0.2455
INFO - 2026-01-29 07:36:53 --> Config Class Initialized
INFO - 2026-01-29 07:36:53 --> Hooks Class Initialized
DEBUG - 2026-01-29 07:36:53 --> UTF-8 Support Enabled
INFO - 2026-01-29 07:36:53 --> Utf8 Class Initialized
INFO - 2026-01-29 07:36:53 --> URI Class Initialized
INFO - 2026-01-29 07:36:53 --> Router Class Initialized
INFO - 2026-01-29 07:36:54 --> Output Class Initialized
INFO - 2026-01-29 07:36:54 --> Security Class Initialized
DEBUG - 2026-01-29 07:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 07:36:54 --> CSRF cookie sent
INFO - 2026-01-29 07:36:54 --> Input Class Initialized
INFO - 2026-01-29 07:36:54 --> Language Class Initialized
INFO - 2026-01-29 07:36:54 --> Loader Class Initialized
INFO - 2026-01-29 07:36:54 --> Helper loaded: url_helper
INFO - 2026-01-29 07:36:54 --> Helper loaded: text_helper
INFO - 2026-01-29 07:36:54 --> Helper loaded: string_helper
INFO - 2026-01-29 07:36:54 --> Helper loaded: form_helper
INFO - 2026-01-29 07:36:55 --> Helper loaded: download_helper
INFO - 2026-01-29 07:36:55 --> Helper loaded: security_helper
INFO - 2026-01-29 07:36:55 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 07:36:55 --> Database Driver Class Initialized
DEBUG - 2026-01-29 07:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 07:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 07:36:56 --> Form Validation Class Initialized
INFO - 2026-01-29 07:36:56 --> Model "User_model" initialized
INFO - 2026-01-29 13:36:56 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 13:36:56 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 13:36:56 --> Model "Nav_model" initialized
INFO - 2026-01-29 13:36:56 --> Controller Class Initialized
INFO - 2026-01-29 13:36:56 --> Model "Download_model" initialized
INFO - 2026-01-29 13:36:56 --> Model "Kategori_download_model" initialized
INFO - 2026-01-29 13:36:56 --> Model "Jenis_download_model" initialized
INFO - 2026-01-29 13:36:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-29 13:36:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 13:36:57 --> Model "Log_model" initialized
INFO - 2026-01-29 13:36:57 --> Final output sent to browser
DEBUG - 2026-01-29 13:36:57 --> Total execution time: 4.7364
INFO - 2026-01-29 07:37:15 --> Config Class Initialized
INFO - 2026-01-29 07:37:15 --> Hooks Class Initialized
DEBUG - 2026-01-29 07:37:15 --> UTF-8 Support Enabled
INFO - 2026-01-29 07:37:15 --> Utf8 Class Initialized
INFO - 2026-01-29 07:37:15 --> URI Class Initialized
DEBUG - 2026-01-29 07:37:15 --> No URI present. Default controller set.
INFO - 2026-01-29 07:37:15 --> Router Class Initialized
INFO - 2026-01-29 07:37:16 --> Output Class Initialized
INFO - 2026-01-29 07:37:16 --> Security Class Initialized
DEBUG - 2026-01-29 07:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 07:37:16 --> CSRF cookie sent
INFO - 2026-01-29 07:37:16 --> Input Class Initialized
INFO - 2026-01-29 07:37:16 --> Language Class Initialized
INFO - 2026-01-29 07:37:16 --> Loader Class Initialized
INFO - 2026-01-29 07:37:16 --> Helper loaded: url_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: text_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: string_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: form_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: download_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: security_helper
INFO - 2026-01-29 07:37:16 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 07:37:16 --> Database Driver Class Initialized
DEBUG - 2026-01-29 07:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 07:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 07:37:16 --> Form Validation Class Initialized
INFO - 2026-01-29 07:37:16 --> Model "User_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Nav_model" initialized
INFO - 2026-01-29 13:37:16 --> Controller Class Initialized
INFO - 2026-01-29 13:37:16 --> Model "Berita_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Galeri_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Video_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Agenda_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Tautan_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Mitra_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Jurusan_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Prodi_model" initialized
INFO - 2026-01-29 13:37:16 --> Model "Testimoni_model" initialized
INFO - 2026-01-29 13:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 13:37:16 --> Pagination Class Initialized
INFO - 2026-01-29 13:37:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-29 13:37:18 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 13:37:18 --> Model "Log_model" initialized
INFO - 2026-01-29 13:37:18 --> Final output sent to browser
DEBUG - 2026-01-29 13:37:18 --> Total execution time: 2.9947
INFO - 2026-01-29 07:43:09 --> Config Class Initialized
INFO - 2026-01-29 07:43:09 --> Hooks Class Initialized
DEBUG - 2026-01-29 07:43:09 --> UTF-8 Support Enabled
INFO - 2026-01-29 07:43:09 --> Utf8 Class Initialized
INFO - 2026-01-29 07:43:09 --> URI Class Initialized
INFO - 2026-01-29 07:43:09 --> Router Class Initialized
INFO - 2026-01-29 07:43:09 --> Output Class Initialized
INFO - 2026-01-29 07:43:09 --> Security Class Initialized
DEBUG - 2026-01-29 07:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-29 07:43:09 --> CSRF cookie sent
INFO - 2026-01-29 07:43:09 --> Input Class Initialized
INFO - 2026-01-29 07:43:09 --> Language Class Initialized
INFO - 2026-01-29 07:43:09 --> Loader Class Initialized
INFO - 2026-01-29 07:43:09 --> Helper loaded: url_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: text_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: string_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: form_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: download_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: security_helper
INFO - 2026-01-29 07:43:09 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-29 07:43:09 --> Database Driver Class Initialized
DEBUG - 2026-01-29 07:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-29 07:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-29 07:43:09 --> Form Validation Class Initialized
INFO - 2026-01-29 07:43:09 --> Model "User_model" initialized
INFO - 2026-01-29 13:43:09 --> Model "Kunjungan_model" initialized
INFO - 2026-01-29 13:43:09 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-29 13:43:09 --> Model "Nav_model" initialized
INFO - 2026-01-29 13:43:09 --> Controller Class Initialized
INFO - 2026-01-29 13:43:09 --> Model "Berita_model" initialized
INFO - 2026-01-29 13:43:09 --> Model "Kategori_model" initialized
INFO - 2026-01-29 13:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-29 13:43:09 --> Pagination Class Initialized
INFO - 2026-01-29 13:43:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\berita/list.php
INFO - 2026-01-29 13:43:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-29 13:43:09 --> Model "Log_model" initialized
INFO - 2026-01-29 13:43:09 --> Final output sent to browser
DEBUG - 2026-01-29 13:43:09 --> Total execution time: 0.4616
