<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-05 05:04:32 --> Config Class Initialized
INFO - 2026-01-05 05:04:32 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:04:32 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:04:32 --> Utf8 Class Initialized
INFO - 2026-01-05 05:04:32 --> URI Class Initialized
DEBUG - 2026-01-05 05:04:32 --> No URI present. Default controller set.
INFO - 2026-01-05 05:04:32 --> Router Class Initialized
INFO - 2026-01-05 05:04:33 --> Output Class Initialized
INFO - 2026-01-05 05:04:33 --> Security Class Initialized
DEBUG - 2026-01-05 05:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:04:33 --> CSRF cookie sent
INFO - 2026-01-05 05:04:33 --> Input Class Initialized
INFO - 2026-01-05 05:04:33 --> Language Class Initialized
INFO - 2026-01-05 05:04:33 --> Loader Class Initialized
INFO - 2026-01-05 05:04:33 --> Helper loaded: url_helper
INFO - 2026-01-05 05:04:33 --> Helper loaded: text_helper
INFO - 2026-01-05 05:04:33 --> Helper loaded: string_helper
INFO - 2026-01-05 05:04:33 --> Helper loaded: form_helper
INFO - 2026-01-05 05:04:33 --> Helper loaded: download_helper
INFO - 2026-01-05 05:04:34 --> Helper loaded: security_helper
INFO - 2026-01-05 05:04:34 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:04:34 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:04:34 --> Form Validation Class Initialized
INFO - 2026-01-05 05:04:34 --> Model "User_model" initialized
INFO - 2026-01-05 11:04:34 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:04:34 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:04:34 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:04:34 --> Controller Class Initialized
INFO - 2026-01-05 11:04:34 --> Model "Berita_model" initialized
INFO - 2026-01-05 11:04:35 --> Model "Galeri_model" initialized
INFO - 2026-01-05 11:04:35 --> Model "Video_model" initialized
INFO - 2026-01-05 11:04:35 --> Model "Agenda_model" initialized
INFO - 2026-01-05 11:04:35 --> Model "Tautan_model" initialized
INFO - 2026-01-05 11:04:35 --> Model "Mitra_model" initialized
INFO - 2026-01-05 11:04:35 --> Model "Jurusan_model" initialized
INFO - 2026-01-05 11:04:35 --> Model "Prodi_model" initialized
INFO - 2026-01-05 11:04:35 --> Model "Testimoni_model" initialized
INFO - 2026-01-05 11:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-05 11:04:35 --> Pagination Class Initialized
INFO - 2026-01-05 11:04:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-05 11:04:38 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:04:38 --> Model "Log_model" initialized
INFO - 2026-01-05 11:04:38 --> Final output sent to browser
DEBUG - 2026-01-05 11:04:38 --> Total execution time: 5.8581
INFO - 2026-01-05 05:09:34 --> Config Class Initialized
INFO - 2026-01-05 05:09:34 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:09:34 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:09:34 --> Utf8 Class Initialized
INFO - 2026-01-05 05:09:34 --> URI Class Initialized
INFO - 2026-01-05 05:09:34 --> Router Class Initialized
INFO - 2026-01-05 05:09:35 --> Output Class Initialized
INFO - 2026-01-05 05:09:35 --> Security Class Initialized
DEBUG - 2026-01-05 05:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:09:35 --> CSRF cookie sent
INFO - 2026-01-05 05:09:35 --> Input Class Initialized
INFO - 2026-01-05 05:09:35 --> Language Class Initialized
INFO - 2026-01-05 05:09:35 --> Loader Class Initialized
INFO - 2026-01-05 05:09:35 --> Helper loaded: url_helper
INFO - 2026-01-05 05:09:35 --> Helper loaded: text_helper
INFO - 2026-01-05 05:09:35 --> Helper loaded: string_helper
INFO - 2026-01-05 05:09:35 --> Helper loaded: form_helper
INFO - 2026-01-05 05:09:35 --> Helper loaded: download_helper
INFO - 2026-01-05 05:09:35 --> Helper loaded: security_helper
INFO - 2026-01-05 05:09:35 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:09:36 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:09:36 --> Form Validation Class Initialized
INFO - 2026-01-05 05:09:36 --> Model "User_model" initialized
INFO - 2026-01-05 11:09:36 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:09:36 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:09:36 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:09:36 --> Controller Class Initialized
INFO - 2026-01-05 11:09:36 --> Model "Pages_model" initialized
INFO - 2026-01-05 11:09:36 --> Model "Berita_model" initialized
INFO - 2026-01-05 11:09:36 --> Model "Download_model" initialized
INFO - 2026-01-05 11:09:36 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 11:09:36 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 11:09:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-05 11:09:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:09:37 --> Model "Log_model" initialized
INFO - 2026-01-05 11:09:37 --> Final output sent to browser
DEBUG - 2026-01-05 11:09:37 --> Total execution time: 3.3660
INFO - 2026-01-05 05:10:11 --> Config Class Initialized
INFO - 2026-01-05 05:10:11 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:10:11 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:10:11 --> Utf8 Class Initialized
INFO - 2026-01-05 05:10:11 --> URI Class Initialized
INFO - 2026-01-05 05:10:11 --> Router Class Initialized
INFO - 2026-01-05 05:10:11 --> Output Class Initialized
INFO - 2026-01-05 05:10:11 --> Security Class Initialized
DEBUG - 2026-01-05 05:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:10:11 --> CSRF cookie sent
INFO - 2026-01-05 05:10:11 --> Input Class Initialized
INFO - 2026-01-05 05:10:11 --> Language Class Initialized
INFO - 2026-01-05 05:10:11 --> Loader Class Initialized
INFO - 2026-01-05 05:10:11 --> Helper loaded: url_helper
INFO - 2026-01-05 05:10:11 --> Helper loaded: text_helper
INFO - 2026-01-05 05:10:11 --> Helper loaded: string_helper
INFO - 2026-01-05 05:10:11 --> Helper loaded: form_helper
INFO - 2026-01-05 05:10:11 --> Helper loaded: download_helper
INFO - 2026-01-05 05:10:11 --> Helper loaded: security_helper
INFO - 2026-01-05 05:10:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:10:11 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:10:11 --> Form Validation Class Initialized
INFO - 2026-01-05 05:10:11 --> Model "User_model" initialized
INFO - 2026-01-05 11:10:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:10:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:10:12 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:10:12 --> Controller Class Initialized
INFO - 2026-01-05 11:10:12 --> Model "Pages_model" initialized
INFO - 2026-01-05 11:10:12 --> Model "Berita_model" initialized
INFO - 2026-01-05 11:10:12 --> Model "Download_model" initialized
INFO - 2026-01-05 11:10:12 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 11:10:12 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 11:10:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-05 11:10:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:10:12 --> Model "Log_model" initialized
INFO - 2026-01-05 11:10:12 --> Final output sent to browser
DEBUG - 2026-01-05 11:10:12 --> Total execution time: 0.1396
INFO - 2026-01-05 05:10:19 --> Config Class Initialized
INFO - 2026-01-05 05:10:19 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:10:19 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:10:19 --> Utf8 Class Initialized
INFO - 2026-01-05 05:10:19 --> URI Class Initialized
INFO - 2026-01-05 05:10:19 --> Router Class Initialized
INFO - 2026-01-05 05:10:19 --> Output Class Initialized
INFO - 2026-01-05 05:10:19 --> Security Class Initialized
DEBUG - 2026-01-05 05:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:10:19 --> CSRF cookie sent
INFO - 2026-01-05 05:10:19 --> Input Class Initialized
INFO - 2026-01-05 05:10:19 --> Language Class Initialized
INFO - 2026-01-05 05:10:19 --> Loader Class Initialized
INFO - 2026-01-05 05:10:19 --> Helper loaded: url_helper
INFO - 2026-01-05 05:10:19 --> Helper loaded: text_helper
INFO - 2026-01-05 05:10:19 --> Helper loaded: string_helper
INFO - 2026-01-05 05:10:19 --> Helper loaded: form_helper
INFO - 2026-01-05 05:10:19 --> Helper loaded: download_helper
INFO - 2026-01-05 05:10:19 --> Helper loaded: security_helper
INFO - 2026-01-05 05:10:19 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:10:19 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:10:19 --> Form Validation Class Initialized
INFO - 2026-01-05 05:10:19 --> Model "User_model" initialized
INFO - 2026-01-05 11:10:19 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:10:19 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:10:19 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:10:19 --> Controller Class Initialized
INFO - 2026-01-05 11:10:19 --> Model "Pages_model" initialized
INFO - 2026-01-05 11:10:19 --> Model "Berita_model" initialized
INFO - 2026-01-05 11:10:19 --> Model "Download_model" initialized
INFO - 2026-01-05 11:10:19 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 11:10:19 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 11:10:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-05 11:10:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:10:19 --> Model "Log_model" initialized
INFO - 2026-01-05 11:10:19 --> Final output sent to browser
DEBUG - 2026-01-05 11:10:19 --> Total execution time: 0.1069
INFO - 2026-01-05 05:10:20 --> Config Class Initialized
INFO - 2026-01-05 05:10:20 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:10:20 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:10:20 --> Utf8 Class Initialized
INFO - 2026-01-05 05:10:20 --> URI Class Initialized
INFO - 2026-01-05 05:10:20 --> Router Class Initialized
INFO - 2026-01-05 05:10:20 --> Output Class Initialized
INFO - 2026-01-05 05:10:20 --> Security Class Initialized
DEBUG - 2026-01-05 05:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:10:20 --> CSRF cookie sent
INFO - 2026-01-05 05:10:20 --> Input Class Initialized
INFO - 2026-01-05 05:10:20 --> Language Class Initialized
INFO - 2026-01-05 05:10:20 --> Loader Class Initialized
INFO - 2026-01-05 05:10:20 --> Helper loaded: url_helper
INFO - 2026-01-05 05:10:20 --> Helper loaded: text_helper
INFO - 2026-01-05 05:10:20 --> Helper loaded: string_helper
INFO - 2026-01-05 05:10:20 --> Helper loaded: form_helper
INFO - 2026-01-05 05:10:20 --> Helper loaded: download_helper
INFO - 2026-01-05 05:10:20 --> Helper loaded: security_helper
INFO - 2026-01-05 05:10:20 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:10:20 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:10:20 --> Form Validation Class Initialized
INFO - 2026-01-05 05:10:20 --> Model "User_model" initialized
INFO - 2026-01-05 11:10:20 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:10:20 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:10:20 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:10:20 --> Controller Class Initialized
INFO - 2026-01-05 11:10:20 --> Model "Pages_model" initialized
INFO - 2026-01-05 11:10:20 --> Model "Berita_model" initialized
INFO - 2026-01-05 11:10:20 --> Model "Download_model" initialized
INFO - 2026-01-05 11:10:20 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 11:10:20 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 11:10:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-05 11:10:20 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:10:20 --> Model "Log_model" initialized
INFO - 2026-01-05 11:10:20 --> Final output sent to browser
DEBUG - 2026-01-05 11:10:20 --> Total execution time: 0.1412
INFO - 2026-01-05 05:10:31 --> Config Class Initialized
INFO - 2026-01-05 05:10:31 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:10:31 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:10:31 --> Utf8 Class Initialized
INFO - 2026-01-05 05:10:31 --> URI Class Initialized
INFO - 2026-01-05 05:10:31 --> Router Class Initialized
INFO - 2026-01-05 05:10:31 --> Output Class Initialized
INFO - 2026-01-05 05:10:31 --> Security Class Initialized
DEBUG - 2026-01-05 05:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:10:31 --> CSRF cookie sent
INFO - 2026-01-05 05:10:31 --> Input Class Initialized
INFO - 2026-01-05 05:10:31 --> Language Class Initialized
INFO - 2026-01-05 05:10:31 --> Loader Class Initialized
INFO - 2026-01-05 05:10:31 --> Helper loaded: url_helper
INFO - 2026-01-05 05:10:31 --> Helper loaded: text_helper
INFO - 2026-01-05 05:10:31 --> Helper loaded: string_helper
INFO - 2026-01-05 05:10:31 --> Helper loaded: form_helper
INFO - 2026-01-05 05:10:31 --> Helper loaded: download_helper
INFO - 2026-01-05 05:10:31 --> Helper loaded: security_helper
INFO - 2026-01-05 05:10:31 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:10:31 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:10:31 --> Form Validation Class Initialized
INFO - 2026-01-05 05:10:31 --> Model "User_model" initialized
INFO - 2026-01-05 11:10:31 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:10:31 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:10:31 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:10:31 --> Controller Class Initialized
INFO - 2026-01-05 11:10:31 --> Model "Pages_model" initialized
INFO - 2026-01-05 11:10:31 --> Model "Berita_model" initialized
INFO - 2026-01-05 11:10:31 --> Model "Download_model" initialized
INFO - 2026-01-05 11:10:31 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 11:10:31 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 11:10:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-05 11:10:31 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:10:31 --> Model "Log_model" initialized
INFO - 2026-01-05 11:10:31 --> Final output sent to browser
DEBUG - 2026-01-05 11:10:31 --> Total execution time: 0.1127
INFO - 2026-01-05 05:10:39 --> Config Class Initialized
INFO - 2026-01-05 05:10:39 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:10:39 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:10:39 --> Utf8 Class Initialized
INFO - 2026-01-05 05:10:39 --> URI Class Initialized
INFO - 2026-01-05 05:10:39 --> Router Class Initialized
INFO - 2026-01-05 05:10:39 --> Output Class Initialized
INFO - 2026-01-05 05:10:39 --> Security Class Initialized
DEBUG - 2026-01-05 05:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:10:39 --> CSRF cookie sent
INFO - 2026-01-05 05:10:39 --> Input Class Initialized
INFO - 2026-01-05 05:10:39 --> Language Class Initialized
INFO - 2026-01-05 05:10:39 --> Loader Class Initialized
INFO - 2026-01-05 05:10:39 --> Helper loaded: url_helper
INFO - 2026-01-05 05:10:39 --> Helper loaded: text_helper
INFO - 2026-01-05 05:10:39 --> Helper loaded: string_helper
INFO - 2026-01-05 05:10:39 --> Helper loaded: form_helper
INFO - 2026-01-05 05:10:39 --> Helper loaded: download_helper
INFO - 2026-01-05 05:10:39 --> Helper loaded: security_helper
INFO - 2026-01-05 05:10:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:10:39 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:10:39 --> Form Validation Class Initialized
INFO - 2026-01-05 05:10:39 --> Model "User_model" initialized
INFO - 2026-01-05 11:10:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:10:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:10:39 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:10:39 --> Controller Class Initialized
INFO - 2026-01-05 11:10:39 --> Model "Pages_model" initialized
INFO - 2026-01-05 11:10:39 --> Model "Berita_model" initialized
INFO - 2026-01-05 11:10:39 --> Model "Download_model" initialized
INFO - 2026-01-05 11:10:39 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 11:10:39 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 11:10:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-05 11:10:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:10:39 --> Model "Log_model" initialized
INFO - 2026-01-05 11:10:39 --> Final output sent to browser
DEBUG - 2026-01-05 11:10:39 --> Total execution time: 0.0958
INFO - 2026-01-05 05:10:40 --> Config Class Initialized
INFO - 2026-01-05 05:10:40 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:10:40 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:10:40 --> Utf8 Class Initialized
INFO - 2026-01-05 05:10:40 --> URI Class Initialized
INFO - 2026-01-05 05:10:40 --> Router Class Initialized
INFO - 2026-01-05 05:10:40 --> Output Class Initialized
INFO - 2026-01-05 05:10:40 --> Security Class Initialized
DEBUG - 2026-01-05 05:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:10:40 --> CSRF cookie sent
INFO - 2026-01-05 05:10:40 --> Input Class Initialized
INFO - 2026-01-05 05:10:40 --> Language Class Initialized
INFO - 2026-01-05 05:10:40 --> Loader Class Initialized
INFO - 2026-01-05 05:10:40 --> Helper loaded: url_helper
INFO - 2026-01-05 05:10:40 --> Helper loaded: text_helper
INFO - 2026-01-05 05:10:40 --> Helper loaded: string_helper
INFO - 2026-01-05 05:10:40 --> Helper loaded: form_helper
INFO - 2026-01-05 05:10:40 --> Helper loaded: download_helper
INFO - 2026-01-05 05:10:40 --> Helper loaded: security_helper
INFO - 2026-01-05 05:10:40 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:10:40 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:10:40 --> Form Validation Class Initialized
INFO - 2026-01-05 05:10:40 --> Model "User_model" initialized
INFO - 2026-01-05 11:10:40 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:10:40 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:10:40 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:10:40 --> Controller Class Initialized
INFO - 2026-01-05 11:10:40 --> Model "Pages_model" initialized
INFO - 2026-01-05 11:10:40 --> Model "Berita_model" initialized
INFO - 2026-01-05 11:10:40 --> Model "Download_model" initialized
INFO - 2026-01-05 11:10:40 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 11:10:40 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 11:10:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-05 11:10:40 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:10:40 --> Model "Log_model" initialized
INFO - 2026-01-05 11:10:40 --> Final output sent to browser
DEBUG - 2026-01-05 11:10:40 --> Total execution time: 0.1218
INFO - 2026-01-05 05:11:04 --> Config Class Initialized
INFO - 2026-01-05 05:11:04 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:11:04 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:11:04 --> Utf8 Class Initialized
INFO - 2026-01-05 05:11:04 --> URI Class Initialized
INFO - 2026-01-05 05:11:04 --> Router Class Initialized
INFO - 2026-01-05 05:11:04 --> Output Class Initialized
INFO - 2026-01-05 05:11:04 --> Security Class Initialized
DEBUG - 2026-01-05 05:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:11:04 --> CSRF cookie sent
INFO - 2026-01-05 05:11:04 --> Input Class Initialized
INFO - 2026-01-05 05:11:04 --> Language Class Initialized
INFO - 2026-01-05 05:11:04 --> Loader Class Initialized
INFO - 2026-01-05 05:11:04 --> Helper loaded: url_helper
INFO - 2026-01-05 05:11:04 --> Helper loaded: text_helper
INFO - 2026-01-05 05:11:04 --> Helper loaded: string_helper
INFO - 2026-01-05 05:11:04 --> Helper loaded: form_helper
INFO - 2026-01-05 05:11:04 --> Helper loaded: download_helper
INFO - 2026-01-05 05:11:04 --> Helper loaded: security_helper
INFO - 2026-01-05 05:11:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:11:04 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:11:04 --> Form Validation Class Initialized
INFO - 2026-01-05 05:11:04 --> Model "User_model" initialized
INFO - 2026-01-05 11:11:04 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:11:04 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:11:04 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:11:04 --> Controller Class Initialized
INFO - 2026-01-05 11:11:04 --> Model "Pages_model" initialized
INFO - 2026-01-05 11:11:04 --> Model "Berita_model" initialized
INFO - 2026-01-05 11:11:04 --> Model "Download_model" initialized
INFO - 2026-01-05 11:11:04 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 11:11:04 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 11:11:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-05 11:11:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:11:04 --> Model "Log_model" initialized
INFO - 2026-01-05 11:11:04 --> Final output sent to browser
DEBUG - 2026-01-05 11:11:04 --> Total execution time: 0.1477
INFO - 2026-01-05 05:11:39 --> Config Class Initialized
INFO - 2026-01-05 05:11:39 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:11:39 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:11:39 --> Utf8 Class Initialized
INFO - 2026-01-05 05:11:39 --> URI Class Initialized
INFO - 2026-01-05 05:11:39 --> Router Class Initialized
INFO - 2026-01-05 05:11:39 --> Output Class Initialized
INFO - 2026-01-05 05:11:39 --> Security Class Initialized
DEBUG - 2026-01-05 05:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:11:39 --> CSRF cookie sent
INFO - 2026-01-05 05:11:39 --> Input Class Initialized
INFO - 2026-01-05 05:11:39 --> Language Class Initialized
INFO - 2026-01-05 05:11:39 --> Loader Class Initialized
INFO - 2026-01-05 05:11:39 --> Helper loaded: url_helper
INFO - 2026-01-05 05:11:39 --> Helper loaded: text_helper
INFO - 2026-01-05 05:11:39 --> Helper loaded: string_helper
INFO - 2026-01-05 05:11:39 --> Helper loaded: form_helper
INFO - 2026-01-05 05:11:39 --> Helper loaded: download_helper
INFO - 2026-01-05 05:11:39 --> Helper loaded: security_helper
INFO - 2026-01-05 05:11:39 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:11:39 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:11:39 --> Form Validation Class Initialized
INFO - 2026-01-05 05:11:39 --> Model "User_model" initialized
INFO - 2026-01-05 11:11:39 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:11:39 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:11:39 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:11:39 --> Controller Class Initialized
INFO - 2026-01-05 11:11:39 --> Model "Pages_model" initialized
INFO - 2026-01-05 11:11:39 --> Model "Berita_model" initialized
INFO - 2026-01-05 11:11:39 --> Model "Download_model" initialized
INFO - 2026-01-05 11:11:39 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 11:11:39 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 11:11:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/profil.php
INFO - 2026-01-05 11:11:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:11:39 --> Model "Log_model" initialized
INFO - 2026-01-05 11:11:39 --> Final output sent to browser
DEBUG - 2026-01-05 11:11:39 --> Total execution time: 0.1230
INFO - 2026-01-05 05:11:45 --> Config Class Initialized
INFO - 2026-01-05 05:11:45 --> Hooks Class Initialized
DEBUG - 2026-01-05 05:11:45 --> UTF-8 Support Enabled
INFO - 2026-01-05 05:11:45 --> Utf8 Class Initialized
INFO - 2026-01-05 05:11:45 --> URI Class Initialized
INFO - 2026-01-05 05:11:45 --> Router Class Initialized
INFO - 2026-01-05 05:11:45 --> Output Class Initialized
INFO - 2026-01-05 05:11:45 --> Security Class Initialized
DEBUG - 2026-01-05 05:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 05:11:45 --> CSRF cookie sent
INFO - 2026-01-05 05:11:45 --> Input Class Initialized
INFO - 2026-01-05 05:11:45 --> Language Class Initialized
INFO - 2026-01-05 05:11:45 --> Loader Class Initialized
INFO - 2026-01-05 05:11:45 --> Helper loaded: url_helper
INFO - 2026-01-05 05:11:45 --> Helper loaded: text_helper
INFO - 2026-01-05 05:11:45 --> Helper loaded: string_helper
INFO - 2026-01-05 05:11:45 --> Helper loaded: form_helper
INFO - 2026-01-05 05:11:45 --> Helper loaded: download_helper
INFO - 2026-01-05 05:11:45 --> Helper loaded: security_helper
INFO - 2026-01-05 05:11:45 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 05:11:45 --> Database Driver Class Initialized
DEBUG - 2026-01-05 05:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 05:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 05:11:45 --> Form Validation Class Initialized
INFO - 2026-01-05 05:11:45 --> Model "User_model" initialized
INFO - 2026-01-05 11:11:45 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 11:11:45 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 11:11:45 --> Model "Nav_model" initialized
INFO - 2026-01-05 11:11:45 --> Controller Class Initialized
INFO - 2026-01-05 11:11:45 --> Model "Download_model" initialized
INFO - 2026-01-05 11:11:45 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 11:11:45 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 11:11:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-05 11:11:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 11:11:45 --> Model "Log_model" initialized
INFO - 2026-01-05 11:11:45 --> Final output sent to browser
DEBUG - 2026-01-05 11:11:45 --> Total execution time: 0.8050
INFO - 2026-01-05 07:24:11 --> Config Class Initialized
INFO - 2026-01-05 07:24:11 --> Hooks Class Initialized
DEBUG - 2026-01-05 07:24:11 --> UTF-8 Support Enabled
INFO - 2026-01-05 07:24:11 --> Utf8 Class Initialized
INFO - 2026-01-05 07:24:11 --> URI Class Initialized
DEBUG - 2026-01-05 07:24:11 --> No URI present. Default controller set.
INFO - 2026-01-05 07:24:11 --> Router Class Initialized
INFO - 2026-01-05 07:24:11 --> Output Class Initialized
INFO - 2026-01-05 07:24:11 --> Security Class Initialized
DEBUG - 2026-01-05 07:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 07:24:11 --> CSRF cookie sent
INFO - 2026-01-05 07:24:11 --> Input Class Initialized
INFO - 2026-01-05 07:24:11 --> Language Class Initialized
INFO - 2026-01-05 07:24:11 --> Loader Class Initialized
INFO - 2026-01-05 07:24:11 --> Helper loaded: url_helper
INFO - 2026-01-05 07:24:11 --> Helper loaded: text_helper
INFO - 2026-01-05 07:24:11 --> Helper loaded: string_helper
INFO - 2026-01-05 07:24:11 --> Helper loaded: form_helper
INFO - 2026-01-05 07:24:11 --> Helper loaded: download_helper
INFO - 2026-01-05 07:24:11 --> Helper loaded: security_helper
INFO - 2026-01-05 07:24:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 07:24:11 --> Database Driver Class Initialized
DEBUG - 2026-01-05 07:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 07:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 07:24:11 --> Form Validation Class Initialized
INFO - 2026-01-05 07:24:11 --> Model "User_model" initialized
INFO - 2026-01-05 13:24:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 13:24:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 13:24:11 --> Model "Nav_model" initialized
INFO - 2026-01-05 13:24:11 --> Controller Class Initialized
INFO - 2026-01-05 13:24:11 --> Model "Berita_model" initialized
INFO - 2026-01-05 13:24:11 --> Model "Galeri_model" initialized
INFO - 2026-01-05 13:24:11 --> Model "Video_model" initialized
INFO - 2026-01-05 13:24:11 --> Model "Agenda_model" initialized
INFO - 2026-01-05 13:24:11 --> Model "Tautan_model" initialized
INFO - 2026-01-05 13:24:11 --> Model "Mitra_model" initialized
INFO - 2026-01-05 13:24:12 --> Model "Jurusan_model" initialized
INFO - 2026-01-05 13:24:12 --> Model "Prodi_model" initialized
INFO - 2026-01-05 13:24:12 --> Model "Testimoni_model" initialized
INFO - 2026-01-05 13:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-05 13:24:12 --> Pagination Class Initialized
INFO - 2026-01-05 13:24:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-05 13:24:14 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 13:24:14 --> Model "Log_model" initialized
INFO - 2026-01-05 13:24:14 --> Final output sent to browser
DEBUG - 2026-01-05 13:24:14 --> Total execution time: 2.4510
INFO - 2026-01-05 07:24:30 --> Config Class Initialized
INFO - 2026-01-05 07:24:30 --> Hooks Class Initialized
DEBUG - 2026-01-05 07:24:30 --> UTF-8 Support Enabled
INFO - 2026-01-05 07:24:30 --> Utf8 Class Initialized
INFO - 2026-01-05 07:24:30 --> URI Class Initialized
INFO - 2026-01-05 07:24:30 --> Router Class Initialized
INFO - 2026-01-05 07:24:30 --> Output Class Initialized
INFO - 2026-01-05 07:24:30 --> Security Class Initialized
DEBUG - 2026-01-05 07:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 07:24:30 --> CSRF cookie sent
INFO - 2026-01-05 07:24:30 --> Input Class Initialized
INFO - 2026-01-05 07:24:30 --> Language Class Initialized
INFO - 2026-01-05 07:24:30 --> Loader Class Initialized
INFO - 2026-01-05 07:24:30 --> Helper loaded: url_helper
INFO - 2026-01-05 07:24:30 --> Helper loaded: text_helper
INFO - 2026-01-05 07:24:30 --> Helper loaded: string_helper
INFO - 2026-01-05 07:24:30 --> Helper loaded: form_helper
INFO - 2026-01-05 07:24:30 --> Helper loaded: download_helper
INFO - 2026-01-05 07:24:30 --> Helper loaded: security_helper
INFO - 2026-01-05 07:24:30 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 07:24:30 --> Database Driver Class Initialized
DEBUG - 2026-01-05 07:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 07:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 07:24:30 --> Form Validation Class Initialized
INFO - 2026-01-05 07:24:30 --> Model "User_model" initialized
INFO - 2026-01-05 13:24:30 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 13:24:30 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 13:24:30 --> Model "Nav_model" initialized
INFO - 2026-01-05 13:24:30 --> Controller Class Initialized
INFO - 2026-01-05 13:24:30 --> Model "Download_model" initialized
INFO - 2026-01-05 13:24:30 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 13:24:30 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 13:24:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\download/list_akuntabilitas.php
INFO - 2026-01-05 13:24:30 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 13:24:30 --> Model "Log_model" initialized
INFO - 2026-01-05 13:24:30 --> Final output sent to browser
DEBUG - 2026-01-05 13:24:30 --> Total execution time: 0.1750
INFO - 2026-01-05 07:24:32 --> Config Class Initialized
INFO - 2026-01-05 07:24:32 --> Hooks Class Initialized
DEBUG - 2026-01-05 07:24:32 --> UTF-8 Support Enabled
INFO - 2026-01-05 07:24:32 --> Utf8 Class Initialized
INFO - 2026-01-05 07:24:32 --> URI Class Initialized
DEBUG - 2026-01-05 07:24:32 --> No URI present. Default controller set.
INFO - 2026-01-05 07:24:32 --> Router Class Initialized
INFO - 2026-01-05 07:24:32 --> Output Class Initialized
INFO - 2026-01-05 07:24:32 --> Security Class Initialized
DEBUG - 2026-01-05 07:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 07:24:32 --> CSRF cookie sent
INFO - 2026-01-05 07:24:32 --> Input Class Initialized
INFO - 2026-01-05 07:24:32 --> Language Class Initialized
INFO - 2026-01-05 07:24:32 --> Loader Class Initialized
INFO - 2026-01-05 07:24:32 --> Helper loaded: url_helper
INFO - 2026-01-05 07:24:32 --> Helper loaded: text_helper
INFO - 2026-01-05 07:24:32 --> Helper loaded: string_helper
INFO - 2026-01-05 07:24:32 --> Helper loaded: form_helper
INFO - 2026-01-05 07:24:32 --> Helper loaded: download_helper
INFO - 2026-01-05 07:24:32 --> Helper loaded: security_helper
INFO - 2026-01-05 07:24:32 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 07:24:32 --> Database Driver Class Initialized
DEBUG - 2026-01-05 07:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 07:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 07:24:32 --> Form Validation Class Initialized
INFO - 2026-01-05 07:24:32 --> Model "User_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Nav_model" initialized
INFO - 2026-01-05 13:24:32 --> Controller Class Initialized
INFO - 2026-01-05 13:24:32 --> Model "Berita_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Galeri_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Video_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Agenda_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Tautan_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Mitra_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Jurusan_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Prodi_model" initialized
INFO - 2026-01-05 13:24:32 --> Model "Testimoni_model" initialized
INFO - 2026-01-05 13:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-05 13:24:32 --> Pagination Class Initialized
INFO - 2026-01-05 13:24:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-05 13:24:32 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 13:24:32 --> Model "Log_model" initialized
INFO - 2026-01-05 13:24:32 --> Final output sent to browser
DEBUG - 2026-01-05 13:24:32 --> Total execution time: 0.2000
INFO - 2026-01-05 07:25:04 --> Config Class Initialized
INFO - 2026-01-05 07:25:04 --> Hooks Class Initialized
DEBUG - 2026-01-05 07:25:04 --> UTF-8 Support Enabled
INFO - 2026-01-05 07:25:04 --> Utf8 Class Initialized
INFO - 2026-01-05 07:25:04 --> URI Class Initialized
DEBUG - 2026-01-05 07:25:04 --> No URI present. Default controller set.
INFO - 2026-01-05 07:25:04 --> Router Class Initialized
INFO - 2026-01-05 07:25:04 --> Output Class Initialized
INFO - 2026-01-05 07:25:04 --> Security Class Initialized
DEBUG - 2026-01-05 07:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 07:25:04 --> CSRF cookie sent
INFO - 2026-01-05 07:25:04 --> Input Class Initialized
INFO - 2026-01-05 07:25:04 --> Language Class Initialized
INFO - 2026-01-05 07:25:04 --> Loader Class Initialized
INFO - 2026-01-05 07:25:04 --> Helper loaded: url_helper
INFO - 2026-01-05 07:25:04 --> Helper loaded: text_helper
INFO - 2026-01-05 07:25:04 --> Helper loaded: string_helper
INFO - 2026-01-05 07:25:04 --> Helper loaded: form_helper
INFO - 2026-01-05 07:25:04 --> Helper loaded: download_helper
INFO - 2026-01-05 07:25:04 --> Helper loaded: security_helper
INFO - 2026-01-05 07:25:04 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 07:25:04 --> Database Driver Class Initialized
DEBUG - 2026-01-05 07:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 07:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 07:25:04 --> Form Validation Class Initialized
INFO - 2026-01-05 07:25:04 --> Model "User_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Nav_model" initialized
INFO - 2026-01-05 13:25:04 --> Controller Class Initialized
INFO - 2026-01-05 13:25:04 --> Model "Berita_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Galeri_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Video_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Agenda_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Tautan_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Mitra_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Jurusan_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Prodi_model" initialized
INFO - 2026-01-05 13:25:04 --> Model "Testimoni_model" initialized
INFO - 2026-01-05 13:25:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-05 13:25:04 --> Pagination Class Initialized
INFO - 2026-01-05 13:25:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-05 13:25:04 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 13:25:04 --> Model "Log_model" initialized
INFO - 2026-01-05 13:25:04 --> Final output sent to browser
DEBUG - 2026-01-05 13:25:04 --> Total execution time: 0.2622
INFO - 2026-01-05 07:34:11 --> Config Class Initialized
INFO - 2026-01-05 07:34:11 --> Hooks Class Initialized
DEBUG - 2026-01-05 07:34:11 --> UTF-8 Support Enabled
INFO - 2026-01-05 07:34:11 --> Utf8 Class Initialized
INFO - 2026-01-05 07:34:11 --> URI Class Initialized
DEBUG - 2026-01-05 07:34:11 --> No URI present. Default controller set.
INFO - 2026-01-05 07:34:11 --> Router Class Initialized
INFO - 2026-01-05 07:34:11 --> Output Class Initialized
INFO - 2026-01-05 07:34:11 --> Security Class Initialized
DEBUG - 2026-01-05 07:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 07:34:11 --> CSRF cookie sent
INFO - 2026-01-05 07:34:11 --> Input Class Initialized
INFO - 2026-01-05 07:34:11 --> Language Class Initialized
INFO - 2026-01-05 07:34:11 --> Loader Class Initialized
INFO - 2026-01-05 07:34:11 --> Helper loaded: url_helper
INFO - 2026-01-05 07:34:11 --> Helper loaded: text_helper
INFO - 2026-01-05 07:34:11 --> Helper loaded: string_helper
INFO - 2026-01-05 07:34:11 --> Helper loaded: form_helper
INFO - 2026-01-05 07:34:11 --> Helper loaded: download_helper
INFO - 2026-01-05 07:34:11 --> Helper loaded: security_helper
INFO - 2026-01-05 07:34:11 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 07:34:11 --> Database Driver Class Initialized
DEBUG - 2026-01-05 07:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 07:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 07:34:11 --> Form Validation Class Initialized
INFO - 2026-01-05 07:34:11 --> Model "User_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Nav_model" initialized
INFO - 2026-01-05 13:34:11 --> Controller Class Initialized
INFO - 2026-01-05 13:34:11 --> Model "Berita_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Galeri_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Video_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Agenda_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Tautan_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Mitra_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Jurusan_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Prodi_model" initialized
INFO - 2026-01-05 13:34:11 --> Model "Testimoni_model" initialized
INFO - 2026-01-05 13:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-05 13:34:12 --> Pagination Class Initialized
INFO - 2026-01-05 13:34:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-05 13:34:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 13:34:12 --> Model "Log_model" initialized
INFO - 2026-01-05 13:34:12 --> Final output sent to browser
DEBUG - 2026-01-05 13:34:12 --> Total execution time: 0.3722
INFO - 2026-01-05 07:34:37 --> Config Class Initialized
INFO - 2026-01-05 07:34:37 --> Hooks Class Initialized
DEBUG - 2026-01-05 07:34:37 --> UTF-8 Support Enabled
INFO - 2026-01-05 07:34:37 --> Utf8 Class Initialized
INFO - 2026-01-05 07:34:37 --> URI Class Initialized
DEBUG - 2026-01-05 07:34:37 --> No URI present. Default controller set.
INFO - 2026-01-05 07:34:37 --> Router Class Initialized
INFO - 2026-01-05 07:34:37 --> Output Class Initialized
INFO - 2026-01-05 07:34:37 --> Security Class Initialized
DEBUG - 2026-01-05 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 07:34:37 --> CSRF cookie sent
INFO - 2026-01-05 07:34:37 --> Input Class Initialized
INFO - 2026-01-05 07:34:37 --> Language Class Initialized
INFO - 2026-01-05 07:34:37 --> Loader Class Initialized
INFO - 2026-01-05 07:34:37 --> Helper loaded: url_helper
INFO - 2026-01-05 07:34:37 --> Helper loaded: text_helper
INFO - 2026-01-05 07:34:37 --> Helper loaded: string_helper
INFO - 2026-01-05 07:34:37 --> Helper loaded: form_helper
INFO - 2026-01-05 07:34:37 --> Helper loaded: download_helper
INFO - 2026-01-05 07:34:37 --> Helper loaded: security_helper
INFO - 2026-01-05 07:34:37 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 07:34:37 --> Database Driver Class Initialized
DEBUG - 2026-01-05 07:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 07:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 07:34:37 --> Form Validation Class Initialized
INFO - 2026-01-05 07:34:37 --> Model "User_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Nav_model" initialized
INFO - 2026-01-05 13:34:37 --> Controller Class Initialized
INFO - 2026-01-05 13:34:37 --> Model "Berita_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Galeri_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Video_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Agenda_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Tautan_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Mitra_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Jurusan_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Prodi_model" initialized
INFO - 2026-01-05 13:34:37 --> Model "Testimoni_model" initialized
INFO - 2026-01-05 13:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-05 13:34:37 --> Pagination Class Initialized
INFO - 2026-01-05 13:34:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-05 13:34:37 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 13:34:37 --> Model "Log_model" initialized
INFO - 2026-01-05 13:34:37 --> Final output sent to browser
DEBUG - 2026-01-05 13:34:37 --> Total execution time: 0.2737
INFO - 2026-01-05 07:34:51 --> Config Class Initialized
INFO - 2026-01-05 07:34:51 --> Hooks Class Initialized
DEBUG - 2026-01-05 07:34:51 --> UTF-8 Support Enabled
INFO - 2026-01-05 07:34:51 --> Utf8 Class Initialized
INFO - 2026-01-05 07:34:52 --> URI Class Initialized
INFO - 2026-01-05 07:34:52 --> Router Class Initialized
INFO - 2026-01-05 07:34:52 --> Output Class Initialized
INFO - 2026-01-05 07:34:52 --> Security Class Initialized
DEBUG - 2026-01-05 07:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 07:34:52 --> CSRF cookie sent
INFO - 2026-01-05 07:34:52 --> Input Class Initialized
INFO - 2026-01-05 07:34:52 --> Language Class Initialized
INFO - 2026-01-05 07:34:52 --> Loader Class Initialized
INFO - 2026-01-05 07:34:52 --> Helper loaded: url_helper
INFO - 2026-01-05 07:34:52 --> Helper loaded: text_helper
INFO - 2026-01-05 07:34:52 --> Helper loaded: string_helper
INFO - 2026-01-05 07:34:52 --> Helper loaded: form_helper
INFO - 2026-01-05 07:34:52 --> Helper loaded: download_helper
INFO - 2026-01-05 07:34:52 --> Helper loaded: security_helper
INFO - 2026-01-05 07:34:52 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 07:34:52 --> Database Driver Class Initialized
DEBUG - 2026-01-05 07:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 07:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 07:34:52 --> Form Validation Class Initialized
INFO - 2026-01-05 07:34:52 --> Model "User_model" initialized
INFO - 2026-01-05 13:34:52 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 13:34:52 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 13:34:52 --> Model "Nav_model" initialized
INFO - 2026-01-05 13:34:52 --> Controller Class Initialized
INFO - 2026-01-05 13:34:52 --> Model "Jurusan_model" initialized
INFO - 2026-01-05 13:34:52 --> Model "Prodi_model" initialized
INFO - 2026-01-05 13:34:52 --> Model "Sdm_model" initialized
INFO - 2026-01-05 13:34:52 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-05 13:34:52 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-05 13:34:53 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-05 13:34:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-05 13:34:54 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-05 13:34:54 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-05 13:34:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-05 13:34:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 13:34:54 --> Model "Log_model" initialized
INFO - 2026-01-05 13:34:54 --> Final output sent to browser
DEBUG - 2026-01-05 13:34:54 --> Total execution time: 2.0511
INFO - 2026-01-05 07:46:06 --> Config Class Initialized
INFO - 2026-01-05 07:46:06 --> Hooks Class Initialized
DEBUG - 2026-01-05 07:46:06 --> UTF-8 Support Enabled
INFO - 2026-01-05 07:46:06 --> Utf8 Class Initialized
INFO - 2026-01-05 07:46:06 --> URI Class Initialized
INFO - 2026-01-05 07:46:06 --> Router Class Initialized
INFO - 2026-01-05 07:46:06 --> Output Class Initialized
INFO - 2026-01-05 07:46:06 --> Security Class Initialized
DEBUG - 2026-01-05 07:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 07:46:06 --> CSRF cookie sent
INFO - 2026-01-05 07:46:06 --> Input Class Initialized
INFO - 2026-01-05 07:46:06 --> Language Class Initialized
INFO - 2026-01-05 07:46:06 --> Loader Class Initialized
INFO - 2026-01-05 07:46:06 --> Helper loaded: url_helper
INFO - 2026-01-05 07:46:06 --> Helper loaded: text_helper
INFO - 2026-01-05 07:46:06 --> Helper loaded: string_helper
INFO - 2026-01-05 07:46:06 --> Helper loaded: form_helper
INFO - 2026-01-05 07:46:06 --> Helper loaded: download_helper
INFO - 2026-01-05 07:46:06 --> Helper loaded: security_helper
INFO - 2026-01-05 07:46:06 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 07:46:07 --> Database Driver Class Initialized
DEBUG - 2026-01-05 07:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 07:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 07:46:07 --> Form Validation Class Initialized
INFO - 2026-01-05 07:46:07 --> Model "User_model" initialized
INFO - 2026-01-05 13:46:07 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 13:46:07 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 13:46:07 --> Model "Nav_model" initialized
INFO - 2026-01-05 13:46:07 --> Controller Class Initialized
INFO - 2026-01-05 13:46:07 --> Model "Jurusan_model" initialized
INFO - 2026-01-05 13:46:07 --> Model "Prodi_model" initialized
INFO - 2026-01-05 13:46:07 --> Model "Sdm_model" initialized
INFO - 2026-01-05 13:46:07 --> Model "Sdm_jurusan_model" initialized
INFO - 2026-01-05 13:46:07 --> Query SDM berhasil untuk jurusan: Keperawatan, Total: 1
ERROR - 2026-01-05 13:46:07 --> Severity: Notice --> Undefined variable: features D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-05 13:46:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dev_jkt3\application\views\jurusan\jurusan.php 40
ERROR - 2026-01-05 13:46:07 --> Severity: Notice --> Undefined variable: pusat_data D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
ERROR - 2026-01-05 13:46:07 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\dev_jkt3\application\views\jurusan\sdm.php 488
INFO - 2026-01-05 13:46:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\jurusan/list.php
INFO - 2026-01-05 13:46:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 13:46:07 --> Model "Log_model" initialized
INFO - 2026-01-05 13:46:07 --> Final output sent to browser
DEBUG - 2026-01-05 13:46:07 --> Total execution time: 0.4624
INFO - 2026-01-05 07:50:49 --> Config Class Initialized
INFO - 2026-01-05 07:50:49 --> Hooks Class Initialized
DEBUG - 2026-01-05 07:50:49 --> UTF-8 Support Enabled
INFO - 2026-01-05 07:50:49 --> Utf8 Class Initialized
INFO - 2026-01-05 07:50:49 --> URI Class Initialized
INFO - 2026-01-05 07:50:49 --> Router Class Initialized
INFO - 2026-01-05 07:50:49 --> Output Class Initialized
INFO - 2026-01-05 07:50:49 --> Security Class Initialized
DEBUG - 2026-01-05 07:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-05 07:50:49 --> CSRF cookie sent
INFO - 2026-01-05 07:50:49 --> Input Class Initialized
INFO - 2026-01-05 07:50:49 --> Language Class Initialized
INFO - 2026-01-05 07:50:49 --> Loader Class Initialized
INFO - 2026-01-05 07:50:49 --> Helper loaded: url_helper
INFO - 2026-01-05 07:50:49 --> Helper loaded: text_helper
INFO - 2026-01-05 07:50:49 --> Helper loaded: string_helper
INFO - 2026-01-05 07:50:49 --> Helper loaded: form_helper
INFO - 2026-01-05 07:50:49 --> Helper loaded: download_helper
INFO - 2026-01-05 07:50:49 --> Helper loaded: security_helper
INFO - 2026-01-05 07:50:49 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-05 07:50:49 --> Database Driver Class Initialized
DEBUG - 2026-01-05 07:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-05 07:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-05 07:50:49 --> Form Validation Class Initialized
INFO - 2026-01-05 07:50:49 --> Model "User_model" initialized
INFO - 2026-01-05 13:50:49 --> Model "Kunjungan_model" initialized
INFO - 2026-01-05 13:50:49 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-05 13:50:49 --> Model "Nav_model" initialized
INFO - 2026-01-05 13:50:49 --> Controller Class Initialized
INFO - 2026-01-05 13:50:49 --> Model "Pages_model" initialized
INFO - 2026-01-05 13:50:49 --> Model "Berita_model" initialized
INFO - 2026-01-05 13:50:49 --> Model "Download_model" initialized
INFO - 2026-01-05 13:50:49 --> Model "Kategori_download_model" initialized
INFO - 2026-01-05 13:50:49 --> Model "Jenis_download_model" initialized
INFO - 2026-01-05 13:50:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pages/pendidikan.php
INFO - 2026-01-05 13:50:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-05 13:50:49 --> Model "Log_model" initialized
INFO - 2026-01-05 13:50:49 --> Final output sent to browser
DEBUG - 2026-01-05 13:50:49 --> Total execution time: 0.2691
