<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-01 04:27:44 --> Config Class Initialized
INFO - 2025-10-01 04:27:44 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:27:44 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:27:44 --> Utf8 Class Initialized
INFO - 2025-10-01 04:27:44 --> URI Class Initialized
DEBUG - 2025-10-01 04:27:44 --> No URI present. Default controller set.
INFO - 2025-10-01 04:27:44 --> Router Class Initialized
INFO - 2025-10-01 04:27:44 --> Output Class Initialized
INFO - 2025-10-01 04:27:44 --> Security Class Initialized
DEBUG - 2025-10-01 04:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:27:44 --> CSRF cookie sent
INFO - 2025-10-01 04:27:44 --> Input Class Initialized
INFO - 2025-10-01 04:27:44 --> Language Class Initialized
INFO - 2025-10-01 04:27:44 --> Loader Class Initialized
INFO - 2025-10-01 04:27:44 --> Helper loaded: url_helper
INFO - 2025-10-01 04:27:45 --> Helper loaded: text_helper
INFO - 2025-10-01 04:27:45 --> Helper loaded: string_helper
INFO - 2025-10-01 04:27:45 --> Helper loaded: form_helper
INFO - 2025-10-01 04:27:45 --> Helper loaded: download_helper
INFO - 2025-10-01 04:27:45 --> Helper loaded: security_helper
INFO - 2025-10-01 04:27:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:27:45 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:27:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:27:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:27:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:27:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:27:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:27:46 --> Controller Class Initialized
INFO - 2025-10-01 09:27:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:27:47 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:27:47 --> Model "Video_model" initialized
INFO - 2025-10-01 09:27:47 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:27:47 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:27:47 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:27:47 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:27:47 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:27:47 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:27:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-01 09:27:47 --> Pagination Class Initialized
INFO - 2025-10-01 09:27:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-01 09:27:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:27:50 --> Model "Log_model" initialized
INFO - 2025-10-01 09:27:50 --> Final output sent to browser
DEBUG - 2025-10-01 09:27:50 --> Total execution time: 6.4547
INFO - 2025-10-01 04:30:45 --> Config Class Initialized
INFO - 2025-10-01 04:30:45 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:45 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:45 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:45 --> URI Class Initialized
INFO - 2025-10-01 04:30:45 --> Router Class Initialized
INFO - 2025-10-01 04:30:45 --> Output Class Initialized
INFO - 2025-10-01 04:30:45 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:45 --> CSRF cookie sent
INFO - 2025-10-01 04:30:45 --> Input Class Initialized
INFO - 2025-10-01 04:30:45 --> Language Class Initialized
INFO - 2025-10-01 04:30:45 --> Loader Class Initialized
INFO - 2025-10-01 04:30:45 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:45 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:45 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:45 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:45 --> Controller Class Initialized
INFO - 2025-10-01 09:30:45 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Sdm_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Sdm_unit_model" initialized
INFO - 2025-10-01 09:30:45 --> Query SDM berhasil untuk unit: Unit Pengelola Usaha, Total: 1
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\unit/list.php
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:45 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:45 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:45 --> Total execution time: 0.3788
INFO - 2025-10-01 04:30:45 --> Config Class Initialized
INFO - 2025-10-01 04:30:45 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:45 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:45 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:45 --> URI Class Initialized
INFO - 2025-10-01 04:30:45 --> Router Class Initialized
INFO - 2025-10-01 04:30:45 --> Output Class Initialized
INFO - 2025-10-01 04:30:45 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:45 --> CSRF cookie sent
INFO - 2025-10-01 04:30:45 --> Input Class Initialized
INFO - 2025-10-01 04:30:45 --> Language Class Initialized
INFO - 2025-10-01 04:30:45 --> Loader Class Initialized
INFO - 2025-10-01 04:30:45 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:45 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:45 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:45 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:45 --> Controller Class Initialized
INFO - 2025-10-01 09:30:45 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:45 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:45 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:45 --> Total execution time: 0.0673
INFO - 2025-10-01 04:30:45 --> Config Class Initialized
INFO - 2025-10-01 04:30:45 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:45 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:45 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:45 --> URI Class Initialized
INFO - 2025-10-01 04:30:45 --> Router Class Initialized
INFO - 2025-10-01 04:30:45 --> Output Class Initialized
INFO - 2025-10-01 04:30:45 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:45 --> CSRF cookie sent
INFO - 2025-10-01 04:30:45 --> Input Class Initialized
INFO - 2025-10-01 04:30:45 --> Language Class Initialized
INFO - 2025-10-01 04:30:45 --> Loader Class Initialized
INFO - 2025-10-01 04:30:45 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:45 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:45 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:45 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:45 --> Controller Class Initialized
INFO - 2025-10-01 09:30:45 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:45 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:45 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:45 --> Total execution time: 0.0579
INFO - 2025-10-01 04:30:45 --> Config Class Initialized
INFO - 2025-10-01 04:30:45 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:45 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:45 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:45 --> URI Class Initialized
INFO - 2025-10-01 04:30:45 --> Router Class Initialized
INFO - 2025-10-01 04:30:45 --> Output Class Initialized
INFO - 2025-10-01 04:30:45 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:45 --> CSRF cookie sent
INFO - 2025-10-01 04:30:45 --> Input Class Initialized
INFO - 2025-10-01 04:30:45 --> Language Class Initialized
INFO - 2025-10-01 04:30:45 --> Loader Class Initialized
INFO - 2025-10-01 04:30:45 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:45 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:45 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:45 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:45 --> Controller Class Initialized
INFO - 2025-10-01 09:30:45 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:45 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:45 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:45 --> Total execution time: 0.0631
INFO - 2025-10-01 04:30:45 --> Config Class Initialized
INFO - 2025-10-01 04:30:45 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:45 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:45 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:45 --> URI Class Initialized
INFO - 2025-10-01 04:30:45 --> Router Class Initialized
INFO - 2025-10-01 04:30:45 --> Output Class Initialized
INFO - 2025-10-01 04:30:45 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:45 --> CSRF cookie sent
INFO - 2025-10-01 04:30:45 --> Input Class Initialized
INFO - 2025-10-01 04:30:45 --> Language Class Initialized
INFO - 2025-10-01 04:30:45 --> Loader Class Initialized
INFO - 2025-10-01 04:30:45 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:45 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:45 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:45 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:45 --> Controller Class Initialized
INFO - 2025-10-01 09:30:45 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:45 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:45 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:45 --> Total execution time: 0.0652
INFO - 2025-10-01 04:30:45 --> Config Class Initialized
INFO - 2025-10-01 04:30:45 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:45 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:45 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:45 --> URI Class Initialized
INFO - 2025-10-01 04:30:45 --> Router Class Initialized
INFO - 2025-10-01 04:30:45 --> Output Class Initialized
INFO - 2025-10-01 04:30:45 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:45 --> CSRF cookie sent
INFO - 2025-10-01 04:30:45 --> Input Class Initialized
INFO - 2025-10-01 04:30:45 --> Language Class Initialized
INFO - 2025-10-01 04:30:45 --> Loader Class Initialized
INFO - 2025-10-01 04:30:45 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:45 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:45 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:45 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:45 --> Controller Class Initialized
INFO - 2025-10-01 09:30:45 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:45 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:45 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:45 --> Total execution time: 0.0777
INFO - 2025-10-01 04:30:45 --> Config Class Initialized
INFO - 2025-10-01 04:30:45 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:45 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:45 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:45 --> URI Class Initialized
INFO - 2025-10-01 04:30:45 --> Router Class Initialized
INFO - 2025-10-01 04:30:45 --> Output Class Initialized
INFO - 2025-10-01 04:30:45 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:45 --> CSRF cookie sent
INFO - 2025-10-01 04:30:45 --> Input Class Initialized
INFO - 2025-10-01 04:30:45 --> Language Class Initialized
INFO - 2025-10-01 04:30:45 --> Loader Class Initialized
INFO - 2025-10-01 04:30:45 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:45 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:45 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:45 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:45 --> Controller Class Initialized
INFO - 2025-10-01 09:30:45 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:45 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0695
INFO - 2025-10-01 04:30:46 --> Config Class Initialized
INFO - 2025-10-01 04:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:46 --> URI Class Initialized
INFO - 2025-10-01 04:30:46 --> Router Class Initialized
INFO - 2025-10-01 04:30:46 --> Output Class Initialized
INFO - 2025-10-01 04:30:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:46 --> CSRF cookie sent
INFO - 2025-10-01 04:30:46 --> Input Class Initialized
INFO - 2025-10-01 04:30:46 --> Language Class Initialized
INFO - 2025-10-01 04:30:46 --> Loader Class Initialized
INFO - 2025-10-01 04:30:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:46 --> Controller Class Initialized
INFO - 2025-10-01 09:30:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0544
INFO - 2025-10-01 04:30:46 --> Config Class Initialized
INFO - 2025-10-01 04:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:46 --> URI Class Initialized
INFO - 2025-10-01 04:30:46 --> Router Class Initialized
INFO - 2025-10-01 04:30:46 --> Output Class Initialized
INFO - 2025-10-01 04:30:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:46 --> CSRF cookie sent
INFO - 2025-10-01 04:30:46 --> Input Class Initialized
INFO - 2025-10-01 04:30:46 --> Language Class Initialized
INFO - 2025-10-01 04:30:46 --> Loader Class Initialized
INFO - 2025-10-01 04:30:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:46 --> Controller Class Initialized
INFO - 2025-10-01 09:30:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0439
INFO - 2025-10-01 04:30:46 --> Config Class Initialized
INFO - 2025-10-01 04:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:46 --> URI Class Initialized
INFO - 2025-10-01 04:30:46 --> Router Class Initialized
INFO - 2025-10-01 04:30:46 --> Output Class Initialized
INFO - 2025-10-01 04:30:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:46 --> CSRF cookie sent
INFO - 2025-10-01 04:30:46 --> Input Class Initialized
INFO - 2025-10-01 04:30:46 --> Language Class Initialized
INFO - 2025-10-01 04:30:46 --> Loader Class Initialized
INFO - 2025-10-01 04:30:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:46 --> Controller Class Initialized
INFO - 2025-10-01 09:30:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0661
INFO - 2025-10-01 04:30:46 --> Config Class Initialized
INFO - 2025-10-01 04:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:46 --> URI Class Initialized
INFO - 2025-10-01 04:30:46 --> Router Class Initialized
INFO - 2025-10-01 04:30:46 --> Output Class Initialized
INFO - 2025-10-01 04:30:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:46 --> CSRF cookie sent
INFO - 2025-10-01 04:30:46 --> Input Class Initialized
INFO - 2025-10-01 04:30:46 --> Language Class Initialized
INFO - 2025-10-01 04:30:46 --> Loader Class Initialized
INFO - 2025-10-01 04:30:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:46 --> Controller Class Initialized
INFO - 2025-10-01 09:30:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0569
INFO - 2025-10-01 04:30:46 --> Config Class Initialized
INFO - 2025-10-01 04:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:46 --> URI Class Initialized
INFO - 2025-10-01 04:30:46 --> Router Class Initialized
INFO - 2025-10-01 04:30:46 --> Output Class Initialized
INFO - 2025-10-01 04:30:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:46 --> CSRF cookie sent
INFO - 2025-10-01 04:30:46 --> Input Class Initialized
INFO - 2025-10-01 04:30:46 --> Language Class Initialized
INFO - 2025-10-01 04:30:46 --> Loader Class Initialized
INFO - 2025-10-01 04:30:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:46 --> Controller Class Initialized
INFO - 2025-10-01 09:30:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0638
INFO - 2025-10-01 04:30:46 --> Config Class Initialized
INFO - 2025-10-01 04:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:46 --> URI Class Initialized
INFO - 2025-10-01 04:30:46 --> Router Class Initialized
INFO - 2025-10-01 04:30:46 --> Output Class Initialized
INFO - 2025-10-01 04:30:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:46 --> CSRF cookie sent
INFO - 2025-10-01 04:30:46 --> Input Class Initialized
INFO - 2025-10-01 04:30:46 --> Language Class Initialized
INFO - 2025-10-01 04:30:46 --> Loader Class Initialized
INFO - 2025-10-01 04:30:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:46 --> Controller Class Initialized
INFO - 2025-10-01 09:30:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0615
INFO - 2025-10-01 04:30:46 --> Config Class Initialized
INFO - 2025-10-01 04:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:46 --> URI Class Initialized
INFO - 2025-10-01 04:30:46 --> Router Class Initialized
INFO - 2025-10-01 04:30:46 --> Output Class Initialized
INFO - 2025-10-01 04:30:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:46 --> CSRF cookie sent
INFO - 2025-10-01 04:30:46 --> Input Class Initialized
INFO - 2025-10-01 04:30:46 --> Language Class Initialized
INFO - 2025-10-01 04:30:46 --> Loader Class Initialized
INFO - 2025-10-01 04:30:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:46 --> Controller Class Initialized
INFO - 2025-10-01 09:30:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0636
INFO - 2025-10-01 04:30:46 --> Config Class Initialized
INFO - 2025-10-01 04:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:46 --> URI Class Initialized
INFO - 2025-10-01 04:30:46 --> Router Class Initialized
INFO - 2025-10-01 04:30:46 --> Output Class Initialized
INFO - 2025-10-01 04:30:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:46 --> CSRF cookie sent
INFO - 2025-10-01 04:30:46 --> Input Class Initialized
INFO - 2025-10-01 04:30:46 --> Language Class Initialized
INFO - 2025-10-01 04:30:46 --> Loader Class Initialized
INFO - 2025-10-01 04:30:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:46 --> Controller Class Initialized
INFO - 2025-10-01 09:30:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0712
INFO - 2025-10-01 04:30:46 --> Config Class Initialized
INFO - 2025-10-01 04:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:46 --> URI Class Initialized
INFO - 2025-10-01 04:30:46 --> Router Class Initialized
INFO - 2025-10-01 04:30:46 --> Output Class Initialized
INFO - 2025-10-01 04:30:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:46 --> CSRF cookie sent
INFO - 2025-10-01 04:30:46 --> Input Class Initialized
INFO - 2025-10-01 04:30:46 --> Language Class Initialized
INFO - 2025-10-01 04:30:46 --> Loader Class Initialized
INFO - 2025-10-01 04:30:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:46 --> Controller Class Initialized
INFO - 2025-10-01 09:30:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0607
INFO - 2025-10-01 04:30:46 --> Config Class Initialized
INFO - 2025-10-01 04:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:46 --> URI Class Initialized
INFO - 2025-10-01 04:30:46 --> Router Class Initialized
INFO - 2025-10-01 04:30:46 --> Output Class Initialized
INFO - 2025-10-01 04:30:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:46 --> CSRF cookie sent
INFO - 2025-10-01 04:30:46 --> Input Class Initialized
INFO - 2025-10-01 04:30:46 --> Language Class Initialized
INFO - 2025-10-01 04:30:46 --> Loader Class Initialized
INFO - 2025-10-01 04:30:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:46 --> Controller Class Initialized
INFO - 2025-10-01 09:30:46 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:46 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:46 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:46 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:46 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:46 --> Total execution time: 0.0659
INFO - 2025-10-01 04:30:47 --> Config Class Initialized
INFO - 2025-10-01 04:30:47 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:47 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:47 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:47 --> URI Class Initialized
INFO - 2025-10-01 04:30:47 --> Router Class Initialized
INFO - 2025-10-01 04:30:47 --> Output Class Initialized
INFO - 2025-10-01 04:30:47 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:47 --> CSRF cookie sent
INFO - 2025-10-01 04:30:47 --> Input Class Initialized
INFO - 2025-10-01 04:30:47 --> Language Class Initialized
INFO - 2025-10-01 04:30:47 --> Loader Class Initialized
INFO - 2025-10-01 04:30:47 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:47 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:47 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:47 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:47 --> Controller Class Initialized
INFO - 2025-10-01 09:30:47 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:47 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:47 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:47 --> Total execution time: 0.0548
INFO - 2025-10-01 04:30:47 --> Config Class Initialized
INFO - 2025-10-01 04:30:47 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:47 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:47 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:47 --> URI Class Initialized
INFO - 2025-10-01 04:30:47 --> Router Class Initialized
INFO - 2025-10-01 04:30:47 --> Output Class Initialized
INFO - 2025-10-01 04:30:47 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:47 --> CSRF cookie sent
INFO - 2025-10-01 04:30:47 --> Input Class Initialized
INFO - 2025-10-01 04:30:47 --> Language Class Initialized
INFO - 2025-10-01 04:30:47 --> Loader Class Initialized
INFO - 2025-10-01 04:30:47 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:47 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:47 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:47 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:47 --> Controller Class Initialized
INFO - 2025-10-01 09:30:47 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:47 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:47 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:47 --> Total execution time: 0.0667
INFO - 2025-10-01 04:30:47 --> Config Class Initialized
INFO - 2025-10-01 04:30:47 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:47 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:47 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:47 --> URI Class Initialized
INFO - 2025-10-01 04:30:47 --> Router Class Initialized
INFO - 2025-10-01 04:30:47 --> Output Class Initialized
INFO - 2025-10-01 04:30:47 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:47 --> CSRF cookie sent
INFO - 2025-10-01 04:30:47 --> Input Class Initialized
INFO - 2025-10-01 04:30:47 --> Language Class Initialized
INFO - 2025-10-01 04:30:47 --> Loader Class Initialized
INFO - 2025-10-01 04:30:47 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:47 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:47 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:47 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:47 --> Controller Class Initialized
INFO - 2025-10-01 09:30:47 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:47 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:47 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:47 --> Total execution time: 0.0668
INFO - 2025-10-01 04:30:47 --> Config Class Initialized
INFO - 2025-10-01 04:30:47 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:47 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:47 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:47 --> URI Class Initialized
INFO - 2025-10-01 04:30:47 --> Router Class Initialized
INFO - 2025-10-01 04:30:47 --> Output Class Initialized
INFO - 2025-10-01 04:30:47 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:47 --> CSRF cookie sent
INFO - 2025-10-01 04:30:47 --> Input Class Initialized
INFO - 2025-10-01 04:30:47 --> Language Class Initialized
INFO - 2025-10-01 04:30:47 --> Loader Class Initialized
INFO - 2025-10-01 04:30:47 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:47 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:47 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:47 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:47 --> Controller Class Initialized
INFO - 2025-10-01 09:30:47 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:47 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:47 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:47 --> Total execution time: 0.0407
INFO - 2025-10-01 04:30:47 --> Config Class Initialized
INFO - 2025-10-01 04:30:47 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:47 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:47 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:47 --> URI Class Initialized
INFO - 2025-10-01 04:30:47 --> Router Class Initialized
INFO - 2025-10-01 04:30:47 --> Output Class Initialized
INFO - 2025-10-01 04:30:47 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:47 --> CSRF cookie sent
INFO - 2025-10-01 04:30:47 --> Input Class Initialized
INFO - 2025-10-01 04:30:47 --> Language Class Initialized
INFO - 2025-10-01 04:30:47 --> Loader Class Initialized
INFO - 2025-10-01 04:30:47 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:47 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:47 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:47 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:47 --> Controller Class Initialized
INFO - 2025-10-01 09:30:47 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:47 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:47 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:47 --> Total execution time: 0.0582
INFO - 2025-10-01 04:30:47 --> Config Class Initialized
INFO - 2025-10-01 04:30:47 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:47 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:47 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:47 --> URI Class Initialized
INFO - 2025-10-01 04:30:47 --> Router Class Initialized
INFO - 2025-10-01 04:30:47 --> Output Class Initialized
INFO - 2025-10-01 04:30:47 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:47 --> CSRF cookie sent
INFO - 2025-10-01 04:30:47 --> Input Class Initialized
INFO - 2025-10-01 04:30:47 --> Language Class Initialized
INFO - 2025-10-01 04:30:47 --> Loader Class Initialized
INFO - 2025-10-01 04:30:47 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:47 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:47 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:47 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:47 --> Controller Class Initialized
INFO - 2025-10-01 09:30:47 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:47 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:47 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:47 --> Total execution time: 0.0464
INFO - 2025-10-01 04:30:47 --> Config Class Initialized
INFO - 2025-10-01 04:30:47 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:47 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:47 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:47 --> URI Class Initialized
INFO - 2025-10-01 04:30:47 --> Router Class Initialized
INFO - 2025-10-01 04:30:47 --> Output Class Initialized
INFO - 2025-10-01 04:30:47 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:47 --> CSRF cookie sent
INFO - 2025-10-01 04:30:47 --> Input Class Initialized
INFO - 2025-10-01 04:30:47 --> Language Class Initialized
INFO - 2025-10-01 04:30:47 --> Loader Class Initialized
INFO - 2025-10-01 04:30:47 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:47 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:47 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:47 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:47 --> Controller Class Initialized
INFO - 2025-10-01 09:30:47 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:47 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:47 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:47 --> Total execution time: 0.0599
INFO - 2025-10-01 04:30:47 --> Config Class Initialized
INFO - 2025-10-01 04:30:47 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:47 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:47 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:47 --> URI Class Initialized
INFO - 2025-10-01 04:30:47 --> Router Class Initialized
INFO - 2025-10-01 04:30:47 --> Output Class Initialized
INFO - 2025-10-01 04:30:47 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:47 --> CSRF cookie sent
INFO - 2025-10-01 04:30:47 --> Input Class Initialized
INFO - 2025-10-01 04:30:47 --> Language Class Initialized
INFO - 2025-10-01 04:30:47 --> Loader Class Initialized
INFO - 2025-10-01 04:30:47 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:47 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:47 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:47 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:47 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:47 --> Controller Class Initialized
INFO - 2025-10-01 09:30:47 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:47 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0488
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0631
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0523
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0601
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0560
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0670
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0608
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0526
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0548
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0626
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0574
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0598
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:48 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:48 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:48 --> Controller Class Initialized
INFO - 2025-10-01 09:30:48 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:48 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:48 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:48 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:48 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:48 --> Total execution time: 0.0645
INFO - 2025-10-01 04:30:48 --> Config Class Initialized
INFO - 2025-10-01 04:30:48 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:48 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:48 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:48 --> URI Class Initialized
INFO - 2025-10-01 04:30:48 --> Router Class Initialized
INFO - 2025-10-01 04:30:48 --> Output Class Initialized
INFO - 2025-10-01 04:30:48 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:48 --> CSRF cookie sent
INFO - 2025-10-01 04:30:48 --> Input Class Initialized
INFO - 2025-10-01 04:30:48 --> Language Class Initialized
INFO - 2025-10-01 04:30:48 --> Loader Class Initialized
INFO - 2025-10-01 04:30:48 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:48 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:48 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:49 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:49 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:49 --> Controller Class Initialized
INFO - 2025-10-01 09:30:49 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:49 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:49 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:49 --> Total execution time: 0.0745
INFO - 2025-10-01 04:30:49 --> Config Class Initialized
INFO - 2025-10-01 04:30:49 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:49 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:49 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:49 --> URI Class Initialized
INFO - 2025-10-01 04:30:49 --> Router Class Initialized
INFO - 2025-10-01 04:30:49 --> Output Class Initialized
INFO - 2025-10-01 04:30:49 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:49 --> CSRF cookie sent
INFO - 2025-10-01 04:30:49 --> Input Class Initialized
INFO - 2025-10-01 04:30:49 --> Language Class Initialized
INFO - 2025-10-01 04:30:49 --> Loader Class Initialized
INFO - 2025-10-01 04:30:49 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:49 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:49 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:49 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:49 --> Controller Class Initialized
INFO - 2025-10-01 09:30:49 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:49 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:49 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:49 --> Total execution time: 0.0706
INFO - 2025-10-01 04:30:49 --> Config Class Initialized
INFO - 2025-10-01 04:30:49 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:49 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:49 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:49 --> URI Class Initialized
INFO - 2025-10-01 04:30:49 --> Router Class Initialized
INFO - 2025-10-01 04:30:49 --> Output Class Initialized
INFO - 2025-10-01 04:30:49 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:49 --> CSRF cookie sent
INFO - 2025-10-01 04:30:49 --> Input Class Initialized
INFO - 2025-10-01 04:30:49 --> Language Class Initialized
INFO - 2025-10-01 04:30:49 --> Loader Class Initialized
INFO - 2025-10-01 04:30:49 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:49 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:49 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:49 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:49 --> Controller Class Initialized
INFO - 2025-10-01 09:30:49 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:49 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:49 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:49 --> Total execution time: 0.0617
INFO - 2025-10-01 04:30:49 --> Config Class Initialized
INFO - 2025-10-01 04:30:49 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:49 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:49 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:49 --> URI Class Initialized
INFO - 2025-10-01 04:30:49 --> Router Class Initialized
INFO - 2025-10-01 04:30:49 --> Output Class Initialized
INFO - 2025-10-01 04:30:49 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:49 --> CSRF cookie sent
INFO - 2025-10-01 04:30:49 --> Input Class Initialized
INFO - 2025-10-01 04:30:49 --> Language Class Initialized
INFO - 2025-10-01 04:30:49 --> Loader Class Initialized
INFO - 2025-10-01 04:30:49 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:49 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:49 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:49 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:49 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:49 --> Controller Class Initialized
INFO - 2025-10-01 09:30:49 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:49 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:49 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:49 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:49 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:49 --> Total execution time: 0.0600
INFO - 2025-10-01 04:30:50 --> Config Class Initialized
INFO - 2025-10-01 04:30:50 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:50 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:50 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:50 --> URI Class Initialized
INFO - 2025-10-01 04:30:50 --> Router Class Initialized
INFO - 2025-10-01 04:30:50 --> Output Class Initialized
INFO - 2025-10-01 04:30:50 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:50 --> CSRF cookie sent
INFO - 2025-10-01 04:30:50 --> Input Class Initialized
INFO - 2025-10-01 04:30:50 --> Language Class Initialized
INFO - 2025-10-01 04:30:50 --> Loader Class Initialized
INFO - 2025-10-01 04:30:50 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:50 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:50 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:50 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:50 --> Controller Class Initialized
INFO - 2025-10-01 09:30:50 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:50 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:50 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:50 --> Total execution time: 0.0568
INFO - 2025-10-01 04:30:50 --> Config Class Initialized
INFO - 2025-10-01 04:30:50 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:50 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:50 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:50 --> URI Class Initialized
INFO - 2025-10-01 04:30:50 --> Router Class Initialized
INFO - 2025-10-01 04:30:50 --> Output Class Initialized
INFO - 2025-10-01 04:30:50 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:50 --> CSRF cookie sent
INFO - 2025-10-01 04:30:50 --> Input Class Initialized
INFO - 2025-10-01 04:30:50 --> Language Class Initialized
INFO - 2025-10-01 04:30:50 --> Loader Class Initialized
INFO - 2025-10-01 04:30:50 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:50 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:50 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:50 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:50 --> Controller Class Initialized
INFO - 2025-10-01 09:30:50 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:50 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:50 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:50 --> Total execution time: 0.0492
INFO - 2025-10-01 04:30:50 --> Config Class Initialized
INFO - 2025-10-01 04:30:50 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:50 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:50 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:50 --> URI Class Initialized
INFO - 2025-10-01 04:30:50 --> Router Class Initialized
INFO - 2025-10-01 04:30:50 --> Output Class Initialized
INFO - 2025-10-01 04:30:50 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:50 --> CSRF cookie sent
INFO - 2025-10-01 04:30:50 --> Input Class Initialized
INFO - 2025-10-01 04:30:50 --> Language Class Initialized
INFO - 2025-10-01 04:30:50 --> Loader Class Initialized
INFO - 2025-10-01 04:30:50 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:50 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:50 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:50 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:50 --> Controller Class Initialized
INFO - 2025-10-01 09:30:50 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:50 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:50 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:50 --> Total execution time: 0.0515
INFO - 2025-10-01 04:30:50 --> Config Class Initialized
INFO - 2025-10-01 04:30:50 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:50 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:50 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:50 --> URI Class Initialized
INFO - 2025-10-01 04:30:50 --> Router Class Initialized
INFO - 2025-10-01 04:30:50 --> Output Class Initialized
INFO - 2025-10-01 04:30:50 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:50 --> CSRF cookie sent
INFO - 2025-10-01 04:30:50 --> Input Class Initialized
INFO - 2025-10-01 04:30:50 --> Language Class Initialized
INFO - 2025-10-01 04:30:50 --> Loader Class Initialized
INFO - 2025-10-01 04:30:50 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:50 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:50 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:50 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:50 --> Controller Class Initialized
INFO - 2025-10-01 09:30:50 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:50 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:50 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:50 --> Total execution time: 0.0615
INFO - 2025-10-01 04:30:50 --> Config Class Initialized
INFO - 2025-10-01 04:30:50 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:50 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:50 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:50 --> URI Class Initialized
INFO - 2025-10-01 04:30:50 --> Router Class Initialized
INFO - 2025-10-01 04:30:50 --> Output Class Initialized
INFO - 2025-10-01 04:30:50 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:50 --> CSRF cookie sent
INFO - 2025-10-01 04:30:50 --> Input Class Initialized
INFO - 2025-10-01 04:30:50 --> Language Class Initialized
INFO - 2025-10-01 04:30:50 --> Loader Class Initialized
INFO - 2025-10-01 04:30:50 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:50 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:50 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:50 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:50 --> Controller Class Initialized
INFO - 2025-10-01 09:30:50 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:50 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:50 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:50 --> Total execution time: 0.0539
INFO - 2025-10-01 04:30:50 --> Config Class Initialized
INFO - 2025-10-01 04:30:50 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:50 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:50 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:50 --> URI Class Initialized
INFO - 2025-10-01 04:30:50 --> Router Class Initialized
INFO - 2025-10-01 04:30:50 --> Output Class Initialized
INFO - 2025-10-01 04:30:50 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:50 --> CSRF cookie sent
INFO - 2025-10-01 04:30:50 --> Input Class Initialized
INFO - 2025-10-01 04:30:50 --> Language Class Initialized
INFO - 2025-10-01 04:30:50 --> Loader Class Initialized
INFO - 2025-10-01 04:30:50 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:50 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:50 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:50 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:50 --> Controller Class Initialized
INFO - 2025-10-01 09:30:50 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:50 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:50 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:50 --> Total execution time: 0.0645
INFO - 2025-10-01 04:30:50 --> Config Class Initialized
INFO - 2025-10-01 04:30:50 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:50 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:50 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:50 --> URI Class Initialized
INFO - 2025-10-01 04:30:50 --> Router Class Initialized
INFO - 2025-10-01 04:30:50 --> Output Class Initialized
INFO - 2025-10-01 04:30:50 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:50 --> CSRF cookie sent
INFO - 2025-10-01 04:30:50 --> Input Class Initialized
INFO - 2025-10-01 04:30:50 --> Language Class Initialized
INFO - 2025-10-01 04:30:50 --> Loader Class Initialized
INFO - 2025-10-01 04:30:50 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:50 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:50 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:50 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:50 --> Controller Class Initialized
INFO - 2025-10-01 09:30:50 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:50 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:50 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:50 --> Total execution time: 0.0493
INFO - 2025-10-01 04:30:50 --> Config Class Initialized
INFO - 2025-10-01 04:30:50 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:50 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:50 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:50 --> URI Class Initialized
INFO - 2025-10-01 04:30:50 --> Router Class Initialized
INFO - 2025-10-01 04:30:50 --> Output Class Initialized
INFO - 2025-10-01 04:30:50 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:50 --> CSRF cookie sent
INFO - 2025-10-01 04:30:50 --> Input Class Initialized
INFO - 2025-10-01 04:30:50 --> Language Class Initialized
INFO - 2025-10-01 04:30:50 --> Loader Class Initialized
INFO - 2025-10-01 04:30:50 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:50 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:50 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:50 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:50 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:50 --> Controller Class Initialized
INFO - 2025-10-01 09:30:50 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:50 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:50 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:50 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:50 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:50 --> Total execution time: 0.0554
INFO - 2025-10-01 04:30:50 --> Config Class Initialized
INFO - 2025-10-01 04:30:50 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0629
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0640
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0558
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0557
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0622
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0558
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0656
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0504
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0607
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0630
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0394
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0612
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0667
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:51 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:51 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:51 --> Total execution time: 0.0448
INFO - 2025-10-01 04:30:51 --> Config Class Initialized
INFO - 2025-10-01 04:30:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:51 --> URI Class Initialized
INFO - 2025-10-01 04:30:51 --> Router Class Initialized
INFO - 2025-10-01 04:30:51 --> Output Class Initialized
INFO - 2025-10-01 04:30:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:51 --> CSRF cookie sent
INFO - 2025-10-01 04:30:51 --> Input Class Initialized
INFO - 2025-10-01 04:30:51 --> Language Class Initialized
INFO - 2025-10-01 04:30:51 --> Loader Class Initialized
INFO - 2025-10-01 04:30:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:51 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:51 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:51 --> Controller Class Initialized
INFO - 2025-10-01 09:30:51 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:51 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:51 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0580
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0657
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0512
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0583
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0555
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0568
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0608
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0541
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0527
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0508
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0587
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0518
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0581
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:52 --> Controller Class Initialized
INFO - 2025-10-01 09:30:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:52 --> Total execution time: 0.0619
INFO - 2025-10-01 04:30:52 --> Config Class Initialized
INFO - 2025-10-01 04:30:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:52 --> URI Class Initialized
INFO - 2025-10-01 04:30:52 --> Router Class Initialized
INFO - 2025-10-01 04:30:52 --> Output Class Initialized
INFO - 2025-10-01 04:30:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:52 --> CSRF cookie sent
INFO - 2025-10-01 04:30:52 --> Input Class Initialized
INFO - 2025-10-01 04:30:52 --> Language Class Initialized
INFO - 2025-10-01 04:30:52 --> Loader Class Initialized
INFO - 2025-10-01 04:30:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0608
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0522
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0640
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0631
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0523
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0659
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0623
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0503
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0510
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0617
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0634
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0708
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0607
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0524
INFO - 2025-10-01 04:30:53 --> Config Class Initialized
INFO - 2025-10-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:53 --> URI Class Initialized
INFO - 2025-10-01 04:30:53 --> Router Class Initialized
INFO - 2025-10-01 04:30:53 --> Output Class Initialized
INFO - 2025-10-01 04:30:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:53 --> CSRF cookie sent
INFO - 2025-10-01 04:30:53 --> Input Class Initialized
INFO - 2025-10-01 04:30:53 --> Language Class Initialized
INFO - 2025-10-01 04:30:53 --> Loader Class Initialized
INFO - 2025-10-01 04:30:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:53 --> Controller Class Initialized
INFO - 2025-10-01 09:30:53 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:53 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:53 --> Total execution time: 0.0501
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0416
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0652
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0532
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0511
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0627
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0398
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0607
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0704
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0644
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0483
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0512
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0506
INFO - 2025-10-01 04:30:54 --> Config Class Initialized
INFO - 2025-10-01 04:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:54 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:54 --> URI Class Initialized
INFO - 2025-10-01 04:30:54 --> Router Class Initialized
INFO - 2025-10-01 04:30:54 --> Output Class Initialized
INFO - 2025-10-01 04:30:54 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:54 --> CSRF cookie sent
INFO - 2025-10-01 04:30:54 --> Input Class Initialized
INFO - 2025-10-01 04:30:54 --> Language Class Initialized
INFO - 2025-10-01 04:30:54 --> Loader Class Initialized
INFO - 2025-10-01 04:30:54 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:54 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:54 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:54 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:54 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:54 --> Controller Class Initialized
INFO - 2025-10-01 09:30:54 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:54 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:54 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:54 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:54 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:54 --> Total execution time: 0.0622
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0472
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0533
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0679
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0617
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0692
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0605
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0489
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0423
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0566
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0622
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0490
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0667
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0618
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:55 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:55 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:55 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:55 --> Total execution time: 0.0619
INFO - 2025-10-01 04:30:55 --> Config Class Initialized
INFO - 2025-10-01 04:30:55 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:55 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:55 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:55 --> URI Class Initialized
INFO - 2025-10-01 04:30:55 --> Router Class Initialized
INFO - 2025-10-01 04:30:55 --> Output Class Initialized
INFO - 2025-10-01 04:30:55 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:55 --> CSRF cookie sent
INFO - 2025-10-01 04:30:55 --> Input Class Initialized
INFO - 2025-10-01 04:30:55 --> Language Class Initialized
INFO - 2025-10-01 04:30:55 --> Loader Class Initialized
INFO - 2025-10-01 04:30:55 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:55 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:55 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:55 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:55 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:55 --> Controller Class Initialized
INFO - 2025-10-01 09:30:55 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:55 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0406
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0648
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0612
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0477
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0551
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0503
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0494
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0406
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0476
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0642
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0544
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0653
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0597
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0635
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:56 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:56 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:56 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:56 --> Total execution time: 0.0590
INFO - 2025-10-01 04:30:56 --> Config Class Initialized
INFO - 2025-10-01 04:30:56 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:56 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:56 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:56 --> URI Class Initialized
INFO - 2025-10-01 04:30:56 --> Router Class Initialized
INFO - 2025-10-01 04:30:56 --> Output Class Initialized
INFO - 2025-10-01 04:30:56 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:56 --> CSRF cookie sent
INFO - 2025-10-01 04:30:56 --> Input Class Initialized
INFO - 2025-10-01 04:30:56 --> Language Class Initialized
INFO - 2025-10-01 04:30:56 --> Loader Class Initialized
INFO - 2025-10-01 04:30:56 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:56 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:56 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:56 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:56 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:56 --> Controller Class Initialized
INFO - 2025-10-01 09:30:56 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:56 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0613
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0573
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0652
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0659
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0664
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0513
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0656
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0649
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0637
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0504
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0649
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0620
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0516
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:57 --> Controller Class Initialized
INFO - 2025-10-01 09:30:57 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:57 --> Total execution time: 0.0606
INFO - 2025-10-01 04:30:57 --> Config Class Initialized
INFO - 2025-10-01 04:30:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:57 --> URI Class Initialized
INFO - 2025-10-01 04:30:57 --> Router Class Initialized
INFO - 2025-10-01 04:30:57 --> Output Class Initialized
INFO - 2025-10-01 04:30:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:57 --> CSRF cookie sent
INFO - 2025-10-01 04:30:57 --> Input Class Initialized
INFO - 2025-10-01 04:30:57 --> Language Class Initialized
INFO - 2025-10-01 04:30:57 --> Loader Class Initialized
INFO - 2025-10-01 04:30:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:58 --> Controller Class Initialized
INFO - 2025-10-01 09:30:58 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:30:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
INFO - 2025-10-01 09:30:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:58 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:58 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:58 --> Total execution time: 0.0626
INFO - 2025-10-01 04:30:58 --> Config Class Initialized
INFO - 2025-10-01 04:30:58 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:58 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:58 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:58 --> URI Class Initialized
INFO - 2025-10-01 04:30:58 --> Router Class Initialized
INFO - 2025-10-01 04:30:58 --> Output Class Initialized
INFO - 2025-10-01 04:30:58 --> Security Class Initialized
DEBUG - 2025-10-01 04:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:30:58 --> CSRF cookie sent
INFO - 2025-10-01 04:30:58 --> Input Class Initialized
INFO - 2025-10-01 04:30:58 --> Language Class Initialized
INFO - 2025-10-01 04:30:58 --> Loader Class Initialized
INFO - 2025-10-01 04:30:58 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:58 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:58 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:58 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:58 --> Controller Class Initialized
INFO - 2025-10-01 09:30:58 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Video_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 04:30:58 --> Config Class Initialized
INFO - 2025-10-01 04:30:58 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:30:58 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:30:58 --> Utf8 Class Initialized
INFO - 2025-10-01 04:30:58 --> URI Class Initialized
INFO - 2025-10-01 04:30:58 --> Router Class Initialized
INFO - 2025-10-01 04:30:58 --> Output Class Initialized
INFO - 2025-10-01 04:30:58 --> Security Class Initialized
INFO - 2025-10-01 09:30:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/oops.php
DEBUG - 2025-10-01 04:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 09:30:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 04:30:58 --> CSRF cookie sent
INFO - 2025-10-01 04:30:58 --> Input Class Initialized
INFO - 2025-10-01 09:30:58 --> Model "Log_model" initialized
INFO - 2025-10-01 04:30:58 --> Language Class Initialized
INFO - 2025-10-01 04:30:58 --> Loader Class Initialized
INFO - 2025-10-01 09:30:58 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:58 --> Total execution time: 0.0656
INFO - 2025-10-01 04:30:58 --> Helper loaded: url_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: text_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: string_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: form_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: download_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: security_helper
INFO - 2025-10-01 04:30:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:30:58 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:30:58 --> Form Validation Class Initialized
INFO - 2025-10-01 04:30:58 --> Model "User_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:30:58 --> Controller Class Initialized
INFO - 2025-10-01 09:30:58 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Sdm_model" initialized
INFO - 2025-10-01 09:30:58 --> Model "Sdm_unit_model" initialized
INFO - 2025-10-01 09:30:58 --> Query SDM berhasil untuk unit: Unit Teknologi Informasi, Total: 1
INFO - 2025-10-01 09:30:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\unit/list.php
INFO - 2025-10-01 09:30:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:30:58 --> Model "Log_model" initialized
INFO - 2025-10-01 09:30:58 --> Final output sent to browser
DEBUG - 2025-10-01 09:30:58 --> Total execution time: 0.0547
INFO - 2025-10-01 04:31:04 --> Config Class Initialized
INFO - 2025-10-01 04:31:04 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:31:04 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:31:04 --> Utf8 Class Initialized
INFO - 2025-10-01 04:31:04 --> URI Class Initialized
INFO - 2025-10-01 04:31:04 --> Router Class Initialized
INFO - 2025-10-01 04:31:04 --> Output Class Initialized
INFO - 2025-10-01 04:31:04 --> Security Class Initialized
DEBUG - 2025-10-01 04:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:31:04 --> CSRF cookie sent
INFO - 2025-10-01 04:31:04 --> Input Class Initialized
INFO - 2025-10-01 04:31:04 --> Language Class Initialized
INFO - 2025-10-01 04:31:05 --> Loader Class Initialized
INFO - 2025-10-01 04:31:05 --> Helper loaded: url_helper
INFO - 2025-10-01 04:31:05 --> Helper loaded: text_helper
INFO - 2025-10-01 04:31:05 --> Helper loaded: string_helper
INFO - 2025-10-01 04:31:05 --> Helper loaded: form_helper
INFO - 2025-10-01 04:31:05 --> Helper loaded: download_helper
INFO - 2025-10-01 04:31:05 --> Helper loaded: security_helper
INFO - 2025-10-01 04:31:05 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:31:05 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:31:05 --> Form Validation Class Initialized
INFO - 2025-10-01 04:31:05 --> Model "User_model" initialized
INFO - 2025-10-01 09:31:05 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:31:05 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:31:05 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:31:05 --> Controller Class Initialized
DEBUG - 2025-10-01 09:31:05 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-10-01 09:31:05 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\login/list.php
INFO - 2025-10-01 09:31:05 --> Model "Log_model" initialized
INFO - 2025-10-01 09:31:05 --> Final output sent to browser
DEBUG - 2025-10-01 09:31:05 --> Total execution time: 0.1764
INFO - 2025-10-01 04:31:11 --> Config Class Initialized
INFO - 2025-10-01 04:31:11 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:31:11 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:31:11 --> Utf8 Class Initialized
INFO - 2025-10-01 04:31:11 --> URI Class Initialized
INFO - 2025-10-01 04:31:11 --> Router Class Initialized
INFO - 2025-10-01 04:31:11 --> Output Class Initialized
INFO - 2025-10-01 04:31:11 --> Security Class Initialized
DEBUG - 2025-10-01 04:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:31:11 --> CSRF cookie sent
INFO - 2025-10-01 04:31:11 --> CSRF token verified
INFO - 2025-10-01 04:31:11 --> Input Class Initialized
INFO - 2025-10-01 04:31:11 --> Language Class Initialized
INFO - 2025-10-01 04:31:11 --> Loader Class Initialized
INFO - 2025-10-01 04:31:11 --> Helper loaded: url_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: text_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: string_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: form_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: download_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: security_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:31:11 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:31:11 --> Form Validation Class Initialized
INFO - 2025-10-01 04:31:11 --> Model "User_model" initialized
INFO - 2025-10-01 09:31:11 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:31:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:31:11 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:31:11 --> Controller Class Initialized
DEBUG - 2025-10-01 09:31:11 --> Recaptcha class already loaded. Second attempt ignored.
INFO - 2025-10-01 09:31:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-01 04:31:11 --> Config Class Initialized
INFO - 2025-10-01 04:31:11 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:31:11 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:31:11 --> Utf8 Class Initialized
INFO - 2025-10-01 04:31:11 --> URI Class Initialized
INFO - 2025-10-01 04:31:11 --> Router Class Initialized
INFO - 2025-10-01 04:31:11 --> Output Class Initialized
INFO - 2025-10-01 04:31:11 --> Security Class Initialized
DEBUG - 2025-10-01 04:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:31:11 --> CSRF cookie sent
INFO - 2025-10-01 04:31:11 --> Input Class Initialized
INFO - 2025-10-01 04:31:11 --> Language Class Initialized
INFO - 2025-10-01 04:31:11 --> Loader Class Initialized
INFO - 2025-10-01 04:31:11 --> Helper loaded: url_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: text_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: string_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: form_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: download_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: security_helper
INFO - 2025-10-01 04:31:11 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:31:11 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:31:11 --> Form Validation Class Initialized
INFO - 2025-10-01 04:31:11 --> Model "User_model" initialized
INFO - 2025-10-01 09:31:11 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:31:11 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:31:11 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:31:11 --> Controller Class Initialized
INFO - 2025-10-01 09:31:11 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:31:11 --> Model "Staff_model" initialized
INFO - 2025-10-01 09:31:11 --> Model "Dasbor_model" initialized
INFO - 2025-10-01 09:31:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/dasbor/list.php
INFO - 2025-10-01 09:31:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:31:12 --> Model "Log_model" initialized
INFO - 2025-10-01 09:31:12 --> Final output sent to browser
DEBUG - 2025-10-01 09:31:12 --> Total execution time: 1.3694
INFO - 2025-10-01 04:31:22 --> Config Class Initialized
INFO - 2025-10-01 04:31:22 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:31:22 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:31:22 --> Utf8 Class Initialized
INFO - 2025-10-01 04:31:22 --> URI Class Initialized
INFO - 2025-10-01 04:31:22 --> Router Class Initialized
INFO - 2025-10-01 04:31:22 --> Output Class Initialized
INFO - 2025-10-01 04:31:22 --> Security Class Initialized
DEBUG - 2025-10-01 04:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:31:22 --> CSRF cookie sent
INFO - 2025-10-01 04:31:22 --> Input Class Initialized
INFO - 2025-10-01 04:31:22 --> Language Class Initialized
INFO - 2025-10-01 04:31:22 --> Loader Class Initialized
INFO - 2025-10-01 04:31:22 --> Helper loaded: url_helper
INFO - 2025-10-01 04:31:22 --> Helper loaded: text_helper
INFO - 2025-10-01 04:31:22 --> Helper loaded: string_helper
INFO - 2025-10-01 04:31:22 --> Helper loaded: form_helper
INFO - 2025-10-01 04:31:22 --> Helper loaded: download_helper
INFO - 2025-10-01 04:31:22 --> Helper loaded: security_helper
INFO - 2025-10-01 04:31:22 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:31:22 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:31:22 --> Form Validation Class Initialized
INFO - 2025-10-01 04:31:22 --> Model "User_model" initialized
INFO - 2025-10-01 09:31:22 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:31:22 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:31:22 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:31:22 --> Controller Class Initialized
INFO - 2025-10-01 09:31:22 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:31:22 --> Model "Kategori_model" initialized
INFO - 2025-10-01 09:31:22 --> Model "Download_model" initialized
INFO - 2025-10-01 09:31:22 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:31:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/berita/list.php
INFO - 2025-10-01 09:31:22 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:31:22 --> Model "Log_model" initialized
INFO - 2025-10-01 09:31:22 --> Final output sent to browser
DEBUG - 2025-10-01 09:31:22 --> Total execution time: 0.2664
INFO - 2025-10-01 04:31:28 --> Config Class Initialized
INFO - 2025-10-01 04:31:28 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:31:28 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:31:28 --> Utf8 Class Initialized
INFO - 2025-10-01 04:31:28 --> URI Class Initialized
INFO - 2025-10-01 04:31:28 --> Router Class Initialized
INFO - 2025-10-01 04:31:28 --> Output Class Initialized
INFO - 2025-10-01 04:31:28 --> Security Class Initialized
DEBUG - 2025-10-01 04:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:31:28 --> CSRF cookie sent
INFO - 2025-10-01 04:31:29 --> Input Class Initialized
INFO - 2025-10-01 04:31:29 --> Language Class Initialized
INFO - 2025-10-01 04:31:29 --> Loader Class Initialized
INFO - 2025-10-01 04:31:29 --> Helper loaded: url_helper
INFO - 2025-10-01 04:31:29 --> Helper loaded: text_helper
INFO - 2025-10-01 04:31:29 --> Helper loaded: string_helper
INFO - 2025-10-01 04:31:29 --> Helper loaded: form_helper
INFO - 2025-10-01 04:31:29 --> Helper loaded: download_helper
INFO - 2025-10-01 04:31:29 --> Helper loaded: security_helper
INFO - 2025-10-01 04:31:29 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:31:29 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:31:29 --> Form Validation Class Initialized
INFO - 2025-10-01 04:31:29 --> Model "User_model" initialized
INFO - 2025-10-01 09:31:29 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:31:29 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:31:29 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:31:29 --> Controller Class Initialized
INFO - 2025-10-01 09:31:29 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:31:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/list.php
INFO - 2025-10-01 09:31:29 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:31:29 --> Model "Log_model" initialized
INFO - 2025-10-01 09:31:29 --> Final output sent to browser
DEBUG - 2025-10-01 09:31:29 --> Total execution time: 0.2335
INFO - 2025-10-01 04:31:33 --> Config Class Initialized
INFO - 2025-10-01 04:31:33 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:31:33 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:31:33 --> Utf8 Class Initialized
INFO - 2025-10-01 04:31:33 --> URI Class Initialized
INFO - 2025-10-01 04:31:33 --> Router Class Initialized
INFO - 2025-10-01 04:31:33 --> Output Class Initialized
INFO - 2025-10-01 04:31:33 --> Security Class Initialized
DEBUG - 2025-10-01 04:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:31:33 --> CSRF cookie sent
INFO - 2025-10-01 04:31:33 --> Input Class Initialized
INFO - 2025-10-01 04:31:33 --> Language Class Initialized
INFO - 2025-10-01 04:31:33 --> Loader Class Initialized
INFO - 2025-10-01 04:31:33 --> Helper loaded: url_helper
INFO - 2025-10-01 04:31:33 --> Helper loaded: text_helper
INFO - 2025-10-01 04:31:33 --> Helper loaded: string_helper
INFO - 2025-10-01 04:31:33 --> Helper loaded: form_helper
INFO - 2025-10-01 04:31:33 --> Helper loaded: download_helper
INFO - 2025-10-01 04:31:33 --> Helper loaded: security_helper
INFO - 2025-10-01 04:31:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:31:33 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:31:33 --> Form Validation Class Initialized
INFO - 2025-10-01 04:31:33 --> Model "User_model" initialized
INFO - 2025-10-01 09:31:33 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:31:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:31:33 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:31:33 --> Controller Class Initialized
INFO - 2025-10-01 09:31:33 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:31:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/edit.php
INFO - 2025-10-01 09:31:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:31:33 --> Model "Log_model" initialized
INFO - 2025-10-01 09:31:33 --> Final output sent to browser
DEBUG - 2025-10-01 09:31:33 --> Total execution time: 0.2334
INFO - 2025-10-01 04:32:15 --> Config Class Initialized
INFO - 2025-10-01 04:32:15 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:32:15 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:32:15 --> Utf8 Class Initialized
INFO - 2025-10-01 04:32:15 --> URI Class Initialized
INFO - 2025-10-01 04:32:15 --> Router Class Initialized
INFO - 2025-10-01 04:32:15 --> Output Class Initialized
INFO - 2025-10-01 04:32:15 --> Security Class Initialized
DEBUG - 2025-10-01 04:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:32:15 --> CSRF cookie sent
INFO - 2025-10-01 04:32:15 --> CSRF token verified
INFO - 2025-10-01 04:32:15 --> Input Class Initialized
INFO - 2025-10-01 04:32:15 --> Language Class Initialized
INFO - 2025-10-01 04:32:15 --> Loader Class Initialized
INFO - 2025-10-01 04:32:15 --> Helper loaded: url_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: text_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: string_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: form_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: download_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: security_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:32:15 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:32:15 --> Form Validation Class Initialized
INFO - 2025-10-01 04:32:15 --> Model "User_model" initialized
INFO - 2025-10-01 09:32:15 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:32:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:32:15 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:32:15 --> Controller Class Initialized
INFO - 2025-10-01 09:32:15 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:32:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-01 09:32:15 --> Upload Class Initialized
INFO - 2025-10-01 09:32:15 --> Language file loaded: language/english/upload_lang.php
INFO - 2025-10-01 09:32:15 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2025-10-01 04:32:15 --> Config Class Initialized
INFO - 2025-10-01 04:32:15 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:32:15 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:32:15 --> Utf8 Class Initialized
INFO - 2025-10-01 04:32:15 --> URI Class Initialized
INFO - 2025-10-01 04:32:15 --> Router Class Initialized
INFO - 2025-10-01 04:32:15 --> Output Class Initialized
INFO - 2025-10-01 04:32:15 --> Security Class Initialized
DEBUG - 2025-10-01 04:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:32:15 --> CSRF cookie sent
INFO - 2025-10-01 04:32:15 --> Input Class Initialized
INFO - 2025-10-01 04:32:15 --> Language Class Initialized
INFO - 2025-10-01 04:32:15 --> Loader Class Initialized
INFO - 2025-10-01 04:32:15 --> Helper loaded: url_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: text_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: string_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: form_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: download_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: security_helper
INFO - 2025-10-01 04:32:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:32:15 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:32:15 --> Form Validation Class Initialized
INFO - 2025-10-01 04:32:15 --> Model "User_model" initialized
INFO - 2025-10-01 09:32:15 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:32:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:32:15 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:32:15 --> Controller Class Initialized
INFO - 2025-10-01 09:32:15 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:32:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/list.php
INFO - 2025-10-01 09:32:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:32:15 --> Model "Log_model" initialized
INFO - 2025-10-01 09:32:15 --> Final output sent to browser
DEBUG - 2025-10-01 09:32:15 --> Total execution time: 0.0495
INFO - 2025-10-01 04:43:39 --> Config Class Initialized
INFO - 2025-10-01 04:43:39 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:43:39 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:43:39 --> Utf8 Class Initialized
INFO - 2025-10-01 04:43:39 --> URI Class Initialized
INFO - 2025-10-01 04:43:39 --> Router Class Initialized
INFO - 2025-10-01 04:43:39 --> Output Class Initialized
INFO - 2025-10-01 04:43:39 --> Security Class Initialized
DEBUG - 2025-10-01 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:43:39 --> CSRF cookie sent
INFO - 2025-10-01 04:43:39 --> Input Class Initialized
INFO - 2025-10-01 04:43:39 --> Language Class Initialized
INFO - 2025-10-01 04:43:39 --> Loader Class Initialized
INFO - 2025-10-01 04:43:39 --> Helper loaded: url_helper
INFO - 2025-10-01 04:43:39 --> Helper loaded: text_helper
INFO - 2025-10-01 04:43:39 --> Helper loaded: string_helper
INFO - 2025-10-01 04:43:39 --> Helper loaded: form_helper
INFO - 2025-10-01 04:43:39 --> Helper loaded: download_helper
INFO - 2025-10-01 04:43:39 --> Helper loaded: security_helper
INFO - 2025-10-01 04:43:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:43:39 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:43:39 --> Form Validation Class Initialized
INFO - 2025-10-01 04:43:39 --> Model "User_model" initialized
INFO - 2025-10-01 09:43:39 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:43:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:43:39 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:43:39 --> Controller Class Initialized
INFO - 2025-10-01 09:43:39 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:43:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/edit.php
INFO - 2025-10-01 09:43:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:43:39 --> Model "Log_model" initialized
INFO - 2025-10-01 09:43:39 --> Final output sent to browser
DEBUG - 2025-10-01 09:43:39 --> Total execution time: 0.0515
INFO - 2025-10-01 04:43:51 --> Config Class Initialized
INFO - 2025-10-01 04:43:51 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:43:51 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:43:51 --> Utf8 Class Initialized
INFO - 2025-10-01 04:43:51 --> URI Class Initialized
INFO - 2025-10-01 04:43:51 --> Router Class Initialized
INFO - 2025-10-01 04:43:51 --> Output Class Initialized
INFO - 2025-10-01 04:43:51 --> Security Class Initialized
DEBUG - 2025-10-01 04:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:43:51 --> CSRF cookie sent
INFO - 2025-10-01 04:43:51 --> CSRF token verified
INFO - 2025-10-01 04:43:51 --> Input Class Initialized
INFO - 2025-10-01 04:43:51 --> Language Class Initialized
INFO - 2025-10-01 04:43:51 --> Loader Class Initialized
INFO - 2025-10-01 04:43:51 --> Helper loaded: url_helper
INFO - 2025-10-01 04:43:51 --> Helper loaded: text_helper
INFO - 2025-10-01 04:43:51 --> Helper loaded: string_helper
INFO - 2025-10-01 04:43:51 --> Helper loaded: form_helper
INFO - 2025-10-01 04:43:51 --> Helper loaded: download_helper
INFO - 2025-10-01 04:43:51 --> Helper loaded: security_helper
INFO - 2025-10-01 04:43:51 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:43:51 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:43:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:43:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:43:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:43:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:43:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:43:52 --> Controller Class Initialized
INFO - 2025-10-01 09:43:52 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:43:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-01 09:43:52 --> Upload Class Initialized
INFO - 2025-10-01 04:43:52 --> Config Class Initialized
INFO - 2025-10-01 04:43:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:43:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:43:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:43:52 --> URI Class Initialized
INFO - 2025-10-01 04:43:52 --> Router Class Initialized
INFO - 2025-10-01 04:43:52 --> Output Class Initialized
INFO - 2025-10-01 04:43:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:43:52 --> CSRF cookie sent
INFO - 2025-10-01 04:43:52 --> Input Class Initialized
INFO - 2025-10-01 04:43:52 --> Language Class Initialized
INFO - 2025-10-01 04:43:52 --> Loader Class Initialized
INFO - 2025-10-01 04:43:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:43:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:43:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:43:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:43:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:43:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:43:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:43:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:43:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:43:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:43:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:43:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:43:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:43:52 --> Controller Class Initialized
INFO - 2025-10-01 09:43:52 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:43:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/list.php
INFO - 2025-10-01 09:43:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:43:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:43:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:43:52 --> Total execution time: 0.0463
INFO - 2025-10-01 04:43:58 --> Config Class Initialized
INFO - 2025-10-01 04:43:58 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:43:58 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:43:58 --> Utf8 Class Initialized
INFO - 2025-10-01 04:43:58 --> URI Class Initialized
INFO - 2025-10-01 04:43:58 --> Router Class Initialized
INFO - 2025-10-01 04:43:58 --> Output Class Initialized
INFO - 2025-10-01 04:43:58 --> Security Class Initialized
DEBUG - 2025-10-01 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:43:58 --> CSRF cookie sent
INFO - 2025-10-01 04:43:58 --> Input Class Initialized
INFO - 2025-10-01 04:43:58 --> Language Class Initialized
INFO - 2025-10-01 04:43:58 --> Loader Class Initialized
INFO - 2025-10-01 04:43:58 --> Helper loaded: url_helper
INFO - 2025-10-01 04:43:58 --> Helper loaded: text_helper
INFO - 2025-10-01 04:43:58 --> Helper loaded: string_helper
INFO - 2025-10-01 04:43:58 --> Helper loaded: form_helper
INFO - 2025-10-01 04:43:58 --> Helper loaded: download_helper
INFO - 2025-10-01 04:43:58 --> Helper loaded: security_helper
INFO - 2025-10-01 04:43:58 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:43:58 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:43:58 --> Form Validation Class Initialized
INFO - 2025-10-01 04:43:58 --> Model "User_model" initialized
INFO - 2025-10-01 09:43:58 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:43:58 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:43:58 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:43:58 --> Controller Class Initialized
INFO - 2025-10-01 09:43:58 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:43:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/edit.php
INFO - 2025-10-01 09:43:58 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:43:58 --> Model "Log_model" initialized
INFO - 2025-10-01 09:43:58 --> Final output sent to browser
DEBUG - 2025-10-01 09:43:58 --> Total execution time: 0.0553
INFO - 2025-10-01 04:44:07 --> Config Class Initialized
INFO - 2025-10-01 04:44:07 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:07 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:07 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:07 --> URI Class Initialized
INFO - 2025-10-01 04:44:07 --> Router Class Initialized
INFO - 2025-10-01 04:44:07 --> Output Class Initialized
INFO - 2025-10-01 04:44:07 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:07 --> CSRF cookie sent
INFO - 2025-10-01 04:44:07 --> CSRF token verified
INFO - 2025-10-01 04:44:07 --> Input Class Initialized
INFO - 2025-10-01 04:44:07 --> Language Class Initialized
INFO - 2025-10-01 04:44:07 --> Loader Class Initialized
INFO - 2025-10-01 04:44:07 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:07 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:07 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:07 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:07 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:07 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:07 --> Controller Class Initialized
INFO - 2025-10-01 09:44:07 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-01 09:44:07 --> Upload Class Initialized
INFO - 2025-10-01 04:44:07 --> Config Class Initialized
INFO - 2025-10-01 04:44:07 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:07 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:07 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:07 --> URI Class Initialized
INFO - 2025-10-01 04:44:07 --> Router Class Initialized
INFO - 2025-10-01 04:44:07 --> Output Class Initialized
INFO - 2025-10-01 04:44:07 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:07 --> CSRF cookie sent
INFO - 2025-10-01 04:44:07 --> Input Class Initialized
INFO - 2025-10-01 04:44:07 --> Language Class Initialized
INFO - 2025-10-01 04:44:07 --> Loader Class Initialized
INFO - 2025-10-01 04:44:07 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:07 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:07 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:07 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:07 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:07 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:07 --> Controller Class Initialized
INFO - 2025-10-01 09:44:07 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/list.php
INFO - 2025-10-01 09:44:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:44:07 --> Model "Log_model" initialized
INFO - 2025-10-01 09:44:07 --> Final output sent to browser
DEBUG - 2025-10-01 09:44:07 --> Total execution time: 0.0552
INFO - 2025-10-01 04:44:12 --> Config Class Initialized
INFO - 2025-10-01 04:44:12 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:12 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:12 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:12 --> URI Class Initialized
INFO - 2025-10-01 04:44:12 --> Router Class Initialized
INFO - 2025-10-01 04:44:12 --> Output Class Initialized
INFO - 2025-10-01 04:44:12 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:12 --> CSRF cookie sent
INFO - 2025-10-01 04:44:12 --> Input Class Initialized
INFO - 2025-10-01 04:44:12 --> Language Class Initialized
INFO - 2025-10-01 04:44:12 --> Loader Class Initialized
INFO - 2025-10-01 04:44:12 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:12 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:12 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:12 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:12 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:12 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:12 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:12 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:12 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:12 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:12 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:12 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:12 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:12 --> Controller Class Initialized
INFO - 2025-10-01 09:44:12 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/edit.php
INFO - 2025-10-01 09:44:12 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:44:12 --> Model "Log_model" initialized
INFO - 2025-10-01 09:44:12 --> Final output sent to browser
DEBUG - 2025-10-01 09:44:12 --> Total execution time: 0.0512
INFO - 2025-10-01 04:44:19 --> Config Class Initialized
INFO - 2025-10-01 04:44:19 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:19 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:19 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:19 --> URI Class Initialized
INFO - 2025-10-01 04:44:19 --> Router Class Initialized
INFO - 2025-10-01 04:44:19 --> Output Class Initialized
INFO - 2025-10-01 04:44:19 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:19 --> CSRF cookie sent
INFO - 2025-10-01 04:44:19 --> CSRF token verified
INFO - 2025-10-01 04:44:19 --> Input Class Initialized
INFO - 2025-10-01 04:44:19 --> Language Class Initialized
INFO - 2025-10-01 04:44:19 --> Loader Class Initialized
INFO - 2025-10-01 04:44:19 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:19 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:19 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:19 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:19 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:19 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:19 --> Controller Class Initialized
INFO - 2025-10-01 09:44:19 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-01 09:44:19 --> Upload Class Initialized
INFO - 2025-10-01 04:44:19 --> Config Class Initialized
INFO - 2025-10-01 04:44:19 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:19 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:19 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:19 --> URI Class Initialized
INFO - 2025-10-01 04:44:19 --> Router Class Initialized
INFO - 2025-10-01 04:44:19 --> Output Class Initialized
INFO - 2025-10-01 04:44:19 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:19 --> CSRF cookie sent
INFO - 2025-10-01 04:44:19 --> Input Class Initialized
INFO - 2025-10-01 04:44:19 --> Language Class Initialized
INFO - 2025-10-01 04:44:19 --> Loader Class Initialized
INFO - 2025-10-01 04:44:19 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:19 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:19 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:19 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:19 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:19 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:19 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:19 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:19 --> Controller Class Initialized
INFO - 2025-10-01 09:44:19 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/list.php
INFO - 2025-10-01 09:44:19 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:44:19 --> Model "Log_model" initialized
INFO - 2025-10-01 09:44:19 --> Final output sent to browser
DEBUG - 2025-10-01 09:44:19 --> Total execution time: 0.0486
INFO - 2025-10-01 04:44:23 --> Config Class Initialized
INFO - 2025-10-01 04:44:23 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:23 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:23 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:23 --> URI Class Initialized
INFO - 2025-10-01 04:44:23 --> Router Class Initialized
INFO - 2025-10-01 04:44:23 --> Output Class Initialized
INFO - 2025-10-01 04:44:23 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:23 --> CSRF cookie sent
INFO - 2025-10-01 04:44:23 --> Input Class Initialized
INFO - 2025-10-01 04:44:23 --> Language Class Initialized
INFO - 2025-10-01 04:44:23 --> Loader Class Initialized
INFO - 2025-10-01 04:44:23 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:23 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:23 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:23 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:23 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:23 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:23 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:23 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:23 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:23 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:23 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:23 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:23 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:23 --> Controller Class Initialized
INFO - 2025-10-01 09:44:23 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/edit.php
INFO - 2025-10-01 09:44:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:44:23 --> Model "Log_model" initialized
INFO - 2025-10-01 09:44:23 --> Final output sent to browser
DEBUG - 2025-10-01 09:44:23 --> Total execution time: 0.0611
INFO - 2025-10-01 04:44:41 --> Config Class Initialized
INFO - 2025-10-01 04:44:41 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:41 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:41 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:41 --> URI Class Initialized
INFO - 2025-10-01 04:44:41 --> Router Class Initialized
INFO - 2025-10-01 04:44:41 --> Output Class Initialized
INFO - 2025-10-01 04:44:41 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:41 --> CSRF cookie sent
INFO - 2025-10-01 04:44:41 --> CSRF token verified
INFO - 2025-10-01 04:44:41 --> Input Class Initialized
INFO - 2025-10-01 04:44:41 --> Language Class Initialized
INFO - 2025-10-01 04:44:41 --> Loader Class Initialized
INFO - 2025-10-01 04:44:41 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:41 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:41 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:41 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:41 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:41 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:41 --> Controller Class Initialized
INFO - 2025-10-01 09:44:41 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-01 09:44:41 --> Upload Class Initialized
INFO - 2025-10-01 04:44:41 --> Config Class Initialized
INFO - 2025-10-01 04:44:41 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:41 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:41 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:41 --> URI Class Initialized
INFO - 2025-10-01 04:44:41 --> Router Class Initialized
INFO - 2025-10-01 04:44:41 --> Output Class Initialized
INFO - 2025-10-01 04:44:41 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:41 --> CSRF cookie sent
INFO - 2025-10-01 04:44:41 --> Input Class Initialized
INFO - 2025-10-01 04:44:41 --> Language Class Initialized
INFO - 2025-10-01 04:44:41 --> Loader Class Initialized
INFO - 2025-10-01 04:44:41 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:41 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:41 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:41 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:41 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:41 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:41 --> Controller Class Initialized
INFO - 2025-10-01 09:44:41 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/list.php
INFO - 2025-10-01 09:44:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:44:41 --> Model "Log_model" initialized
INFO - 2025-10-01 09:44:41 --> Final output sent to browser
DEBUG - 2025-10-01 09:44:41 --> Total execution time: 0.0593
INFO - 2025-10-01 04:44:45 --> Config Class Initialized
INFO - 2025-10-01 04:44:45 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:45 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:45 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:45 --> URI Class Initialized
INFO - 2025-10-01 04:44:45 --> Router Class Initialized
INFO - 2025-10-01 04:44:45 --> Output Class Initialized
INFO - 2025-10-01 04:44:45 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:45 --> CSRF cookie sent
INFO - 2025-10-01 04:44:45 --> Input Class Initialized
INFO - 2025-10-01 04:44:45 --> Language Class Initialized
INFO - 2025-10-01 04:44:45 --> Loader Class Initialized
INFO - 2025-10-01 04:44:45 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:45 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:45 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:45 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:45 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:45 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:45 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:45 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:45 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:45 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:45 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:45 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:45 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:45 --> Controller Class Initialized
INFO - 2025-10-01 09:44:45 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/edit.php
INFO - 2025-10-01 09:44:45 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:44:45 --> Model "Log_model" initialized
INFO - 2025-10-01 09:44:45 --> Final output sent to browser
DEBUG - 2025-10-01 09:44:45 --> Total execution time: 0.0547
INFO - 2025-10-01 04:44:53 --> Config Class Initialized
INFO - 2025-10-01 04:44:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:53 --> URI Class Initialized
INFO - 2025-10-01 04:44:53 --> Router Class Initialized
INFO - 2025-10-01 04:44:53 --> Output Class Initialized
INFO - 2025-10-01 04:44:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:53 --> CSRF cookie sent
INFO - 2025-10-01 04:44:53 --> CSRF token verified
INFO - 2025-10-01 04:44:53 --> Input Class Initialized
INFO - 2025-10-01 04:44:53 --> Language Class Initialized
INFO - 2025-10-01 04:44:53 --> Loader Class Initialized
INFO - 2025-10-01 04:44:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:53 --> Controller Class Initialized
INFO - 2025-10-01 09:44:53 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-01 09:44:53 --> Upload Class Initialized
INFO - 2025-10-01 04:44:53 --> Config Class Initialized
INFO - 2025-10-01 04:44:53 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:53 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:53 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:53 --> URI Class Initialized
INFO - 2025-10-01 04:44:53 --> Router Class Initialized
INFO - 2025-10-01 04:44:53 --> Output Class Initialized
INFO - 2025-10-01 04:44:53 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:53 --> CSRF cookie sent
INFO - 2025-10-01 04:44:53 --> Input Class Initialized
INFO - 2025-10-01 04:44:53 --> Language Class Initialized
INFO - 2025-10-01 04:44:53 --> Loader Class Initialized
INFO - 2025-10-01 04:44:53 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:53 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:53 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:53 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:53 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:53 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:53 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:53 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:53 --> Controller Class Initialized
INFO - 2025-10-01 09:44:53 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/list.php
INFO - 2025-10-01 09:44:53 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:44:53 --> Model "Log_model" initialized
INFO - 2025-10-01 09:44:53 --> Final output sent to browser
DEBUG - 2025-10-01 09:44:53 --> Total execution time: 0.0458
INFO - 2025-10-01 04:44:57 --> Config Class Initialized
INFO - 2025-10-01 04:44:57 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:44:57 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:44:57 --> Utf8 Class Initialized
INFO - 2025-10-01 04:44:57 --> URI Class Initialized
INFO - 2025-10-01 04:44:57 --> Router Class Initialized
INFO - 2025-10-01 04:44:57 --> Output Class Initialized
INFO - 2025-10-01 04:44:57 --> Security Class Initialized
DEBUG - 2025-10-01 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:44:57 --> CSRF cookie sent
INFO - 2025-10-01 04:44:57 --> Input Class Initialized
INFO - 2025-10-01 04:44:57 --> Language Class Initialized
INFO - 2025-10-01 04:44:57 --> Loader Class Initialized
INFO - 2025-10-01 04:44:57 --> Helper loaded: url_helper
INFO - 2025-10-01 04:44:57 --> Helper loaded: text_helper
INFO - 2025-10-01 04:44:57 --> Helper loaded: string_helper
INFO - 2025-10-01 04:44:57 --> Helper loaded: form_helper
INFO - 2025-10-01 04:44:57 --> Helper loaded: download_helper
INFO - 2025-10-01 04:44:57 --> Helper loaded: security_helper
INFO - 2025-10-01 04:44:57 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:44:57 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:44:57 --> Form Validation Class Initialized
INFO - 2025-10-01 04:44:57 --> Model "User_model" initialized
INFO - 2025-10-01 09:44:57 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:44:57 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:44:57 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:44:57 --> Controller Class Initialized
INFO - 2025-10-01 09:44:57 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:44:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/edit.php
INFO - 2025-10-01 09:44:57 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:44:57 --> Model "Log_model" initialized
INFO - 2025-10-01 09:44:57 --> Final output sent to browser
DEBUG - 2025-10-01 09:44:57 --> Total execution time: 0.0497
INFO - 2025-10-01 04:45:03 --> Config Class Initialized
INFO - 2025-10-01 04:45:03 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:45:03 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:45:03 --> Utf8 Class Initialized
INFO - 2025-10-01 04:45:03 --> URI Class Initialized
INFO - 2025-10-01 04:45:03 --> Router Class Initialized
INFO - 2025-10-01 04:45:03 --> Output Class Initialized
INFO - 2025-10-01 04:45:03 --> Security Class Initialized
DEBUG - 2025-10-01 04:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:45:03 --> CSRF cookie sent
INFO - 2025-10-01 04:45:03 --> CSRF token verified
INFO - 2025-10-01 04:45:03 --> Input Class Initialized
INFO - 2025-10-01 04:45:03 --> Language Class Initialized
INFO - 2025-10-01 04:45:03 --> Loader Class Initialized
INFO - 2025-10-01 04:45:03 --> Helper loaded: url_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: text_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: string_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: form_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: download_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: security_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:45:03 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:45:03 --> Form Validation Class Initialized
INFO - 2025-10-01 04:45:03 --> Model "User_model" initialized
INFO - 2025-10-01 09:45:03 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:45:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:45:03 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:45:03 --> Controller Class Initialized
INFO - 2025-10-01 09:45:03 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:45:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-01 09:45:03 --> Upload Class Initialized
INFO - 2025-10-01 04:45:03 --> Config Class Initialized
INFO - 2025-10-01 04:45:03 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:45:03 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:45:03 --> Utf8 Class Initialized
INFO - 2025-10-01 04:45:03 --> URI Class Initialized
INFO - 2025-10-01 04:45:03 --> Router Class Initialized
INFO - 2025-10-01 04:45:03 --> Output Class Initialized
INFO - 2025-10-01 04:45:03 --> Security Class Initialized
DEBUG - 2025-10-01 04:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:45:03 --> CSRF cookie sent
INFO - 2025-10-01 04:45:03 --> Input Class Initialized
INFO - 2025-10-01 04:45:03 --> Language Class Initialized
INFO - 2025-10-01 04:45:03 --> Loader Class Initialized
INFO - 2025-10-01 04:45:03 --> Helper loaded: url_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: text_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: string_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: form_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: download_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: security_helper
INFO - 2025-10-01 04:45:03 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:45:03 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:45:03 --> Form Validation Class Initialized
INFO - 2025-10-01 04:45:03 --> Model "User_model" initialized
INFO - 2025-10-01 09:45:03 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:45:03 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:45:03 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:45:03 --> Controller Class Initialized
INFO - 2025-10-01 09:45:03 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:45:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/unit/list.php
INFO - 2025-10-01 09:45:03 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:45:03 --> Model "Log_model" initialized
INFO - 2025-10-01 09:45:03 --> Final output sent to browser
DEBUG - 2025-10-01 09:45:03 --> Total execution time: 0.0576
INFO - 2025-10-01 04:45:07 --> Config Class Initialized
INFO - 2025-10-01 04:45:07 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:45:07 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:45:07 --> Utf8 Class Initialized
INFO - 2025-10-01 04:45:07 --> URI Class Initialized
DEBUG - 2025-10-01 04:45:07 --> No URI present. Default controller set.
INFO - 2025-10-01 04:45:07 --> Router Class Initialized
INFO - 2025-10-01 04:45:07 --> Output Class Initialized
INFO - 2025-10-01 04:45:07 --> Security Class Initialized
DEBUG - 2025-10-01 04:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:45:07 --> CSRF cookie sent
INFO - 2025-10-01 04:45:07 --> Input Class Initialized
INFO - 2025-10-01 04:45:07 --> Language Class Initialized
INFO - 2025-10-01 04:45:07 --> Loader Class Initialized
INFO - 2025-10-01 04:45:07 --> Helper loaded: url_helper
INFO - 2025-10-01 04:45:07 --> Helper loaded: text_helper
INFO - 2025-10-01 04:45:07 --> Helper loaded: string_helper
INFO - 2025-10-01 04:45:07 --> Helper loaded: form_helper
INFO - 2025-10-01 04:45:07 --> Helper loaded: download_helper
INFO - 2025-10-01 04:45:07 --> Helper loaded: security_helper
INFO - 2025-10-01 04:45:07 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:45:07 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:45:07 --> Form Validation Class Initialized
INFO - 2025-10-01 04:45:07 --> Model "User_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:45:07 --> Controller Class Initialized
INFO - 2025-10-01 09:45:07 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Video_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:45:07 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-01 09:45:07 --> Pagination Class Initialized
INFO - 2025-10-01 09:45:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-01 09:45:07 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:45:07 --> Model "Log_model" initialized
INFO - 2025-10-01 09:45:07 --> Final output sent to browser
DEBUG - 2025-10-01 09:45:07 --> Total execution time: 0.1007
INFO - 2025-10-01 04:45:08 --> Config Class Initialized
INFO - 2025-10-01 04:45:08 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:45:08 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:45:08 --> Utf8 Class Initialized
INFO - 2025-10-01 04:45:08 --> URI Class Initialized
INFO - 2025-10-01 04:45:08 --> Router Class Initialized
INFO - 2025-10-01 04:45:08 --> Output Class Initialized
INFO - 2025-10-01 04:45:08 --> Security Class Initialized
DEBUG - 2025-10-01 04:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:45:08 --> CSRF cookie sent
INFO - 2025-10-01 04:45:08 --> Input Class Initialized
INFO - 2025-10-01 04:45:08 --> Language Class Initialized
INFO - 2025-10-01 04:45:08 --> Loader Class Initialized
INFO - 2025-10-01 04:45:08 --> Helper loaded: url_helper
INFO - 2025-10-01 04:45:08 --> Helper loaded: text_helper
INFO - 2025-10-01 04:45:08 --> Helper loaded: string_helper
INFO - 2025-10-01 04:45:08 --> Helper loaded: form_helper
INFO - 2025-10-01 04:45:08 --> Helper loaded: download_helper
INFO - 2025-10-01 04:45:08 --> Helper loaded: security_helper
INFO - 2025-10-01 04:45:08 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:45:08 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:45:08 --> Form Validation Class Initialized
INFO - 2025-10-01 04:45:08 --> Model "User_model" initialized
INFO - 2025-10-01 09:45:08 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:45:08 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:45:08 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:45:08 --> Controller Class Initialized
INFO - 2025-10-01 09:45:09 --> Model "Pusat_model" initialized
INFO - 2025-10-01 09:45:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/pusat/list.php
INFO - 2025-10-01 09:45:09 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:45:09 --> Model "Log_model" initialized
INFO - 2025-10-01 09:45:09 --> Final output sent to browser
DEBUG - 2025-10-01 09:45:09 --> Total execution time: 0.2757
INFO - 2025-10-01 04:45:15 --> Config Class Initialized
INFO - 2025-10-01 04:45:15 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:45:15 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:45:15 --> Utf8 Class Initialized
INFO - 2025-10-01 04:45:15 --> URI Class Initialized
INFO - 2025-10-01 04:45:15 --> Router Class Initialized
INFO - 2025-10-01 04:45:15 --> Output Class Initialized
INFO - 2025-10-01 04:45:15 --> Security Class Initialized
DEBUG - 2025-10-01 04:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:45:15 --> CSRF cookie sent
INFO - 2025-10-01 04:45:15 --> Input Class Initialized
INFO - 2025-10-01 04:45:15 --> Language Class Initialized
INFO - 2025-10-01 04:45:15 --> Loader Class Initialized
INFO - 2025-10-01 04:45:15 --> Helper loaded: url_helper
INFO - 2025-10-01 04:45:15 --> Helper loaded: text_helper
INFO - 2025-10-01 04:45:15 --> Helper loaded: string_helper
INFO - 2025-10-01 04:45:15 --> Helper loaded: form_helper
INFO - 2025-10-01 04:45:15 --> Helper loaded: download_helper
INFO - 2025-10-01 04:45:15 --> Helper loaded: security_helper
INFO - 2025-10-01 04:45:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:45:15 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:45:15 --> Form Validation Class Initialized
INFO - 2025-10-01 04:45:15 --> Model "User_model" initialized
INFO - 2025-10-01 09:45:15 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:45:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:45:15 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:45:15 --> Controller Class Initialized
INFO - 2025-10-01 09:45:15 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:45:15 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:45:15 --> Model "Sdm_model" initialized
INFO - 2025-10-01 09:45:15 --> Model "Sdm_unit_model" initialized
INFO - 2025-10-01 09:45:15 --> Query SDM berhasil untuk unit: Unit Pengelola Usaha, Total: 1
INFO - 2025-10-01 09:45:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\unit/list.php
INFO - 2025-10-01 09:45:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:45:15 --> Model "Log_model" initialized
INFO - 2025-10-01 09:45:15 --> Final output sent to browser
DEBUG - 2025-10-01 09:45:15 --> Total execution time: 0.0832
INFO - 2025-10-01 04:45:25 --> Config Class Initialized
INFO - 2025-10-01 04:45:25 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:45:25 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:45:25 --> Utf8 Class Initialized
INFO - 2025-10-01 04:45:25 --> URI Class Initialized
INFO - 2025-10-01 04:45:25 --> Router Class Initialized
INFO - 2025-10-01 04:45:25 --> Output Class Initialized
INFO - 2025-10-01 04:45:25 --> Security Class Initialized
DEBUG - 2025-10-01 04:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:45:25 --> CSRF cookie sent
INFO - 2025-10-01 04:45:25 --> Input Class Initialized
INFO - 2025-10-01 04:45:25 --> Language Class Initialized
INFO - 2025-10-01 04:45:25 --> Loader Class Initialized
INFO - 2025-10-01 04:45:25 --> Helper loaded: url_helper
INFO - 2025-10-01 04:45:25 --> Helper loaded: text_helper
INFO - 2025-10-01 04:45:25 --> Helper loaded: string_helper
INFO - 2025-10-01 04:45:25 --> Helper loaded: form_helper
INFO - 2025-10-01 04:45:25 --> Helper loaded: download_helper
INFO - 2025-10-01 04:45:25 --> Helper loaded: security_helper
INFO - 2025-10-01 04:45:25 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:45:25 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:45:25 --> Form Validation Class Initialized
INFO - 2025-10-01 04:45:25 --> Model "User_model" initialized
INFO - 2025-10-01 09:45:25 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:45:25 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:45:25 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:45:25 --> Controller Class Initialized
INFO - 2025-10-01 09:45:25 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:45:25 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:45:25 --> Model "Sdm_model" initialized
INFO - 2025-10-01 09:45:25 --> Model "Sdm_unit_model" initialized
INFO - 2025-10-01 09:45:25 --> Query SDM berhasil untuk unit: Unit Teknologi Informasi, Total: 1
INFO - 2025-10-01 09:45:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\unit/list.php
INFO - 2025-10-01 09:45:25 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:45:26 --> Model "Log_model" initialized
INFO - 2025-10-01 09:45:26 --> Final output sent to browser
DEBUG - 2025-10-01 09:45:26 --> Total execution time: 0.0716
INFO - 2025-10-01 04:45:33 --> Config Class Initialized
INFO - 2025-10-01 04:45:33 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:45:33 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:45:33 --> Utf8 Class Initialized
INFO - 2025-10-01 04:45:33 --> URI Class Initialized
INFO - 2025-10-01 04:45:33 --> Router Class Initialized
INFO - 2025-10-01 04:45:33 --> Output Class Initialized
INFO - 2025-10-01 04:45:33 --> Security Class Initialized
DEBUG - 2025-10-01 04:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:45:33 --> CSRF cookie sent
INFO - 2025-10-01 04:45:33 --> Input Class Initialized
INFO - 2025-10-01 04:45:33 --> Language Class Initialized
INFO - 2025-10-01 04:45:33 --> Loader Class Initialized
INFO - 2025-10-01 04:45:33 --> Helper loaded: url_helper
INFO - 2025-10-01 04:45:33 --> Helper loaded: text_helper
INFO - 2025-10-01 04:45:33 --> Helper loaded: string_helper
INFO - 2025-10-01 04:45:33 --> Helper loaded: form_helper
INFO - 2025-10-01 04:45:33 --> Helper loaded: download_helper
INFO - 2025-10-01 04:45:33 --> Helper loaded: security_helper
INFO - 2025-10-01 04:45:33 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:45:33 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:45:33 --> Form Validation Class Initialized
INFO - 2025-10-01 04:45:33 --> Model "User_model" initialized
INFO - 2025-10-01 09:45:33 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:45:33 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:45:33 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:45:33 --> Controller Class Initialized
INFO - 2025-10-01 09:45:33 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:45:33 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:45:33 --> Model "Sdm_model" initialized
INFO - 2025-10-01 09:45:33 --> Model "Sdm_unit_model" initialized
INFO - 2025-10-01 09:45:33 --> Query SDM berhasil untuk unit: Unit Perpustakaan Terpadu, Total: 1
INFO - 2025-10-01 09:45:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\unit/list.php
INFO - 2025-10-01 09:45:33 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:45:33 --> Model "Log_model" initialized
INFO - 2025-10-01 09:45:33 --> Final output sent to browser
DEBUG - 2025-10-01 09:45:33 --> Total execution time: 0.0995
INFO - 2025-10-01 04:45:39 --> Config Class Initialized
INFO - 2025-10-01 04:45:39 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:45:39 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:45:39 --> Utf8 Class Initialized
INFO - 2025-10-01 04:45:39 --> URI Class Initialized
INFO - 2025-10-01 04:45:39 --> Router Class Initialized
INFO - 2025-10-01 04:45:39 --> Output Class Initialized
INFO - 2025-10-01 04:45:39 --> Security Class Initialized
DEBUG - 2025-10-01 04:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:45:39 --> CSRF cookie sent
INFO - 2025-10-01 04:45:39 --> Input Class Initialized
INFO - 2025-10-01 04:45:39 --> Language Class Initialized
INFO - 2025-10-01 04:45:39 --> Loader Class Initialized
INFO - 2025-10-01 04:45:39 --> Helper loaded: url_helper
INFO - 2025-10-01 04:45:39 --> Helper loaded: text_helper
INFO - 2025-10-01 04:45:39 --> Helper loaded: string_helper
INFO - 2025-10-01 04:45:39 --> Helper loaded: form_helper
INFO - 2025-10-01 04:45:39 --> Helper loaded: download_helper
INFO - 2025-10-01 04:45:39 --> Helper loaded: security_helper
INFO - 2025-10-01 04:45:39 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:45:39 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:45:39 --> Form Validation Class Initialized
INFO - 2025-10-01 04:45:39 --> Model "User_model" initialized
INFO - 2025-10-01 09:45:39 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:45:39 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:45:39 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:45:39 --> Controller Class Initialized
INFO - 2025-10-01 09:45:39 --> Model "Unit_model" initialized
INFO - 2025-10-01 09:45:39 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:45:39 --> Model "Sdm_model" initialized
INFO - 2025-10-01 09:45:39 --> Model "Sdm_unit_model" initialized
INFO - 2025-10-01 09:45:39 --> Query SDM berhasil untuk unit: Unit Pengembangan Kompetensi, Total: 1
INFO - 2025-10-01 09:45:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\unit/list.php
INFO - 2025-10-01 09:45:39 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:45:39 --> Model "Log_model" initialized
INFO - 2025-10-01 09:45:39 --> Final output sent to browser
DEBUG - 2025-10-01 09:45:39 --> Total execution time: 0.0807
INFO - 2025-10-01 04:45:46 --> Config Class Initialized
INFO - 2025-10-01 04:45:46 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:45:46 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:45:46 --> Utf8 Class Initialized
INFO - 2025-10-01 04:45:46 --> URI Class Initialized
INFO - 2025-10-01 04:45:46 --> Router Class Initialized
INFO - 2025-10-01 04:45:46 --> Output Class Initialized
INFO - 2025-10-01 04:45:46 --> Security Class Initialized
DEBUG - 2025-10-01 04:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:45:46 --> CSRF cookie sent
INFO - 2025-10-01 04:45:46 --> Input Class Initialized
INFO - 2025-10-01 04:45:46 --> Language Class Initialized
INFO - 2025-10-01 04:45:46 --> Loader Class Initialized
INFO - 2025-10-01 04:45:46 --> Helper loaded: url_helper
INFO - 2025-10-01 04:45:46 --> Helper loaded: text_helper
INFO - 2025-10-01 04:45:46 --> Helper loaded: string_helper
INFO - 2025-10-01 04:45:46 --> Helper loaded: form_helper
INFO - 2025-10-01 04:45:46 --> Helper loaded: download_helper
INFO - 2025-10-01 04:45:46 --> Helper loaded: security_helper
INFO - 2025-10-01 04:45:46 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:45:46 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:45:46 --> Form Validation Class Initialized
INFO - 2025-10-01 04:45:46 --> Model "User_model" initialized
INFO - 2025-10-01 09:45:46 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:45:46 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:45:46 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:45:46 --> Controller Class Initialized
INFO - 2025-10-01 09:45:46 --> Model "Pusat_model" initialized
INFO - 2025-10-01 09:45:46 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:45:46 --> Model "Sdm_model" initialized
INFO - 2025-10-01 09:45:47 --> Model "Sdm_pusat_model" initialized
INFO - 2025-10-01 09:45:47 --> Query SDM berhasil untuk pusat: Pusat Penelitian dan Pengabdian Masyarakat, Total: 1
INFO - 2025-10-01 09:45:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-10-01 09:45:47 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:45:47 --> Model "Log_model" initialized
INFO - 2025-10-01 09:45:47 --> Final output sent to browser
DEBUG - 2025-10-01 09:45:47 --> Total execution time: 0.2827
INFO - 2025-10-01 04:47:52 --> Config Class Initialized
INFO - 2025-10-01 04:47:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:47:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:47:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:47:52 --> URI Class Initialized
INFO - 2025-10-01 04:47:52 --> Router Class Initialized
INFO - 2025-10-01 04:47:52 --> Output Class Initialized
INFO - 2025-10-01 04:47:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:47:52 --> CSRF cookie sent
INFO - 2025-10-01 04:47:52 --> Input Class Initialized
INFO - 2025-10-01 04:47:52 --> Language Class Initialized
INFO - 2025-10-01 04:47:52 --> Loader Class Initialized
INFO - 2025-10-01 04:47:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:47:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:47:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:47:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:47:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:47:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:47:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:47:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:47:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:47:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:47:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:47:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:47:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:47:52 --> Controller Class Initialized
INFO - 2025-10-01 09:47:52 --> Model "Pusat_model" initialized
INFO - 2025-10-01 09:47:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:47:52 --> Model "Sdm_model" initialized
INFO - 2025-10-01 09:47:52 --> Model "Sdm_pusat_model" initialized
INFO - 2025-10-01 09:47:52 --> Query SDM berhasil untuk pusat: Pusat Pengembangan Pendidikan, Total: 1
INFO - 2025-10-01 09:47:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\pusat/list.php
INFO - 2025-10-01 09:47:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:47:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:47:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:47:52 --> Total execution time: 0.0764
INFO - 2025-10-01 04:48:41 --> Config Class Initialized
INFO - 2025-10-01 04:48:41 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:48:41 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:48:41 --> Utf8 Class Initialized
INFO - 2025-10-01 04:48:41 --> URI Class Initialized
INFO - 2025-10-01 04:48:41 --> Router Class Initialized
INFO - 2025-10-01 04:48:41 --> Output Class Initialized
INFO - 2025-10-01 04:48:41 --> Security Class Initialized
DEBUG - 2025-10-01 04:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:48:41 --> CSRF cookie sent
INFO - 2025-10-01 04:48:41 --> Input Class Initialized
INFO - 2025-10-01 04:48:41 --> Language Class Initialized
INFO - 2025-10-01 04:48:41 --> Loader Class Initialized
INFO - 2025-10-01 04:48:41 --> Helper loaded: url_helper
INFO - 2025-10-01 04:48:41 --> Helper loaded: text_helper
INFO - 2025-10-01 04:48:41 --> Helper loaded: string_helper
INFO - 2025-10-01 04:48:41 --> Helper loaded: form_helper
INFO - 2025-10-01 04:48:41 --> Helper loaded: download_helper
INFO - 2025-10-01 04:48:41 --> Helper loaded: security_helper
INFO - 2025-10-01 04:48:41 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:48:41 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:48:41 --> Form Validation Class Initialized
INFO - 2025-10-01 04:48:41 --> Model "User_model" initialized
INFO - 2025-10-01 09:48:41 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:48:41 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:48:41 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:48:41 --> Controller Class Initialized
INFO - 2025-10-01 09:48:41 --> Model "Sdm_model" initialized
INFO - 2025-10-01 09:48:41 --> Model "Jabatansdm_model" initialized
INFO - 2025-10-01 09:48:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\sdm/list.php
INFO - 2025-10-01 09:48:41 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:48:41 --> Model "Log_model" initialized
INFO - 2025-10-01 09:48:41 --> Final output sent to browser
DEBUG - 2025-10-01 09:48:41 --> Total execution time: 0.2783
INFO - 2025-10-01 04:48:52 --> Config Class Initialized
INFO - 2025-10-01 04:48:52 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:48:52 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:48:52 --> Utf8 Class Initialized
INFO - 2025-10-01 04:48:52 --> URI Class Initialized
DEBUG - 2025-10-01 04:48:52 --> No URI present. Default controller set.
INFO - 2025-10-01 04:48:52 --> Router Class Initialized
INFO - 2025-10-01 04:48:52 --> Output Class Initialized
INFO - 2025-10-01 04:48:52 --> Security Class Initialized
DEBUG - 2025-10-01 04:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:48:52 --> CSRF cookie sent
INFO - 2025-10-01 04:48:52 --> Input Class Initialized
INFO - 2025-10-01 04:48:52 --> Language Class Initialized
INFO - 2025-10-01 04:48:52 --> Loader Class Initialized
INFO - 2025-10-01 04:48:52 --> Helper loaded: url_helper
INFO - 2025-10-01 04:48:52 --> Helper loaded: text_helper
INFO - 2025-10-01 04:48:52 --> Helper loaded: string_helper
INFO - 2025-10-01 04:48:52 --> Helper loaded: form_helper
INFO - 2025-10-01 04:48:52 --> Helper loaded: download_helper
INFO - 2025-10-01 04:48:52 --> Helper loaded: security_helper
INFO - 2025-10-01 04:48:52 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:48:52 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:48:52 --> Form Validation Class Initialized
INFO - 2025-10-01 04:48:52 --> Model "User_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:48:52 --> Controller Class Initialized
INFO - 2025-10-01 09:48:52 --> Model "Berita_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Galeri_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Video_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Agenda_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Tautan_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Mitra_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Jurusan_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Prodi_model" initialized
INFO - 2025-10-01 09:48:52 --> Model "Testimoni_model" initialized
INFO - 2025-10-01 09:48:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-10-01 09:48:52 --> Pagination Class Initialized
INFO - 2025-10-01 09:48:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2025-10-01 09:48:52 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2025-10-01 09:48:52 --> Model "Log_model" initialized
INFO - 2025-10-01 09:48:52 --> Final output sent to browser
DEBUG - 2025-10-01 09:48:52 --> Total execution time: 0.1293
INFO - 2025-10-01 04:53:15 --> Config Class Initialized
INFO - 2025-10-01 04:53:15 --> Hooks Class Initialized
DEBUG - 2025-10-01 04:53:15 --> UTF-8 Support Enabled
INFO - 2025-10-01 04:53:15 --> Utf8 Class Initialized
INFO - 2025-10-01 04:53:15 --> URI Class Initialized
INFO - 2025-10-01 04:53:15 --> Router Class Initialized
INFO - 2025-10-01 04:53:15 --> Output Class Initialized
INFO - 2025-10-01 04:53:15 --> Security Class Initialized
DEBUG - 2025-10-01 04:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-01 04:53:15 --> CSRF cookie sent
INFO - 2025-10-01 04:53:15 --> Input Class Initialized
INFO - 2025-10-01 04:53:15 --> Language Class Initialized
INFO - 2025-10-01 04:53:15 --> Loader Class Initialized
INFO - 2025-10-01 04:53:15 --> Helper loaded: url_helper
INFO - 2025-10-01 04:53:15 --> Helper loaded: text_helper
INFO - 2025-10-01 04:53:15 --> Helper loaded: string_helper
INFO - 2025-10-01 04:53:15 --> Helper loaded: form_helper
INFO - 2025-10-01 04:53:15 --> Helper loaded: download_helper
INFO - 2025-10-01 04:53:15 --> Helper loaded: security_helper
INFO - 2025-10-01 04:53:15 --> Helper loaded: image_optimizer_helper
INFO - 2025-10-01 04:53:15 --> Database Driver Class Initialized
DEBUG - 2025-10-01 04:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-01 04:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-01 04:53:15 --> Form Validation Class Initialized
INFO - 2025-10-01 04:53:15 --> Model "User_model" initialized
INFO - 2025-10-01 09:53:15 --> Model "Kunjungan_model" initialized
INFO - 2025-10-01 09:53:15 --> Model "Konfigurasi_model" initialized
INFO - 2025-10-01 09:53:15 --> Model "Nav_model" initialized
INFO - 2025-10-01 09:53:15 --> Controller Class Initialized
INFO - 2025-10-01 09:53:15 --> Model "Sdm_model" initialized
INFO - 2025-10-01 09:53:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/sdm/list.php
INFO - 2025-10-01 09:53:15 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\admin/layout/wrapper.php
INFO - 2025-10-01 09:53:15 --> Model "Log_model" initialized
INFO - 2025-10-01 09:53:15 --> Final output sent to browser
DEBUG - 2025-10-01 09:53:15 --> Total execution time: 0.1962
