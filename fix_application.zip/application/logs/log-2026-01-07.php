<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-07 03:23:18 --> Config Class Initialized
INFO - 2026-01-07 03:23:18 --> Hooks Class Initialized
DEBUG - 2026-01-07 03:23:18 --> UTF-8 Support Enabled
INFO - 2026-01-07 03:23:18 --> Utf8 Class Initialized
INFO - 2026-01-07 03:23:18 --> URI Class Initialized
DEBUG - 2026-01-07 03:23:19 --> No URI present. Default controller set.
INFO - 2026-01-07 03:23:19 --> Router Class Initialized
INFO - 2026-01-07 03:23:19 --> Output Class Initialized
INFO - 2026-01-07 03:23:19 --> Security Class Initialized
DEBUG - 2026-01-07 03:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-07 03:23:19 --> CSRF cookie sent
INFO - 2026-01-07 03:23:19 --> Input Class Initialized
INFO - 2026-01-07 03:23:19 --> Language Class Initialized
INFO - 2026-01-07 03:23:19 --> Loader Class Initialized
INFO - 2026-01-07 03:23:19 --> Helper loaded: url_helper
INFO - 2026-01-07 03:23:19 --> Helper loaded: text_helper
INFO - 2026-01-07 03:23:19 --> Helper loaded: string_helper
INFO - 2026-01-07 03:23:19 --> Helper loaded: form_helper
INFO - 2026-01-07 03:23:19 --> Helper loaded: download_helper
INFO - 2026-01-07 03:23:19 --> Helper loaded: security_helper
INFO - 2026-01-07 03:23:19 --> Helper loaded: image_optimizer_helper
INFO - 2026-01-07 03:23:20 --> Database Driver Class Initialized
DEBUG - 2026-01-07 03:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-01-07 03:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-07 03:23:20 --> Form Validation Class Initialized
INFO - 2026-01-07 03:23:20 --> Model "User_model" initialized
INFO - 2026-01-07 09:23:20 --> Model "Kunjungan_model" initialized
INFO - 2026-01-07 09:23:20 --> Model "Konfigurasi_model" initialized
INFO - 2026-01-07 09:23:20 --> Model "Nav_model" initialized
INFO - 2026-01-07 09:23:20 --> Controller Class Initialized
INFO - 2026-01-07 09:23:20 --> Model "Berita_model" initialized
INFO - 2026-01-07 09:23:20 --> Model "Galeri_model" initialized
INFO - 2026-01-07 09:23:21 --> Model "Video_model" initialized
INFO - 2026-01-07 09:23:21 --> Model "Agenda_model" initialized
INFO - 2026-01-07 09:23:21 --> Model "Tautan_model" initialized
INFO - 2026-01-07 09:23:21 --> Model "Mitra_model" initialized
INFO - 2026-01-07 09:23:21 --> Model "Jurusan_model" initialized
INFO - 2026-01-07 09:23:21 --> Model "Prodi_model" initialized
INFO - 2026-01-07 09:23:21 --> Model "Testimoni_model" initialized
INFO - 2026-01-07 09:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-07 09:23:21 --> Pagination Class Initialized
INFO - 2026-01-07 09:23:23 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\home/list.php
INFO - 2026-01-07 09:23:24 --> File loaded: D:\xampp\htdocs\dev_jkt3\application\views\layout/wrapper.php
INFO - 2026-01-07 09:23:24 --> Model "Log_model" initialized
INFO - 2026-01-07 09:23:24 --> Final output sent to browser
DEBUG - 2026-01-07 09:23:24 --> Total execution time: 5.9297
